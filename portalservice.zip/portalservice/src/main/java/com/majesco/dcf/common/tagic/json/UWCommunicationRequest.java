package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

public class UWCommunicationRequest {
	private String customerName;
	private String policyNo;
	private String premiumAmt;
	private String ProductName;
	private String prvPolExpDt;
	private String vehicleRegNo;
	private String agentName;
	private String producerMobile;
	private String producerEmail;
	private String customerId;
	private String productCode;
	private String polIncptionDt;
	private String proposalNo;
	private String customerEmail;
	private String customerMobile;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getPremiumAmt() {
		return premiumAmt;
	}
	public void setPremiumAmt(String premiumAmt) {
		this.premiumAmt = premiumAmt;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public String getPrvPolExpDt() {
		return prvPolExpDt;
	}
	public void setPrvPolExpDt(String prvPolExpDt) {
		this.prvPolExpDt = prvPolExpDt;
	}
	public String getVehicleRegNo() {
		return vehicleRegNo;
	}
	public void setVehicleRegNo(String vehicleRegNo) {
		this.vehicleRegNo = vehicleRegNo;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getProducerMobile() {
		return producerMobile;
	}
	public void setProducerMobile(String producerMobile) {
		this.producerMobile = producerMobile;
	}
	public String getProducerEmail() {
		return producerEmail;
	}
	public void setProducerEmail(String producerEmail) {
		this.producerEmail = producerEmail;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getPolIncptionDt() {
		return polIncptionDt;
	}
	public void setPolIncptionDt(String polIncptionDt) {
		this.polIncptionDt = polIncptionDt;
	}
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerMobile() {
		return customerMobile;
	}
	public void setCustomerMobile(String customerMobile) {
		this.customerMobile = customerMobile;
	}
	
	
}

package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.entity.GarageRadius;
import com.majesco.dcf.common.tagic.json.GarageRadiusRequest;
import com.majesco.dcf.common.tagic.json.GarageRadiusResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;

@Service
public class GarageRadiusService {
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(GarageRadiusService.class);
	
	@SuppressWarnings({ "null", "unchecked" })
	public GarageRadiusResponse getLongLat(GarageRadiusRequest docreq) throws Exception
	{
		GarageRadiusResponse docres = new GarageRadiusResponse();
		ArrayList docArr = new ArrayList();
		try
		{
		
			logger.info("In DocumentService.FetchDocumentInfo() Method Begin()...");
			
			List<String> lstaddress = new ArrayList<String>();
			List<String> lstlongitude = new ArrayList<String>();
			List<String> lstlattitude = new ArrayList<String>();
			List<ResponseError> reserrList = new ArrayList<ResponseError>();
			
			ResponseError res = new ResponseError();
			res.setErrorCode("101");
			res.setErrorMMessag("Sorry Authentication Issue....");
			reserrList.add(res);
	
			//docArr = (ArrayList) dbserv.getGarageRadius("com.majesco.dcf.common.tagic.entity.DocumentMaster", docreq);
			List<GarageRadius> idvList =  (List<GarageRadius>) dbserv.getLongLat("com.majesco.dcf.common.tagic.entity.GarageRadius", docreq);
	        for(GarageRadius idv:idvList){
	        
	        	lstaddress.add(idv.getAddress());
	        	lstlongitude.add(idv.getNlongitude());
	        	lstlattitude.add(idv.getNlatitude());
	        }
			/*for(int i=0; i< docArr.size(); i++)
			{
				
				lstStrstrdoccd.add(docres.getStrdoccd());
				lstStrdcodesc.add(docres.getStrdcodesc());
		        		        
	        }*/
			docres.setAddress(lstaddress);
			docres.setNlongitude(lstlongitude);
			docres.setNlatitude(lstlattitude);
		}
		catch(Exception e)
		{
			//System.out.println(e.toString());
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In DocumentService.DocumentInfo() Method End()...");
//		ObjectMapper objMap=new ObjectMapper();
//		System.out.println(objMap.writeValueAsString(docres));
		logger.info("In DocumentService.DocumentInfo() Method :: Response Of variantres : "+docres);
		
		return docres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }
}

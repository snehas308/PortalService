package com.majesco.dcf.claims.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CoverageDetails {

	private String coverageCode;
	private String coverageName;
	private String coverGroupIndex;
	public String getCoverageCode() {
		return coverageCode;
	}
	public void setCoverageCode(String coverageCode) {
		this.coverageCode = coverageCode;
	}
	public String getCoverageName() {
		return coverageName;
	}
	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}
	public String getCoverGroupIndex() {
		return coverGroupIndex;
	}
	public void setCoverGroupIndex(String coverGroupIndex) {
		this.coverGroupIndex = coverGroupIndex;
	}
	
	
}

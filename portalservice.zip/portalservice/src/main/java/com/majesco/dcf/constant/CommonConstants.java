package com.majesco.dcf.constant;

public class CommonConstants {

	private CommonConstants(){}

	public static final String MOTOR_SERVICE = "MotorService";
	public static final String MOTOR_SERVICE_TWOWHEELER = "MotorServiceTwoWheeler";
	public static final String MOTOR_SERVICE_PRIVATECAR = "MotorServicePrivateCar";
	public static final String MOTOR_SERVICE_COMMERCIAL = "MotorServiceCommercial";
	public static final String MOTOR_CLAIM_SERVICE = "MotorServiceClaim";
	public static final String AUTHENTICATION_SERVICE = "AuthenticationService";
	public static final String POLICY_SEARCH = "PolicySearchMotor";
	public static final String MASTER_MAP_ENTRY = "9999";
	public static final String MASTER_ROLLOVER = "Rollover";
	public static final String MASTER_NEW_BUSINESS = "New Business";
	public static final String MASTER_USED_CAR = "Used Car";
	public static final String ACCOUNTSERVICE_ID="AccountService";
	public static final String AUTOMOBILE_ASSOC_NAME = "AASI";
	public static final String AUTOMOBILE_ASSOC_MEMBER_NUM = "12345";
	public static final String AUTOMOBILE_ASSOC_FALSE_STATUS = "false";
	public static final String AUTOMOBILE_ASSOC_TRUE_STATUS = "true";
	public static final String CREATECUSTOMER_SERVICE = "CreateCustomerService";

	public static final String BUSINESSTYPE_IPA_SYSTEM_PARAMCD="1023";
	public static final String GENDERCD_SYSTEM_PARAMCD="5504";
	public static final String MARITALSTATUS_SYSTEM_PARAMCD="1005";
	public static final String NATIONALITY_SYSTEM_PARAMCD="1003";
	public static final String OCCUPATION_SYSTEM_PARAMCD="1045";
	public static final String IDTYPE_SYSTEM_PARAMCD="1007";
	public static final String TITLE_SYSTEM_PARAMCD="1002";
	public static final String PRIVATE_CAR_LITE_SERVICE = "PrivateCarLiteService";
	public static final String PRIVATE_TW_LITE_SERVICE = "PrivateTWLiteService";
	/*public static final String SOURCE="0";
	public static final String MEDIUM="0";
	public static final String CAMPAIGN="0";*/

	public static final String SOURCE="TATA-AIG";
	public static final String MEDIUM="NEWCHANNEL";
	public static final String CAMPAIGN="NEWCHANNEL";

	public static final String BILLDESK_PAY_REQ = "billdeskPayReq";
	public static final String BILLDESK_PAY_RES = "billdeskResponsePage";
	public static final String SELF_PAY_RES = "billdeskPayRes";
	public static final String SELF_PAYMENT_PAGE = "selfPayPage";

	public static final String PRE_INSPECTION_SERVICE="VehicleInspectionService";
	public static final String InterfaceParam_Entity="com.majesco.dcf.common.tagic.entity.InterfaceParam";
	public static final String SUCCESS_STATUS="1";
	public static final String FAILURE_STATUS="0";
	public static final String BLANK_STRING="";

	public static final String TERTIARY_MO_CODE="A_PORTAL";
	public static final String CREATED_DATE="CreatedDate";
public static final String PROPOSAL_STATUS_SERVICE="GenConfStubService";

	// Added for payment Unique order ID
	public static String UNIQUE_SEQUENCE = "yyyyMMddHHmmss";
	public static String BILLDESK_PREFIX="CHP";
	
	//Start:-<YogeshM><06/12/2017><Defect-HotFixed><to get unique sequence of CHP in spl link>
	public static String UNIQUE_SEQUENCE_PG = "yyyyMMddHHmmssSSS";
	//End:-<YogeshM><06/12/2017><Defect-HotFixed><to get unique sequence of CHP in spl link>

	public static final String DEFAULT_ZERO_VALUE="0";
	public static final String DEFAULT_FALSE_STATUS="false";
	public static final String DEFAULT_TRUE_STATUS="true";

	public static final String DEFAULT_INDIGENOUS="Indigenous";
	public static final String DEFAULT_IMPORTED="Imported";
	public static final String DEFAULT_OBSOLETE="Obsolete";

	public static final String PRINT_PROP_POL_DOCUMENT_SERVICE="GetDocumentForPortalService";

	public static final String WORKFLOWID_STARTWITH="W";
	public static final String ERRORA001 = "ERRORA001";
	public static final String ERRORT001 = "ERRORT001";

	public static final String YES_FLAG_VAL1="YES";

	public static final String YES_FLAG_VAL2="Y";
	public static final String NOT_APPLICABLE_VAL="NA";

	public static final String MOTOR_QUOTE_SEARCH_SERVICE="MotorQuoteSearch";
	public static final Boolean BOOLEAN_TRUE_FLAG=true;
	public static final Boolean BOOLEAN_FALSE_FLAG=false;
	public static final String NEWPOLICY_MOD_OPR="NEWPOLICY";

	public static final String GENERIC_SERVICE="GenericIntegration";

	public static final String PROP_PENDING_QUOTE_STATUS="NQTN";
	public static final String PROP_PENDING_INSPECTION_STATUS="NPVI";
	public static final String RENEWAL_PENDING_INSPECTION_STATUS="RPVI";
	public static final String RENEWAL_REJECTED_STATUS="RR";
	public static final String PROP_REJECTED_STATUS="NR";
	public static final String RENEWAL_PENDING_APPROVAL_STATUS="RPA";
	public static final String PROP_PENDING_APPROVAL_STATUS="NPA";
	public static final String PROP_PENDING_PAYMENT_STATUS1="NCCA";
	public static final String RENEWAL_PENDING_PAYMENT_STATUS1="RCCA";
	public static final String PROP_PENDING_PAYMENT_STATUS2="NCCN";
	public static final String RENEWAL_PENDING_PAYMENT_STATUS2="RCCN";
	public static final String PROP_PENDING_PAYMENT_STATUS3="NPQC2";
	public static final String RENEWAL_PENDING_PAYMENT_STATUS3="RPQC2";
	public static final String BILLDESK_SUCCESS="0300";

	public static final String PRIVATE_CAR_PRODUCT_CODE="3121";
	public static final String CITY_WHERE_PRIMARILY_USED_NAME="MUMBAI";
	public static final String CITY_WHERE_PRIMARILY_USED_CODE="18136";
	public static final String EXPERIENCING_ISSUE = "System Is Experiencing Issue, Please Try After Some Time.";

	//Constants added for EMAIL & SMS
	public static final String SEND_EMAIL="EMAIL";
	public static final String SEND_SMS="SMS";
	public static final String EVENT_SELFPAYMENT_LINK="SelfPayLink";
	public static final String EVENT_PAYMENT_SUCCESS="PMT_SUC_OL";
	public static final String EVENT_OFFLINE_PAYMENT_SUCCESS="PMT_SUC_OF";
	public static final String EVENT_CREATE_PROPOSAL_IPA="PR_IPA";
	public static final String EVENT_CREATE_PROPOSAL_MOTOR="PR_MOTOR";
	public static final String EVENT_PAYMENT_FAILED="PMT_FAIL_OL";
	public static final String EVENT_OFFLINE_COVERNOTE_PAYMENT_SUCCESS="PMT_CN_SUC_OF";
	public static final String EVENT_RENEWAL_PAYMENT_SUCCESS_MOTOR="REN_PMT_SUC_OF_MOTOR";
	public static final String EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR="REN_PR_MOTOR";
	public static final String EVENT_RENEWAL_PROPOSAL_GENERATED_IPA="REN_PR_IPA";
	public static final String EVENT_RENEWAL_PENDING_UW_MOTOR="REN_PENDING_UW_MOTOR";
	public static final String EVENT_RENEWAL_SELFPAYMENT_LINK_IPA="REN_SelfPayLink_IPA";
	public static final String EVENT_RENEWAL_SELFPAYMENT_LINK_MOTOR="REN_SelfPayLink_MOTOR";
	public static final String EVENT_RENEWAL_PAYMENT_SUCCESS_PRODUCER="REN_PMT_SUC_OF_MOTOR_PRODUCER";
	public static final String EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR_PRODUCER="REN_PR_MOTOR_PRODUCER";
	public static final String EVENT_RENEWAL_PROPOSAL_GENERATED_IPA_PRODUCER="REN_PR_IPA_PRODUCER";
	public static final String EVENT_RENEWAL_PENDING_UW_PRODUCER="REN_PENDING_UW_PRODUCER";
	public static final String EVENT_RENEWAL_NOTICE_FOR_CUSTOMER="REN_Policy_Reminder_Mailer";  // 1704 | Vishal J | Constant added for Renewal Notice.
	//ISSUE:9870467
	public static final String PMT_PENDING="PMT_PENDING";
	///END:9870467
	
	
	public static final String TWO_WHEELER_PRODUCT_CODE="3122";
	public static final String COMMERCIAL_PRODUCT_CODE="3124";

	public static final String PROP_POL_NEW_STATUS_REVERSE_MAP_CATG="9998";
	public static final String MOTOR_TWO_WHEELER_IDV_PERCENTAGE_TEN = "10";
	public static final String MOTOR_TWO_WHEELER_IDV_PERCENTAGE_FIFTEEN = "15";
	public static final String MOTOR_TWO_WHEELER_IDV_PERCENTAGE = "10";
	public static final String PROPOSAL_STATUS_CODE = "1097";

	public static final String MOTOR_ENTITLED_NCB_NO="No";
	public static final String MOTOR_ENTITLED_NCB_Yes="Yes";

	public static final String Renewal_Search_LobCode_Cat="";
	public static final String Renewal_Search_ProductCode_Cat="9900";
	public static final String GENERIC_COVERNOTE_SERVICE="GenericService";
	public static final String WCF_GC_INTEGRATION_SERVICE="WCFGCIntegrationService";
	public static final String COVERNOTE_MISSING="2";
	public static final String COVERNOTE_CANCELLED="1";
	public static final String COVERNOTE_DESCREPANCY="3";
	public static final String USEDBOOK_SENT_TO_TAGIC="4";
	public static final String CANCELED_CN_SENT_TO_TAGIC="5";
	public static final String CANCEL_COVERNOTE_MISSING="Missing";
	public static final String CANCEL_COVERNOTE_LOST="LOST";
	public static final String CANCEL_COVERNOTE_PHYSICALLY_CANCELLED="Physically Cancelled";
	public static final String CANCEL_COVERNOTE_CANCELLED="CANCELLED";
	public static final String CANCEL_COVERNOTE_DISCREPANCY="Discrepancy";
	public static final String CANCEL_COVERNOTE_USED_BOOK_TAGIC="Used Book Sent To TAGIC";
	public static final String CANCEL_COVERNOTE_CANCELLED_COVERNOTE_TAGIC="Cancelled Covernote Sent to TAGIC";
	public static final String CANCEL_COVERNOTE_OTHER="Other";

	public static final String COMMERCIAL_SUBPRODUCT_RULE_CHECK="Goods Carrying Vehicle";
	public static final String COMMERCIAL_GVW_RULE_CHECK_STRING="GVW";
	public static final String COMMERCIAL_PORTAL_RULE_STRING="Decline GCV Non Preferred State";
	public static final String PRIVATE_PORTAL_RULE_STRING="Decline SATP Non Preferred State";
	public static final String TWO_WHEELER_PORTAL_RULE_STRING="Decline SATP Non Preferred State";

	public static final String USERTRANSACTION_ENTITY_CLASSNAME="com.majesco.dcf.common.tagic.entity.UserTransaction";
	public static final String CUSTOMER_ENTITY_CLASSNAME="com.majesco.dcf.common.tagic.entity.CustomerEntity";
	public static final String CITY_ENTITY_CLASSNAME="com.majesco.dcf.common.tagic.entity.City";

	public static final String PRIVATE_CAR_LIABILITYONLY="LiabilityOnly";

	public static final String USER_SUBTYPE_PRODUCER="PRODUCER";
	public static final String USER_SUBTYPE_DEALER="DEALER";
	public static final String USER_SUBTYPE_PORTALADMIN="PortalAdmin";
	public static final String VEHICLE_INSPECTION_WARNING_MESSAGE = "Vehicle Inspection is required for this proposal .";
	
	public static final String PASSWORD_CHANGE_GC_RESPONSE="PASSWORD CHANGED SUCCESSFULLY!!";
	public static final String PORTAL_ADMIN_TYPE="PortalAdmin";
	public static final String SECURITY_QUESTION_PARAM_CODE="7778";
	public static final String FORGOTPASS_GC_SUCCESS_RESPONSE="Password retrieved successfully";
	public static final String PRIVILEGE_SYS_PARAM_CODE="7777";
	public static final String SYSTEM_PARAM_TYPE="1";
	public static final String USER_PARAM_TYPE="2";
	
	public static final String EVENT_PAYMENT_SUCCESS_PRODUCER="PRODUCER_PMT_SUC_OL";
	public static final String EVENT_OFFLINE_PAYMENT_SUCCESS_PRODUCER="PRODUCER_PMT_SUC_OF";
	public static final String EVENT_CREATE_PROPOSAL_IPA_PRODUCER="PRODUCER_PR_IPA";
	public static final String EVENT_CREATE_PROPOSAL_MOTOR_PRODUCER="PRODUCER_PR_MOTOR";
	public static final String EVENT_PAYMENT_FAILED_PRODUCER="PRODUCER_PMT_FAIL_OL";
	
	/*DEFECT 526 -Constant field added*/
	public static final String CLAIM_AMOUNT_CONSTANT ="1";
	
	public static final String CASH_ACCOUNT_NUMBER ="123456789";
	public static final String CASH_HOUSEBANKBRANCH_NUMBER ="10013";
	
	public static final String CHEQUE_ACCOUNT_NUMBER ="123456789";
	public static final String CHEQUE_HOUSEBANKBRANCH_NUMBER ="10013";
	
	public static final String DEMANDDRAFT_ACCOUNT_NUMBER ="912020044796381";
	public static final String DEMANDDRAFT_HOUSEBANKBRANCH_NUMBER ="10525";
	
	public static final String ONLINE_ACCOUNT_NUMBER ="123456789";
	public static final String ONLINE_HOUSEBANKBRANCH_NUMBER ="10013";
	public static final String STATUS_PENDING_UNDERWRITING ="RPA";
	
	public static final String DATAENTRY_USER_STATUS_MSG="User Created Successfully. User id is ";
	public static final String SYSTEM_FAILED_SERVICE_MSG="System Failed to call service... !!!";
	
	public static final String USER_SUBTYPE_SUBPRODUCER="SUB PRODUCER";
	
	public static final String BLANK_SINGLE_SPACE_STRING=" ";
	
	public static final String MORATORIUM_ERROR_MESSAGE="Declined- For moratorium vehicle";
	public static final String MORATORIUM_ERROR_MESSAGE_1="This is a moratorium vehicle. Kindly contact Tata AIG"; // Added for CR 3530 by Anil on 03/04/2018
	
	public static final String IndividualCustomer="I";
	
	public static final String OrganizationCustomer="O";
	
	public static final String Maximimum_Tow_Charge_Private_Car="MAX_TOW_CHARGES_PV";
	public static final String Maximimum_Tow_Charge_Two_Wheeler="MAX_TOW_CHARGES_TW";
	public static final String Maximimum_Tow_Charge_Commercial="MAX_TOW_CHARGES_CV";
	
	public static final String System_Master_Code="sys";
	public static final String User_Master_Code="usr";

	public static final String DOCUMENTLIST_NEW="1";
	public static final String DOCUMENTLIST_ROLLOVER="2";
	public static final String DOCUMENTLIST_USEDCAR="3";
	public static final String DOCUMENTLIST_RENEWAL="4";
	
	public static final String RELATIONSHIP_SYSTEM_PARAMCD="1057";
	public static final String OCCUPATONCLASSOFSELF_SYSTEM_PARAMCD="1004";
	public static final String RECORD_STATUS_ACTIVE = "A";
	public static final String QUOTESEARCH_LIMIT_DAYS_SYSTEM_PARAMCD="MOTOR_QUOTE_VALID_DAYS";
	
	public static final String DASHBOARD_APPROVAL_PENDING="ApprovalPendingService";
	//Start:02/06/2017:Defect_ID:1231:Added constant for No flag
	public static final String NO_FLAG_VAL1="N";
	//End:02/06/2017:Defect_ID:1231:Added constant for No flag
	public static final String ORA_EXCEPTION_STRING = "ORA EXCEPTION"; //Added For ORA EXCEPTION Change
	
	public static final String PAYMENT_FALURE_GENERIC_ERR_MSG = "SOMETHING SEEMS TO HAVE GONE WRONG! PLEASE TAKE A SCREENSHOT AND CONTACT OUR CUSTOMER CARE ON 1800 266 7780 ALONG WITH THE REFERENCE ID’S MENTIONED ON THE SCREEN";  // Constant Added | 1825 | Vishal J | 10-Aug-2017 
	public static final String IS_ERROR_STRING = "isError"; 
//Start: RahulT <Production 2027>| constant added for payment methods
	public static final String PAYMENT_METHOD_AD="AD";
	public static final String PAYMENT_METHOD_SPL="SPL";
	//End: RahulT <Production 2027>| constant added for payment methods
	//Start: RahulT <1266> | UPI payment integration with channel portal
	public static final String UPI_POLICY_GENERATION_INITIATED="1";
	//End: RahulT <1266> | UPI payment integration with channel portal
	// Start: KetanM <Production 2505>| Re-hit mechanism to be put up for policycumreciept generation service
	public static final String PROCESS_REHIT_MECH_ORDER_ID="strorderid";
	public static final String PROCESS_REHIT_MECH_JSON_REQUEST="strrequestmsg";
	public static final String PROCESS_REHIT_MECH_POSTAUTHCODE="strpgtxnrefno";
	public static final String PROCESS_REHIT_MECH_CONFIG_KEY="REHITCOUNT";
	public static final String PROCESS_REHIT_MECH_SUCCESS_MESSAGE="Policy Has Been Created Successfully";
	public static final String PROCESS_REHIT_MECH_SUCCESSFULLY_PERFORMED="Rehit Performed On This Record Without Exception";
	// End: KetanM <Production 2505>| Re-hit mechanism to be put up for policycumreciept generation service
	public static final String POLICY_CREATION_EVENT="paymentEntryCumPolicyGen";
	//Start: KetanM <SIT 2594>| service exposed to getFastLaneIntegration on 29 Nov 2017
	public static final String FASTLANE_EXCEPTION="Something Went Wrong. Please Try After Some Time.";
	public static final String FASTLANE_SERVICE="FastlaneService";
	//End: KetanM <SIT 2594>| service exposed to getFastLaneIntegration on 29 Nov 2017
	//Start: KetanM <SIT 2717>| service exposed to getHouseBankAndAccountNo on 11 Dec 2017
	public static final String FASTLANE_WRONG_OPERATION_MSG="Please Check The Operation Type In Request";
	//End: KetanM <SIT 2717>| service exposed to getHouseBankAndAccountNo on 11 Dec 2017
public static final String RENEWAL_EXP_DAY_LIMIT = "REN_EXP_DAY_LIMIT";  //Added For Issue ID 3330
public static final String RENEWAL_ENTITY_CLASSNAME="com.majesco.dcf.common.tagic.entity.RenPolicyMaster";	
public static final String SEGMENT_TYPE_CODE_HIGH_END="4";//Added For Issue ID 3270
public static final String ADDON_WRONG_OPERATION_MSG="Please Check Request, Required Inputs Are Not Proper.";//Added For Issue ID 3270
	public static final String HOUSE_BANK_RETREIVING_ISSUE="Unable To Fetch House Bank Details, Please Try After Some Time.";//Added For Issue ID 2717 - ICICI House Bank Changes
	public static final String HOUSE_BANK_RESPONSE_ISSUE="Something Went Wrong, Please Try After Some Time.";//Added For Issue ID 2717 - ICICI House Bank Changes
	public static final String INTERNAL_POSP_TYPE="INTERNAL POSP"; // 
	public static final String EXTERNAL_POSP_TYPE="EXTERNAL POSP";	
	//Start:<YogeshM>:<19/02/2018>:<SIT>:<DefectID-HotFixed>:<for paymentmode optn "Payment link to Customer" & "Online Payment modes" need to send value as "DA">
	public static final String HOUSE_BANK_PAYMENT_MODE_OL_SP="DA"; 
	public static final String HOUSE_BANK_PAYMENT_MODE_UI_SP="SP";
	public static final String HOUSE_BANK_PAYMENT_MODE_UI_OL="OL";
	//End:<YogeshM>:<19/02/2018>:<SIT>:<DefectID-HotFixed>:<for paymentmode optn "Payment link to Customer" & "Online Payment modes" need to send value as "DA">
	//START: 28-02-2018:Code changes for defects 2753 ,3268, 3284,3350 
	public static final String  USER_SUBTYPE_FIELDUSER="FieldUser";
	public static final String PG_REDIRECT_FLAG="PG_REDIRECT_FLAG";
	public static final String CPI_PAY_REQ = "cpiPayReq";
	//Document upload by Rahul Kumar
	public static final String DOC_UPLOAD_DTLS_ENTITY="com.majesco.dcf.docmgmt.entity.DocUploadDtlsEntity";
	public static final String RESP_HTTPSTATUS_OK="Document saved successfully";
	public static final String RESP_HTTPSTATUS_422_USERID="Please provide a UserId!";
	public static final String RESP_HTTPSTATUS_422_FILES="please select a file!";
	public static final String RESP_HTTPSTATUS_422_PROPNO="please provide a proposalNo!";
	public static final String RESP_HTTPSTATUS_422_DOCMAPID="please provide a DocMapId!";
	public static final String DOCUMENT_UPLOAD_USER_STRING="DOCUPLDUSERLIMIT";
	public static final String DOCUMENT_UPLOAD_QCUSER_STRING="DOCUPLDQCUSERLIMIT";
	public static final String DCF_DOCUMENT_UPLOAD_OPTN_LATER="LATER";
	public static final String DCF_DOCUMENT_UPLOAD_OPTN_ENTITY="com.majesco.dcf.docmgmt.entity.DocUploadOptn";
	public static final String DCF_DOCUPLOAD_DTLS_DOC_STATUS = "R";
	public static final String PRODUCER_COUNT_DOC_UPLOAD_MSG="Please Upload Your Pending Documents to enable Proceed to Pay, Which are Opted By You As UPLOAD LATER.";
	public static final String QC_USER_COUNT_DOC_UPLOAD_MSG="Please Upload Documents Again to enable Proceed to Pay, Which are Rejected By QC Team.";
	public static final String PRODUCER_AND_QC_USER_COUNT_DOC_UPLOAD_MSG="Please Upload Your Pending Documents to enable Proceed to Pay, Which are in pending and rejected by QC status.";
	public static final String CUST_DOC_UPLOAD_PAGE = "custDocUploadPage";		//Document Upload Customer Doc Upload Page
	public static String CUST_DOC_PREFIX="CDU";
	public static final String EVENT_CUST_DOC_UPLOAD_LINK="CUST_DOC_UPLOAD_LINK";
	//Document Upload Finish
	
	
	//Start:DineshS | For Lite service for save proposal PV on 26 July 2017
	public static final String MOTOR_SERVICE_PRIVATECAR_LITE = "MotorServicePrivateCarLite";
	public static final String SUCCESS_VALUE="S";
	public static final String FAILURE_VALUE="F";
	public static final String PDF_SUCCESS="EncodedStringNotEmpty";
	public static final String PDF_FAILURE="EncodedStringEmpty";
	public static final String SMS_SUCCESS="SMS_SUCCESS";
	public static final String SMS_FAILURE= "SMS_FAILURE";
	public static final String RECEIPT_ENTRY_FOR_BFL = "RECEIPT_ENTRY_FOR_BFL";
	public static final String PROPOSAL_TAGGING_CUM_POLICY_GEN = "PROPOSAL_TAGGING_CUM_POLICY_GEN";
	public static final String ERROR_CODE_FOR_RECEIPT_ALREADY_GEN = "12";
	public static final String ERROR_CODE_FOR_PROPOSAL_ALREADY_TAG= "52";
	public static final String ERROR_CODE_FOR_PROPOSAL_ALREADY_TAGGED= "2";
	public static final String STRING_REF_ID="strscreenrefno";
	public static final String STRING_PROPOSAL_NUM="strtxnmodeVal";
	public static final String STRING_TXT_POLICY_NO_CHAR= "txt_policy_no_char";
	public static final String STRING_STATUS="status";
	public static final String STRING_ACTIVE_FLAG="active_flag";
	public static final String POLICY_STATUS_RC = "RC";
	public static final String POLICY_STATUS_NC = "NC";
	public static final String POLICY_ACTIVE_STATUS = "A";
	public static final String POLICY_INACTIVE_STATUS = "I";
 	
	//End: :DineshS |  For Lite service for save proposal PV on 26 July 2017
}

package com.majesco.dcf.receipt.handler;

import java.io.PrintWriter;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.tagic.entity.AccFinancierBranch;
import com.majesco.dcf.common.tagic.json.AccFinancierBranchRequest;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.SOAPInfo;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;
import com.majesco.dcf.common.tagic.util.CommonHelper;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyResponse;
import com.majesco.dcf.receipt.json.ReceiptPaymentDetails;
import com.majesco.dcf.receipt.json.ReceiptResponse;
import com.majesco.dcf.receipt.util.ReceiptConstants;
import com.majesco.dcf.util.CXFInBoundInterceptor;
import com.majesco.dcf.util.CXFOutInterceptor;
import com.majesco.dcf.common.chp.util.CdataWriterInterceptor;
import com.unotechsoft.stub.accountservice.client.AccountService;
import com.unotechsoft.stub.accountservice.client.AccountService_Service;
import com.unotechsoft.stub.accountservice.client.ArrayOfClsPolicyIdGrid;
import com.unotechsoft.stub.accountservice.client.ArrayOfKeyValueOfstringint;
import com.unotechsoft.stub.accountservice.client.ArrayOfKeyValueOfstringint.KeyValueOfstringint;
import com.unotechsoft.stub.accountservice.client.ArrayOfKeyValueOfstringstring;
import com.unotechsoft.stub.accountservice.client.ArrayOfUserDataExistPayments;
import com.unotechsoft.stub.accountservice.client.ArrayOfUserDataPaymentEntry;
import com.unotechsoft.stub.accountservice.client.ClsPolicyIdGrid;
import com.unotechsoft.stub.accountservice.client.PaymentEntryCumPolicyGen2;
import com.unotechsoft.stub.accountservice.client.PaymentEntryCumPolicyGenResponse2;
import com.unotechsoft.stub.accountservice.client.PaymentEntryServiceResult;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentEntry;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentTaging;
import com.unotechsoft.stub.accountservice.client.UserDataSubReceipt;

@Service
@Transactional
public class ReceiptDDHandler implements ReceiptHandlerIntf{

//	@Autowired
//	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(ReceiptChequeHandler.class);
	
	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	private static Properties prop = new Properties();

	static{
		try{
	InputStream inputStream = TagicCommunicationService.class.getClassLoader().getResourceAsStream("resources.properties");
	prop.load(inputStream);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/
	
	
	public  String serviceURL="";
	
	
	public String getWSDLURL(String param)
	{
		//String propVal="";
		try
		{
//			serviceURL = dbserv.getWSDLURL(param,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			//return serviceURL;
		}
		catch(Exception ae)
		{
			logger.error("Inside ReceiptChequeHandler :: getWSDLURL() method ::",ae);
		}
		return serviceURL;
	}

	public ReceiptCumPolicyResponse callReceiptCumPolicyProcess(ReceiptCumPolicyRequest receiptReq,DBService dbService) throws Exception{
		
		ReceiptCumPolicyResponse response=new ReceiptCumPolicyResponse();
		ReceiptPaymentDetails receiptPayDtls=null;
		String localTransId=receiptReq.getProcessTransId();
		ObjectMapper objMap=null;
		SimpleDateFormat sdfProposalDate = null;
		sdfProposalDate = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
		Date proposalDate = new Date();
		String proposalNumber = null;	//RahulT| user Transaction changes
		//RahulT| Added for HouseBank & Account Number changes
		String officeCode = null;
		String paymentMode = null;
		String pageName = "Portal";
		String accountNo = null;
		String branchCode = null;
		CommonHelper helper = new CommonHelper();
		HashMap paramVal = new HashMap();
		CXFInBoundInterceptor cxfInInterceptor =null;
		CXFOutInterceptor cxfOutInterceptor= null;
		//RahulT| Added for HouseBank & Account Number changes
		try{
			objMap=new ObjectMapper();
			logger.info("Start::"+localTransId+"::ReceiptDDHandler::callReceiptCumPolicyProcess::Entered");
			//if(logger.isDebugEnabled())logger.debug("Input::"+localTransId+"::ReceiptDDHandler::callReceiptCumPolicyProcess:: Request JSON ::"+objMap.writeValueAsString(receiptReq));
			receiptPayDtls = receiptReq.getPaymentDetails().get(0);
			String userId=receiptReq.getUserID();
			
			// This is done for testing purpose. Code needs to be removed.
			if(userId == null || userId.equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				userId = ReceiptConstants.DEFAULT_USERID;
			}
			
			/*HashMap accNoHouseBankMap = new HashMap();
			accNoHouseBankMap = dbService.getAccountNoHouseBankBranch("S");*/
				
			
		if(serviceURL==null || serviceURL.equalsIgnoreCase("")){
			serviceURL=dbService.getWSDLURL(ReceiptConstants.ACCOUNTSERVICE_ID,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			//serviceURL=wsdlURL;
		}
		AccountService_Service accService=new AccountService_Service(new URL(serviceURL));
		
		AccountService accServClient=accService.getSOAPOverHTTP();
		PaymentEntryCumPolicyGen2 polGen2=new PaymentEntryCumPolicyGen2();
		ArrayOfUserDataPaymentEntry userDatPayEntryList=new ArrayOfUserDataPaymentEntry();
		
		//RahulT| Added for HouseBank & Account Number changes
		/*paymentMode = "D";
		officeCode = receiptReq.getProposalDetails().getDepositOfficeCode();
		paramVal = helper.getHouseBankAndAccountNo(accServClient, officeCode, paymentMode, pageName);
		branchCode = (String)paramVal.get("branchCode");
		accountNo = (String)paramVal.get("bankAccountNo");*/ //Commented For Issue ID 2717
		branchCode = (String)receiptPayDtls.getHouseBranchCode(); //Added For Issue ID 2717
		accountNo = (String)receiptPayDtls.getAccountNo(); //Added For Issue ID 2717
		//RahulT| Added for HouseBank & Account Number changes
		
		UserDataPaymentEntry userDatPayEntry=new UserDataPaymentEntry();
		// Start: Rahul/Ketan
		Date date_entryTag = new Date();
		SimpleDateFormat sdf_entryTag =new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a", Locale.US);
		//Setting other default values required in GC
		userDatPayEntry.setAcceptanceDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setAcceptanceVoucherNumber(new Long(0));
		userDatPayEntry.setAuthorizationCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setBackDateAcc(new Long(0));
		userDatPayEntry.setBalanceAmount(new Long(0));
		userDatPayEntry.setBankAccountNo(accountNo); // RahulT Defaulting done for some extra fields
		//userDatPayEntry.setBankAccountNo("983009830"); // Defaulted to 983009830. Master to be shared by TAGIC as per mail on 10/09/2016
		userDatPayEntry.setBankCode(new Long(0));
		userDatPayEntry.setBankName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setBatchDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setBatchNumber(new Long(0));
		userDatPayEntry.setCMSSlipNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setCardHolderName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setConversionAmount(new BigDecimal(0));
		userDatPayEntry.setCounterNo(new Integer(0));
		userDatPayEntry.setCurrencyAmount(new BigDecimal(0));
		userDatPayEntry.setCurrencyConcateString(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setCurrencyConvertRate(new BigDecimal(0));
		userDatPayEntry.setDealerCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setDealerName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		//userDatPayEntry.setDepositAdviceDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setDepositAdviceDate(sdf_entryTag.format(date_entryTag)); // Defaulted to system date as per logic provided by TAGIC on 10/09/2016
		userDatPayEntry.setDeptCode(new Long(0));
		userDatPayEntry.setDraweeBankLoc(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setEnable_Pol_Issue_Role_Wise(false);
		userDatPayEntry.setEncodedCardNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setEntryDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setExpiryDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setForeignCurrencyAmount(new BigDecimal(0));
		userDatPayEntry.setHoRefDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setHoRefNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		//userDatPayEntry.setHouseBankBranchCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setHouseBankBranchCode(branchCode); // Defaulted 10001 as per mail from TAGIC on 10/09/2016. To be changed once master is received.
		userDatPayEntry.setIFSCCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setILPosPaymentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setITSPaymentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setInsertedTransID(new Long(0));
		userDatPayEntry.setInsertedTransIDDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setInstrumentType(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setInstrumentTypeCd(new Integer(0));
		if(receiptReq.getProducerCode()!=null && !receiptReq.getProducerCode().equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
			userDatPayEntry.setIntermediaryCode(receiptReq.getProducerCode());
		}else{
		userDatPayEntry.setIntermediaryCode(ReceiptConstants.DEFAULT_PRODUCERCODE);
		}
		userDatPayEntry.setIntermediaryName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setInvoiceId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		//userDatPayEntry.setInwardNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setInwardNumber("0"); //RahulT Defaulting done for some extra fields
		userDatPayEntry.setIsAcceptanceApplicable(false);
		userDatPayEntry.setIsDepositSlipNoGenerate(false);
		userDatPayEntry.setIsPortalReceipt(false);
		userDatPayEntry.setMICRNumber("0");
		userDatPayEntry.setMICRTag(0);
		userDatPayEntry.setMerchantId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setModifiedTransID(new Long(0));
		userDatPayEntry.setModifiedTransIDDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setMonthEndExtension(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setMultiCustomerApplicability(true); // Hard coded to true
		userDatPayEntry.setMultiCustomerConcat(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		//userDatPayEntry.setMultiCustomerFlag("N"); // Already hard coded at set to N
		userDatPayEntry.setNsurPlusPaymentID(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setPayinSlipDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setPayinSlipNumber(new Long(0));
		userDatPayEntry.setPaymentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setPolicyNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setPostAuthCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setPropCount(0);
		userDatPayEntry.setReconcileDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setRelationShip(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setRemarks(ReceiptConstants.ACCOUNTSERVICE_REMARKS); // Defaulted to generic remark provide by TAGIC on 10/09/2016
		userDatPayEntry.setStatus(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setTAGICAccNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setVoucherNoAlternation(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setYNOthersType(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		//Start: RahulT Defaulting done for some extra fields
		userDatPayEntry.setBGId(new Long(0));
		userDatPayEntry.setBounceReason(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setBranchCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setBranchName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setPaymentNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		userDatPayEntry.setVoucherNoMiscTransfer(new Long(0));
		
		//userDatPayEntry.setModeForSearch("D"); /*Commented For Issue ID 1155*/
		/*Added For Issue ID 1155 - Starts Here*/
		if(receiptReq!=null && receiptReq.getProposalDetails()!=null && receiptReq.getProposalDetails().getModeOfSearch()!=null && !receiptReq.getProposalDetails().getModeOfSearch().equals(""))
		{
			userDatPayEntry.setModeForSearch(receiptReq.getProposalDetails().getModeOfSearch());
		}
		else
		{
			userDatPayEntry.setModeForSearch(ReceiptConstants.ACCOUNTSERVICE_MODE_FOR_SEARCH_D);
		}
		/*Added For Issue ID 1155 - Ends Here*/
		//End: RahulT Defaulting done for some extra fields
		//End: Rahul/Ketan
		/*Adding Code To Handle PRevious Date For CHEQUE & DD Transactions*/
		SimpleDateFormat sdfDateChk = new SimpleDateFormat("dd/MM/yyyy");
		Date date1 = sdfDateChk.parse(receiptPayDtls.getInstrumentDate());
		Date d2 = new Date();
		String dt2 = sdfDateChk.format(d2);
		Date date2 = sdfDateChk.parse(dt2);
        /*Adding Code To Handle PRevious Date For CHEQUE & DD Transactions*/
		
		userDatPayEntry.setAllocationReqd("Y"); // Default to Y
		/*Adding Code As Suggested By Amol Bhuvad On 29/03/2017 3.02PM*/
		if(date1.compareTo(date2) < 0) 
        {
			userDatPayEntry.setBGTag(new Integer(ReceiptConstants.ACCOUNTSERVICE_BGTAG_SCROLL));
        }
		else
		{
			userDatPayEntry.setBGTag(new Integer(ReceiptConstants.ACCOUNTSERVICE_BGTAG));
		}
		/*Adding Code As Suggested By Amol Bhuvad On 29/03/2017 3.02PM*/
		userDatPayEntry.setBckDtVal(ReceiptConstants.ACCOUNTSERVICE_BCKDTVAL);
		userDatPayEntry.setBusinessLocation(Integer.parseInt(receiptReq.getProposalDetails().getBusinessLocation()));
		userDatPayEntry.setDepositOfficeCode(Integer.parseInt(receiptReq.getProposalDetails().getDepositOfficeCode()));
		userDatPayEntry.setBusinessLocationName(receiptReq.getProposalDetails().getBussLocName());
		//userDatPayEntry.setBusinessType(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPE_CASH);
		/*Adding Code To Handle PRevious Date For CHEQUE & DD Transactions*/

        if(date1.compareTo(date2) < 0) 
        {
        	userDatPayEntry.setBusinessType(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPE_SCROLL);
        }
        else
        {
        	userDatPayEntry.setBusinessType(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPE_CASH);
        }
        
		/*Adding Code To Handle PRevious Date For CHEQUE & DD Transactions*/
		userDatPayEntry.setBusinessTypeCd(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPECD);
		userDatPayEntry.setCallEnv(ReceiptConstants.ACCOUNTSERVICE_CALLENV);
		//userDatPayEntry.setDecimalPaymentAmount(BigDecimal.valueOf(Double.parseDouble(receiptReq.getProposalDetails().getProposalAmount()))); // receiptReq.getProposalDetails().getProposalAmount()
		//Start: RahulT <Production> 25/04/2017| sent receipt amount in DecimalPaymentAmount field as per mail from Manish(TCS) @ Tue 4/25/2017 2:01 PM
		userDatPayEntry.setDecimalPaymentAmount(BigDecimal.valueOf(Double.parseDouble(receiptPayDtls.getPaymentAmount())));
		//End: RahulT <Production> 25/04/2017| sent receipt amount in DecimalPaymentAmount field as per mail from Manish(TCS) @ Tue 4/25/2017 2:01 PM
		userDatPayEntry.setGenPolicyNo(ReceiptConstants.ACCOUNTSERVICE_GENPOLNO);
		userDatPayEntry.setMultiCustomerFlag("N"); // Hard coded to N for Cash
		
				//Start: RahulT <Production> 25/04/2017| send Cheque related field values to GC
		
				if (receiptPayDtls.getPayerType()!=null && receiptPayDtls.getPayerType().equalsIgnoreCase(ReceiptConstants.UI_PAYERTYPE_CHEQUE_INTERMIDIARY)){
					if (receiptPayDtls.getPayorID()==null || receiptPayDtls.getPayorID().equals(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING))
						receiptPayDtls.setPayorID(receiptReq.getProducerCode());
					userDatPayEntry.setPayerCustomerId(receiptPayDtls.getPayorID());
					userDatPayEntry.setPayerName(receiptPayDtls.getPayerName());
					userDatPayEntry.setPayerTypeCd(Integer.parseInt(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CHEQUE_INTERMIDIARY_CD));
					userDatPayEntry.setPayerType(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CHEQUE_INTERMIDIARY);
				}
				
				else if (receiptPayDtls.getPayerType()!=null && receiptPayDtls.getPayerType().equalsIgnoreCase(ReceiptConstants.UI_PAYERTYPE_CHEQUE_CUSTOMER)){
					userDatPayEntry.setPayerCustomerId(receiptPayDtls.getPayorID());
					userDatPayEntry.setPayerName(receiptPayDtls.getPayerName());
					userDatPayEntry.setPayerTypeCd(Integer.parseInt(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CD));
					userDatPayEntry.setPayerType(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CASH);
				}
				
				else if (receiptPayDtls.getPayerType()!=null && receiptPayDtls.getPayerType().equalsIgnoreCase(ReceiptConstants.UI_PAYERTYPE_CHEQUE_DEALER)){
					userDatPayEntry.setPayerCustomerId(receiptPayDtls.getPayorID());
					userDatPayEntry.setPayerName(receiptPayDtls.getPayerName());
					userDatPayEntry.setPayerTypeCd(Integer.parseInt(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CHEQUE_DEALER_CD));
					userDatPayEntry.setPayerType(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CHEQUE_DEALER);
				}
				
				else if (receiptPayDtls.getPayerType()!=null && receiptPayDtls.getPayerType().equalsIgnoreCase(ReceiptConstants.UI_PAYERTYPE_CHEQUE_FINANCIER)){
					userDatPayEntry.setPayerCustomerId(receiptPayDtls.getPayorID());
					userDatPayEntry.setPayerName(receiptPayDtls.getPayerName());
					userDatPayEntry.setPayerTypeCd(Integer.parseInt(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CHEQUE_FINANCIER_CD));
					userDatPayEntry.setPayerType(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CHEQUE_FINANCIER);
				}
				
				else if (receiptPayDtls.getPayerType()!=null && receiptPayDtls.getPayerType().equalsIgnoreCase(ReceiptConstants.UI_PAYERTYPE_CHEQUE_OTHERS)){
					userDatPayEntry.setPayerCustomerId(receiptPayDtls.getPayorID());
					userDatPayEntry.setPayerName(receiptPayDtls.getPayerName());
					userDatPayEntry.setPayerTypeCd(Integer.parseInt(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CHEQUE_OTHERS_CD));
					userDatPayEntry.setPayerType(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CHEQUE_OTHERS);
				}
				
				else if (receiptPayDtls.getPayerType()!=null && receiptPayDtls.getPayerType().equalsIgnoreCase(ReceiptConstants.UI_PAYERTYPE_CHEQUE_NEW)){
					userDatPayEntry.setPayerCustomerId(receiptPayDtls.getPayorID());
					userDatPayEntry.setPayerName(receiptPayDtls.getPayerName());
					userDatPayEntry.setPayerTypeCd(Integer.parseInt(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CHEQUE_OTHERS_CD));
					userDatPayEntry.setPayerType(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CHEQUE_OTHERS);
				}
				
				//End: RahulT <Production> 25/04/2017| send Cheque related field values to GC
	
		userDatPayEntry.setPaymentMode(ReceiptConstants.ACCOUNTSERVICE_PAYMENT_MODE_DD);
		userDatPayEntry.setPaymentType(Long.parseLong("-1")); // Hard coded to -1 as it's mandatory to GC
		userDatPayEntry.setPaymentNumber(receiptPayDtls.getInstrumentNo()); // Cheque number / instrument number
		userDatPayEntry.setPaymentDate(receiptPayDtls.getInstrumentDate());
//		userDatPayEntry.setPaymentNumber("549875"); // Cheque number / instrument number
//		userDatPayEntry.setPaymentDate("18/10/2016");
		userDatPayEntry.setRemarks(ReceiptConstants.ACCOUNTSERVICE_REMARKS); // Defaulted to generic remark provide by TAGIC on 10/09/2016
		//userDatPayEntry.setBankAccountNo(accNoHouseBankMap.get("ACCOUNT_NUMBER").toString()); // Defaulted to 983009830. Master to be shared by TAGIC as per mail on 10/09/2016
		
		
		AccFinancierBranchRequest finBranchReq=new AccFinancierBranchRequest();
		finBranchReq.setStrIFSCCD(receiptPayDtls.getIfscCode());
		//finBranchReq.setStrIFSCCD("UTIB0000005");
		List finList=dbService.getAccFinancierBranch("com.majesco.dcf.common.tagic.entity.AccFinancierBranch", finBranchReq);
		
		AccFinancierBranch finBranch=null;
		
		if(finList!=null && finList.size()>0){
			
			HashMap mapList = (HashMap) finList.get(0);
			
			if(mapList!=null && mapList.size()>0)
			{
					BigDecimal bigDec = new BigDecimal(mapList.get("nfinanciercd").toString());
					userDatPayEntry.setBankCode(bigDec.longValue());
					//userDatPayEntry.setMICRNumber((String)(mapList.get("strmicrcd")));
					userDatPayEntry.setBankName((String)(mapList.get("strfinanciername")));
					userDatPayEntry.setBranchName((String)(mapList.get("strbranchname")));
					userDatPayEntry.setDraweeBankLoc((String)(mapList.get("strbranchname")));
					
			}
			else
			{
				userDatPayEntry.setBankCode(new Long(0));
				//userDatPayEntry.setMICRNumber("");
				userDatPayEntry.setBankName("");
				userDatPayEntry.setBranchName("");
				userDatPayEntry.setDraweeBankLoc("");
			}
		}
		
		
	//	userDatPayEntry.setBankCode(value); // Set Bank code from financier master based on IFSC code
		//userDatPayEntry.setBankName(value); // Set Bank name from financier master based on IFSC code
		//userDatPayEntry.setBranchName(); // Set branch name from financier master based on IFSC code
		userDatPayEntry.setIFSCCode(receiptPayDtls.getIfscCode());
		//userDatPayEntry.setIFSCCode("UTIB0000005");
		//userDatPayEntry.setMICRNumber(value); //Set MICR number from financier master based on IFSC code
		userDatPayEntry.setMICRTag(1); // MICR tag hard coded to 1.
		//userDatPayEntry.setHouseBankBranchCode("1"); // Hard coded to 1, need to check whether some logic required to set 1 or any other value
		
		if(receiptReq.getProducerCode()!=null && !receiptReq.getProducerCode().equalsIgnoreCase("")){
		userDatPayEntry.setProducerCode(receiptReq.getProducerCode());
		}else{
			userDatPayEntry.setProducerCode(ReceiptConstants.DEFAULT_PRODUCERCODE);
		}
		
		Date date = new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a", Locale.US);
		
		
		
		userDatPayEntry.setReceiptDate(sdf.format(date));
		userDatPayEntry.setTransactionType(Integer.parseInt(ReceiptConstants.ACCOUNTSERVICE_TRANS_TYPE_CASH));
		userDatPayEntry.setTransactionTime(sdf.format(date));
		userDatPayEntry.setDepositAdviceDate(sdf.format(date)); // Defaulted to system date as per logic provided by TAGIC on 10/09/2016
		
		if(receiptReq.getProposalDetails()!=null && receiptReq.getProposalDetails().getProposalSystemId() == null){
			//setting dummy transaction ID
			String transID = "5454678755";
			receiptReq.getProposalDetails().setProposalSystemId(transID);
		}
		
		if(receiptReq.getProposalDetails()!=null && receiptReq.getProposalDetails().getProposalSystemId()!=null
				&& !receiptReq.getProposalDetails().getProposalSystemId().equals("")){
			userDatPayEntry.setTransactionId(Long.parseLong(receiptReq.getProposalDetails().getProposalSystemId()));
		}
		userDatPayEntry.setUserRole(ReceiptConstants.DEFAULT_GC_ROLE);
		userDatPayEntry.setUserId(userId);
		
		ArrayOfKeyValueOfstringint arrKeyValNote=new ArrayOfKeyValueOfstringint();
		KeyValueOfstringint keyValTotalAmount=new KeyValueOfstringint();
		keyValTotalAmount.setKey(ReceiptConstants.ACCOUNTSERVICE_TotalAmount);
		keyValTotalAmount.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTotalAmount);
		
		
		KeyValueOfstringint keyValThousand=new KeyValueOfstringint();
		keyValThousand.setKey(ReceiptConstants.ACCOUNTSERVICE_Thousand);
		keyValThousand.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValThousand);
		
		
		KeyValueOfstringint keyValFivehundred=new KeyValueOfstringint();
		keyValFivehundred.setKey(ReceiptConstants.ACCOUNTSERVICE_Fivehundred);
		keyValFivehundred.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValFivehundred);
		
		
		KeyValueOfstringint keyValHundred=new KeyValueOfstringint();
		keyValHundred.setKey(ReceiptConstants.ACCOUNTSERVICE_Hundred);
		keyValHundred.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValHundred);
		
		
		KeyValueOfstringint keyValFifty=new KeyValueOfstringint();
		keyValFifty.setKey(ReceiptConstants.ACCOUNTSERVICE_Fifty);
		keyValFifty.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValFifty);
		
		KeyValueOfstringint keyValTwenty=new KeyValueOfstringint();
		keyValTwenty.setKey(ReceiptConstants.ACCOUNTSERVICE_Twenty);
		keyValTwenty.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTwenty);
		
		KeyValueOfstringint keyValTen=new KeyValueOfstringint();
		keyValTen.setKey(ReceiptConstants.ACCOUNTSERVICE_Ten);
		keyValTen.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTen);
		
		KeyValueOfstringint keyValFive=new KeyValueOfstringint();
		keyValFive.setKey(ReceiptConstants.ACCOUNTSERVICE_Five);
		keyValFive.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValFive);
		
		KeyValueOfstringint keyValTwo=new KeyValueOfstringint();
		keyValTwo.setKey(ReceiptConstants.ACCOUNTSERVICE_Two);
		keyValTwo.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTwo);
		
		KeyValueOfstringint keyValOne=new KeyValueOfstringint();
		keyValOne.setKey(ReceiptConstants.ACCOUNTSERVICE_One);
		keyValOne.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValOne);
		
		userDatPayEntry.setNoteNumber(arrKeyValNote);
		
		userDatPayEntryList.getUserDataPaymentEntry().add(userDatPayEntry);
		polGen2.setObjLVUserDataPEntryLst(userDatPayEntryList);
		
		UserDataSubReceipt subReceipt=new UserDataSubReceipt();
		subReceipt.setCallSLEnv(ReceiptConstants.ACCOUNTSERVICE_CALLENV);
		subReceipt.setTransactionID(receiptReq.getProposalDetails().getProposalSystemId());
		subReceipt.setUserID(userId);
		polGen2.setObjUserDataSubReceipt(subReceipt);
		
		UserDataPaymentTaging payTag=new UserDataPaymentTaging();
		payTag.setBusinessType(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPECD);
		payTag.setCallSLEnv(ReceiptConstants.ACCOUNTSERVICE_CALLENV);
		payTag.setCheckAutopayment(1); // Hard coded to 1 for CASH
		payTag.setCheckAutoProposal(1); // Hard coded to 1 for CASH
		ArrayOfClsPolicyIdGrid proposalGrid=new ArrayOfClsPolicyIdGrid();
		ClsPolicyIdGrid policyGrid=new ClsPolicyIdGrid();
		policyGrid.setBankCharge("0");
		policyGrid.setIsChecked(true);
		/*if(receiptReq.getProposalDetails()!=null && receiptReq.getProposalDetails().getProposalDate()!=null)
		{
			//proposalDate = new Date(receiptReq.getProposalDetails().getProposalDate());
			String dt = receiptReq.getProposalDetails().getProposalDate(); 
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(sdf1.parse(dt));
			//p2Dto.setPropRisksExpirydate(sdf.format(c.getTime()));
			policyGrid.setProposalDate(sdf1.format(c.getTime()));
		}*//*Commented For Issue ID 1258 - 05/06/2017*/
		//policyGrid.setProposalDate(sdfProposalDate.format(proposalDate));/*Added For Issue ID 1258 - 05/06/2017*/ /*Commented For Issue ID 1576*/
		/*Added For Issue ID 1576 Starts Here*/
		SimpleDateFormat sdfPropDate = null;
		sdfPropDate = new SimpleDateFormat("dd/MM/yyyy");
		Date propDate = new Date();
		if(receiptReq!=null && receiptReq.getIsManualCovernoteChk()!=null && receiptReq.getIsManualCovernoteChk().equalsIgnoreCase("true"))
		{
			policyGrid.setProposalDate(sdfPropDate.format(propDate));
		}
		else
		{
			policyGrid.setProposalDate(receiptReq.getProposalDetails().getProposalDate());
		}
		/*Added For Issue ID 1576 Ends Here*/
		policyGrid.setProposalNo(receiptReq.getProposalDetails().getProposalNo());
		payTag.setModeOfEntry(ReceiptConstants.ACCOUNTSERVICE_BGTAG);
		payTag.setOfficeCode(receiptReq.getProposalDetails().getDepositOfficeCode());
		payTag.setPayerId(receiptReq.getProposalDetails().getCustomerId());
		//payTag.setPayerType(receiptPayDtls.getPayerType()); // hardcoded as it should be 1 by default
		payTag.setPayerType("1");
		payTag.setProposalId(receiptReq.getProposalDetails().getProposalNo());
		payTag.setTransactionId(receiptReq.getProposalDetails().getProposalSystemId());
		payTag.setTransactionTime(sdf.format(date));
		payTag.setUserId(userId);
		
		proposalGrid.getClsPolicyIdGrid().add(policyGrid);
		payTag.setClsProposalDetailsGrd(proposalGrid);
		
		polGen2.setObjUserDataPaymentTaging(payTag);
		
		
		ArrayOfKeyValueOfstringstring arrLVWF=new ArrayOfKeyValueOfstringstring();
		
		/*KeyValueOfstringstring keyValue1=new KeyValueOfstringstring();
		keyValue1.setKey(ReceiptConstants.ACCOUNTSERVICE_GUID_WORKFLOW_KEY);
		keyValue1.setValue(receiptReq.getProposalDetails().getProposalSystemId());
		arrLVWF.getKeyValueOfstringstring().add(keyValue1);
		
		KeyValueOfstringstring keyValue2=new KeyValueOfstringstring();
		keyValue2.setKey(ReceiptConstants.ACCOUNTSERVICE_CURRENT_STATE_KEY);
		keyValue2.setValue(ReceiptConstants.ACCOUNTSERVICE_CURRENT_STATE_VALUE);
		arrLVWF.getKeyValueOfstringstring().add(keyValue2);
		
		KeyValueOfstringstring keyValue3=new KeyValueOfstringstring();
		keyValue3.setKey(ReceiptConstants.ACCOUNTSERVICE_PAGE_ACTION_KEY);
		keyValue3.setValue(ReceiptConstants.ACCOUNTSERVICE_PAGE_ACTION_VALUE);
		arrLVWF.getKeyValueOfstringstring().add(keyValue3);
		
		KeyValueOfstringstring keyValue4=new KeyValueOfstringstring();
		keyValue4.setKey(ReceiptConstants.ACCOUNTSERVICE_WORKFLOW_NAME_KEY);
		keyValue4.setValue(ReceiptConstants.ACCOUNTSERVICE_WORKFLOW_NAME_VALUE);
		arrLVWF.getKeyValueOfstringstring().add(keyValue4);*/
		
		ArrayOfUserDataExistPayments existPayment = new ArrayOfUserDataExistPayments();
		polGen2.setLstExistPayments(existPayment);
		
		polGen2.setDicLVWFParams(null);
		
		polGen2.setSource(prop.getProperty("smc.source"));
		polGen2.setCampaign(prop.getProperty("smc.medium"));
		polGen2.setMedium(prop.getProperty("smc.campaign"));
		polGen2.setStrLVTokenID(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		
		/*Client client=ClientProxy.getClient(accServClient);
		PrintWriter writer = new PrintWriter(System.out);
		
		client.getOutInterceptors().add(new CdataWriterInterceptor());
		client.getInInterceptors().add(new LoggingInInterceptor(writer));
		client.getOutInterceptors().add(new LoggingOutInterceptor(writer));*/
		// Code added to save info abt SOAP in DB Start
		SOAPInfo soapInfo = new SOAPInfo();
		soapInfo.setTransactionID(Long.parseLong(receiptReq.getProcessTransId()));
		soapInfo.setLobService("paymentEntryCumPolicyGen");
		soapInfo.setLobtype(receiptReq.getStrLOB());
		soapInfo.setCreatedBy(receiptReq.getUserID());
		soapInfo.setProducerCode(receiptReq.getProducerCode());
		soapInfo.setSystemIP(receiptReq.getSystemIP());
		soapInfo.setTransactionEvent(CommonConstants.POLICY_CREATION_EVENT);
		soapInfo.setJsonRequest(objMap.writeValueAsString(receiptReq));
		if(receiptReq.getProposalDetails()!=null)
		soapInfo.setProductCode(receiptReq.getProposalDetails().getProductCode());
		
		
		cxfInInterceptor = new CXFInBoundInterceptor(soapInfo);
		cxfOutInterceptor= new CXFOutInterceptor(soapInfo);
		
		ServiceUtility utility = new ServiceUtility();
		utility.addClientInterceptorDB(accServClient,cxfInInterceptor,cxfOutInterceptor);
		
		proposalNumber = receiptReq.getProposalDetails().getProposalNo();	//RahulT| User transaction changes
		
		//if(logger.isDebugEnabled())logger.debug("Start::"+localTransId+"::ReceiptDDHandler::Calling AccountService-->paymentEntryCumPolicyGen::Entered");
		PaymentEntryCumPolicyGenResponse2 receiptResponse=accServClient.paymentEntryCumPolicyGen(polGen2);
		//if(logger.isDebugEnabled())logger.debug("End::"+localTransId+"::ReceiptDDHandler::After Calling AccountService-->paymentEntryCumPolicyGen::Exit");
		PaymentEntryServiceResult payResult=null;
		
		//if(logger.isDebugEnabled())logger.debug("Adding Out Logs to DB");
		dbService.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
		//if(logger.isDebugEnabled())logger.debug("Adding In Logs to DB");
		dbService.saveInSoapInfo(cxfInInterceptor.getInBound());				
		
//Code end for Saving SOAP Data to DB.	
		
		payResult=receiptResponse.getReturn();
		if(payResult!=null && payResult.getErrorCode()!=null && payResult.getErrorCode().equalsIgnoreCase("0") && payResult.getErrorMsg()!=null && payResult.getErrorMsg().equalsIgnoreCase("-1")){
			
		response.setPolicyNo(payResult.getPolicyNo());
		ReceiptResponse receiptRes=new ReceiptResponse();
		receiptRes.setReceiptNo(payResult.getNewlyCreatedReceipts());
		receiptRes.setSubReceiptId(payResult.getTaggedSubReceipt());
		
		response.setReceiptDtls(receiptRes);
		response.setResultCode("1");
		
		dbService.updateUserTransForPolicy(response.getPolicyNo(),proposalNumber);	//RahulT| user transaction changes
		
		}else if(payResult!=null && payResult.getErrorMsg()!=null && !payResult.getErrorMsg().equalsIgnoreCase("-1") && payResult.getErrorCode()!=null && !payResult.getErrorCode().equalsIgnoreCase("0")){
			response.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError error=new ResponseError();
			error.setErrorCode(payResult.getErrorCode());
			error.setErrorMMessag(payResult.getErrorMsg());
			errorList.add(error);
			response.setErrorList(errorList);
		}
		
		}catch(Exception ex){
			logger.error("Exception::"+localTransId+"::ReceiptDDHandler::callReceiptCumPolicyProcess::Exit", ex);
			response.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError error=new ResponseError();
			error.setErrorCode("ERR01");
			error.setErrorMMessag("Failed to call service !!");
			errorList.add(error);
			response.setErrorList(errorList);
		}
		logger.info("End::"+localTransId+"::ReceiptDDHandler::callReceiptCumPolicyProcess::Exit");
		if(cxfInInterceptor!=null){
			cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(response));
			cxfInInterceptor.getInBound().setStrrefno(receiptReq.getProposalDetails().getProposalNo() == null ? "":receiptReq.getProposalDetails().getProposalNo());
			dbService.saveInSoapInfo(cxfInInterceptor.getInBound());	
		}					
        if(cxfOutInterceptor!=null){
			cxfOutInterceptor.getOutBound().setStrrefno(receiptReq.getProposalDetails().getProposalNo() == null ? "":receiptReq.getProposalDetails().getProposalNo());						
			dbService.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
		}
		return response;
	}
	
	public ReceiptCumPolicyResponse createReceipt(ReceiptCumPolicyRequest receiptReq,DBService dbService) throws Exception{
		
	//Method to be implemented at later stage.
		
		return null;
	}

}

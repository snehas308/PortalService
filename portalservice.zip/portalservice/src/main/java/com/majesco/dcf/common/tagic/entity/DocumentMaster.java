package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_document_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_document_m")								// Added for Oracle Migration
public class DocumentMaster implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4283262705828869203L;
	
	
	/*private Integer npincodeseq;*/
	private String strdoccd;
	private String strdcodesc;
	private String dtstart;
	private String dtend;
	private String strstatus;
	private String strlobcd;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	
	@Id
	@Column(name = "strdoccd")
	public String getStrdoccd() {
		return strdoccd;
	}
	public void setStrdoccd(String strdoccd) {
		this.strdoccd = strdoccd;
	}
	
	@Column(name = "strdcodesc")
	public String getStrdcodesc() {
		return strdcodesc;
	}
	public void setStrdcodesc(String strdcodesc) {
		this.strdcodesc = strdcodesc;
	}
	
	@Column(name = "dtstart")
	public String getDtstart() {
		return dtstart;
	}
	public void setDtstart(String dtstart) {
		this.dtstart = dtstart;
	}
	
	@Column(name = "dtend")
	public String getDtend() {
		return dtend;
	}
	public void setDtend(String dtend) {
		this.dtend = dtend;
	}
	
	@Column(name = "strstatus")
	public String getStrstatus() {
		return strstatus;
	}
	public void setStrstatus(String strstatus) {
		this.strstatus = strstatus;
	}
	
	@Column(name = "strlobcd")
	public String getStrlobcd() {
		return strlobcd;
	}
	public void setStrlobcd(String strlobcd) {
		this.strlobcd = strlobcd;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")

	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	
	
}

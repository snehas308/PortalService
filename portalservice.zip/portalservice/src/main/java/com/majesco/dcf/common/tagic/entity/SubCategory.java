package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_servreq_catprod_map",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_servreq_catprod_map")							// Added for Oracle Migration
public class SubCategory{
	
	private Integer nservreqcatmapseq;
	private String strservreqcatcd;
	private String strservreqsubcatcd;
	private Integer nlobseq;
	private String strprodcd;
	private Integer nprodver;
	private Integer nisactive;
	private String strtype;
	private String strsubtype;
	private String strgrp;
	private String strsubgrp;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	private String strcddesc;
	
	@Id
	@Column(name = "nservreqcatmapseq")
	public Integer getNservreqcatmapseq() {
		return nservreqcatmapseq;
	}
	public void setNservreqcatmapseq(Integer nservreqcatmapseq) {
		this.nservreqcatmapseq = nservreqcatmapseq;
	}
	
	@Column(name = "strservreqcatcd")
	public String getStrservreqcatcd() {
		return strservreqcatcd;
	}
	public void setStrservreqcatcd(String strservreqcatcd) {
		this.strservreqcatcd = strservreqcatcd;
	}
	
	@Column(name = "strservreqsubcatcd")
	public String getStrservreqsubcatcd() {
		return strservreqsubcatcd;
	}
	public void setStrservreqsubcatcd(String strservreqsubcatcd) {
		this.strservreqsubcatcd = strservreqsubcatcd;
	}
	
	@Column(name = "nlobseq")
	public Integer getNlobseq() {
		return nlobseq;
	}
	public void setNlobseq(Integer nlobseq) {
		this.nlobseq = nlobseq;
	}
	
	@Column(name = "strprodcd")
	public String getStrprodcd() {
		return strprodcd;
	}
	public void setStrprodcd(String strprodcd) {
		this.strprodcd = strprodcd;
	}
	
	@Column(name = "nprodver")
	public Integer getNprodver() {
		return nprodver;
	}
	public void setNprodver(Integer nprodver) {
		this.nprodver = nprodver;
	}
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
	@Column(name = "strtype")
	public String getStrtype() {
		return strtype;
	}
	public void setStrtype(String strtype) {
		this.strtype = strtype;
	}
	
	@Column(name = "strsubtype")
	public String getStrsubtype() {
		return strsubtype;
	}
	public void setStrsubtype(String strsubtype) {
		this.strsubtype = strsubtype;
	}
	
	@Column(name = "strgrp")
	public String getStrgrp() {
		return strgrp;
	}
	public void setStrgrp(String strgrp) {
		this.strgrp = strgrp;
	}
	
	@Column(name = "strsubgrp")
	public String getStrsubgrp() {
		return strsubgrp;
	}
	public void setStrsubgrp(String strsubgrp) {
		this.strsubgrp = strsubgrp;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	@Column(name = "strcddesc")
	public String getStrcddesc() {
		return strcddesc;
	}
	public void setStrcddesc(String strcddesc) {
		this.strcddesc = strcddesc;
	}
	//@Column(name = "strsubcategorydesc")
	
}

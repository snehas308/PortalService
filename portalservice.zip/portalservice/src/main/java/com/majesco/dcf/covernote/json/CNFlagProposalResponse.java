package com.majesco.dcf.covernote.json;

public class CNFlagProposalResponse {
	
	private String cnFlag;

	public String getCnFlag() {
		return cnFlag;
	}

	public void setCnFlag(String cnFlag) {
		this.cnFlag = cnFlag;
	} 

}

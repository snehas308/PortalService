package com.majesco.dcf.paproduct.json;

public class PremiumDetailsQuot {
	private String netPremium;
	private String totalPremium;
	private String sumInsured;
	private String serviceTax;
	private String discount;
	private String premiumPayable;
	private String premRate;
	private String addonPremiumPayable;
	public String getNetPremium() {
		return netPremium;
	}
	public void setNetPremium(String netPremium) {
		this.netPremium = netPremium;
	}
	public String getTotalPremium() {
		return totalPremium;
	}
	public void setTotalPremium(String totalPremium) {
		this.totalPremium = totalPremium;
	}
	public String getSumInsured() {
		return sumInsured;
	}
	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}
	public String getServiceTax() {
		return serviceTax;
	}
	public void setServiceTax(String serviceTax) {
		this.serviceTax = serviceTax;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	public String getPremiumPayable() {
		return premiumPayable;
	}
	public void setPremiumPayable(String premiumPayable) {
		this.premiumPayable = premiumPayable;
	}
	public String getPremRate() {
		return premRate;
	}
	public void setPremRate(String premRate) {
		this.premRate = premRate;
	}
	public String getAddonPremiumPayable() {
		return addonPremiumPayable;
	}
	public void setAddonPremiumPayable(String addonPremiumPayable) {
		this.addonPremiumPayable = addonPremiumPayable;
	}
	
}

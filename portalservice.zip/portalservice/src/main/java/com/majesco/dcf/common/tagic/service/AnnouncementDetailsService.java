package com.majesco.dcf.common.tagic.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.json.AnnouncementDetails;
import com.majesco.dcf.common.tagic.json.AnnouncementDetailsResponse;
import com.majesco.dcf.constant.CommonConstants;


@Service
public class AnnouncementDetailsService {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(AnnouncementDetailsService.class);
	
	@SuppressWarnings("unchecked")
	public AnnouncementDetailsResponse getAnnouncementDetails() throws Exception
	{
		logger.info("In AnnouncementDetailsService.getAnnouncementDetails() Method Begin()...");
		
		ObjectMapper objMap=new ObjectMapper();
		HashMap resultMap = new HashMap();
		AnnouncementDetailsResponse announceDtlsRes = new AnnouncementDetailsResponse();
		AnnouncementDetails announcementDtls = null;
		ArrayList<AnnouncementDetails> lstAnnouncementDtls = new ArrayList<AnnouncementDetails>();
		ArrayList<Object[]> resultData = new ArrayList();
		
		
		try
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date date1 = new Date();
			String formattedDate = dateFormat.format(date1);
			
			DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
			Date date2 = new Date();
			String formattedTime = timeFormat.format(date2);
			
			logger.info("In AnnouncementDetailsService.getAnnouncementDetails() :: About To Call getAnnouncementValue()...");
			
			resultData = dbserv.getAnnouncementValue(formattedDate, formattedDate, formattedTime, formattedTime);
			
			if(resultData!=null && resultData.size()>0)
			{	
				for(Object[] row : resultData)
				{
					announcementDtls = new AnnouncementDetails();
					announcementDtls.setParamCode((String) nullCheckString(row[0]));
					announcementDtls.setParamValue((String) nullCheckString(row[1]));
					lstAnnouncementDtls.add(announcementDtls);
				}
				announceDtlsRes.setLstAnnouncementDtls(lstAnnouncementDtls);
				announceDtlsRes.setErrorCode(CommonConstants.SUCCESS_STATUS);
			}
			else
			{
				announceDtlsRes.setLstAnnouncementDtls(null);
				announceDtlsRes.setErrorCode(CommonConstants.FAILURE_STATUS);
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("Exception StackTrace : ", e);
		}
		logger.info("In AnnouncementDetailsService.getAnnouncementDetails() Method ::: "+objMap.writeValueAsString(announceDtlsRes));
		
		return announceDtlsRes;
	}

	public String nullCheckString(Object obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }
}

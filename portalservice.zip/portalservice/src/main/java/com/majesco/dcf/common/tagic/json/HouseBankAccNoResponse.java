package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author ketan570156
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class HouseBankAccNoResponse extends ResultObject{
	
	private ArrayList<KeyValuePair> lstKeyValuePair;

	public ArrayList<KeyValuePair> getLstKeyValuePair() {
		return lstKeyValuePair;
	}

	public void setLstKeyValuePair(ArrayList<KeyValuePair> lstKeyValuePair) {
		this.lstKeyValuePair = lstKeyValuePair;
	}

}

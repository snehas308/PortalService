package com.majesco.dcf.common.tagic.json;

public class PaymentDetails {
	
	public String paymentMode;
	public String paymentAmount;
	public String payerType;
	public String payerID;
	public String payerName;
	public String chequeType;
	public String ifscCode;
	public String bankName;
	public String onlinePaymentMode;
	public String instrumentNo;
	public String instrumentDt;
	public String emailID;
	public String mobileNo;
	public String relation;
	
	
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	
	
	public String getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	
	
	public String getPayerType() {
		return payerType;
	}
	public void setPayerType(String payerType) {
		this.payerType = payerType;
	}
	
	
	public String getPayerID() {
		return payerID;
	}
	public void setPayerID(String payerID) {
		this.payerID = payerID;
	}
	
	
	public String getPayerName() {
		return payerName;
	}
	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}
	
	
	public String getChequeType() {
		return chequeType;
	}
	public void setChequeType(String chequeType) {
		this.chequeType = chequeType;
	}
	
	
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	
	
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	
	public String getOnlinePaymentMode() {
		return onlinePaymentMode;
	}
	public void setOnlinePaymentMode(String onlinePaymentMode) {
		this.onlinePaymentMode = onlinePaymentMode;
	}
	
	
	public String getInstrumentNo() {
		return instrumentNo;
	}
	public void setInstrumentNo(String instrumentNo) {
		this.instrumentNo = instrumentNo;
	}
	
	
	public String getInstrumentDt() {
		return instrumentDt;
	}
	public void setInstrumentDt(String instrumentDt) {
		this.instrumentDt = instrumentDt;
	}
	
	
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	
	
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	
	

}

package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ProdSupportContactServiceResponse {
	
	private ArrayList<ProdSupportContact> lstProdSupportContact;

	public ArrayList<ProdSupportContact> getLstProdSupportContact() {
		return lstProdSupportContact;
	}

	public void setLstProdSupportContact(
			ArrayList<ProdSupportContact> lstProdSupportContact) {
		this.lstProdSupportContact = lstProdSupportContact;
	}
	
	

}

package com.majesco.dcf.common.tagic.json;

public class ResponseError {

	private String errorCode;
	private String errorMMessag;
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMMessag() {
		return errorMMessag;
	}
	public void setErrorMMessag(String errorMMessag) {
		this.errorMMessag = errorMMessag;
	}
	
}

package com.majesco.dcf.common.tagic.service;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.json.IDVRelaxationRequest;
import com.majesco.dcf.common.tagic.json.IDVRelaxationResponse;

@Service
public class IDVRelaxationService {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(IDVRelaxationService.class);
	
	public IDVRelaxationResponse getIDVRelaxationDetails(IDVRelaxationRequest idvRelaxationRequest)  throws Exception
	{
		ObjectMapper objMap=new ObjectMapper();
		IDVRelaxationResponse idvRelaxRes = new IDVRelaxationResponse();
		double resultIDV = 0.0;
		try
		{
		
			logger.info("In IDVRelaxationService.getIDVRelaxationDetails() Method Begin()...");
			
			resultIDV = (double) dbserv.getIDVRelaxationValue(idvRelaxationRequest);
			
			if(resultIDV != 0)
			{
				idvRelaxRes.setResultCode("1");
				idvRelaxRes.setNidv(resultIDV+"");
			}
			else
			{
				idvRelaxRes.setResultCode("0");
				idvRelaxRes.setNidv("0");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("Exception StackTrace : ", e);
			idvRelaxRes.setResultCode("0");
			idvRelaxRes.setNidv("0");
			return idvRelaxRes;
		}
		logger.info("In IDVRelaxationService.getIDVRelaxationDetails() Method End()...");
		logger.info("In IDVRelaxationService.getIDVRelaxationDetails() Method ::: "+objMap.writeValueAsString(idvRelaxRes));
		
		return idvRelaxRes;
	}

}

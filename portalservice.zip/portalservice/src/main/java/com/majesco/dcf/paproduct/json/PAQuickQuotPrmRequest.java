package com.majesco.dcf.paproduct.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PAQuickQuotPrmRequest extends UserObject{
	
	private String gender;
	private String insuranceFor; //Want to cover* members like Self,Spouse,Father,Mother,Daughter,Son etc.
	private String pincode;
	private String profession;	//Salaried or Business
	private String annualIncome;
	private String dob;
	private String payoutType; 
	private String coverType;  
	
	private String user;
	private String firstName;
	private String middleName;
	private String lastName;
	private String intermediaryCode;
	private String mobileNumber;
	private String email;
	
	private String customerType;
	private String productCode;
	private String policyTerm;
	private String plan;	//Plan A or Plan B || self+spous+child
	private String planCoverage;
	private String coreBenPerUnit;	//Core Benefit Per Unit. Value: 500000
	private String coreBenNoOfUnit;	//Core Benefit Number Of Units
	private String coreSumInsured;
	private String weeklyBenUpto52Weeks;	//Weekly Benefit - Upto 52 Weeks Applicable
	private String weeklyBenNoOfUnits;		//Weekly Benefit - Number Of Units
	private String weeklyBenefit;			//Weekly Benefit
	private String benperMonth;
	private String addoncoverApp;
	private Integer familySize;
	private String payPeriod;
	private String customerId;
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getInsuranceFor() {
		return insuranceFor;
	}
	public void setInsuranceFor(String insuranceFor) {
		this.insuranceFor = insuranceFor;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	public String getAnnualIncome() {
		return annualIncome;
	}
	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPayoutType() {
		return payoutType;
	}
	public void setPayoutType(String payoutType) {
		this.payoutType = payoutType;
	}
	public String getCoverType() {
		return coverType;
	}
	public void setCoverType(String coverType) {
		this.coverType = coverType;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getIntermediaryCode() {
		return intermediaryCode;
	}
	public void setIntermediaryCode(String intermediaryCode) {
		this.intermediaryCode = intermediaryCode;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getPolicyTerm() {
		return policyTerm;
	}
	public void setPolicyTerm(String policyTerm) {
		this.policyTerm = policyTerm;
	}
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public String getPlanCoverage() {
		return planCoverage;
	}
	public void setPlanCoverage(String planCoverage) {
		this.planCoverage = planCoverage;
	}
	public String getCoreBenPerUnit() {
		return coreBenPerUnit;
	}
	public void setCoreBenPerUnit(String coreBenPerUnit) {
		this.coreBenPerUnit = coreBenPerUnit;
	}
	public String getCoreBenNoOfUnit() {
		return coreBenNoOfUnit;
	}
	public void setCoreBenNoOfUnit(String coreBenNoOfUnit) {
		this.coreBenNoOfUnit = coreBenNoOfUnit;
	}
	public String getCoreSumInsured() {
		return coreSumInsured;
	}
	public void setCoreSumInsured(String coreSumInsured) {
		this.coreSumInsured = coreSumInsured;
	}
	public String getWeeklyBenUpto52Weeks() {
		return weeklyBenUpto52Weeks;
	}
	public void setWeeklyBenUpto52Weeks(String weeklyBenUpto52Weeks) {
		this.weeklyBenUpto52Weeks = weeklyBenUpto52Weeks;
	}
	public String getWeeklyBenNoOfUnits() {
		return weeklyBenNoOfUnits;
	}
	public void setWeeklyBenNoOfUnits(String weeklyBenNoOfUnits) {
		this.weeklyBenNoOfUnits = weeklyBenNoOfUnits;
	}
	public String getWeeklyBenefit() {
		return weeklyBenefit;
	}
	public void setWeeklyBenefit(String weeklyBenefit) {
		this.weeklyBenefit = weeklyBenefit;
	}
	public String getAddoncoverApp() {
		return addoncoverApp;
	}
	public void setAddoncoverApp(String addoncoverApp) {
		this.addoncoverApp = addoncoverApp;
	}
	public Integer getFamilySize() {
		return familySize;
	}
	public void setFamilySize(Integer familySize) {
		this.familySize = familySize;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}	
	public String getBenperMonth() {
		return benperMonth;
	}
	public void setBenperMonth(String benperMonth) {
		this.benperMonth = benperMonth;
	}
	public String getPayPeriod() {
		return payPeriod;
	}
	public void setPayPeriod(String payPeriod) {
		this.payPeriod = payPeriod;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	
}

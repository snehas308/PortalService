package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author yogesh570158
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CPIPaymentResponse {
	
	private String consumerAppTransId;
	private String bankId;
	private String cardType;
	private String consumerAppId;
	private String gatewayId;
	private String paymentMode;
	private String premiumAmount;
	private String responseCode;
	private String responseDescription;
	private String pgiTransactionid;
	private String transactionStatus;
	private String chequeType;
	private String gatewayTxnid;
	
	
	
	public String getGatewayTxnid() {
		return gatewayTxnid;
	}
	public void setGatewayTxnid(String gatewayTxnid) {
		this.gatewayTxnid = gatewayTxnid;
	}
	public String getConsumerAppTransId() {
		return consumerAppTransId;
	}
	public void setConsumerAppTransId(String consumerAppTransId) {
		this.consumerAppTransId = consumerAppTransId;
	}
	public String getBankId() {
		return bankId;
	}
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getConsumerAppId() {
		return consumerAppId;
	}
	public void setConsumerAppId(String consumerAppId) {
		this.consumerAppId = consumerAppId;
	}
	public String getGatewayId() {
		return gatewayId;
	}
	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getPremiumAmount() {
		return premiumAmount;
	}
	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	public String getPgiTransactionid() {
		return pgiTransactionid;
	}
	public void setPgiTransactionid(String pgiTransactionid) {
		this.pgiTransactionid = pgiTransactionid;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public String getChequeType() {
		return chequeType;
	}
	public void setChequeType(String chequeType) {
		this.chequeType = chequeType;
	}
	
}

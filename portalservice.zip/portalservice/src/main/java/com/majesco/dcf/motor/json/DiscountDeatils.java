package com.majesco.dcf.motor.json;

import java.util.Date;

import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class DiscountDeatils {

	private String tppdRestricted ; //TPPDRestricted
	private String vehicFiberFule; //Vehicle fittedwithFibreGlassFuelTank
	private String isAntitheftdev; //IstheVehiclefittedwithapprovedantitheftdevice
	private String areaExt; //AreaExtension
	private String assoType;//AssociationType
	private String assMemberno;//AssociationMemberNo
	private String memExpDate ; //MemberExpiryDate
	private String discount;//Discount
	private String rate;
	private String lifeMember;
	private String bangladesh;
	private String bhutan;
	private String nepal;
	private String maldives;
	private String pakistan;
	private String srilanka;
	private String fuelUsedNonConv;//Fuel Used/non-conventional source
	private String extensionToCoverDamage;
	private String coverForHireOrReward;
	private String legalLiabToPassexcludEmp;
	private String campaign;
	private String basisOfRatingGC;
	ServiceUtility serviceUtility = new ServiceUtility();
	// Start : 3444 : Vishal : 26-Feb-2018
	private String fleetDiscount;
		
	public String getFleetDiscount() {
		return fleetDiscount;
	}
	public void setFleetDiscount(String fleetDiscount) {
		this.fleetDiscount = fleetDiscount;
	}
	// Start : 3444 : Vishal : 26-Feb-2018
	public String getCampaign() {
		return campaign;
	}
	public void setCampaign(String campaign) {
		campaign = serviceUtility.blankToNullCheck(campaign);
		this.campaign = campaign;
	}
	public String getBasisOfRatingGC() {
		return basisOfRatingGC;
	}
	public void setBasisOfRatingGC(String basisOfRatingGC) {
		basisOfRatingGC = serviceUtility.blankToNullCheck(basisOfRatingGC);
		this.basisOfRatingGC = basisOfRatingGC;
	}
	public String getTppdRestricted() {
		return tppdRestricted;
	}
	public void setTppdRestricted(String tppdRestricted) {
		tppdRestricted = serviceUtility.blankToNullCheck(tppdRestricted);
		this.tppdRestricted = tppdRestricted;
	}
	public String getVehicFiberFule() {
		return vehicFiberFule;
	}
	public void setVehicFiberFule(String vehicFiberFule) {
		vehicFiberFule = serviceUtility.blankToNullCheck(vehicFiberFule);
		this.vehicFiberFule = vehicFiberFule;
	}
	public String getIsAntitheftdev() {
		return isAntitheftdev;
	}
	public void setIsAntitheftdev(String isAntitheftdev) {
		isAntitheftdev = serviceUtility.blankToNullCheck(isAntitheftdev);
		this.isAntitheftdev = isAntitheftdev;
	}
	public String getAreaExt() {
		return areaExt;
	}
	public void setAreaExt(String areaExt) {
		areaExt = serviceUtility.blankToNullCheck(areaExt);
		this.areaExt = areaExt;
	}
	public String getAssoType() {
		return assoType;
	}
	public void setAssoType(String assoType) {
		assoType = serviceUtility.blankToNullCheck(assoType);
		this.assoType = assoType;
	}
	public String getAssMemberno() {
		return assMemberno;
	}
	public void setAssMemberno(String assMemberno) {
		assMemberno = serviceUtility.blankToNullCheck(assMemberno);
		this.assMemberno = assMemberno;
	}
	public String getMemExpDate() {
		return memExpDate;
	}
	public void setMemExpDate(String memExpDate) {
		memExpDate = serviceUtility.blankToNullCheck(memExpDate);
		this.memExpDate = memExpDate;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		discount = serviceUtility.blankToNullCheck(discount);
		this.discount = discount;
	}
	public String getLifeMember() {
		return lifeMember;
	}
	public void setLifeMember(String lifeMember) {
		lifeMember = serviceUtility.blankToNullCheck(lifeMember);
		this.lifeMember = lifeMember;
	}
	public String getBangladesh() {
		return bangladesh;
	}
	public void setBangladesh(String bangladesh) {
		bangladesh = serviceUtility.blankToNullCheck(bangladesh);
		this.bangladesh = bangladesh;
	}
	public String getBhutan() {
		return bhutan;
	}
	public void setBhutan(String bhutan) {
		bhutan = serviceUtility.blankToNullCheck(bhutan);
		this.bhutan = bhutan;
	}
	public String getNepal() {
		return nepal;
	}
	public void setNepal(String nepal) {
		nepal = serviceUtility.blankToNullCheck(nepal);
		this.nepal = nepal;
	}
	public String getMaldives() {
		return maldives;
	}
	public void setMaldives(String maldives) {
		maldives = serviceUtility.blankToNullCheck(maldives);
		this.maldives = maldives;
	}
	public String getPakistan() {
		return pakistan;
	}
	public void setPakistan(String pakistan) {
		pakistan = serviceUtility.blankToNullCheck(pakistan);
		this.pakistan = pakistan;
	}
	public String getSrilanka() {
		return srilanka;
	}
	public void setSrilanka(String srilanka) {
		srilanka = serviceUtility.blankToNullCheck(srilanka);
		this.srilanka = srilanka;
	}
	public String getFuelUsedNonConv() {
		return fuelUsedNonConv;
	}
	public void setFuelUsedNonConv(String fuelUsedNonConv) {
		fuelUsedNonConv = serviceUtility.blankToNullCheck(fuelUsedNonConv);
		this.fuelUsedNonConv = fuelUsedNonConv;
	}
	public String getExtensionToCoverDamage() {
		return extensionToCoverDamage;
	}
	public void setExtensionToCoverDamage(String extensionToCoverDamage) {
		extensionToCoverDamage = serviceUtility.blankToNullCheck(extensionToCoverDamage);
		this.extensionToCoverDamage = extensionToCoverDamage;
	}
	public String getCoverForHireOrReward() {
		return coverForHireOrReward;
	}
	public void setCoverForHireOrReward(String coverForHireOrReward) {
		coverForHireOrReward = serviceUtility.blankToNullCheck(coverForHireOrReward);
		this.coverForHireOrReward = coverForHireOrReward;
	}
	public String getLegalLiabToPassexcludEmp() {
		return legalLiabToPassexcludEmp;
	}
	public void setLegalLiabToPassexcludEmp(String legalLiabToPassexcludEmp) {
		legalLiabToPassexcludEmp = serviceUtility.blankToNullCheck(legalLiabToPassexcludEmp);
		this.legalLiabToPassexcludEmp = legalLiabToPassexcludEmp;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	
	
}

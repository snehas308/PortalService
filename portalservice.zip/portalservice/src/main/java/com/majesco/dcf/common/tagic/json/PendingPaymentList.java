package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

public class PendingPaymentList {

	private int noOfPendingPayment;
	private ArrayList<DashBoardSummaryDetails> dashBoardPendingPaymentList;
	public int getNoOfPendingPayment() {
		return noOfPendingPayment;
	}
	public void setNoOfPendingPayment(int noOfPendingPayment) {
		this.noOfPendingPayment = noOfPendingPayment;
	}
	public ArrayList<DashBoardSummaryDetails> getDashBoardPendingPaymentList() {
		return dashBoardPendingPaymentList;
	}
	public void setDashBoardPendingPaymentList(
			ArrayList<DashBoardSummaryDetails> dashBoardPendingPaymentList) {
		this.dashBoardPendingPaymentList = dashBoardPendingPaymentList;
	}
	
	
}

package com.majesco.dcf.motor.json;

import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class NomineeDetails {

	
	private String nomineeName;
	private String nomineeAge;
	private String relationship;
	private String appointeeName;
	private String nomineeRelationship;
	ServiceUtility serviceUtility = new ServiceUtility();
	public String getNomineeName() {
		return nomineeName;
	}
	public void setNomineeName(String nomineeName) {
		nomineeName = serviceUtility.blankToNullCheck(nomineeName);
		this.nomineeName = nomineeName;
	}
	public String getNomineeAge() {
		return nomineeAge;
	}
	public void setNomineeAge(String nomineeAge) {
		nomineeAge = serviceUtility.blankToNullCheck(nomineeAge);
		this.nomineeAge = nomineeAge;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		relationship = serviceUtility.blankToNullCheck(relationship);
		this.relationship = relationship;
	}
	public String getAppointeeName() {
		return appointeeName;
	}
	public void setAppointeeName(String appointeeName) {
		appointeeName = serviceUtility.blankToNullCheck(appointeeName);
		this.appointeeName = appointeeName;
	}
	public String getNomineeRelationship() {
		return nomineeRelationship;
	}
	public void setNomineeRelationship(String nomineeRelationship) {
		nomineeRelationship = serviceUtility.blankToNullCheck(nomineeRelationship);
		this.nomineeRelationship = nomineeRelationship;
	}
	

}

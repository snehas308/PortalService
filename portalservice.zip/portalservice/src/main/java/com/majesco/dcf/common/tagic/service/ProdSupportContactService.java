package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.googlecode.ehcache.annotations.Cacheable;
import com.majesco.dcf.common.tagic.entity.FieldUser;
import com.majesco.dcf.common.tagic.json.FieldUserResponse;
import com.majesco.dcf.common.tagic.json.ProdSupportContact;
import com.majesco.dcf.common.tagic.json.ProdSupportContactServiceRequest;
import com.majesco.dcf.common.tagic.json.ProdSupportContactServiceResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;

@Service
public class ProdSupportContactService {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(ProdSupportContactService.class);
	
	@SuppressWarnings("null")
	@Cacheable(cacheName="prodContactSupportCache")
	public ProdSupportContactServiceResponse getProdSupportDetails(ProdSupportContactServiceRequest prodSupportContactServiceReq)  throws Exception
	{
		ObjectMapper objMap=new ObjectMapper();
		ProdSupportContactServiceResponse prodSupportRes = new ProdSupportContactServiceResponse();
		ProdSupportContact prodSupportContact = null;
		ArrayList<ProdSupportContact> lstProdSupportContact = new ArrayList<ProdSupportContact>();
		ArrayList<String> lstParamCodes = null;
		String tempParamCode = null;
		String paramVal = null;
		//AccFinancierVO_old docVO = null;
		try
		{
		
			logger.info("In ProdSupportContactService.getProdSupportDetails() Method Begin()...");
			
			lstParamCodes = prodSupportContactServiceReq.getParamCode();
			
			for(int i=0; i<lstParamCodes.size();i++)
			{
				prodSupportContact = new ProdSupportContact();
				tempParamCode = lstParamCodes.get(i);
				//if(logger.isDebugEnabled())
					logger.info("In ProdSupportContactService.getProdSupportDetails() :: tempParamCode = "+tempParamCode);
				paramVal = dbserv.getConfigParamVal(tempParamCode);
				
				prodSupportContact.setParamCode(tempParamCode);
				prodSupportContact.setParamValue(paramVal);
				lstProdSupportContact.add(prodSupportContact);
			}
			prodSupportRes.setLstProdSupportContact(lstProdSupportContact);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("Exception StackTrace : ", e);
		}
		logger.info("In ProdSupportContactService.getProdSupportDetails() Method End()...");
		logger.info("In ProdSupportContactService.getProdSupportDetails() Method ::: "+objMap.writeValueAsString(prodSupportRes));
		
		return prodSupportRes;
	}

}

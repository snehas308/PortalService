package com.majesco.dcf.paproduct.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class SearchIPAQuotRequest extends UserObject {
	private String productCode;
	private String customerCd;
	private String mobileNo;
	private String emailId;
	private String dtQuotFrom;
	private String dtQuotTo;
	private String dtBirth;
	private String quotationNo;
	
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getCustomerCd() {
		return customerCd;
	}
	public void setCustomerCd(String customerCd) {
		this.customerCd = customerCd;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getDtQuotFrom() {
		return dtQuotFrom;
	}
	public void setDtQuotFrom(String dtQuotFrom) {
		this.dtQuotFrom = dtQuotFrom;
	}
	public String getDtQuotTo() {
		return dtQuotTo;
	}
	public void setDtQuotTo(String dtQuotTo) {
		this.dtQuotTo = dtQuotTo;
	}
	public String getDtBirth() {
		return dtBirth;
	}
	public void setDtBirth(String dtBirth) {
		this.dtBirth = dtBirth;
	}
	public String getQuotationNo() {
		return quotationNo;
	}
	public void setQuotationNo(String quotationNo) {
		this.quotationNo = quotationNo;
	}
}

package com.majesco.dcf.motor.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class SearchCoverNoteForPropRequest extends UserObject{
	
	private String productCode;
	private String coverNoteLeafNo;
	private String fieldUser;
	private String dealerCode;
	private String businessSrc;
	private String businessType;
	private String officeCode;
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getCoverNoteLeafNo() {
		return coverNoteLeafNo;
	}
	public void setCoverNoteLeafNo(String coverNoteLeafNo) {
		this.coverNoteLeafNo = coverNoteLeafNo;
	}
	public String getFieldUser() {
		return fieldUser;
	}
	public void setFieldUser(String fieldUser) {
		this.fieldUser = fieldUser;
	}
	public String getBusinessSrc() {
		return businessSrc;
	}
	public void setBusinessSrc(String businessSrc) {
		this.businessSrc = businessSrc;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getOfficeCode() {
		return officeCode;
	}
	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}
	public String getDealerCode() {
		return dealerCode;
	}
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}
	
	

}

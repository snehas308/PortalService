package com.majesco.dcf.common.tagic.json;

public class ProposalStatusReq extends UserObject {

	private String proposalNo;
	private String productCode;

	public String getProposalNo() {
		return proposalNo;
	}

	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
}

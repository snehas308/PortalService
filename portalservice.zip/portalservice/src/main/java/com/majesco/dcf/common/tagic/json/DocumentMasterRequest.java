package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocumentMasterRequest {
	
	private String strprodcd;
	private String strmodeofoperation;
	private String strendorsementtypecd;
	private String strcondition1;
	private String strcondition2;
	private String strcondition3;
	private String strcondition4;
	//private String authenticationToken;
	
	public String getStrprodcd() {
		return strprodcd;
	}
	public void setStrprodcd(String strprodcd) {
		this.strprodcd = strprodcd;
	}
	public String getStrmodeofoperation() {
		return strmodeofoperation;
	}
	public void setStrmodeofoperation(String strmodeofoperation) {
		this.strmodeofoperation = strmodeofoperation;
	}
	public String getStrendorsementtypecd() {
		return strendorsementtypecd;
	}
	public void setStrendorsementtypecd(String strendorsementtypecd) {
		this.strendorsementtypecd = strendorsementtypecd;
	}
	public String getStrcondition1() {
		return strcondition1;
	}
	public void setStrcondition1(String strcondition1) {
		this.strcondition1 = strcondition1;
	}
	public String getStrcondition2() {
		return strcondition2;
	}
	public void setStrcondition2(String strcondition2) {
		this.strcondition2 = strcondition2;
	}
	public String getStrcondition3() {
		return strcondition3;
	}
	public void setStrcondition3(String strcondition3) {
		this.strcondition3 = strcondition3;
	}
	public String getStrcondition4() {
		return strcondition4;
	}
	public void setStrcondition4(String strcondition4) {
		this.strcondition4 = strcondition4;
	}
//	public String getAuthenticationToken() {
//		return authenticationToken;
//	}
//	public void setAuthenticationToken(String authenticationToken) {
//		this.authenticationToken = authenticationToken;
//	}
	
	
}

package com.majesco.dcf.motor.json;

import com.majesco.dcf.common.tagic.json.CustomerDetails;
import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class InsuredDetails {

	private String insuredType;
	private CustomerDetails custoDet;
	ServiceUtility serviceUtility = new ServiceUtility();
	public String getInsuredType() {
		return insuredType;
	}
	public void setInsuredType(String insuredType) {
		insuredType = serviceUtility.blankToNullCheck(insuredType);
		this.insuredType = insuredType;
	}
	public CustomerDetails getCustoDet() {
		return custoDet;
	}
	public void setCustoDet(CustomerDetails custoDet) {
		this.custoDet = custoDet;
	}
	

}

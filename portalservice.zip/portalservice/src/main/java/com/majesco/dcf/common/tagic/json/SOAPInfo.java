package com.majesco.dcf.common.tagic.json;

public class SOAPInfo extends UserObject{
	
	private Long transactionID=(long) 0;
	private String createdBy="";	
	private String jsonRequest="";
	private String jsonResponse="";
	private String lobService;
	private String lobtype;
	private String transactionEvent;
	private String productCode;
	
	
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getTransactionEvent() {
		return transactionEvent;
	}
	public void setTransactionEvent(String transactionEvent) {
		this.transactionEvent = transactionEvent;
	}
	public Long getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(Long transactionID) {
		this.transactionID = transactionID;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public String getJsonRequest() {
		return jsonRequest;
	}
	public void setJsonRequest(String jsonRequest) {
		this.jsonRequest = jsonRequest;
	}
	public String getJsonResponse() {
		return jsonResponse;
	}
	public void setJsonResponse(String jsonResponse) {
		this.jsonResponse = jsonResponse;
	}
	public String getLobService() {
		return lobService;
	}
	public void setLobService(String lobService) {
		this.lobService = lobService;
	}
	public String getLobtype() {
		return lobtype;
	}
	public void setLobtype(String lobtype) {
		this.lobtype = lobtype;
	}
	
}

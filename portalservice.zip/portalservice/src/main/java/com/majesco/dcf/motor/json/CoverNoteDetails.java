package com.majesco.dcf.motor.json;

import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class CoverNoteDetails {
	
	private String openCvrNt;
	private String fieldUser;
	private String userCd;
	private String userNm;
	private String cvrNtNo;
	private String cvrIssDtTm;
	private String discount;
	private String underWrtngLoadng;
	private String underWrtngDisc;
	private String basisOfRtng;
	private String rate;
	private String dealer;
	private String cvrIssTm;
	private String manualCvrNtOpt;
	ServiceUtility serviceUtility = new ServiceUtility();
	
	public String getOpenCvrNt() {
		return openCvrNt;
	}
	public void setOpenCvrNt(String openCvrNt) {
		openCvrNt = serviceUtility.blankToNullCheck(openCvrNt);
		this.openCvrNt = openCvrNt;
	}
	public String getFieldUser() {
		return fieldUser;
	}
	public void setFieldUser(String fieldUser) {
		fieldUser = serviceUtility.blankToNullCheck(fieldUser);
		this.fieldUser = fieldUser;
	}
	public String getUserCd() {
		return userCd;
	}
	public void setUserCd(String userCd) {
		userCd = serviceUtility.blankToNullCheck(userCd);
		this.userCd = userCd;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		userNm = serviceUtility.blankToNullCheck(userNm);
		this.userNm = userNm;
	}
	public String getCvrNtNo() {
		return cvrNtNo;
	}
	public void setCvrNtNo(String cvrNtNo) {
		cvrNtNo = serviceUtility.blankToNullCheck(cvrNtNo);
		this.cvrNtNo = cvrNtNo;
	}
	public String getCvrIssDtTm() {
		return cvrIssDtTm;
	}
	public void setCvrIssDtTm(String cvrIssDtTm) {
		cvrIssDtTm = serviceUtility.blankToNullCheck(cvrIssDtTm);
		this.cvrIssDtTm = cvrIssDtTm;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		discount = serviceUtility.blankToNullCheck(discount);
		this.discount = discount;
	}
	public String getUnderWrtngLoadng() {
		return underWrtngLoadng;
	}
	public void setUnderWrtngLoadng(String underWrtngLoadng) {
		underWrtngLoadng = serviceUtility.blankToNullCheck(underWrtngLoadng);
		this.underWrtngLoadng = underWrtngLoadng;
	}
	public String getUnderWrtngDisc() {
		return underWrtngDisc;
	}
	public void setUnderWrtngDisc(String underWrtngDisc) {
		underWrtngDisc = serviceUtility.blankToNullCheck(underWrtngDisc);
		this.underWrtngDisc = underWrtngDisc;
	}
	public String getBasisOfRtng() {
		return basisOfRtng;
	}
	public void setBasisOfRtng(String basisOfRtng) {
		basisOfRtng = serviceUtility.blankToNullCheck(basisOfRtng);
		this.basisOfRtng = basisOfRtng;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		rate = serviceUtility.blankToNullCheck(rate);
		this.rate = rate;
	}
	public String getDealer() {
		return dealer;
	}
	public void setDealer(String dealer) {
		dealer = serviceUtility.blankToNullCheck(dealer);
		this.dealer = dealer;
	}
	public String getCvrIssTm() {
		return cvrIssTm;
	}
	public void setCvrIssTm(String cvrIssTm) {
		cvrIssTm = serviceUtility.blankToNullCheck(cvrIssTm);
		this.cvrIssTm = cvrIssTm;
	}
	public String getManualCvrNtOpt() {
		return manualCvrNtOpt;
	}
	public void setManualCvrNtOpt(String manualCvrNtOpt) {
		manualCvrNtOpt = serviceUtility.blankToNullCheck(manualCvrNtOpt);
		this.manualCvrNtOpt = manualCvrNtOpt;
	}
	
	

}

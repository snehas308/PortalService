package com.majesco.dcf.policyservicing.serviceimpl;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.paproduct.util.IPAProductConstants;
import com.majesco.dcf.policyservicing.jaxb.incident.IncidentCreation;
import com.majesco.dcf.policyservicing.jaxb.incident.IncidentCreation.DocList;
import com.majesco.dcf.policyservicing.jaxb.incident.IncidentCreation.DocList.Doc;
import com.majesco.dcf.policyservicing.jaxb.incident.result.IncidentCreationResponse;
import com.majesco.dcf.policyservicing.json.DCFDocument;
import com.majesco.dcf.policyservicing.json.DCFIncidentCreationRequest;
import com.majesco.dcf.policyservicing.json.DCFIncidentCreationResult;
import com.majesco.dcf.policyservicing.json.DocumentListResult;
import com.majesco.dcf.policyservicing.service.PolicyServicingService;
import com.majesco.dcf.common.chp.util.JAXBXMLHandler;
import com.unotechsoft.stub.policyservicing.upload.ServiceSoap;

@Service
@Transactional
public class PolicyServicingServiceImpl implements PolicyServicingService {
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(PolicyServicingServiceImpl.class);

	@Override
	public DCFIncidentCreationResult fileUploadToOnyx(
			DCFIncidentCreationRequest incidentReq) throws Exception {
		
		ObjectMapper objMapper = new ObjectMapper();
		logger.info("IPAServiceImpl :: getProductProposalDataPrvtCar() Request JSONObj :: \n " + objMapper.writeValueAsString(incidentReq)); // To print UI req
		
		IncidentCreation p2Dto = null;
		Mapper mapper =null;
		DCFIncidentCreationResult response = new DCFIncidentCreationResult();
		List<String> list = new ArrayList<String>(1);
		String propValue = "";
		String jaxbXML = null;
		IncidentCreationResponse incidentResp = new IncidentCreationResponse();
		DocumentListResult docResult = null;
		List<DocumentListResult> lstdocResult = new ArrayList<DocumentListResult>();
		
		try{
			list.add("PSMapping.xml");
			mapper = (Mapper) new DozerBeanMapper(list);
			p2Dto = new IncidentCreation();
			
			mapper.map(incidentReq, p2Dto,"FileUploadOnyx");
			DocList docListObject = new DocList();
			List<Doc> lstdoc = new ArrayList<IncidentCreation.DocList.Doc>();
			
			for (DCFDocument dcfdoc: incidentReq.getDocList()){
				Doc ObjDoc = new Doc();
				mapper.map(dcfdoc, ObjDoc,"DocumentDtl");
				docListObject.getDoc().add(ObjDoc);
			}
			
			p2Dto.setDocList(docListObject);
			
			propValue=getWSDLURL(IPAProductConstants.ONYX_SERVICE_WSDL);
			
			jaxbXML=JAXBXMLHandler.marshal(p2Dto);
			logger.info("Inside PolicyServicingServiceImpl :: fileUploadToOnyx method :: jaxbXML :: "+jaxbXML);
			
			URL url = new URL(propValue);
			com.unotechsoft.stub.policyservicing.upload.Service stub = new com.unotechsoft.stub.policyservicing.upload.Service(url);
			
			com.unotechsoft.stub.policyservicing.upload.ChannelportalIncidentCreation reqQ = new com.unotechsoft.stub.policyservicing.upload.ChannelportalIncidentCreation();
			reqQ.setInputElement(jaxbXML);
			
			ServiceSoap port = stub.getServiceSoap12();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);
			com.unotechsoft.stub.policyservicing.upload.ChannelportalIncidentCreationResponse.ChannelportalIncidentCreationResult result = port.channelportalIncidentCreation(jaxbXML);
			if(result.getContent()!=null){
				for (Object obj: result.getContent()){
					String responseStr = (String) obj;
					incidentResp=(IncidentCreationResponse)JAXBXMLHandler.unmarshal(responseStr, incidentResp);
					if (incidentResp.getChannelportalIncidentCreationResult()!= null && incidentResp.getChannelportalIncidentCreationResult().getWebResponse()!= null
							&& incidentResp.getChannelportalIncidentCreationResult().getWebResponse().getResponseDetails()!= null ){
						docResult =  new DocumentListResult();
						docResult.setIncidentStatus(incidentResp.getChannelportalIncidentCreationResult().getWebResponse().getResponseDetails().getIncidentStatus());
						docResult.setIncidentID(""+incidentResp.getChannelportalIncidentCreationResult().getWebResponse().getResponseDetails().getIncidentID());
						docResult.setRemarks(incidentResp.getChannelportalIncidentCreationResult().getWebResponse().getResponseDetails().getRemarks());
						lstdocResult.add(docResult);
					}
				}
				response.setLstDocResult(lstdocResult);
			}
			
		}
		catch (Exception ex){
			ex.printStackTrace();
		}
		return response;
	}
	
	private String getWSDLURL(String param)
	{
		String propVal="";
		try
		{
			propVal = dbserv.getWSDLURL(param,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			return propVal;
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
			logger.error("Inside PolicyServicingServiceImpl :: getWSDLURL() method ::",ae);
		}
		return propVal;
	}
	
	

}

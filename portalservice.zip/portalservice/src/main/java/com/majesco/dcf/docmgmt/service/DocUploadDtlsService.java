package com.majesco.dcf.docmgmt.service;

import com.majesco.dcf.common.tagic.json.PortalLockDetails;
import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.docmgmt.json.CustDocUploadLinkReq;
import com.majesco.dcf.docmgmt.json.CustDocUploadLinkRes;
import com.majesco.dcf.docmgmt.json.DocSourceOptionReq;
import com.majesco.dcf.docmgmt.json.DocUploadDtlsObj;
import com.majesco.dcf.docmgmt.json.DocUploadDtlsRequest;
import com.majesco.dcf.docmgmt.json.DocUploadDtlsResponse;
import com.majesco.dcf.docmgmt.json.DocUploadOptionReq;
import com.majesco.dcf.docmgmt.json.DocUploadOptnResponse;
import com.majesco.dcf.docmgmt.json.DocUploadSearchObj;
import com.majesco.dcf.docmgmt.json.DocUploadSearchResponse;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsReq;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsRes;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsSearchReq;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsSearchRes;
import com.majesco.dcf.docmgmt.json.QCDecisionRequest;
import com.majesco.dcf.docmgmt.json.QCDecisionResponse;
import com.majesco.dcf.docmgmt.json.QCInspectionRequest;
import com.majesco.dcf.docmgmt.json.QCInspectionResponse;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

@Service
@Transactional
public abstract interface DocUploadDtlsService
{
  public abstract DocUploadDtlsResponse saveDocUploadDtls(DocUploadDtlsRequest paramDocUploadDtlsRequest, String paramString)
    throws Exception;
  
  public abstract boolean saveUploadedFiles(DocUploadDtlsObj paramDocUploadDtlsObj)
    throws Exception;
  
  public abstract QCInspectionResponse getDataForQCInspection(QCInspectionRequest paramQCInspectionRequest)
    throws Exception;
  
  public abstract DocUploadSearchResponse getUploadDocSearch(DocUploadSearchObj paramDocUploadSearchObj)
    throws Exception;
  
  public abstract QCDecisionResponse updateDataForQCInspection(@RequestBody QCDecisionRequest paramQCDecisionRequest)
    throws Exception;
  
  public abstract DocUploadOptnResponse saveDocUploadOptn(DocUploadOptionReq paramDocUploadOptionReq)
    throws Exception;
  
  public abstract byte[] getRequestedDocument(QCInspectionRequest paramQCInspectionRequest, HttpServletResponse paramHttpServletResponse)
    throws Exception;
  
  public abstract boolean saveUploadedMultiFiles(DocUploadDtlsRequest paramDocUploadDtlsRequest)
    throws Exception;
  
  public abstract CustDocUploadLinkRes sendCustDocUploadLink(CustDocUploadLinkReq paramCustDocUploadLinkReq)
    throws Exception;
  
  public abstract PortalLockDetails portalLockForDocument(UserObject paramUserObject)
    throws Exception;
  
  public abstract Map<String, String> getUploadDocDetails(String paramString)
    throws Exception;
  
  public abstract DocUploadSearchResponse getUploadRejDocSearch(DocUploadSearchObj paramDocUploadSearchObj)
    throws Exception;
  
  public abstract ProducerLockDtlsRes saveProducerLockDtls(ProducerLockDtlsReq paramProducerLockDtlsReq)
    throws Exception;
  
  public abstract ProducerLockDtlsSearchRes searchProdLockDtls(ProducerLockDtlsSearchReq paramProducerLockDtlsSearchReq)
    throws Exception;
  
  public abstract DocUploadOptnResponse saveSourceOptn(DocSourceOptionReq paramDocSourceOptionReq)
    throws Exception;
}

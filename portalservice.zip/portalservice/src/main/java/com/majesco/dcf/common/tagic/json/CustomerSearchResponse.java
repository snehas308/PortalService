package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CustomerSearchResponse extends ResultObject {

	private ArrayList<CustomerSearchDetails> customerSearchDetailsList;

	public ArrayList<CustomerSearchDetails> getCustomerSearchDetailsList() {
		return customerSearchDetailsList;
	}

	public void setCustomerSearchDetailsList(
			ArrayList<CustomerSearchDetails> customerSearchDetailsList) {
		this.customerSearchDetailsList = customerSearchDetailsList;
	}
	
}

package com.majesco.dcf.common.tagic.errorhandler;

import java.io.IOException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author yogesh570158
 *
 */
@Service
@Transactional
public class ErrorHandlerUtility implements ErrorHandlerService {
	
	private static final Logger logger = LoggerFactory.getLogger(ErrorHandlerUtility.class);
	
	static String propValue = null;
	static String propFileName = null;
	static Properties properties;
//	static InputStream inputStream = ErrorHandlerUtility.class.getClassLoader().getResourceAsStream(propFileName);
	
	/**
	 * @return
	 */
	private static String getErrorCodeProperty(String propName){
		try {
			
			propFileName = "errorcode.properties";
			properties = new Properties();
		
			logger.info("ErrorHandlerUtility.getErrorMSGProperty :: propFileName: " + propFileName);
			properties.load(ErrorHandlerUtility.class.getClassLoader().getResourceAsStream(propFileName));
			propValue = properties.getProperty(propName);
			logger.info("ErrorHandlerUtility.getErrorMSGProperty :: response propValue: " + propValue);
		
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("ErrorHandlerUtility.getErrorMSGProperty :: IOException: ", e);
		} catch (Exception ex){
			ex.printStackTrace();
			logger.error("ErrorHandlerUtility.getErrorMSGProperty :: Exception: ", ex);
		}
		
		return propValue;	
	}

	@SuppressWarnings("static-access")
	@Override
	public String getErrorCodeByPropName(String propName) throws Exception {
		// TODO Auto-generated method stub
		try {
			
			logger.info("ErrorHandlerUtility.getErrorCodeByPropName :: Request-propName: " + propName);
			propValue = this.getErrorCodeProperty(propName);	
			logger.info("ErrorHandlerUtility.getErrorCodeByPropName :: Response-propValue: " + propValue);
			
		} catch (Exception ex){
			ex.printStackTrace();
			logger.error("ErrorHandlerUtility.getErrorCodeByPropName :: Exception: ", ex);
		}
		
		return propValue;	
	}

}

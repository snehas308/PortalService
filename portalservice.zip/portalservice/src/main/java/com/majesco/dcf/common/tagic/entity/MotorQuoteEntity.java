package com.majesco.dcf.common.tagic.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "dcf_motor_quot_dtl")
public class MotorQuoteEntity {
	
	private String quoteNo;
	private String proposalNo;
	private String producerCd;
	private Date dtCreated;
	private Date dtUpdated;
	private String strCreatedBy;
	private String strUpdatedBy;
	
	@Id
	@Column(name="quotenumber", nullable=false)
	@Index(name="quotenumber_index")
	public String getQuoteNo() {
		return quoteNo;
	}
	public void setQuoteNo(String quoteNo) {
		this.quoteNo = quoteNo;
	}
	
	@Column(name="proposalnumber", nullable=false)
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	
	@Column(name="producercode", nullable=false)
	@Index(name="producercode_index")
	public String getProducerCd() {
		return producerCd;
	}
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtcreated")
	public Date getDtCreated() {
		return dtCreated;
	}
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtupdated")
	public Date getDtUpdated() {
		return dtUpdated;
	}
	public void setDtUpdated(Date dtUpdated) {
		this.dtUpdated = dtUpdated;
	}
	
	@Column(name="strcreatedby")
	public String getStrCreatedBy() {
		return strCreatedBy;
	}
	public void setStrCreatedBy(String strCreatedBy) {
		this.strCreatedBy = strCreatedBy;
	}
	
	@Column(name="strupdatedby")
	public String getStrUpdatedBy() {
		return strUpdatedBy;
	}
	public void setStrUpdatedBy(String strUpdatedBy) {
		this.strUpdatedBy = strUpdatedBy;
	}

	
}

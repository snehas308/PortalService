package com.majesco.dcf.docmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

/**
 * @author yogesh570158
 *
 */
@Entity
@Table(name = "dcf_document_upload_optn")
public class DocUploadOptn implements Serializable{

	@Id
	@Column(name = "strproposalno")
	private String strproposalno;
	
	@Column(name = "strpolicyno")
	private String strpolicyno;
	
	@Column(name = "strstatus")
	private String  strstatus;
	
	@Column(name = "stroption")
	private String stroption;
	
	
	@Column(name = "strcreatedby")
	private String strCreatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtcreated", insertable=false)
	private Date dtCreated;
	
	@Column(name = "strupdatedby")
	private String strUpdatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtupdated", insertable=false)
	private Date dtUpdated;


	public String getStrproposalno() {
		return strproposalno;
	}

	public void setStrproposalno(String strproposalno) {
		this.strproposalno = strproposalno;
	}

	public String getStrpolicyno() {
		return strpolicyno;
	}

	public void setStrpolicyno(String strpolicyno) {
		this.strpolicyno = strpolicyno;
	}

	public String getStrstatus() {
		return strstatus;
	}

	public void setStrstatus(String strstatus) {
		this.strstatus = strstatus;
	}

	public String getStroption() {
		return stroption;
	}

	public void setStroption(String stroption) {
		this.stroption = stroption;
	}

	public String getStrCreatedBy() {
		return strCreatedBy;
	}

	public void setStrCreatedBy(String strCreatedBy) {
		this.strCreatedBy = strCreatedBy;
	}

	public Date getDtCreated() {
		return dtCreated;
	}

	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}

	public String getStrUpdatedBy() {
		return strUpdatedBy;
	}

	public void setStrUpdatedBy(String strUpdatedBy) {
		this.strUpdatedBy = strUpdatedBy;
	}

	public Date getDtUpdated() {
		return dtUpdated;
	}

	public void setDtUpdated(Date dtUpdated) {
		this.dtUpdated = dtUpdated;
	}

	
	
	
	
	
}

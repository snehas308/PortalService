package com.majesco.dcf.covernote.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class SaveOpenCNResponse {
	
	private String status;
	private String transactionId;
	private String policyNo;
	private List<String> receiptNo;
	private List<String> subReceiptNo;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public List<String> getReceiptNo() {
		return receiptNo;
	}
	public void setReceiptNo(List<String> receiptNo) {
		this.receiptNo = receiptNo;
	}
	public List<String> getSubReceiptNo() {
		return subReceiptNo;
	}
	public void setSubReceiptNo(List<String> subReceiptNo) {
		this.subReceiptNo = subReceiptNo;
	}
	
}

package com.majesco.dcf.common.tagic.json;


import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DealerMasterResponse {
	private List<String> strintermediarycd;
	private List<String> strintermediaryname;
	/*private List<String> dtbirth;
	private List<String> dtintermediarystart;
	private List<String> dtintermediaryend;
	private List<Integer> nintermediarystatus;
	private List<String> strintermediarystatus;
	private List<String> strindcorpflag;
	private List<Integer> ncategoryid;
	private List<String> strlicenseno;
	private List<String> strpanno;
	private List<Integer> nlocationcd;
	private List<Integer> nbranchcd;
	private List<String> strbankbranch;
	private List<String> straccountno;
	private List<String> strparentintermediarycd;
	private List<Integer> nynparent;
	private List<Integer> nyndealer;
	private List<Integer> nbankcd;
	private List<String> strifscd;
	private List<String> strmicrcd;
	private List<Integer> niscorpbranch;
	private List<Integer> ncommremtype;
	private List<String> strcommpaymode;
	private List<String> strinterpaymentfreq;
	private List<Integer> npaylocationcd;
	private List<String> strpayeename;
	private List<Integer> npayoutpayto;
	private List<Integer> npartnerid;
	private List<String> strchanneltype;
	private List<String> strgender;
	private List<String> struidno;
	private List<Integer> naccounttype ;
	private List<String> strsalutation;
	private List<String> strdnd;
	private List<Integer> nofficecd ;
	private List<String> strstatus;
	private List<Integer> nproducerprofilecd;
	private List<String> strsubtype;
	private List<String> strreasonsuspension;
	private List<String> strotherreasonsus;
	private List<String> strcategory;
	private List<String> strsubtransfercategory;
	private List<String> stralternatecd;
	private List<String> strissubproducer;
	private List<String> strchequedispatchedto;
	private List<String> strchequedisbursement;
	private List<String> strissuingcompanycd;
	private List<String> dtsubproducerissuedt;
	private List<Integer> nchannelid;
	private List<Integer> nchqdisptchoffcloc;*/
	private List<String> strdealercd;
	private List<String> strdealername;
	/*private List<String> strapprovalstatus;
	private List<String> strchecklocationcdm;
	private List<String> strcheckalllocation;
	private List<String> dtstatusefectivedt;
	private List<String> stremailsmsreqd;
	private List<String> stralt_dnd;
	private List<String> dtcreated;
	private List<String> strcreatedby;
	private List<String> dtupdated;
	private List<String> strupdatedby;*/
	private List<ResponseError> resErr;
	
	
	public List<String> getStrintermediarycd() {
		return strintermediarycd;
	}
	public void setStrintermediarycd(List<String> strintermediarycd) {
		this.strintermediarycd = strintermediarycd;
	}
	public List<String> getStrintermediaryname() {
		return strintermediaryname;
	}
	public void setStrintermediaryname(List<String> strintermediaryname) {
		this.strintermediaryname = strintermediaryname;
	}
	/*public List<String> getDtbirth() {
		return dtbirth;
	}
	public void setDtbirth(List<String> dtbirth) {
		this.dtbirth = dtbirth;
	}
	public List<String> getDtintermediarystart() {
		return dtintermediarystart;
	}
	public void setDtintermediarystart(List<String> dtintermediarystart) {
		this.dtintermediarystart = dtintermediarystart;
	}
	public List<String> getDtintermediaryend() {
		return dtintermediaryend;
	}
	public void setDtintermediaryend(List<String> dtintermediaryend) {
		this.dtintermediaryend = dtintermediaryend;
	}
	public List<Integer> getNintermediarystatus() {
		return nintermediarystatus;
	}
	public void setNintermediarystatus(List<Integer> nintermediarystatus) {
		this.nintermediarystatus = nintermediarystatus;
	}
	public List<String> getStrintermediarystatus() {
		return strintermediarystatus;
	}
	public void setStrintermediarystatus(List<String> strintermediarystatus) {
		this.strintermediarystatus = strintermediarystatus;
	}
	public List<String> getStrindcorpflag() {
		return strindcorpflag;
	}
	public void setStrindcorpflag(List<String> strindcorpflag) {
		this.strindcorpflag = strindcorpflag;
	}
	public List<Integer> getNcategoryid() {
		return ncategoryid;
	}
	public void setNcategoryid(List<Integer> ncategoryid) {
		this.ncategoryid = ncategoryid;
	}
	public List<String> getStrlicenseno() {
		return strlicenseno;
	}
	public void setStrlicenseno(List<String> strlicenseno) {
		this.strlicenseno = strlicenseno;
	}
	public List<String> getStrpanno() {
		return strpanno;
	}
	public void setStrpanno(List<String> strpanno) {
		this.strpanno = strpanno;
	}
	public List<Integer> getNlocationcd() {
		return nlocationcd;
	}
	public void setNlocationcd(List<Integer> nlocationcd) {
		this.nlocationcd = nlocationcd;
	}
	public List<Integer> getNbranchcd() {
		return nbranchcd;
	}
	public void setNbranchcd(List<Integer> nbranchcd) {
		this.nbranchcd = nbranchcd;
	}
	public List<String> getStrbankbranch() {
		return strbankbranch;
	}
	public void setStrbankbranch(List<String> strbankbranch) {
		this.strbankbranch = strbankbranch;
	}
	public List<String> getStraccountno() {
		return straccountno;
	}
	public void setStraccountno(List<String> straccountno) {
		this.straccountno = straccountno;
	}
	public List<String> getStrparentintermediarycd() {
		return strparentintermediarycd;
	}
	public void setStrparentintermediarycd(List<String> strparentintermediarycd) {
		this.strparentintermediarycd = strparentintermediarycd;
	}
	public List<Integer> getNynparent() {
		return nynparent;
	}
	public void setNynparent(List<Integer> nynparent) {
		this.nynparent = nynparent;
	}
	public List<Integer> getNyndealer() {
		return nyndealer;
	}
	public void setNyndealer(List<Integer> nyndealer) {
		this.nyndealer = nyndealer;
	}
	public List<Integer> getNbankcd() {
		return nbankcd;
	}
	public void setNbankcd(List<Integer> nbankcd) {
		this.nbankcd = nbankcd;
	}
	public List<String> getStrifscd() {
		return strifscd;
	}
	public void setStrifscd(List<String> strifscd) {
		this.strifscd = strifscd;
	}
	public List<String> getStrmicrcd() {
		return strmicrcd;
	}
	public void setStrmicrcd(List<String> strmicrcd) {
		this.strmicrcd = strmicrcd;
	}
	public List<Integer> getNiscorpbranch() {
		return niscorpbranch;
	}
	public void setNiscorpbranch(List<Integer> niscorpbranch) {
		this.niscorpbranch = niscorpbranch;
	}
	public List<Integer> getNcommremtype() {
		return ncommremtype;
	}
	public void setNcommremtype(List<Integer> ncommremtype) {
		this.ncommremtype = ncommremtype;
	}
	public List<String> getStrcommpaymode() {
		return strcommpaymode;
	}
	public void setStrcommpaymode(List<String> strcommpaymode) {
		this.strcommpaymode = strcommpaymode;
	}
	public List<String> getStrinterpaymentfreq() {
		return strinterpaymentfreq;
	}
	public void setStrinterpaymentfreq(List<String> strinterpaymentfreq) {
		this.strinterpaymentfreq = strinterpaymentfreq;
	}
	public List<Integer> getNpaylocationcd() {
		return npaylocationcd;
	}
	public void setNpaylocationcd(List<Integer> npaylocationcd) {
		this.npaylocationcd = npaylocationcd;
	}
	public List<String> getStrpayeename() {
		return strpayeename;
	}
	public void setStrpayeename(List<String> strpayeename) {
		this.strpayeename = strpayeename;
	}
	public List<Integer> getNpayoutpayto() {
		return npayoutpayto;
	}
	public void setNpayoutpayto(List<Integer> npayoutpayto) {
		this.npayoutpayto = npayoutpayto;
	}
	public List<Integer> getNpartnerid() {
		return npartnerid;
	}
	public void setNpartnerid(List<Integer> npartnerid) {
		this.npartnerid = npartnerid;
	}
	public List<String> getStrchanneltype() {
		return strchanneltype;
	}
	public void setStrchanneltype(List<String> strchanneltype) {
		this.strchanneltype = strchanneltype;
	}
	public List<String> getStrgender() {
		return strgender;
	}
	public void setStrgender(List<String> strgender) {
		this.strgender = strgender;
	}
	public List<String> getStruidno() {
		return struidno;
	}
	public void setStruidno(List<String> struidno) {
		this.struidno = struidno;
	}
	public List<Integer> getNaccounttype() {
		return naccounttype;
	}
	public void setNaccounttype(List<Integer> naccounttype) {
		this.naccounttype = naccounttype;
	}
	public List<String> getStrsalutation() {
		return strsalutation;
	}
	public void setStrsalutation(List<String> strsalutation) {
		this.strsalutation = strsalutation;
	}
	public List<String> getStrdnd() {
		return strdnd;
	}
	public void setStrdnd(List<String> strdnd) {
		this.strdnd = strdnd;
	}
	public List<Integer> getNofficecd() {
		return nofficecd;
	}
	public void setNofficecd(List<Integer> nofficecd) {
		this.nofficecd = nofficecd;
	}
	public List<String> getStrstatus() {
		return strstatus;
	}
	public void setStrstatus(List<String> strstatus) {
		this.strstatus = strstatus;
	}
	public List<Integer> getNproducerprofilecd() {
		return nproducerprofilecd;
	}
	public void setNproducerprofilecd(List<Integer> nproducerprofilecd) {
		this.nproducerprofilecd = nproducerprofilecd;
	}
	public List<String> getStrsubtype() {
		return strsubtype;
	}
	public void setStrsubtype(List<String> strsubtype) {
		this.strsubtype = strsubtype;
	}
	public List<String> getStrreasonsuspension() {
		return strreasonsuspension;
	}
	public void setStrreasonsuspension(List<String> strreasonsuspension) {
		this.strreasonsuspension = strreasonsuspension;
	}
	public List<String> getStrotherreasonsus() {
		return strotherreasonsus;
	}
	public void setStrotherreasonsus(List<String> strotherreasonsus) {
		this.strotherreasonsus = strotherreasonsus;
	}
	public List<String> getStrcategory() {
		return strcategory;
	}
	public void setStrcategory(List<String> strcategory) {
		this.strcategory = strcategory;
	}
	public List<String> getStrsubtransfercategory() {
		return strsubtransfercategory;
	}
	public void setStrsubtransfercategory(List<String> strsubtransfercategory) {
		this.strsubtransfercategory = strsubtransfercategory;
	}
	public List<String> getStralternatecd() {
		return stralternatecd;
	}
	public void setStralternatecd(List<String> stralternatecd) {
		this.stralternatecd = stralternatecd;
	}
	public List<String> getStrissubproducer() {
		return strissubproducer;
	}
	public void setStrissubproducer(List<String> strissubproducer) {
		this.strissubproducer = strissubproducer;
	}
	public List<String> getStrchequedispatchedto() {
		return strchequedispatchedto;
	}
	public void setStrchequedispatchedto(List<String> strchequedispatchedto) {
		this.strchequedispatchedto = strchequedispatchedto;
	}
	public List<String> getStrchequedisbursement() {
		return strchequedisbursement;
	}
	public void setStrchequedisbursement(List<String> strchequedisbursement) {
		this.strchequedisbursement = strchequedisbursement;
	}
	public List<String> getStrissuingcompanycd() {
		return strissuingcompanycd;
	}
	public void setStrissuingcompanycd(List<String> strissuingcompanycd) {
		this.strissuingcompanycd = strissuingcompanycd;
	}
	public List<String> getDtsubproducerissuedt() {
		return dtsubproducerissuedt;
	}
	public void setDtsubproducerissuedt(List<String> dtsubproducerissuedt) {
		this.dtsubproducerissuedt = dtsubproducerissuedt;
	}
	public List<Integer> getNchannelid() {
		return nchannelid;
	}
	public void setNchannelid(List<Integer> nchannelid) {
		this.nchannelid = nchannelid;
	}
	public List<Integer> getNchqdisptchoffcloc() {
		return nchqdisptchoffcloc;
	}
	public void setNchqdisptchoffcloc(List<Integer> nchqdisptchoffcloc) {
		this.nchqdisptchoffcloc = nchqdisptchoffcloc;
	}*/
	public List<String> getStrdealercd() {
		return strdealercd;
	}
	public void setStrdealercd(List<String> strdealercd) {
		this.strdealercd = strdealercd;
	}
	public List<String> getStrdealername() {
		return strdealername;
	}
	public void setStrdealername(List<String> strdealername) {
		this.strdealername = strdealername;
	}
	/*public List<String> getStrapprovalstatus() {
		return strapprovalstatus;
	}
	public void setStrapprovalstatus(List<String> strapprovalstatus) {
		this.strapprovalstatus = strapprovalstatus;
	}
	public List<String> getStrchecklocationcdm() {
		return strchecklocationcdm;
	}
	public void setStrchecklocationcdm(List<String> strchecklocationcdm) {
		this.strchecklocationcdm = strchecklocationcdm;
	}
	public List<String> getStrcheckalllocation() {
		return strcheckalllocation;
	}
	public void setStrcheckalllocation(List<String> strcheckalllocation) {
		this.strcheckalllocation = strcheckalllocation;
	}
	public List<String> getDtstatusefectivedt() {
		return dtstatusefectivedt;
	}
	public void setDtstatusefectivedt(List<String> dtstatusefectivedt) {
		this.dtstatusefectivedt = dtstatusefectivedt;
	}
	public List<String> getStremailsmsreqd() {
		return stremailsmsreqd;
	}
	public void setStremailsmsreqd(List<String> stremailsmsreqd) {
		this.stremailsmsreqd = stremailsmsreqd;
	}
	public List<String> getStralt_dnd() {
		return stralt_dnd;
	}
	public void setStralt_dnd(List<String> stralt_dnd) {
		this.stralt_dnd = stralt_dnd;
	}
	public List<String> getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(List<String> dtcreated) {
		this.dtcreated = dtcreated;
	}
	public List<String> getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(List<String> strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	public List<String> getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(List<String> dtupdated) {
		this.dtupdated = dtupdated;
	}
	public List<String> getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(List<String> strupdatedby) {
		this.strupdatedby = strupdatedby;
	}*/
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	

}

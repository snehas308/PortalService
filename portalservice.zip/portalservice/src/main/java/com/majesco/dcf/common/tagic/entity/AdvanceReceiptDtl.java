package com.majesco.dcf.common.tagic.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "dcf_ad_receipt_spl")
public class AdvanceReceiptDtl {
	
	private Integer lreceiptSeq;
	private String receiptNumber;
	private String receiptAmount;
	private String transId;
	private String status;
	private Date dtCreated;
	private Date dtUpdated;
	private String proposalNo;
	private String updatedBy;
	private String isrenew;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="lreceiptseq")
	public Integer getLreceiptSeq() {
		return lreceiptSeq;
	}
	public void setLreceiptSeq(Integer lreceiptSeq) {
		this.lreceiptSeq = lreceiptSeq;
	}
	
	@Column(name="receiptnumber")
	public String getReceiptNumber() {
		return receiptNumber;
	}
	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}
	
	@Column(name="receiptamount")
	public String getReceiptAmount() {
		return receiptAmount;
	}
	public void setReceiptAmount(String receiptAmount) {
		this.receiptAmount = receiptAmount;
	}
	
	@Column(name="transid")
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	
	@Column(name="status")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Column(name="dtcreated")
	public Date getDtCreated() {
		return dtCreated;
	}
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	@Column(name="dtupdated")
	public Date getDtUpdated() {
		return dtUpdated;
	}
	public void setDtUpdated(Date dtUpdated) {
		this.dtUpdated = dtUpdated;
	}
	
	@Column(name="proposalno")
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	
	@Column(name="updatedby")
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	@Column(name="isrenew")
	public String getIsrenew() {
		return isrenew;
	}
	public void setIsrenew(String isrenew) {
		this.isrenew = isrenew;
	}
	
	
}

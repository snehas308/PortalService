package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

public class PendingInspectionList {

	private int noOfPendingInspection;
	private ArrayList<DashBoardSummaryDetails> dashBoardSummaryInspectionList;
	public int getNoOfPendingInspection() {
		return noOfPendingInspection;
	}
	public void setNoOfPendingInspection(int noOfPendingInspection) {
		this.noOfPendingInspection = noOfPendingInspection;
	}
	public ArrayList<DashBoardSummaryDetails> getDashBoardSummaryInspectionList() {
		return dashBoardSummaryInspectionList;
	}
	public void setDashBoardSummaryInspectionList(
			ArrayList<DashBoardSummaryDetails> dashBoardSummaryInspectionList) {
		this.dashBoardSummaryInspectionList = dashBoardSummaryInspectionList;
	}
}

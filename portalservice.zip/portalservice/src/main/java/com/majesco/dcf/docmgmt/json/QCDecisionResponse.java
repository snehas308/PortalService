package com.majesco.dcf.docmgmt.json;

import java.util.ArrayList;
import java.util.HashMap;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

/**
 * @author ketan570156
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class QCDecisionResponse extends ResponseError{
	
	HashMap<String,Boolean> mapIsSuccessful;

	public HashMap<String, Boolean> getMapIsSuccessful() {
		return mapIsSuccessful;
	}

	public void setMapIsSuccessful(HashMap<String, Boolean> mapIsSuccessful) {
		this.mapIsSuccessful = mapIsSuccessful;
	}
	
	
}

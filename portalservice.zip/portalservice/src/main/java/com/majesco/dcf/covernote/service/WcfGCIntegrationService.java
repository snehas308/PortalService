package com.majesco.dcf.covernote.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.covernote.json.CNFlagProposalResponse;
import com.majesco.dcf.covernote.json.CheckCNFlagForProposal;
import com.majesco.dcf.covernote.json.PendingCoverNoteRequest;
import com.majesco.dcf.covernote.json.PendingCoverNoteResponse;
import com.majesco.dcf.covernote.json.SearchCoverNoteForPropRequest;
import com.majesco.dcf.covernote.json.SearchCoverNoteForPropResponse;

@Service
@Transactional
public interface WcfGCIntegrationService {
	
	public SearchCoverNoteForPropResponse searchUniqueCoverNote(SearchCoverNoteForPropRequest getCoverNoteReq) throws Exception;
	public List<PendingCoverNoteResponse> getOpenCoverNoteList(PendingCoverNoteRequest openCoverNoteReq) throws Exception;
	public CNFlagProposalResponse isCoverNoteProposal(CheckCNFlagForProposal cnFlagRequest) throws Exception;
	

}

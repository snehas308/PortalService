package com.majesco.dcf.common.tagic.json;

public class DBLinkPolicyDetails {
	
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getPolicStatus() {
		return policStatus;
	}
	public void setPolicStatus(String policStatus) {
		this.policStatus = policStatus;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	private String policyNo;
	private String policStatus;
	private String status;

	
	

}

package com.majesco.dcf.mailcomm.handler;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.mailcomm.json.EmailTemplateParam;
import com.majesco.dcf.mailcomm.service.MailTemplateService;

public class HTMLTemplateHandler implements MailTemplateService {

private static Properties prop = new Properties();
final static Logger logger=Logger.getLogger(HTMLTemplateHandler.class);
private static String _strCLassName="MailTemplateFactory";
	static{
		try{
	InputStream inputStream = HTMLTemplateHandler.class.getClassLoader().getResourceAsStream("mailhandler.properties");
	prop.load(inputStream);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	@Override
	public Object getHtmlMsgTemplate(EmailTemplateParam emailTemplateParam) throws Exception {
		// TODO Auto-generated method stub
		Object htmlMsgObj=null;
		File htmlFile=null;
		String strMethodName="getHtmlMsgTemplate";
		try{
			logger.info("Inside ::"+_strCLassName+"::"+strMethodName+"::Entered");
			if(emailTemplateParam!=null && emailTemplateParam.getEventID()!=null && !emailTemplateParam.getEventID().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				logger.info("Inside ::"+_strCLassName+"::"+strMethodName+":: HTML template file::"+prop.getProperty(emailTemplateParam.getEventID()));
				htmlFile=new File(prop.getProperty(emailTemplateParam.getEventID()));
				
				Document htmlDoc=Jsoup.parse(htmlFile, "UTF-8");
				if(htmlDoc!=null && emailTemplateParam.getParameterMap()!=null && emailTemplateParam.getParameterMap().size()>0){
					
					HashMap<String, String> parameterMap=emailTemplateParam.getParameterMap();
					
					Set<String> paramKeySet=parameterMap.keySet();
					Iterator<String> paramKeyItr=paramKeySet.iterator();
					String strElementId=null;
					if(paramKeyItr!=null){
						
						while(paramKeyItr.hasNext()){
							strElementId=paramKeyItr.next();
							//logger.info("Inside while loop **********::"+strElementId);
							logger.info("Inside while loop **********::"+htmlDoc.getElementById(strElementId));
							if (emailTemplateParam.getEventID().equalsIgnoreCase("SelfPayLink")&& strElementId.equalsIgnoreCase("param11")){
								htmlDoc.getElementById(strElementId).attr("href", parameterMap.get(strElementId));
								logger.info("self pay link testing **********::"+parameterMap.get(strElementId).toString());
							}
							else if(emailTemplateParam.getEventID().equalsIgnoreCase("REN_SelfPayLink_MOTOR")&& strElementId.equalsIgnoreCase("param10")){
								htmlDoc.getElementById(strElementId).attr("href", parameterMap.get(strElementId));
								logger.info("Renewal self pay link testing **********::"+parameterMap.get(strElementId).toString());
							}
							else if(emailTemplateParam.getEventID().equalsIgnoreCase("CUST_DOC_UPLOAD_LINK")&& strElementId.equalsIgnoreCase("param11")){
								htmlDoc.getElementById(strElementId).attr("href", parameterMap.get(strElementId));
								logger.info("CustDoc Upload link testing **********::"+parameterMap.get(strElementId).toString());
							}
							else if(htmlDoc.getElementById(strElementId)!=null)
							htmlDoc.getElementById(strElementId).appendText(parameterMap.get(strElementId));
							
							
						}
						
						htmlMsgObj=htmlDoc.html();
					}
					
				}
				
			}
			//if (logger.isDebugEnabled())
				//logger.debug("Inside ::"+_strCLassName+"::"+strMethodName+"::htmlMsgObj::"+htmlMsgObj.toString());
			
			logger.info("Inside ::"+_strCLassName+"::"+strMethodName+"::Exit");
		}catch(Exception ex){
			logger.error("Inside ::"+_strCLassName+"::"+strMethodName+"::Exception::",ex);
		}
		
		return htmlMsgObj;
	}

}

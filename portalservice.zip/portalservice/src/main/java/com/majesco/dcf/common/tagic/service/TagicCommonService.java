package com.majesco.dcf.common.tagic.service;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import com.majesco.dcf.common.tagic.json.AgentDashBoardRequest;
import com.majesco.dcf.common.tagic.json.AgentDashBoardResponse;
import com.majesco.dcf.common.tagic.json.FastLaneRequest;
import com.majesco.dcf.common.tagic.json.FastLaneResponse;
import com.majesco.dcf.common.tagic.json.HouseBankAccNoRequest;
import com.majesco.dcf.common.tagic.json.HouseBankAccNoResponse;
import com.majesco.dcf.common.tagic.json.PendingPayInSlipResponse;
import com.majesco.dcf.common.tagic.json.JsonDBService;
import com.majesco.dcf.common.tagic.json.PendingPropListRequest;
import com.majesco.dcf.common.tagic.json.PendingPropListResponse;
import com.majesco.dcf.common.tagic.json.PolicyDetailsSearchRequest;
import com.majesco.dcf.common.tagic.json.PolicyDetailsSearchResponse;
import com.majesco.dcf.common.tagic.json.PolicySearchRequest;
import com.majesco.dcf.common.tagic.json.PolicySearchResponse;
import com.majesco.dcf.common.tagic.json.PortalLockDaysRequest;
import com.majesco.dcf.common.tagic.json.PortalLockDetails;
import com.majesco.dcf.common.tagic.json.PrintProposalReq;
import com.majesco.dcf.common.tagic.json.ProposalSearchRequest;
import com.majesco.dcf.common.tagic.json.ProposalSearchResponse;
import com.majesco.dcf.common.tagic.json.ProposalStatus;
import com.majesco.dcf.common.tagic.json.ProposalStatusReq;
import com.majesco.dcf.common.tagic.json.QlikTicketResponse;
//import com.majesco.dcf.common.tagic.json.QlikTicketResponse;
import com.majesco.dcf.common.tagic.json.QuotationListResponse;
import com.majesco.dcf.common.tagic.json.QuotationSearchRequest;
import com.majesco.dcf.common.tagic.json.RenewalCalCountRequest;
import com.majesco.dcf.common.tagic.json.RenewalCalCountResponse;
import com.majesco.dcf.common.tagic.json.RenewalPolLetterRequest;
import com.majesco.dcf.common.tagic.json.RenewalPolLetterResponse;
import com.majesco.dcf.common.tagic.json.RenewalSearchRequest;
import com.majesco.dcf.common.tagic.json.RenewalSearchResponse;
import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.receipt.json.PrintRecieptResponse;
import com.majesco.dcf.reports.service.ReportService;
import com.majesco.dcf.usermgmt.json.UserInfoResponse;
import com.majesco.dcf.common.tagic.json.ValueByEffDateRequest;
import com.majesco.dcf.common.tagic.json.ValueByEffDateResponse;

@Service
@Transactional
public interface TagicCommonService {

	public ProposalStatus getProposalStatus (ProposalStatusReq reqObj) throws Exception;
	
	public PolicyDetailsSearchResponse getPolicyDetailsByPolicyNo(PolicyDetailsSearchRequest prodPropDataReq);
	
	public byte[] printProposal(PrintProposalReq printProposalReq,HttpServletResponse response) throws Exception;
	
	public byte[] printPolicy(PrintProposalReq printProposalReq,HttpServletResponse response) throws Exception;
	
	public byte[] printWorksheet(PrintProposalReq printProposalReq,HttpServletResponse response) throws Exception;
	
	public QuotationListResponse searchQuote(QuotationSearchRequest quoteSearchReq) throws Exception;
	
	public ProposalSearchResponse searchProposal(ProposalSearchRequest proposalSearchRequest) throws Exception;
	
	public AgentDashBoardResponse dashBoardPendingList(AgentDashBoardRequest agentDashBoardRequest) throws Exception;
	
	
	public PolicySearchResponse searchPolicy(PolicySearchRequest policySearchRequest) throws Exception;
	
	public QuotationListResponse searchQuoteByQuoteNo(QuotationSearchRequest quoteSearchReq) throws Exception;
	
	//@Async
	public byte[] printProposalAttachment(PrintProposalReq printProposalReq) throws Exception;
	//@Async
	public byte[] printPolicyAttachment(PrintProposalReq printProposalReq) throws Exception;
	//@Async
	public byte[] printWorksheetAttachment(PrintProposalReq printProposalReq) throws Exception;
	//@Async
	public byte[] printReceiptAttachment(String receiptNo, String userId, String password, String proposalNo) throws Exception;
	
	public RenewalCalCountResponse getRenewalCalCount(RenewalCalCountRequest renewalCalCountRequest) throws Exception;

	public RenewalSearchResponse getRenewalSearch(RenewalSearchRequest renewalSearchRequest) throws Exception;

	public RenewalPolLetterResponse printRenewalPolicyLetter(RenewalPolLetterRequest renewalPolLetterRequest) throws Exception;
	
	public UserInfoResponse getDealerInfo(UserObject userObject)throws Exception;
	
	public PendingPropListResponse getPendingProposalList(PendingPropListRequest pendingPropListRequest)throws Exception; 

	public String getProposalNoByPolicyNo(String  policyNumber,String productCode,String userId,String password,String authToken)throws Exception;
	
	public AgentDashBoardResponse dashBoardSPLPendingList(AgentDashBoardRequest agentDashBoardRequest) throws Exception;
	
	public AgentDashBoardResponse dashBoardRejectedList(AgentDashBoardRequest agentDashBoardRequest) throws Exception;

	public ProposalSearchResponse searchProposalOnSearchScreen(ProposalSearchRequest proposalSearchRequest) throws Exception;
	
	public Map<String,String> getMinPaymentDateForPortalLock(String userId) throws Exception;
	//public ResponseEntity<String> getPortalLockDays(PortalLockDaysRequest request) throws Exception;
	
	public boolean getPortalLockDays(PortalLockDaysRequest request) throws Exception;

	
	public AgentDashBoardResponse getPendingApprovalList(AgentDashBoardRequest agentDashBoardRequest) throws Exception;
	
	//method added on 18/05/2017 :Sailesh
	
	public AgentDashBoardResponse getPendingInspectionDetailsForPortal(AgentDashBoardRequest agentDashBoardRequest) throws Exception;
	

	public PortalLockDetails getPendingPayInSlipCount (UserObject request) throws Exception;
	public PortalLockDetails portalLockEODReceipting(UserObject request) throws Exception;

public ValueByEffDateResponse getValueByEffDate(ValueByEffDateRequest request) throws Exception; // Method to fetch Key & Values by EffDate into table
//Start: RahulT <SIT 1614>| service exposed to get workflow id from proposal no based on swaraj mail 24 July 2017 18:37
	public JsonDBService getProposalTaggedWithQuot(JsonDBService request) throws Exception;
	//End: RahulT <SIT 1614>| service exposed to get workflow id from proposal no based on swaraj mail 24 July 2017 18:37
//Start: RahulT <SIT 1608>| service exposed to get workflow id from proposal no based on swaraj mail 24 July 2017 18:37	
	public JsonDBService getWorkflowId(JsonDBService data) throws Exception;
	//End: RahulT <SIT 1608>| service exposed to get workflow id from proposal no based on swaraj mail 24 July 2017 18:37
	//1704 : Vishal J | New method added for getting byte[] for renewal notice email attachment | Start
	public byte[] printRenewalNoticeAttachment(String policyNo, String userId, String password) throws Exception;
	// 1704 : Vishal J | New method added for getting byte[] for renewal notice email attachment | End

	//Start: KetanM <SIT 2594>| service exposed to getFastLaneIntegration on 29 Nov 2017
	public FastLaneResponse getFastLaneIntegration(FastLaneRequest fastLaneRequest) throws Exception;
	//End: KetanM <SIT 2594>| service exposed to getFastLaneIntegration on 29 Nov 2017
	//Start: KetanM <SIT 2717>| service exposed to getHouseBankAndAccountNo on 11 Dec 2017
	public HouseBankAccNoResponse getHouseBankAndAccountNo(HouseBankAccNoRequest houseBankAccNoRequest) throws Exception;
	//End: KetanM <SIT 2717>| service exposed to getHouseBankList on 11 Dec 2017
	//Start: VishalJ <CR 3267>| To Renewal Search from Portal.	
	public RenewalSearchResponse renewalSearchPortal(RenewalSearchRequest renewalSearchRequest) throws Exception;
	//End: VishalJ <CR 3267>| To Renewal Search from Portal.
	//Start: VishalJ <SIT 2717>| service exposed to getHouseBankAndAccountNo on 21 Feb 2017
	public HouseBankAccNoResponse getHouseBankAndAccountNo_portal(HouseBankAccNoRequest houseBankAccNoRequest) throws Exception;
	//End: VishalJ <SIT 2717>| service exposed to getHouseBankList on 21 Feb 2017
    //START:Code changes for defects 2753,3284 to get Intermediary code w.r.t FieldUser
	public UserInfoResponse getFieldUserInfo(UserObject userObject)throws Exception;	
//Start: VishalJ <New Report Issue>| Service to be created for giving token
	QlikTicketResponse getQlikTicketNo(UserObject userObject) throws Exception;
	//End: VishalJ <New Report Issue>| Service to be created for giving token
	//Code Added For Reports Changes - Starts Here
	public String getEncryptedProducerCode(String producerCode) throws Exception;
}

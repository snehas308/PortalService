package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

public class SPLExpiredList {
	private int noOfPayLinkExpired;
	private ArrayList<DashBoardSummaryDetails> dashBoardPayLinkExp;
	
	public int getNoOfPayLinkExpired() {
		return noOfPayLinkExpired;
	}
	public void setNoOfPayLinkExpired(int noOfPayLinkExpired) {
		this.noOfPayLinkExpired = noOfPayLinkExpired;
	}
	
	public ArrayList<DashBoardSummaryDetails> getDashBoardPayLinkExp() {
		return dashBoardPayLinkExp;
	}
	public void setDashBoardPayLinkExp(
			ArrayList<DashBoardSummaryDetails> dashBoardPayLinkExp) {
		this.dashBoardPayLinkExp = dashBoardPayLinkExp;
	}
	
	

}

package com.majesco.dcf.paproduct.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.codehaus.jackson.map.annotate.JsonSerialize;
/**
 * @author ketan570156
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
@Entity
@Table(name = "dcf_quotation_dtl1")
public class QuotationPA1 {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="dcf_quotation_pa1_seqid")
	@SequenceGenerator(
			name="dcf_quotation_pa1_seqid",
			sequenceName="dcf_quotation_pa1_seqid",
			allocationSize=1
			)
	
	@Column(name = "strquotnumber")
	private Long quoteNumber;
	@Column(name = "strfirstname")
	private String firstName;
	@Column(name = "strlastname")
	private String lastName;
	@Column(name = "strmobile")
	private String mobileNumber;
	@Column(name = "stremail")
	private String email;
	@Column(name = "strplancode")
	private String planCode;
	@Column(name = "strintermediarycode")
	private String intermediaryCode;
	@Column(name = "strrequestdata")
	private String requestTransData;
	@Column(name = "strresponsedata")
	private String responseTransData;
	@Column(name = "dtcreated")
	private Date createdDate;
	@Column(name = "createdby")
	private String createdBy;
	@Column(name = "dtupdated")
	private Date updatedDate;
	@Column(name = "updatedby")
	private String updatedBy;
	@Column(name = "strproposalnumber")
	private String proposalNumber;
	@Column(name = "dtotalpayable")
	private String totalPayable;
	@Column(name = "strproductcode")
	private String productCode;
	/**
	 * @return the quoteNumber
	 */
	public Long getQuoteNumber() {
		return quoteNumber;
	}
	/**
	 * @param quoteNumber the quoteNumber to set
	 */
	public void setQuoteNumber(Long quoteNumber) {
		this.quoteNumber = quoteNumber;
	}
	
	
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}
	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the planCode
	 */
	public String getPlanCode() {
		return planCode;
	}
	/**
	 * @param planCode the planCode to set
	 */
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	/**
	 * @return the intermediaryCode
	 */
	public String getIntermediaryCode() {
		return intermediaryCode;
	}
	/**
	 * @param intermediaryCode the intermediaryCode to set
	 */
	public void setIntermediaryCode(String intermediaryCode) {
		this.intermediaryCode = intermediaryCode;
	}
	/**
	 * @return the requestTransData
	 */
	public String getRequestTransData() {
		return requestTransData;
	}
	/**
	 * @param requestTransData the requestTransData to set
	 */
	public void setRequestTransData(String requestTransData) {
		this.requestTransData = requestTransData;
	}
	/**
	 * @return the responseTransData
	 */
	public String getResponseTransData() {
		return responseTransData;
	}
	/**
	 * @param responseTransData the responseTransData to set
	 */
	public void setResponseTransData(String responseTransData) {
		this.responseTransData = responseTransData;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the updatedDate
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}
	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}
	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	/**
	 * @return the proposalNumber
	 */
	public String getProposalNumber() {
		return proposalNumber;
	}
	/**
	 * @param proposalNumber the proposalNumber to set
	 */
	public void setProposalNumber(String proposalNumber) {
		this.proposalNumber = proposalNumber;
	}
	/**
	 * @return the totalPayable
	 */
	public String getTotalPayable() {
		return totalPayable;
	}
	/**
	 * @param totalPayable the totalPayable to set
	 */
	public void setTotalPayable(String totalPayable) {
		this.totalPayable = totalPayable;
	}
	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}
	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

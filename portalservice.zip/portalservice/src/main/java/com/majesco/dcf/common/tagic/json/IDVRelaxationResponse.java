package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class IDVRelaxationResponse {
	
	private String resultCode;
	private String nidv;
	
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getNidv() {
		return nidv;
	}
	public void setNidv(String nidv) {
		this.nidv = nidv;
	}
	
	
	

	
}

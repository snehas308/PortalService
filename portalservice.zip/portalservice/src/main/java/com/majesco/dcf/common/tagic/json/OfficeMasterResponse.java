package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class OfficeMasterResponse {
	private List<String> office;
	private List<BigDecimal> nofficecd;
	private List<BigDecimal> nparentofficecd;
	private List<String> strofficedesc;
	private List<String> strofficecd;
	private List<String> strparentofficecd;
	private List<ResponseError> resErr;
	
	
	public List<String> getOffice() {
		return office;
	}
	public void setOffice(List<String> office) {
		this.office = office;
	}
	public List<BigDecimal> getNofficecd() {
		return nofficecd;
	}
	public void setNofficecd(List<BigDecimal> nofficecd) {
		this.nofficecd = nofficecd;
	}
	public List<BigDecimal> getNparentofficecd() {
		return nparentofficecd;
	}
	public void setNparentofficecd(List<BigDecimal> nparentofficecd) {
		this.nparentofficecd = nparentofficecd;
	}
	public List<String> getStrofficedesc() {
		return strofficedesc;
	}
	public void setStrofficedesc(List<String> strofficedesc) {
		this.strofficedesc = strofficedesc;
	}
	public List<String> getStrofficecd() {
		return strofficecd;
	}
	public void setStrofficecd(List<String> strofficecd) {
		this.strofficecd = strofficecd;
	}
	public List<String> getStrparentofficecd() {
		return strparentofficecd;
	}
	public void setStrparentofficecd(List<String> strparentofficecd) {
		this.strparentofficecd = strparentofficecd;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
}

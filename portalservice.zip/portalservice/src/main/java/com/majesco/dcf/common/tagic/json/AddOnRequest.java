package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class AddOnRequest {
	
	private String strplancode="";
	private String strchoice="";

	public String getStrplancode() {
		return strplancode;
	}

	public void setStrplancode(String strplancode) {
		this.strplancode = strplancode;
	}

	public String getStrchoice() {
		return strchoice;
	}

	public void setStrchoice(String strchoice) {
		this.strchoice = strchoice;
	}

	

}

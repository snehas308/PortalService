package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.json.IntermediaryOfficeCodeServiceRequest;
import com.majesco.dcf.common.tagic.json.IntermediaryOfficeCodeServiceResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;

@Service
public class IntermediaryOfficeCodeService {
	

	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(IntermediaryOfficeCodeService.class);
	
	@SuppressWarnings({ "null", "unchecked" })
	public IntermediaryOfficeCodeServiceResponse fetchIntermediaryOfficeCode(IntermediaryOfficeCodeServiceRequest modelreq) throws Exception
	{
		IntermediaryOfficeCodeServiceResponse modelres = new IntermediaryOfficeCodeServiceResponse();
		try
		{
		
			logger.info("In ModelService.fetchIntermediaryOfficeCode() Method Begin()...");
			
			String strrtolocationcd="";
			String strrtolocationdesc="";
			HashMap<String, Object> resultMap = new HashMap<String, Object>();
			BigDecimal bigVar = null;
			
			List<ResponseError> reserrList = new ArrayList<ResponseError>();
			
			
			ResponseError res = new ResponseError();
			res.setErrorCode("101");
			res.setErrorMMessag("Sorry Authentication Issue....");
			reserrList.add(res);
			
			//resultMap =  (HashMap<String, String>) dbserv.getIntermediaryDetails(modelreq.getProducerCode());
			
			resultMap =  (HashMap<String, Object>) dbserv.getIntermediaryDetailsOffice(modelreq.getProducerCode());
			
			if(resultMap!=null && resultMap.size()>0){
				
				modelres.setIntermediaryCode((String)resultMap.get("intermediary_code")==null?"":(String)resultMap.get("intermediary_code"));
				modelres.setIntermediaryName((String)resultMap.get("intermediary_name")==null?"":(String)resultMap.get("intermediary_name"));
				//System.out.println("getIntermediaryDetailsOffice :: resultMap.get('intermediary_officecd'): " + resultMap.get("intermediary_officecd"));
				//String strOfficeCd=(String)resultMap.get("intermediary_officecd");
				BigDecimal bg=(BigDecimal)resultMap.get("intermediary_officecd");
				//System.out.println("getIntermediaryDetailsOffice :: strOfficeCd: " + bg.toPlainString());
				modelres.setIntermediaryOfficeCode(bg.toPlainString());
				
			}
			
			return modelres;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("Exception StackTrace : ", e);
		}
		logger.info("In IntermediaryOfficeCodeService.fetchIntermediaryOfficeCode() Method End()...");
		ObjectMapper objMap=new ObjectMapper();
		//System.out.println(objMap.writeValueAsString(modelres));
		logger.info("In IntermediaryOfficeCodeService.fetchIntermediaryOfficeCode() Method ::: "+modelres);
		
		return modelres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }


}

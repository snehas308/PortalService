package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PolicySearchResponse extends ResultObject {
	private ArrayList<PolicySearchResultDet> policySearchResultDetList = new ArrayList<PolicySearchResultDet>();

	public ArrayList<PolicySearchResultDet> getPolicySearchResultDetList() {
		return policySearchResultDetList;
	}

	public void setPolicySearchResultDetList(
			ArrayList<PolicySearchResultDet> policySearchResultDetList) {
		this.policySearchResultDetList = policySearchResultDetList;
	}
	
	
}

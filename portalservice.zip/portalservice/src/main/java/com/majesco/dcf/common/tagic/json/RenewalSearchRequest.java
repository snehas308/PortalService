package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class RenewalSearchRequest extends UserObject {
	
	private String fromDate;
	private String toDate;
	private String strCustomerID;
	private String strCustomerName;
	private String strLOB;
	private String strProductCode;
	private String strPolicyNo;
	private String strPolicyInspectionDate;
	private String strDOB;
	private String strMobileNo;
	private String strAddOn;
	
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getStrCustomerID() {
		return strCustomerID;
	}
	public void setStrCustomerID(String strCustomerID) {
		this.strCustomerID = strCustomerID;
	}
	public String getStrCustomerName() {
		return strCustomerName;
	}
	public void setStrCustomerName(String strCustomerName) {
		this.strCustomerName = strCustomerName;
	}
	public String getStrLOB() {
		return strLOB;
	}
	public void setStrLOB(String strLOB) {
		this.strLOB = strLOB;
	}
	public String getStrProductCode() {
		return strProductCode;
	}
	public void setStrProductCode(String strProductCode) {
		this.strProductCode = strProductCode;
	}
	public String getStrPolicyNo() {
		return strPolicyNo;
	}
	public void setStrPolicyNo(String strPolicyNo) {
		this.strPolicyNo = strPolicyNo;
	}
	public String getStrPolicyInspectionDate() {
		return strPolicyInspectionDate;
	}
	public void setStrPolicyInspectionDate(String strPolicyInspectionDate) {
		this.strPolicyInspectionDate = strPolicyInspectionDate;
	}
	public String getStrDOB() {
		return strDOB;
	}
	public void setStrDOB(String strDOB) {
		this.strDOB = strDOB;
	}
	public String getStrMobileNo() {
		return strMobileNo;
	}
	public void setStrMobileNo(String strMobileNo) {
		this.strMobileNo = strMobileNo;
	}
	public String getStrAddOn() {
		return strAddOn;
	}
	public void setStrAddOn(String strAddOn) {
		this.strAddOn = strAddOn;
	}	
	
}

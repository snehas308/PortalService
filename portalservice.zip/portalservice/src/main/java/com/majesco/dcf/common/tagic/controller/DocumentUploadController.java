package com.majesco.dcf.common.tagic.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.majesco.dcf.common.chp.usermgmt.util.OAuth2Constants;
import com.majesco.dcf.common.tagic.json.PortalLockDetails;
import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.docmgmt.json.CustDocUploadLinkReq;
import com.majesco.dcf.docmgmt.json.CustDocUploadLinkRes;
import com.majesco.dcf.docmgmt.json.DocSourceOptionReq;
import com.majesco.dcf.docmgmt.json.DocUploadDtlsObj;
import com.majesco.dcf.docmgmt.json.DocUploadDtlsRequest;
import com.majesco.dcf.docmgmt.json.DocUploadDtlsResponse;
import com.majesco.dcf.docmgmt.json.DocUploadOptionReq;
import com.majesco.dcf.docmgmt.json.DocUploadOptnResponse;
import com.majesco.dcf.docmgmt.json.DocUploadSearchObj;
import com.majesco.dcf.docmgmt.json.DocUploadSearchResponse;
import com.majesco.dcf.docmgmt.json.MultiUploadModel;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsReq;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsRes;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsSearchReq;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsSearchRes;
import com.majesco.dcf.docmgmt.json.QCDecisionRequest;
import com.majesco.dcf.docmgmt.json.QCDecisionResponse;
import com.majesco.dcf.docmgmt.json.QCInspectionRequest;
import com.majesco.dcf.docmgmt.json.QCInspectionResponse;
import com.majesco.dcf.docmgmt.json.UploadModel;
import com.majesco.dcf.docmgmt.service.DocUploadDtlsService;
import com.majesco.dcf.usermgmt.json.UserCredentials;


/**
 * @author yogesh570158
 *
 */
@RestController
@RequestMapping(value="/documentservice")
public class DocumentUploadController {
	
	@Autowired
	 ServletContext context;
	
	@Value("${docUploadPath}")
	private String UPLOADED_FOLDER;
	//private String docFilePath;
	
	@Autowired
	DocUploadDtlsService docUploadDtlsService;
	
	@Value("${default.userid.spl}")
	private String defaultSPLUseerId;
	
	@Value("${default.password.spl}")
	private String defaultSPLPassword;
	
	@Value("${usgmgt.url}")
	private String usermgtBaseURL;
	
	final static Logger logger = Logger.getLogger(DocumentUploadController.class);
	private static String _strClassName="DocumentUploadController";
	 //public ResponseEntity<?> uploadFile(@RequestParam("propNo") String propNo, @RequestParam("docMapId") String docMapId, @RequestParam("createdBy") String createdBy, @RequestParam("file") MultipartFile uploadfile) {  
		//Start:<YogeshM>:<18/12/2017>:<SIT>:<DefectID-0001305>:<to save single files Upload>
	  
		
	
	
	 @RequestMapping(value="/upload/", method = RequestMethod.POST)
	 //public ResponseEntity<?> uploadFile(@RequestParam("propNo") String propNo, @RequestParam("docMapId") String docMapId, @RequestParam("files") MultipartFile uploadfile) {
	     public ResponseEntity<?> uploadFile(@ModelAttribute UploadModel model) {
	    	
	  	if(logger.isDebugEnabled())logger.debug("DocumentUploadController.uploadFile() :: Single file upload!");
	    	
	    	DocUploadDtlsObj docUploadDtlsObj = new DocUploadDtlsObj();
	    	ObjectMapper objMap = new ObjectMapper(); 
	
	        if (model.getFiles().length==0) {
	            return new ResponseEntity(CommonConstants.RESP_HTTPSTATUS_422_FILES, HttpStatus.UNPROCESSABLE_ENTITY);
	        }
	        if (model.getPropNo().isEmpty()){
	        	return new ResponseEntity(CommonConstants.RESP_HTTPSTATUS_422_PROPNO, HttpStatus.UNPROCESSABLE_ENTITY);
	        }
	        if (model.getDocMapId().isEmpty()){
	        	return new ResponseEntity(CommonConstants.RESP_HTTPSTATUS_422_DOCMAPID, HttpStatus.UNPROCESSABLE_ENTITY);
	        }
	        if (model.getUserId().isEmpty()){
	        	return new ResponseEntity(CommonConstants.RESP_HTTPSTATUS_422_USERID, HttpStatus.UNPROCESSABLE_ENTITY);
	        }
	
	        try {
	        	//logger.info("DocumentUploadController.uploadFile() :: UploadModel getting from UI:- "+objMap.writeValueAsString(model));
	        	
	        	boolean isSave = false;
	        	
	            //saveUploadedFiles(Arrays.asList(uploadfile));
	        	//if (!uploadfile.isEmpty() && !propNo.isEmpty()) {
	        		docUploadDtlsObj = new DocUploadDtlsObj();
	        		docUploadDtlsObj.setProposalNo(model.getPropNo() == null ? "": model.getPropNo());
	        		docUploadDtlsObj.setDocmodMapId(model.getDocMapId() == null ? "": model.getDocMapId());
	        		docUploadDtlsObj.setCreatedBy((model.getUserId() == null ? "": model.getUserId()));
	        		docUploadDtlsObj.setFiles(Arrays.asList(model.getFiles()));
	        			        	
	        		//logger.info("DocumentUploadController.uploadFile() :: docUploadDtlsObj:-"+objMap.writeValueAsString(docUploadDtlsObj));
	        		isSave = docUploadDtlsService.saveUploadedFiles(docUploadDtlsObj);
	        		
	        		logger.info("DocumentUploadController.uploadFile() :: isSave:-"+isSave);
	        		if (isSave=false){
	        			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	        		}
	        	//}
	
	        //} catch (IOException e) {
	        //    return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	        } catch (Exception e) {
	        	logger.error("DocumentUploadController.uploadFile() :: Exception Occured:- ", e);
	        	//return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	        	return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	
	        //return new ResponseEntity("Successfully uploaded - " + uploadfile.getOriginalFilename(), new HttpHeaders(), HttpStatus.OK);
	        return new ResponseEntity(CommonConstants.RESP_HTTPSTATUS_OK, HttpStatus.OK);
	
	    }
	  //End:<YogeshM>:<18/12/2017>:<SIT>:<DefectID-0001305>:<to save single files Upload>
	    
	    /*
		 * Start:<KetanM>:<20/11/2017><DefectID-0001305>
		 * to provide data for UI for QC Inspection
		 * 
		 * */
	    @RequestMapping(value="/fetchDataForQCInspection/", method = RequestMethod.POST)
		@ResponseBody
		public QCInspectionResponse getDataForQCInspection(@RequestBody QCInspectionRequest qcInspectionRequest, HttpServletRequest httpServletRequest) throws Exception{
	    	QCInspectionResponse qcInspectionResponse=null;
			String strMethodName="getDataForQCInspection";
			try
			{
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
				
				qcInspectionResponse=docUploadDtlsService.getDataForQCInspection(qcInspectionRequest);
				
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
				
			}catch(Exception ex){
				logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
				qcInspectionResponse=new QCInspectionResponse();
				qcInspectionResponse.setErrorCode(CommonConstants.FAILURE_STATUS);
				qcInspectionResponse.setErrorMMessag(CommonConstants.EXPERIENCING_ISSUE);
			}
			return qcInspectionResponse;
		}
	  //End:<KetanM>:<20/12/2017><DefectID-0001305>
	  //Start:<VishalJ>:<21/11/2017><DefectID-0001305>
	    @RequestMapping(value="/getUploadDocSearch/", method = RequestMethod.POST)
		@ResponseBody
		public DocUploadSearchResponse getUploadDocSearch(@RequestBody DocUploadSearchObj docSearchDtls, HttpServletRequest httpServletRequest) throws Exception{
	    	DocUploadSearchResponse docUploadSearchResponse=null;
			String strMethodName="getUploadDocSearch";
			ObjectMapper objMap = new ObjectMapper();
			try
			{
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
				logger.info("Inside "+_strClassName+"::"+strMethodName+":: UI JSON Request: " + objMap.writeValueAsString(docSearchDtls));
				
				if(docSearchDtls.getSearchFlag()!=null && docSearchDtls.getSearchFlag().equalsIgnoreCase("R"))
				{
					docUploadSearchResponse=docUploadDtlsService.getUploadRejDocSearch(docSearchDtls);
				}
				//Start:<YogeshM>:<14/03/2018>:<SIT>:<DefectID-0001305>:<To get docUpload Pending Status>
				/*else if(docSearchDtls.getSearchFlag()!=null && docSearchDtls.getSearchFlag().equalsIgnoreCase("P"))
				{
					docUploadSearchResponse=docUploadDtlsService.getUploadDocSearch(docSearchDtls);
				}*/
				//End:<YogeshM>:<14/03/2018>:<SIT>:<DefectID-0001305>:<To get docUpload Pending Status>
				else 
				{
					docUploadSearchResponse=docUploadDtlsService.getUploadDocSearch(docSearchDtls);
				}
				
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
				
			}catch(Exception ex){
				logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
				docUploadSearchResponse=new DocUploadSearchResponse();
				docUploadSearchResponse.setErrorCode(CommonConstants.FAILURE_STATUS);
				docUploadSearchResponse.setErrorMMessag(CommonConstants.EXPERIENCING_ISSUE);
			}
			return docUploadSearchResponse;
		}
	  //End:<VishalJ>:<21/11/2017><DefectID-0001305>
	    
	    /*
		 * Start:<KetanM>:<20/11/2017><DefectID-0001305>
		 * to update data through UI for QC Inspection
		 * 
		 * */
	    @RequestMapping(value="/updateDataForQCInspection/", method = RequestMethod.POST)
		@ResponseBody
		public QCDecisionResponse updateDataForQCInspection(@RequestBody QCDecisionRequest qcDecisionRequest, HttpServletRequest httpServletRequest) throws Exception{
	    	QCDecisionResponse qcDecisionResponse=null;
			String strMethodName="updateDataForQCInspection";
			try
			{
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
				
				qcDecisionResponse=docUploadDtlsService.updateDataForQCInspection(qcDecisionRequest);
				
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
				
			}catch(Exception ex){
				logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
				qcDecisionResponse=new QCDecisionResponse();
				qcDecisionResponse.setErrorCode(CommonConstants.FAILURE_STATUS);
				qcDecisionResponse.setErrorMMessag(CommonConstants.EXPERIENCING_ISSUE);
			}
			return qcDecisionResponse;
		}
	  //End:<KetanM>:<20/12/2017><DefectID-0001305>
	    
	    
		  //Start:<VishalJ>:<21/11/2017><DefectID-0001305>
	    @RequestMapping(value="/saveDocUploadOptn/", method = RequestMethod.POST)
		@ResponseBody
		public ResponseEntity saveDocUploadOptn(@RequestBody DocUploadOptionReq docUploadOptnReq, HttpServletRequest httpServletRequest) throws Exception{
	    	DocUploadOptnResponse docUploadOptnRes=null;
			String strMethodName="saveDocUploadOptn";
			ResponseEntity resEntity = null;
			DocUploadDtlsResponse result=null;
			try
			{
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
				
				docUploadOptnRes=docUploadDtlsService.saveDocUploadOptn(docUploadOptnReq);
				DocUploadDtlsRequest request=new DocUploadDtlsRequest();
				resEntity = new ResponseEntity("Success!", HttpStatus.OK);
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
				
			}catch(Exception ex){
				logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
				docUploadOptnRes=new DocUploadOptnResponse();
				docUploadOptnRes.setErrorCode(CommonConstants.FAILURE_STATUS);
				docUploadOptnRes.setErrorMMessag(CommonConstants.EXPERIENCING_ISSUE);
				resEntity = new ResponseEntity("Failure!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return resEntity;
		}
	  //End:<VishalJ>:<21/11/2017><DefectID-0001305>
	    
	    /*
		 * Start:<KetanM>:<23/11/2017><DefectID-0001305>
		 * to download the document for QC Inspection
		 * 
		 * */
	    @RequestMapping(value="/download/{seqID}", method = RequestMethod.GET)
		public void getRequestedDocumentGet(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@PathVariable String seqID) throws Exception
	    {
	    	String strMethodName="getRequestedDocumentGet";
	    	logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			ObjectMapper objMap = new ObjectMapper();
			QCInspectionRequest qcInspectionRequest = new QCInspectionRequest();
			//httpServletRequest.getParameterNames();
			if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+" :: "+strMethodName+" method :: Request Object seqID--> "+seqID);
			
			qcInspectionRequest.setSeqID(seqID);
			//if(logger.isDebugEnabled())logger.debug("Inside CommonServiceController :: getRequestedDocument method :: Request Object--> "+objMap.writeValueAsString(qcInspectionRequest));
			
			docUploadDtlsService.getRequestedDocument(qcInspectionRequest, httpServletResponse);
			
			logger.info("Inside "+_strClassName+" :: "+strMethodName+" method :: Execution Ended");
		}
	  //End:<KetanM>:<23/12/2017><DefectID-0001305>
	    
	  //Start:<YogeshM>:<23/12/2017>:<SIT>:<DefectID-0001305>:<to save multiple files Upload>
	    @SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "/multiUpload", method = RequestMethod.POST)
	    public ResponseEntity<?> multiUploadFile(@ModelAttribute MultiUploadModel model) {
	
	    	if(logger.isDebugEnabled())logger.debug("DocumentUploadController.uploadFile() :: Single file upload!");
	    	
	    	DocUploadDtlsRequest docUploadDtlsRequest = new DocUploadDtlsRequest();
	    	DocUploadDtlsObj docUploadDtlsObj = new DocUploadDtlsObj();
	    	ObjectMapper objMap = new ObjectMapper(); 
	    	
	    	if (model.getUploadModelLst()!=null)
	    	{	
	    		for (int i = 0; i < model.getUploadModelLst().size(); i++) {
					
	    			if (model.getUploadModelLst().get(i).getFiles().length==0) {
	    	            return new ResponseEntity(CommonConstants.RESP_HTTPSTATUS_422_FILES, HttpStatus.UNPROCESSABLE_ENTITY);
	    	        }
	    	        if (model.getUploadModelLst().get(i).getPropNo().isEmpty()){
	    	        	return new ResponseEntity(CommonConstants.RESP_HTTPSTATUS_422_PROPNO, HttpStatus.UNPROCESSABLE_ENTITY);
	    	        }
	    	        if (model.getUploadModelLst().get(i).getDocMapId().isEmpty()){
	    	        	return new ResponseEntity(CommonConstants.RESP_HTTPSTATUS_422_DOCMAPID, HttpStatus.UNPROCESSABLE_ENTITY);
	    	        }
	    	        if (model.getUploadModelLst().get(i).getUserId().isEmpty()){
	    	        	return new ResponseEntity(CommonConstants.RESP_HTTPSTATUS_422_USERID, HttpStatus.UNPROCESSABLE_ENTITY);
	    	        }
	    	        
	    	        try {
	    	        	boolean isSave = false;
	    	        	
	    	            //saveUploadedFiles(Arrays.asList(uploadfile));
	    	        	//if (!uploadfile.isEmpty() && !propNo.isEmpty()) {
	    	        		docUploadDtlsObj = new DocUploadDtlsObj();
	    	        		docUploadDtlsObj.setProposalNo(model.getUploadModelLst().get(i).getPropNo() == null ? "": model.getUploadModelLst().get(i).getPropNo());
	    	        		docUploadDtlsObj.setDocmodMapId(model.getUploadModelLst().get(i).getDocMapId() == null ? "": model.getUploadModelLst().get(i).getDocMapId());
	    	        		docUploadDtlsObj.setCreatedBy((model.getUploadModelLst().get(i).getUserId() == null ? "": model.getUploadModelLst().get(i).getUserId()));
	    	        		docUploadDtlsObj.setFiles(Arrays.asList(model.getUploadModelLst().get(i).getFiles()));
	    	        			        	
	    	        		//logger.info("DocumentUploadController.uploadFile() :: docUploadDtlsObj:-"+objMap.writeValueAsString(docUploadDtlsObj));
	    	        		isSave = docUploadDtlsService.saveUploadedFiles(docUploadDtlsObj);
	    	        		
	    	        		logger.info("DocumentUploadController.uploadFile() :: isSave:-"+isSave);
	    	        		if (isSave=false){
	    	        			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    	        		}
	    	        	//}
	    	
	    	        } catch (Exception e) {
	    	        	logger.error("DocumentUploadController.uploadFile() :: Exception Occured:- ", e);
	    	        	return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	    	        }
	    	        
				}
	    	}
	        return new ResponseEntity(CommonConstants.RESP_HTTPSTATUS_OK, HttpStatus.OK);
	    }
	  //End:<YogeshM>:<23/12/2017>:<SIT>:<DefectID-0001305>:<to save multiple files Upload>

	
	    /*
		 * Start:<KetanM>:<23/11/2017><DefectID-0001305>
		 * to check whether is there lock exist for logged in User
		 * 
		 * */
	    @SuppressWarnings({ "rawtypes", "unchecked" })
		@RequestMapping(value="/portalLockForDocument/", method = RequestMethod.POST)
		@ResponseBody
		public ResponseEntity<String> portalLockForDocument(@RequestBody String strRequestJson, HttpServletRequest httpServletRequest) throws Exception{
			String strMethodName = "portalLockForDocument";
			Gson gson = new Gson();
			HttpHeaders responseHeaders =  new HttpHeaders();
			String result="Success";
			try{
				UserObject request = gson.fromJson(strRequestJson, UserObject.class);
				
				if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING))
					request.setAuthToken(httpServletRequest.getHeader("gc_token"));
				
				StopWatch watch = new StopWatch();
				watch.start();
				PortalLockDetails portalLockDetails = docUploadDtlsService.portalLockForDocument(request);
				watch.stop();
				if(logger.isDebugEnabled())logger.info("Time Taken by "+_strClassName+" --> "+strMethodName+" service in seconds..>>"+watch.getTotalTimeSeconds());
				if(portalLockDetails!=null && portalLockDetails.isPortalLock()){
					return new ResponseEntity(portalLockDetails,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
				}else{
					return new ResponseEntity(portalLockDetails,responseHeaders,HttpStatus.OK);
				}
				
			}catch(Exception ex){
				logger.error("Inside +_strClassName+ :: "+strMethodName+" method ::", ex);
				return new ResponseEntity(ex.getMessage(),responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	  //End:<KetanM>:<23/12/2017><DefectID-0001305>

	    /**
	     * 
	     */
	    
		  //Start:<VishalJ>:<21/11/2017><DefectID-0001305> : <To send Customer Document Upload Link>
	    @RequestMapping(value="/custDocUploadLink/", method = RequestMethod.POST)
		@ResponseBody
		public ResponseEntity sendCustDocUploadLink(@RequestBody CustDocUploadLinkReq custDocUploadLinkReq, HttpServletRequest httpServletRequest) throws Exception{
	    	CustDocUploadLinkRes custDocUploadLinkRes=null;
			String strMethodName="sendCustDocUploadLink";
			ResponseEntity resEntity = null;
			try
			{
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
				
				custDocUploadLinkRes=docUploadDtlsService.sendCustDocUploadLink(custDocUploadLinkReq);
				
				resEntity = new ResponseEntity("Success!", HttpStatus.OK);
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
				
			}catch(Exception ex){
				logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
				custDocUploadLinkRes=new CustDocUploadLinkRes();
				custDocUploadLinkRes.setErrorCode(CommonConstants.FAILURE_STATUS);
				custDocUploadLinkRes.setErrorMMessag(CommonConstants.EXPERIENCING_ISSUE);
				resEntity = new ResponseEntity("Failure!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return resEntity;
		}
	  //End:<VishalJ>:<21/11/2017><DefectID-0001305><To send Customer Document Link>
	    
	    
	 // This service generates self payment link URL 
		@SuppressWarnings("unchecked")
		@RequestMapping(value = "/custdocupload/{transID}", method = RequestMethod.GET)
		//Start:<YogeshM>:<11/01/2018>:<SIT>:<DefectID-0001305>:<uploadLinkURL controller return type change with ModelAndView>
		public ModelAndView uploadLinkURL(Locale locale, Model model, @PathVariable String transID, HttpServletRequest httpServletRequest) {
		//End:<YogeshM>:<11/01/2018>:<SIT>:<DefectID-0001305>:<uploadLinkURL controller return type change with ModelAndView>
			Map<String, String> mapVal = null;
			ObjectMapper objMapper = new ObjectMapper();
			UserCredentials userCredObj= new UserCredentials();
			Gson gson = new Gson();
			HttpHeaders headers = new HttpHeaders();
			ModelAndView modelView = null;
			try {
				mapVal = docUploadDtlsService.getUploadDocDetails(transID);
				
				modelView = new ModelAndView(CommonConstants.CUST_DOC_UPLOAD_PAGE);	 //<YogeshM>:<11/01/2018>:<SIT>:<DefectID-0001305>:<uploadLinkURL controller return type change with ModelAndView>
							
				//Start: RahulT< 1908> | code added to get refresh token for SPL user 
				JSONObject jsonObject = new JSONObject(); 
				jsonObject.put("userId", defaultSPLUseerId);
				jsonObject.put("password", defaultSPLPassword);
				jsonObject.put("username", defaultSPLUseerId);
				
				userCredObj.setUserId(defaultSPLUseerId);
				userCredObj.setPassword(defaultSPLPassword);
				userCredObj.setUsername(defaultSPLUseerId);
				//String userCredJson = gson.toJson(userCredObj);
				String userCredJson = jsonObject.toJSONString();
				headers.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<String> entity = new HttpEntity<String>(userCredJson, headers);
				
				logger.debug("Inside DocumentUploadController. uploadLinkURL method:: USER OBJECT FOR CustUploadLink toJSONString --> "+objMapper.writeValueAsString(userCredJson));
				logger.debug("Inside DocumentUploadController. uploadLinkURL method:: USER OBJECT FOR CustUploadLink toString()--> "+objMapper.writeValueAsString(jsonObject.toString()));
				
				logger.debug("Inside DocumentUploadController .uploadLinkURL method:: USER OBJECT FOR CustUploadLink --> "+objMapper.writeValueAsString(jsonObject));
				
				String url =usermgtBaseURL+"/sec/login/";
				RestTemplate restTemplate = new RestTemplate();
				ResponseEntity<String> loginResponse = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
				
				logger.debug("Inside DocumentUploadController .uploadLinkURL method:: Login Response -->"+loginResponse);
				
				headers = loginResponse.getHeaders();
				Set<String> keys = headers.keySet();
				
				for (String header : keys) {
					List<String> values = headers.get(header);
					if(header.equals(OAuth2Constants.REFRESH_TOKEN)){
						for (String value : values) {						
							mapVal.put(OAuth2Constants.REFRESH_TOKEN, value);
							logger.debug("Inside DocumentUploadController .uploadLinkURL method:: Token Value -->"+value);
						}
					}
				}
				//End: RahulT< 1908> | code added to get refresh token for SPL user
				
				//System.out.println("final value in result Map "+objMapper.writeValueAsString(mapVal));
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			model.addAttribute("customerName", mapVal.get("customerName"));
			model.addAttribute("proposalNo", mapVal.get("proposalNo"));
			model.addAttribute("transAmt", mapVal.get("transAmt"));	
			model.addAttribute("transID", transID);
			model.addAttribute("custName", mapVal.get("custName"));
			model.addAttribute("isError", mapVal.get("isError"));
			model.addAttribute("messageDisplay", mapVal.get("messageDisplay"));
			
			model.addAttribute("productCd", mapVal.get("productCd"));
			model.addAttribute("agentCode", mapVal.get("agentCode"));
			model.addAttribute("agentName", mapVal.get("agentName"));
			model.addAttribute("productName", mapVal.get("productName"));
			model.addAttribute("planName", mapVal.get("planName"));
			model.addAttribute("vehRegNo", mapVal.get("vehRegNo"));
			model.addAttribute("lobNo", mapVal.get("lobNo"));
			model.addAttribute("documentChecklist", mapVal.get("documentChecklist"));
			model.addAttribute(OAuth2Constants.REFRESH_TOKEN, mapVal.get(OAuth2Constants.REFRESH_TOKEN));	//RahulT< 1908>
			try {
				logger.debug("Inside DocumentUploadController Exiting Model Object "+objMapper.writeValueAsString(model));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				logger.error("Inside DocumentUploadController Exception",e);
			}
			//return CommonConstants.CUST_DOC_UPLOAD_PAGE;
			return modelView; //<YogeshM>:<11/01/2018>:<SIT>:<DefectID-0001305>:<uploadLinkURL controller return type change with ModelAndView>
		}
		
		// End : <1305> : VishalJ : Controller method to Return Customer Upload Link Page

		  //Start:<VishalJ>:<01/01/2018><DefectID-0001305>  :- To save Producer Locking details to give option to manipulate Document Upload option Producer wise.
	    @RequestMapping(value="/saveProducerLockDtls/", method = RequestMethod.POST)
		@ResponseBody
		public ResponseEntity saveProducerLockDtls(@RequestBody ProducerLockDtlsReq producerLockDtlsReq, HttpServletRequest httpServletRequest) throws Exception{
	    	ProducerLockDtlsRes producerLockDtlsRes=null;
			String strMethodName="saveProducerLockDtls";
			ResponseEntity resEntity = null;
			try
			{
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
				
				producerLockDtlsRes=docUploadDtlsService.saveProducerLockDtls(producerLockDtlsReq);
				
				resEntity = new ResponseEntity("Success!", HttpStatus.OK);
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
				
			}catch(Exception ex){
				logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
				producerLockDtlsRes=new ProducerLockDtlsRes();
				producerLockDtlsRes.setErrorCode(CommonConstants.FAILURE_STATUS);
				producerLockDtlsRes.setErrorMMessag(CommonConstants.EXPERIENCING_ISSUE);
				resEntity = new ResponseEntity("Failure!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return resEntity;
		}
	  //End:<VishalJ>:<21/11/2017><DefectID-0001305><To save Producer Locking details to give option to manipulate Document Upload option Producer wise.>
	    
	    //Start:<VishalJ>:<01/01/2018><DefectID-0001305>  :- To search Producer Lock Details for modification
	    @RequestMapping(value="/searchProdLockDtls/", method = RequestMethod.POST)
		@ResponseBody
		public ResponseEntity searchProdLockDtls(@RequestBody ProducerLockDtlsSearchReq producerLockDtlsSearchReq, HttpServletRequest httpServletRequest) throws Exception{
	    	ProducerLockDtlsSearchRes producerLockDtlsSearchRes=null;
	    	String result=null;
			String strMethodName="saveProducerLockDtls";
			Gson gson = new Gson();
			ResponseEntity resEntity = null;
			try
			{
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
				
				producerLockDtlsSearchRes=docUploadDtlsService.searchProdLockDtls(producerLockDtlsSearchReq);
				result=gson.toJson(producerLockDtlsSearchRes);	
				resEntity = new ResponseEntity(result, HttpStatus.OK);
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
				
			}catch(Exception ex){
				logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
				producerLockDtlsSearchRes=new ProducerLockDtlsSearchRes();
				producerLockDtlsSearchRes.setErrorCode(CommonConstants.FAILURE_STATUS);
				producerLockDtlsSearchRes.setErrorMMessag(CommonConstants.EXPERIENCING_ISSUE);
				resEntity = new ResponseEntity("Failure!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return resEntity;
		}
	  //End:<VishalJ>:<21/11/2017><DefectID-0001305><To search Producer Lock Details for modification>
	    //Start:<VishalJ>:<21/11/2017><DefectID-0001305>
	    @RequestMapping(value="/saveDocSourceOptn/", method = RequestMethod.POST)
		@ResponseBody
		public ResponseEntity saveDocSourceOptn(@RequestBody DocSourceOptionReq docSourceOptnReq, HttpServletRequest httpServletRequest) throws Exception{
	    	DocUploadOptnResponse docUploadOptnRes=null;
			String strMethodName="saveDocSourceOptn";
			ResponseEntity resEntity = null;
			try
			{
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
				
				docUploadOptnRes=docUploadDtlsService.saveSourceOptn(docSourceOptnReq);
				
				resEntity = new ResponseEntity("Success!", HttpStatus.OK);
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
				
			}catch(Exception ex){
				logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
				docUploadOptnRes=new DocUploadOptnResponse();
				docUploadOptnRes.setErrorCode(CommonConstants.FAILURE_STATUS);
				docUploadOptnRes.setErrorMMessag(CommonConstants.EXPERIENCING_ISSUE);
				resEntity = new ResponseEntity("Failure!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return resEntity;
		}
	  //End:<VishalJ>:<21/11/2017><DefectID-0001305>
}

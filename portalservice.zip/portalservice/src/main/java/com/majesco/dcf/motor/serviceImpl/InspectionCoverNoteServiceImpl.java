package com.majesco.dcf.motor.serviceImpl;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.majesco.dcf.common.chp.dozer.DozerMapUtil;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.service.AuthenticationService;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.motor.json.InspectionRequest;
import com.majesco.dcf.motor.json.InspectionResponse;
import com.majesco.dcf.motor.service.InspectionCoverNoteService;
import com.unotechsoft.stub.inspectionservice.client.ArrayOfKeyValueOfstringstring;
import com.unotechsoft.stub.inspectionservice.client.ArrayOfstring;
import com.unotechsoft.stub.inspectionservice.client.ClsUserData_InspDtls;
import com.unotechsoft.stub.inspectionservice.client.UWServiceResult;
import com.unotechsoft.stub.inspectionservice.client.VehicleInspction;
import com.unotechsoft.stub.inspectionservice.client.VehicleInspction_Service;

@Service
@Transactional
public class InspectionCoverNoteServiceImpl implements
InspectionCoverNoteService {

	final static Logger logger = Logger.getLogger(InspectionCoverNoteServiceImpl.class);
	
	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/

	@Autowired
	AuthenticationService authServ;

	@Autowired
	DBService dbserv;

	private String _strClassName="InspectionCoverNoteServiceImpl";
	private static String inspectionServiceUrl=null;

	@Override
	public InspectionResponse triggerPreInspection(
			InspectionRequest inspectionRequest) throws Exception {
		// TODO Auto-generated method stub
		InspectionResponse response=new InspectionResponse();
		String strMethodName="triggerPreInspection";
		ObjectMapper objMap=new ObjectMapper();
		String source=smc_source;
		String campaign=smc_medium;
		String medium=smc_campaign;
		String authToken=null;
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			logger.info("Inside "+_strClassName+"::"+strMethodName+":: Request ::"+objMap.writeValueAsString(inspectionRequest));

			if(inspectionServiceUrl==null || inspectionServiceUrl.equalsIgnoreCase("")){
				inspectionServiceUrl=dbserv.getWSDLURL(CommonConstants.PRE_INSPECTION_SERVICE, CommonConstants.InterfaceParam_Entity);
			}
			DozerMapUtil dozerUtil=new DozerMapUtil();
			/*ClsUserData_InspDtls inspectionServiceReq=new ClsUserData_InspDtls();
			dozerUtil.transformObject(inspectionRequest, inspectionServiceReq, "PreInspection", "MotorMapping.xml");
			GenConfStubService_Service service=new GenConfStubService_Service(new URL(inspectionServiceUrl));
			GenConfStubService stubService=service.getSOAPOverHTTP();*/
			
			ClsUserData_InspDtls inspectionServiceReq=new ClsUserData_InspDtls();
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Workflow ID before::"+inspectionRequest.getWorkFlowId());
			dozerUtil.transformObject(inspectionRequest, inspectionServiceReq, "PreInspection", "MotorMapping.xml");
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Workflow ID::"+inspectionRequest.getWorkFlowId());
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Workflow ID after dozer::"+inspectionServiceReq.getWorkFlowId());
			inspectionServiceReq=defaultFields(inspectionServiceReq, inspectionRequest);
			VehicleInspction_Service service=new VehicleInspction_Service(new URL(inspectionServiceUrl));
			VehicleInspction stubService=service.getSOAPOverHTTP();

			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(stubService);

			if(inspectionRequest!=null && inspectionRequest.getAuthToken()!=null && !inspectionRequest.getAuthToken().equalsIgnoreCase(""))
				authToken=inspectionRequest.getAuthToken();
			
			authToken = authToken==null?"":authToken; //Added By Ketan On 09/11/2016 
			ArrayOfKeyValueOfstringstring dicLVWFParams = new ArrayOfKeyValueOfstringstring(); //Added By Ketan On 10/11/2016 
//Defaulting Vehicle inspection fields.
			//inspectionServiceReq=defaultFields(inspectionServiceReq, inspectionRequest);
			
			inspectionServiceReq.setUserRole("ADMIN"); // HardCoded to ADMIN
			
			StopWatch watch = new StopWatch();
			watch.start();
			UWServiceResult serviceResult=stubService.saveInspectionDetails(source, medium, campaign, authToken, inspectionServiceReq, dicLVWFParams);
			watch.stop();
			logger.info("Time Taken by saveInspectionDetails service in seconds..>>"+watch.getTotalTimeSeconds());
			if(serviceResult!=null){
				if(serviceResult.getErrorText()!=null && !serviceResult.getErrorText().equalsIgnoreCase("")){
					response.setResultCode(CommonConstants.FAILURE_STATUS);
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError error=new ResponseError();
					error.setErrorCode(serviceResult.getErrorText());
					error.setErrorMMessag(serviceResult.getErrorText()); // Error text / message from GC
					errorList.add(error);
					response.setResponseError(errorList);
				}else{

					// Response object population for successful service call to be done later. Pending
					response.setResultCode(CommonConstants.SUCCESS_STATUS);
				}
			}

		}catch(Exception ex){
			logger.error("Inside "+_strClassName+"::"+strMethodName+":: Exception ::", ex);
			response.setResultCode(CommonConstants.FAILURE_STATUS);
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError error=new ResponseError();
			error.setErrorCode(ex.getMessage());
			error.setErrorMMessag(ex.getMessage()); // Need to change error description
			errorList.add(error);
			response.setResponseError(errorList);
		}
		logger.info("Inside "+_strClassName+"::"+strMethodName+":: Response ::"+objMap.writeValueAsString(response));
		logger.info("Inside "+_strClassName+"::"+strMethodName+":: Exit");
		return response;
	}

	@Override
	public InspectionResponse triggerCoverNote(
			InspectionRequest inspectionRequest) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	private ClsUserData_InspDtls defaultFields(ClsUserData_InspDtls inspectionServiceReq,InspectionRequest inspectionRequest){
		
		if(inspectionServiceReq!=null){
			logger.info("Inside "+_strClassName+"::defaultFields:: Entered");
			Date today=new Date();
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy", Locale.US);
			
			inspectionServiceReq.setChannelId(CommonConstants.DEFAULT_ZERO_VALUE);
			inspectionServiceReq.setDeptNo("31");
			inspectionServiceReq.setEndDate(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setEndorsementDate(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setEndorsementTypeCode(CommonConstants.DEFAULT_ZERO_VALUE);
			inspectionServiceReq.setErrorText(CommonConstants.BLANK_STRING); //Added By Ketan On 09 Nov 2016
			inspectionServiceReq.setInsertDate(sdf.format(today));
			inspectionServiceReq.setInsertTransId(CommonConstants.DEFAULT_ZERO_VALUE);
			inspectionServiceReq.setInspectionAgencyCode(""); // To be derived from Inspection agency master
			inspectionServiceReq.setInspectionAgencyName(inspectionRequest.getLstPreInspResDet().getNameOfInspectAgency()); // From input field to be added in UI.
			inspectionServiceReq.setInspectionRequestDate(inspectionRequest.getLstPreInspResDet().getInspDt()); // From input field to be added in UI.
			inspectionServiceReq.setInspectionRequestTime(inspectionRequest.getLstPreInspResDet().getInspTime()); // From input field to be added in UI.
			inspectionServiceReq.setID(CommonConstants.BLANK_STRING); //Added By Ketan On 09 Nov 2016
			inspectionServiceReq.setMailPassword(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setMailPort(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setMailSender(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setMailServer(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setMarketingOfficerCode(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setMarketingOfficerName(CommonConstants.BLANK_STRING);
			//inspectionServiceReq.setModeOfOperation(inspectionRequest.getModeOfOperation()); //Commented By Ketan On 09 Nov 2016
			inspectionServiceReq.setModeOfOperation("NEWPOLICY"); //Added By Ketan On 09 Nov 2016
			inspectionServiceReq.setModifyDate(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setModifyTransId(CommonConstants.DEFAULT_ZERO_VALUE);
			inspectionServiceReq.setName(CommonConstants.BLANK_STRING);
			if(inspectionRequest!=null && inspectionRequest.getLstPreInspResDet()!=null)
				inspectionServiceReq.setOdometerReading(inspectionRequest.getLstPreInspResDet().getOdometerRead()==null?"":inspectionRequest.getLstPreInspResDet().getOdometerRead());
			inspectionServiceReq.setPolicyNO(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setReceiptMailID(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setRefDate(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setRegdNo(CommonConstants.DEFAULT_ZERO_VALUE);
			inspectionServiceReq.setRiskStartDate(inspectionRequest.getLstRiskdet().getPolIncpnDt());
			inspectionServiceReq.setRiskEndDate(inspectionRequest.getLstRiskdet().getPolExpDt());
			inspectionServiceReq.setRowCount(CommonConstants.DEFAULT_ZERO_VALUE); 	//Added By Ketan On 09 Nov 2016
			inspectionServiceReq.setSenderMailId(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setStartDate(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setStartTime(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setSubject(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setUploadedFileName(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setUserId(inspectionRequest.getUserID());
			inspectionServiceReq.setUserRole(inspectionRequest.getUserRole()); // Currently hard coded, need to change as input from UserObject
			// Addded by Vishal Start : 23/02/2017
			inspectionServiceReq.setRetSqlQuery(CommonConstants.BLANK_STRING);  
			inspectionServiceReq.setInspectionAgencyName(inspectionRequest.getLstPreInspResDet().getNameOfInspectAgency()==null?"":inspectionRequest.getLstPreInspResDet().getNameOfInspectAgency()); 					
			ArrayOfstring arrInspAuth = new ArrayOfstring();			
			ArrayOfstring arrInspStatus = new ArrayOfstring();
			inspectionServiceReq.setInspectionAuthority(arrInspAuth);  
			inspectionServiceReq.setInspectionStatus(arrInspStatus);  
			// Addded by Vishal End 23/02/2017
			
			
			
			String strWorkFlowID=inspectionRequest.getWorkFlowId();
			logger.info("Inside "+_strClassName+"::defaultFields:: strWorkFlowID::"+strWorkFlowID);
			if(strWorkFlowID!=null && !strWorkFlowID.equalsIgnoreCase("")){
				
				if(!strWorkFlowID.startsWith("W")){
					strWorkFlowID=CommonConstants.WORKFLOWID_STARTWITH+strWorkFlowID;
					logger.info("Inside "+_strClassName+"::defaultFields:: strWorkFlowID::"+strWorkFlowID);
				}
			}
			//inspectionServiceReq.setWorkFlowId(inspectionRequest.getWorkFlowId());
			inspectionServiceReq.setWorkFlowId(strWorkFlowID);
			inspectionServiceReq.setApprovalNo(CommonConstants.BLANK_STRING);
			//inspectionServiceReq.setEmployeeName(""); // To be set from input. //Commented By Ketan On 09 Nov 2016
			inspectionServiceReq.setEmployeeName(inspectionRequest.getLstPreInspResDet().getEmployeeName()==null?"":inspectionRequest.getLstPreInspResDet().getEmployeeName()); //Added By Ketan On 09 Nov 2016
			inspectionServiceReq.setEmployeeNo(CommonConstants.BLANK_STRING);
			inspectionServiceReq.setInspectionOverride(CommonConstants.DEFAULT_FALSE_STATUS);
			//inspectionServiceReq.setOverrideFlag(CommonConstants.DEFAULT_FALSE_STATUS); //Commented By Ketan On 10 Nov 2016
			inspectionServiceReq.setOverrideFlag(CommonConstants.BLANK_STRING); //Added By Ketan On 10 Nov 2016
			//inspectionServiceReq.setStatus(CommonConstants.BLANK_STRING); //Commented By Ketan On 10 Nov 2016
			/*Added By Ketan On 10 Nov 2016 starts here*/
			if(inspectionRequest.getLstPreInspResDet()!=null)
				inspectionServiceReq.setStatus(inspectionRequest.getLstPreInspResDet().getInspStatus()==null?"":inspectionRequest.getLstPreInspResDet().getInspStatus());
			else
				inspectionServiceReq.setStatus(CommonConstants.BLANK_STRING);
			/*Added By Ketan On 10 Nov 2016 ends here*/
		}
		
		return inspectionServiceReq;
	}
	
}

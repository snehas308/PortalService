package com.majesco.dcf.motor.json;

import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class ChannelDetails {
	
	private String applNo;
	private String applDt;
	private String partApplNo;
	private String prodIntermCd;
	private String prodIntermNm;
	private String dealPartCd;
	private String subAgntCd;
	private String subAgntNm;
	private String remarks;
	ServiceUtility serviceUtility = new ServiceUtility();
	
	public String getApplNo() {
		return applNo;
	}
	public void setApplNo(String applNo) {
		applNo = serviceUtility.blankToNullCheck(applNo);
		this.applNo = applNo;
	}
	public String getApplDt() {
		return applDt;
	}
	public void setApplDt(String applDt) {
		applDt = serviceUtility.blankToNullCheck(applDt);
		this.applDt = applDt;
	}
	public String getPartApplNo() {
		return partApplNo;
	}
	public void setPartApplNo(String partApplNo) {
		partApplNo = serviceUtility.blankToNullCheck(partApplNo);
		this.partApplNo = partApplNo;
	}
	public String getProdIntermCd() {
		return prodIntermCd;
	}
	public void setProdIntermCd(String prodIntermCd) {
		prodIntermCd = serviceUtility.blankToNullCheck(prodIntermCd);
		this.prodIntermCd = prodIntermCd;
	}
	public String getProdIntermNm() {
		return prodIntermNm;
	}
	public void setProdIntermNm(String prodIntermNm) {
		prodIntermNm = serviceUtility.blankToNullCheck(prodIntermNm);
		this.prodIntermNm = prodIntermNm;
	}
	public String getDealPartCd() {
		return dealPartCd;
	}
	public void setDealPartCd(String dealPartCd) {
		dealPartCd = serviceUtility.blankToNullCheck(dealPartCd);
		this.dealPartCd = dealPartCd;
	}
	public String getSubAgntCd() {
		return subAgntCd;
	}
	public void setSubAgntCd(String subAgntCd) {
		subAgntCd = serviceUtility.blankToNullCheck(subAgntCd);
		this.subAgntCd = subAgntCd;
	}
	public String getSubAgntNm() {
		return subAgntNm;
	}
	public void setSubAgntNm(String subAgntNm) {
		subAgntNm = serviceUtility.blankToNullCheck(subAgntNm);
		this.subAgntNm = subAgntNm;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		remarks = serviceUtility.blankToNullCheck(remarks);
		this.remarks = remarks;
	}
	
}

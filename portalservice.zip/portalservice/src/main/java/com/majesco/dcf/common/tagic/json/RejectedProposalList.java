package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

public class RejectedProposalList {

	private int noOfRejectedProposal;
	private ArrayList<DashBoardSummaryDetails> dashBoardSummaryRejectedList;
	public int getNoOfRejectedProposal() {
		return noOfRejectedProposal;
	}
	public void setNoOfRejectedProposal(int noOfRejectedProposal) {
		this.noOfRejectedProposal = noOfRejectedProposal;
	}
	public ArrayList<DashBoardSummaryDetails> getDashBoardSummaryRejectedList() {
		return dashBoardSummaryRejectedList;
	}
	public void setDashBoardSummaryRejectedList(
			ArrayList<DashBoardSummaryDetails> dashBoardSummaryRejectedList) {
		this.dashBoardSummaryRejectedList = dashBoardSummaryRejectedList;
	}
}

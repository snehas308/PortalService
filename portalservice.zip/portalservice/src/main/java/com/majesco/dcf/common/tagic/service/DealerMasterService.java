package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.entity.DealerMaster;
import com.majesco.dcf.common.tagic.entity.RTOLocation;
import com.majesco.dcf.common.tagic.json.DealerMasterRequest;
import com.majesco.dcf.common.tagic.json.DealerMasterResponse;
import com.majesco.dcf.common.tagic.json.DocumentVO;
import com.majesco.dcf.common.tagic.json.ResponseError;

@Service
public class DealerMasterService {
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(DealerMasterService.class);
	
	@SuppressWarnings({ "null", "unchecked" })
	public DealerMasterResponse FetchDealerInfo(DealerMasterRequest docreq) throws Exception
	{
		DealerMasterResponse docres = new DealerMasterResponse();
		try
		{
		
			logger.info("In DealerMasterService.FetchDealerInfo() Method Begin()...");
			
			 String strintermediarycd ="";
			 String strintermediaryname ="";
			 /*String dtbirth ="";
			 String dtintermediarystart ="";
			 String dtintermediaryend ="";
			 Integer nintermediarystatus ;
			 String strintermediarystatus ="";
			 String strindcorpflag ="";
			 Integer ncategoryid ;
			 String strlicenseno ="";
			 String strpanno ="";
			 Integer nlocationcd ;
			 Integer nbranchcd ;
			 String strbankbranch ="";
			 String straccountno ="";
			 String strparentintermediarycd ="";
			 Integer nynparent ;
			 Integer nyndealer ;
			 Integer nbankcd ;
			 String strifscd ="";
			 String strmicrcd ="";
			 Integer niscorpbranch ;
			 Integer ncommremtype ;
			 String strcommpaymode ="";
			 String strinterpaymentfreq ="";
			 Integer npaylocationcd ;
			 String strpayeename ="";
			 Integer npayoutpayto ;
			 Integer npartnerid ;
			 String strchanneltype ="";
			 String strgender ="";
			 String struidno ="";
			 Integer naccounttype ;
			 String strsalutation ="";
			 String strdnd ="";
			 Integer nofficecd ;
			 String strstatus ="";
			 Integer nproducerprofilecd ;
			 String strsubtype ="";
			 String strreasonsuspension ="";
			 String strotherreasonsus ="";
			 String strcategory ="";
			 String strsubtransfercategory ="";
			 String stralternatecd ="";
			 String strissubproducer ="";
			 String strchequedispatchedto ="";
			 String strchequedisbursement ="";
			 String strissuingcompanycd ="";
			 String dtsubproducerissuedt ="";
			 Integer nchannelid ;
			 Integer nchqdisptchoffcloc ;*/
			 String strdealercd ="";
			 String strdealername ="";
			 /*String strapprovalstatus ="";
			 String strchecklocationcdm ="";
			 String strcheckalllocation ="";
			 String dtstatusefectivedt ="";
			 String stremailsmsreqd ="";
			 String stralt_dnd ="";
			 String dtcreated ="";
			 String strcreatedby ="";
			 String dtupdated ="";
			 String strupdatedby ="";*/
			
			 
			 
		 	List<String> lststrintermediarycd = new ArrayList<String>();
			List<String> lststrintermediaryname = new ArrayList<String>();
			/*List<String> lstdtbirth;
			List<String> lstdtintermediarystart;
			List<String> lstdtintermediaryend;
			List<Integer> lstnintermediarystatus;
			List<String> lststrintermediarystatus;
			List<String> lststrindcorpflag;
			List<Integer> lstncategoryid;
			List<String> lststrlicenseno;
			List<String> lststrpanno;
			List<Integer> lstnlocationcd;
			List<Integer> lstnbranchcd;
			List<String> lststrbankbranch;
			List<String> lststraccountno;
			List<String> lststrparentintermediarycd;
			List<Integer> lstnynparent;
			List<Integer> lstnyndealer;
			List<Integer> lstnbankcd;
			List<String> lststrifscd;
			List<String> lststrmicrcd;
			List<Integer> lstniscorpbranch;
			List<Integer> lstncommremtype;
			List<String> lststrcommpaymode;
			List<String> lststrinterpaymentfreq;
			List<Integer> lstnpaylocationcd;
			List<String> lststrpayeename;
			List<Integer> lstnpayoutpayto;
			List<Integer> lstnpartnerid;
			List<String> lststrchanneltype;
			List<String> lststrgender;
			List<String> lststruidno;
			List<Integer> lstnaccounttype ;
			List<String> lststrsalutation;
			List<String> lststrdnd;
			List<Integer> lstnofficecd ;
			List<String> lststrstatus;
			List<Integer> lstnproducerprofilecd;
			List<String> lststrsubtype;
			List<String> lststrreasonsuspension;
			List<String> lststrotherreasonsus;
			List<String> lststrcategory;
			List<String> lststrsubtransfercategory;
			List<String> lststralternatecd;
			List<String> lststrissubproducer;
			List<String> lststrchequedispatchedto;
			List<String> lststrchequedisbursement;
			List<String> lststrissuingcompanycd;
			List<String> lstdtsubproducerissuedt;
			List<Integer> lstnchannelid;
			List<Integer> lstnchqdisptchoffcloc;*/
			List<String> lststrdealercd = new ArrayList<String>();
			List<String> lststrdealername = new ArrayList<String>();
			/*List<String> lststrapprovalstatus;
			List<String> lststrchecklocationcdm;
			List<String> lststrcheckalllocation;
			List<String> lstdtstatusefectivedt;
			List<String> lststremailsmsreqd;
			List<String> lststralt_dnd;
			List<String> lstdtcreated;
			List<String> lststrcreatedby;
			List<String> lstdtupdated;
			List<String> lststrupdatedby;*/
					
			
			
			List<ResponseError> reserrList = new ArrayList<ResponseError>();
			
			
			ResponseError res = new ResponseError();
			res.setErrorCode("101");
			res.setErrorMMessag("Sorry Authentication Issue....");
			reserrList.add(res);
			
	
			List<DealerMaster> dealerList = (List<DealerMaster>) dbserv.getDealerMasterResponse("com.majesco.dcf.common.tagic.entity.DealerMaster", docreq);
			for(DealerMaster rec:dealerList){
		        
				strintermediarycd = rec.getStrintermediarycd();
				strintermediaryname = rec.getStrintermediaryname();
				strdealercd =rec.getStrdealercd();
				strdealername =rec.getStrdealername();
				lststrintermediarycd.add(strintermediarycd);
				lststrintermediaryname.add(strintermediaryname);
				lststrdealercd.add(strdealercd);
				lststrdealername.add(strdealername);
	        }
			docres.setStrintermediarycd(lststrintermediarycd);
	        docres.setStrintermediaryname(lststrintermediaryname);
	        docres.setStrdealercd(lststrdealercd);
	        docres.setStrdealername(lststrdealername);
	        
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In DealerMasterService.FetchDealerInfo() Method End()...");
//		ObjectMapper objMap=new ObjectMapper();
//		System.out.println(objMap.writeValueAsString(docres));
		logger.info("In DealerMasterService.FetchDealerInfo() Method :: Response : "+docres);
		
		return docres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }
}

package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_product_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_product_m")								// Added for Oracle Migration
public class Product implements Serializable{
	
	private String strprodcd;
	private Integer nprodver;
	private String strprodname;
	private String strlobcd;
	private Integer nisactive;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	
	
	@Id
	@Column(name = "strprodcd")
	public String getStrprodcd() {
		return strprodcd;
	}
	public void setStrprodcd(String strprodcd) {
		this.strprodcd = strprodcd;
	}
	
	
	@Id
	@Column(name = "nprodver")
	public Integer getNprodver() {
		return nprodver;
	}
	public void setNprodver(Integer nprodver) {
		this.nprodver = nprodver;
	}
	
	
	@Column(name = "strprodname")
	public String getStrprodname() {
		return strprodname;
	}
	public void setStrprodname(String strprodname) {
		this.strprodname = strprodname;
	}
	
	
	@Column(name = "strlobcd")
	public String getStrlobcd() {
		return strlobcd;
	}
	public void setStrlobcd(String strlobcd) {
		this.strlobcd = strlobcd;
	}
	
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}

}

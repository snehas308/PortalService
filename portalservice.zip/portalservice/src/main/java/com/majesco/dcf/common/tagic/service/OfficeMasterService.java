package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.googlecode.ehcache.annotations.Cacheable;
import com.majesco.dcf.common.tagic.entity.OfficeMaster;
import com.majesco.dcf.common.tagic.json.DealerMasterResponse;
import com.majesco.dcf.common.tagic.json.OfficeMasterRequest;
import com.majesco.dcf.common.tagic.json.OfficeMasterResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.usermgmt.json.UserDetails;
import com.majesco.dcf.usermgmt.json.UserInfoResponse;
import com.majesco.dcf.usermgmt.service.UserService;

@Service
public class OfficeMasterService {
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(OfficeMasterService.class);
	
	@Autowired
	UserService userService;
	
	@SuppressWarnings({ "null", "unchecked" })
	@Cacheable(cacheName="officeMasterInfoEhcache")
	public OfficeMasterResponse getOfficeMaster(OfficeMasterRequest docreq) throws Exception
	{
		OfficeMasterResponse docres = new OfficeMasterResponse();
		ArrayList docArr = new ArrayList();
		try
		{
		
			logger.info("In OfficeMasterService.getOfficeMaster() Method Begin()...");
			
			List<String> office = new ArrayList<String>();
			List<BigDecimal> officeccode = new ArrayList<BigDecimal>();
			List<BigDecimal> parentofficecode = new ArrayList<BigDecimal>();
			List<String> officedesc= new ArrayList<String>();
			List<String> strofficecode = new ArrayList<String>();
			List<String> strparentofccode = new ArrayList<String>();
			
			
			List<ResponseError> reserrList = new ArrayList<ResponseError>();
			
			
			ResponseError res = new ResponseError();
			//res.setErrorCode("101");
			//res.setErrorMMessag("Sorry Authentication Issue....");
			reserrList.add(res);
			
	//Start:TAGIC:19/12/2016:Added to get office list according to user assigned branch location
			/*UserObject userObject=new UserObject();
			userObject.setUserID(docreq.getUserID());
			StopWatch watch_userInforForOfcMst = new StopWatch();
			watch_userInforForOfcMst.start();
			UserInfoResponse userInfoResponse=userService.getUserInfo(userObject);
			watch_userInforForOfcMst.stop();
			logger.info("Time Taken by OfficeMasterService--> getOfficeMaster--> getUserInfo service in seconds..>>"+watch_userInforForOfcMst.getTotalTimeSeconds());
			UserDetails userDetails=userInfoResponse.getUserInfoDetails();
			String strBranchList[]=null;
			if(userDetails!=null && userDetails.getBranchLocation()!=null){
				if(userDetails.getBranchLocation().indexOf(",")==-1){
					strBranchList=new String[1];
					strBranchList[0]="'"+userDetails.getBranchLocation()+"'";
					userDetails.setBranchLocation(strBranchList[0]);
				}else{
				strBranchList=userDetails.getBranchLocation().split(",");
				StringBuffer strBuf=new StringBuffer();
				int nCommaCounter=1;
				for(int i=0;i<strBranchList.length;i++){
					strBuf=strBuf.append("'").append(strBranchList[i]).append("'");
					if(nCommaCounter<strBranchList.length){
						strBuf=strBuf.append(",")	;
						nCommaCounter++;
					}
				}
				userDetails.setBranchLocation(strBuf.toString());
				}
			}*/ /*Commented As BranchLocation Is No More In Use In dbserv.getOfficeMaster() call on 18/04/2017 -- Ketan*/
			/*Added As BranchLocation Is No More In Use In dbserv.getOfficeMaster() call on 18/04/2017 -- Ketan*/
			UserDetails userDetails = new UserDetails();
			userDetails.setBranchLocation(null);
			/*Added As BranchLocation Is No More In Use In dbserv.getOfficeMaster() call on 18/04/2017 -- Ketan*/
			
			//End:TAGIC:19/12/2016:Added to get office list according to user assigned branch location	
			
			StopWatch watch_OfcMstDB = new StopWatch();
			watch_OfcMstDB.start();
			docArr = (ArrayList<Object>) dbserv.getOfficeMaster("com.majesco.dcf.common.tagic.entity.OfficeMaster",userDetails.getBranchLocation());
			for(int i=0; i< docArr.size(); i++)
			{
		        OfficeMaster ent = new OfficeMaster();
		        ent = (OfficeMaster) docArr.get(i);
				office.add(ent.getOffice());
				officeccode.add(ent.getNofficecd());
				parentofficecode.add(ent.getNparentofficecd());
				officedesc.add(ent.getStrofficedesc());
				strofficecode.add(ent.getStrofficecd());
				strparentofccode.add(ent.getStrparentofficecd());
	        }
			watch_OfcMstDB.stop();
			logger.info("Time Taken by OfficeMasterService--> getOfficeMaster--> getOfficeMasterDB service in seconds..>>"+watch_OfcMstDB.getTotalTimeSeconds());
			docres.setOffice(office);
			docres.setNofficecd(officeccode);
			docres.setNparentofficecd(parentofficecode);
			docres.setStrofficecd(strofficecode);
			docres.setStrofficedesc(officedesc);
			docres.setStrparentofficecd(strparentofccode);
			//modelres.setNfieldusercd(nfieldusercd);
		}
		catch(Exception e)
		{
			//System.out.println(e.toString());
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In DocumentService.DocumentInfo() Method End()...");
//		ObjectMapper objMap=new ObjectMapper();
//		System.out.println(objMap.writeValueAsString(docres));
		logger.info("In DocumentService.DocumentInfo() Method :: Response Of variantres : "+docres);
		
		return docres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }


}

package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ModelResponse {
	
	private List<String> strmodelcd;
	private List<String> strmodelnumber;
	

	public List<String> getStrmodelcd() {
		return strmodelcd;
	}
	public void setStrmodelcd(List<String> strmodelcd) {
		this.strmodelcd = strmodelcd;
	}
	public List<String> getStrmodelnumber() {
		return strmodelnumber;
	}
	public void setStrmodelnumber(List<String> strmodelnumber) {
		this.strmodelnumber = strmodelnumber;
	}
	private List<ResponseError> resErr;
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}

}

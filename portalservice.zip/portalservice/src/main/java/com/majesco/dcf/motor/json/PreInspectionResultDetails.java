package com.majesco.dcf.motor.json;

import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class PreInspectionResultDetails {
	
	private String inspRefNo;
	private String inspDt;
	private String inspTime;
	private String inspAuth;
	private String bodyColor;
	private String odometerRead;
	private String inspStatus;
	private String remarks;
	private String nameOfInspectAgency;
	private String employeeName;
	//ServiceUtility serviceUtility = new ServiceUtility();
	
	public String getInspRefNo() {
		return inspRefNo;
	}
	public void setInspRefNo(String inspRefNo) {
		this.inspRefNo = inspRefNo;
	}
	public String getInspDt() {
		return inspDt;
	}
	public void setInspDt(String inspDt) {
		this.inspDt = inspDt;
	}
	public String getInspTime() {
		return inspTime;
	}
	public void setInspTime(String inspTime) {
		this.inspTime = inspTime;
	}
	public String getInspAuth() {
		return inspAuth;
	}
	public void setInspAuth(String inspAuth) {
		this.inspAuth = inspAuth;
	}
	public String getBodyColor() {
		return bodyColor;
	}
	public void setBodyColor(String bodyColor) {
		this.bodyColor = bodyColor;
	}
	public String getOdometerRead() {
		return odometerRead;
	}
	public void setOdometerRead(String odometerRead) {
		this.odometerRead = odometerRead;
	}
	public String getInspStatus() {
		return inspStatus;
	}
	public void setInspStatus(String inspStatus) {
		this.inspStatus = inspStatus;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getNameOfInspectAgency() {
		return nameOfInspectAgency;
	}
	public void setNameOfInspectAgency(String nameOfInspectAgency) {
		this.nameOfInspectAgency = nameOfInspectAgency;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
		

}

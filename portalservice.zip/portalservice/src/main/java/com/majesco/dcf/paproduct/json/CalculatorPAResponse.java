package com.majesco.dcf.paproduct.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CalculatorPAResponse {

	private String resultCode; 
	private List<PremiumDetails> premDetlst;
	private List<ResponseError> resErr;
	
	
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public List<PremiumDetails> getPremDetlst() {
		return premDetlst;
	}
	public void setPremDetlst(List<PremiumDetails> premDetlst) {
		this.premDetlst = premDetlst;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	
	
	
}

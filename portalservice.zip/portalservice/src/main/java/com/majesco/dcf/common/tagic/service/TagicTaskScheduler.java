package com.majesco.dcf.common.tagic.service;

import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@EnableScheduling
public interface TagicTaskScheduler {
	//@Scheduled(cron = "${cron.schedule.expiredPayLink}") 0 0 0 1/1 * ?
	@Scheduled(cron = "0 0 0 1/1 * ?")
	public void markPayLinkInactive() throws Exception;
	//@Scheduled(cron = "${cron.schedule.masterDataJSON}")
	@Scheduled(cron = "0 0 0 1/1 * ?")
	public void generateJSONFileForMstData() throws Exception;
	
	// Start: KetanM <Production 2505>| Re-hit mechanism to be put up for policycumreciept generation service
	@Scheduled(cron = "0 0/15 * 1/1 * ?")
	public void processRehitMechForExceptionPolicy() throws Exception;
	// End: KetanM <Production 2505>| Re-hit mechanism to be put up for policycumreciept generation service
	
	//Start: Issue: 9870467
	@Scheduled(cron = "0 0/20 * 1/1 * ?")
	public void sendCommunicationForPendingTxn() throws Exception;
	//End: Issue: 9870467
	
	@Scheduled(cron = "0 0/15 * 1/1 * ?")
	public void processSetStatusForSuccessPolicy() throws Exception;
	
	@Scheduled(cron = "0 0/20 * 1/1 * ?")
	public void paymentSchedulerForSuccessPaymentPolicyNotIssued() throws Exception;
	
}

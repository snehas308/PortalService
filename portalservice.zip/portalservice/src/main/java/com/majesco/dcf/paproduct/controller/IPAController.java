package com.majesco.dcf.paproduct.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.majesco.dcf.common.constant.CommonConstants;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.service.TagicCommonService;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.paproduct.entity.QuotationPA;
import com.majesco.dcf.paproduct.json.IPAProposalDataRequest;
import com.majesco.dcf.paproduct.json.IPAProposalDataResponse;
import com.majesco.dcf.paproduct.json.IPAProposalRequest;
import com.majesco.dcf.paproduct.json.IPAProposalResponse;
import com.majesco.dcf.paproduct.json.PAQuickQuotPrmRequest;
import com.majesco.dcf.paproduct.json.PAQuickQuotPrmResponse;
import com.majesco.dcf.paproduct.json.SearchIPAQuotRequest;
import com.majesco.dcf.paproduct.json.SearchIPAQuotResponse;
import com.majesco.dcf.paproduct.service.CalculatorPAService;
import com.majesco.dcf.paproduct.service.IPAService;

@Controller
@RequestMapping(value="/IPAService")
public class IPAController {

	@Autowired
	IPAService paServ;
	@Autowired
	CalculatorPAService calcPAserv;
	@Autowired
	TagicCommonService commonService;
	
	
	
	final static Logger logger=Logger.getLogger(IPAController.class);
	
	@RequestMapping(value="/createProposalAG/", method = RequestMethod.POST)
	@ResponseBody
	public IPAProposalResponse generateIPAProposalAG(@RequestBody IPAProposalRequest propPAReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside IPAController :: generateIPAProposalAG method :: Execution Started");		
		//propPAReq.setLocalTransId(System.nanoTime());
		propPAReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		propPAReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+propPAReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
		
		
		IPAProposalResponse propPARes = paServ.getIPAProposalAG(propPAReq);
		
		logger.info("Inside IPAController :: generateIPAProposalAG method :: Execution Completed Successfully");
		
		return propPARes;
	}
	
	@RequestMapping(value="/quickQuotPremiumPA/",method = RequestMethod.POST)
	@ResponseBody
	public List<PAQuickQuotPrmResponse> getQuickQuotPremium(@RequestBody List<PAQuickQuotPrmRequest> quickQuotReqList, HttpServletRequest httpServletRequest)
			throws Exception	
	{
		logger.info("Inside IPAController :: getQuickQuotPremium method :: Execution Started");
		
		int size = quickQuotReqList.size();
		
		List<PAQuickQuotPrmResponse> responseList = new ArrayList<PAQuickQuotPrmResponse>(size);
		
		for (PAQuickQuotPrmRequest quickQuotObj : quickQuotReqList){
			PAQuickQuotPrmResponse paResponse =calcPAserv.getQuickQuotPremium(quickQuotObj);
			responseList.add(paResponse);
		}
		
		
		logger.info("Inside IPAController :: getQuickQuotPremium method :: Execution Completed Successfully");
		
		return responseList;
	}
	
	@RequestMapping(value="/saveQuickQuotPA/",method = RequestMethod.POST)
	@ResponseBody
	public List<PAQuickQuotPrmResponse> saveQuickQuotPremium(@RequestBody List<PAQuickQuotPrmRequest> quickQuotReqList, HttpServletRequest httpServletRequest)
			throws Exception	
	{
		logger.info("Inside IPAController :: saveQuickQuotPremium method :: Execution Started");
						
		int size = quickQuotReqList.size();
		
		List<PAQuickQuotPrmResponse> responseList = new ArrayList<PAQuickQuotPrmResponse>(size);
		
		for (PAQuickQuotPrmRequest quickQuotObj : quickQuotReqList){
			PAQuickQuotPrmResponse paResponse = new PAQuickQuotPrmResponse ();
			quickQuotObj.setAuthToken(httpServletRequest.getHeader("gc_token"));
			quickQuotObj.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
			paResponse =calcPAserv.saveQuickQuotPremium(quickQuotObj);
			responseList.add(paResponse);
		}
		
		
		logger.info("Inside IPAController :: saveQuickQuotPremium method :: Execution Completed Successfully");
		
		return responseList;
//		return paResponse;
	}
	
	@RequestMapping(value="/createProposalAS/", method = RequestMethod.POST)
	@ResponseBody
	public IPAProposalResponse generateIPAProposalAS(@RequestBody IPAProposalRequest propPAReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside IPAController :: generateIPAProposalAS method :: Execution Started");
		propPAReq.setLocalTransId(System.nanoTime());
		propPAReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		propPAReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+propPAReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object		
		
		IPAProposalResponse propPARes = paServ.generateIPAProposalAS(propPAReq);
		
		logger.info("Inside IPAController :: generateIPAProposalAS method :: Execution Completed Successfully");
		
		return propPARes;
	}
	
	@RequestMapping(value="/createPremiumAS/", method = RequestMethod.POST)
	@ResponseBody
	public IPAProposalResponse generateIPAPremiumAS(@RequestBody IPAProposalRequest propPAReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside IPAController :: generateIPAProposalAS method :: Execution Started");
		propPAReq.setLocalTransId(System.nanoTime());
		propPAReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		propPAReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+propPAReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
		
		IPAProposalResponse propPARes = paServ.generateIPAPremiumAS(propPAReq);
		
		logger.info("Inside IPAController :: generateIPAProposalAS method :: Execution Completed Successfully");
		
		return propPARes;
	}
	
	@RequestMapping(value="/createProposalSecurePlan/", method = RequestMethod.POST)
	@ResponseBody
	public IPAProposalResponse generateIPAProposalSecurePlan(@RequestBody IPAProposalRequest propPAReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside IPAController :: generateIPAProposalSecurePlan method :: Execution Started");
		propPAReq.setLocalTransId(System.nanoTime());
		propPAReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		propPAReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+propPAReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
		
		IPAProposalResponse propPARes = paServ.generateIPAProposalSecurePlan(propPAReq);
		
		logger.info("Inside IPAController :: generateIPAProposalSecurePlan method :: Execution Completed Successfully");
		
		return propPARes;
	}
	
	@RequestMapping(value="/getPremiumAG/",method = RequestMethod.POST)
	@ResponseBody
	public IPAProposalResponse getPremiumAG(@RequestBody IPAProposalRequest propPAReq, HttpServletRequest httpServletRequest)
			throws Exception	
	{
		logger.info("Inside IPAController :: getPremiumAG method :: Execution Started");
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		propPAReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+propPAReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
				
          IPAProposalResponse propPARes = paServ.getIPAPremiumAG(propPAReq);
		

		logger.info("Inside IPAController :: getPremiumAG method :: Execution Completed Successfully");
		
		return propPARes;
	}
	
	@RequestMapping(value="/getPremiumAS/",method = RequestMethod.POST)
	@ResponseBody
	public IPAProposalResponse getPremiumAS(@RequestBody IPAProposalRequest propPAReq, HttpServletRequest httpServletRequest)
			throws Exception	
	{
		logger.info("Inside IPAController :: getPremiumAS method :: Execution Started");
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		propPAReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+propPAReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
					
        IPAProposalResponse propPARes = paServ.generateIPAPremiumAS(propPAReq);
		
		logger.info("Inside IPAController :: getPremiumAS method :: Execution Completed Successfully");
		
		return propPARes;
	}
	
	
	@RequestMapping(value="/getPremiumSFP/",method = RequestMethod.POST)
	@ResponseBody
	public IPAProposalResponse getPremiumSFP(@RequestBody IPAProposalRequest propPAReq, HttpServletRequest httpServletRequest)
			throws Exception	
	{
		logger.info("Inside IPAController :: getPremiumSFP method :: Execution Started");
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		propPAReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+propPAReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
				
          IPAProposalResponse propPARes = paServ.getIPAPremiumSecurePlan(propPAReq);
		

		logger.info("Inside IPAController :: getPremiumSFP method :: Execution Completed Successfully");
		
		return propPARes;
	}
	
	
	
	@RequestMapping(value="/getQuoteDetails/",method = RequestMethod.POST)
	@ResponseBody
	public QuotationPA getQuoteDetails(@RequestBody QuotationPA quoteDetails, HttpServletRequest httpServletRequest)
			throws Exception	
	{
		logger.info("Inside IPAController :: getQuoteDetails method :: Execution Started");
		
		QuotationPA quotetionPA = paServ.getQuotationDetails(quoteDetails);
		

		logger.info("Inside IPAController :: getQuoteDetails method :: Execution Completed Successfully");
		
		return quotetionPA;
	}
	
	//Start: RahulT | added to get policy/proposal details For Accident Guard
	@RequestMapping(value="/getIPAProposalDataAG/",method = RequestMethod.POST)
	@ResponseBody
	public IPAProposalDataResponse getIPAProposalDataAG(@RequestBody IPAProposalDataRequest prodPropDataReq, HttpServletRequest httpServletRequest)
			throws Exception	
	{
		logger.info("Inside IPAController :: getIPAProposalDataAG method :: Execution Started");
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		prodPropDataReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+prodPropDataReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
				
		IPAProposalDataResponse propPARes = paServ.getIPAProposalDataAG(prodPropDataReq);
		

		logger.info("Inside IPAController :: getIPAProposalDataAG method :: Execution Completed Successfully");
		
		return propPARes;
	}
	//End: RahulT | added to get policy/proposal details For Accident Guard
	
	//Start: RahulT | added to get policy/proposal details For Accident Shield
		@RequestMapping(value="/getIPAProposalDataAS/",method = RequestMethod.POST)
		@ResponseBody
		public IPAProposalDataResponse getIPAProposalDataAS(@RequestBody IPAProposalDataRequest prodPropDataReq, HttpServletRequest httpServletRequest)
				throws Exception	
		{
			logger.info("Inside IPAController :: getIPAProposalDataAG method :: Execution Started");
			//Start:Vishal<VAPT comments>| code added to set GC token into user object 
			prodPropDataReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			logger.info("Auth token received from Request Header..--> "+prodPropDataReq.getAuthToken());
			//End:Vishal<VAPT comments>| code added to set GC token into user object
			
			IPAProposalDataResponse propPARes = paServ.getIPAProposalDataAS(prodPropDataReq);
			

			logger.info("Inside IPAController :: getIPAProposalDataAG method :: Execution Completed Successfully");
			
			return propPARes;
		}
		//End: RahulT | added to get policy/proposal details For Accident Shield
		
		//Start: RahulT | added to get policy/proposal details For secure Future plan
		@RequestMapping(value="/getIPAProposalDataSFP/",method = RequestMethod.POST)
		@ResponseBody
		public IPAProposalDataResponse getIPAProposalDataSFP(@RequestBody IPAProposalDataRequest prodPropDataReq, HttpServletRequest httpServletRequest)
				throws Exception	
		{
			logger.info("Inside IPAController :: getIPAProposalDataAG method :: Execution Started");
			//Start:Vishal<VAPT comments>| code added to set GC token into user object 
			prodPropDataReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			logger.info("Auth token received from Request Header..--> "+prodPropDataReq.getAuthToken());
			//End:Vishal<VAPT comments>| code added to set GC token into user object
			
			IPAProposalDataResponse propPARes = paServ.getIPAProposalDataSFP(prodPropDataReq);
			

			logger.info("Inside IPAController :: getIPAProposalDataAG method :: Execution Completed Successfully");
			
			return propPARes;
		}
		//End: RahulT | added to get policy/proposal details For secure Future plan
		
		//Start: RahulT | added for search IPA Quote
		@RequestMapping(value="/searchIPAQuotList/",method = RequestMethod.POST)
		@ResponseBody
		public List<SearchIPAQuotResponse> searchIPAQuotationList(@RequestBody SearchIPAQuotRequest ipaQuotRequest, HttpServletRequest httpServletRequest)
				throws Exception	
		{
			ObjectMapper objMapper = new ObjectMapper();
			List<SearchIPAQuotResponse> ipaQuotResponse = new ArrayList<SearchIPAQuotResponse>();
			logger.info("Inside IPAController :: searchIPAQuotation method :: UI Object--> "+objMapper.writeValueAsString(ipaQuotRequest));
			
			try{
				ipaQuotResponse = paServ.searchIPAQuotationList(ipaQuotRequest);
				logger.info("Inside IPAController :: searchIPAQuotation method :: Execution Completed Successfully");
			}

			catch(Exception e){
				e.printStackTrace();
			}
			return ipaQuotResponse;
		}
		
		@RequestMapping(value="/getIPAQuotation/",method = RequestMethod.POST)
		@ResponseBody
		public SearchIPAQuotResponse getIPAQuotationDtl(@RequestBody SearchIPAQuotRequest ipaQuotRequest, HttpServletRequest httpServletRequest)
				throws Exception	
		{
			logger.info("Inside IPAController :: 	 method :: Execution Started");
			SearchIPAQuotResponse ipaQuotResponse = null;
			try{
			ipaQuotResponse = paServ.getIPAQuotation(ipaQuotRequest);
			logger.info("Inside IPAController :: getIPAQuotationDtl method :: Execution Completed Successfully");
			}
			
			catch(Exception e){
				e.printStackTrace();
			}
			
			return ipaQuotResponse;
		}
		//End: RahulT | added for search IPA Quote
		//Start: Vishal | added to Modify Proposal on renewal search For All IPA Product
		@RequestMapping(value="/getIPAPolicyDetailsOnRenewal/",method = RequestMethod.POST)
		@ResponseBody
		public IPAProposalDataResponse getIPAPolicyDetailsOnRenewal(@RequestBody IPAProposalDataRequest prodPropDataReq, HttpServletRequest httpServletRequest)
				throws Exception	
		{
			logger.info("Inside IPAController :: getIPAPolicyDetailsOnRenewal method :: Execution Started");

			//Start:Vishal<VAPT comments>| code added to set GC token into user object 
			prodPropDataReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			logger.info("Auth token received from Request Header..--> "+prodPropDataReq.getAuthToken());
			//End:Vishal<VAPT comments>| code added to set GC token into user object

			IPAProposalDataResponse propPARes = new IPAProposalDataResponse();
			String proposalNo="";
			
			if(prodPropDataReq!=null){
				try{
				logger.info("Inside IPAController :: getIPAPolicyDetailsOnRenewal method :: prodPropDataReq.getPolicyNumber()"+prodPropDataReq.getPolicyNumber());				
					proposalNo = commonService.getProposalNoByPolicyNo(prodPropDataReq.getPolicyNumber(), prodPropDataReq.getProductCode(), prodPropDataReq.getUserID(), prodPropDataReq.getPassword(),prodPropDataReq.getAuthToken());
				}
				catch(Exception e){
					e.printStackTrace();
				}
				if(proposalNo==null || proposalNo.equalsIgnoreCase("")){
					propPARes.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR");
					errorRes.setErrorMMessag("Proposal Number Not Recieved From PolicyService");
					errorList.add(errorRes);
					propPARes.setResErr(errorList);
					
					return propPARes;
				}else{
					
					logger.info("Inside IPAController :: getIPAPolicyDetailsOnRenewal method :: proposalNo :- "+proposalNo+" ProductCode :- "+prodPropDataReq.getProductCode());
					prodPropDataReq.setProposalNumber(proposalNo);
					if(prodPropDataReq.getProductCode() !=null && prodPropDataReq.getProductCode().equalsIgnoreCase("4251")){
						propPARes = paServ.getIPAProposalDataAG(prodPropDataReq);	
					}else if(prodPropDataReq.getProductCode() !=null && prodPropDataReq.getProductCode().equalsIgnoreCase("4254")){
						propPARes = paServ.getIPAProposalDataAS(prodPropDataReq);
					}else if(prodPropDataReq.getProductCode() !=null && prodPropDataReq.getProductCode().equalsIgnoreCase("4255")){
						propPARes = paServ.getIPAProposalDataSFP(prodPropDataReq);
					}		
					
				}																									
			}
			logger.info("Inside IPAController :: getIPAPolicyDetailsOnRenewal method :: Execution Completed Successfully");
			
			return propPARes;
		}
		//End: Vishal | added to Modify Proposal on renewal search For All IPA Product
		
		
		
		
}

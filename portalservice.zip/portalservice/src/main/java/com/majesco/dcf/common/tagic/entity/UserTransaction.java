package com.majesco.dcf.common.tagic.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "dcf_user_trans_dtl")
public class UserTransaction{
	
	@Column(name= "ltransid")
	private Long ltransId;
	
	@Column(name= "strquotnumber")
	private String strQuotNumber;
	
	@Column(name= "strpropnumber")
	private String strPropNumber;
	
	@Column(name= "strcustomerid")
	private String strCustomerId;
	
	@Column(name= "strpolnbr")
	private String strPolNbr;
	
	@Column(name= "strlob")
	private String strlob;
	
	@Column(name= "stryranstype")
	private String strTranstype;
	
	@Column(name= "strproducercd")
	private String strProducercd;
	
	@Column(name= "struserid")
	private String strUserid;
	
	@Column(name= "stripaddress")
	private String strIPAddress;
	
	@Column(name= "dtotsa")
	private Double dtotSA;
	
	@Column(name= "dtotalpremium")
	private String totalPremium;
	
	@Column(name= "dttrans")
	private Date dtTrans;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtcreated", insertable=false)
	private Date dtCreated;
	
	@Column(name= "strcreatedby")
	private String strCreatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtupdated", insertable=false)
	private Date dtUpdated;
	
	@Column(name= "strupdatedby")
	private String strUpdatedBy;
	
	@Column(name= "strworkflowid")
	private String strWorkflowId;
	
	@Column(name= "strvehregno1")
	private String strvehregno1;

	@Column(name= "strvehregno2")
	private String strvehregno2;
	
	@Column(name= "strvehregno3")
	private String strvehregno3;
	
	@Column(name= "strvehregno4")
	private String strvehregno4;
	
	public String getStrvehregno1() {
		return strvehregno1;
	}

	public void setStrvehregno1(String strvehregno1) {
		this.strvehregno1 = strvehregno1;
	}

	public String getStrvehregno2() {
		return strvehregno2;
	}

	public void setStrvehregno2(String strvehregno2) {
		this.strvehregno2 = strvehregno2;
	}

	public String getStrvehregno3() {
		return strvehregno3;
	}

	public void setStrvehregno3(String strvehregno3) {
		this.strvehregno3 = strvehregno3;
	}

	public String getStrvehregno4() {
		return strvehregno4;
	}

	public void setStrvehregno4(String strvehregno4) {
		this.strvehregno4 = strvehregno4;
	}


	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="dcf_user_trans_dtl_seq")
	@SequenceGenerator(
			name="dcf_user_trans_dtl_seq",
			sequenceName="dcf_user_trans_dtl_seq",
			allocationSize=1
			)
	/*@AttributeOverrides({
	@AttributeOverride(name = "STRQUOTNUMBER",
	column = @Column(name="STRQUOTNUMBER")),
	@AttributeOverride(name = "STRPROPNUMBER",
	column = @Column(name="STRPROPNUMBER"))
	})*/
	public Long getLtransId() {
		return ltransId;
	}

	public void setLtransId(Long ltransId) {
		this.ltransId = ltransId;
	}

	public String getStrQuotNumber() {
		return strQuotNumber;
	}

	public void setStrQuotNumber(String strQuotNumber) {
		this.strQuotNumber = strQuotNumber;
	}

	public String getStrPropNumber() {
		return strPropNumber;
	}

	public void setStrPropNumber(String strPropNumber) {
		this.strPropNumber = strPropNumber;
	}

	public String getStrCustomerId() {
		return strCustomerId;
	}

	public void setStrCustomerId(String strCustomerId) {
		this.strCustomerId = strCustomerId;
	}

	public String getStrPolNbr() {
		return strPolNbr;
	}

	public void setStrPolNbr(String strPolNbr) {
		this.strPolNbr = strPolNbr;
	}

	public String getStrlob() {
		return strlob;
	}

	public void setStrlob(String strlob) {
		this.strlob = strlob;
	}

	public String getStrTranstype() {
		return strTranstype;
	}

	public void setStrTranstype(String strTranstype) {
		this.strTranstype = strTranstype;
	}

	public String getStrProducercd() {
		return strProducercd;
	}

	public void setStrProducercd(String strProducercd) {
		this.strProducercd = strProducercd;
	}

	public String getStrUserid() {
		return strUserid;
	}

	public void setStrUserid(String strUserid) {
		this.strUserid = strUserid;
	}

	public String getStrIPAddress() {
		return strIPAddress;
	}

	public void setStrIPAddress(String strIPAddress) {
		this.strIPAddress = strIPAddress;
	}

	public Double getDtotSA() {
		return dtotSA;
	}

	public void setDtotSA(Double dtotSA) {
		this.dtotSA = dtotSA;
	}

	public String getTotalPremium() {
		return totalPremium;
	}

	public void setTotalPremium(String totalPremium) {
		this.totalPremium = totalPremium;
	}

	public Date getDtTrans() {
		return dtTrans;
	}

	public void setDtTrans(Date dtTrans) {
		this.dtTrans = dtTrans;
	}

	public Date getDtCreated() {
		return dtCreated;
	}

	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}

	public String getStrCreatedBy() {
		return strCreatedBy;
	}

	public void setStrCreatedBy(String strCreatedBy) {
		this.strCreatedBy = strCreatedBy;
	}

	public Date getDtUpdated() {
		return dtUpdated;
	}

	public void setDtUpdated(Date dtUpdated) {
		this.dtUpdated = dtUpdated;
	}

	public String getStrUpdatedBy() {
		return strUpdatedBy;
	}

	public void setStrUpdatedBy(String strUpdatedBy) {
		this.strUpdatedBy = strUpdatedBy;
	}

	public String getStrWorkflowId() {
		return strWorkflowId;
	}

	public void setStrWorkflowId(String strWorkflowId) {
		this.strWorkflowId = strWorkflowId;
	}
	
	
}

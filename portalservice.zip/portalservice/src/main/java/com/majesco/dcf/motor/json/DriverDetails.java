package com.majesco.dcf.motor.json;

import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class DriverDetails {
	
	private String mainDriverType;
	private String driverAge;
	private String drivingExperience;
	private String marritalStatus;
	private String isInsurdMainDriver;
	ServiceUtility serviceUtility = new ServiceUtility();
	private String campaignCodeParameter;
	
	public String getCampaignCodeParameter() {
		return campaignCodeParameter;
	}
	public void setCampaignCodeParameter(String campaignCodeParameter) {
		this.campaignCodeParameter = campaignCodeParameter;
	}
	public String getMainDriverType() {
		return mainDriverType;
	}
	public void setMainDriverType(String mainDriverType) {
		mainDriverType = serviceUtility.blankToNullCheck(mainDriverType);
		this.mainDriverType = mainDriverType;
	}
	public String getDriverAge() {
		return driverAge;
	}
	public void setDriverAge(String driverAge) {
		driverAge = serviceUtility.blankToNullCheck(driverAge);
		this.driverAge = driverAge;
	}
	public String getDrivingExperience() {
		return drivingExperience;
	}
	public void setDrivingExperience(String drivingExperience) {
		drivingExperience = serviceUtility.blankToNullCheck(drivingExperience);
		this.drivingExperience = drivingExperience;
	}
	public String getMarritalStatus() {
		return marritalStatus;
	}
	public void setMarritalStatus(String marritalStatus) {
		marritalStatus = serviceUtility.blankToNullCheck(marritalStatus);
		this.marritalStatus = marritalStatus;
	}
	public String getIsInsurdMainDriver() {
		return isInsurdMainDriver;
	}
	public void setIsInsurdMainDriver(String isInsurdMainDriver) {
		isInsurdMainDriver = serviceUtility.blankToNullCheck(isInsurdMainDriver);
		this.isInsurdMainDriver = isInsurdMainDriver;
	}
	
	
}

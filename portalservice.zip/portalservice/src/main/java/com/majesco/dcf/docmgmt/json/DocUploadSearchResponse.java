package com.majesco.dcf.docmgmt.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.ResultObject;

/**
 * 
 * @author vishal662335
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocUploadSearchResponse extends ResponseError {
	
	
	private List<DocUploadDtlsObj>  docUploadDtlsObj;

	public List<DocUploadDtlsObj> getDocUploadDtlsObj() {
		return docUploadDtlsObj;
	}

	public void setDocUploadDtlsObj(List<DocUploadDtlsObj> docUploadDtlsObj) {
		this.docUploadDtlsObj = docUploadDtlsObj;
	}
	
	
	
	
}

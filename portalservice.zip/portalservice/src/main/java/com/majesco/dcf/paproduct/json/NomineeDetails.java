package com.majesco.dcf.paproduct.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class NomineeDetails {
	
	private String insuPerson;
	private String nomName;
	private String nomDOB;
	private String nomAge;
	private String nomGender;
	private String nomRelation;
	private String nomMinor;
	private String nomGaurdian;
	private String nomContribtn;
	private String nomGaurdRelation;
	
	
	public String getInsuPerson() {
		return insuPerson;
	}
	public void setInsuPerson(String insuPerson) {
		this.insuPerson = insuPerson;
	}
	
	
	public String getNomName() {
		return nomName;
	}
	public void setNomName(String nomName) {
		this.nomName = nomName;
	}
	
	
	public String getNomDOB() {
		return nomDOB;
	}
	public void setNomDOB(String nomDOB) {
		this.nomDOB = nomDOB;
	}
	
	
	public String getNomAge() {
		return nomAge;
	}
	public void setNomAge(String nomAge) {
		this.nomAge = nomAge;
	}
	
	
	public String getNomGender() {
		return nomGender;
	}
	public void setNomGender(String nomGender) {
		this.nomGender = nomGender;
	}
	
	
	public String getNomRelation() {
		return nomRelation;
	}
	public void setNomRelation(String nomRelation) {
		this.nomRelation = nomRelation;
	}
	
	
	public String getNomMinor() {
		return nomMinor;
	}
	public void setNomMinor(String nomMinor) {
		this.nomMinor = nomMinor;
	}
	
	
	public String getNomGaurdian() {
		return nomGaurdian;
	}
	public void setNomGaurdian(String nomGaurdian) {
		this.nomGaurdian = nomGaurdian;
	}
	
	
	public String getNomContribtn() {
		return nomContribtn;
	}
	public void setNomContribtn(String nomContribtn) {
		this.nomContribtn = nomContribtn;
	}
	
	
	public String getNomGaurdRelation() {
		return nomGaurdRelation;
	}
	public void setNomGaurdRelation(String nomGaurdRelation) {
		this.nomGaurdRelation = nomGaurdRelation;
	}
	
	

}

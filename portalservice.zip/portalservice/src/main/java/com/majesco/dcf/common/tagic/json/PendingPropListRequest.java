package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include= JsonSerialize.Inclusion.NON_EMPTY)
public class PendingPropListRequest extends UserObject {
	
	private String entityType;
	private String entityCode;
	private String proposalFromDate;
	private String proposalToDate;
	private String policyFromDate;
	private String policyToDate;
	private String userType;
	private String proposalNo;
	private String covernoteNo;
	private String customerID;
	private String vehicleRegNo;
	private String applicationNo;
	private String officeCode;
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getEntityCode() {
		return entityCode;
	}
	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}
	public String getProposalFromDate() {
		return proposalFromDate;
	}
	public void setProposalFromDate(String proposalFromDate) {
		this.proposalFromDate = proposalFromDate;
	}
	public String getProposalToDate() {
		return proposalToDate;
	}
	public void setProposalToDate(String proposalToDate) {
		this.proposalToDate = proposalToDate;
	}
	public String getPolicyFromDate() {
		return policyFromDate;
	}
	public void setPolicyFromDate(String policyFromDate) {
		this.policyFromDate = policyFromDate;
	}
	public String getPolicyToDate() {
		return policyToDate;
	}
	public void setPolicyToDate(String policyToDate) {
		this.policyToDate = policyToDate;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getCovernoteNo() {
		return covernoteNo;
	}
	public void setCovernoteNo(String covernoteNo) {
		this.covernoteNo = covernoteNo;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public String getVehicleRegNo() {
		return vehicleRegNo;
	}
	public void setVehicleRegNo(String vehicleRegNo) {
		this.vehicleRegNo = vehicleRegNo;
	}
	public String getApplicationNo() {
		return applicationNo;
	}
	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}
	public String getOfficeCode() {
		return officeCode;
	}
	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}
}

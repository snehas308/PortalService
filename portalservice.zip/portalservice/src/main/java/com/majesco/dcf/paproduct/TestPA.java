package com.majesco.dcf.paproduct;

import com.majesco.dcf.paproduct.json.IPAProposalDataRequest;
import com.majesco.dcf.paproduct.service.IPAService;
import com.majesco.dcf.paproduct.serviceImpl.IPAServiceImpl;

public class TestPA {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		/*IPAProposalRequest req=new IPAProposalRequest();
		
		req.setApplnDt("ApplicationDate");
		req.setApplnNo("3243423");
		req.setBusinessType("New Business");
		req.setCustCode("C3534433");
		req.setFirstName("First name");
		req.setIntermCd("I325435");
		req.setLastName("lastName");
		req.setInterNm("interNm");
		req.setPartnerApplnDt("partnerApplnDt");
		req.setPolExpiryDt("polExpiryDt");
		req.setPolExpiryTm("polExpiryTm");
		req.setPolInceptionDt("polInceptionDt");
		req.setPolInceptionTm("polInceptionTm");
		req.setPolTerm("polTerm");
		req.setProdCode("prodcode");
		req.setRemarks("remarks");
		req.setTataAIGBranch("tataAIGBranch");
		CustomerDetails custDet=new CustomerDetails();
		req.setProposerDet(custDet);
		CoverageDetails cvg=new CoverageDetails();
		req.setLstcvrgDet(cvg);
		List<InsuredDetails> insuredList=new ArrayList<InsuredDetails>();
		InsuredDetails insured1=new InsuredDetails();
		insuredList.add(insured1);
		InsuredDetails insured2=new InsuredDetails();
		insuredList.add(insured2);
		req.setLstInsurDet(insuredList);
		
		List<NomineeDetails> nomineeList=new ArrayList<NomineeDetails>();
		NomineeDetails nominee1=new NomineeDetails();
		nomineeList.add(nominee1);
		NomineeDetails nominee2=new NomineeDetails();
		nomineeList.add(nominee2);
		req.setLstNomDet(nomineeList);
	
		ObjectMapper objMap=new ObjectMapper();
		System.out.println(objMap.writeValueAsString(req));
		System.out.println("===========================================");
		System.out.println("===========================================");
		
		IPAProposalResponse response=new IPAProposalResponse();
		
		IPAService service = new IPAServiceImpl();
		response = service.getIPAPremiumAG(req);
		
		
		response.setBusinessLocation("90200");
		response.setBussLocName("MUMBAI");
		response.setDepositOfficeCode("0200");
		response.setProposalDate("20/08/2016");
		response.setProposalNumber("P354354353");
		PremiumDetails prmDet=new PremiumDetails();
		response.setPremDet(prmDet);
		response.setResultCode("1");
		List<ResponseError> resErr=new ArrayList<ResponseError>();
		ResponseError respError=new ResponseError();
		resErr.add(respError);
		response.setResErr(resErr);*/
		
		IPAService service = new IPAServiceImpl();
		IPAProposalDataRequest request = new IPAProposalDataRequest();
		request.setPolicyNumber("123");
		request.setIsRenew("Y");
		request.setProductCode("1234");
		request.setProposalNumber("HOC1425");
		request.setQuotaionNumber("QUOT111");
		//service.getIPAProposalDataAG(request);
		//service.getIPAProposalDataAS(request);
		service.getIPAProposalDataSFP(request);
		
		
		//System.out.println(objMap.writeValueAsString(response));
		
	}

}

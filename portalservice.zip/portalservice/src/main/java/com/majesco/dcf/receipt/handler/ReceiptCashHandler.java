package com.majesco.dcf.receipt.handler;

import java.io.PrintWriter;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import java.util.Properties;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.SOAPInfo;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;
import com.majesco.dcf.common.tagic.util.CommonHelper;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyResponse;
import com.majesco.dcf.receipt.json.ReceiptPaymentDetails;
import com.majesco.dcf.receipt.json.ReceiptResponse;
import com.majesco.dcf.receipt.util.ReceiptConstants;
import com.majesco.dcf.util.CXFInBoundInterceptor;
import com.majesco.dcf.util.CXFOutInterceptor;
import com.majesco.dcf.common.chp.util.CdataWriterInterceptor;
import com.unotechsoft.stub.accountservice.client.AccountService;
import com.unotechsoft.stub.accountservice.client.AccountService_Service;
import com.unotechsoft.stub.accountservice.client.ArrayOfClsPolicyIdGrid;
import com.unotechsoft.stub.accountservice.client.ArrayOfKeyValueOfstringint;
import com.unotechsoft.stub.accountservice.client.ArrayOfKeyValueOfstringint.KeyValueOfstringint;
import com.unotechsoft.stub.accountservice.client.ArrayOfKeyValueOfstringstring;
import com.unotechsoft.stub.accountservice.client.ArrayOfUserDataExistPayments;
import com.unotechsoft.stub.accountservice.client.ArrayOfUserDataPaymentEntry;
import com.unotechsoft.stub.accountservice.client.ClsPolicyIdGrid;
import com.unotechsoft.stub.accountservice.client.PaymentEntryCumPolicyGen2;
import com.unotechsoft.stub.accountservice.client.PaymentEntryCumPolicyGenResponse2;
import com.unotechsoft.stub.accountservice.client.PaymentEntryServiceResult;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentEntry;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentTaging;
import com.unotechsoft.stub.accountservice.client.UserDataSubReceipt;

@Service
@Transactional
public class ReceiptCashHandler implements ReceiptHandlerIntf{

	
	final static Logger logger=Logger.getLogger(ReceiptCashHandler.class);
	
	private static Properties prop = new Properties();

	static{
		try{
	InputStream inputStream = TagicCommunicationService.class.getClassLoader().getResourceAsStream("resources.properties");
	prop.load(inputStream);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	
	public  String serviceURL=ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING;


	public ReceiptCumPolicyResponse callReceiptCumPolicyProcess(ReceiptCumPolicyRequest receiptReq,DBService dbService) throws Exception{
		
		ReceiptCumPolicyResponse response=new ReceiptCumPolicyResponse();
		ReceiptPaymentDetails receiptPayDtls=null;
		String localTransId=receiptReq.getProcessTransId();
		ObjectMapper objMap=new ObjectMapper();
		SimpleDateFormat sdfProposalDate = null;
		sdfProposalDate = new SimpleDateFormat("dd/MM/yyyy");
		Date proposalDate = new Date();
		String proposalNumber = null;	//RahulT| user Transaction changes
		//RahulT| Added for HouseBank & Account Number changes
		String officeCode = null;
		String paymentMode = null;
		String pageName = "Portal";
		String accountNo = null;
		String branchCode = null;
		CommonHelper helper = new CommonHelper();
		HashMap paramVal = new HashMap();
		CXFInBoundInterceptor cxfInInterceptor =null;
		CXFOutInterceptor cxfOutInterceptor= null;
		//RahulT| Added for HouseBank & Account Number changes
		try{
			logger.info("Start::"+localTransId+"::ReceiptCashHandler::callReceiptCumPolicyProcess::Entered");
			//if(logger.isDebugEnabled())logger.debug("Input::"+localTransId+"::ReceiptCashHandler::callReceiptCumPolicyProcess::"+objMap.writeValueAsString(receiptReq));
			receiptPayDtls = receiptReq.getPaymentDetails().get(0);
			String userId=receiptReq.getUserID();
			//String userId = ReceiptConstants.DEFAULT_USERID;
			// This is done for testing purpose. Code needs to be removed.
			if(userId == null || userId.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
				userId = ReceiptConstants.DEFAULT_USERID;
			}
			
			/*HashMap accNoHouseBankMap = new HashMap();
			accNoHouseBankMap = dbService.getAccountNoHouseBankBranch("S");*/
				
			
		if(serviceURL==null || serviceURL.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
			serviceURL=dbService.getWSDLURL(ReceiptConstants.ACCOUNTSERVICE_ID,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			//serviceURL="http://172.17.203.45:9393/AccountService_SOAPOverHTTP?wsdl";
			//serviceURL=wsdlURL;
		}
		AccountService_Service accService=new AccountService_Service(new URL(serviceURL));
		
		AccountService accServClient=accService.getSOAPOverHTTP();
		PaymentEntryCumPolicyGen2 polGen2=new PaymentEntryCumPolicyGen2();
		ArrayOfUserDataPaymentEntry userDatPayEntryList=new ArrayOfUserDataPaymentEntry();
		UserDataPaymentEntry userDatPayEntry=new UserDataPaymentEntry();
		//RahulT| Added for HouseBank & Account Number changes
		/*paymentMode = "S";
		officeCode = receiptReq.getProposalDetails().getDepositOfficeCode();
		paramVal = helper.getHouseBankAndAccountNo(accServClient, officeCode, paymentMode, pageName);
		branchCode = (String)paramVal.get("branchCode");
		accountNo = (String)paramVal.get("bankAccountNo");*/ //Commented For Issue ID 2717
		branchCode = (String)receiptPayDtls.getHouseBranchCode(); //Added For Issue ID 2717
		accountNo = (String)receiptPayDtls.getAccountNo(); //Added For Issue ID 2717
		//RahulT| Added for HouseBank & Account Number changes
		
		userDatPayEntry.setAllocationReqd("Y"); // Default to Y
		userDatPayEntry.setBGTag(new Integer(ReceiptConstants.ACCOUNTSERVICE_BGTAG));
		userDatPayEntry.setBckDtVal(ReceiptConstants.ACCOUNTSERVICE_BCKDTVAL);
		userDatPayEntry.setBusinessLocation(Integer.parseInt(receiptReq.getProposalDetails().getBusinessLocation()));
		//userDatPayEntry.setBusinessLocation(Integer.parseInt("90200"));	// RahulT Defaulting done based on sample response file
		userDatPayEntry.setDepositOfficeCode(Integer.parseInt(receiptReq.getProposalDetails().getDepositOfficeCode()));
		//userDatPayEntry.setDepositOfficeCode(Integer.parseInt("90200"));	// RahulT Defaulting done based on sample response file
		userDatPayEntry.setBusinessLocationName(receiptReq.getProposalDetails().getBussLocName());
		userDatPayEntry.setBusinessType(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPE_CASH);
		userDatPayEntry.setBusinessTypeCd(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPECD);
		userDatPayEntry.setCallEnv(ReceiptConstants.ACCOUNTSERVICE_CALLENV);
		userDatPayEntry.setDecimalPaymentAmount(BigDecimal.valueOf(Double.parseDouble(receiptReq.getProposalDetails().getProposalAmount()))); // receiptReq.getProposalDetails().getProposalAmount()
		userDatPayEntry.setGenPolicyNo(ReceiptConstants.ACCOUNTSERVICE_GENPOLNO);
		userDatPayEntry.setMultiCustomerFlag("N"); // Hard coded to N for Cash
		
		userDatPayEntry.setPayerCustomerId(receiptReq.getProposalDetails().getCustomerId());
		userDatPayEntry.setPayerName(receiptReq.getProposalDetails().getCustomerName());
		userDatPayEntry.setPayerTypeCd(Integer.parseInt(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CD));
		userDatPayEntry.setPayerType(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CASH);
		userDatPayEntry.setPaymentMode(ReceiptConstants.ACCOUNTSERVICE_PAYMENT_MODE_CASH);
		userDatPayEntry.setPaymentType(Long.parseLong("-1")); // Hard coded to -1 as it's mandatory to GC
		//userDatPayEntry.setModeForSearch("D"); /*Commented For Issue ID 1155*/
		/*Added For Issue ID 1155 - Starts Here*/
		if(receiptReq!=null && receiptReq.getProposalDetails()!=null && receiptReq.getProposalDetails().getModeOfSearch()!=null && !receiptReq.getProposalDetails().getModeOfSearch().equals(""))
		{
			userDatPayEntry.setModeForSearch(receiptReq.getProposalDetails().getModeOfSearch());
		}
		else
		{
			userDatPayEntry.setModeForSearch(ReceiptConstants.ACCOUNTSERVICE_MODE_FOR_SEARCH_D);
		}
		/*Added For Issue ID 1155 - Ends Here*/
		Date date = new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a", Locale.US);
		// RahulT: corrected date format based on sample request provided on 23/09/2016
		Date dateFormat_PayTag = new Date();
		SimpleDateFormat sdf_transTime = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss", Locale.US);
		
		Date payDate=new Date();
		SimpleDateFormat sdfPay=new SimpleDateFormat("dd/MM/yyyy", Locale.US);
		
//		if(receiptReq.getProposalDetails()!=null && receiptReq.getProposalDetails().getProposalDate()!=null){
//			proposalDate = new Date(receiptReq.getProposalDetails().getProposalDate());
//		}
		
		//Changes done to handle data type issue
		Double payAmount=new Double(receiptPayDtls.getPaymentAmount());
		userDatPayEntry.setPaymentAmount(payAmount.longValue());
		//userDatPayEntry.setPaymentDate(sdfPay.format(payDate)); /*commented for Issue ID 1258*/
		/*Added for Issue ID 1258 - Starts Here*/
		if(receiptReq!=null && receiptReq.getProposalDetails()!=null && receiptReq.getProposalDetails().getPolicyEffDt()!=null && !receiptReq.getProposalDetails().getPolicyEffDt().equals(""))
		{
			SimpleDateFormat sdfDateChk = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat sdfDateIssue=new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a", Locale.US);
			SimpleDateFormat sdfDat=new SimpleDateFormat("dd/MM/yyyy", Locale.US);
			Date currentDate = new Date();
			Date date1 = sdfDateChk.parse(receiptReq.getProposalDetails().getPolicyEffDt());
			Date d2 = new Date();
			String dt2 = sdfDateChk.format(d2);
			Date date2 = sdfDateChk.parse(dt2);
			
			
			
			if(date1.compareTo(date2) < 0) /*If date is less than current date*/
	        {
				userDatPayEntry.setPaymentDate(receiptReq.getProposalDetails().getPolicyEffDt());
				userDatPayEntry.setReceiptDate(sdfDateIssue.format(sdfDat.parse(receiptReq.getProposalDetails().getPolicyEffDt())));
				userDatPayEntry.setDepositAdviceDate(sdfDateIssue.format(sdfDat.parse(receiptReq.getProposalDetails().getPolicyEffDt())));
	        }
			else if(date1.compareTo(date2) > 0) /*If date is greater than current date*/
	        {
				userDatPayEntry.setPaymentDate(sdfDateChk.format(currentDate));
				userDatPayEntry.setReceiptDate(sdf.format(date));
				userDatPayEntry.setDepositAdviceDate(sdf.format(date));
	        }
			else if(date1.compareTo(date2) == 0) /*If date is equal to current date*/
			{
				userDatPayEntry.setPaymentDate(sdfDateChk.format(currentDate));
				userDatPayEntry.setReceiptDate(sdf.format(date));
				userDatPayEntry.setDepositAdviceDate(sdf.format(date));
			}
		}
		else
		{
			userDatPayEntry.setPaymentDate(sdfPay.format(payDate));
		}
		/*Added for Issue ID 1258 - Ends Here*/
		
		if(receiptReq.getProducerCode()!=null && !receiptReq.getProducerCode().equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
		userDatPayEntry.setProducerCode(receiptReq.getProducerCode());
		}else{
		userDatPayEntry.setProducerCode(ReceiptConstants.DEFAULT_PRODUCERCODE);
		}
		
		//String currentDateInString = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new java.util.Date());
		if(receiptReq.getProposalDetails()!=null && receiptReq.getProposalDetails().getProposalSystemId() == null){
			//setting dummy transaction ID
			String transID = "5454678755";
			receiptReq.getProposalDetails().setProposalSystemId(transID);
		}
		
         //Code changes for defect 1434
	 	//userDatPayEntry.setReceiptDate(sdf.format(date)); /*Commented For Defect ID 1258*/
		userDatPayEntry.setTransactionType(Integer.parseInt(ReceiptConstants.ACCOUNTSERVICE_TRANS_TYPE_CASH));
		userDatPayEntry.setTransactionTime(sdf.format(date));
		userDatPayEntry.setTransactionId(Long.parseLong(receiptReq.getProposalDetails().getProposalSystemId()));
		userDatPayEntry.setUserRole(ReceiptConstants.DEFAULT_GC_ROLE);
		userDatPayEntry.setUserId(userId);
		//Setting other default values required in GC
				userDatPayEntry.setAcceptanceDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setAcceptanceVoucherNumber(new Long(0));
				userDatPayEntry.setAuthorizationCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setBackDateAcc(new Long(0));
				userDatPayEntry.setBalanceAmount(new Long(0));
				userDatPayEntry.setBankAccountNo(accountNo);	// RahulT Defaulting done for some extra fields
				//userDatPayEntry.setBankAccountNo("983009830"); // Defaulted to 983009830. Master to be shared by TAGIC as per mail on 10/09/2016
				userDatPayEntry.setBankCode(new Long(0));
				userDatPayEntry.setBankName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setBatchDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setBatchNumber(new Long(0));
				userDatPayEntry.setCMSSlipNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setCardHolderName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setConversionAmount(new BigDecimal(0));
				userDatPayEntry.setCounterNo(new Integer(0));
				userDatPayEntry.setCurrencyAmount(new BigDecimal(0));
				userDatPayEntry.setCurrencyConcateString(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setCurrencyConvertRate(new BigDecimal(0));
				userDatPayEntry.setDealerCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setDealerName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				//userDatPayEntry.setDepositAdviceDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				//userDatPayEntry.setDepositAdviceDate(sdf.format(date)); // Defaulted to system date as per logic provided by TAGIC on 10/09/2016 /*Commented For Issue ID 1258*/
				userDatPayEntry.setDeptCode(new Long(0));
				userDatPayEntry.setDraweeBankLoc(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setEnable_Pol_Issue_Role_Wise(false);
				userDatPayEntry.setEncodedCardNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setEntryDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setExpiryDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setForeignCurrencyAmount(new BigDecimal(0));
				userDatPayEntry.setHoRefDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setHoRefNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				//userDatPayEntry.setHouseBankBranchCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setHouseBankBranchCode(branchCode); // Defaulted 10001 as per mail from TAGIC on 10/09/2016. To be changed once master is received.
				userDatPayEntry.setIFSCCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setILPosPaymentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setITSPaymentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setInsertedTransID(new Long(0));
				userDatPayEntry.setInsertedTransIDDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setInstrumentType(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setInstrumentTypeCd(new Integer(0));
				if(receiptReq.getProducerCode()!=null && !receiptReq.getProducerCode().equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
					userDatPayEntry.setIntermediaryCode(receiptReq.getProducerCode());
				}else{
				userDatPayEntry.setIntermediaryCode(ReceiptConstants.DEFAULT_PRODUCERCODE);
				}
				userDatPayEntry.setIntermediaryName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setInvoiceId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				//userDatPayEntry.setInwardNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setInwardNumber("0");	//RahulT Defaulting done for some extra fields
				userDatPayEntry.setIsAcceptanceApplicable(false);
				userDatPayEntry.setIsDepositSlipNoGenerate(false);
				userDatPayEntry.setIsPortalReceipt(false);
				userDatPayEntry.setMICRNumber("0");
				userDatPayEntry.setMICRTag(0);
				userDatPayEntry.setMerchantId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setModifiedTransID(new Long(0));
				userDatPayEntry.setModifiedTransIDDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setMonthEndExtension(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setMultiCustomerApplicability(true); // Hard coded to true
				userDatPayEntry.setMultiCustomerConcat(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				//userDatPayEntry.setMultiCustomerFlag("N"); // Already hard coded at set to N
				userDatPayEntry.setNsurPlusPaymentID(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setPayinSlipDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setPayinSlipNumber(new Long(0));
				userDatPayEntry.setPaymentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setPolicyNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setPostAuthCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setPropCount(0);
				userDatPayEntry.setReconcileDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setRelationShip(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setRemarks(ReceiptConstants.ACCOUNTSERVICE_REMARKS); // Defaulted to generic remark provide by TAGIC on 10/09/2016
				userDatPayEntry.setStatus(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setTAGICAccNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setVoucherNoAlternation(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setYNOthersType(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				//Start: RahulT Defaulting done for some extra fields
				userDatPayEntry.setBGId(new Long(0));
				userDatPayEntry.setBounceReason(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setBranchCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setBranchName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setPaymentNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setVoucherNoMiscTransfer(new Long(0));
				//End: RahulT Defaulting done for some extra fields

		ArrayOfKeyValueOfstringint arrKeyValNote=new ArrayOfKeyValueOfstringint();
		KeyValueOfstringint keyValTotalAmount=new KeyValueOfstringint();
		keyValTotalAmount.setKey(ReceiptConstants.ACCOUNTSERVICE_TotalAmount);
		keyValTotalAmount.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTotalAmount);
		
		
		KeyValueOfstringint keyValThousand=new KeyValueOfstringint();
		keyValThousand.setKey(ReceiptConstants.ACCOUNTSERVICE_Thousand);
		keyValThousand.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValThousand);
		
		
		KeyValueOfstringint keyValFivehundred=new KeyValueOfstringint();
		keyValFivehundred.setKey(ReceiptConstants.ACCOUNTSERVICE_Fivehundred);
		keyValFivehundred.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValFivehundred);
		
		
		KeyValueOfstringint keyValHundred=new KeyValueOfstringint();
		keyValHundred.setKey(ReceiptConstants.ACCOUNTSERVICE_Hundred);
		keyValHundred.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValHundred);
		
		
		KeyValueOfstringint keyValFifty=new KeyValueOfstringint();
		keyValFifty.setKey(ReceiptConstants.ACCOUNTSERVICE_Fifty);
		keyValFifty.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValFifty);
		
		KeyValueOfstringint keyValTwenty=new KeyValueOfstringint();
		keyValTwenty.setKey(ReceiptConstants.ACCOUNTSERVICE_Twenty);
		keyValTwenty.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTwenty);
		
		KeyValueOfstringint keyValTen=new KeyValueOfstringint();
		keyValTen.setKey(ReceiptConstants.ACCOUNTSERVICE_Ten);
		keyValTen.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTen);
		
		KeyValueOfstringint keyValFive=new KeyValueOfstringint();
		keyValFive.setKey(ReceiptConstants.ACCOUNTSERVICE_Five);
		keyValFive.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValFive);
		
		KeyValueOfstringint keyValTwo=new KeyValueOfstringint();
		keyValTwo.setKey(ReceiptConstants.ACCOUNTSERVICE_Two);
		keyValTwo.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTwo);
		
		KeyValueOfstringint keyValOne=new KeyValueOfstringint();
		keyValOne.setKey(ReceiptConstants.ACCOUNTSERVICE_One);
		keyValOne.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValOne);
		
		userDatPayEntry.setNoteNumber(arrKeyValNote);
		
		userDatPayEntryList.getUserDataPaymentEntry().add(userDatPayEntry);
		polGen2.setObjLVUserDataPEntryLst(userDatPayEntryList);
		
		UserDataSubReceipt subReceipt=new UserDataSubReceipt();
		subReceipt.setCallSLEnv(ReceiptConstants.ACCOUNTSERVICE_CALLENV);
		subReceipt.setTransactionID(receiptReq.getProposalDetails().getProposalSystemId());
		subReceipt.setUserID(userId);
		polGen2.setObjUserDataSubReceipt(subReceipt);
		
		UserDataPaymentTaging payTag=new UserDataPaymentTaging();
		payTag.setBusinessType(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPECD);
		payTag.setCallSLEnv(ReceiptConstants.ACCOUNTSERVICE_CALLENV);
		payTag.setCheckAutopayment(1); // Hard coded to 1 for CASH
		payTag.setCheckAutoProposal(1); // Hard coded to 1 for CASH
		ArrayOfClsPolicyIdGrid proposalGrid=new ArrayOfClsPolicyIdGrid();
		ClsPolicyIdGrid policyGrid=new ClsPolicyIdGrid();
		policyGrid.setBankCharge("0");
		policyGrid.setIsChecked(true);
		//policyGrid.setProposalDate(sdfProposalDate.format(proposalDate));
		/*if(receiptReq.getProposalDetails()!=null && receiptReq.getProposalDetails().getProposalDate()!=null)
		{
			//proposalDate = new Date(receiptReq.getProposalDetails().getProposalDate());
			String dt = receiptReq.getProposalDetails().getProposalDate(); 
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(sdf1.parse(dt));
			//p2Dto.setPropRisksExpirydate(sdf.format(c.getTime()));
			policyGrid.setProposalDate(sdf1.format(c.getTime()));
		}*/ /*Commented For Issue ID 1258*/
		//policyGrid.setProposalDate(sdfProposalDate.format(proposalDate));/*Added For Issue ID 1258*/ /*Commented For  Issue ID 1576*/
		/*Added For Issue ID 1576 Starts Here*/
		SimpleDateFormat sdfPropDate = null;
		sdfPropDate = new SimpleDateFormat("dd/MM/yyyy");
		Date propDate = new Date();
		if(receiptReq!=null && receiptReq.getIsManualCovernoteChk()!=null && receiptReq.getIsManualCovernoteChk().equalsIgnoreCase("true"))
		{
			policyGrid.setProposalDate(sdfPropDate.format(propDate));
		}
		else
		{
			policyGrid.setProposalDate(receiptReq.getProposalDetails().getProposalDate());
		}
		/*Added For Issue ID 1576 Ends Here*/
		policyGrid.setProposalNo(receiptReq.getProposalDetails().getProposalNo());
		payTag.setModeOfEntry(ReceiptConstants.ACCOUNTSERVICE_BGTAG);
		payTag.setOfficeCode(receiptReq.getProposalDetails().getDepositOfficeCode());
		payTag.setPayerId(receiptReq.getProposalDetails().getCustomerId());
		//payTag.setPayerType(receiptPayDtls.getPayerType());
		payTag.setPayerType("1");
		payTag.setProposalId(receiptReq.getProposalDetails().getProposalNo());
		payTag.setTransactionId(receiptReq.getProposalDetails().getProposalSystemId());
		payTag.setTransactionTime(sdf_transTime.format(dateFormat_PayTag));
		payTag.setUserId(userId);
		
		//Defaulting other values for paytag
		payTag.setAutoAcceptanceApplicable(0);
		payTag.setBankChargeAmt(new Long(0));
		payTag.setDealerId("0");
		payTag.setDealerName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		payTag.setFinancierID("0");
		payTag.setGenPolicy(0);
		payTag.setInstrumentAmount(new Long(0));
		payTag.setInstrumentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		payTag.setIntermediaryId("0");
		payTag.setIs64VbAllowed(false);
		payTag.setIsAutoPaymentChecked(false);
		payTag.setIsAutoPropChecked(false);
		payTag.setIsCreditPolicy(false);
		payTag.setIsShortFallNonAllowedFlg(false);
		payTag.setIsShortPremAllowedFlg(false);
		payTag.setMaxPremium(new Long(0));
		payTag.setMonthlyExtension(0);
		payTag.setOtherBankApplicability("0");
		payTag.setProposalUnPaidAmount(new Long(0));
		payTag.setShortPremium("0");
		payTag.setTagSequence(0);
		payTag.setTotalInstrumentBalanceAmount(new Long(0));
		payTag.setWorkflowName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		payTag.setProposalAmount(new Long(0));
		
		
		
		proposalGrid.getClsPolicyIdGrid().add(policyGrid);
		payTag.setClsProposalDetailsGrd(proposalGrid);
		
		polGen2.setObjUserDataPaymentTaging(payTag);
		
		
		ArrayOfKeyValueOfstringstring arrLVWF=new ArrayOfKeyValueOfstringstring();
		
		/*KeyValueOfstringstring keyValue1=new KeyValueOfstringstring();
		keyValue1.setKey(ReceiptConstants.ACCOUNTSERVICE_GUID_WORKFLOW_KEY);
		keyValue1.setValue(ReceiptConstants.ACCOUNTSERVICE_GUID_WORKFLOW_VALUE);
		arrLVWF.getKeyValueOfstringstring().add(keyValue1);
		
		KeyValueOfstringstring keyValue2=new KeyValueOfstringstring();
		keyValue2.setKey(ReceiptConstants.ACCOUNTSERVICE_CURRENT_STATE_KEY);
		keyValue2.setValue(ReceiptConstants.ACCOUNTSERVICE_CURRENT_STATE_VALUE);
		arrLVWF.getKeyValueOfstringstring().add(keyValue2);
		
		KeyValueOfstringstring keyValue3=new KeyValueOfstringstring();
		keyValue3.setKey(ReceiptConstants.ACCOUNTSERVICE_PAGE_ACTION_KEY);
		keyValue3.setValue(ReceiptConstants.ACCOUNTSERVICE_PAGE_ACTION_VALUE);
		arrLVWF.getKeyValueOfstringstring().add(keyValue3);
		
		KeyValueOfstringstring keyValue4=new KeyValueOfstringstring();
		keyValue4.setKey(ReceiptConstants.ACCOUNTSERVICE_WORKFLOW_NAME_KEY);
		keyValue4.setValue(ReceiptConstants.ACCOUNTSERVICE_WORKFLOW_NAME_VALUE);
		arrLVWF.getKeyValueOfstringstring().add(keyValue4);*/
		
		ArrayOfUserDataExistPayments existPayment = new ArrayOfUserDataExistPayments();
		
		polGen2.setLstExistPayments(existPayment);
		polGen2.setDicLVWFParams(null);
				
		
		polGen2.setSource(prop.getProperty("smc.source"));
		polGen2.setCampaign(prop.getProperty("smc.medium"));
		polGen2.setMedium(prop.getProperty("smc.campaign"));
		polGen2.setStrLVTokenID(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		
		proposalNumber = receiptReq.getProposalDetails().getProposalNo();	//RahulT| User transaction changes
		
		/*Client client=ClientProxy.getClient(accServClient);
		PrintWriter writer = new PrintWriter(System.out);
		
		client.getOutInterceptors().add(new CdataWriterInterceptor());
		
		client.getInInterceptors().add(new LoggingInInterceptor(writer));
		
		client.getOutInterceptors().add(new LoggingOutInterceptor(writer));*/
		
		// Code added to save info abt SOAP in DB Start
		SOAPInfo soapInfo = new SOAPInfo();
		soapInfo.setTransactionID(Long.parseLong(receiptReq.getProcessTransId()));
		soapInfo.setLobService("paymentEntryCumPolicyGen");
		soapInfo.setLobtype(receiptReq.getStrLOB());
		soapInfo.setCreatedBy(receiptReq.getUserID());
		soapInfo.setProducerCode(receiptReq.getProducerCode());
		soapInfo.setSystemIP(receiptReq.getSystemIP());
		soapInfo.setTransactionEvent(CommonConstants.POLICY_CREATION_EVENT);
		soapInfo.setJsonRequest(objMap.writeValueAsString(receiptReq));
		if(receiptReq.getProposalDetails()!=null)
		soapInfo.setProductCode(receiptReq.getProposalDetails().getProductCode());
		
		
		cxfInInterceptor =new CXFInBoundInterceptor(soapInfo);
		cxfOutInterceptor= new CXFOutInterceptor(soapInfo);
		
		ServiceUtility utility = new ServiceUtility();
		utility.addClientInterceptorDB(accServClient,cxfInInterceptor,cxfOutInterceptor);
		
		//if(logger.isDebugEnabled())logger.debug("Start::"+localTransId+"::ReceiptCashHandler::Calling AccountService-->paymentEntryCumPolicyGen::Entered");
		PaymentEntryCumPolicyGenResponse2 receiptResponse=accServClient.paymentEntryCumPolicyGen(polGen2);
		//if(logger.isDebugEnabled())logger.debug("End::"+localTransId+"::ReceiptCashHandler::After Calling AccountService-->paymentEntryCumPolicyGen::Exit");
		
		//if(logger.isDebugEnabled())logger.debug("Adding Out Logs to DB");
		dbService.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
		//if(logger.isDebugEnabled())logger.debug("Adding In Logs to DB");
		dbService.saveInSoapInfo(cxfInInterceptor.getInBound());				
		
//Code end for Saving SOAP Data to DB.	
		
		PaymentEntryServiceResult payResult=null;
				
		payResult=receiptResponse.getReturn();
		if(payResult!=null && payResult.getErrorCode()!=null && payResult.getErrorCode().equalsIgnoreCase("0") && payResult.getErrorMsg()!=null && payResult.getErrorMsg().equalsIgnoreCase("-1")){
			
		response.setPolicyNo(payResult.getPolicyNo());
		ReceiptResponse receiptRes=new ReceiptResponse();
		receiptRes.setReceiptNo(payResult.getNewlyCreatedReceipts());
		receiptRes.setSubReceiptId(payResult.getTaggedSubReceipt());
		
		response.setReceiptDtls(receiptRes);
		response.setResultCode("1");

		dbService.updateUserTransForPolicy(response.getPolicyNo(),proposalNumber);	//RahulT| user transaction changes		
		
		}else if(payResult!=null && payResult.getErrorMsg()!=null && !payResult.getErrorMsg().equalsIgnoreCase("-1") && payResult.getErrorCode()!=null && !payResult.getErrorCode().equalsIgnoreCase("0")){
			response.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError error=new ResponseError();
			error.setErrorCode(payResult.getErrorCode());
			error.setErrorMMessag(payResult.getErrorMsg());
			errorList.add(error);
			response.setErrorList(errorList);
		}
		
		}catch(Exception ex){
			logger.error("Exception::"+localTransId+"::ReceiptCashHandler::callReceiptCumPolicyProcess::Exit", ex);
			response.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError error=new ResponseError();
			error.setErrorCode("ERR01");
			error.setErrorMMessag("Failed to call service !!."+ex.getMessage()+".Transaction ID "+localTransId);
			errorList.add(error);
			response.setErrorList(errorList);
		}
		//if(logger.isDebugEnabled())logger.debug("Response::"+localTransId+"::ReceiptCashHandler::callReceiptCumPolicyProcess::"+objMap.writeValueAsString(response));
		logger.info("End::"+localTransId+"::ReceiptCashHandler::callReceiptCumPolicyProcess::Exit");
		
		if(cxfInInterceptor!=null){
			cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(response));
			cxfInInterceptor.getInBound().setStrrefno(receiptReq.getProposalDetails().getProposalNo() == null ? "":receiptReq.getProposalDetails().getProposalNo());
			dbService.saveInSoapInfo(cxfInInterceptor.getInBound());	
		}					
        if(cxfOutInterceptor!=null){
			cxfOutInterceptor.getOutBound().setStrrefno(receiptReq.getProposalDetails().getProposalNo() == null ? "":receiptReq.getProposalDetails().getProposalNo());						
			dbService.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
		}
		return response;
	}
	
	public ReceiptCumPolicyResponse createReceipt(ReceiptCumPolicyRequest receiptReq,DBService dbService) throws Exception{
		
	//Method to be implemented at later stage.
		
		return null;
	}
}

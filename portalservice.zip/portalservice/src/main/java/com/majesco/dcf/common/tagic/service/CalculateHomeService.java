package com.majesco.dcf.common.tagic.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.chp.dozer.CommonRequest;
import com.majesco.dcf.common.tagic.json.CalculateHomeRequest;
import com.majesco.dcf.common.tagic.json.CalculateHomeResponse;
import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;


//@RunWith(SpringJUnit4ClassRunner.class)
@Service
public class CalculateHomeService {

	final static Logger logger = Logger.getLogger(CalculateHomeService.class);
	
    
	public CalculateHomeResponse CalculatePremiumHome(CalculateHomeRequest quickReq) throws Exception
	{	
		
		logger.info("Inside CalculateHomeService :: CalculatePremiumHome method :: Execution Started");
		
		List<ResponseError> reserrList; 
		List<String> list = new ArrayList<String>();
		list.add("RequestMapping.xml");
		CalculateHomeResponse quicRes =  new CalculateHomeResponse(); 
		quicRes.setResult("OK");
		quicRes.setQuotationNumber("101010");
		quicRes.setQuotationVersion("1");
		
		reserrList = new ArrayList<ResponseError>();
		
		List<PremiumDetails> premiumdetails;
		PremiumDetails predet = new PremiumDetails();
		predet.setDiscount("10");
		predet.setNetPremium("100");
		predet.setPremiumPayable("200");
		predet.setServiceTax("6");
		predet.setSumInsured("50000");
		predet.setTotalPremium("5000");
		predet.setPremRate("5");
		
		
		
		
		Mapper mapper = (Mapper) new DozerBeanMapper(list);
		//System.out.println("Mapper mapper = (Mapper) new DozerBeanMapper(Arrays.asList(new String[]{resource}));");

		try
		{
			CommonRequest p1Dto = new CommonRequest();
			mapper.map(quickReq, p1Dto,"HomeReq");
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		premiumdetails = new ArrayList<PremiumDetails>();
		
		premiumdetails.add(predet);
		
			ResponseError res = new ResponseError();
			res.setErrorCode("101");
			reserrList.add(res);
		
		quicRes.setErrorList(reserrList);
		quicRes.setPremiumDetails(premiumdetails);	
		
		logger.info("Inside CalculateHomeService :: CalculatePremiumHome method :: Execution Completed Successfully");
		
		return quicRes;
	}
	
	
	
}

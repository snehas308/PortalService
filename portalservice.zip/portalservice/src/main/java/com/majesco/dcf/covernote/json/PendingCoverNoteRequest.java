package com.majesco.dcf.covernote.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PendingCoverNoteRequest extends UserObject{
	private String riskStartDate;
	private String riskendDate;
	private String proposalFromDate;
	private String proposalToDate;
	private String coverNoteNo;
	private String proposalNo;
	private String custId;
	public String getRiskStartDate() {
		return riskStartDate;
	}
	public void setRiskStartDate(String riskStartDate) {
		this.riskStartDate = riskStartDate;
	}
	public String getRiskendDate() {
		return riskendDate;
	}
	public void setRiskendDate(String riskendDate) {
		this.riskendDate = riskendDate;
	}
	public String getProposalFromDate() {
		return proposalFromDate;
	}
	public void setProposalFromDate(String proposalFromDate) {
		this.proposalFromDate = proposalFromDate;
	}
	public String getProposalToDate() {
		return proposalToDate;
	}
	public void setProposalToDate(String proposalToDate) {
		this.proposalToDate = proposalToDate;
	}
	public String getCoverNoteNo() {
		return coverNoteNo;
	}
	public void setCoverNoteNo(String coverNoteNo) {
		this.coverNoteNo = coverNoteNo;
	}
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}

}

package com.majesco.dcf.common.tagic.json;
import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class SubCategoryRequest {
	private String strlobcd;
	private String strprodcd;
	private String strservreqcatcd;
	public String getStrlobcd() {
		return strlobcd;
	}
	public void setStrlobcd(String strlobcd) {
		this.strlobcd = strlobcd;
	}
	public String getStrprodcd() {
		return strprodcd;
	}
	public void setStrprodcd(String strprodcd) {
		this.strprodcd = strprodcd;
	}
	public String getStrservreqcatcd() {
		return strservreqcatcd;
	}
	public void setStrservreqcatcd(String strservreqcatcd) {
		this.strservreqcatcd = strservreqcatcd;
	}
	
}

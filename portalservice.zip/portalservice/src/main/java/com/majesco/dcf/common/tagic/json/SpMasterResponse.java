package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class SpMasterResponse {
	private List<SpDetails> spDetailsList;

	public List<SpDetails> getSpDetailsList() {
		return spDetailsList;
	}

	public void setSpDetailsList(List<SpDetails> spDetailsList) {
		this.spDetailsList = spDetailsList;
	}
	
	
	}

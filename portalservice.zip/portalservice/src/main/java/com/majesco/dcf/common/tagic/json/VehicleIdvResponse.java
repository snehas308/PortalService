package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class VehicleIdvResponse {
	
	private List<BigDecimal> nidv;
	private List<BigDecimal> nvehiclesellingprice;
	private List<BigDecimal> nvehiclechassisprice;
	private List<BigDecimal> nlocationexshowroomprice;
	
	public List<BigDecimal> getNvehiclesellingprice() {
		return nvehiclesellingprice;
	}
	public void setNvehiclesellingprice(List<BigDecimal> lstnvehiclesellingprice) {
		this.nvehiclesellingprice = lstnvehiclesellingprice;
	}
	public List<BigDecimal> getNvehiclechassisprice() {
		return nvehiclechassisprice;
	}
	public void setNvehiclechassisprice(List<BigDecimal> lstnvehiclechassisprice) {
		this.nvehiclechassisprice = lstnvehiclechassisprice;
	}
	public List<BigDecimal> getNlocationexshowroomprice() {
		return nlocationexshowroomprice;
	}
	public void setNlocationexshowroomprice(List<BigDecimal> lstnlocationexshowroomprice) {
		this.nlocationexshowroomprice = lstnlocationexshowroomprice;
	}
	public List<BigDecimal> getNidv() {
		return nidv;
	}
	public void setNidv(List<BigDecimal> lstnidv) {
		this.nidv = lstnidv;
	}
	
	private List<ResponseError> resErr;
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}

}

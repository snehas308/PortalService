package com.majesco.dcf.claims.service;

import com.majesco.dcf.claims.json.ClaimServiceValidateSaveRequest;
import com.majesco.dcf.claims.json.ClaimServiceValidateSaveResponse;
import com.majesco.dcf.claims.json.CoverageSearchRequest;
import com.majesco.dcf.claims.json.CoverageSearchResponse;
import com.majesco.dcf.claims.json.PolicyDetailsSearchRequest;
import com.majesco.dcf.claims.json.PolicyDetailsSearchResponse;
import com.majesco.dcf.claims.json.PolicySearchCoverNoteRequest;
import com.majesco.dcf.claims.json.PolicySearchCoverNoteResponse;


public interface ClaimService 
{
	
	public PolicySearchCoverNoteResponse getClaimServiceGetLOV(PolicySearchCoverNoteRequest cvrNoteClaimReq) throws Exception;
	
	public PolicyDetailsSearchResponse getClaimServiceFetchGeneralDetails(PolicyDetailsSearchRequest polDetSearchReq) throws Exception;
	
	public CoverageSearchResponse getClaimServiceGetLOV(CoverageSearchRequest cvrgSearchReq) throws Exception;
	
	public ClaimServiceValidateSaveResponse getClaimServiceValidateSave(ClaimServiceValidateSaveRequest claimServValidateSaveReq) throws Exception;

}

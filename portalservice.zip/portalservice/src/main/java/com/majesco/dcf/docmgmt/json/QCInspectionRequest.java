package com.majesco.dcf.docmgmt.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

/**
 * @author ketan570156
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class QCInspectionRequest extends UserObject{
	
	private String proposalNummber;
	private String policyNumber;
	private String fromDate;
	private String toDate;
	private String seqID;
	public String getProposalNummber() {
		return proposalNummber;
	}
	public void setProposalNummber(String proposalNummber) {
		this.proposalNummber = proposalNummber;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getSeqID() {
		return seqID;
	}
	public void setSeqID(String seqID) {
		this.seqID = seqID;
	}
	
}

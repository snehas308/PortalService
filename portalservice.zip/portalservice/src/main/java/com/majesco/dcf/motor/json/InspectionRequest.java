package com.majesco.dcf.motor.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.CustomerDetails;
import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class InspectionRequest extends UserObject{

	private String productCode;
	private String newPolStartDate;
	private String strcustID;
	private String strcustName;
	private String printFlag;
	private String isHardCopyReq;
	private CustomerDetails lstcustDet;
	private RiskDetails lstRiskdet;
	private VehicleRegDetails lstvecReg;
	private VehicleAdditionalDetails lsdaddDet;
	private DiscountDeatils lstdiscdet;
	private AddOnCoverDetails lstAddonCover;
	private PrevExistingPolDetails prvExisPolDet;
	private DriverDetails lstDrivrDet;
	private InsuredDetails lstInsuDet;
	private NomineeDetails lstNomDet;
	private ChannelDetails lstChanlDet;
	private CoverNoteDetails lstCvrNtDet;
	private DocumentChecklistDetails lstDocChkDet;
	private PreInspectionResultDetails lstPreInspResDet;
	private String proposalNo;
	private String policyNo;
	private String workFlowId;
	private String modeOfOperation;
	
	public String getModeOfOperation() {
		return modeOfOperation;
	}
	public void setModeOfOperation(String modeOfOperation) {
		this.modeOfOperation = modeOfOperation;
	}
	public String getWorkFlowId() {
		return workFlowId;
	}
	public void setWorkFlowId(String workFlowId) {
		this.workFlowId = workFlowId;
	}
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getNewPolStartDate() {
		return newPolStartDate;
	}
	public void setNewPolStartDate(String newPolStartDate) {
		this.newPolStartDate = newPolStartDate;
	}
	public String getStrcustID() {
		return strcustID;
	}
	public void setStrcustID(String strcustID) {
		this.strcustID = strcustID;
	}
	public String getStrcustName() {
		return strcustName;
	}
	public void setStrcustName(String strcustName) {
		this.strcustName = strcustName;
	}
	public String getPrintFlag() {
		return printFlag;
	}
	public void setPrintFlag(String printFlag) {
		this.printFlag = printFlag;
	}
	public String getIsHardCopyReq() {
		return isHardCopyReq;
	}
	public void setIsHardCopyReq(String isHardCopyReq) {
		this.isHardCopyReq = isHardCopyReq;
	}
	public CustomerDetails getLstcustDet() {
		return lstcustDet;
	}
	public void setLstcustDet(CustomerDetails lstcustDet) {
		this.lstcustDet = lstcustDet;
	}
	public RiskDetails getLstRiskdet() {
		return lstRiskdet;
	}
	public void setLstRiskdet(RiskDetails lstRiskdet) {
		this.lstRiskdet = lstRiskdet;
	}
	public VehicleRegDetails getLstvecReg() {
		return lstvecReg;
	}
	public void setLstvecReg(VehicleRegDetails lstvecReg) {
		this.lstvecReg = lstvecReg;
	}
	public VehicleAdditionalDetails getLsdaddDet() {
		return lsdaddDet;
	}
	public void setLsdaddDet(VehicleAdditionalDetails lsdaddDet) {
		this.lsdaddDet = lsdaddDet;
	}
	public DiscountDeatils getLstdiscdet() {
		return lstdiscdet;
	}
	public void setLstdiscdet(DiscountDeatils lstdiscdet) {
		this.lstdiscdet = lstdiscdet;
	}
	public AddOnCoverDetails getLstAddonCover() {
		return lstAddonCover;
	}
	public void setLstAddonCover(AddOnCoverDetails lstAddonCover) {
		this.lstAddonCover = lstAddonCover;
	}
	public PrevExistingPolDetails getPrvExisPolDet() {
		return prvExisPolDet;
	}
	public void setPrvExisPolDet(PrevExistingPolDetails prvExisPolDet) {
		this.prvExisPolDet = prvExisPolDet;
	}
	public DriverDetails getLstDrivrDet() {
		return lstDrivrDet;
	}
	public void setLstDrivrDet(DriverDetails lstDrivrDet) {
		this.lstDrivrDet = lstDrivrDet;
	}
	public InsuredDetails getLstInsuDet() {
		return lstInsuDet;
	}
	public void setLstInsuDet(InsuredDetails lstInsuDet) {
		this.lstInsuDet = lstInsuDet;
	}
	public NomineeDetails getLstNomDet() {
		return lstNomDet;
	}
	public void setLstNomDet(NomineeDetails lstNomDet) {
		this.lstNomDet = lstNomDet;
	}
	public ChannelDetails getLstChanlDet() {
		return lstChanlDet;
	}
	public void setLstChanlDet(ChannelDetails lstChanlDet) {
		this.lstChanlDet = lstChanlDet;
	}
	public CoverNoteDetails getLstCvrNtDet() {
		return lstCvrNtDet;
	}
	public void setLstCvrNtDet(CoverNoteDetails lstCvrNtDet) {
		this.lstCvrNtDet = lstCvrNtDet;
	}
	public DocumentChecklistDetails getLstDocChkDet() {
		return lstDocChkDet;
	}
	public void setLstDocChkDet(DocumentChecklistDetails lstDocChkDet) {
		this.lstDocChkDet = lstDocChkDet;
	}
	public PreInspectionResultDetails getLstPreInspResDet() {
		return lstPreInspResDet;
	}
	public void setLstPreInspResDet(PreInspectionResultDetails lstPreInspResDet) {
		this.lstPreInspResDet = lstPreInspResDet;
	}
}

package com.majesco.dcf.paproduct.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.codehaus.jackson.map.annotate.JsonSerialize;
/**
 * @author ketan570156
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
@Entity
@Table(name = "dcf_quotation_dtl")
public class QuotationPA implements Serializable{
	
	private String QuoteNumber;
	
	private String FirstName;
	private String LastName;
	
	private String MobileNumber;
	private String Email;
	private String PlanCode;
	private String IntermediaryCode;
	private String RequestTransData;
	private String ResponseTransData;
	private Date CreatedDate;
	private String CreatedBy;
	private Date UpdatedDate;
	private String UpdatedBy;
	private String ProposalNumber;
	private String totalPayable;
	private String productCode;
	private String customerId;
	private String strdob; 
	
	@Id
	/*@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="dcf_quotation_pa_seqid")
	@SequenceGenerator(
			name="dcf_quotation_pa_seqid",
			sequenceName="dcf_quotation_pa_seqid",
			allocationSize=1
			)*/
	
	@Column(name = "strquotnumber")
	public String getQuoteNumber() {
		return QuoteNumber;
	}
	public void setQuoteNumber(String quoteNumber) {
		QuoteNumber = quoteNumber;
	}
	
	
	/**
	 * @return the firstName
	 */
	@Column(name = "firstname")
	public String getFirstName() {
		return FirstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	@Column(name = "lastname")
	public String getLastName() {
		return LastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	@Column(name = "strmobile")
	public String getMobileNumber() {
		return MobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		MobileNumber = mobileNumber;
	}
	
	@Column(name = "stremail")
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
	@Column(name = "strplancode")
	public String getPlanCode() {
		return PlanCode;
	}
	public void setPlanCode(String planCode) {
		PlanCode = planCode;
	}
	
	@Column(name = "strintermediarycode")
	public String getIntermediaryCode() {
		return IntermediaryCode;
	}
	public void setIntermediaryCode(String intermediaryCode) {
		IntermediaryCode = intermediaryCode;
	}
	
	@Column(name = "strrequestdata")
	public String getRequestTransData() {
		return RequestTransData;
	}
	public void setRequestTransData(String requestTransData) {
		RequestTransData = requestTransData;
	}
	
	@Column(name = "strresponsedata")
	public String getResponseTransData() {
		return ResponseTransData;
	}
	public void setResponseTransData(String responseTransData) {
		ResponseTransData = responseTransData;
	}
	
	@Column(name = "dtcreated")
	public Date getCreatedDate() {
		return CreatedDate;
	}
	public void setCreatedDate(Date createdDate) {
		CreatedDate = createdDate;
	}
	
	@Column(name = "createdby")
	public String getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}
	
	@Column(name = "dtupdated")
	public Date getUpdatedDate() {
		return UpdatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		UpdatedDate = updatedDate;
	}
	
	@Column(name = "updatedby")
	public String getUpdatedBy() {
		return UpdatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		UpdatedBy = updatedBy;
	}
	
	@Column(name = "strproposalnumber")
	public String getProposalNumber() {
		return ProposalNumber;
	}
	public void setProposalNumber(String proposalNumber) {
		ProposalNumber = proposalNumber;
	}
	
	@Column(name = "dtotalpayable")
	public String getTotalPayable() {
		return totalPayable;
	}
	public void setTotalPayable(String totalPayable) {
		this.totalPayable = totalPayable;
	}
	
	@Column(name = "strproductcode")
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	@Column(name = "strcustomerid")
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	@Column(name = "strdob")
	public String getStrdob() {
		return strdob;
	}
	public void setStrdob(String strdob) {
		this.strdob = strdob;
	}
	
	

}

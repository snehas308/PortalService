package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class RTOLocationResponse {
	  private String strrtolocationcd="";
	  private String strrtolocationdesc="";
	  
	  private List<ResponseError> resErr;
	  
	public String getStrrtolocationcd() {
		return strrtolocationcd;
	}
	public void setStrrtolocationcd(String strrtolocationcd) {
		this.strrtolocationcd = strrtolocationcd;
	}
	public String getStrrtolocationdesc() {
		return strrtolocationdesc;
	}
	public void setStrrtolocationdesc(String strrtolocationdesc) {
		this.strrtolocationdesc = strrtolocationdesc;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	

}

package com.majesco.dcf.paproduct.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.entity.InBoundMaster;
import com.majesco.dcf.common.tagic.entity.OutBoundMaster;
import com.majesco.dcf.common.tagic.entity.UserTransaction;
import com.majesco.dcf.common.tagic.json.CommunicationRequest;
import com.majesco.dcf.common.tagic.json.CustomerDetailRequest;
import com.majesco.dcf.common.tagic.json.CustomerDetailResponse;
import com.majesco.dcf.common.tagic.json.EmailAttachment;
import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.SOAPInfo;
import com.majesco.dcf.common.tagic.service.CustomerService;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.paproduct.entity.QuotationPA;
import com.majesco.dcf.paproduct.json.CalculatorPARequest;
import com.majesco.dcf.paproduct.json.CalculatorPAResponse;
import com.majesco.dcf.paproduct.json.PAQuickQuotPrmRequest;
import com.majesco.dcf.paproduct.json.PAQuickQuotPrmResponse;
import com.majesco.dcf.paproduct.json.PremiumDetailsQuot;
import com.majesco.dcf.util.CXFInBoundInterceptor;
import com.majesco.dcf.util.CXFOutInterceptor;

@Service
public class CalculatorPAService {
	
	@Autowired
	DBService dbserv;
	
	@Autowired
	TagicCommunicationService tagicCommunicationService;
	
	@Autowired
	CustomerService customerService;

	final static Logger logger=Logger.getLogger(CalculatorPAService.class);
	
	@SuppressWarnings("unchecked")
	public CalculatorPAResponse calculatePAPremium(CalculatorPARequest clacpareq)throws Exception
	{
		CalculatorPAResponse calcpares = new CalculatorPAResponse();
		ObjectMapper objMap = new ObjectMapper();
		long transId=System.nanoTime();
		try
		{
		
		logger.info("In CalculatorPAService.calculatePAPremium Method Begin()...");
			
		ArrayList arr = new ArrayList();
		//System.out.println("In Service");
		List result = null ;
		Double prm= 0.0;
		Double addonprm=0.0;
		double dserviceTaxRate=0.0;	//RahulT
		double serviceTaxAmt = 0;	//RahulT
		double totalPrmAmt = 0;	//RahulT
		List<ResponseError> reserrList; 
		List<PremiumDetails> premiumDet = new ArrayList<PremiumDetails>();
		reserrList = new ArrayList<ResponseError>();
		
		ResponseError res = new ResponseError();
		res.setErrorCode("1");
		res.setErrorMMessag("Ok");
		reserrList.add(res);
		
		PremiumDetails prmDet = new PremiumDetails();
		arr = dbserv.getPremiumPA("com.majesco.dcf.paproduct.entity.PAPremium",clacpareq);
		
		if(clacpareq.getAddoncoverApp()!=null && clacpareq.getAddoncoverApp().equalsIgnoreCase("Y")){

			if (clacpareq.getProductcd()!=null && (clacpareq.getProductcd().equals("4251") || clacpareq.getProductcd().equals("4255"))){
				clacpareq.setPayPeriod(Integer.parseInt(clacpareq.getCbenunit()));
			}
			if(clacpareq.getCbenunit()!=null && clacpareq.getUnitsAddon()!=null){
				
				int dsa=Integer.parseInt(clacpareq.getCbenunit()) * Integer.parseInt(clacpareq.getUnitsAddon());
				clacpareq.setSumAssured(String.valueOf(dsa));
			}
			
			
			arr = dbserv.getAdonPremiumPA("com.majesco.dcf.paproduct.entity.PAPremium",clacpareq,arr);
		}
		else{
			arr.add(new Double(0));
		}
		OutBoundMaster outBound = new OutBoundMaster();
		outBound.setSeqid(transId+"");
		outBound.setCreateby(clacpareq.getUserID());
		outBound.setDtcreated(new Date());
		outBound.setStripaddress(clacpareq.getSystemIP());
		outBound.setStrjsonobj(objMap.writeValueAsString(clacpareq));
		outBound.setStrlobservice("getAdonPremiumPA");
		outBound.setStrproductcode(clacpareq.getProducerCode());
		outBound.setStrlobtype("42");
		outBound.setStrtransactionevent("GetPremium / IPA-Calculator");
		outBound.setStrproducercode(clacpareq.getProducerCode());
		dbserv.saveOutSoapInfo(outBound);
		logger.info("In CalculatorPAService.calculatePAPremium Method :: Size Of arr : "+arr.size());
		
		if(arr!=null && !arr.isEmpty()){
			prm = (Double) arr.get(0);
			addonprm = (Double) arr.get(1);
			
			// RahulT: added for service tax rate calculations
			String strParamVal = dbserv.getConfigParamVal("SERVICETAX");
			dserviceTaxRate =new Double(strParamVal);
			// RahulT: added for service tax rate calculations
			
			//Start :RahulT: added for service tax rate calculations
			
			double tempTotalPrm = prm.doubleValue() + addonprm.doubleValue();
			prmDet.setNetPremium(""+tempTotalPrm);
			if (dserviceTaxRate > 0){
				serviceTaxAmt = tempTotalPrm * dserviceTaxRate/100;
				prmDet.setServiceTax(""+serviceTaxAmt);
			}
			
			totalPrmAmt = serviceTaxAmt + tempTotalPrm;
			prmDet.setPremiumPayable(""+totalPrmAmt);
			//End: RahulT| added for service tax rate calculations
			prmDet.setAddonPremiumPayable(addonprm.toString());
			premiumDet.add(prmDet);
		}
		
		calcpares.setPremDetlst(premiumDet);
		calcpares.setResErr(reserrList);
		calcpares.setResultCode("Y");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info("Exception StackTrace : ", e);
		}
		
		logger.info("In CalculatorPAService.calculatePAPremium Method End()...");
		logger.info("In CalculatorPAService.calculatePAPremium :: Response Of calcpares : "+calcpares);
		InBoundMaster inBound = new InBoundMaster();
		inBound.setSeqid(transId+"");
		inBound.setCreateby(clacpareq.getUserID());
		inBound.setDtcreated(new Date());
		inBound.setStripaddress(clacpareq.getSystemIP());
		inBound.setStrjsonobj(objMap.writeValueAsString(calcpares));
		inBound.setStrlobservice("getAdonPremiumPA");
		inBound.setStrproductcode(clacpareq.getProducerCode());
		inBound.setStrlobtype("42");
		inBound.setStrtransactionevent("GetPremium / IPA-Calculator");
		inBound.setStrproducercode(clacpareq.getProducerCode());
		dbserv.saveInSoapInfo(inBound);
		
		return calcpares;
		
	}
	
	@SuppressWarnings("unchecked")
	public PAQuickQuotPrmResponse getQuickQuotPremium(PAQuickQuotPrmRequest quickQuotObj)throws Exception
	{
		PAQuickQuotPrmResponse calcpares = new PAQuickQuotPrmResponse();
		CalculatorPARequest clacpareq = new CalculatorPARequest();
		
		try
		{
		
		logger.info("In CalculatorPAService.calculatePAPremium Method Begin()...");
			
		@SuppressWarnings("rawtypes")
		ArrayList arr = new ArrayList();
		Double prm= 0.0;
		Double addonprm=0.0;
		double dserviceTaxRate=0.0;	//RahulT
		double serviceTaxAmt = 0;	//RahulT
		double totalPrmAmt = 0;	//RahulT
		List<ResponseError> reserrList;
		reserrList = new ArrayList<ResponseError>();
		
		ResponseError res = new ResponseError();
		res.setErrorCode("0");
		res.setErrorMMessag("Ok");
		reserrList.add(res);
		
		PremiumDetailsQuot quotPrmDtl = new PremiumDetailsQuot();
		clacpareq.setAddoncoverApp(quickQuotObj.getWeeklyBenUpto52Weeks());
		clacpareq.setProductcd(quickQuotObj.getProductCode());
		clacpareq.setInsuranceFor(quickQuotObj.getInsuranceFor());
		clacpareq.setPlantype(quickQuotObj.getPlan());
		clacpareq.setCbenunit(quickQuotObj.getCoreBenPerUnit());
		if (quickQuotObj.getProductCode()!=null && quickQuotObj.getProductCode().equals("4254")){
			clacpareq.setTenure(quickQuotObj.getPolicyTerm());
		}
		clacpareq.setFamilySize(quickQuotObj.getFamilySize());
		clacpareq.setBenperMonth(quickQuotObj.getBenperMonth());
		if (quickQuotObj.getProductCode()!=null && !quickQuotObj.getProductCode().equals("4255") 
				&& quickQuotObj.getCoreSumInsured()!=null && !quickQuotObj.getCoreSumInsured().equals("")){
		
			clacpareq.setSumAssured(quickQuotObj.getCoreSumInsured());
		
		}
		else{
			
			if (quickQuotObj.getCoreBenNoOfUnit()!=null && !quickQuotObj.getCoreBenNoOfUnit().equals(""))
				clacpareq.setUnits(Integer.parseInt(quickQuotObj.getCoreBenNoOfUnit()));
			if (quickQuotObj.getPayPeriod()!=null && !quickQuotObj.getPayPeriod().equals(""))
				clacpareq.setPayPeriod(Integer.parseInt(quickQuotObj.getPayPeriod()));
			if (quickQuotObj.getBenperMonth()!=null && !quickQuotObj.getBenperMonth().equals(""))
				clacpareq.setBenperMonth(quickQuotObj.getBenperMonth());
			
			}
		
		arr = dbserv.getPremiumPA("com.majesco.dcf.paproduct.entity.PAPremium",clacpareq);
		
		if(clacpareq.getAddoncoverApp()!=null && clacpareq.getAddoncoverApp().equalsIgnoreCase("Y")){

			if (clacpareq.getProductcd()!=null && (clacpareq.getProductcd().equals("4251") || clacpareq.getProductcd().equals("4255"))){
				clacpareq.setPayPeriod(Integer.parseInt(clacpareq.getCbenunit()));
			}
			
			clacpareq.setUnitsAddon(quickQuotObj.getWeeklyBenNoOfUnits());		// RahulT: fixed premium mismatch on IPA Save & quot
			if(clacpareq.getCbenunit()!=null && clacpareq.getUnitsAddon()!=null){
				
				int dsa=Integer.parseInt(clacpareq.getCbenunit()) * Integer.parseInt(clacpareq.getUnitsAddon());
				clacpareq.setSumAssured(String.valueOf(dsa));
			}
			
			arr = dbserv.getAdonPremiumPA("com.majesco.dcf.paproduct.entity.PAPremium",clacpareq,arr);
		}
		else{
			arr.add(new Double(0));
		}
		
		logger.info("In CalculatorPAService.calculatePAPremium Method :: Size Of arr : "+arr.size());
		
		// String quotNoCurrDate = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new java.util.Date());
		
		// RahulT: added for service tax rate calculations
		String strParamVal = dbserv.getConfigParamVal("SERVICETAX");
		dserviceTaxRate =new Double(strParamVal);
		// RahulT: added for service tax rate calculations
		
		prm = (Double) arr.get(0);
		addonprm = (Double) arr.get(1);
		quotPrmDtl.setAddonPremiumPayable(addonprm.toString());
		
		//Start :RahulT: added for service tax rate calculations
		
		double tempTotalPrm = prm.doubleValue() + addonprm.doubleValue();
		quotPrmDtl.setNetPremium(""+tempTotalPrm);
		if (dserviceTaxRate>0){
			serviceTaxAmt = tempTotalPrm * dserviceTaxRate/100;
			quotPrmDtl.setServiceTax(""+serviceTaxAmt);
		}
		
		totalPrmAmt = serviceTaxAmt + tempTotalPrm;
		quotPrmDtl.setTotalPremium(""+totalPrmAmt);
		//End: RahulT| added for service tax rate calculations
		
		calcpares.setPremDetlst(quotPrmDtl);
		calcpares.setResErr(reserrList);
		calcpares.setResultCode("Y");
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In CalculatorPAService.calculatePAPremium :: Response Of calcpares : "+calcpares);
		
		return calcpares;
		
	}
	
	@SuppressWarnings("unchecked")
	public PAQuickQuotPrmResponse saveQuickQuotPremium(PAQuickQuotPrmRequest quickQuotObj)throws Exception
	{
		PAQuickQuotPrmResponse calcpares = new PAQuickQuotPrmResponse();
		CalculatorPARequest clacpareq = new CalculatorPARequest();
		QuotationPA quotEntity = null;
		long transId=System.nanoTime();
		ObjectMapper objMap = new ObjectMapper();
		String prodSeries = "";
		try
		{
		
		logger.info("In CalculatorPAService.saveQuickQuotPremium Method Begin()...");
			
		@SuppressWarnings("rawtypes")
		ArrayList arr = new ArrayList();
		Double prm= 0.0;
		Double addonprm=0.0;
		double dserviceTaxRate=0.0;	//RahulT
		double serviceTaxAmt = 0;	//RahulT
		double totalPrmAmt = 0;	//RahulT
		List<ResponseError> reserrList;
		reserrList = new ArrayList<ResponseError>();
		
		ResponseError res = new ResponseError();
		res.setErrorCode("0");
		res.setErrorMMessag("Ok");
		reserrList.add(res);
		
		PremiumDetailsQuot quotPrmDtl = new PremiumDetailsQuot();
		clacpareq.setAddoncoverApp(quickQuotObj.getWeeklyBenUpto52Weeks());
		clacpareq.setProductcd(quickQuotObj.getProductCode());
		clacpareq.setInsuranceFor(quickQuotObj.getInsuranceFor());
		clacpareq.setPlantype(quickQuotObj.getPlan());
		clacpareq.setCbenunit(quickQuotObj.getCoreBenPerUnit());
		if (quickQuotObj.getProductCode()!=null && quickQuotObj.getProductCode().equals("4254")){
			clacpareq.setTenure(quickQuotObj.getPolicyTerm());
		}
		clacpareq.setFamilySize(quickQuotObj.getFamilySize());
		clacpareq.setBenperMonth(quickQuotObj.getBenperMonth());
		if (quickQuotObj.getProductCode()!=null && !quickQuotObj.getProductCode().equals("4255") 
				&& quickQuotObj.getCoreSumInsured()!=null && !quickQuotObj.getCoreSumInsured().equals("")){
		
			clacpareq.setSumAssured(quickQuotObj.getCoreSumInsured());
		
		}
		else{
			
			if (quickQuotObj.getCoreBenNoOfUnit()!=null && !quickQuotObj.getCoreBenNoOfUnit().equals(""))
				clacpareq.setUnits(Integer.parseInt(quickQuotObj.getCoreBenNoOfUnit()));
			if (quickQuotObj.getPayPeriod()!=null && !quickQuotObj.getPayPeriod().equals(""))
				clacpareq.setPayPeriod(Integer.parseInt(quickQuotObj.getPayPeriod()));
			if (quickQuotObj.getBenperMonth()!=null && !quickQuotObj.getBenperMonth().equals(""))
				clacpareq.setBenperMonth(quickQuotObj.getBenperMonth());
			
			}
	
		arr = dbserv.getPremiumPA("com.majesco.dcf.paproduct.entity.PAPremium",clacpareq);
		
		if(clacpareq.getAddoncoverApp()!=null && clacpareq.getAddoncoverApp().equalsIgnoreCase("Y")){

			if (clacpareq.getProductcd()!=null && (clacpareq.getProductcd().equals("4251") || clacpareq.getProductcd().equals("4255"))){
				clacpareq.setPayPeriod(Integer.parseInt(clacpareq.getCbenunit()));
			}
			
			clacpareq.setUnitsAddon(quickQuotObj.getWeeklyBenNoOfUnits());
			if(clacpareq.getCbenunit()!=null && clacpareq.getUnitsAddon()!=null){
				
				int dsa=Integer.parseInt(clacpareq.getCbenunit()) * Integer.parseInt(clacpareq.getUnitsAddon());
				clacpareq.setSumAssured(String.valueOf(dsa));
			}
			
			arr = dbserv.getAdonPremiumPA("com.majesco.dcf.paproduct.entity.PAPremium",clacpareq,arr);
		}
		else{
			arr.add(new Double(0));
		}
		
		logger.info("In CalculatorPAService.saveQuickQuotPremium Method :: Size Of arr : "+arr.size());
		
		// RahulT: added for service tax rate calculations
		String strParamVal = dbserv.getConfigParamVal("SERVICETAX");
		dserviceTaxRate =new Double(strParamVal);
		// RahulT: added for service tax rate calculations
		
		prm = (Double) arr.get(0);
		addonprm = (Double) arr.get(1);
		quotPrmDtl.setAddonPremiumPayable(addonprm.toString());
		
		//Start:RahulT: added for service tax rate calculations
		
		double tempTotalPrm = prm.doubleValue() + addonprm.doubleValue();
		quotPrmDtl.setNetPremium(""+tempTotalPrm);
		
		if (dserviceTaxRate>0){
			serviceTaxAmt = tempTotalPrm * dserviceTaxRate/100;
			quotPrmDtl.setServiceTax(""+serviceTaxAmt);
		}
				
		totalPrmAmt = serviceTaxAmt + tempTotalPrm;
		quotPrmDtl.setTotalPremium(""+totalPrmAmt);
		//End: RahulT| added for service tax rate calculations
		
		calcpares.setPremDetlst(quotPrmDtl);
		calcpares.setResErr(reserrList);
		calcpares.setResultCode("Y");
		
		// persisting quotation data
		if (clacpareq.getProductcd().equals("4251")){
			prodSeries ="AG";
		}
		else if (clacpareq.getProductcd().equals("4254")){
			prodSeries ="AS";
		}
		else if (clacpareq.getProductcd().equals("4255")){
			prodSeries ="SF";
		}
		
		Long quoteSeq = dbserv.getNextQuotSeq();	//SELECT nextval('dcf_quotation_pa_seqid');
		
		DateFormat df = new SimpleDateFormat("yy"); // Just the year, with 2 digits
		String currentYear = df.format(Calendar.getInstance().getTime());
		int nextYear = new Integer(currentYear)+1;
		String fiscalYear = currentYear+nextYear;
		OutBoundMaster outBound = new OutBoundMaster();
		outBound.setSeqid(transId+"");
		outBound.setCreateby(quickQuotObj.getUserID());
		outBound.setDtcreated(new Date());
		outBound.setStripaddress(quickQuotObj.getSystemIP());
		outBound.setStrjsonobj(objMap.writeValueAsString(clacpareq));
		outBound.setStrlobservice("saveQuickQuot");
		outBound.setStrproductcode(quickQuotObj.getProducerCode());
		outBound.setStrlobtype("42");
		outBound.setStrtransactionevent("SaveQuote / IPA-Quote");
		outBound.setStrproducercode(quickQuotObj.getProducerCode());
		dbserv.saveOutSoapInfo(outBound);
		
		//arr = dbserv.getPremiumPA("com.majesco.dcf.paproduct.entity.PAPremium",clacpareq);
		calcpares.setQutationNo("PA-"+prodSeries+"-"+fiscalYear+"-"+quoteSeq);	// Setting Quotation no in response JSON. 
		quotEntity = new QuotationPA();
		quotEntity.setEmail(quickQuotObj.getEmail());
		quotEntity.setFirstName(quickQuotObj.getFirstName());
		quotEntity.setIntermediaryCode(quickQuotObj.getIntermediaryCode());
		quotEntity.setLastName(quickQuotObj.getLastName());
		quotEntity.setMobileNumber(quickQuotObj.getMobileNumber());
		quotEntity.setPlanCode(quickQuotObj.getPlan());
		quotEntity.setRequestTransData(objMap.writeValueAsString(quickQuotObj));
		quotEntity.setResponseTransData(objMap.writeValueAsString(calcpares));
		quotEntity.setTotalPayable(prm.toString());
		quotEntity.setProductCode(quickQuotObj.getProductCode());
		quotEntity.setCreatedBy("SYSTEM");
		quotEntity.setCreatedDate(new Date());
		quotEntity.setQuoteNumber("PA-"+prodSeries+"-"+fiscalYear+"-"+quoteSeq);
		quotEntity.setCustomerId(quickQuotObj.getCustomerId());	
		quotEntity.setStrdob(quickQuotObj.getDob());
		
		String quotNumber = dbserv.saveQuickQuot(quotEntity);
		calcpares.setQutationNo(quotNumber.toString());
		//Start:07/03/2017:To search customer details by customer id and populate full customer details data from GC
        if(quickQuotObj.getCustomerId()!=null && !quickQuotObj.getCustomerId().equals(CommonConstants.BLANK_STRING)){
        	CustomerDetailRequest customerDetailRequest=new CustomerDetailRequest();
        	customerDetailRequest.setAuthToken(quickQuotObj.getAuthToken());
        	customerDetailRequest.setCustomerID(quickQuotObj.getCustomerId());
        	//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getProductProposalDataComm :: Fetching Customer Details"+quickQuotObj.getCustomerId());
        	CustomerDetailResponse customerDetailResponse=customerService.getCustomerDetails(customerDetailRequest);
        	
        	if(customerDetailResponse!=null && customerDetailResponse.getCustDetails()!=null && customerDetailResponse.getCustDetails().size()>0){
        		calcpares.setProposerDet(customerDetailResponse.getCustDetails().get(0));
        	}
        }
      //End:07/03/2017:To search customer details by customer id and populate full customer details data from GC
		try{
			logger.info("In CalculatorPAService.saveQuickQuotPremium :: Sending eamil !!!!!::Entered");
			//Persisting data into transaction table for Save customer service.
			UserTransaction transaction = new UserTransaction();
			transaction.setDtCreated(new Date());
			transaction.setDtTrans(new Date());
			transaction.setStrCreatedBy(quickQuotObj.getUserID());
			transaction.setStrlob("IPA");
			transaction.setStrProducercd(quickQuotObj.getProducerCode());	// 27122016
			transaction.setStrTranstype("Save Quote");
			transaction.setStrUserid(quickQuotObj.getUserID());
			transaction.setDtotSA(prm);
			transaction.setStrIPAddress(quickQuotObj.getSystemIP());
			transaction.setTotalPremium(""+tempTotalPrm);
			//transaction.setStrCustomerId(quickQuotObj.getc());
			transaction.setStrQuotNumber(quotNumber);
			transaction.setStrCustomerId(quickQuotObj.getCustomerId());
			dbserv.saveOrUpdate(transaction);
			logger.info("In CalculatorPAService.saveQuickQuotPremium :: Sending eamil !!!!!::Exit");
		}catch(Exception cex){
			logger.info("In CalculatorPAService.saveQuickQuotPremium::Send mail failed !!!", cex);
		}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In CalculatorPAService.saveQuickQuotPremium :: Response Of calcpares : "+calcpares);
		InBoundMaster inBound = new InBoundMaster();
		inBound.setSeqid(transId+"");
		inBound.setCreateby(quickQuotObj.getUserID());
		inBound.setDtcreated(new Date());
		inBound.setStripaddress(quickQuotObj.getSystemIP());
		inBound.setStrjsonobj(objMap.writeValueAsString(calcpares));
		inBound.setStrlobservice("saveQuickQuot");
		inBound.setStrproductcode(quickQuotObj.getProducerCode());
		inBound.setStrlobtype("42");
		inBound.setStrtransactionevent("SaveQuote / IPA-Quote");
		inBound.setStrproducercode(quickQuotObj.getProducerCode());
		dbserv.saveInSoapInfo(inBound);
		
		return calcpares;
		
	}
	
}

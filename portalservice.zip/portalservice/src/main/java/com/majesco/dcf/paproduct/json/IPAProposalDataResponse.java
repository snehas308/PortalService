package com.majesco.dcf.paproduct.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.CustomerDetails;
import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.ResultObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class IPAProposalDataResponse {
	
	private String custCode;
	private String firstName;
	private String prodCode;
	private String lastName;
	private String businessType;
	private String polInceptionDt;
	private String polInceptionTm;
	private String polTerm;
	private String polExpiryDt;
	private String polExpiryTm;
	private String tataAIGBranch;
	private String applnNo;
	private String applnDt;
	private String partnerApplnDt;
	private String intermCd;
	private String interNm;
	private String remarks;
	private CustomerDetails proposerDet;
	private CoverageDetails lstcvrgDet;
	private List<InsuredDetails> lstInsurDet;
	private List<NomineeDetails> lstNomDet;
	private long localTransId;
	private String userId;	
	private String propPolRefNo;
	private String officeCode;
	private String officeName;	//
	private String displayOfficeCode;
	private String branchOfficeCode;
	
	private String quoteNo;
	private String isRenew;
	private String fullName;
	private String posPanNo;
	private String posAdhaarNo;		
	private String isPUP;
	private String proposalSystemId;
	private String middleName;
	//private String policyNumber;
	//private String proposalNumber;
	//private String quotaionNumber;
		
	private String resultCode;
	private List<ResponseError> resErr;
	//private PremiumDetailsQuot premDet;
	//private String proposalSystemId; // WFSystemId from create proposal response.WFSystemID	
	//private String bussLocName; // From proposal response.PropGeneralProposalInformation_OfficeName
	//private String proposalDate;	
	private String propPolRefDate;
		
	private String productName;
	
	private PremiumDetails premDet;
	//18-10-2017:CODE CHANGES FOR DEFECT 2319.Done by SAILESH
	private String proposalStatus;
	//09-11-2017:cODE CHANGES FOR DEFECT 2443.Done bySAILESH
	private String proposalNumber;
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	private String proposalStatusDesc;
	
	public String getProposalNumber() {
		return proposalNumber;
	}
	public void setProposalNumber(String proposalNumber) {
		this.proposalNumber = proposalNumber;
	}
	public String getProposalStatus() {
		return proposalStatus;
	}
	public void setProposalStatus(String proposalStatus) {
		this.proposalStatus = proposalStatus;
	}
	public String getProposalStatusDesc() {
		return proposalStatusDesc;
	}
	public void setProposalStatusDesc(String proposalStatusDesc) {
		this.proposalStatusDesc = proposalStatusDesc;
	}
	
				
	
	public PremiumDetails getPremDet() {
		return premDet;
	}
	public void setPremDet(PremiumDetails premDet) {
		this.premDet = premDet;
	}
	public String getQuoteNo() {
		return quoteNo;
	}
	public void setQuoteNo(String quoteNo) {
		this.quoteNo = quoteNo;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPosPanNo() {
		return posPanNo;
	}
	public void setPosPanNo(String posPanNo) {
		this.posPanNo = posPanNo;
	}
	public String getPosAdhaarNo() {
		return posAdhaarNo;
	}
	public void setPosAdhaarNo(String posAdhaarNo) {
		this.posAdhaarNo = posAdhaarNo;
	}
	public String getIsPUP() {
		return isPUP;
	}
	public void setIsPUP(String isPUP) {
		this.isPUP = isPUP;
	}
	public String getProposalSystemId() {
		return proposalSystemId;
	}
	public void setProposalSystemId(String proposalSystemId) {
		this.proposalSystemId = proposalSystemId;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCustCode() {
		return custCode;
	}
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getProdCode() {
		return prodCode;
	}
	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getPolInceptionDt() {
		return polInceptionDt;
	}
	public void setPolInceptionDt(String polInceptionDt) {
		this.polInceptionDt = polInceptionDt;
	}
	public String getPolInceptionTm() {
		return polInceptionTm;
	}
	public void setPolInceptionTm(String polInceptionTm) {
		this.polInceptionTm = polInceptionTm;
	}
	public String getPolTerm() {
		return polTerm;
	}
	public void setPolTerm(String polTerm) {
		this.polTerm = polTerm;
	}
	public String getPolExpiryDt() {
		return polExpiryDt;
	}
	public void setPolExpiryDt(String polExpiryDt) {
		this.polExpiryDt = polExpiryDt;
	}
	public String getPolExpiryTm() {
		return polExpiryTm;
	}
	public void setPolExpiryTm(String polExpiryTm) {
		this.polExpiryTm = polExpiryTm;
	}
	public String getTataAIGBranch() {
		return tataAIGBranch;
	}
	public void setTataAIGBranch(String tataAIGBranch) {
		this.tataAIGBranch = tataAIGBranch;
	}
	public String getApplnNo() {
		return applnNo;
	}
	public void setApplnNo(String applnNo) {
		this.applnNo = applnNo;
	}
	public String getApplnDt() {
		return applnDt;
	}
	public void setApplnDt(String applnDt) {
		this.applnDt = applnDt;
	}
	public String getPartnerApplnDt() {
		return partnerApplnDt;
	}
	public void setPartnerApplnDt(String partnerApplnDt) {
		this.partnerApplnDt = partnerApplnDt;
	}
	public String getIntermCd() {
		return intermCd;
	}
	public void setIntermCd(String intermCd) {
		this.intermCd = intermCd;
	}
	public String getInterNm() {
		return interNm;
	}
	public void setInterNm(String interNm) {
		this.interNm = interNm;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public CustomerDetails getProposerDet() {
		return proposerDet;
	}
	public void setProposerDet(CustomerDetails proposerDet) {
		this.proposerDet = proposerDet;
	}
	public CoverageDetails getLstcvrgDet() {
		return lstcvrgDet;
	}
	public void setLstcvrgDet(CoverageDetails lstcvrgDet) {
		this.lstcvrgDet = lstcvrgDet;
	}
	public List<InsuredDetails> getLstInsurDet() {
		return lstInsurDet;
	}
	public void setLstInsurDet(List<InsuredDetails> lstInsurDet) {
		this.lstInsurDet = lstInsurDet;
	}
	public List<NomineeDetails> getLstNomDet() {
		return lstNomDet;
	}
	public void setLstNomDet(List<NomineeDetails> lstNomDet) {
		this.lstNomDet = lstNomDet;
	}
	public long getLocalTransId() {
		return localTransId;
	}
	public void setLocalTransId(long localTransId) {
		this.localTransId = localTransId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getIsRenew() {
		return isRenew;
	}
	public void setIsRenew(String isRenew) {
		this.isRenew = isRenew;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public String getOfficeCode() {
		return officeCode;
	}
	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}
	public String getOfficeName() {
		return officeName;
	}
	public void setOfficeName(String officeName) {
		this.officeName = officeName;
	}
	public String getDisplayOfficeCode() {
		return displayOfficeCode;
	}
	public void setDisplayOfficeCode(String displayOfficeCode) {
		this.displayOfficeCode = displayOfficeCode;
	}
	public String getBranchOfficeCode() {
		return branchOfficeCode;
	}
	public void setBranchOfficeCode(String branchOfficeCode) {
		this.branchOfficeCode = branchOfficeCode;
	}
	public String getPropPolRefNo() {
		return propPolRefNo;
	}
	public void setPropPolRefNo(String propPolRefNo) {
		this.propPolRefNo = propPolRefNo;
	}
	public String getPropPolRefDate() {
		return propPolRefDate;
	}
	public void setPropPolRefDate(String propPolRefDate) {
		this.propPolRefDate = propPolRefDate;
	}
	
}

package com.majesco.dcf.common.tagic.json;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

public class DocumentVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public String strdcodesc;
	public BigDecimal nisrequired;
	
	public String getStrdcodesc() {
		return strdcodesc;
	}
	public void setStrdcodesc(String strdcodesc) {
		this.strdcodesc = strdcodesc;
	}


	public BigDecimal getNisrequired() {
		return nisrequired;
	}
	public void setNisrequired(BigDecimal nisrequired) {
		this.nisrequired = nisrequired;
	}
			

}

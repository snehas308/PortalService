package com.majesco.dcf.common.tagic.entity;

public class Address {

}

package com.majesco.dcf.common.tagic.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.majesco.dcf.common.tagic.json.AgentDashBoardRequest;
import com.majesco.dcf.common.tagic.json.AgentDashBoardResponse;
import com.majesco.dcf.common.tagic.json.AuthenticationRequest;
import com.majesco.dcf.common.tagic.json.AuthenticationResponse;
import com.majesco.dcf.common.tagic.json.DocumentListGCRequest;
import com.majesco.dcf.common.tagic.json.DocumentListGCResponse;
import com.majesco.dcf.common.tagic.json.FastLaneRequest;
import com.majesco.dcf.common.tagic.json.FastLaneResponse;
import com.majesco.dcf.common.tagic.json.HouseBankAccNoRequest;
import com.majesco.dcf.common.tagic.json.HouseBankAccNoResponse;
import com.majesco.dcf.common.tagic.json.PolicyDetailsSearchRequest;
import com.majesco.dcf.common.tagic.json.PolicyDetailsSearchResponse;
import com.majesco.dcf.common.tagic.json.PolicySearchRequest;
import com.majesco.dcf.common.tagic.json.PolicySearchResponse;
import com.majesco.dcf.common.tagic.json.PolicySearchResultDet;
import com.majesco.dcf.common.tagic.json.PortalLockDaysRequest;
import com.majesco.dcf.common.tagic.json.PortalLockDetails;
import com.majesco.dcf.common.tagic.json.PrintProposalReq;
import com.majesco.dcf.common.tagic.json.ProposalSearchRequest;
import com.majesco.dcf.common.tagic.json.ProposalSearchResponse;
import com.majesco.dcf.common.tagic.json.QlikTicketResponse;
import com.majesco.dcf.common.tagic.json.QuotationListResponse;
import com.majesco.dcf.common.tagic.json.QuotationSearchRequest;
import com.majesco.dcf.common.tagic.json.RenewalCalCountRequest;
import com.majesco.dcf.common.tagic.json.RenewalCalCountResponse;
import com.majesco.dcf.common.tagic.json.RenewalPolLetterRequest;
import com.majesco.dcf.common.tagic.json.RenewalPolLetterResponse;
import com.majesco.dcf.common.tagic.json.RenewalSearchRequest;
import com.majesco.dcf.common.tagic.json.RenewalSearchResponse;
import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.common.tagic.json.ValueByEffDateRequest;
import com.majesco.dcf.common.tagic.json.ValueByEffDateResponse;
import com.majesco.dcf.common.tagic.service.AuthenticationService;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.DocListService;
import com.majesco.dcf.common.tagic.service.TagicCommonService;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.receipt.json.getPolicyDetailsEODRequest;
import com.majesco.dcf.receipt.json.getPolicyDetailsEODResponse;
import com.majesco.dcf.receipt.service.ReceiptService;
import com.majesco.dcf.usermgmt.json.UserInfoResponse;
import com.majesco.dcf.common.chp.util.AesUtil;
import com.majesco.dcf.common.tagic.json.PendingPayInSlipResponse;

@Controller
@RequestMapping(value="/CommonService")
public class CommonServiceController {
	
	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/
	//Start: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
	@Value("${aes.passphrase}")
	private String passphrase;
		
	@Value("${aes.iterationCount}")
	private String iterationCount;
		
	@Value("${aes.keySize}")
	private String keySize;
		
	@Value("${passwordEncryptionApplied}")
	private String isAesEncryption;
		
	@Value("${aes.salt}")
	private String aesSalt;
		
	@Value("${aes.iv}")
	private String aesIv;	
	//End: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
	
	@Autowired
	TagicCommonService comServ;
	
	/*Added For Issue ID 1566 - Starts Here*/
	@Autowired
	ReceiptService receiptService;
	
	@Autowired
	DBService dbService;
	/*Added For Issue ID 1566 - Ends Here*/
	
	@Autowired
	AuthenticationService authService;
	@Autowired
	DocListService documentLstService;

	private Gson gson=new Gson();
	
	final static Logger logger=Logger.getLogger(CommonServiceController.class);
	
	@RequestMapping(value="/getPolicyDetailsByPolicyNoCommon/", method = RequestMethod.POST)
	@ResponseBody
	public PolicyDetailsSearchResponse getPolicyDetailsByPolicyNo(@RequestBody PolicyDetailsSearchRequest cvrNoteClaimReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside CommonServiceController :: getPolicyDetailsByPolicyNo method :: Execution Started");
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		cvrNoteClaimReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+cvrNoteClaimReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
		
		PolicyDetailsSearchResponse cvrNoteClaimRes = comServ.getPolicyDetailsByPolicyNo(cvrNoteClaimReq);
		
		logger.info("Inside CommonServiceController :: getPolicyDetailsByPolicyNo method :: Execution Completed Successfully");
		
		return cvrNoteClaimRes;
	}
	
	/*@RequestMapping(value="/printProposal/{customerID}/{productCode}/{proposalDate}/{proposalNumber}", method = RequestMethod.GET)
	//@ResponseBody
	public void printProposal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@PathVariable("customerID") String customerID, @PathVariable("productCode") String productCode,@PathVariable("proposalDate") String proposalDate,@PathVariable("proposalNumber") String proposalNumber) throws Exception{
		
		PrintProposalReq printProposalReq =new PrintProposalReq();
		printProposalReq.setCustomerID(customerID);
		printProposalReq.setProductCode(productCode);
		printProposalReq.setProposalDate(proposalDate);
		printProposalReq.setProposalNumber(proposalNumber);
		comServ.printProposal(printProposalReq, httpServletResponse);
	}*/
	
	@RequestMapping(value="/printProposal/", method = RequestMethod.POST)
	//@ResponseBody
	public void printProposal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception{
		
		logger.info("Inside CommonServiceController :: printProposal method :: Execution Started");
		PrintProposalReq printProposalReq =new PrintProposalReq();
		printProposalReq.setCustomerID(httpServletRequest.getParameter("customerID"));
		printProposalReq.setProductCode(httpServletRequest.getParameter("productCode"));
		printProposalReq.setProposalDate(httpServletRequest.getParameter("proposalDate"));
		printProposalReq.setProposalNumber(httpServletRequest.getParameter("proposalNumber"));
		printProposalReq.setUserID(httpServletRequest.getParameter("userID"));
		
		//Start: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
		if (isAesEncryption!=null && isAesEncryption.equals(CommonConstants.YES_FLAG_VAL2)){
	        String strIV = new String(Base64.decodeBase64(aesIv));
	        String strSalt = new String(Base64.decodeBase64(aesSalt));
	        String phrasePass = new String(Base64.decodeBase64(passphrase));
			String ciphertext = httpServletRequest.getParameter("password");
	        AesUtil aesUtil = new AesUtil(Integer.parseInt(keySize),Integer.parseInt(iterationCount));
	        //if(logger.isDebugEnabled())logger.debug("iv value ..--> "+strIV+", salt value--> "+strSalt+", ciphertext--> "+ciphertext);
	        String decodePass = aesUtil.decrypt(strSalt, strIV, phrasePass, ciphertext);
	        logger.info("Pasword has been decoded successfully--> "+decodePass);
	        printProposalReq.setPassword(decodePass);
		}
		else{
        //End: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
			printProposalReq.setPassword(httpServletRequest.getParameter("password"));
		}
		
		
		//printProposalReq.setPassword(httpServletRequest.getParameter("password")); //Commented For RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		printProposalReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+printProposalReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
		comServ.printProposal(printProposalReq, httpServletResponse);
		logger.info("Inside CommonServiceController :: printProposal method :: Execution Ended");
	}
	
	
	@RequestMapping(value="/printPolicy/", method = RequestMethod.POST)
	//@ResponseBody
	public void printPolicy(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception{
		logger.info("Inside CommonServiceController :: printPolicy method :: Execution Started");
		PrintProposalReq printProposalReq =new PrintProposalReq();
		printProposalReq.setCustomerID(httpServletRequest.getParameter("customerID"));
		printProposalReq.setProductCode(httpServletRequest.getParameter("productCode"));
		printProposalReq.setProposalDate(httpServletRequest.getParameter("proposalDate"));
		printProposalReq.setProposalNumber(httpServletRequest.getParameter("proposalNumber"));
		printProposalReq.setUserID(httpServletRequest.getParameter("userID"));
		
		//Start: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
		if (isAesEncryption!=null && isAesEncryption.equals(CommonConstants.YES_FLAG_VAL2)){
			String strIV = new String(Base64.decodeBase64(aesIv));
			String strSalt = new String(Base64.decodeBase64(aesSalt));
			String phrasePass = new String(Base64.decodeBase64(passphrase));
			String ciphertext = httpServletRequest.getParameter("password");
			AesUtil aesUtil = new AesUtil(Integer.parseInt(keySize),Integer.parseInt(iterationCount));
			//if(logger.isDebugEnabled())logger.debug("iv value ..--> "+strIV+", salt value--> "+strSalt+", ciphertext--> "+ciphertext);
			String decodePass = aesUtil.decrypt(strSalt, strIV, phrasePass, ciphertext);
			logger.info("Pasword has been decoded successfully--> "+decodePass);
			printProposalReq.setPassword(decodePass);
		}
		else{
			printProposalReq.setPassword(httpServletRequest.getParameter("password"));
		//End: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
		}
		
		//printProposalReq.setPassword(httpServletRequest.getParameter("password")); // Commented RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		printProposalReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+printProposalReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
		comServ.printPolicy(printProposalReq, httpServletResponse);
		logger.info("Inside CommonServiceController :: printPolicy method :: Execution Ended");
	}
	
	@RequestMapping(value="/printWorksheet/", method = RequestMethod.POST)
	//@ResponseBody
	public void printWorksheet(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception{
		logger.info("Inside CommonServiceController :: printWorksheet method :: Execution Started");
		PrintProposalReq printProposalReq =new PrintProposalReq();
		printProposalReq.setCustomerID(httpServletRequest.getParameter("customerID"));
		printProposalReq.setProductCode(httpServletRequest.getParameter("productCode"));
		printProposalReq.setProposalDate(httpServletRequest.getParameter("proposalDate"));
		printProposalReq.setProposalNumber(httpServletRequest.getParameter("proposalNumber"));
		printProposalReq.setUserID(httpServletRequest.getParameter("userID"));
		
		//Start: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
		if (isAesEncryption!=null && isAesEncryption.equals(CommonConstants.YES_FLAG_VAL2)){
				String strIV = new String(Base64.decodeBase64(aesIv));
				String strSalt = new String(Base64.decodeBase64(aesSalt));
				String phrasePass = new String(Base64.decodeBase64(passphrase));
				String ciphertext = httpServletRequest.getParameter("password");
				AesUtil aesUtil = new AesUtil(Integer.parseInt(keySize),Integer.parseInt(iterationCount));
				//if(logger.isDebugEnabled())logger.debug("iv value ..--> "+strIV+", salt value--> "+strSalt+", ciphertext--> "+ciphertext);
				String decodePass = aesUtil.decrypt(strSalt, strIV, phrasePass, ciphertext);
				logger.info("Pasword has been decoded successfully--> "+decodePass);
				printProposalReq.setPassword(decodePass);
			}
			else{
				printProposalReq.setPassword(httpServletRequest.getParameter("password"));
				//End: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
			}
		
		//printProposalReq.setPassword(httpServletRequest.getParameter("password")); //Commented For RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		printProposalReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+printProposalReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
		comServ.printWorksheet(printProposalReq, httpServletResponse);
		logger.info("Inside CommonServiceController :: printWorksheet method :: Execution Ended");
	}
	
	/*@RequestMapping(value="/searchQuotation/", method = RequestMethod.POST)
	@ResponseBody
	public QuotationListResponse searchQuotation(@RequestBody QuotationSearchRequest quoteSearchReq,HttpServletRequest httpServletRequest) throws Exception{
		logger.info("Inside CommonServiceController :: searchQuotation method :: Execution Started");
		
		QuotationListResponse quoteList=null;
		try{
			
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				quoteSearchReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
				if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+quoteSearchReq.getAuthToken());
				//End:Vishal<VAPT comments>| code added to set GC token into user object	
			}else{
				AuthenticationRequest authReq=new AuthenticationRequest();
				Adding For Time Being
//				authReq.setUserID("3051994444");
//				authReq.setPassword("cmc123");
				Adding For Time Being
				authReq.setUserID(quoteSearchReq.getUserID());
				authReq.setPassword(quoteSearchReq.getPassword());
				authReq.setCampain(smc_campaign);
				authReq.setMedium(smc_medium);
				authReq.setSource(smc_source);
				AuthenticationResponse authResponse=null;
				
				authResponse=authService.getAuthenticationToken(authReq);
				if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
				quoteSearchReq.setAuthToken(authResponse.getResultRes());
			}			
		quoteList=comServ.searchQuote(quoteSearchReq);
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: searchQuotation method ::", ex);
		}
		logger.info("Inside CommonServiceController :: searchQuotation method :: Execution Ended");
		return quoteList;
		
	}*/
	
	@RequestMapping(value="/searchQuotation/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> searchQuotation(@RequestBody String requestJson,HttpServletRequest httpServletRequest) throws Exception{
		logger.info("Inside CommonServiceController :: searchQuotation method :: Execution Started");
		
		QuotationListResponse quoteList=null;
		String result=null;		
		QuotationSearchRequest quoteSearchReq=null;
		HttpHeaders responseHeaders =  new HttpHeaders();
		ResponseEntity responseEntity = null;
		try{
			quoteSearchReq=gson.fromJson(requestJson, QuotationSearchRequest.class);
			
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				quoteSearchReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
				//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+quoteSearchReq.getAuthToken());
				//End:Vishal<VAPT comments>| code added to set GC token into user object	
			}else{
				AuthenticationRequest authReq=new AuthenticationRequest();
				/*Adding For Time Being*/
//				authReq.setUserID("3051994444");
//				authReq.setPassword("cmc123");
				/*Adding For Time Being*/
				authReq.setUserID(quoteSearchReq.getUserID());
				authReq.setPassword(quoteSearchReq.getPassword());
				authReq.setCampain(smc_campaign);
				authReq.setMedium(smc_medium);
				authReq.setSource(smc_source);
				AuthenticationResponse authResponse=null;
				
				authResponse=authService.getAuthenticationToken(authReq);
				if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
				quoteSearchReq.setAuthToken(authResponse.getResultRes());
			}			
		quoteList=comServ.searchQuote(quoteSearchReq);
		
		if(quoteList!=null && quoteList.getQuoteList()!=null && quoteList.getQuoteList().size()>0){
			result=gson.toJson(quoteList);
			logger.info("VJ  1:- "+result+"HttpStatus.OK :- "+HttpStatus.OK +" ## "+quoteList.getQuoteList().size());
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.OK);
		}
		else{
			result="No Data Found";
			logger.info("VJ  2:- "+result+"HttpStatus.NO_CONTENT :- "+HttpStatus.NO_CONTENT+" ## "+quoteList.getQuoteList().size());
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);	
		}
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: searchQuotation method ::", ex);
			quoteList=new QuotationListResponse();
			quoteList.setResultCode(CommonConstants.FAILURE_STATUS);
			//quoteList.setMessage(ex.getMessage());
			result=gson.toJson(quoteList);
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return responseEntity;
		
	}
	
	
	@RequestMapping(value="/searchProposal/", method = RequestMethod.POST)
	@ResponseBody
	public /*ProposalSearchResponse*/ResponseEntity<String> searchProposal(@RequestBody String requestJson/*@RequestBody ProposalSearchRequest proposalSearchRequest*/,HttpServletRequest httpServletRequest) throws Exception{
		ProposalSearchResponse proposalSearchResponse=null;
		ProposalSearchRequest proposalSearchRequest=null;
		String result=null;		
		ResponseEntity responseEntity=null;
		HttpHeaders responseHeaders =  new HttpHeaders();
		try{
			logger.info("Inside CommonServiceController :: searchProposal method :: Entered");
			proposalSearchRequest=gson.fromJson(requestJson, ProposalSearchRequest.class);
			
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				proposalSearchRequest.setAuthToken(httpServletRequest.getHeader("gc_token"));
				//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+proposalSearchRequest.getAuthToken());
				//End:Vishal<VAPT comments>| code added to set GC token into user object	
			}else{
				AuthenticationRequest authReq=new AuthenticationRequest();
				authReq.setUserID(proposalSearchRequest.getUserID());
				authReq.setPassword(proposalSearchRequest.getPassword());
//				authReq.setUserID("3051994444");
//				authReq.setPassword("cmc#123");
				authReq.setCampain(smc_campaign);
				authReq.setMedium(smc_medium);
				authReq.setSource(smc_source);
				AuthenticationResponse authResponse=null;
				
				authResponse=authService.getAuthenticationToken(authReq);
				if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
				proposalSearchRequest.setAuthToken(authResponse.getResultRes());
			}
			

			
		//proposalSearchResponse=comServ.searchProposal(proposalSearchRequest);  // Method commented to change the ServiceIMPL method call : 29-Apr-2017
		proposalSearchResponse =comServ.searchProposalOnSearchScreen(proposalSearchRequest);
		
		
		if(proposalSearchResponse!=null && proposalSearchResponse.getProposalSearchResultDetList()!=null && proposalSearchResponse.getProposalSearchResultDetList().size()>0){
			result=gson.toJson(proposalSearchResponse);
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.OK);
		}
		else{
			result="No Data Found";
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);	
		}
		logger.info("Inside CommonServiceController :: searchProposal method :: Exit");
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: searchProposal method ::", ex);
			proposalSearchResponse=new ProposalSearchResponse();
			proposalSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			proposalSearchResponse.setMessage(ex.getMessage());
			result=gson.toJson(proposalSearchResponse);
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return responseEntity;
	}
	
	@RequestMapping(value="/dashboard/", method = RequestMethod.POST)
	@ResponseBody
	public AgentDashBoardResponse dashBoardPendingList(@RequestBody AgentDashBoardRequest agentDashBoardRequest,HttpServletRequest httpServletRequest) throws Exception{
		AgentDashBoardResponse agentDashBoardResponse=null;
		try{
			logger.info("Inside CommonServiceController :: dashBoardPendingList method :: Entered");
			StopWatch watch = new StopWatch();
			watch.start();
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				agentDashBoardRequest.setAuthToken(httpServletRequest.getHeader("gc_token"));
				//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+agentDashBoardRequest.getAuthToken());
				//End:Vishal<VAPT comments>| code added to set GC token into user object	
			}else{
				
				AuthenticationRequest authReq=new AuthenticationRequest();
				authReq.setUserID(agentDashBoardRequest.getUserID());
				authReq.setPassword(agentDashBoardRequest.getPassword());
				authReq.setCampain(smc_campaign);
				authReq.setMedium(smc_medium);
				authReq.setSource(smc_source);
				AuthenticationResponse authResponse=null;
				
				authResponse=authService.getAuthenticationToken(authReq);
				if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
				agentDashBoardRequest.setAuthToken(authResponse.getResultRes());
				
			}
		
		agentDashBoardResponse=comServ.dashBoardPendingList(agentDashBoardRequest);
		watch.stop();
		logger.info("Time Taken by UserController--> getUserInfoDetails service in seconds..>>"+watch.getTotalTimeSeconds());
		
		logger.info("Inside CommonServiceController :: dashBoardPendingList method :: Exit");
		
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: dashBoardPendingList method ::", ex);
			agentDashBoardResponse=new AgentDashBoardResponse();
			agentDashBoardResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			agentDashBoardResponse.setMessage(ex.getMessage());
		}
		return agentDashBoardResponse;
	}

	@RequestMapping(value="/searchPolicy/", method = RequestMethod.POST)
	@ResponseBody
	public /*PolicySearchResponse*/ResponseEntity<String> searchPolicy(@RequestBody String requestJson/*@RequestBody PolicySearchRequest policySearchRequest*/,HttpServletRequest httpServletRequest) throws Exception{
		PolicySearchResponse policySearchResponse=null;
		PolicySearchRequest policySearchRequest = null;
		String result=null;		
		HttpHeaders responseHeaders =  new HttpHeaders();
		ResponseEntity responseEntity=null;
		getPolicyDetailsEODRequest policyDetailsEODRequest = null;//Added For Issue ID 1566
		getPolicyDetailsEODResponse response = null;//Added For Issue ID 1566
		ArrayList<getPolicyDetailsEODResponse> lstResponse = null;//Added For Issue ID 1566
		try{				
			logger.info("Inside CommonServiceController :: searchPolicy method :: Entered");
			policySearchRequest=gson.fromJson(requestJson, PolicySearchRequest.class);
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				policySearchRequest.setAuthToken(httpServletRequest.getHeader("gc_token"));
				//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+policySearchRequest.getAuthToken());
				//End:Vishal<VAPT comments>| code added to set GC token into user object	
			}else{

				AuthenticationRequest authReq=new AuthenticationRequest();
				authReq.setUserID(policySearchRequest.getUserID());
				authReq.setPassword(policySearchRequest.getPassword());
//				authReq.setUserID("3051994444");
//				authReq.setPassword("cmc#123");
				authReq.setCampain(smc_campaign);
				authReq.setMedium(smc_medium);
				authReq.setSource(smc_source);
				AuthenticationResponse authResponse=null;
				
				authResponse=authService.getAuthenticationToken(authReq);
				if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
				policySearchRequest.setAuthToken(authResponse.getResultRes());
				
			}
			
		policySearchResponse=comServ.searchPolicy(policySearchRequest);
		logger.info("Inside CommonServiceController :: searchPolicy method :: Exit");
		
		if(policySearchResponse!=null && policySearchResponse.getPolicySearchResultDetList()!=null && policySearchResponse.getPolicySearchResultDetList().size()>0){
			result=gson.toJson(policySearchResponse);
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.OK);
		}
		else{
			/*Added For Issue ID 1566 - Starts Here*/
			policyDetailsEODRequest = new getPolicyDetailsEODRequest();
			PolicySearchResultDet policySearchResultDet = new PolicySearchResultDet();
			ArrayList<PolicySearchResultDet> policySearchResultDetList=new ArrayList<PolicySearchResultDet>();
			ObjectMapper objMap = new ObjectMapper();
			String strStatusDesc = null;
			policyDetailsEODRequest.setUserID(policySearchRequest.getUserID());
			policyDetailsEODRequest.setPassword(policySearchRequest.getPassword());
			policyDetailsEODRequest.setAuthToken(policySearchRequest.getAuthToken());
			policyDetailsEODRequest.setSystemIP(policySearchRequest.getSystemIP());
			policyDetailsEODRequest.setUserName(policySearchRequest.getUserName());
			policyDetailsEODRequest.setUserRole(policySearchRequest.getUserRole());
			policyDetailsEODRequest.setProducerCode(policySearchRequest.getProducerCode());
			policyDetailsEODRequest.setProducerName(policySearchRequest.getProducerName());
			policyDetailsEODRequest.setProducerMobile(policySearchRequest.getProducerMobile());
			policyDetailsEODRequest.setPolicyNumber(policySearchRequest.getPolicyNo());
			
			lstResponse = receiptService.getPolicyDetailsEOD(policyDetailsEODRequest);
			if(lstResponse!=null && lstResponse.size()>0)
			{
				response = (getPolicyDetailsEODResponse) lstResponse.get(0);
				
				policySearchResultDet.setProposalNo(response.getProposalNo());
                policySearchResultDet.setCustomerName(response.getPayerName());
                policySearchResultDet.setPolicyInceptionDate(response.getPolicyInceptionDate());
                policySearchResultDet.setPolicyNo(response.getPolicyNo());
                policySearchResultDet.setPolicyStatus(response.getStatus());
                if(policySearchResultDet.getPolicyStatus()!=null && !policySearchResultDet.getPolicyStatus().equals(CommonConstants.BLANK_STRING)){
                strStatusDesc=dbService.getCodeDesc(null, policySearchResultDet.getPolicyStatus(), CommonConstants.PROPOSAL_STATUS_CODE, "1");
                if(strStatusDesc!=null && !strStatusDesc.equals(CommonConstants.BLANK_STRING)){
              	  policySearchResultDet.setPolicyStatus(strStatusDesc);
                }
                }
                policySearchResultDet.setProducerCode(response.getProducerCode());
                policySearchResultDet.setProductName(response.getProductName());
                policySearchResultDet.setTotalPremium(response.getPremiumAmount());
                policySearchResultDet.setTransactionType(response.getProposalTransactionType());
                policySearchResultDet.setProductCode(response.getProductCode());
                policySearchResultDetList.add(policySearchResultDet);
                
                policySearchResponse.setPolicySearchResultDetList(policySearchResultDetList);
                policySearchResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
                policySearchResponse.setMessage(null);
                
                result=gson.toJson(policySearchResponse);
                logger.info("Inside CommonServiceController :: searchPolicy method through EOD Policy Search :: "+objMap.writeValueAsString(policySearchResponse));
    			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.OK);
			}
			else
			{
			/*Added For Issue ID 1566 - Ends Here*/
				result="No Data Found";
				responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);	
			}//Added For Issue ID 1566
		}
		
		
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: searchPolicy method ::", ex);
			policySearchResponse=new PolicySearchResponse();
			policySearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			policySearchResponse.setMessage(ex.getMessage());
			result=gson.toJson(policySearchResponse);
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
		}		
		return responseEntity;
	}
	
	/*
	 * Added for renewal count Service
	 */
	@RequestMapping(value="/renewalCalCount/", method = RequestMethod.POST)
	@ResponseBody
	public RenewalCalCountResponse renewalCalCount(@RequestBody RenewalCalCountRequest renewalCalCountRequest,HttpServletRequest httpServletRequest) throws Exception{
		RenewalCalCountResponse renewalCalCountResponse=null;
		ObjectMapper objMap=new ObjectMapper();
		try{
			logger.info("Inside CommonServiceController :: renewalCalCount method :: Entered");
			/*AuthenticationRequest authReq=new AuthenticationRequest();
			authReq.setUserID(renewalCalCountRequest.getUserID());
			authReq.setPassword(renewalCalCountRequest.getPassword());
			authReq.setCampain(smc_campaign);
			authReq.setMedium(smc_medium);
			authReq.setSource(smc_source);
			AuthenticationResponse authResponse=null;
			
		authResponse=authService.getAuthenticationToken(authReq);
		if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
			renewalCalCountRequest.setAuthToken(authResponse.getResultRes());*/
			
			//if(logger.isDebugEnabled())
				logger.debug("Inside CommonServiceController :: renewalCalCount method :: Request JSON::"+objMap.writeValueAsString(renewalCalCountRequest));
		renewalCalCountResponse=comServ.getRenewalCalCount(renewalCalCountRequest);
		
		logger.info("Inside CommonServiceController :: renewalCalCount method :: Exit");
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: renewalCalCount method ::", ex);
			renewalCalCountResponse=new RenewalCalCountResponse();
			renewalCalCountResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			renewalCalCountResponse.setMessage(ex.getMessage());
		}
		//if(logger.isDebugEnabled())
			logger.debug("Inside CommonServiceController :: renewalCalCount method :: Response JSON::"+objMap.writeValueAsString(renewalCalCountResponse));
		return renewalCalCountResponse;
	}
	

	/*
	 * Added for Renewal Search
	 */
	@RequestMapping(value="/renewalSearch/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> renewalSearch(@RequestBody String requestJson,HttpServletRequest httpServletRequest) throws Exception{
		RenewalSearchResponse renewalSearchResponse=null;
		RenewalSearchRequest renewalSearchRequest=null;
		String result=null;		
		HttpHeaders responseHeaders =  new HttpHeaders();
		ResponseEntity responseEntity=null;
		ObjectMapper objMap=new ObjectMapper();
		try{
			logger.info("Inside CommonServiceController :: renewalSearch method :: Entered");
			/*AuthenticationRequest authReq=new AuthenticationRequest();
			authReq.setUserID(renewalCalCountRequest.getUserID());
			authReq.setPassword(renewalCalCountRequest.getPassword());
			authReq.setCampain(smc_campaign);
			authReq.setMedium(smc_medium);
			authReq.setSource(smc_source);
			AuthenticationResponse authResponse=null;
			
		authResponse=authService.getAuthenticationToken(authReq);
		if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
			renewalCalCountRequest.setAuthToken(authResponse.getResultRes());*/
			
			renewalSearchRequest=gson.fromJson(requestJson, RenewalSearchRequest.class);
			
			//if(logger.isDebugEnabled())
				logger.debug("Inside CommonServiceController :: renewalSearch method :: Request JSON::"+objMap.writeValueAsString(renewalSearchRequest));
			// Start : <Vishal> : Mantis :- 3267 : To Renewal Search from Portal.
			renewalSearchResponse = comServ.renewalSearchPortal(renewalSearchRequest);
			if(renewalSearchResponse==null || renewalSearchResponse.getRenewalSearchDataList()==null || renewalSearchResponse.getRenewalSearchDataList().size()==0){
				logger.debug("Inside CommonServiceController :: renewalSearch method :: Calling ESB Services");
				renewalSearchResponse =comServ.getRenewalSearch(renewalSearchRequest);
			}
			// End : <Vishal> : Mantis :- 3267 : To Renewal Search from Portal.				
				
			if(renewalSearchResponse!=null && renewalSearchResponse.getRenewalSearchDataList()!=null && renewalSearchResponse.getRenewalSearchDataList().size()>0){
				result=gson.toJson(renewalSearchResponse);
				responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.OK);
			}
			else{
				result="No Data Found";
				responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);	
			}
			
		logger.info("Inside CommonServiceController :: renewalCalCount method :: Exit");
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: renewalCalCount method ::", ex);
			renewalSearchResponse=new RenewalSearchResponse();
			renewalSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			renewalSearchResponse.setMessage(ex.getMessage());
			result=gson.toJson(renewalSearchResponse);
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		//if(logger.isDebugEnabled())logger.debug("Inside CommonServiceController :: renewalCalCount method :: Response JSON::"+objMap.writeValueAsString(renewalSearchRequest));
		return responseEntity;
	}
	
	/*
	 * Added to get Producer code after Giving Dealer Code	 
	 */
	
	@RequestMapping(value="/getDealerInfo/", method = RequestMethod.POST)
	@ResponseBody
	public UserInfoResponse getDealerInfo(@RequestBody UserObject userObject,HttpServletRequest httpServletRequest) throws Exception{
		UserInfoResponse userInfoRes=null;
		String strMethodName = "getDealerInfo";
		ObjectMapper objMap=new ObjectMapper();
		try{
			logger.info("Inside CommonServiceController :: "+strMethodName+" method :: Entered");
			/*AuthenticationRequest authReq=new AuthenticationRequest();
			authReq.setUserID(renewalCalCountRequest.getUserID());
			authReq.setPassword(renewalCalCountRequest.getPassword());
			authReq.setCampain(smc_campaign);
			authReq.setMedium(smc_medium);
			authReq.setSource(smc_source);
			AuthenticationResponse authResponse=null;
			
		authResponse=authService.getAuthenticationToken(authReq);
		if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
			renewalCalCountRequest.setAuthToken(authResponse.getResultRes());*/
			
			//if(logger.isDebugEnabled())
				logger.debug("Inside CommonServiceController :: "+strMethodName+" method :: Request JSON::"+objMap.writeValueAsString(userObject));
			userInfoRes =comServ.getDealerInfo(userObject);
		
		logger.info("Inside CommonServiceController :: "+strMethodName+" method :: Exit");
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: "+strMethodName+" method ::", ex);
			userInfoRes=new UserInfoResponse();
			userInfoRes.setResultCode(CommonConstants.FAILURE_STATUS);
			userInfoRes.setMessage(ex.getMessage());
		}
		//if(logger.isDebugEnabled())
			logger.debug("Inside CommonServiceController :: "+strMethodName+" method :: Response JSON::"+objMap.writeValueAsString(userObject));
		return userInfoRes;
	}
	
	
	
	/*
	 * Added for GetRenewalPolicyDetails
	 */
	
	@RequestMapping(value="/printRenewalPolicyLetter/", method = RequestMethod.POST)
	@ResponseBody
	public RenewalPolLetterResponse printRenPolLetter(@RequestBody RenewalPolLetterRequest renPolLetRequest,HttpServletRequest httpServletRequest) throws Exception{
		RenewalPolLetterResponse renPolLetResponse=null;
		String strMethodName = "printRenPolLetter";
		ObjectMapper objMap=new ObjectMapper();
		try{
			logger.info("Inside CommonServiceController :: printRenPolLetter method :: Entered");
			/*AuthenticationRequest authReq=new AuthenticationRequest();
			authReq.setUserID(renewalCalCountRequest.getUserID());
			authReq.setPassword(renewalCalCountRequest.getPassword());
			authReq.setCampain(smc_campaign);
			authReq.setMedium(smc_medium);
			authReq.setSource(smc_source);
			AuthenticationResponse authResponse=null;
			
		authResponse=authService.getAuthenticationToken(authReq);
		if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
			renewalCalCountRequest.setAuthToken(authResponse.getResultRes());*/
			
			//if(logger.isDebugEnabled())
				logger.debug("Inside CommonServiceController :: "+strMethodName+"method :: Request JSON::"+objMap.writeValueAsString(renPolLetRequest));
			renPolLetResponse =comServ.printRenewalPolicyLetter(renPolLetRequest);
		
		logger.info("Inside CommonServiceController ::"+strMethodName+" method :: Exit");
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: "+strMethodName+" method ::", ex);
			renPolLetResponse=new RenewalPolLetterResponse();
			renPolLetResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			renPolLetResponse.setMessage(ex.getMessage());
		}
		//if(logger.isDebugEnabled())
			logger.debug("Inside CommonServiceController :: "+strMethodName+" method :: Response JSON::"+objMap.writeValueAsString(renPolLetRequest));
		return renPolLetResponse;
	}
	
	//Start: RahulT| Added to get SPL expired links on dashboard  
	@RequestMapping(value="/dashboardSPLPendingList/", method = RequestMethod.POST)
	@ResponseBody
	public AgentDashBoardResponse dashBoardSPLPendingList(@RequestBody AgentDashBoardRequest agentDashBoardRequest,HttpServletRequest httpServletRequest) throws Exception{
		AgentDashBoardResponse agentDashBoardResponse=null;
		try{
			logger.info("Inside CommonServiceController :: dashBoardSPLPendingList method :: Entered");
			StopWatch watch = new StopWatch();
			watch.start();
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				agentDashBoardRequest.setAuthToken(httpServletRequest.getHeader("gc_token"));
				//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+agentDashBoardRequest.getAuthToken());
				//End:Vishal<VAPT comments>| code added to set GC token into user object	
			}else{
				
				AuthenticationRequest authReq=new AuthenticationRequest();
				authReq.setUserID(agentDashBoardRequest.getUserID());
				authReq.setPassword(agentDashBoardRequest.getPassword());
				authReq.setCampain(smc_campaign);
				authReq.setMedium(smc_medium);
				authReq.setSource(smc_source);
				AuthenticationResponse authResponse=null;
				
				authResponse=authService.getAuthenticationToken(authReq);
				if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
				agentDashBoardRequest.setAuthToken(authResponse.getResultRes());
				
			}
		
		agentDashBoardResponse=comServ.dashBoardSPLPendingList(agentDashBoardRequest);
		watch.stop();
		logger.info("Time Taken by CommonServiceController--> dashBoardSPLPendingList service in seconds..>>"+watch.getTotalTimeSeconds());
		
		logger.info("Inside CommonServiceController :: dashBoardSPLPendingList method :: Exit");
		
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: dashBoardSPLPendingList method ::", ex);
			agentDashBoardResponse=new AgentDashBoardResponse();
			agentDashBoardResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			agentDashBoardResponse.setMessage(ex.getMessage());
		}
		return agentDashBoardResponse;
	}
	
	@RequestMapping(value="/dashBoardRejectedList/", method = RequestMethod.POST)
	@ResponseBody
	public AgentDashBoardResponse dashBoardRejectedList(@RequestBody AgentDashBoardRequest agentDashBoardRequest,HttpServletRequest httpServletRequest) throws Exception{
		AgentDashBoardResponse agentDashBoardResponse=null;
		try{
			logger.info("Inside CommonServiceController :: dashBoardRejectedList method :: Entered");
			StopWatch watch = new StopWatch();
			watch.start();
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				agentDashBoardRequest.setAuthToken(httpServletRequest.getHeader("gc_token"));
				//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+agentDashBoardRequest.getAuthToken());
				//End:Vishal<VAPT comments>| code added to set GC token into user object	
			}else{
				
				AuthenticationRequest authReq=new AuthenticationRequest();
				authReq.setUserID(agentDashBoardRequest.getUserID());
				authReq.setPassword(agentDashBoardRequest.getPassword());
				authReq.setCampain(smc_campaign);
				authReq.setMedium(smc_medium);
				authReq.setSource(smc_source);
				AuthenticationResponse authResponse=null;
				
				authResponse=authService.getAuthenticationToken(authReq);
				if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
				agentDashBoardRequest.setAuthToken(authResponse.getResultRes());
				
			}
		
		agentDashBoardResponse=comServ.dashBoardRejectedList(agentDashBoardRequest);
		watch.stop();
		logger.info("Time Taken by CommonServiceController--> dashBoardRejectedList service in seconds..>>"+watch.getTotalTimeSeconds());
		
		logger.info("Inside CommonServiceController :: dashBoardRejectedList method :: Exit");
		
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: dashBoardPendingList method ::", ex);
			agentDashBoardResponse=new AgentDashBoardResponse();
			agentDashBoardResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			agentDashBoardResponse.setMessage(ex.getMessage());
		}
		return agentDashBoardResponse;
	}
	
	@RequestMapping(value="/getDocumentListFromGC/", method = RequestMethod.POST)
	@ResponseBody
	public List<DocumentListGCResponse> getDocumentList(@RequestBody DocumentListGCRequest documentRequest,HttpServletRequest httpServletRequest) throws Exception{
		RenewalPolLetterResponse renPolLetResponse=null;
		String strMethodName = "getDocumentList";
		ObjectMapper objMap=new ObjectMapper();
		List<DocumentListGCResponse> documentResponseLst = new ArrayList<DocumentListGCResponse>(); 
		try{
			//if(logger.isDebugEnabled())
				logger.debug("Inside CommonServiceController :: "+strMethodName+"method :: Request JSON::"+objMap.writeValueAsString(documentRequest));
			StopWatch watch = new StopWatch();
			watch.start();
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING))
				documentRequest.setAuthToken(httpServletRequest.getHeader("gc_token"));
			
			documentResponseLst = documentLstService.getDocumentListGC(documentRequest);
			watch.stop();
			//if(logger.isDebugEnabled())logger.info("Time Taken by CommonServiceController--> getDocumentList service in seconds..>>"+watch.getTotalTimeSeconds());
		
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: "+strMethodName+" method ::", ex);
			renPolLetResponse=new RenewalPolLetterResponse();
			renPolLetResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			renPolLetResponse.setMessage(ex.getMessage());
		}
		//if(logger.isDebugEnabled())
			logger.debug("Inside CommonServiceController :: "+strMethodName+" method :: Response JSON::"+objMap.writeValueAsString(documentResponseLst));
		return documentResponseLst;
	}
	
	@RequestMapping(value="/getMinPaymentDateForPortalLock/", method = RequestMethod.POST)
	@ResponseBody
	public Map<String,String> getMinPaymentDateForPortalLock(@RequestBody UserObject userObject, HttpServletRequest httpServletRequest) throws Exception{
		String strMethodName = "getMinPaymentDateForPortalLock";
		ObjectMapper objMap=new ObjectMapper();
		Map<String,String> responseMap = new HashMap<String,String>(); 
		try{
			
			StopWatch watch = new StopWatch();
			watch.start();			
			responseMap = comServ.getMinPaymentDateForPortalLock(userObject.getUserID());
			watch.stop();
			
			//if(logger.isDebugEnabled())logger.info("Time Taken by CommonServiceController--> getMinPaymentDateForPortalLock service in seconds..>>"+watch.getTotalTimeSeconds());
		
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: "+strMethodName+" method ::", ex);
		}
		//if(logger.isDebugEnabled())
			logger.debug("Inside CommonServiceController :: "+strMethodName+" method :: Response JSON::"+objMap.writeValueAsString(responseMap));
		return responseMap;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/getPortalLockDays/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> getPortalLockDays(@RequestBody String strRequestJson, HttpServletRequest httpServletRequest) throws Exception{
		String strMethodName = "getPortalLockDays";
		ResponseEntity<String> response = null;
		Gson gson = new Gson();
		HttpHeaders responseHeaders =  new HttpHeaders();
		boolean portalLockFlag=false;
		String result="Success";
		try{
			PortalLockDaysRequest request = gson.fromJson(strRequestJson, PortalLockDaysRequest.class);
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING))
				request.setAuthToken(httpServletRequest.getHeader("gc_token"));
			
			StopWatch watch = new StopWatch();
			watch.start();			
			//response = comServ.getPortalLockDays(request);
			portalLockFlag = comServ.getPortalLockDays(request);
			watch.stop();
			//if(logger.isDebugEnabled())logger.info("Time Taken by CommonServiceController--> getPortalLockDays service in seconds..>>"+watch.getTotalTimeSeconds());
			
			if(portalLockFlag){
				result="Payment/s Pending. New Transactions locked. Deposit pending payments to Unlock";
				return new ResponseEntity(result,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
			}else{
				return new ResponseEntity(result,responseHeaders,HttpStatus.OK);
			}
			
			
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: "+strMethodName+" method ::", ex);
			return new ResponseEntity(ex.getMessage(),responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		//return response;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/portalLockPayInSlip/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> portalLockPayInSlip(@RequestBody String strRequestJson, HttpServletRequest httpServletRequest) throws Exception{
		String strMethodName = "portalLockPayInSlip";
		Gson gson = new Gson();
		HttpHeaders responseHeaders =  new HttpHeaders();
		String result="Success";
		try{
			UserObject request = gson.fromJson(strRequestJson, UserObject.class);
			
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING))
				request.setAuthToken(httpServletRequest.getHeader("gc_token"));
			
			StopWatch watch = new StopWatch();
			watch.start();
			PortalLockDetails portalLockDetails = comServ.getPendingPayInSlipCount(request);
			watch.stop();
			//if(logger.isDebugEnabled())logger.info("Time Taken by CommonServiceController--> getPortalLockDays service in seconds..>>"+watch.getTotalTimeSeconds());
			if(portalLockDetails!=null && portalLockDetails.isPortalLock()){
				return new ResponseEntity(portalLockDetails,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
			}else{
				return new ResponseEntity(portalLockDetails,responseHeaders,HttpStatus.OK);
			}
			
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: "+strMethodName+" method ::", ex);
			return new ResponseEntity(ex.getMessage(),responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
		
	@RequestMapping(value="/getPendingApprovalList/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> getPendingApprovalList(@RequestBody String requestJson,HttpServletRequest httpServletRequest) throws Exception{
		String methodName ="getPendingApprovalList"; 
		AgentDashBoardResponse agentDashBoardResponse=null;
		AgentDashBoardRequest agentDashBoardRequest=null;
		String result=null;
		
		HttpHeaders responseHeaders =  new HttpHeaders();
		try{
			logger.info("Inside CommonServiceController :: "+methodName+"method :: Entered");
			StopWatch watch = new StopWatch();
			watch.start();
			
			agentDashBoardRequest=gson.fromJson(requestJson, AgentDashBoardRequest.class);
			
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				agentDashBoardRequest.setAuthToken(httpServletRequest.getHeader("gc_token"));
				//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+agentDashBoardRequest.getAuthToken());
				//End:Vishal<VAPT comments>| code added to set GC token into user object	
			}else{
				
				AuthenticationRequest authReq=new AuthenticationRequest();
				authReq.setUserID(agentDashBoardRequest.getUserID());
				authReq.setPassword(agentDashBoardRequest.getPassword());
				authReq.setCampain(smc_campaign);
				authReq.setMedium(smc_medium);
				authReq.setSource(smc_source);
				AuthenticationResponse authResponse=null;
				
				authResponse=authService.getAuthenticationToken(authReq);
				if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
				agentDashBoardRequest.setAuthToken(authResponse.getResultRes());
				
			}
		
		agentDashBoardResponse=comServ.getPendingApprovalList(agentDashBoardRequest);
		watch.stop();
		//if(logger.isDebugEnabled())logger.debug("Time Taken by CommonServiceController-->"+methodName+"service in seconds..>>"+watch.getTotalTimeSeconds());
		
	//if(logger.isDebugEnabled())logger.debug("Inside CommonServiceController :: "+methodName+" method :: Exit");
		
		if(agentDashBoardResponse!=null && agentDashBoardResponse.getPendingApprovalList()!=null){
			result=gson.toJson(agentDashBoardResponse);
			return  new ResponseEntity(result,responseHeaders,HttpStatus.OK);
		}
		else{
			result="No Data Found";
			return  new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);	
		}
		

		
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: dashBoardPendingList method ::", ex);
			agentDashBoardResponse=new AgentDashBoardResponse();
			agentDashBoardResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			agentDashBoardResponse.setMessage(ex.getMessage());
			result=gson.toJson(agentDashBoardResponse);
			return  new ResponseEntity(result,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		//return  new ResponseEntity(result,responseHeaders,HttpStatus.OK);
	}
	
	
	
	/**
	 * @param agentDashBoardRequest
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 * This method calls the service implementation method
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/getPendingInspectionDetailsForPortal/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String>  getPendingInspectionDetailsForPortal(@RequestBody String requestJson,HttpServletRequest httpServletRequest) throws Exception
	{
        AgentDashBoardResponse agentDashBoardResponse=null;
        AgentDashBoardRequest agentDashBoardRequest=null;
        String result=null;        
        HttpHeaders responseHeaders =  new HttpHeaders();
		
		try{
			StopWatch watch = new StopWatch();
			watch.start();
			logger.info("Inside CommonServiceController :: getPendingInspectionDetailsForPortal method :: Entered");
			agentDashBoardRequest=gson.fromJson(requestJson, AgentDashBoardRequest.class);
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				agentDashBoardRequest.setAuthToken(httpServletRequest.getHeader("gc_token"));
				//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+agentDashBoardRequest.getAuthToken());
			}
			else
			{
				AuthenticationRequest authReq=new AuthenticationRequest();
				authReq.setUserID(agentDashBoardRequest.getUserID());
				authReq.setPassword(agentDashBoardRequest.getPassword());
				authReq.setCampain(smc_campaign);
				authReq.setMedium(smc_medium);
				authReq.setSource(smc_source);
				AuthenticationResponse authResponse=null;
				authResponse=authService.getAuthenticationToken(authReq);
				if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
				agentDashBoardRequest.setAuthToken(authResponse.getResultRes());
			    
			}
			
		    agentDashBoardResponse=comServ.getPendingInspectionDetailsForPortal(agentDashBoardRequest);
		    watch.stop();
		logger.info("Time Taken by CommonServiceController--> getPendingInspectionDetailsForPortal service in seconds..>>"+watch.getTotalTimeSeconds());
		   if(agentDashBoardResponse!=null )
		    {
            result=gson.toJson(agentDashBoardResponse);
            return  new ResponseEntity(result,responseHeaders,HttpStatus.OK);
            }
          else
            {
            result="No Data Found";
            return  new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);  
             }
     

		   }	
		catch(Exception ex){
			logger.error("Inside CommonServiceController :: getPendingInspectionDetailsForPortal method ::", ex);
            agentDashBoardResponse=new AgentDashBoardResponse();
            agentDashBoardResponse.setResultCode(CommonConstants.FAILURE_STATUS);
            agentDashBoardResponse.setMessage(ex.getMessage());
            result=gson.toJson(agentDashBoardResponse);
            return  new ResponseEntity(result,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);

		}
  }
@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/portalLockEODReceipting/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity portalLockEODReceipting(@RequestBody String strRequestJson, HttpServletRequest httpServletRequest) throws Exception{
		String strMethodName = "getPendingPayInSlipCount";
		Gson gson = new Gson();
		HttpHeaders responseHeaders =  new HttpHeaders();
		String result="Success";
		PortalLockDetails portalLockDtl = new PortalLockDetails(); 
		try{
			UserObject request = gson.fromJson(strRequestJson, UserObject.class);
			
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING))
				request.setAuthToken(httpServletRequest.getHeader("gc_token"));
			
			StopWatch watch = new StopWatch();
			watch.start();
			portalLockDtl = comServ.portalLockEODReceipting(request);
			watch.stop();
			//if(logger.isDebugEnabled())logger.info("Time Taken by CommonServiceController--> getPortalLockDays service in seconds..>>"+watch.getTotalTimeSeconds());
			if(portalLockDtl!=null && portalLockDtl.isPortalLock()){
				return new ResponseEntity(portalLockDtl,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
			}else{
				return new ResponseEntity(portalLockDtl,responseHeaders,HttpStatus.OK);
			}
	
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: "+strMethodName+" method ::", ex);
			return new ResponseEntity(ex.getMessage(),responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}	
//Start: RahulT <VAPT Point 2: Production 1345> | added new service for printReceipt to bifurgate call from portal and SPL's Jsp page
	@RequestMapping(value="/printProposalSPL/", method = RequestMethod.POST)
	//@ResponseBody
	public void printProposalSPL(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception{
		
		logger.info("Inside CommonServiceController :: printProposal method :: Execution Started");
		PrintProposalReq printProposalReq =new PrintProposalReq();
		printProposalReq.setCustomerID(httpServletRequest.getParameter("customerID"));
		printProposalReq.setProductCode(httpServletRequest.getParameter("productCode"));
		printProposalReq.setProposalDate(httpServletRequest.getParameter("proposalDate"));
		printProposalReq.setProposalNumber(httpServletRequest.getParameter("proposalNumber"));
		printProposalReq.setUserID(httpServletRequest.getParameter("userID"));
		printProposalReq.setPassword(httpServletRequest.getParameter("password"));
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		printProposalReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+printProposalReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
		comServ.printProposal(printProposalReq, httpServletResponse);
		logger.info("Inside CommonServiceController :: printProposal method :: Execution Ended");
	}
	
	
	@RequestMapping(value="/printPolicySPL/", method = RequestMethod.POST)
	//@ResponseBody
	public void printPolicySPL(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception{
		logger.info("Inside CommonServiceController :: printPolicy method :: Execution Started");
		PrintProposalReq printProposalReq =new PrintProposalReq();
		printProposalReq.setCustomerID(httpServletRequest.getParameter("customerID"));
		printProposalReq.setProductCode(httpServletRequest.getParameter("productCode"));
		printProposalReq.setProposalDate(httpServletRequest.getParameter("proposalDate"));
		printProposalReq.setProposalNumber(httpServletRequest.getParameter("proposalNumber"));
		printProposalReq.setUserID(httpServletRequest.getParameter("userID"));
		printProposalReq.setPassword(httpServletRequest.getParameter("password"));
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		printProposalReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+printProposalReq.getAuthToken());
		//End:Vishal<VAPT comments>| code added to set GC token into user object
		comServ.printPolicy(printProposalReq, httpServletResponse);
		logger.info("Inside CommonServiceController :: printPolicy method :: Execution Ended");
	}
	//End: RahulT <VAPT Point 2: Production 1345> | added new service for printReceipt to bifurgate call from portal and SPL's Jsp page	
@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/getValueByEffDate/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity getValueByEffDate(@RequestBody String strRequestJson, HttpServletRequest httpServletRequest) throws Exception{
		String strMethodName = "getValueByEffDate";
		Gson gson = new Gson();
		HttpHeaders responseHeaders =  new HttpHeaders();
		String result="Success";		
		ValueByEffDateResponse effDateResponse = new ValueByEffDateResponse(); 
		try{
			ValueByEffDateRequest request = gson.fromJson(strRequestJson, ValueByEffDateRequest.class);
			
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING))
				request.setAuthToken(httpServletRequest.getHeader("gc_token"));
			
			StopWatch watch = new StopWatch();
			watch.start();
			effDateResponse = comServ.getValueByEffDate(request);
			watch.stop();
			//if(logger.isDebugEnabled())logger.info("Time Taken by CommonServiceController--> getPortalLockDays service in seconds..>>"+watch.getTotalTimeSeconds());
			if(effDateResponse!=null ){
				return new ResponseEntity(effDateResponse,responseHeaders,HttpStatus.OK);
			}else{
				return new ResponseEntity(effDateResponse,responseHeaders,HttpStatus.OK);
			}
			
		}catch(Exception ex){
			logger.error("Inside CommonServiceController :: "+strMethodName+" method ::", ex);
			return new ResponseEntity(ex.getMessage(),responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
			//Start: KetanM <SIT 2594>| service exposed to getFastLaneIntegration on 29 Nov 2017
				@RequestMapping(value="/getFastLaneIntegration/", method = RequestMethod.POST)
				@ResponseBody
				public FastLaneResponse getFastLaneIntegration(@RequestBody FastLaneRequest fastLaneRequest, HttpServletRequest httpServletRequest) throws Exception{
					String strMethodName = "getFastLaneIntegration";
					FastLaneResponse fastLaneResponse = new FastLaneResponse();
					ObjectMapper objMap=new ObjectMapper();
					
					try{
						logger.info("Inside CommonServiceController :: " +strMethodName+ " method :: Entered");
						//if(logger.isDebugEnabled())
							logger.debug("Inside CommonServiceController :: "+strMethodName+"method :: Request JSON::"+objMap.writeValueAsString(fastLaneRequest));
						
						StopWatch watch = new StopWatch();
						watch.start();
						fastLaneResponse = comServ.getFastLaneIntegration(fastLaneRequest);
						watch.stop();
						//if(logger.isDebugEnabled())logger.info("Time Taken by CommonServiceController--> getFastLaneIntegration service in seconds..>> "+watch.getTotalTimeSeconds());
						
						logger.info("Inside CommonServiceController ::"+strMethodName+" method :: Exit");
					}catch(Exception ex){
						logger.error("Inside CommonServiceController :: "+strMethodName+" method ::", ex);
						fastLaneResponse=new FastLaneResponse();
						fastLaneResponse.setResultCode(CommonConstants.FAILURE_STATUS);
						fastLaneResponse.setMessage(CommonConstants.FASTLANE_EXCEPTION);
					}
					
					//if(logger.isDebugEnabled())
						logger.debug("Inside CommonServiceController :: "+strMethodName+" method :: Response JSON::"+objMap.writeValueAsString(fastLaneResponse));			
					return fastLaneResponse;
				}
			//End: KetanM <SIT 2594>| service exposed to getFastLaneIntegration on 29 Nov 2017
			//Start: KetanM <SIT 2717>| service exposed to getHouseBankAndAccountNo on 11 Dec 2017
				@RequestMapping(value="/getHouseBankAndAccountNo/", method = RequestMethod.POST)
				@ResponseBody
				public HouseBankAccNoResponse getHouseBankAndAccountNo(@RequestBody HouseBankAccNoRequest houseBankAccNoRequest, HttpServletRequest httpServletRequest) throws Exception{
					String strMethodName = "getHouseBankAndAccountNo";
					HouseBankAccNoResponse houseBankAccNoResponse = new HouseBankAccNoResponse();
					ObjectMapper objMap=new ObjectMapper();
					
					try{
						logger.info("Inside CommonServiceController :: " +strMethodName+ " method :: Entered");
						//if(logger.isDebugEnabled())
							logger.debug("Inside CommonServiceController :: "+strMethodName+" method :: Request JSON::"+objMap.writeValueAsString(houseBankAccNoRequest));
						
						StopWatch watch = new StopWatch();
						watch.start();
						houseBankAccNoResponse = comServ.getHouseBankAndAccountNo_portal(houseBankAccNoRequest);
						watch.stop();
						//if(logger.isDebugEnabled())logger.info("Time Taken by CommonServiceController--> getHouseBankAndAccountNo service in seconds..>> "+watch.getTotalTimeSeconds());
						
						logger.info("Inside CommonServiceController ::"+strMethodName+" method :: Exit");
					}catch(Exception ex){
						logger.error("Inside CommonServiceController :: "+strMethodName+" method ::", ex);
						houseBankAccNoResponse=new HouseBankAccNoResponse();
						houseBankAccNoResponse.setResultCode(CommonConstants.FAILURE_STATUS);
						houseBankAccNoResponse.setMessage(CommonConstants.FASTLANE_EXCEPTION);
					}
					
					//if(logger.isDebugEnabled())
						logger.debug("Inside CommonServiceController :: "+strMethodName+" method :: Response JSON::"+objMap.writeValueAsString(houseBankAccNoResponse));			
					return houseBankAccNoResponse;
				}
			//End: KetanM <SIT 2717>| service exposed to getHouseBankAndAccountNo on 11 Dec 2017
				
				//Start: VishalJ <New Report Issue>| Service to be created for giving token
				@RequestMapping(value="/getQlikTicketNo/", method = RequestMethod.POST)
				@ResponseBody
				public QlikTicketResponse getQlikTicketNo(@RequestBody UserObject userObject, HttpServletRequest httpServletRequest) throws Exception{
					String strMethodName = "getQlikTicketNo";
					QlikTicketResponse qlikTicketResponse = new QlikTicketResponse();
					ObjectMapper objMap=new ObjectMapper();
					
					try{
						logger.info("Inside CommonServiceController :: " +strMethodName+ " method :: Entered");
						if(logger.isDebugEnabled())
							logger.debug("Inside CommonServiceController :: "+strMethodName+" method :: Request JSON::"+objMap.writeValueAsString(userObject));
						
						StopWatch watch = new StopWatch();
						watch.start();
						qlikTicketResponse = comServ.getQlikTicketNo(userObject);
						watch.stop();
						if(logger.isDebugEnabled())logger.info("Time Taken by CommonServiceController--> getQlikTicketNo service in seconds..>> "+watch.getTotalTimeSeconds());
						
						logger.info("Inside CommonServiceController ::"+strMethodName+" method :: Exit");
					}catch(Exception ex){
						logger.error("Inside CommonServiceController :: "+strMethodName+" method ::", ex);
						qlikTicketResponse=new QlikTicketResponse();
						qlikTicketResponse.setResultCode(CommonConstants.FAILURE_STATUS);
						qlikTicketResponse.setMessage(CommonConstants.FASTLANE_EXCEPTION);
					}
					
					if(logger.isDebugEnabled())
						logger.debug("Inside CommonServiceController :: "+strMethodName+" method :: Response JSON::"+objMap.writeValueAsString(qlikTicketResponse));			
					return qlikTicketResponse;
				}
			//End:VishalJ <New Report Issue>| Service to be created for giving token
				
				/*Code Added For Reports Changes - Starts Here*/
				@RequestMapping(value="/getEncryptedProducerCode/", method = RequestMethod.POST)
				@ResponseBody
				public String getEncryptedProducerCode(@RequestBody String producerCode, HttpServletRequest httpServletRequest) throws Exception{
					String strMethodName = "getEncryptedProducerCode";
					String respString = null;
					try
					{
						logger.info("Inside CommonServiceController :: " +strMethodName+ " method :: Entered");
						respString = comServ.getEncryptedProducerCode(producerCode);
						
					}catch(Exception ex)
					{
						logger.error(strMethodName+" method ::", ex);
					}
					return respString;
				}
				/*Code Added For Reports Changes - Ends Here*/

}

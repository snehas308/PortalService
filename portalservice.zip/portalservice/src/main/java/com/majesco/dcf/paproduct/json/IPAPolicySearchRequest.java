package com.majesco.dcf.paproduct.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class IPAPolicySearchRequest extends UserObject{

	private String propopsalNo;
	private String policyNo;
	private String quoteNo;
	private String productCode;
	private String customerID;
	private String producerCode;
	private String customerName;
	private String polInceptionDate;
	private String polExpiryDate;
	
	public String getPropopsalNo() {
		return propopsalNo;
	}
	public void setPropopsalNo(String propopsalNo) {
		this.propopsalNo = propopsalNo;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getQuoteNo() {
		return quoteNo;
	}
	public void setQuoteNo(String quoteNo) {
		this.quoteNo = quoteNo;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public String getProducerCode() {
		return producerCode;
	}
	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPolInceptionDate() {
		return polInceptionDate;
	}
	public void setPolInceptionDate(String polInceptionDate) {
		this.polInceptionDate = polInceptionDate;
	}
	public String getPolExpiryDate() {
		return polExpiryDate;
	}
	public void setPolExpiryDate(String polExpiryDate) {
		this.polExpiryDate = polExpiryDate;
	}
	
}

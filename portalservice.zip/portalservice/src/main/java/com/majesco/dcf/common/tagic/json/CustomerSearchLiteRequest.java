package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CustomerSearchLiteRequest {
	
	private String producerCD;//ProducerCode
	private String cistId;//CustomerID
	private String firstName;//FirstName
	private String lastName;//LastName
	private String mob;//MobileNo
	private String frmDate;//FromDate
	private String toDate;//ToDate
	private String pin;//Pincode 
	private String city;//City
	private String policyNbr;//PolicyNo  
	private String propNbr;//ProposalNo
	private String quotNbr;//QuoteNo
	//private String authenticationToken;
	public String getProducerCD() {
		return producerCD;
	}
	public void setProducerCD(String producerCD) {
		this.producerCD = producerCD;
	}
	public String getCistId() {
		return cistId;
	}
	public void setCistId(String cistId) {
		this.cistId = cistId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getFrmDate() {
		return frmDate;
	}
	public void setFrmDate(String frmDate) {
		this.frmDate = frmDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPolicyNbr() {
		return policyNbr;
	}
	public void setPolicyNbr(String policyNbr) {
		this.policyNbr = policyNbr;
	}
	public String getPropNbr() {
		return propNbr;
	}
	public void setPropNbr(String propNbr) {
		this.propNbr = propNbr;
	}
	public String getQuotNbr() {
		return quotNbr;
	}
	public void setQuotNbr(String quotNbr) {
		this.quotNbr = quotNbr;
	}
//	public String getAuthenticationToken() {
//		return authenticationToken;
//	}
//	public void setAuthenticationToken(String authenticationToken) {
//		this.authenticationToken = authenticationToken;
//	}
	
	

}

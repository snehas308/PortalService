package com.majesco.dcf.paproduct.json;

import com.majesco.dcf.common.tagic.json.IdDetails;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class InsuredDetails {
	
	private String insuTitle;
	private String insuName;
	private String relationship;
	private String dob;
	private String age;
	private String gender;
	private String maritalStatus;
	private String occupation;
	private String baseSumInsured;
	private String escalationAmt;
	private String sumInsured;
	private String anyOtherPAInsurance;
	private String nameOfInsurer;
	private String otherPAInsurancePolNum;
	private String pedIllInjuryDisableTwoYears;//Any PED/Illness/Injury/Disability In Last Two Years
	private String pedIllInjuryDisableName;
	private String premiumAmount;
	private IdDetails idList;
	
	public IdDetails getIdList() {
		return idList;
	}
	public void setIdList(IdDetails idList) {
		this.idList = idList;
	}
	public String getPremiumAmount() {
		return premiumAmount;
	}
	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}
	public String getInsuTitle() {
		return insuTitle;
	}
	public void setInsuTitle(String insuTitle) {
		this.insuTitle = insuTitle;
	}
	
	
	public String getInsuName() {
		return insuName;
	}
	public void setInsuName(String insuName) {
		this.insuName = insuName;
	}
	
	
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	
	
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	
	
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	
	
	public String getBaseSumInsured() {
		return baseSumInsured;
	}
	public void setBaseSumInsured(String baseSumInsured) {
		this.baseSumInsured = baseSumInsured;
	}
	
	
	public String getEscalationAmt() {
		return escalationAmt;
	}
	public void setEscalationAmt(String escalationAmt) {
		this.escalationAmt = escalationAmt;
	}
	
	
	public String getSumInsured() {
		return sumInsured;
	}
	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}
	
	
	public String getAnyOtherPAInsurance() {
		return anyOtherPAInsurance;
	}
	public void setAnyOtherPAInsurance(String anyOtherPAInsurance) {
		this.anyOtherPAInsurance = anyOtherPAInsurance;
	}
	
	
	public String getNameOfInsurer() {
		return nameOfInsurer;
	}
	public void setNameOfInsurer(String nameOfInsurer) {
		this.nameOfInsurer = nameOfInsurer;
	}
	
	
	public String getOtherPAInsurancePolNum() {
		return otherPAInsurancePolNum;
	}
	public void setOtherPAInsurancePolNum(String otherPAInsurancePolNum) {
		this.otherPAInsurancePolNum = otherPAInsurancePolNum;
	}
	
	
	public String getPedIllInjuryDisableTwoYears() {
		return pedIllInjuryDisableTwoYears;
	}
	public void setPedIllInjuryDisableTwoYears(String pedIllInjuryDisableTwoYears) {
		this.pedIllInjuryDisableTwoYears = pedIllInjuryDisableTwoYears;
	}
	
	
	public String getPedIllInjuryDisableName() {
		return pedIllInjuryDisableName;
	}
	public void setPedIllInjuryDisableName(String pedIllInjuryDisableName) {
		this.pedIllInjuryDisableName = pedIllInjuryDisableName;
	}
	
	
}

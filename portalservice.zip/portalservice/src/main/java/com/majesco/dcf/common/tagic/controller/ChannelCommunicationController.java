package com.majesco.dcf.common.tagic.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.majesco.dcf.common.tagic.json.CommunicationRequest;
import com.majesco.dcf.common.tagic.json.CommunicationResponse;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;

@Controller
@RequestMapping(value = "/channelCommunication")
public class ChannelCommunicationController {
	
	@Autowired
	TagicCommunicationService commService;
	
	final static Logger logger = Logger.getLogger(ChannelCommunicationController.class);
	
	@RequestMapping(value="/sendcommunication/", method = RequestMethod.POST)
	@ResponseBody		
	public CommunicationResponse sendCommunication(@RequestBody CommunicationRequest commRequest, HttpServletRequest httpServletRequest) throws Exception{
		logger.debug("Inside CommunicationController.sendCommunication method.. ");
				
		String statusMsg = "Success";
		CommunicationResponse result = new CommunicationResponse();
		commService.sendCommunication(commRequest);
		result.setStatusMsg(statusMsg);
		
		return result;
	}
	

}

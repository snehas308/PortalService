package com.majesco.dcf.common.tagic.entity;


import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_ch_agent_m",schema="dcf_master")		// Commented for Oracle Migration	
@Table(name = "dcf_ch_agent_m")								// Added for oracle migration
public class AgentMaster implements Serializable{
	private String stragentcd ="";
	private String stragentname ="";
	private String strproducercd ="";
	private String stremailid ="";
	private Integer nmobileno;
	private String strbranchcd ="";
	private Integer nisactive;
	private String dtcreated ="";
	private String strcreatedby ="";
	private String dtupdated ="";
	private String strupdatedby ="";
	
	@Id
	@Column(name = "stragentcd")
	public String getStragentcd() {
		return stragentcd;
	}
	public void setStragentcd(String stragentcd) {
		this.stragentcd = stragentcd;
	}
	
	@Column(name = "stragentname")
	public String getStragentname() {
		return stragentname;
	}
	public void setStragentname(String stragentname) {
		this.stragentname = stragentname;
	}
	
	@Column(name = "strproducercd")
	public String getStrproducercd() {
		return strproducercd;
	}
	public void setStrproducercd(String strproducercd) {
		this.strproducercd = strproducercd;
	}
	
	@Column(name = "stremailid")
	public String getStremailid() {
		return stremailid;
	}
	public void setStremailid(String stremailid) {
		this.stremailid = stremailid;
	}
	
	@Column(name = "nmobileno")
	public Integer getNmobileno() {
		return nmobileno;
	}
	public void setNmobileno(Integer nmobileno) {
		this.nmobileno = nmobileno;
	}
	
	@Column(name = "strbranchcd")
	public String getStrbranchcd() {
		return strbranchcd;
	}
	public void setStrbranchcd(String strbranchcd) {
		this.strbranchcd = strbranchcd;
	}
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
}

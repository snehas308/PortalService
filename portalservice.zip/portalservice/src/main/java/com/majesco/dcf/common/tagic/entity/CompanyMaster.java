package com.majesco.dcf.common.tagic.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_all_company_m",schema="dcf_master")				// Commented for Oracle Migration
@Table(name = "dcf_all_company_m")										// Added for Oracle Migration
public class CompanyMaster {
	private String strcompanycd="";
	private String strcompanyname="";
	private String strshortname="";
	private String strcorporatecustomerid="";
	private String strentitytypeid="";
	private String strcompanytype="";
	private String dtstart="";
	private String dtend="";
	private Integer nisactive;
	private String dtcreated="";
	private String strcreatedby="";
	private String dtupdated="";
	private String strupdatedby="";
	
	@Id
	@Column(name = "strcompanycd")
	public String getStrcompanycd() {
		return strcompanycd;
	}
	public void setStrcompanycd(String strcompanycd) {
		this.strcompanycd = strcompanycd;
	}
	
	@Column(name = "strcompanyname")
	public String getStrcompanyname() {
		return strcompanyname;
	}
	public void setStrcompanyname(String strcompanyname) {
		this.strcompanyname = strcompanyname;
	}
	
	@Column(name = "strshortname")
	public String getStrshortname() {
		return strshortname;
	}
	public void setStrshortname(String strshortname) {
		this.strshortname = strshortname;
	}
	
	@Column(name = "strcorporatecustomerid")
	public String getStrcorporatecustomerid() {
		return strcorporatecustomerid;
	}
	public void setStrcorporatecustomerid(String strcorporatecustomerid) {
		this.strcorporatecustomerid = strcorporatecustomerid;
	}
	
	@Column(name = "strentitytypeid")
	public String getStrentitytypeid() {
		return strentitytypeid;
	}
	public void setStrentitytypeid(String strentitytypeid) {
		this.strentitytypeid = strentitytypeid;
	}
	
	@Column(name = "strcompanytype")
	public String getStrcompanytype() {
		return strcompanytype;
	}
	public void setStrcompanytype(String strcompanytype) {
		this.strcompanytype = strcompanytype;
	}
	
	@Column(name = "dtstart")
	public String getDtstart() {
		return dtstart;
	}
	public void setDtstart(String dtstart) {
		this.dtstart = dtstart;
	}
	
	@Column(name = "dtend")
	public String getDtend() {
		return dtend;
	}
	public void setDtend(String dtend) {
		this.dtend = dtend;
	}
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
}

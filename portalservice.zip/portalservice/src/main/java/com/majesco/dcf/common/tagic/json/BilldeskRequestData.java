package com.majesco.dcf.common.tagic.json;

public class BilldeskRequestData {

	private String msg;
	private String txtPayCategory;
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getTxtPayCategory() {
		return txtPayCategory;
	}
	public void setTxtPayCategory(String txtPayCategory) {
		this.txtPayCategory = txtPayCategory;
	}
	
}

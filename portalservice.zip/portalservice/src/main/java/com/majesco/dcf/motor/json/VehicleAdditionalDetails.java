package com.majesco.dcf.motor.json;

import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class VehicleAdditionalDetails {

	public String valueFornonElec; //ValueofNonElectricalAccessories
	public String valForElecAcc; //valueofElectricalAccessories
	public String cnglpgExtFt; //CNG LPG external fitted 
	public String cnglpgKitValue;// CNG LPG kit value
	public String paCoverForPer; //PACoverforNamedPerson
	public String noOfPersPA; // NoOfPersons For PA COver
	public String capitalSumInsPer;//CapitalSumInsuredperperson
	public String patounearHireDriver; //PAtounnamedHirerDriver
	public String noOfPerHD;// Numberofpersons indicates PA to unearned Hire Driver
	public String capitalSumInsPerHD;	//PA Cover for Paid Driver/Conductor/Cleaner >> Capital Sum Insured per person
	public String capitalSumInsPerHDNew;	//PA Cover for Paid Driver Added For Two Wheeler Conflict
	public String siPaidDriver;
	public String liblitoPerson; //Liabilitytopersons
	public String noofperlib;// Applicable to only Goods carrying Vehicle 
	public String legalLiability; // LegalLiability
	public String noofPerLib;//
	public String legalExdrclco; //LegalLiabilityexcludingpaiddrivercleanerconductor
	public String noOfPersonLgLi;//
	public String legLiatononFarePay; //LegalLiabilitytoNonfarepayingpassengersexcludingemployees
	public String noofper;//relater to LegalLiabilitytoNonfarepayingpassengersexcludingemployees
	public String legalLibexPas;//LegalLiabilitytoNonfarepayingpassengersincludingemployees
	public String noofPersons; //Related to LegalLiabilitytoNonfarepayingpassengersincludingemployees
	public String useofcommVech; //UseofCOMMERCIALTYPEVEHICLES
	public String coverforhirelib;//CoverforHireorrewardLiability
	public String hirevehdrv; //HiredVehicledrivenbyHirer
	public String indemnity;//IndemnitytoHirers
	public String covfortheft;//CoverforTheftandConversionRiskbytheHirer
	public String sideCarOption;
	public String sideCarValue;
	public String vehInsrdDeclVal;
	public String cnglpgInsrdPIP;
	public String nomName;
	public String nomAge;
	public String nomReltn;
	public String libSoldierSailorAirman; //Liability to Soldier/ Sailor/Airman employed as Driver in private capacity
	public String covTheftConvRisk;//Cover for theft and conversion risk by the hirer
	public String paCoverToUnnamedPassengers;
	public String lamp_Tyr_Mudg_Bonn;
	ServiceUtility serviceUtility = new ServiceUtility();
	
	public String getSideCarOption() {
		return sideCarOption;
	}
	public void setSideCarOption(String sideCarOption) {
		sideCarOption = serviceUtility.blankToNullCheck(sideCarOption);
		this.sideCarOption = sideCarOption;
	}
	public String getSideCarValue() {
		return sideCarValue;
	}
	public void setSideCarValue(String sideCarValue) {
		sideCarValue = serviceUtility.blankToNullCheck(sideCarValue);
		this.sideCarValue = sideCarValue;
	}
	public String getValueFornonElec() {
		return valueFornonElec;
	}
	public void setValueFornonElec(String valueFornonElec) {
		valueFornonElec = serviceUtility.blankToNullCheck(valueFornonElec);
		this.valueFornonElec = valueFornonElec;
	}
	public String getValForElecAcc() {
		return valForElecAcc;
	}
	public void setValForElecAcc(String valForElecAcc) {
		valForElecAcc = serviceUtility.blankToNullCheck(valForElecAcc);
		this.valForElecAcc = valForElecAcc;
	}
	public String getCnglpgExtFt() {
		return cnglpgExtFt;
	}
	public void setCnglpgExtFt(String cnglpgExtFt) {
		cnglpgExtFt = serviceUtility.blankToNullCheck(cnglpgExtFt);
		this.cnglpgExtFt = cnglpgExtFt;
	}
	public String getCnglpgKitValue() {
		return cnglpgKitValue;
	}
	public void setCnglpgKitValue(String cnglpgKitValue) {
		cnglpgKitValue = serviceUtility.blankToNullCheck(cnglpgKitValue);
		this.cnglpgKitValue = cnglpgKitValue;
	}
	public String getPaCoverForPer() {
		return paCoverForPer;
	}
	public void setPaCoverForPer(String paCoverForPer) {
		paCoverForPer = serviceUtility.blankToNullCheck(paCoverForPer);
		this.paCoverForPer = paCoverForPer;
	}
	public String getNoOfPersPA() {
		return noOfPersPA;
	}
	public void setNoOfPersPA(String noOfPersPA) {
		noOfPersPA = serviceUtility.blankToNullCheck(noOfPersPA);
		this.noOfPersPA = noOfPersPA;
	}
	public String getCapitalSumInsPer() {
		return capitalSumInsPer;
	}
	public void setCapitalSumInsPer(String capitalSumInsPer) {
		capitalSumInsPer = serviceUtility.blankToNullCheck(capitalSumInsPer);
		this.capitalSumInsPer = capitalSumInsPer;
	}
	public String getPatounearHireDriver() {
		return patounearHireDriver;
	}
	public void setPatounearHireDriver(String patounearHireDriver) {
		patounearHireDriver = serviceUtility.blankToNullCheck(patounearHireDriver);
		this.patounearHireDriver = patounearHireDriver;
	}
	public String getNoOfPerHD() {
		return noOfPerHD;
	}
	public void setNoOfPerHD(String noOfPerHD) {
		noOfPerHD = serviceUtility.blankToNullCheck(noOfPerHD);
		this.noOfPerHD = noOfPerHD;
	}
	public String getSiPaidDriver() {
		return siPaidDriver;
	}
	public void setSiPaidDriver(String siPaidDriver) {
		siPaidDriver = serviceUtility.blankToNullCheck(siPaidDriver);
		this.siPaidDriver = siPaidDriver;
	}
	public String getLiblitoPerson() {
		return liblitoPerson;
	}
	public void setLiblitoPerson(String liblitoPerson) {
		liblitoPerson = serviceUtility.blankToNullCheck(liblitoPerson);
		this.liblitoPerson = liblitoPerson;
	}
	public String getNoofperlib() {
		return noofperlib;
	}
	public void setNoofperlib(String noofperlib) {
		noofperlib = serviceUtility.blankToNullCheck(noofperlib);
		this.noofperlib = noofperlib;
	}
	public String getLegalLiability() {
		return legalLiability;
	}
	public void setLegalLiability(String legalLiability) {
		legalLiability = serviceUtility.blankToNullCheck(legalLiability);
		this.legalLiability = legalLiability;
	}
	public String getNoofPerLib() {
		return noofPerLib;
	}
	public void setNoofPerLib(String noofPerLib) {
		noofPerLib = serviceUtility.blankToNullCheck(noofPerLib);
		this.noofPerLib = noofPerLib;
	}
	public String getLegalExdrclco() {
		return legalExdrclco;
	}
	public void setLegalExdrclco(String legalExdrclco) {
		legalExdrclco = serviceUtility.blankToNullCheck(legalExdrclco);
		this.legalExdrclco = legalExdrclco;
	}
	public String getNoOfPersonLgLi() {
		return noOfPersonLgLi;
	}
	public void setNoOfPersonLgLi(String noOfPersonLgLi) {
		noOfPersonLgLi = serviceUtility.blankToNullCheck(noOfPersonLgLi);
		this.noOfPersonLgLi = noOfPersonLgLi;
	}
	public String getLegLiatononFarePay() {
		return legLiatononFarePay;
	}
	public void setLegLiatononFarePay(String legLiatononFarePay) {
		legLiatononFarePay = serviceUtility.blankToNullCheck(legLiatononFarePay);
		this.legLiatononFarePay = legLiatononFarePay;
	}
	public String getNoofper() {
		return noofper;
	}
	public void setNoofper(String noofper) {
		noofper = serviceUtility.blankToNullCheck(noofper);
		this.noofper = noofper;
	}
	public String getLegalLibexPas() {
		return legalLibexPas;
	}
	public void setLegalLibexPas(String legalLibexPas) {
		legalLibexPas = serviceUtility.blankToNullCheck(legalLibexPas);
		this.legalLibexPas = legalLibexPas;
	}
	public String getNoofPersons() {
		return noofPersons;
	}
	public void setNoofPersons(String noofPersons) {
		noofPersons = serviceUtility.blankToNullCheck(noofPersons);
		this.noofPersons = noofPersons;
	}
	public String getUseofcommVech() {
		return useofcommVech;
	}
	public void setUseofcommVech(String useofcommVech) {
		useofcommVech = serviceUtility.blankToNullCheck(useofcommVech);
		this.useofcommVech = useofcommVech;
	}
	public String getCoverforhirelib() {
		return coverforhirelib;
	}
	public void setCoverforhirelib(String coverforhirelib) {
		coverforhirelib = serviceUtility.blankToNullCheck(coverforhirelib);
		this.coverforhirelib = coverforhirelib;
	}
	public String getHirevehdrv() {
		return hirevehdrv;
	}
	public void setHirevehdrv(String hirevehdrv) {
		hirevehdrv = serviceUtility.blankToNullCheck(hirevehdrv);
		this.hirevehdrv = hirevehdrv;
	}
	public String getIndemnity() {
		return indemnity;
	}
	public void setIndemnity(String indemnity) {
		indemnity = serviceUtility.blankToNullCheck(indemnity);
		this.indemnity = indemnity;
	}
	public String getCovfortheft() {
		return covfortheft;
	}
	public void setCovfortheft(String covfortheft) {
		covfortheft = serviceUtility.blankToNullCheck(covfortheft);
		this.covfortheft = covfortheft;
	}
	public String getLegallibpass() {
		return legallibpass;
	}
	public void setLegallibpass(String legallibpass) {
		legallibpass = serviceUtility.blankToNullCheck(legallibpass);
		this.legallibpass = legallibpass;
	}
	public String getExtcovUnit() {
		return extcovUnit;
	}
	public void setExtcovUnit(String extcovUnit) {
		extcovUnit = serviceUtility.blankToNullCheck(extcovUnit);
		this.extcovUnit = extcovUnit;
	}
	public Integer getNoofperunit() {
		return noofperunit;
	}
	public void setNoofperunit(Integer noofperunit) {
		this.noofperunit = noofperunit;
	}
	public String legallibpass;//LegalLiabilitypasssexclaccdntSI
	public String extcovUnit;//ExtCoverUnit
	public Integer noofperunit; //NoofPersons7

	public String getVehInsrdDeclVal() {
		return vehInsrdDeclVal;
	}
	public void setVehInsrdDeclVal(String vehInsrdDeclVal) {
		vehInsrdDeclVal = serviceUtility.blankToNullCheck(vehInsrdDeclVal);
		this.vehInsrdDeclVal = vehInsrdDeclVal;
	}
	public String getCnglpgInsrdPIP() {
		return cnglpgInsrdPIP;
	}
	public void setCnglpgInsrdPIP(String cnglpgInsrdPIP) {
		cnglpgInsrdPIP = serviceUtility.blankToNullCheck(cnglpgInsrdPIP);
		this.cnglpgInsrdPIP = cnglpgInsrdPIP;
	}
	public String getNomName() {
		return nomName;
	}
	public void setNomName(String nomName) {
		nomName = serviceUtility.blankToNullCheck(nomName);
		this.nomName = nomName;
	}
	public String getNomAge() {
		return nomAge;
	}
	public void setNomAge(String nomAge) {
		nomAge = serviceUtility.blankToNullCheck(nomAge);
		this.nomAge = nomAge;
	}
	public String getNomReltn() {
		return nomReltn;
	}
	public void setNomReltn(String nomReltn) {
		nomReltn = serviceUtility.blankToNullCheck(nomReltn);
		this.nomReltn = nomReltn;
	}
	public String getCapitalSumInsPerHD() {
		return capitalSumInsPerHD;
	}
	public void setCapitalSumInsPerHD(String capitalSumInsPerHD) {
		capitalSumInsPerHD = serviceUtility.blankToNullCheck(capitalSumInsPerHD);
		this.capitalSumInsPerHD = capitalSumInsPerHD;
	}
	public String getLibSoldierSailorAirman() {
		return libSoldierSailorAirman;
	}
	public void setLibSoldierSailorAirman(String libSoldierSailorAirman) {
		libSoldierSailorAirman = serviceUtility.blankToNullCheck(libSoldierSailorAirman);
		this.libSoldierSailorAirman = libSoldierSailorAirman;
	}
	public String getCovTheftConvRisk() {
		return covTheftConvRisk;
	}
	public void setCovTheftConvRisk(String covTheftConvRisk) {
		covTheftConvRisk = serviceUtility.blankToNullCheck(covTheftConvRisk);
		this.covTheftConvRisk = covTheftConvRisk;
	}
	public String getCapitalSumInsPerHDNew() {
		return capitalSumInsPerHDNew;
	}
	public void setCapitalSumInsPerHDNew(String capitalSumInsPerHDNew) {
		capitalSumInsPerHDNew = serviceUtility.blankToNullCheck(capitalSumInsPerHDNew);
		this.capitalSumInsPerHDNew = capitalSumInsPerHDNew;
	}
	public String getPaCoverToUnnamedPassengers() {
		return paCoverToUnnamedPassengers;
	}
	public void setPaCoverToUnnamedPassengers(String paCoverToUnnamedPassengers) {
		paCoverToUnnamedPassengers = serviceUtility.blankToNullCheck(paCoverToUnnamedPassengers);
		this.paCoverToUnnamedPassengers = paCoverToUnnamedPassengers;
	}
	public String getLamp_Tyr_Mudg_Bonn() {
		return lamp_Tyr_Mudg_Bonn;
	}
	public void setLamp_Tyr_Mudg_Bonn(String lamp_Tyr_Mudg_Bonn) {
		lamp_Tyr_Mudg_Bonn = serviceUtility.blankToNullCheck(lamp_Tyr_Mudg_Bonn);
		this.lamp_Tyr_Mudg_Bonn = lamp_Tyr_Mudg_Bonn;
	}
	
	
	
}

package com.majesco.dcf.claims.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ClaimServiceValidateSaveResponse {
	
	private String claimNumber;
	private String resultCode;
	private List<ResponseError> resErr;
	private ClaimServiceValidateSaveRequest lstclaimServValidateSaveReq;
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public ClaimServiceValidateSaveRequest getLstclaimServValidateSaveReq() {
		return lstclaimServValidateSaveReq;
	}
	public void setLstclaimServValidateSaveReq(
			ClaimServiceValidateSaveRequest lstclaimServValidateSaveReq) {
		this.lstclaimServValidateSaveReq = lstclaimServValidateSaveReq;
	}
	
	

}

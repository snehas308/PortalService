package com.majesco.dcf.paproduct.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CoverageDetails {
	
	private String insuranceFor;
	private String plan;
	private String planCvrg;
	private String occuptnClassOfSelf;
	private String annGrsIncOfPH;
	private String coreBenefitPerUnit;
	private String coreBenefitNumberPerUnit;
	private String coreSumInsured;
	private String weeklyBenefit52;
	private String weeklyBenefitNoOfUnits;
	private String weeklyBenefit;
	private String selfIsPolicyHolder;
	private String payOutPeriod;
	private String benefitPerMonth;
	
	public String getPayOutPeriod() {
		return payOutPeriod;
	}
	public void setPayOutPeriod(String payOutPeriod) {
		this.payOutPeriod = payOutPeriod;
	}
	public String getBenefitPerMonth() {
		return benefitPerMonth;
	}
	public void setBenefitPerMonth(String benefitPerMonth) {
		this.benefitPerMonth = benefitPerMonth;
	}
	public String getInsuranceFor() {
		return insuranceFor;
	}
	public void setInsuranceFor(String insuranceFor) {
		this.insuranceFor = insuranceFor;
	}
	
	
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	
	
	public String getPlanCvrg() {
		return planCvrg;
	}
	public void setPlanCvrg(String planCvrg) {
		this.planCvrg = planCvrg;
	}
	
	
	public String getOccuptnClassOfSelf() {
		return occuptnClassOfSelf;
	}
	public void setOccuptnClassOfSelf(String occuptnClassOfSelf) {
		this.occuptnClassOfSelf = occuptnClassOfSelf;
	}
	
	
	public String getAnnGrsIncOfPH() {
		return annGrsIncOfPH;
	}
	public void setAnnGrsIncOfPH(String annGrsIncOfPH) {
		this.annGrsIncOfPH = annGrsIncOfPH;
	}
	
	
	public String getCoreBenefitPerUnit() {
		return coreBenefitPerUnit;
	}
	public void setCoreBenefitPerUnit(String coreBenefitPerUnit) {
		this.coreBenefitPerUnit = coreBenefitPerUnit;
	}
	
	
	public String getCoreBenefitNumberPerUnit() {
		return coreBenefitNumberPerUnit;
	}
	public void setCoreBenefitNumberPerUnit(String coreBenefitNumberPerUnit) {
		this.coreBenefitNumberPerUnit = coreBenefitNumberPerUnit;
	}
	
	
	public String getCoreSumInsured() {
		return coreSumInsured;
	}
	public void setCoreSumInsured(String coreSumInsured) {
		this.coreSumInsured = coreSumInsured;
	}
	
	
	public String getWeeklyBenefit52() {
		return weeklyBenefit52;
	}
	public void setWeeklyBenefit52(String weeklyBenefit52) {
		this.weeklyBenefit52 = weeklyBenefit52;
	}
	
	
	public String getWeeklyBenefitNoOfUnits() {
		return weeklyBenefitNoOfUnits;
	}
	public void setWeeklyBenefitNoOfUnits(String weeklyBenefitNoOfUnits) {
		this.weeklyBenefitNoOfUnits = weeklyBenefitNoOfUnits;
	}
	
	
	public String getWeeklyBenefit() {
		return weeklyBenefit;
	}
	public void setWeeklyBenefit(String weeklyBenefit) {
		this.weeklyBenefit = weeklyBenefit;
	}
	
	
	public String getSelfIsPolicyHolder() {
		return selfIsPolicyHolder;
	}
	public void setSelfIsPolicyHolder(String selfIsPolicyHolder) {
		this.selfIsPolicyHolder = selfIsPolicyHolder;
	}
	
	
}

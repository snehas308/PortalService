package com.majesco.dcf.motor.json;

import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class AddOnCoverDetails {

	private String addonCover; //AddonCovers 
	private String addOnPlan;//Addonplan
	private String addonchoice;
	private String isUsedforBliedHandi; // IstheVehicleusedforblindorhandicappedpersons
	private String volDedAmt; //VoluntaryDeductibleAmount
	private String autoAssoMem;//AutomobileAssociationMembership
	private String embaLoading;//EmbassyLoadingImportedwithoutcustomduty
	private String drivingTution; //DrivingTuitions
	private String vintDiscunt;//VintageCardiscount
	private String depriReim;//DepreciationReimbursement
	private String noofClaims;
	private String returnToInvoice;//ReturntoInvoice
	private String lossofEquipments;
	private String addTransCost;//AdditionalTransportationCost
	private String loassOfInc;//LossofIncome
	private String emiProtect;//EMIProtector
	private String loabAmt;//LoanAmount
	
	private String protCvrNCB;//NCB protection cover
	private String roadAsst;//Roadside Assistance
	private String consExp;//Consumables expenses
	private String dailyAllow;//Per Day allowance
	private String dailyAllowMain;//Daily allowance
	private String lossPersBelo;//Loss of Personal belongings
	private String emrgTransHotExp;//Emergency transport and Hotel expenses (IDV)
	private String sumAssAOY;//Sum Assured(AOY) (In Rs.)
	private String courtHirCar;//Courtesy/hire car
	private String engSec;//Engine Secure
	private String engSecOpt;//Engine Secure Options
	private String tyrSec;//Tyre Secure
	private String tyrSecOpt;//Tyre Secure Option
	private String keyReplace;//Key Replacement 
	private String deprReimbDed;//Depreciation Re-imbursement Deductible 
	private String emrgMedExp;//Emergency Medical Expenses
	private String addThirdPartyProp;//Additional Third Party Property Damage
	private String addPersAccCovOwner;//Additional Personal Accident Cover to Owner Driver
	private String addPersAccCovUnmdPass;//Additional Personal Accident cover to Unnamed Passenger
	private String repOfGlasRubrPlastic;
	private String sumAssKeyReplc;
	private String grpPersnlAccdnt;
	private String persnlBelongSI;
	private String emergTransprtSI;
	private String ratioOfAOAAOY;
	private String sumInsrdAOA;
	private String courtAllwncDaysTheft;
	private String courtFranchiseDays;
	private String courtAllwncDaysAccdnt;
	private String dailyAllwncDaysTheft;
	private String dailyFranchiseDays;
	private String dailyAllwncDaysAccdnt;
	private String useOfVehclePremices;
	private String typeOfBody;
	private String maxNoOfDays;
	private String legLiabDrivCleanConduct;//Legal Liability to Paid Driver / Cleaner / Conductor
	private String paCoverForPaidDrvClnr;
	private String paCoverToUnNamedPass;
	
	//Additional Variables By TAGIC
	private String liabToEmpTravelDriv;
	private String additionalTowCharge;
	private String additionalTowChargeAmount;
	ServiceUtility serviceUtility = new ServiceUtility();
	
	public String getAddPersAccCovUnmdPass() {
		return addPersAccCovUnmdPass;
	}
	public void setAddPersAccCovUnmdPass(String addPersAccCovUnmdPass) {
		addPersAccCovUnmdPass = serviceUtility.blankToNullCheck(addPersAccCovUnmdPass);
		this.addPersAccCovUnmdPass = addPersAccCovUnmdPass;
	}
	public String getDeprReimbDed() {
		return deprReimbDed;
	}
	public void setDeprReimbDed(String deprReimbDed) {
		deprReimbDed = serviceUtility.blankToNullCheck(deprReimbDed);
		this.deprReimbDed = deprReimbDed;
	}
	public String getEmrgMedExp() {
		return emrgMedExp;
	}
	public void setEmrgMedExp(String emrgMedExp) {
		emrgMedExp = serviceUtility.blankToNullCheck(emrgMedExp);
		this.emrgMedExp = emrgMedExp;
	}
	public String getAddThirdPartyProp() {
		return addThirdPartyProp;
	}
	public void setAddThirdPartyProp(String addThirdPartyProp) {
		addThirdPartyProp = serviceUtility.blankToNullCheck(addThirdPartyProp);
		this.addThirdPartyProp = addThirdPartyProp;
	}
	public String getAddPersAccCovOwner() {
		return addPersAccCovOwner;
	}
	public void setAddPersAccCovOwner(String addPersAccCovOwner) {
		addPersAccCovOwner = serviceUtility.blankToNullCheck(addPersAccCovOwner);
		this.addPersAccCovOwner = addPersAccCovOwner;
	}
	public String getKeyReplace() {
		return keyReplace;
	}
	public void setKeyReplace(String keyReplace) {
		keyReplace = serviceUtility.blankToNullCheck(keyReplace);
		this.keyReplace = keyReplace;
	}
	public String getTyrSecOpt() {
		return tyrSecOpt;
	}
	public void setTyrSecOpt(String tyrSecOpt) {
		tyrSecOpt = serviceUtility.blankToNullCheck(tyrSecOpt);
		this.tyrSecOpt = tyrSecOpt;
	}
	public String getTyrSec() {
		return tyrSec;
	}
	public void setTyrSec(String tyrSec) {
		tyrSec = serviceUtility.blankToNullCheck(tyrSec);
		this.tyrSec = tyrSec;
	}
	public String getEngSecOpt() {
		return engSecOpt;
	}
	public void setEngSecOpt(String engSecOpt) {
		engSecOpt = serviceUtility.blankToNullCheck(engSecOpt);
		this.engSecOpt = engSecOpt;
	}
	public String getEngSec() {
		return engSec;
	}
	public void setEngSec(String engSec) {
		engSec = serviceUtility.blankToNullCheck(engSec);
		this.engSec = engSec;
	}
	public String getCourtHirCar() {
		return courtHirCar;
	}
	public void setCourtHirCar(String courtHirCar) {
		courtHirCar = serviceUtility.blankToNullCheck(courtHirCar);
		this.courtHirCar = courtHirCar;
	}
	public String getSumAssAOY() {
		return sumAssAOY;
	}
	public void setSumAssAOY(String sumAssAOY) {
		sumAssAOY = serviceUtility.blankToNullCheck(sumAssAOY);
		this.sumAssAOY = sumAssAOY;
	}
	public String getEmrgTransHotExp() {
		return emrgTransHotExp;
	}
	public void setEmrgTransHotExp(String emrgTransHotExp) {
		emrgTransHotExp = serviceUtility.blankToNullCheck(emrgTransHotExp);
		this.emrgTransHotExp = emrgTransHotExp;
	}
	public String getLossPersBelo() {
		return lossPersBelo;
	}
	public void setLossPersBelo(String lossPersBelo) {
		lossPersBelo = serviceUtility.blankToNullCheck(lossPersBelo);
		this.lossPersBelo = lossPersBelo;
	}
	public String getConsExp() {
		return consExp;
	}
	public void setConsExp(String consExp) {
		consExp = serviceUtility.blankToNullCheck(consExp);
		this.consExp = consExp;
	}
	public String getDailyAllow() {
		return dailyAllow;
	}
	public void setDailyAllow(String dailyAllow) {
		dailyAllow = serviceUtility.blankToNullCheck(dailyAllow);
		this.dailyAllow = dailyAllow;
	}
	public String getProtCvrNCB() {
		return protCvrNCB;
	}
	public void setProtCvrNCB(String protCvrNCB) {
		protCvrNCB = serviceUtility.blankToNullCheck(protCvrNCB);
		this.protCvrNCB = protCvrNCB;
	}
	public String getRoadAsst() {
		return roadAsst;
	}
	public void setRoadAsst(String roadAsst) {
		roadAsst = serviceUtility.blankToNullCheck(roadAsst);
		this.roadAsst = roadAsst;
	}
	public String getAddonCover() {
		return addonCover;
	}
	public void setAddonCover(String addonCover) {
		addonCover = serviceUtility.blankToNullCheck(addonCover);
		this.addonCover = addonCover;
	}
	public String getAddOnPlan() {
		return addOnPlan;
	}
	public void setAddOnPlan(String addOnPlan) {
		addOnPlan = serviceUtility.blankToNullCheck(addOnPlan);
		this.addOnPlan = addOnPlan;
	}
	public String getAddonchoice() {
		return addonchoice;
	}
	public void setAddonchoice(String addonchoice) {
		addonchoice = serviceUtility.blankToNullCheck(addonchoice);
		this.addonchoice = addonchoice;
	}
	public String getIsUsedforBliedHandi() {
		return isUsedforBliedHandi;
	}
	public void setIsUsedforBliedHandi(String isUsedforBliedHandi) {
		isUsedforBliedHandi = serviceUtility.blankToNullCheck(isUsedforBliedHandi);
		this.isUsedforBliedHandi = isUsedforBliedHandi;
	}
	public String getVolDedAmt() {
		return volDedAmt;
	}
	public void setVolDedAmt(String volDedAmt) {
		volDedAmt = serviceUtility.blankToNullCheck(volDedAmt);
		this.volDedAmt = volDedAmt;
	}
	public String getAutoAssoMem() {
		return autoAssoMem;
	}
	public void setAutoAssoMem(String autoAssoMem) {
		autoAssoMem = serviceUtility.blankToNullCheck(autoAssoMem);
		this.autoAssoMem = autoAssoMem;
	}
	public String getEmbaLoading() {
		return embaLoading;
	}
	public void setEmbaLoading(String embaLoading) {
		embaLoading = serviceUtility.blankToNullCheck(embaLoading);
		this.embaLoading = embaLoading;
	}
	public String getDrivingTution() {
		return drivingTution;
	}
	public void setDrivingTution(String drivingTution) {
		drivingTution = serviceUtility.blankToNullCheck(drivingTution);
		this.drivingTution = drivingTution;
	}
	public String getVintDiscunt() {
		return vintDiscunt;
	}
	public void setVintDiscunt(String vintDiscunt) {
		vintDiscunt = serviceUtility.blankToNullCheck(vintDiscunt);
		this.vintDiscunt = vintDiscunt;
	}
	public String getDepriReim() {
		return depriReim;
	}
	public void setDepriReim(String depriReim) {
		depriReim = serviceUtility.blankToNullCheck(depriReim);
		this.depriReim = depriReim;
	}
	public String getNoofClaims() {
		return noofClaims;
	}
	public void setNoofClaims(String noofClaims) {
		noofClaims = serviceUtility.blankToNullCheck(noofClaims);
		this.noofClaims = noofClaims;
	}
	public String getReturnToInvoice() {
		return returnToInvoice;
	}
	public void setReturnToInvoice(String returnToInvoice) {
		returnToInvoice = serviceUtility.blankToNullCheck(returnToInvoice);
		this.returnToInvoice = returnToInvoice;
	}
	public String getLossofEquipments() {
		return lossofEquipments;
	}
	public void setLossofEquipments(String lossofEquipments) {
		lossofEquipments = serviceUtility.blankToNullCheck(lossofEquipments);
		this.lossofEquipments = lossofEquipments;
	}
	public String getAddTransCost() {
		return addTransCost;
	}
	public void setAddTransCost(String addTransCost) {
		addTransCost = serviceUtility.blankToNullCheck(addTransCost);
		this.addTransCost = addTransCost;
	}
	public String getLoassOfInc() {
		return loassOfInc;
	}
	public void setLoassOfInc(String loassOfInc) {
		loassOfInc = serviceUtility.blankToNullCheck(loassOfInc);
		this.loassOfInc = loassOfInc;
	}
	public String getEmiProtect() {
		return emiProtect;
	}
	public void setEmiProtect(String emiProtect) {
		emiProtect = serviceUtility.blankToNullCheck(emiProtect);
		this.emiProtect = emiProtect;
	}
	public String getLoabAmt() {
		return loabAmt;
	}
	public void setLoabAmt(String loabAmt) {
		loabAmt = serviceUtility.blankToNullCheck(loabAmt);
		this.loabAmt = loabAmt;
	}
	public String getRepOfGlasRubrPlastic() {
		return repOfGlasRubrPlastic;
	}
	public void setRepOfGlasRubrPlastic(String repOfGlasRubrPlastic) {
		repOfGlasRubrPlastic = serviceUtility.blankToNullCheck(repOfGlasRubrPlastic);
		this.repOfGlasRubrPlastic = repOfGlasRubrPlastic;
	}
	public String getSumAssKeyReplc() {
		return sumAssKeyReplc;
	}
	public void setSumAssKeyReplc(String sumAssKeyReplc) {
		sumAssKeyReplc = serviceUtility.blankToNullCheck(sumAssKeyReplc);
		this.sumAssKeyReplc = sumAssKeyReplc;
	}
	public String getGrpPersnlAccdnt() {
		return grpPersnlAccdnt;
	}
	public void setGrpPersnlAccdnt(String grpPersnlAccdnt) {
		grpPersnlAccdnt = serviceUtility.blankToNullCheck(grpPersnlAccdnt);
		this.grpPersnlAccdnt = grpPersnlAccdnt;
	}
	public String getPersnlBelongSI() {
		return persnlBelongSI;
	}
	public void setPersnlBelongSI(String persnlBelongSI) {
		persnlBelongSI = serviceUtility.blankToNullCheck(persnlBelongSI);
		this.persnlBelongSI = persnlBelongSI;
	}
	public String getEmergTransprtSI() {
		return emergTransprtSI;
	}
	public void setEmergTransprtSI(String emergTransprtSI) {
		emergTransprtSI = serviceUtility.blankToNullCheck(emergTransprtSI);
		this.emergTransprtSI = emergTransprtSI;
	}
	public String getRatioOfAOAAOY() {
		return ratioOfAOAAOY;
	}
	public void setRatioOfAOAAOY(String ratioOfAOAAOY) {
		ratioOfAOAAOY = serviceUtility.blankToNullCheck(ratioOfAOAAOY);
		this.ratioOfAOAAOY = ratioOfAOAAOY;
	}
	public String getSumInsrdAOA() {
		return sumInsrdAOA;
	}
	public void setSumInsrdAOA(String sumInsrdAOA) {
		sumInsrdAOA = serviceUtility.blankToNullCheck(sumInsrdAOA);
		this.sumInsrdAOA = sumInsrdAOA;
	}
	public String getCourtAllwncDaysTheft() {
		return courtAllwncDaysTheft;
	}
	public void setCourtAllwncDaysTheft(String courtAllwncDaysTheft) {
		courtAllwncDaysTheft = serviceUtility.blankToNullCheck(courtAllwncDaysTheft);
		this.courtAllwncDaysTheft = courtAllwncDaysTheft;
	}
	public String getCourtFranchiseDays() {
		return courtFranchiseDays;
	}
	public void setCourtFranchiseDays(String courtFranchiseDays) {
		courtFranchiseDays = serviceUtility.blankToNullCheck(courtFranchiseDays);
		this.courtFranchiseDays = courtFranchiseDays;
	}
	public String getCourtAllwncDaysAccdnt() {
		return courtAllwncDaysAccdnt;
	}
	public void setCourtAllwncDaysAccdnt(String courtAllwncDaysAccdnt) {
		courtAllwncDaysAccdnt = serviceUtility.blankToNullCheck(courtAllwncDaysAccdnt);
		this.courtAllwncDaysAccdnt = courtAllwncDaysAccdnt;
	}
	public String getDailyAllwncDaysTheft() {
		return dailyAllwncDaysTheft;
	}
	public void setDailyAllwncDaysTheft(String dailyAllwncDaysTheft) {
		dailyAllwncDaysTheft = serviceUtility.blankToNullCheck(dailyAllwncDaysTheft);
		this.dailyAllwncDaysTheft = dailyAllwncDaysTheft;
	}
	public String getDailyFranchiseDays() {
		return dailyFranchiseDays;
	}
	public void setDailyFranchiseDays(String dailyFranchiseDays) {
		dailyFranchiseDays = serviceUtility.blankToNullCheck(dailyFranchiseDays);
		this.dailyFranchiseDays = dailyFranchiseDays;
	}
	public String getDailyAllwncDaysAccdnt() {
		return dailyAllwncDaysAccdnt;
	}
	public void setDailyAllwncDaysAccdnt(String dailyAllwncDaysAccdnt) {
		dailyAllwncDaysAccdnt = serviceUtility.blankToNullCheck(dailyAllwncDaysAccdnt);
		this.dailyAllwncDaysAccdnt = dailyAllwncDaysAccdnt;
	}
	public String getUseOfVehclePremices() {
		return useOfVehclePremices;
	}
	public void setUseOfVehclePremices(String useOfVehclePremices) {
		useOfVehclePremices = serviceUtility.blankToNullCheck(useOfVehclePremices);
		this.useOfVehclePremices = useOfVehclePremices;
	}
	public String getTypeOfBody() {
		return typeOfBody;
	}
	public void setTypeOfBody(String typeOfBody) {
		typeOfBody = serviceUtility.blankToNullCheck(typeOfBody);
		this.typeOfBody = typeOfBody;
	}
	public String getMaxNoOfDays() {
		return maxNoOfDays;
	}
	public void setMaxNoOfDays(String maxNoOfDays) {
		maxNoOfDays = serviceUtility.blankToNullCheck(maxNoOfDays);
		this.maxNoOfDays = maxNoOfDays;
	}
	public String getLegLiabDrivCleanConduct() {
		return legLiabDrivCleanConduct;
	}
	public void setLegLiabDrivCleanConduct(String legLiabDrivCleanConduct) {
		legLiabDrivCleanConduct = serviceUtility.blankToNullCheck(legLiabDrivCleanConduct);
		this.legLiabDrivCleanConduct = legLiabDrivCleanConduct;
	}
	public String getPaCoverForPaidDrvClnr() {
		return paCoverForPaidDrvClnr;
	}
	public void setPaCoverForPaidDrvClnr(String paCoverForPaidDrvClnr) {
		paCoverForPaidDrvClnr = serviceUtility.blankToNullCheck(paCoverForPaidDrvClnr);
		this.paCoverForPaidDrvClnr = paCoverForPaidDrvClnr;
	}
	public String getPaCoverToUnNamedPass() {
		return paCoverToUnNamedPass;
	}
	public void setPaCoverToUnNamedPass(String paCoverToUnNamedPass) {
		paCoverToUnNamedPass = serviceUtility.blankToNullCheck(paCoverToUnNamedPass);
		this.paCoverToUnNamedPass = paCoverToUnNamedPass;
	}
	public String getLiabToEmpTravelDriv() {
		return liabToEmpTravelDriv;
	}
	public void setLiabToEmpTravelDriv(String liabToEmpTravelDriv) {
		liabToEmpTravelDriv = serviceUtility.blankToNullCheck(liabToEmpTravelDriv);
		this.liabToEmpTravelDriv = liabToEmpTravelDriv;
	}
	public String getAdditionalTowCharge() {
		return additionalTowCharge;
	}
	public void setAdditionalTowCharge(String additionalTowCharge) {
		additionalTowCharge = serviceUtility.blankToNullCheck(additionalTowCharge);
		this.additionalTowCharge = additionalTowCharge;
	}
	public String getAdditionalTowChargeAmount() {
		return additionalTowChargeAmount;
	}
	public void setAdditionalTowChargeAmount(String additionalTowChargeAmount) {
		additionalTowChargeAmount = serviceUtility.blankToNullCheck(additionalTowChargeAmount);
		this.additionalTowChargeAmount = additionalTowChargeAmount;
	}
	public String getDailyAllowMain() {
		return dailyAllowMain;
	}
	public void setDailyAllowMain(String dailyAllowMain) {
		this.dailyAllowMain = dailyAllowMain;
	}
	
	


}

package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CreateCustomerResponse {

	private String resultCode;
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	private String customerID;
	private List<ResponseError> errList = null;
	private CustomerDetails customerDet = new CustomerDetails ();
	
	public String getErrCode() {
		return resultCode;
	}
	public void setErrCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public List<ResponseError> getErrList() {
		return errList;
	}
	public void setErrList(List<ResponseError> errList) {
		this.errList = errList;
	}
	public CustomerDetails getCustomerDet() {
		return customerDet;
	}
	public void setCustomerDet(CustomerDetails customerDet) {
		this.customerDet = customerDet;
	}
	

}



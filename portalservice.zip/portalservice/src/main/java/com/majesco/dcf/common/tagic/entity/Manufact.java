package com.majesco.dcf.common.tagic.entity;


import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_vehicle_manuf_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_vehicle_manuf_m")							// Added for Oracle Migration
public class Manufact implements Serializable{
	
	private String strmanufacturercd;
	private String strmanufacturername;
	private String strvehiclecatcd;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	private String strstatusflag;
	private String strstatus;

	
	
	@Id
	@Column(name = "strmanufacturercd")
	public String getStrmanufacturercd() {
		return strmanufacturercd;
	}
	public void setStrmanufacturercd(String strmanufacturercd) {
		this.strmanufacturercd = strmanufacturercd;
	}
	
	
	@Column(name = "strmanufacturername")
	public String getStrmanufacturername() {
		return strmanufacturername;
	}
	public void setStrmanufacturername(String strmanufacturername) {
		this.strmanufacturername = strmanufacturername;
	}
	
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	
	@Column(name = "strstatusflag")
	public String getStrstatusflag() {
		return strstatusflag;
	}
	public void setStrstatusflag(String strstatusflag) {
		this.strstatusflag = strstatusflag;
	}
	
	
	@Column(name = "strstatus")
	public String getStrstatus() {
		return strstatus;
	}
	public void setStrstatus(String strstatus) {
		this.strstatus = strstatus;
	}
	
	@Column(name = "strvehiclecatcd")
	public String getStrvehiclecatcd() {
		return strvehiclecatcd;
	}
	public void setStrvehiclecatcd(String strvehiclecatcd) {
		this.strvehiclecatcd = strvehiclecatcd;
	}
	
	

}

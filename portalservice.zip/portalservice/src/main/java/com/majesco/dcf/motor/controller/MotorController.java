package com.majesco.dcf.motor.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.majesco.dcf.common.tagic.errorhandler.ErrorHandlerUtility;
import com.majesco.dcf.common.tagic.json.AuthenticationRequest;
import com.majesco.dcf.common.tagic.json.AuthenticationResponse;
import com.majesco.dcf.common.tagic.json.JsonDBService;
import com.majesco.dcf.common.tagic.json.QuotationListResponse;
import com.majesco.dcf.common.tagic.json.QuotationSearchRequest;
import com.majesco.dcf.common.tagic.json.QuotationSearchResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.service.AuthenticationService;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.TagicCommonService;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.motor.json.AddOnPlanProducerRequest;
import com.majesco.dcf.motor.json.AddOnPlanProducerResponse;
import com.majesco.dcf.motor.json.CalculatorMotorRequest;
import com.majesco.dcf.motor.json.CalculatorMotorResponse;
import com.majesco.dcf.motor.json.GenerateMoratoriumRequest;
import com.majesco.dcf.motor.json.GenerateMoratoriumResponse;
import com.majesco.dcf.motor.json.GenerateQuoteMotorRequest;
import com.majesco.dcf.motor.json.GenerateQuoteMotorResponse;
import com.majesco.dcf.motor.json.InspectionRequest;
import com.majesco.dcf.motor.json.InspectionResponse;
import com.majesco.dcf.motor.json.ProductProposalDataCVRequest;
import com.majesco.dcf.motor.json.ProductProposalDataCVResponse;
import com.majesco.dcf.motor.json.ProductProposalDataPVRequest;
import com.majesco.dcf.motor.json.ProductProposalDataPVResponse;
import com.majesco.dcf.motor.json.ProductProposalDataTWRequest;
import com.majesco.dcf.motor.json.ProductProposalDataTWResponse;
import com.majesco.dcf.motor.json.ProposalGenerationCVRequest;
import com.majesco.dcf.motor.json.ProposalGenerationCVResponse;
import com.majesco.dcf.motor.json.ProposalGenerationPVRequest;
import com.majesco.dcf.motor.json.ProposalGenerationPVResponse;
import com.majesco.dcf.motor.json.ProposalGenerationTWRequest;
import com.majesco.dcf.motor.json.ProposalGenerationTWResponse;
import com.majesco.dcf.motor.service.InspectionCoverNoteService;
import com.majesco.dcf.motor.service.MotorService;

@Controller
@RequestMapping(value="/MotorService")
public class MotorController {
	
	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/
	
	@Autowired
	MotorService motorServ;
	
	@Autowired
	InspectionCoverNoteService inspectionCoverNoteService;
	
	@Autowired
	TagicCommonService tagicCommonService;
	
	@Autowired
	AuthenticationService authService;
	
	@Autowired
	DBService dbService;
	
	@Autowired
	ErrorHandlerUtility errorHandlerUtility;
	
	final static Logger logger=Logger.getLogger(MotorController.class);
	
	@RequestMapping(value="/calcPremMotor/", method = RequestMethod.POST)
	@ResponseBody
	public CalculatorMotorResponse calculatePremiumMotor(@RequestBody CalculatorMotorRequest calcMotReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: calculatepremiumMotor method :: Execution Started");
		StopWatch watch_calculatePremiumMotor = new StopWatch();
		watch_calculatePremiumMotor.start();
		/*Moratorium related changes starts here 23/03/2017*/
		boolean isMoratorium = false;
		HashMap<String, String> rtoGroupMap = new HashMap<String, String>();
		String rtoGroupCode = null;
		ObjectMapper objMap = new ObjectMapper();
		String straction = null;
		CalculatorMotorResponse calcMotres = new CalculatorMotorResponse();
		
		try
		{
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: calculatepremiumMotor method :: calcMotReq.getRegisteredCityRTO() : "+calcMotReq.getRegisteredCityRTO());
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			calcMotReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+calcMotReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			
			if(calcMotReq.getRegisteredCityRTO() != null && !(calcMotReq.getRegisteredCityRTO().equalsIgnoreCase("")))
				rtoGroupMap = (HashMap<String,String>) dbService.getRTOGroupCode("com.majesco.dcf.common.tagic.entity.RTOLocation", calcMotReq.getRegisteredCityRTO());
			
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: calculatepremiumMotor method :: rtoGroupMap : "+objMap.writeValueAsString(rtoGroupMap));
			
			if(rtoGroupMap!=null && rtoGroupMap.size()>0)
			{
				rtoGroupCode = rtoGroupMap.get("stateCode");
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: calculatepremiumMotor method :: rtoGroupCode : "+rtoGroupCode);
				
				straction = dbService.getMoratoriumChk(calcMotReq.getProdCD(), calcMotReq.getManufactCode(), calcMotReq.getModelCode(), calcMotReq.getManufactYear(), calcMotReq.getProducerCode(), rtoGroupCode , calcMotReq.getFuelType()); // <2086> : 21-Sep-2017 : Vishal : Extra parameter sent for Checking with fuelType 
				
				if(straction!=null && !straction.equals("") && (straction.equalsIgnoreCase("D") || straction.equalsIgnoreCase("R")))
				{
					isMoratorium = true;
				}
			}
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: calculatepremiumMotor method :: Exception Occured In Moratorium.....",ae);
		}
		/*Moratorium related changes ends here 23/03/2017*/
		
		if(isMoratorium)
		{
			calcMotres.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag(CommonConstants.MORATORIUM_ERROR_MESSAGE);
			errorList.add(errorRes);
			calcMotres.setResErr(errorList);
		}
		else
		{
			calcMotReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
			calcMotres = 	motorServ.calculatePremiumMotor(calcMotReq);
			//Start:16/03/2017:Defect_555:Changes done to re trigger get premium if basis of rating error comes for Campaign.
					if(calcMotres!=null && calcMotres.getResultCode()!=null && calcMotres.getResultCode().equals(CommonConstants.FAILURE_STATUS)){
						List<ResponseError> responseErrorList=calcMotres.getResErr();
						
						if(responseErrorList!=null && responseErrorList.size()>0){
							ResponseError responseError=(ResponseError)responseErrorList.get(0);
							
							if(responseError!=null && responseError.getErrorMMessag()!=null && responseError.getErrorMMessag().contains("Basis of rating")){
								calcMotReq.setBasisOfRating("GLM");
								
								calcMotres = 	motorServ.calculatePremiumMotor(calcMotReq);
							}
						}
					}
		}
		
		logger.info("Inside MotorController :: calculatepremiumMotor method :: Execution Completed Successfully");
		watch_calculatePremiumMotor.stop();
		logger.info("Time Taken by calculatepremiumMotor service in seconds..>>"+watch_calculatePremiumMotor.getTotalTimeSeconds());
		
		return calcMotres;
	}
	
	
	@RequestMapping(value="/createPropMotorCV/", method = RequestMethod.POST)
	@ResponseBody
	public ProposalGenerationCVResponse generateProposalCV(@RequestBody ProposalGenerationCVRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: createProposalCV method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		
		ProposalGenerationCVResponse genProp = new ProposalGenerationCVResponse();
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			
			propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
			if(propGenReq!=null)
			{
				boolean sub_product = false;
				boolean gvw = false;
				boolean reg_state = false;
				String strParamVal = null;
				String stateCode = null;
				propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getSubProduct()!=null)
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalCV method :: Applying Portal Rules : propGenReq.getLstvecReg().getSubProduct() : "+propGenReq.getLstvecReg().getSubProduct());
					if(propGenReq.getLstvecReg().getSubProduct().equalsIgnoreCase(CommonConstants.COMMERCIAL_SUBPRODUCT_RULE_CHECK))
					{
						sub_product = true;
					}
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalCV method :: Applying Portal Rules : sub_product flag : "+sub_product);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getGrossVehWeight()!=null && !propGenReq.getLstvecReg().getGrossVehWeight().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalCV method :: Applying Portal Rules : propGenReq.getLstvecReg().getGrossVehWeight() : "+propGenReq.getLstvecReg().getGrossVehWeight());
					
					strParamVal = dbService.getConfigParamVal(CommonConstants.COMMERCIAL_GVW_RULE_CHECK_STRING);
					
					if(strParamVal!=null & !strParamVal.equals(""))
					{
						double gross_veh_weight_db = Double.parseDouble(strParamVal);
						double gross_veh_weight_request = Double.parseDouble(propGenReq.getLstvecReg().getGrossVehWeight());
						
						//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalCV method :: Applying Portal Rules : gross_veh_weight_db : "+gross_veh_weight_db);
						//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalCV method :: Applying Portal Rules : gross_veh_weight_request : "+gross_veh_weight_request);
						
						if(gross_veh_weight_request > gross_veh_weight_db)
						{
							gvw = true;
						}
					}
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalCV method :: Applying Portal Rules : gvw flag : "+gvw);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getVehicleRegNumber1()!=null && !propGenReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalCV method :: Applying Portal Rules : propGenReq.getLstvecReg().getVehicleRegNumber1() : "+propGenReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, propGenReq.getLstvecReg().getVehicleRegNumber1(), "1098", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalCV method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalCV method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(sub_product && gvw && reg_state)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.COMMERCIAL_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Commercial);
			String errorDesc = null;
			
			if(propGenReq!=null && propGenReq.getLstAddonCover()!=null && propGenReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !propGenReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(propGenReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: createProposalCV method :: Exception Occurred",ae);
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		/*Code For Portal Rules Ends Here....................*/
		// 03/06/2017 : Condition added to restrict call to saveInpection by Vishal 
		if(propGenReq!=null && propGenReq.getLstPreInspResDet()!=null && 
				propGenReq.getLstPreInspResDet().getInspRefNo()!=null && 
				!propGenReq.getLstPreInspResDet().getInspRefNo().equalsIgnoreCase(CommonConstants.BLANK_STRING) &&
				propGenReq.getProposalResponse()!=null && propGenReq.getProposalResponse().getProposalNumber()!=null){   
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalPV method :: Calling  saveInspAfterSaveProposalPV");
			genProp  = motorServ.saveInspAfterSaveProposalCV(propGenReq);					
			return genProp;
			
		}else{
		
		genProp = 	motorServ.generateProposalCV(propGenReq);
		
/*if(propGenReq!=null && propGenReq.getLstPreInspResDet()!=null && genProp!=null && genProp.getProposalNumber()!=null){
			
			InspectionRequest inspectionRequest=new InspectionRequest();
			inspectionRequest.setIsHardCopyReq(propGenReq.getIsHardCopyReq());
			inspectionRequest.setLsdaddDet(propGenReq.getLsdaddDet());
			inspectionRequest.setLstAddonCover(propGenReq.getLstAddonCover());
			inspectionRequest.setLstChanlDet(propGenReq.getLstChanlDet());
			inspectionRequest.setLstcustDet(propGenReq.getLstcustDet());
			inspectionRequest.setLstCvrNtDet(propGenReq.getLstCvrNtDet());
			inspectionRequest.setLstdiscdet(propGenReq.getLstdiscdet());
			inspectionRequest.setLstDocChkDet(propGenReq.getLstDocChkDet());
			inspectionRequest.setLstDrivrDet(propGenReq.getLstDrivrDet());
			inspectionRequest.setLstInsuDet(propGenReq.getLstInsuDet());
			inspectionRequest.setLstNomDet(propGenReq.getLstNomDet());
			inspectionRequest.setLstPreInspResDet(propGenReq.getLstPreInspResDet());
			inspectionRequest.setLstRiskdet(propGenReq.getLstRiskdet());
			inspectionRequest.setLstvecReg(propGenReq.getLstvecReg());
			
			InspectionResponse inspectionResponse=saveInspection(inspectionRequest);
		}*/
		
		logger.info("Inside MotorController :: createProposalCV method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by createProposalCV service in seconds..>>"+watch.getTotalTimeSeconds());
			
		return genProp;
		}
	}
	
	
	@RequestMapping(value="/createPropMotorPV/", method = RequestMethod.POST)
	@ResponseBody
	public ProposalGenerationPVResponse generateProposalPV(@RequestBody ProposalGenerationPVRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: createProposalPV method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		
		ProposalGenerationPVResponse genProp = new ProposalGenerationPVResponse();
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
			
			if(propGenReq!=null)
			{
				boolean cover_variant = false;
				boolean reg_state = false;
				String stateCode = null;
				
				if(propGenReq.getLstRiskdet()!=null && propGenReq.getLstRiskdet().getPolicyCoverVariant()!=null && !propGenReq.getLstRiskdet().getPolicyCoverVariant().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalPV method :: Applying Portal Rules : propGenReq.getLstRiskdet().getPolicyCoverVariant() : "+propGenReq.getLstRiskdet().getPolicyCoverVariant());
					
					if(propGenReq.getLstRiskdet().getPolicyCoverVariant().equalsIgnoreCase("2"))
					{
						cover_variant = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalPV method :: Applying Portal Rules : cover_variant flag : "+cover_variant);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getVehicleRegNumber1()!=null && !propGenReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalPV method :: Applying Portal Rules : propGenReq.getLstvecReg().getVehicleRegNumber1() : "+propGenReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, propGenReq.getLstvecReg().getVehicleRegNumber1(), "1099", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalPV method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalPV method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(cover_variant && reg_state)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.PRIVATE_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Private_Car);
			String errorDesc = null;
			
			if(propGenReq!=null && propGenReq.getLstAddonCover()!=null && propGenReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !propGenReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(propGenReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: createProposalPV method :: Exception Occurred",ae);
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		/*Code For Portal Rules Ends Here....................*/
		//Condition to check for the inspection of the Existing Proposal
		// 03/06/2017 : Condition added to restrict call to saveInpection by Vishal 
		if(propGenReq!=null && propGenReq.getLstPreInspResDet()!=null && 
				propGenReq.getLstPreInspResDet().getInspRefNo()!=null && 
				!propGenReq.getLstPreInspResDet().getInspRefNo().equalsIgnoreCase(CommonConstants.BLANK_STRING) &&
				propGenReq.getProposalResponse()!=null 
				&& propGenReq.getProposalResponse().getProposalNumber()!=null){   
			logger.info("Inside MotorController :: createProposalPV method :: Calling  saveInspAfterSaveProposalPV");
			genProp  = motorServ.saveInspAfterSaveProposalPV(propGenReq);		
			watch.stop();
			logger.info("Time Taken by createProposalPV service in seconds..>>"+watch.getTotalTimeSeconds());
			return genProp;
			
		}else{		
			
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalPV method :: Calling Save Proposal ");
			genProp = 	motorServ.generateProposalPV(propGenReq);
			
			logger.info("Inside MotorController :: createProposalPV method :: Execution Completed Successfully");
			watch.stop();
			logger.info("Time Taken by createProposalPV service in seconds..>>"+watch.getTotalTimeSeconds());
				
			return genProp;
		
		}
		
	}
	
	
	@RequestMapping(value="/createPropMotorTW/", method = RequestMethod.POST)
	@ResponseBody
	public ProposalGenerationTWResponse generateProposalTW(@RequestBody ProposalGenerationTWRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: createProposalTW method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		
		ProposalGenerationTWResponse genProp = new ProposalGenerationTWResponse();
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
			if(propGenReq!=null)
			{
				boolean cover_variant = false;
				boolean reg_state = false;
				String stateCode = null;
				
				if(propGenReq.getLstRiskdet()!=null && propGenReq.getLstRiskdet().getPolicyCoverVariant()!=null && !propGenReq.getLstRiskdet().getPolicyCoverVariant().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalTW method :: Applying Portal Rules : propGenReq.getLstRiskdet().getPolicyCoverVariant() : "+propGenReq.getLstRiskdet().getPolicyCoverVariant());
					
					if(propGenReq.getLstRiskdet().getPolicyCoverVariant().equalsIgnoreCase("2"))
					{
						cover_variant = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalTW method :: Applying Portal Rules : cover_variant flag : "+cover_variant);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getVehicleRegNumber1()!=null && !propGenReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalTW method :: Applying Portal Rules : propGenReq.getLstvecReg().getVehicleRegNumber1() : "+propGenReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, propGenReq.getLstvecReg().getVehicleRegNumber1(), "2000", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalTW method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: createProposalTW method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(cover_variant && reg_state)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.TWO_WHEELER_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Two_Wheeler);
			String errorDesc = null;
			
			if(propGenReq!=null && propGenReq.getLstAddonCover()!=null && propGenReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !propGenReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(propGenReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: createProposalTW method :: Exception Occurred",ae);
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		/*Code For Portal Rules Ends Here....................*/
		//Condition to check for the inspection of the Existing Proposal
		// 03/06/2017 : Condition added to restrict call to saveInpection by Vishal 
		if(propGenReq!=null && propGenReq.getLstPreInspResDet()!=null && 
				propGenReq.getLstPreInspResDet().getInspRefNo()!=null && 
				!propGenReq.getLstPreInspResDet().getInspRefNo().equalsIgnoreCase(CommonConstants.BLANK_STRING) &&
				propGenReq.getProposalResponse()!=null && propGenReq.getProposalResponse().getProposalNumber()!=null){   
			logger.info("Inside MotorController :: createProposalPV method :: Calling  saveInspAfterSaveProposalPV");
			genProp  = motorServ.saveInspAfterSaveProposalTW(propGenReq);					
			return genProp;
			
		}else{
			genProp = 	motorServ.generateProposalTW(propGenReq);
			
			/*if(propGenReq!=null && propGenReq.getLstPreInspResDet()!=null && genProp!=null && genProp.getProposalNumber()!=null){
					
						InspectionRequest inspectionRequest=new InspectionRequest();
						inspectionRequest.setIsHardCopyReq(propGenReq.getIsHardCopyReq());
						inspectionRequest.setLsdaddDet(propGenReq.getLsdaddDet());
						inspectionRequest.setLstAddonCover(propGenReq.getLstAddonCover());
						inspectionRequest.setLstChanlDet(propGenReq.getLstChanlDet());
						inspectionRequest.setLstcustDet(propGenReq.getLstcustDet());
						inspectionRequest.setLstCvrNtDet(propGenReq.getLstCvrNtDet());
						inspectionRequest.setLstdiscdet(propGenReq.getLstdiscdet());
						inspectionRequest.setLstDocChkDet(propGenReq.getLstDocChkDet());
						inspectionRequest.setLstDrivrDet(propGenReq.getLstDrivrDet());
						inspectionRequest.setLstInsuDet(propGenReq.getLstInsuDet());
						inspectionRequest.setLstNomDet(propGenReq.getLstNomDet());
						inspectionRequest.setLstPreInspResDet(propGenReq.getLstPreInspResDet());
						inspectionRequest.setLstRiskdet(propGenReq.getLstRiskdet());
						inspectionRequest.setLstvecReg(propGenReq.getLstvecReg());
								
						InspectionResponse inspectionResponse=saveInspection(inspectionRequest);
					}
				*/
			logger.info("Inside MotorController :: createProposalTW method :: Execution Completed Successfully");
			watch.stop();
			logger.info("Time Taken by createProposalTW service in seconds..>>"+watch.getTotalTimeSeconds());
								
				return genProp;					
		}

	}
	
	
	@RequestMapping(value="/getQuoteMotorCV/", method = RequestMethod.POST)
	@ResponseBody	
	public GenerateQuoteMotorResponse generateQuoteMotorCV(@RequestBody GenerateQuoteMotorRequest quickReq,HttpServletRequest httpServletRequest) throws Exception
	{	
		logger.info("Inside MotorController :: GetMotorQuote method :: Execution Started");	 
		StopWatch watch = new StopWatch();
		watch.start();
		GenerateQuoteMotorResponse result = new GenerateQuoteMotorResponse();
		
		/*Moratorium related changes starts here Issue ID - 1497*/
		boolean isMoratorium = false;
		HashMap<String, String> rtoGroupMap = new HashMap<String, String>();
		String rtoGroupCode = null;
		ObjectMapper objMap = new ObjectMapper();
		String straction = null;
		CalculatorMotorResponse calcMotres = new CalculatorMotorResponse();
		
		try
		{
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorCV method :: calcMotReq.getRegisteredCityRTO() : "+quickReq.getLstvecReg().getRegistrationAuthLoc());
			
			if(quickReq.getLstvecReg().getRegistrationAuthLoc() != null && !(quickReq.getLstvecReg().getRegistrationAuthLoc().equalsIgnoreCase("")))
				rtoGroupMap = (HashMap<String,String>) dbService.getRTOGroupCode("com.majesco.dcf.common.tagic.entity.RTOLocation", quickReq.getLstvecReg().getRegistrationAuthLoc());
			
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorCV method :: rtoGroupMap : "+objMap.writeValueAsString(rtoGroupMap));
			
			if(rtoGroupMap!=null && rtoGroupMap.size()>0)
			{
				rtoGroupCode = rtoGroupMap.get("stateCode");
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorCV method :: rtoGroupCode : "+rtoGroupCode);
				
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorCV method :: prodcd : "+quickReq.getStrprodcd()+" ManufacturerCode : "+quickReq.getLstvecReg().getManufacturerCode()+" ModelCode : "+quickReq.getLstvecReg().getModelCode()+" ManufactureYear : "+quickReq.getLstvecReg().getManufactureYear()+" ProducerCode : "+quickReq.getProducerCode());
				
				straction = dbService.getMoratoriumChk(quickReq.getStrprodcd(), quickReq.getLstvecReg().getManufacturerCode(), quickReq.getLstvecReg().getModelCode(), quickReq.getLstvecReg().getManufactureYear(), quickReq.getProducerCode(), rtoGroupCode, quickReq.getLstvecReg().getFuelType()); // <2086> : 21-Sep-2017 : Vishal : Extra parameter sent for Checking with fuelType
				
				if(straction!=null && !straction.equals("") && (straction.equalsIgnoreCase("D") || straction.equalsIgnoreCase("R")))
				{
					isMoratorium = true;
				}
			}
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: generateQuoteMotorCV method :: Exception Occured In Moratorium.....",ae);
		}
		
		if(isMoratorium)
		{
			result.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag(CommonConstants.MORATORIUM_ERROR_MESSAGE);
			errorList.add(errorRes);
			result.setResErr(errorList);
			
			return result;
		}
		/*Moratorium related changes ends here Issue ID - 1497*/
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			quickReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+quickReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			if(quickReq!=null)
			{
				boolean sub_product = false;
				boolean gvw = false;
				boolean reg_state = false;
				String strParamVal = null;
				String stateCode = null;
				quickReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
				if(quickReq.getLstvecReg()!=null && quickReq.getLstvecReg().getSubProduct()!=null)
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : quickReq.getLstvecReg().getSubProduct() : "+quickReq.getLstvecReg().getSubProduct());
					if(quickReq.getLstvecReg().getSubProduct().equalsIgnoreCase(CommonConstants.COMMERCIAL_SUBPRODUCT_RULE_CHECK))
					{
						sub_product = true;
					}
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : sub_product flag : "+sub_product);
				}
				
				if(quickReq.getLstvecReg()!=null && quickReq.getLstvecReg().getGrossVehWeight()!=null && !quickReq.getLstvecReg().getGrossVehWeight().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : quickReq.getLstvecReg().getGrossVehWeight() : "+quickReq.getLstvecReg().getGrossVehWeight());
					
					strParamVal = dbService.getConfigParamVal(CommonConstants.COMMERCIAL_GVW_RULE_CHECK_STRING);
					
					if(strParamVal!=null & !strParamVal.equals(""))
					{
						double gross_veh_weight_db = Double.parseDouble(strParamVal);
						double gross_veh_weight_request = Double.parseDouble(quickReq.getLstvecReg().getGrossVehWeight());
						
						//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : gross_veh_weight_db : "+gross_veh_weight_db);
						//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : gross_veh_weight_request : "+gross_veh_weight_request);
						
						if(gross_veh_weight_request > gross_veh_weight_db)
						{
							gvw = true;
						}
					}
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : gvw flag : "+gvw);
				}
				
				if(quickReq.getLstvecReg()!=null && quickReq.getLstvecReg().getVehicleRegNumber1()!=null && !quickReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : quickReq.getLstvecReg().getVehicleRegNumber1() : "+quickReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, quickReq.getLstvecReg().getVehicleRegNumber1(), "1098", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(sub_product && gvw && reg_state)
				{
					result.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.COMMERCIAL_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					result.setResErr(errorList);
					
					return result;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Commercial);
			String errorDesc = null;
			
			if(quickReq!=null && quickReq.getLstAddonCover()!=null && quickReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !quickReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(quickReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					result.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					result.setResErr(errorList);
					
					return result;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: GetMotorQuote method :: Exception Occurred",ae);
			result.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			result.setResErr(errorList);
			
			return result;
		}
		/*Code For Portal Rules Ends Here....................*/
		
		result = motorServ.generateQuoteMotorCV(quickReq);
		
		logger.info("Inside MotorController :: GetMotorQuote method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by GetMotorQuote service in seconds..>>"+watch.getTotalTimeSeconds());
					
		return result;
	}	
	
	@RequestMapping(value="/getQuoteMotorPV/", method = RequestMethod.POST)
	@ResponseBody	
	public GenerateQuoteMotorResponse generateQuoteMotorPV(@RequestBody GenerateQuoteMotorRequest quickReq,HttpServletRequest httpServletRequest) throws Exception
	{	
		logger.info("Inside MotorController :: GetMotorQuote method :: Execution Started");	 
		StopWatch watch = new StopWatch();
		watch.start();
		GenerateQuoteMotorResponse result = new GenerateQuoteMotorResponse();
		
		/*Moratorium related changes starts here Issue ID - 1497*/
		boolean isMoratorium = false;
		HashMap<String, String> rtoGroupMap = new HashMap<String, String>();
		String rtoGroupCode = null;
		ObjectMapper objMap = new ObjectMapper();
		String straction = null;
		CalculatorMotorResponse calcMotres = new CalculatorMotorResponse();
		
		try
		{
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorPV method :: calcMotReq.getRegisteredCityRTO() : "+quickReq.getLstvecReg().getRegistrationAuthLoc());
			
			if(quickReq.getLstvecReg().getRegistrationAuthLoc() != null && !(quickReq.getLstvecReg().getRegistrationAuthLoc().equalsIgnoreCase("")))
				rtoGroupMap = (HashMap<String,String>) dbService.getRTOGroupCode("com.majesco.dcf.common.tagic.entity.RTOLocation", quickReq.getLstvecReg().getRegistrationAuthLoc());
			
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorPV method :: rtoGroupMap : "+objMap.writeValueAsString(rtoGroupMap));
			
			if(rtoGroupMap!=null && rtoGroupMap.size()>0)
			{
				rtoGroupCode = rtoGroupMap.get("stateCode");
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorPV method :: rtoGroupCode : "+rtoGroupCode);
				
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorPV method :: prodcd : "+quickReq.getStrprodcd()+" ManufacturerCode : "+quickReq.getLstvecReg().getManufacturerCode()+" ModelCode : "+quickReq.getLstvecReg().getModelCode()+" ManufactureYear : "+quickReq.getLstvecReg().getManufactureYear()+" ProducerCode : "+quickReq.getProducerCode());
				
				straction = dbService.getMoratoriumChk(quickReq.getStrprodcd(), quickReq.getLstvecReg().getManufacturerCode(), quickReq.getLstvecReg().getModelCode(), quickReq.getLstvecReg().getManufactureYear(), quickReq.getProducerCode(), rtoGroupCode ,quickReq.getLstvecReg().getFuelType()); // <2086> : 21-Sep-2017 : Vishal : Extra parameter sent for Checking with fuelType
				
				if(straction!=null && !straction.equals("") && (straction.equalsIgnoreCase("D") || straction.equalsIgnoreCase("R")))
				{
					isMoratorium = true;
				}
			}
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: generateQuoteMotorPV method :: Exception Occured In Moratorium.....",ae);
		}
		
		if(isMoratorium)
		{
			result.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag(CommonConstants.MORATORIUM_ERROR_MESSAGE);
			errorList.add(errorRes);
			result.setResErr(errorList);
			
			return result;
		}
		/*Moratorium related changes ends here Issue ID - 1497*/
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			quickReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+quickReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			if(quickReq!=null)
			{
				boolean cover_variant = false;
				boolean reg_state = false;
				String stateCode = null;
				quickReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
				
				if(quickReq.getLstRiskdet()!=null && quickReq.getLstRiskdet().getPolicyCoverVariant()!=null && !quickReq.getLstRiskdet().getPolicyCoverVariant().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : quickReq.getLstRiskdet().getPolicyCoverVariant() : "+quickReq.getLstRiskdet().getPolicyCoverVariant());
					
					if(quickReq.getLstRiskdet().getPolicyCoverVariant().equalsIgnoreCase("2"))
					{
						cover_variant = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : cover_variant flag : "+cover_variant);
				}
				
				if(quickReq.getLstvecReg()!=null && quickReq.getLstvecReg().getVehicleRegNumber1()!=null && !quickReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : quickReq.getLstvecReg().getVehicleRegNumber1() : "+quickReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, quickReq.getLstvecReg().getVehicleRegNumber1(), "1099", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: GetMotorQuote method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(cover_variant && reg_state)
				{
					result.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.PRIVATE_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					result.setResErr(errorList);
					
					return result;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Private_Car);
			String errorDesc = null;
			
			if(quickReq!=null && quickReq.getLstAddonCover()!=null && quickReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !quickReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(quickReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					result.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					result.setResErr(errorList);
					
					return result;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: GetMotorQuote method :: Exception Occurred",ae);
			result.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			result.setResErr(errorList);
			
			return result;
		}
		/*Code For Portal Rules Ends Here....................*/
		
		result = motorServ.generateQuoteMotorPV(quickReq);
		ObjectMapper objM=new ObjectMapper();
        if(result!=null && result.getResultCode()!=null && result.getResultCode().equals(CommonConstants.FAILURE_STATUS)){
               List<ResponseError> responseErrorList=result.getResErr();
              // if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: ENTERING FAILURE"+objM.writeValueAsString(result));      
               if(responseErrorList!=null && responseErrorList.size()>0){
                     ResponseError responseError=(ResponseError)responseErrorList.get(0);
                     if(responseError!=null && responseError.getErrorMMessag()!=null && responseError.getErrorMMessag().contains("Basis of rating")){
                            quickReq.getLstvecReg().setBasisofRating("GLM");
                            //if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: FAILURE BASIS RESET"+objM.writeValueAsString(quickReq));
                            result =      motorServ.generateQuoteMotorPV(quickReq);
                           // if(logger.isDebugEnabled())logger.debug("Error Response"+objM.writeValueAsString(responseError));
                     }
               }
        }

		logger.info("Inside MotorController :: GetMotorQuote method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by GetMotorQuote service in seconds..>>"+watch.getTotalTimeSeconds());
		return result;
	}
	
	@RequestMapping(value="/getQuoteMotorTW/", method = RequestMethod.POST)
	@ResponseBody	
	public GenerateQuoteMotorResponse generateQuoteMotorTW(@RequestBody GenerateQuoteMotorRequest quickReq,HttpServletRequest httpServletRequest) throws Exception
	{	
		logger.info("Inside MotorController :: generateQuoteMotorTW method :: Execution Started");	 
		StopWatch watch = new StopWatch();
		watch.start();
		GenerateQuoteMotorResponse result = new GenerateQuoteMotorResponse();
		
		/*Moratorium related changes starts here Issue ID - 1497*/
		boolean isMoratorium = false;
		HashMap<String, String> rtoGroupMap = new HashMap<String, String>();
		String rtoGroupCode = null;
		ObjectMapper objMap = new ObjectMapper();
		String straction = null;
		CalculatorMotorResponse calcMotres = new CalculatorMotorResponse();
		
		try
		{
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorTW method :: calcMotReq.getRegisteredCityRTO() : "+quickReq.getLstvecReg().getRegistrationAuthLoc());
			
			if(quickReq.getLstvecReg().getRegistrationAuthLoc() != null && !(quickReq.getLstvecReg().getRegistrationAuthLoc().equalsIgnoreCase("")))
				rtoGroupMap = (HashMap<String,String>) dbService.getRTOGroupCode("com.majesco.dcf.common.tagic.entity.RTOLocation", quickReq.getLstvecReg().getRegistrationAuthLoc());
			
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorTW method :: rtoGroupMap : "+objMap.writeValueAsString(rtoGroupMap));
			
			if(rtoGroupMap!=null && rtoGroupMap.size()>0)
			{
				rtoGroupCode = rtoGroupMap.get("stateCode");
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorTW method :: rtoGroupCode : "+rtoGroupCode);
				
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorTW method :: prodcd : "+quickReq.getStrprodcd()+" ManufacturerCode : "+quickReq.getLstvecReg().getManufacturerCode()+" ModelCode : "+quickReq.getLstvecReg().getModelCode()+" ManufactureYear : "+quickReq.getLstvecReg().getManufactureYear()+" ProducerCode : "+quickReq.getProducerCode());
				
				straction = dbService.getMoratoriumChk(quickReq.getStrprodcd(), quickReq.getLstvecReg().getManufacturerCode(), quickReq.getLstvecReg().getModelCode(), quickReq.getLstvecReg().getManufactureYear(), quickReq.getProducerCode(), rtoGroupCode , quickReq.getLstvecReg().getFuelType()); // <2086> : 21-Sep-2017 : Vishal : Extra parameter sent for Checking with fuelType
				
				if(straction!=null && !straction.equals("") && (straction.equalsIgnoreCase("D") || straction.equalsIgnoreCase("R")))
				{
					isMoratorium = true;
				}
			}
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: generateQuoteMotorTW method :: Exception Occured In Moratorium.....",ae);
		}
		
		if(isMoratorium)
		{
			result.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag(CommonConstants.MORATORIUM_ERROR_MESSAGE);
			errorList.add(errorRes);
			result.setResErr(errorList);
			
			return result;
		}
		/*Moratorium related changes ends here Issue ID - 1497*/
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			quickReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+quickReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			if(quickReq!=null)
			{
				boolean cover_variant = false;
				boolean reg_state = false;
				String stateCode = null;
				quickReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
				if(quickReq.getLstRiskdet()!=null && quickReq.getLstRiskdet().getPolicyCoverVariant()!=null && !quickReq.getLstRiskdet().getPolicyCoverVariant().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorTW method :: Applying Portal Rules : quickReq.getLstRiskdet().getPolicyCoverVariant() : "+quickReq.getLstRiskdet().getPolicyCoverVariant());
					
					if(quickReq.getLstRiskdet().getPolicyCoverVariant().equalsIgnoreCase("2"))
					{
						cover_variant = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorTW method :: Applying Portal Rules : cover_variant flag : "+cover_variant);
				}
				
				if(quickReq.getLstvecReg()!=null && quickReq.getLstvecReg().getVehicleRegNumber1()!=null && !quickReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorTW method :: Applying Portal Rules : quickReq.getLstvecReg().getVehicleRegNumber1() : "+quickReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, quickReq.getLstvecReg().getVehicleRegNumber1(), "2000", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorTW method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: generateQuoteMotorTW method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(cover_variant && reg_state)
				{
					result.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.TWO_WHEELER_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					result.setResErr(errorList);
					
					return result;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Two_Wheeler);
			String errorDesc = null;
			
			if(quickReq!=null && quickReq.getLstAddonCover()!=null && quickReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !quickReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(quickReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					result.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					result.setResErr(errorList);
					
					return result;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: generateQuoteMotorTW method :: Exception Occurred",ae);
			result.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			result.setResErr(errorList);
			
			return result;
		}
		/*Code For Portal Rules Ends Here....................*/
		
		result = motorServ.generateQuoteMotorTW(quickReq);
		
		logger.info("Inside MotorController :: generateQuoteMotorTW method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by generateQuoteMotorTW service in seconds..>>"+watch.getTotalTimeSeconds());
		return result;
	}
	
	
	@RequestMapping(value="/getPremiumCV/", method = RequestMethod.POST)
	@ResponseBody
	public ProposalGenerationCVResponse getPremiumCV(@RequestBody ProposalGenerationCVRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: getPremiumCV method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		ProposalGenerationCVResponse genProp = new ProposalGenerationCVResponse();
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			if(propGenReq!=null)
			{
				boolean sub_product = false;
				boolean gvw = false;
				boolean reg_state = false;
				String strParamVal = null;
				String stateCode = null;
				propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getSubProduct()!=null)
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCV method :: Applying Portal Rules : propGenReq.getLstvecReg().getSubProduct() : "+propGenReq.getLstvecReg().getSubProduct());
					if(propGenReq.getLstvecReg().getSubProduct().equalsIgnoreCase(CommonConstants.COMMERCIAL_SUBPRODUCT_RULE_CHECK))
					{
						sub_product = true;
					}
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCV method :: Applying Portal Rules : sub_product flag : "+sub_product);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getGrossVehWeight()!=null && !propGenReq.getLstvecReg().getGrossVehWeight().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCV method :: Applying Portal Rules : propGenReq.getLstvecReg().getGrossVehWeight() : "+propGenReq.getLstvecReg().getGrossVehWeight());
					
					strParamVal = dbService.getConfigParamVal(CommonConstants.COMMERCIAL_GVW_RULE_CHECK_STRING);
					
					if(strParamVal!=null & !strParamVal.equals(""))
					{
						double gross_veh_weight_db = Double.parseDouble(strParamVal);
						double gross_veh_weight_request = Double.parseDouble(propGenReq.getLstvecReg().getGrossVehWeight());
						
						//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCV method :: Applying Portal Rules : gross_veh_weight_db : "+gross_veh_weight_db);
						//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCV method :: Applying Portal Rules : gross_veh_weight_request : "+gross_veh_weight_request);
						
						if(gross_veh_weight_request > gross_veh_weight_db)
						{
							gvw = true;
						}
					}
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCV method :: Applying Portal Rules : gvw flag : "+gvw);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getVehicleRegNumber1()!=null && !propGenReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCV method :: Applying Portal Rules : propGenReq.getLstvecReg().getVehicleRegNumber1() : "+propGenReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, propGenReq.getLstvecReg().getVehicleRegNumber1(), "1098", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCV method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCV method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(sub_product && gvw && reg_state)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.COMMERCIAL_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Commercial);
			String errorDesc = null;
			
			if(propGenReq!=null && propGenReq.getLstAddonCover()!=null && propGenReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !propGenReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(propGenReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: getPremiumCV method :: Exception Occurred",ae);
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		/*Code For Portal Rules Ends Here....................*/
		
		genProp = 	motorServ.getPremiumCV(propGenReq);
		logger.info("Inside MotorController :: getPremiumCV method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by getPremiumCV service in seconds..>>"+watch.getTotalTimeSeconds());
		return genProp;
	}
	
	
	@RequestMapping(value="/getPremiumPV/", method = RequestMethod.POST)
	@ResponseBody
	public ProposalGenerationPVResponse getPremiumPV(@RequestBody ProposalGenerationPVRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{

		logger.info("Inside MotorController :: getPremiumPV method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		ProposalGenerationPVResponse genProp = new ProposalGenerationPVResponse();
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			if(propGenReq!=null)
			{
				boolean cover_variant = false;
				boolean reg_state = false;
				String stateCode = null;
				propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
				if(propGenReq.getLstRiskdet()!=null && propGenReq.getLstRiskdet().getPolicyCoverVariant()!=null && !propGenReq.getLstRiskdet().getPolicyCoverVariant().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPV method :: Applying Portal Rules : propGenReq.getLstRiskdet().getPolicyCoverVariant() : "+propGenReq.getLstRiskdet().getPolicyCoverVariant());
					
					if(propGenReq.getLstRiskdet().getPolicyCoverVariant().equalsIgnoreCase("2"))
					{
						cover_variant = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPV method :: Applying Portal Rules : cover_variant flag : "+cover_variant);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getVehicleRegNumber1()!=null && !propGenReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPV method :: Applying Portal Rules : propGenReq.getLstvecReg().getVehicleRegNumber1() : "+propGenReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, propGenReq.getLstvecReg().getVehicleRegNumber1(), "1099", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPV method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPV method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(cover_variant && reg_state)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.PRIVATE_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Private_Car);
			String errorDesc = null;
			
			if(propGenReq!=null && propGenReq.getLstAddonCover()!=null && propGenReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !propGenReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(propGenReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: getPremiumPV method :: Exception Occurred",ae);
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		/*Code For Portal Rules Ends Here....................*/
		
		genProp = 	motorServ.getPremiumPV(propGenReq);
		//Start:16/03/2017:Defect_555:Changes done to re trigger get premium if basis of rating error comes for Campaign.
		if(genProp!=null && genProp.getResultCode()!=null && genProp.getResultCode().equals(CommonConstants.FAILURE_STATUS)){
			List<ResponseError> responseErrorList=genProp.getResErr();
			
			if(responseErrorList!=null && responseErrorList.size()>0){
				ResponseError responseError=(ResponseError)responseErrorList.get(0);
				
				if(responseError!=null && responseError.getErrorMMessag()!=null && responseError.getErrorMMessag().contains("Basis of rating")){
					propGenReq.getLstvecReg().setBasisofRating("GLM");
					
					genProp = 	motorServ.getPremiumPV(propGenReq);
				}
			}
		}
		//Start:16/03/2017:Defect_555:Changes done to re trigger get premium if basis of rating error comes for Campaign.
		
		logger.info("Inside MotorController :: getPremiumPV method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by getPremiumPV service in seconds..>>"+watch.getTotalTimeSeconds());	
		return genProp;
	
	}
	
	
	@RequestMapping(value="/getPremiumTW/", method = RequestMethod.POST)
	@ResponseBody
	public ProposalGenerationTWResponse getPremiumTW(@RequestBody ProposalGenerationTWRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: getPremiumTW method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		ProposalGenerationTWResponse genProp = new ProposalGenerationTWResponse();
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			if(propGenReq!=null)
			{
				boolean cover_variant = false;
				boolean reg_state = false;
				String stateCode = null;
				propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
				if(propGenReq.getLstRiskdet()!=null && propGenReq.getLstRiskdet().getPolicyCoverVariant()!=null && !propGenReq.getLstRiskdet().getPolicyCoverVariant().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTW method :: Applying Portal Rules : propGenReq.getLstRiskdet().getPolicyCoverVariant() : "+propGenReq.getLstRiskdet().getPolicyCoverVariant());
					
					if(propGenReq.getLstRiskdet().getPolicyCoverVariant().equalsIgnoreCase("2"))
					{
						cover_variant = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTW method :: Applying Portal Rules : cover_variant flag : "+cover_variant);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getVehicleRegNumber1()!=null && !propGenReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTW method :: Applying Portal Rules : propGenReq.getLstvecReg().getVehicleRegNumber1() : "+propGenReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, propGenReq.getLstvecReg().getVehicleRegNumber1(), "2000", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTW method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTW method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(cover_variant && reg_state)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.TWO_WHEELER_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Two_Wheeler);
			String errorDesc = null;
			
			if(propGenReq!=null && propGenReq.getLstAddonCover()!=null && propGenReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !propGenReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(propGenReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
			
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: getPremiumTW method :: Exception Occurred",ae);
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		genProp = 	motorServ.getPremiumTW(propGenReq);
						
		logger.info("Inside MotorController :: getPremiumTW method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by getPremiumTW service in seconds..>>"+watch.getTotalTimeSeconds());
		return genProp;
	}
	
	
	@RequestMapping(value="/getPremiumCVQuote/", method = RequestMethod.POST)
	@ResponseBody
	public GenerateQuoteMotorResponse getPremiumCVQuote(@RequestBody GenerateQuoteMotorRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: getPremiumCVQuote method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		GenerateQuoteMotorResponse genProp = new GenerateQuoteMotorResponse();
		
		/*Moratorium related changes starts here Issue ID - 1497*/
		boolean isMoratorium = false;
		HashMap<String, String> rtoGroupMap = new HashMap<String, String>();
		String rtoGroupCode = null;
		ObjectMapper objMap = new ObjectMapper();
		String straction = null;
		CalculatorMotorResponse calcMotres = new CalculatorMotorResponse();
		
		try
		{
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: calcMotReq.getRegisteredCityRTO() : "+propGenReq.getLstvecReg().getRegistrationAuthLoc());
			
			if(propGenReq.getLstvecReg().getRegistrationAuthLoc() != null && !(propGenReq.getLstvecReg().getRegistrationAuthLoc().equalsIgnoreCase("")))
				rtoGroupMap = (HashMap<String,String>) dbService.getRTOGroupCode("com.majesco.dcf.common.tagic.entity.RTOLocation", propGenReq.getLstvecReg().getRegistrationAuthLoc());
			
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: rtoGroupMap : "+objMap.writeValueAsString(rtoGroupMap));
			
			if(rtoGroupMap!=null && rtoGroupMap.size()>0)
			{
				rtoGroupCode = rtoGroupMap.get("stateCode");
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: rtoGroupCode : "+rtoGroupCode);
				
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: prodcd : "+propGenReq.getStrprodcd()+" ManufacturerCode : "+propGenReq.getLstvecReg().getManufacturerCode()+" ModelCode : "+propGenReq.getLstvecReg().getModelCode()+" ManufactureYear : "+propGenReq.getLstvecReg().getManufactureYear()+" ProducerCode : "+propGenReq.getProducerCode());
				
				straction = dbService.getMoratoriumChk(propGenReq.getStrprodcd(), propGenReq.getLstvecReg().getManufacturerCode(), propGenReq.getLstvecReg().getModelCode(), propGenReq.getLstvecReg().getManufactureYear(), propGenReq.getProducerCode(), rtoGroupCode , propGenReq.getLstvecReg().getFuelType()); // <2086> : 21-Sep-2017 : Vishal : Extra parameter sent for Checking with fuelType
				
				if(straction!=null && !straction.equals("") && (straction.equalsIgnoreCase("D") || straction.equalsIgnoreCase("R")))
				{
					isMoratorium = true;
				}
			}
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: getPremiumCVQuote method :: Exception Occured In Moratorium.....",ae);
		}
		
		if(isMoratorium)
		{
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag(CommonConstants.MORATORIUM_ERROR_MESSAGE);
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		/*Moratorium related changes ends here Issue ID - 1497*/
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			if(propGenReq!=null)
			{
				boolean sub_product = false;
				boolean gvw = false;
				boolean reg_state = false;
				String strParamVal = null;
				String stateCode = null;
				propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getSubProduct()!=null)
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: Applying Portal Rules : propGenReq.getLstvecReg().getSubProduct() : "+propGenReq.getLstvecReg().getSubProduct());
					if(propGenReq.getLstvecReg().getSubProduct().equalsIgnoreCase(CommonConstants.COMMERCIAL_SUBPRODUCT_RULE_CHECK))
					{
						sub_product = true;
					}
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: Applying Portal Rules : sub_product flag : "+sub_product);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getGrossVehWeight()!=null && !propGenReq.getLstvecReg().getGrossVehWeight().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: Applying Portal Rules : propGenReq.getLstvecReg().getGrossVehWeight() : "+propGenReq.getLstvecReg().getGrossVehWeight());
					
					strParamVal = dbService.getConfigParamVal(CommonConstants.COMMERCIAL_GVW_RULE_CHECK_STRING);
					
					if(strParamVal!=null & !strParamVal.equals(""))
					{
						double gross_veh_weight_db = Double.parseDouble(strParamVal);
						double gross_veh_weight_request = Double.parseDouble(propGenReq.getLstvecReg().getGrossVehWeight());
						
						//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: Applying Portal Rules : gross_veh_weight_db : "+gross_veh_weight_db);
						//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: Applying Portal Rules : gross_veh_weight_request : "+gross_veh_weight_request);
						
						if(gross_veh_weight_request > gross_veh_weight_db)
						{
							gvw = true;
						}
					}
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: Applying Portal Rules : gvw flag : "+gvw);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getVehicleRegNumber1()!=null && !propGenReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: Applying Portal Rules : propGenReq.getLstvecReg().getVehicleRegNumber1() : "+propGenReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, propGenReq.getLstvecReg().getVehicleRegNumber1(), "1098", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumCVQuote method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(sub_product && gvw && reg_state)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.COMMERCIAL_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Commercial);
			String errorDesc = null;
			
			if(propGenReq!=null && propGenReq.getLstAddonCover()!=null && propGenReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !propGenReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(propGenReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: getPremiumCVQuote method :: Exception Occurred",ae);
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		/*Code For Portal Rules Ends Here....................*/
		
		genProp = 	motorServ.getPremiumCVQuote(propGenReq);
		
		logger.info("Inside MotorController :: getPremiumCVQuote method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by getPremiumCVQuote service in seconds..>>"+watch.getTotalTimeSeconds());
		return genProp;
	}
	
	
	@RequestMapping(value="/getPremiumPVQuote/", method = RequestMethod.POST)
	@ResponseBody
	public GenerateQuoteMotorResponse getPremiumPVQuote(@RequestBody GenerateQuoteMotorRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{

		logger.info("Inside MotorController :: getPremiumPVQuote method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		GenerateQuoteMotorResponse genProp = new GenerateQuoteMotorResponse();
		
		/*Moratorium related changes starts here Issue ID - 1497*/
		boolean isMoratorium = false;
		HashMap<String, String> rtoGroupMap = new HashMap<String, String>();
		String rtoGroupCode = null;
		ObjectMapper objMap = new ObjectMapper();
		String straction = null;
		CalculatorMotorResponse calcMotres = new CalculatorMotorResponse();
		
		try
		{
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: calcMotReq.getRegisteredCityRTO() : "+propGenReq.getLstvecReg().getRegistrationAuthLoc());
			
			if(propGenReq.getLstvecReg().getRegistrationAuthLoc() != null && !(propGenReq.getLstvecReg().getRegistrationAuthLoc().equalsIgnoreCase("")))
				rtoGroupMap = (HashMap<String,String>) dbService.getRTOGroupCode("com.majesco.dcf.common.tagic.entity.RTOLocation", propGenReq.getLstvecReg().getRegistrationAuthLoc());
			
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: rtoGroupMap : "+objMap.writeValueAsString(rtoGroupMap));
			
			if(rtoGroupMap!=null && rtoGroupMap.size()>0)
			{
				rtoGroupCode = rtoGroupMap.get("stateCode");
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: rtoGroupCode : "+rtoGroupCode);
				
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: prodcd : "+propGenReq.getStrprodcd()+" ManufacturerCode : "+propGenReq.getLstvecReg().getManufacturerCode()+" ModelCode : "+propGenReq.getLstvecReg().getModelCode()+" ManufactureYear : "+propGenReq.getLstvecReg().getManufactureYear()+" ProducerCode : "+propGenReq.getProducerCode());
				
				straction = dbService.getMoratoriumChk(propGenReq.getStrprodcd(), propGenReq.getLstvecReg().getManufacturerCode(), propGenReq.getLstvecReg().getModelCode(), propGenReq.getLstvecReg().getManufactureYear(), propGenReq.getProducerCode(), rtoGroupCode , propGenReq.getLstvecReg().getFuelType()); // <2086> : 21-Sep-2017 : Vishal : Extra parameter sent for Checking with fuelType
				
				if(straction!=null && !straction.equals("") && (straction.equalsIgnoreCase("D") || straction.equalsIgnoreCase("R")))
				{
					isMoratorium = true;
				}
			}
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: getPremiumPVQuote method :: Exception Occured In Moratorium.....",ae);
		}
		
		if(isMoratorium)
		{
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag(CommonConstants.MORATORIUM_ERROR_MESSAGE);
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		/*Moratorium related changes ends here Issue ID - 1497*/	
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			if(propGenReq!=null)
			{
				boolean cover_variant = false;
				boolean reg_state = false;
				String stateCode = null;
				propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
				if(propGenReq.getLstRiskdet()!=null && propGenReq.getLstRiskdet().getPolicyCoverVariant()!=null && !propGenReq.getLstRiskdet().getPolicyCoverVariant().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: Applying Portal Rules : propGenReq.getLstRiskdet().getPolicyCoverVariant() : "+propGenReq.getLstRiskdet().getPolicyCoverVariant());
					
					if(propGenReq.getLstRiskdet().getPolicyCoverVariant().equalsIgnoreCase("2"))
					{
						cover_variant = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: Applying Portal Rules : cover_variant flag : "+cover_variant);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getVehicleRegNumber1()!=null && !propGenReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: Applying Portal Rules : propGenReq.getLstvecReg().getVehicleRegNumber1() : "+propGenReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, propGenReq.getLstvecReg().getVehicleRegNumber1(), "1099", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(cover_variant && reg_state)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.PRIVATE_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Private_Car);
			String errorDesc = null;
			
			if(propGenReq!=null && propGenReq.getLstAddonCover()!=null && propGenReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !propGenReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(propGenReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: getPremiumPVQuote method :: Exception Occurred",ae);
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		/*Code For Portal Rules Ends Here....................*/
		ObjectMapper objM=new ObjectMapper();
		genProp = 	motorServ.getPremiumPVQuote(propGenReq);
		//Start:16/03/2017:Defect_555:Changes done to re trigger get premium if basis of rating error comes for Campaign.
		//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: Checking For Error status");
		if(genProp!=null && genProp.getResultCode()!=null && genProp.getResultCode().equals(CommonConstants.FAILURE_STATUS)){
			List<ResponseError> responseErrorList=genProp.getResErr();
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: ENTERING FAILURE"+objM.writeValueAsString(genProp));	
			if(responseErrorList!=null && responseErrorList.size()>0){
				ResponseError responseError=(ResponseError)responseErrorList.get(0);
				if(responseError!=null && responseError.getErrorMMessag()!=null && responseError.getErrorMMessag().contains("Basis of rating")){
					propGenReq.getLstvecReg().setBasisofRating("GLM");
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumPVQuote method :: FAILURE BASIS RESET"+objM.writeValueAsString(propGenReq));
					genProp = 	motorServ.getPremiumPVQuote(propGenReq);
					//if(logger.isDebugEnabled())logger.debug("Error Response"+objM.writeValueAsString(responseError));
				}
			}
		}
		
		logger.info("Inside MotorController :: getPremiumPVQuote method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by getPremiumPVQuote service in seconds..>>"+watch.getTotalTimeSeconds());
		return genProp;
	
	}
	
	
	@RequestMapping(value="/getPremiumTWQuote/", method = RequestMethod.POST)
	@ResponseBody
	public GenerateQuoteMotorResponse getPremiumTWQuote(@RequestBody GenerateQuoteMotorRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: createProposalTWQuote method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		GenerateQuoteMotorResponse genProp = new GenerateQuoteMotorResponse();
		
		/*Moratorium related changes starts here Issue ID - 1497*/
		boolean isMoratorium = false;
		HashMap<String, String> rtoGroupMap = new HashMap<String, String>();
		String rtoGroupCode = null;
		ObjectMapper objMap = new ObjectMapper();
		String straction = null;
		CalculatorMotorResponse calcMotres = new CalculatorMotorResponse();
		
		try
		{
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTWQuote method :: calcMotReq.getRegisteredCityRTO() : "+propGenReq.getLstvecReg().getRegistrationAuthLoc());
			
			if(propGenReq.getLstvecReg().getRegistrationAuthLoc() != null && !(propGenReq.getLstvecReg().getRegistrationAuthLoc().equalsIgnoreCase("")))
				rtoGroupMap = (HashMap<String,String>) dbService.getRTOGroupCode("com.majesco.dcf.common.tagic.entity.RTOLocation", propGenReq.getLstvecReg().getRegistrationAuthLoc());
			
			//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTWQuote method :: rtoGroupMap : "+objMap.writeValueAsString(rtoGroupMap));
			
			if(rtoGroupMap!=null && rtoGroupMap.size()>0)
			{
				rtoGroupCode = rtoGroupMap.get("stateCode");
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTWQuote method :: rtoGroupCode : "+rtoGroupCode);
				
				//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTWQuote method :: prodcd : "+propGenReq.getStrprodcd()+" ManufacturerCode : "+propGenReq.getLstvecReg().getManufacturerCode()+" ModelCode : "+propGenReq.getLstvecReg().getModelCode()+" ManufactureYear : "+propGenReq.getLstvecReg().getManufactureYear()+" ProducerCode : "+propGenReq.getProducerCode());
				
				straction = dbService.getMoratoriumChk(propGenReq.getStrprodcd(), propGenReq.getLstvecReg().getManufacturerCode(), propGenReq.getLstvecReg().getModelCode(), propGenReq.getLstvecReg().getManufactureYear(), propGenReq.getProducerCode(), rtoGroupCode , propGenReq.getLstvecReg().getFuelType()); // <2086> : 21-Sep-2017 : Vishal : Extra parameter sent for Checking with fuelType
				
				if(straction!=null && !straction.equals("") && (straction.equalsIgnoreCase("D") || straction.equalsIgnoreCase("R")))
				{
					isMoratorium = true;
				}
			}
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: getPremiumTWQuote method :: Exception Occured In Moratorium.....",ae);
		}
		
		if(isMoratorium)
		{
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag(CommonConstants.MORATORIUM_ERROR_MESSAGE);
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		/*Moratorium related changes ends here Issue ID - 1497*/
		
		/*Code For Portal Rules Starts Here....................*/
		try
		{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			if(propGenReq!=null)
			{
				boolean cover_variant = false;
				boolean reg_state = false;
				String stateCode = null;
				propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
				if(propGenReq.getLstRiskdet()!=null && propGenReq.getLstRiskdet().getPolicyCoverVariant()!=null && !propGenReq.getLstRiskdet().getPolicyCoverVariant().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTWQuote method :: Applying Portal Rules : propGenReq.getLstRiskdet().getPolicyCoverVariant() : "+propGenReq.getLstRiskdet().getPolicyCoverVariant());
					
					if(propGenReq.getLstRiskdet().getPolicyCoverVariant().equalsIgnoreCase("2"))
					{
						cover_variant = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTWQuote method :: Applying Portal Rules : cover_variant flag : "+cover_variant);
				}
				
				if(propGenReq.getLstvecReg()!=null && propGenReq.getLstvecReg().getVehicleRegNumber1()!=null && !propGenReq.getLstvecReg().getVehicleRegNumber1().equals(""))
				{
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTWQuote method :: Applying Portal Rules : propGenReq.getLstvecReg().getVehicleRegNumber1() : "+propGenReq.getLstvecReg().getVehicleRegNumber1());
					
					stateCode = dbService.getCodeDesc(null, propGenReq.getLstvecReg().getVehicleRegNumber1(), "2000", "1");
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTWQuote method :: Applying Portal Rules : stateCode : "+stateCode);
					
					if(stateCode!=null && !stateCode.equals(""))
					{
						reg_state = true;
					}
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getPremiumTWQuote method :: Applying Portal Rules : reg_state flag : "+reg_state);
				}
				
				if(cover_variant && reg_state)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR00");
					errorRes.setErrorMMessag(CommonConstants.TWO_WHEELER_PORTAL_RULE_STRING);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Starts Here*/
			
			String maxTowCharge = dbService.getConfigParamVal(CommonConstants.Maximimum_Tow_Charge_Two_Wheeler);
			String errorDesc = null;
			
			if(propGenReq!=null && propGenReq.getLstAddonCover()!=null && propGenReq.getLstAddonCover().getAdditionalTowChargeAmount()!=null && !propGenReq.getLstAddonCover().getAdditionalTowChargeAmount().equals("") && maxTowCharge!=null && !maxTowCharge.equals(""))
			{
				int maxTowAmt = Integer.parseInt(maxTowCharge);
				int maxTowAmtReq = Integer.parseInt(propGenReq.getLstAddonCover().getAdditionalTowChargeAmount());
				
				if(maxTowAmtReq > maxTowAmt)
				{
					genProp.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorDesc = errorHandlerUtility.getErrorCodeByPropName(CommonConstants.ERRORT001);
					errorRes.setErrorCode(CommonConstants.ERRORT001);
					errorRes.setErrorMMessag(errorDesc==null?"":errorDesc);
					errorList.add(errorRes);
					genProp.setResErr(errorList);
					
					return genProp;
				}
			}
			
			/*Added For Maximum Tow Charge Limit Check Validation Ends Here*/
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorController :: getPremiumTWQuote method :: Exception Occurred",ae);
			genProp.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR00");
			errorRes.setErrorMMessag("System Failed to call service... !!!");
			errorList.add(errorRes);
			genProp.setResErr(errorList);
			
			return genProp;
		}
		/*Code For Portal Rules Ends Here....................*/
		
		ObjectMapper objM=new ObjectMapper();
		//if(logger.isDebugEnabled())logger.debug("MOTOR CONTROLLER :: getPremiumTWQuote :: Recieved Request JSON Object :: "+objM.writeValueAsString(propGenReq));
		
		genProp = 	motorServ.getPremiumTWQuote(propGenReq);
		
		logger.info("Inside MotorController :: getPremiumTWQuote method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by getPremiumTWQuote service in seconds..>>"+watch.getTotalTimeSeconds());
		return genProp;
	}
	
	
	@RequestMapping(value="/getPolicyDetailByPolicyNoPrvtCar/", method = RequestMethod.POST)
	@ResponseBody
	public ProductProposalDataPVResponse getPolicyDetailByPolicyNoPrvtCar(@RequestBody ProductProposalDataPVRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: getPolicyDetailByPolicyNoPrvtCar method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		
		
		propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		ProductProposalDataPVResponse genProp = 	motorServ.getPolicyDetailByPolicyNoPrvtCar(propGenReq);
		
		logger.info("Inside MotorController :: getPolicyDetailByPolicyNoPrvtCar method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by getPolicyDetailByPolicyNoPrvtCar service in seconds..>>"+watch.getTotalTimeSeconds());
		return genProp;
	}
	
	@RequestMapping(value="/getProductProposalDataPrvtCar/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> getProductProposalDataPrvtCar(@RequestBody ProductProposalDataPVRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: getProductProposalDataPrvtCar method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		AuthenticationRequest authReq=new AuthenticationRequest();
		
		AuthenticationResponse authResponse=null;
		QuotationSearchRequest quoteSearchReq=null;
		ProductProposalDataPVResponse genProp=null;
		propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		HashMap<String,String> hmParameters = new HashMap<String, String>();
		boolean isIIPProposal = false;	//RahulT <Prod 1235>
		HttpHeaders responseHeaders =  new HttpHeaders(); //RahulT <Prod 1235>
		Gson gson=new Gson();	//RahulT <Prod 1235>
		String result = ""; 	//RahulT <Prod 1235>
		boolean isQuotSearch = false;	//RahulT <SIT 1097>
		try{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			
			quoteSearchReq=new QuotationSearchRequest();
			authReq.setSource(smc_source);
			authReq.setMedium(smc_medium);
			authReq.setCampain(smc_campaign);
			authReq.setUserID(propGenReq.getUserID());
			authReq.setPassword(propGenReq.getPassword());
			
			//Start: RahulT| Added to get Proposal Number from Motor Quote
			if (propGenReq.getQuotaionNumber()!=null && !propGenReq.getQuotaionNumber().equals("")){
				isQuotSearch = true;	//RahulT <SIT 1097>
				hmParameters.put("quoteNo", propGenReq.getQuotaionNumber());
			if (propGenReq.getProducerCode()!=null && !propGenReq.getProducerCode().equals(""))
				hmParameters.put("producerCd", propGenReq.getProducerCode());
			String proposalNo = dbService.getMotorProposalFromQuote(hmParameters);
			//if(logger.isDebugEnabled())logger.debug("Proposal number extracted from dcf_motor_quot_dtl PRIVATE CAR--> "+proposalNo);
			//Start: RahulT <SIT 1614>| commented to get workflow id from proposal no based on swaraj mail 24 July 2017 18:37
			if (proposalNo == null || proposalNo.equals("")){
				JsonDBService _data = new JsonDBService();
				tagicCommonService.getProposalTaggedWithQuot(_data);
				proposalNo = _data.getProposalNo();
				//if(logger.isDebugEnabled())logger.debug("Proposal number returned by ESB PRIVATE CAR--> "+proposalNo);
			}
			//End: RahulT <SIT 1614>| commented to get workflow id from proposal no based on swaraj mail 24 July 2017 18:37
			
			propGenReq.setProposalNumber(proposalNo);
			}
			//End: RahulT| Added to get Proposal Number from Motor Quote
			
		
		if(propGenReq!=null && (propGenReq.getProposalNumber()==null || propGenReq.getProposalNumber().equals(CommonConstants.BLANK_STRING))){
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			//if(logger.isDebugEnabled())logger.debug("Proposal number not found in dcf_motor_quot_dtl table, trying to invoke GC service for retrieving proposal number");
			if (propGenReq.getAuthToken()!=null ){
				quoteSearchReq.setAuthToken(propGenReq.getAuthToken());
			}
			else{
				authResponse=authService.getAuthenticationToken(authReq);
				quoteSearchReq.setAuthToken(authResponse.getResultRes());
			}
			//End:RahulT<VAPT comments>| code added to set GC token into user object		
		
		quoteSearchReq.setQuoteNo(propGenReq.getQuotaionNumber());
		quoteSearchReq.setProductCode(CommonConstants.PRIVATE_CAR_PRODUCT_CODE);
		QuotationListResponse quoteList=tagicCommonService.searchQuoteByQuoteNo(quoteSearchReq);
		
		if(quoteList!=null && quoteList.getQuoteList()!=null && quoteList.getQuoteList().size()>0){
			QuotationSearchResponse quotationSearchResponse=quoteList.getQuoteList().get(0);
			
			if(quotationSearchResponse!=null && quotationSearchResponse.getProposalNo()!=null && !quotationSearchResponse.getProposalNo().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				propGenReq.setProposalNumber(quotationSearchResponse.getProposalNo());
				propGenReq.setQuotaionNumber(null);
			}
		}
		}
		//Start: RahulT <Prod 1235>| code added to block proposal transaction if generated from other than new channel portal
		//Start: RahulT <Internal>| commented to get workflow id from proposal no based on swaraj mail 24 July 2017 18:37
		
		/*if (propGenReq.getProposalNumber()!=null && !isQuotSearch){		//RahulT <SIT 1097>
			isIIPProposal = dbService.isIIPProposal(propGenReq.getProposalNumber());
			if (isIIPProposal)
				return new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);
		}*/
		
		//End: RahulT <Internal>| commented to get workflow id from proposal no based on swaraj mail 24 July 2017 18:37
		//End: RahulT <Prod 1235>| code added to block proposal transaction if generated from other than new channel portal
		
		genProp = 	motorServ.getProductProposalDataPrvtCar(propGenReq);
		
		result=gson.toJson(genProp);
		
		logger.info("Inside MotorController :: getProductProposalDataPrvtCar method :: Execution Completed Successfully");
		}catch(Exception ex){
			
            logger.error("Inside MotorController :: getProductProposalDataPrvtCar method ::Exception::",ex);
            genProp=new ProductProposalDataPVResponse();
            genProp.setResultCode("0");
            List<ResponseError> errorList=new ArrayList<ResponseError>();
            ResponseError errorRes=new ResponseError();
            errorRes.setErrorCode("ERR01");
            errorRes.setErrorMMessag("System Failed to call service... !!!");
            errorList.add(errorRes);
            genProp.setResErr(errorList);
		}
		watch.stop();
		logger.info("Time Taken by getProductProposalDataPrvtCar service in seconds..>>"+watch.getTotalTimeSeconds());
		return new ResponseEntity(result,responseHeaders,HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/getRenewalProposalPrvtCar/", method = RequestMethod.POST)
	@ResponseBody
	public ProposalGenerationPVResponse renewalProposalPrvtCar(@RequestBody ProposalGenerationPVRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: renewalProposalPrvtCar method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		
		propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		ProposalGenerationPVResponse genProp = 	motorServ.renewalProposalPrvtCar(propGenReq);
		
		logger.info("Inside MotorController :: renewalProposalPrvtCar method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by renewalProposalPrvtCar service in seconds..>>"+watch.getTotalTimeSeconds());	
		return genProp;
	}
	
	
	@RequestMapping(value="/getPolicyDetailByPolicyNoTwoWheeler/", method = RequestMethod.POST)
	@ResponseBody
	public ProductProposalDataTWResponse getPolicyDetailByPolicyNoTwoWheeler(@RequestBody ProductProposalDataTWRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: getPolicyDetailByPolicyNoTwoWheeler method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		
		propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		ProductProposalDataTWResponse genProp = 	motorServ.getPolicyDetailByPolicyNoTwoWheeler(propGenReq);
		
		logger.info("Inside MotorController :: getPolicyDetailByPolicyNoTwoWheeler method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by getPolicyDetailByPolicyNoTwoWheeler service in seconds..>>"+watch.getTotalTimeSeconds());
		return genProp;
	}
	
	
	@RequestMapping(value="/getProductProposalDataTwoWheeler/", method = RequestMethod.POST)
	@ResponseBody
	public ProductProposalDataTWResponse getProductProposalDataTwoWheeler(@RequestBody ProductProposalDataTWRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
       AuthenticationRequest authReq=new AuthenticationRequest();
       StopWatch watch = new StopWatch();
       watch.start();
		AuthenticationResponse authResponse=null;
		QuotationSearchRequest quoteSearchReq=null;
		ProductProposalDataTWResponse genProp=null;
		HashMap<String,String> hmParameters = new HashMap<String, String>();
		try{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object
			logger.info("Inside MotorController :: getProductProposalDataTwoWheeler method :: Execution Started");
			propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			
			propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
			
			quoteSearchReq=new QuotationSearchRequest();
			if(propGenReq.getAuthToken()==null || propGenReq.getAuthToken().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
			authReq.setSource(smc_source);
			authReq.setMedium(smc_medium);
			authReq.setCampain(smc_campaign);
			authReq.setUserID(propGenReq.getUserID());
			authReq.setPassword(propGenReq.getPassword());
			//Start:RahulT<VAPT comments>| code added to set GC token into user object
			//Start: RahulT| Added to get Proposal Number from Motor Quote
			if (propGenReq.getQuotaionNumber()!=null && !propGenReq.getQuotaionNumber().equals("")){
				hmParameters.put("quoteNo", propGenReq.getQuotaionNumber());
			if (propGenReq.getProducerCode()!=null && !propGenReq.getProducerCode().equals(""))
				hmParameters.put("producerCd", propGenReq.getProducerCode());
			String proposalNo = dbService.getMotorProposalFromQuote(hmParameters);
			//Start: RahulT <SIT 1614>| added to get proposal no from quotation no based on swaraj mail 24 July 2017 18:37
			if (proposalNo == null || proposalNo.equals("")){
				JsonDBService _data = new JsonDBService();
				tagicCommonService.getProposalTaggedWithQuot(_data);
				proposalNo = _data.getProposalNo();
				if(logger.isDebugEnabled())logger.debug("Proposal number returned by ESB two-wheeler--> "+proposalNo);
			}
			//End: RahulT <SIT 1614>| added to get proposal no from quotation no based on swaraj mail 24 July 2017 18:37
			
			//if(logger.isDebugEnabled())logger.debug("Proposal number extracted from dcf_motor_quot_dtl TWO-WHEELER --> "+proposalNo);
			propGenReq.setProposalNumber(proposalNo);
			}
			if (propGenReq.getAuthToken()!=null ){
				quoteSearchReq.setAuthToken(propGenReq.getAuthToken());
			}
			else{
				authResponse=authService.getAuthenticationToken(authReq);
				quoteSearchReq.setAuthToken(authResponse.getResultRes());
			}
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			}else{
				quoteSearchReq.setAuthToken(propGenReq.getAuthToken());
			}
		
		if(propGenReq!=null && (propGenReq.getProposalNumber()==null || propGenReq.getProposalNumber().equals(CommonConstants.BLANK_STRING))){
		quoteSearchReq.setQuoteNo(propGenReq.getQuotaionNumber());
		quoteSearchReq.setProductCode(CommonConstants.TWO_WHEELER_PRODUCT_CODE);
		QuotationListResponse quoteList=tagicCommonService.searchQuoteByQuoteNo(quoteSearchReq);
		
		if(quoteList!=null && quoteList.getQuoteList()!=null && quoteList.getQuoteList().size()>0){
			QuotationSearchResponse quotationSearchResponse=quoteList.getQuoteList().get(0);
			
			if(quotationSearchResponse!=null && quotationSearchResponse.getProposalNo()!=null && !quotationSearchResponse.getProposalNo().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				propGenReq.setProposalNumber(quotationSearchResponse.getProposalNo());
				propGenReq.setQuotaionNumber(null);
			}
		}
		}
		genProp = 	motorServ.getProductProposalDataTwoWheeler(propGenReq);
		
		logger.info("Inside MotorController :: getProductProposalDataTwoWheeler method :: Execution Completed Successfully");
		}catch(Exception ex){
			logger.error("Inside MotorController :: getProductProposalDataTwoWheeler method ::Exception::",ex);
			genProp=new ProductProposalDataTWResponse();
            genProp.setResultCode("0");
            List<ResponseError> errorList=new ArrayList<ResponseError>();
            ResponseError errorRes=new ResponseError();
            errorRes.setErrorCode("ERR01");
            errorRes.setErrorMMessag("System Failed to call service... !!!");
            errorList.add(errorRes);
            genProp.setResErr(errorList);
		}
		watch.stop();
		logger.info("Time Taken by getProductProposalDataTwoWheeler service in seconds..>>"+watch.getTotalTimeSeconds());
		return genProp;
	}
	
	
	@RequestMapping(value="/renewalProposalTwoWheeler/", method = RequestMethod.POST)
	@ResponseBody
	public ProposalGenerationTWResponse renewalProposalTwoWheeler(@RequestBody ProposalGenerationTWRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: renewalProposalTwoWheeler method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		ProposalGenerationTWResponse genProp = 	motorServ.renewalProposalTwoWheeler(propGenReq);
		
		logger.info("Inside MotorController :: renewalProposalTwoWheeler method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by renewalProposalTwoWheeler service in seconds..>>"+watch.getTotalTimeSeconds());
		return genProp;
	}
	
	@RequestMapping(value="/getPolicyDetailByPolicyNoComm/", method = RequestMethod.POST)
	@ResponseBody
	public ProductProposalDataCVResponse getPolicyDetailByPolicyNoComm(@RequestBody ProductProposalDataCVRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: getPolicyDetailByPolicyNoComm method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		ProductProposalDataCVResponse genProp = 	motorServ.getPolicyDetailByPolicyNoComm(propGenReq);
		
		logger.info("Inside MotorController :: getPolicyDetailByPolicyNoComm method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by getPolicyDetailByPolicyNoComm service in seconds..>>"+watch.getTotalTimeSeconds());	
		return genProp;
	}
	
	
	@RequestMapping(value="/getProductProposalDataComm/", method = RequestMethod.POST)
	@ResponseBody
	public ProductProposalDataCVResponse getProductProposalDataComm(@RequestBody ProductProposalDataCVRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		StopWatch watch = new StopWatch();
		watch.start();
		AuthenticationRequest authReq=new AuthenticationRequest();
		propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		AuthenticationResponse authResponse=null;
		QuotationSearchRequest quoteSearchReq=null;
		ProductProposalDataCVResponse genProp=null;
		HashMap<String,String> hmParameters = new HashMap<String, String>();
		try{
		logger.info("Inside MotorController :: getProductProposalDataComm method :: Execution Started");
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		
		quoteSearchReq=new QuotationSearchRequest();
		if(propGenReq.getAuthToken()==null || propGenReq.getAuthToken().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
		authReq.setSource(smc_source);
		authReq.setMedium(smc_medium);
		authReq.setCampain(smc_campaign);	
		authReq.setUserID(propGenReq.getUserID());
		authReq.setPassword(propGenReq.getPassword());
		//Start:RahulT<VAPT comments>| code added to set GC token into user object
		//Start: RahulT| Added to get Proposal Number from Motor Quote
		if (propGenReq.getQuotaionNumber()!=null && !propGenReq.getQuotaionNumber().equals("")){
			hmParameters.put("quoteNo", propGenReq.getQuotaionNumber());
		if (propGenReq.getProducerCode()!=null && !propGenReq.getProducerCode().equals(""))
			hmParameters.put("producerCd", propGenReq.getProducerCode());
		String proposalNo = dbService.getMotorProposalFromQuote(hmParameters);
		//if(logger.isDebugEnabled())logger.debug("Proposal number extracted from dcf_motor_quot_dtl FOR COMMERCIAL VEHICLE --> "+proposalNo);
		//Start: RahulT <SIT 1614>| added to get proposal no from quotation no based on swaraj mail 24 July 2017 18:37
		if (proposalNo == null || proposalNo.equals("")){
			JsonDBService _data = new JsonDBService();
			tagicCommonService.getProposalTaggedWithQuot(_data);
			proposalNo = _data.getProposalNo();
			//if(logger.isDebugEnabled())logger.debug("Proposal number returned by ESB COMMERCIAL VEHICLE--> "+proposalNo);
		}
		//End: RahulT <SIT 1614>| added to get proposal no from quotation no based on swaraj mail 24 July 2017 18:37
		propGenReq.setProposalNumber(proposalNo);
		}
		if (propGenReq.getAuthToken()!=null ){
			quoteSearchReq.setAuthToken(propGenReq.getAuthToken());
		}
		else{
			authResponse=authService.getAuthenticationToken(authReq);
			quoteSearchReq.setAuthToken(authResponse.getResultRes());
		}
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		
		}else{
			quoteSearchReq.setAuthToken(propGenReq.getAuthToken());
		}
	if(propGenReq!=null && (propGenReq.getProposalNumber()==null || propGenReq.getProposalNumber().equals(CommonConstants.BLANK_STRING))){
	quoteSearchReq.setQuoteNo(propGenReq.getQuotaionNumber());
	quoteSearchReq.setProductCode(CommonConstants.COMMERCIAL_PRODUCT_CODE);
	QuotationListResponse quoteList=tagicCommonService.searchQuoteByQuoteNo(quoteSearchReq);
	
	if(quoteList!=null && quoteList.getQuoteList()!=null && quoteList.getQuoteList().size()>0){
		QuotationSearchResponse quotationSearchResponse=quoteList.getQuoteList().get(0);
		
		if(quotationSearchResponse!=null && quotationSearchResponse.getProposalNo()!=null && !quotationSearchResponse.getProposalNo().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
			propGenReq.setProposalNumber(quotationSearchResponse.getProposalNo());
			propGenReq.setQuotaionNumber(null);
		}
	}
	}
		
		 genProp = 	motorServ.getProductProposalDataComm(propGenReq);
		
		logger.info("Inside MotorController :: getProductProposalDataComm method :: Execution Completed Successfully");
		}catch(Exception ex){
			logger.error("Inside MotorController :: getProductProposalDataComm method ::Exception::",ex);
			genProp=new ProductProposalDataCVResponse();
            genProp.setResultCode("0");
            List<ResponseError> errorList=new ArrayList<ResponseError>();
            ResponseError errorRes=new ResponseError();
            errorRes.setErrorCode("ERR01");
            errorRes.setErrorMMessag("System Failed to call service... !!!");
            errorList.add(errorRes);
            genProp.setResErr(errorList);
		}
		watch.stop();
		logger.info("Time Taken by getProductProposalDataComm service in seconds..>>"+watch.getTotalTimeSeconds());
		return genProp;
	}
	
	
	@RequestMapping(value="/renewalProposalComm/", method = RequestMethod.POST)
	@ResponseBody
	public ProposalGenerationCVResponse renewalProposalComm(@RequestBody ProposalGenerationCVRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: renewalProposalComm method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		propGenReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		ProposalGenerationCVResponse genProp = 	motorServ.renewalProposalComm(propGenReq);
		
		logger.info("Inside MotorController :: renewalProposalComm method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by renewalProposalComm service in seconds..>>"+watch.getTotalTimeSeconds());	
		return genProp;
	}
	

	private InspectionResponse saveInspection(InspectionRequest inspectionRequest){
		InspectionResponse response=null;
		StopWatch watch = new StopWatch();
		watch.start();
		try{
			logger.info("Inside MotorController :: saveInspection method :: Execution Started");
			
		response = inspectionCoverNoteService.triggerPreInspection(inspectionRequest);
		logger.info("Inside MotorController :: saveInspection method :: Execution Completed Successfully");
		}catch(Exception ex){
			logger.error("Inside MotorController :: saveInspection method :: Error ", ex);
		}
		watch.stop();
		logger.info("Time Taken by saveInspection service in seconds..>>"+watch.getTotalTimeSeconds());
		return response;
	}
	
	//Start: KetanM <SIT 3270>| service exposed for getAddOnPlanBasedOnProducer on 18 Jan 2018
	@RequestMapping(value="/addOnPlanBasedOnProducer/", method = RequestMethod.POST)
	@ResponseBody
	public AddOnPlanProducerResponse getAddOnPlanBasedOnProducer(@RequestBody AddOnPlanProducerRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: getAddOnPlanBasedOnProducer method :: Execution Started");
		StopWatch watch = new StopWatch();
		watch.start();
		
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		propGenReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+propGenReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		
		AddOnPlanProducerResponse genProp = motorServ.getAddOnPlanBasedOnProducer(propGenReq);
		
		logger.info("Inside MotorController :: getAddOnPlanBasedOnProducer method :: Execution Completed Successfully");
		watch.stop();
		logger.info("Time Taken by getAddOnPlanBasedOnProducer service in seconds..>>"+watch.getTotalTimeSeconds());	
		return genProp;
	}
	//End: KetanM <SIT 3270>| service exposed for getAddOnPlanBasedOnProducer on 18 Jan 2018
	 
	
	//Start: Parvind/Akshay/Anil |restrict the selection of make model variant based on Moratorium master setup CR :: 3530
	
	@RequestMapping(value = "/getMoratoriumCheck/", method = RequestMethod.POST)
	@ResponseBody
	public GenerateMoratoriumResponse getMoratorium(@RequestBody GenerateMoratoriumRequest propGenReq,HttpServletRequest httpServletRequest) throws Exception {
		String straction = null;
		String rtoGroupCode = null;
		boolean isMoratorium = false;
		HashMap<String, String> rtoGroupMap = new HashMap<String, String>();
		ObjectMapper objMap = new ObjectMapper();
		GenerateMoratoriumResponse genProp = new GenerateMoratoriumResponse();
		try {
			  // if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getMoratorium method :: calcMotReq.getRegisteredCityRTO() : "+propGenReq.getLstvecReg().getRegistrationAuthLoc());
			
			   if(propGenReq.getLstvecReg().getRegistrationAuthLoc() != null && !(propGenReq.getLstvecReg().getRegistrationAuthLoc().equalsIgnoreCase("")))
				rtoGroupMap = (HashMap<String,String>) dbService.getRTOGroupCode("com.majesco.dcf.common.tagic.entity.RTOLocation", propGenReq.getLstvecReg().getRegistrationAuthLoc());
			
		     //  if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getMoratorium method :: rtoGroupMap : "+objMap.writeValueAsString(rtoGroupMap));
			
			   if(rtoGroupMap!=null && rtoGroupMap.size()>0)
			   {
					rtoGroupCode = rtoGroupMap.get("stateCode");
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getMoratorium method :: rtoGroupCode : "+rtoGroupCode);
					
					//if(logger.isDebugEnabled())logger.debug("Inside MotorController :: getMoratorium method :: prodcd : "+propGenReq.getStrprodcd()+" ManufacturerCode : "+propGenReq.getLstvecReg().getManufacturerCode()+" ModelCode : "+propGenReq.getLstvecReg().getModelCode()+" ManufactureYear : "+propGenReq.getLstvecReg().getManufactureYear()+" ProducerCode : "+propGenReq.getProducerCode());
					
					straction = dbService.getMoratoriumChk(propGenReq.getStrprodcd(), propGenReq.getLstvecReg().getManufacturerCode(), propGenReq.getLstvecReg().getModelCode(), propGenReq.getLstvecReg().getManufactureYear(), propGenReq.getProducerCode(), rtoGroupCode , propGenReq.getLstvecReg().getFuelType()); 
					
					if(straction!=null && !straction.equals("") && (straction.equalsIgnoreCase("D") || straction.equalsIgnoreCase("R")))
					{
						isMoratorium = true;
					}
			   }
			
		} catch (Exception ae) {
			logger.error(
					"Inside MotorController :: getMoratorium method :: Exception Occured In Moratorium.....",
					ae);
		}

		if (isMoratorium) {
			genProp.setResultCode("0");
			genProp.setErrmessage(CommonConstants.MORATORIUM_ERROR_MESSAGE_1);
			genProp.setStraction(straction==null?"":straction);
			logger.info("Result Code : "+genProp.getResultCode()+"Error Message :"+genProp.getErrmessage());
			logger.info(" #### MORATORIUM Vehicle ####");
		}
		else
		{
			genProp.setResultCode("1");						
			genProp.setErrmessage("");
			genProp.setStraction(CommonConstants.BLANK_STRING);
			logger.info("Result Code : "+genProp.getResultCode()+"Error Message :"+genProp.getErrmessage());
			logger.info(" #### NON MORATORIUM Vehicle ####");
		}
		return genProp;
	}
	
	//End: Parvind/Akshay/Anil |restrict the selection of make model variant based on Moratorium master setup CR :: 3530
	
}

package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DealerMasterRequest extends UserObject{
	
	private BigDecimal nofficecd;

	public BigDecimal getNofficecd() {
		return nofficecd;
	}

	public void setNofficecd(BigDecimal nofficecd) {
		this.nofficecd = nofficecd;
	}
	
	
	
}

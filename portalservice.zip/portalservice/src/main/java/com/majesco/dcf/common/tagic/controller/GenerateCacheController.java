package com.majesco.dcf.common.tagic.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.majesco.dcf.common.tagic.json.AccFinancierBranchRequest;
import com.majesco.dcf.common.tagic.json.AnnouncementDetailsResponse;
import com.majesco.dcf.common.tagic.json.CovernoteOtherReasonRequest;
import com.majesco.dcf.common.tagic.json.CovernoteOtherReasonResponse;
import com.majesco.dcf.common.tagic.json.DealerMasterRequest;
import com.majesco.dcf.common.tagic.json.DealerMasterResponse;
import com.majesco.dcf.common.tagic.json.DocListRequest;
import com.majesco.dcf.common.tagic.json.DocListResponse;
import com.majesco.dcf.common.tagic.json.DocumentMasterRequest;
import com.majesco.dcf.common.tagic.json.DocumentMasterResponse;
import com.majesco.dcf.common.tagic.json.FieldUserRequest;
import com.majesco.dcf.common.tagic.json.FieldUserResponse;
import com.majesco.dcf.common.tagic.json.GarageRadiusRequest;
import com.majesco.dcf.common.tagic.json.GarageRadiusResponse;
import com.majesco.dcf.common.tagic.json.IDVRelaxationRequest;
import com.majesco.dcf.common.tagic.json.IDVRelaxationResponse;
import com.majesco.dcf.common.tagic.json.IntermediaryOfficeCodeServiceRequest;
import com.majesco.dcf.common.tagic.json.IntermediaryOfficeCodeServiceResponse;
import com.majesco.dcf.common.tagic.json.ModelRequest;
import com.majesco.dcf.common.tagic.json.ModelResponse;
import com.majesco.dcf.common.tagic.json.OfficeMasterRequest;
import com.majesco.dcf.common.tagic.json.OfficeMasterResponse;
import com.majesco.dcf.common.tagic.json.PinCodeRequest;
import com.majesco.dcf.common.tagic.json.PinCodeResponse;
import com.majesco.dcf.common.tagic.json.PreInspectionDetailsRequest;
import com.majesco.dcf.common.tagic.json.PreInspectionDetailsResponse;
import com.majesco.dcf.common.tagic.json.PrevInsurerRequest;
import com.majesco.dcf.common.tagic.json.ProdSupportContactServiceRequest;
import com.majesco.dcf.common.tagic.json.ProdSupportContactServiceResponse;
import com.majesco.dcf.common.tagic.json.RTOLocationRequest;
import com.majesco.dcf.common.tagic.json.RTOLocationResponse;
import com.majesco.dcf.common.tagic.json.SpMasterRequest;
import com.majesco.dcf.common.tagic.json.SpMasterResponse;
import com.majesco.dcf.common.tagic.json.SubCategoryRequest;
import com.majesco.dcf.common.tagic.json.SubCategoryResponse;
import com.majesco.dcf.common.tagic.json.VehicleAddOnRequest;
import com.majesco.dcf.common.tagic.json.VehicleAddOnResponse;
import com.majesco.dcf.common.tagic.json.VehicleIdvRequest;
import com.majesco.dcf.common.tagic.json.VehicleIdvResponse;
import com.majesco.dcf.common.tagic.json.VehicleVariantRequest;
import com.majesco.dcf.common.tagic.json.VehicleVariantResponse;
import com.majesco.dcf.common.tagic.service.AccFinancierBranchService;
import com.majesco.dcf.common.tagic.service.AnnouncementDetailsService;
import com.majesco.dcf.common.tagic.service.CoverNoteServices;
import com.majesco.dcf.common.tagic.service.DealerMasterService;
import com.majesco.dcf.common.tagic.service.DocListService;
import com.majesco.dcf.common.tagic.service.DocumentMasterService;
import com.majesco.dcf.common.tagic.service.FieldUserService;
import com.majesco.dcf.common.tagic.service.GarageRadiusService;
import com.majesco.dcf.common.tagic.service.GenerateCacheService;
import com.majesco.dcf.common.tagic.service.IDVRelaxationService;
import com.majesco.dcf.common.tagic.service.IntermediaryOfficeCodeService;
import com.majesco.dcf.common.tagic.service.ModelService;
import com.majesco.dcf.common.tagic.service.OfficeMasterService;
import com.majesco.dcf.common.tagic.service.PinCodeService;
import com.majesco.dcf.common.tagic.service.PreInspectionAgencyDetailsService;
import com.majesco.dcf.common.tagic.service.PrevInsurerService;
import com.majesco.dcf.common.tagic.service.ProdSupportContactService;
import com.majesco.dcf.common.tagic.service.RTOLocationService;
import com.majesco.dcf.common.tagic.service.SpMasterService;
import com.majesco.dcf.common.tagic.service.SubCategoryService;
import com.majesco.dcf.common.tagic.service.VehicleAddOnService;
import com.majesco.dcf.common.tagic.service.VehicleIdvService;
import com.majesco.dcf.common.tagic.service.VehicleVariantService;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.usermgmt.json.SecurityQuestionResponse;

@Controller
@RequestMapping(value="/GenerateCache")
public class GenerateCacheController {

	@Autowired
GenerateCacheService genCache;	
	
	@Autowired
	VehicleVariantService varserv;
	
	@Autowired
	PinCodeService pinserv;
	
	@Autowired
	ModelService modelserv;
	
	@Autowired
	DocumentMasterService docserv;
	
	@Autowired
	VehicleIdvService idvserv;
	
	@Autowired
	VehicleAddOnService addonserv;
	
	@Autowired
	RTOLocationService rtolocserv;
	
	@Autowired
	DealerMasterService dealerserv;
	
	@Autowired
	AccFinancierBranchService accfinserv;
	
	@Autowired
	FieldUserService fieldusrserv;
	
	@Autowired
	OfficeMasterService ofcmastserv;
	
	@Autowired
	PrevInsurerService previnsurerserv;
	
	@Autowired
	SubCategoryService subcatserv;
	
	@Autowired
	DocListService doclstserv;
	
	@Autowired
	GarageRadiusService garageradserv;
	
	@Autowired
	IntermediaryOfficeCodeService interOffcCdServ;
	
	@Autowired
	PreInspectionAgencyDetailsService preInspect;
	
	@Autowired
	CoverNoteServices coverNoreServ;
	
	/*Added For Issue ID 1864*/
	@Autowired
	ProdSupportContactService prodSupportService;
	
	/*Added For Issue ID 1899*/
	@Autowired
	IDVRelaxationService idvRelaxationService;
	
	/*Added For Issue ID 2018*/
	@Autowired
	AnnouncementDetailsService announcementDtlsServ;
	
	/*Added For Issue ID 3483*/
	@Autowired
	SpMasterService spmastserv;
	
	final static Logger logger=Logger.getLogger(GenerateCacheController.class);
	private Gson gson=new Gson();
	
	@RequestMapping(value = "/getmaster",  method = RequestMethod.GET)
	@ResponseBody	
	public String getMasterData(HttpServletRequest httpServletRequest)  throws ReflectiveOperationException{
		
		/*if(logger.isDebugEnabled()){
			logger.debug("In TabServiceController.getMasterData Method");
		}*/
		
		logger.info("Inside GenerateCacheController :: getMasterData method :: Execution Started");
		
		JSONObject masterJSON =	genCache.getMasterData();
		
		logger.info("Inside GenerateCacheController :: getMasterData method :: Execution Completed Successfully");

		//httpServletRequest.get
		
		/*if(logger.isDebugEnabled()){
			logger.debug("Out TabServiceController.getMasterData Method");
		}*/
			//System.out.println("xxxxxxx"+masterJSON.toString());			
		return masterJSON.toString();	
}
	
	@RequestMapping(value = "/getbranch",  method = RequestMethod.GET)
	@ResponseBody	
	public String getBranchMaster(HttpServletRequest httpServletRequest)  throws ReflectiveOperationException{
		
		/*if(logger.isDebugEnabled()){
			logger.debug("In TabServiceController.getBranchMaster Method");
		}*/
		
		logger.info("Inside GenerateCacheController :: getBranchMaster method :: Execution Started");
		
		JSONObject masterJSON =	genCache.getBranchMaster();
		
		logger.info("Inside GenerateCacheController :: getBranchMaster method :: Execution Completed Successfully");

		/*if(logger.isDebugEnabled()){
			logger.debug("Out TabServiceController.getBranchMaster Method");
		}*/
			//System.out.println("xxxxxxx"+masterJSON.toString());			
		return masterJSON.toString();
	
	
}
	
	
	
	@RequestMapping(value = "/getSchemaData",  method = RequestMethod.GET)
	@ResponseBody	
	public String getSchema(HttpServletRequest httpServletRequest)  throws ReflectiveOperationException{
		
		/*if(logger.isDebugEnabled()){
			logger.debug("In TabServiceController.getBranchMaster Method");
		}*/
		
		logger.info("Inside GenerateCacheController :: getSchema method :: Execution Started");
		
		JSONObject masterJSON =	genCache.getSchema();
		
		logger.info("Inside GenerateCacheController :: getSchema method :: Execution Completed Successfully");

		/*if(logger.isDebugEnabled()){
			logger.debug("Out TabServiceController.getBranchMaster Method");
		}*/
			//System.out.println("xxxxxxx"+masterJSON.toString());			
		return masterJSON.toString();
	
	
}
	
	
    @RequestMapping(value = "/getproductmaster/{arg}",  method = RequestMethod.GET)
@ResponseBody 
public String getProductMaster(HttpServletRequest httpServletRequest,@PathVariable String arg)  throws ReflectiveOperationException{
  
  /*if(logger.isDebugEnabled()){
         logger.debug("In TabServiceController.getProductMaster Method");
  }*/
  
  logger.info("Inside GenerateCacheController :: getProductMaster method :: Execution Started");
  
  JSONObject productJSON =   genCache.getProductMaster(arg);
  
  logger.info("Inside GenerateCacheController :: getProductMaster method :: Execution Completed Successfully");

  //httpServletRequest.get
  
  /*if(logger.isDebugEnabled()){
         logger.debug("Out TabServiceController.getProductMaster Method");
  }*/
         //System.out.println("xxxxxxx"+productJSON.toString());               
  return productJSON.toString();


}


@RequestMapping(value = "/getcountrymaster",  method = RequestMethod.GET)
@ResponseBody 
public String getCountryMaster(HttpServletRequest httpServletRequest)  throws ReflectiveOperationException{
  
  /*if(logger.isDebugEnabled()){
         logger.debug("In TabServiceController.getCountryMaster Method");
  }*/
  
  logger.info("Inside GenerateCacheController :: getCountryMaster method :: Execution Started");
  
  JSONObject productJSON =   genCache.getCountryMaster();
  
  logger.info("Inside GenerateCacheController :: getCountryMaster method :: Execution Completed Successfully");

  //httpServletRequest.get
  
 /* if(logger.isDebugEnabled()){
         logger.debug("Out TabServiceController.getProductMaster Method");
  }*/
         //System.out.println("xxxxxxx"+masterJSON.toString());               
  return productJSON.toString();



}


@RequestMapping(value = "/getstatemaster/{arg}",  method = RequestMethod.GET)
@ResponseBody 
public String getStateMaster(HttpServletRequest httpServletRequest,@PathVariable String arg)  throws ReflectiveOperationException{
       
      /* if(logger.isDebugEnabled()){
              logger.debug("In TabServiceController.getCountryMaster Method");
       }*/
       
       logger.info("Inside GenerateCacheController :: getStateMaster method :: Execution Started");
       
       JSONObject productJSON =   genCache.getStateMaster(arg);
       
       logger.info("Inside GenerateCacheController :: getStateMaster method :: Execution Completed Successfully");

       //httpServletRequest.get
       
      /* if(logger.isDebugEnabled()){
              logger.debug("Out TabServiceController.getProductMaster Method");
       }*/
              //System.out.println("xxxxxxx"+masterJSON.toString());               
       return productJSON.toString();


}

	
	
@RequestMapping(value = "/getmaster/{arg}",  method = RequestMethod.GET)
@ResponseBody 
public String getMaster(HttpServletRequest httpServletRequest,@PathVariable String arg)  throws ReflectiveOperationException{
       
      /* if(logger.isDebugEnabled()){
              logger.debug("In TabServiceController.getMaster Method");
       }*/
       
       logger.info("Inside GenerateCacheController :: getMaster method :: Execution Started");
       
       JSONObject masterJSON =    genCache.getMaster(arg);
       
       logger.info("Inside GenerateCacheController :: getMaster method :: Execution Completed Successfully");

       //httpServletRequest.get
       
       /*if(logger.isDebugEnabled()){
              logger.debug("Out TabServiceController.getMaster Method");
       }*/
              //System.out.println("xxxxxxx"+masterJSON.toString());               
       return masterJSON.toString();


}
	


@RequestMapping(value = "/getcitymaster/{stid}/{type}/{parent}",  method = RequestMethod.GET)
@ResponseBody 
public String getCityMaster(HttpServletRequest httpServletRequest,@PathVariable String stid,@PathVariable String type,@PathVariable String parent)  throws ReflectiveOperationException{
       
      /* if(logger.isDebugEnabled()){
              logger.debug("In TabServiceController.getCityMaster Method");
       }*/
       
       logger.info("Inside GenerateCacheController :: getCityMaster method :: Execution Started");
       
       JSONObject masterJSON =    genCache.getCityMaster(stid,type,parent);
       
       logger.info("Inside GenerateCacheController :: getCityMaster method :: Execution Completed Successfully");

       //httpServletRequest.get
       
       /*if(logger.isDebugEnabled()){
              logger.debug("Out TabServiceController.getMaster Method");
       }*/
              //System.out.println("xxxxxxx"+masterJSON.toString());               
       return masterJSON.toString();


}

@RequestMapping(value = "/getmanufactmast/{arg}",  method = RequestMethod.GET)
@ResponseBody 
public String getManuFactMaster(HttpServletRequest httpServletRequest, @PathVariable String arg)  throws ReflectiveOperationException{
       
      /* if(logger.isDebugEnabled()){
              logger.debug("In TabServiceController.getManuFactMaster Method");
       }*/
       
       logger.info("Inside GenerateCacheController :: getManuFactMaster method :: Execution Started");
       
       JSONObject masterJSON =    genCache.getManuFactMaster(arg);

       logger.info("Inside GenerateCacheController :: getManuFactMaster method :: Execution Completed Successfully");
       
       /*if(logger.isDebugEnabled()){
              logger.debug("Out TabServiceController.getManuFactMaster Method");
       }*/
              //System.out.println("xxxxxxx"+masterJSON.toString());               
       return masterJSON.toString();


}

	/*@RequestMapping(value = "/getmodelinfo/{arg}",  method = RequestMethod.GET)
	@ResponseBody 
	public String getModelInfo(HttpServletRequest httpServletRequest,@PathVariable String arg)  throws ReflectiveOperationException{
	       
	       if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getModelInfo Method");
	       }
	       
	       logger.info("Inside GenerateCacheController :: getModelInfo method :: Execution Started");
	       
	       JSONObject masterJSON =    genCache.getModelInfo(arg);
	       
	       logger.info("Inside GenerateCacheController :: getModelInfo method :: Execution Completed Successfully");
	
	       //httpServletRequest.get
	       
	       if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getModelInfo Method");
	       }
	              //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON.toString();
	
	
	}*/
	
	@RequestMapping(value = "/getmodelinfo/", method = RequestMethod.POST)
	@ResponseBody 
	public ModelResponse getModelInfo(@RequestBody ModelRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       
	       logger.info("Inside GenerateCacheController :: getModelInfo method :: Execution Started");
	       
	       ModelResponse masterJSON = modelserv.getModelInfo(quickReq);
	
	       logger.info("Inside GenerateCacheController :: getModelInfo method :: Execution Completed Successfully");
	                    
	       /*if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getModelInfo Method");
	       }*/
	              //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON;
	
	
	}

/*@RequestMapping(value = "/getvarinfo/{arg}",  method = RequestMethod.GET)
@ResponseBody 
public String getVarInfo(HttpServletRequest httpServletRequest,@PathVariable String arg)  throws ReflectiveOperationException{
       
       if(logger.isDebugEnabled()){
              logger.debug("In TabServiceController.getVarInfo Method");
       }
       
       logger.info("Inside GenerateCacheController :: getVarInfo method :: Execution Started");
       
       JSONObject masterJSON =    genCache.getVarInfo(arg);
       
       logger.info("Inside GenerateCacheController :: getVarInfo method :: Execution Completed Successfully");

       //httpServletRequest.get
       
       if(logger.isDebugEnabled()){
              logger.debug("Out TabServiceController.getVarInfo Method");
       }
              //System.out.println("xxxxxxx"+masterJSON.toString());               
       return masterJSON.toString();


}*/

	@RequestMapping(value="/getvariantinfo/", method = RequestMethod.POST)
	@ResponseBody	
	public VehicleVariantResponse FetchVariantInfo(@RequestBody VehicleVariantRequest quickReq,HttpServletRequest httpServletRequest) throws Exception
	{	
		logger.info("Inside GenerateCacheController :: FetchVariantInfo method :: Execution Started");	 								
		
		VehicleVariantResponse result = varserv.FetchVariantInfo(quickReq);
		
		logger.info("Inside GenerateCacheController :: FetchVariantInfo method :: Execution Completed Successfully");
					
		return result;
	}

	@RequestMapping(value = "/getvehicleclass/{arg}",  method = RequestMethod.GET)
	@ResponseBody 
	public String getVehicleClass(HttpServletRequest httpServletRequest,@PathVariable String arg)  throws ReflectiveOperationException{
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getVehicleClass Method");
	       }*/
	       
	       logger.info("Inside GenerateCacheController :: getVehicleClass method :: Execution Started");
	       
	       JSONObject masterJSON =    genCache.getVehicleClass(arg);
	
	       logger.info("Inside GenerateCacheController :: getVehicleClass method :: Execution Completed Successfully");
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getVehicleClass Method");
	       }*/
	              //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON.toString();
	
	
	}


@RequestMapping(value = "/getvehiclesubclass/{arg}",  method = RequestMethod.GET)
@ResponseBody 
public String getVehicleSubClass(HttpServletRequest httpServletRequest,@PathVariable String arg)  throws ReflectiveOperationException{
       
       /*if(logger.isDebugEnabled()){
              logger.debug("In TabServiceController.getVehicleSubClass Method");
       }*/
       
       logger.info("Inside GenerateCacheController :: getVehicleSubClass method :: Execution Started");
       
       JSONObject masterJSON =    genCache.getVehicleSubClass(arg);

       logger.info("Inside GenerateCacheController :: getVehicleSubClass method :: Execution Completed Successfully");
       
       /*if(logger.isDebugEnabled()){
              logger.debug("Out TabServiceController.getVehicleSubClass Method");
       }*/
              //System.out.println("xxxxxxx"+masterJSON.toString());               
       return masterJSON.toString();


}


	@RequestMapping(value = "/getrtolocation",  method = RequestMethod.GET)
	@ResponseBody 
	public String getRTOLocation(HttpServletRequest httpServletRequest)  throws ReflectiveOperationException{
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getRTOLocation Method");
	       }*/
	       
	       logger.info("Inside GenerateCacheController :: getRTOLocation method :: Execution Started");
	       
	       JSONObject masterJSON =    genCache.getRTOLocation();
	
	       logger.info("Inside GenerateCacheController :: getRTOLocation method :: Execution Completed Successfully");
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getRTOLocation Method");
	       }*/
	              //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON.toString();
	
	
	}


	@RequestMapping(value = "/getpincodemast/", method = RequestMethod.POST)
	@ResponseBody 
	public PinCodeResponse getPinCodeMast(@RequestBody PinCodeRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       
	       logger.info("Inside GenerateCacheController :: getPinCodeMast method :: Execution Started");
	       
	       PinCodeResponse masterJSON =    pinserv.FetchPinCodeInfo(quickReq);
	
	       logger.info("Inside GenerateCacheController :: getPinCodeMast method :: Execution Completed Successfully");
	                    
	       return masterJSON;
	
	}

	@RequestMapping(value = "/getdocumentmast/", method = RequestMethod.POST)
	@ResponseBody 
	public DocumentMasterResponse getDocumentMast(@RequestBody DocumentMasterRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getDocumentMast method :: Execution Started");
	       
	       DocumentMasterResponse masterJSON = docserv.FetchDocInfo(quickReq);
	
	       logger.info("Inside GenerateCacheController :: getDocumentMast method :: Execution Completed Successfully");
	                    
	       return masterJSON;
	}

	
	@RequestMapping(value = "/getsecurityquest",  method = RequestMethod.GET)
	@ResponseBody 
	public String getSecurityQuestion(HttpServletRequest httpServletRequest)  throws ReflectiveOperationException{
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getSecurityQuestion Method");
	       }*/
	       
	       logger.info("Inside GenerateCacheController :: getSecurityQuestion method :: Execution Started");
	       
	       JSONObject masterJSON = genCache.getSecurityQuestion();

	       logger.info("Inside GenerateCacheController :: getSecurityQuestion method :: Execution Completed Successfully");
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getSecurityQuestion Method");
	       }*/
	              //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON.toString();
	}
	
	@RequestMapping(value = "/getsubcategory/",  method = RequestMethod.POST)
	@ResponseBody 
	public SubCategoryResponse getSubCategory(@RequestBody SubCategoryRequest docreq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getVehicleClass Method");
	       }*/
	       logger.info("Inside GenerateCacheController :: getVehicleClass method :: Execution Started");
	       

	       SubCategoryResponse masterJSON = subcatserv.getSubCategory(docreq);
	       logger.info("Inside GenerateCacheController :: getVehicleClass method :: Execution Completed Successfully");
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getVehicleClass Method");
	       }*/
	       return masterJSON;
	}
	/*-----------------------Added by Nikhil570154 from here-------------------*/
	@RequestMapping(value = "/getvehicleidv/", method = RequestMethod.POST)
	@ResponseBody 
	public VehicleIdvResponse getVehicleIdv(@RequestBody VehicleIdvRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getDocumentMast method :: Execution Started");
	       
	       VehicleIdvResponse masterJSON = idvserv.getVehicleIdv(quickReq);
	
	       logger.info("Inside GenerateCacheController :: getDocumentMast method :: Execution Completed Successfully");
	                    
	       return masterJSON;
	}
	
	@RequestMapping(value = "/getaddonfeatures/",  method = RequestMethod.POST)
	@ResponseBody 
	public /*VehicleAddOnResponse*/ResponseEntity<String> getVehicleAddOn(@RequestBody String requestJson/*@RequestBody VehicleAddOnRequest quickReq*/,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       	logger.info("Inside GenerateCacheController :: getVehicleAddOn method :: Execution Started");
	       	VehicleAddOnResponse masterJSON=null;
	       	VehicleAddOnRequest quickReq=null;
	       	String result=null;		
	       	ResponseEntity responseEntity=null;
			HttpHeaders responseHeaders =  new HttpHeaders();
			try{
				
				quickReq=gson.fromJson(requestJson, VehicleAddOnRequest.class);
				 
				masterJSON = addonserv.getVehicleAddOn(quickReq);  // Calling Add On service
				
				if(masterJSON!=null){
					result=gson.toJson(masterJSON);
					responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.OK);
				}
				else{
					result="No Data Found";
					responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);	
				}
			}catch(Exception ex){
				logger.error("Inside CommonServiceController :: searchProposal method ::", ex);
				masterJSON=new VehicleAddOnResponse();				
				result=gson.toJson(masterJSON);
				responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
			}
												
	       return responseEntity;
	}
	
	@RequestMapping(value = "/getcompanymast",  method = RequestMethod.GET)
	@ResponseBody 
	public String getCompanyMaster(HttpServletRequest httpServletRequest)  throws ReflectiveOperationException{
	       
	       if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getCompanyMaster Method");
	       }
	       
	       logger.info("Inside GenerateCacheController :: getCompanyMaster method :: Execution Started");
	       
	       JSONObject masterJSON = genCache.getCompanyMaster();

	       logger.info("Inside GenerateCacheController :: getCompanyMaster method :: Execution Completed Successfully");
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getCompanyMaster Method");
	       }*/
	       //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON.toString();
	}
	
	@RequestMapping(value = "/getfinanciermast/{arg}",  method = RequestMethod.GET)
	@ResponseBody 
	public String getFinancierMaster(HttpServletRequest httpServletRequest, @PathVariable String arg)  throws ReflectiveOperationException{
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getFinancierMaster Method");
	       }*/
	       
	       logger.info("Inside GenerateCacheController :: getFinancierMaster method :: Execution Started");
	       
	       JSONObject masterJSON = genCache.genFinancierMaster(arg);

	       logger.info("Inside GenerateCacheController :: getFinancierMaster method :: Execution Completed Successfully");
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getFinancierMaster Method");
	       }*/
	       //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON.toString();
	}
	
	@RequestMapping(value = "/getrtolocation/",  method = RequestMethod.POST)
	@ResponseBody 
	public RTOLocationResponse fetchRTOLocation(@RequestBody RTOLocationRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getVehicleAddOn method :: Execution Started");
	       
	       RTOLocationResponse masterJSON = rtolocserv.fetchRTOLocation(quickReq);
	       return masterJSON;
	}
	
	@RequestMapping(value = "/getofficemast/",  method = RequestMethod.POST)
	@ResponseBody 
	public OfficeMasterResponse getOfficeMaster(@RequestBody OfficeMasterRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getOfficeMaster method :: Execution Started");
	       StopWatch watch = new StopWatch();
			watch.start();
	       
	       OfficeMasterResponse masterJSON = ofcmastserv.getOfficeMaster(quickReq);
	       watch.stop();
			logger.info("Time Taken by GenerateCacheController--> getOfficeMaster service in seconds..>>"+watch.getTotalTimeSeconds());
	       return masterJSON;
	}
	
	@RequestMapping(value = "/getdealermaster/",  method = RequestMethod.POST)
	@ResponseBody 
	public DealerMasterResponse fetchDealerMaster(@RequestBody DealerMasterRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: fetchDealerMaster method :: Execution Started");
	       
	       DealerMasterResponse masterJSON = dealerserv.FetchDealerInfo(quickReq);
	       return masterJSON;
	}
	
	
	@RequestMapping(value = "/getbankname/",  method = RequestMethod.POST)
	@ResponseBody 
	public List<? extends Object> getAccFinancierBranch(@RequestBody AccFinancierBranchRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getAccFinancierBranch method :: Execution Started");
	       
	       List masterJSON = (ArrayList) accfinserv.getAccFinancierBranch(quickReq);
	       return masterJSON;
	}
	
	@RequestMapping(value = "/getcityvehicleused/{arg}",  method = RequestMethod.GET)
	@ResponseBody 
	public String getCityVehicleUsedMaster(HttpServletRequest httpServletRequest,@PathVariable String arg)  throws ReflectiveOperationException{
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getCityVehicleUsedMaster Method");
	       }*/
	       
	       logger.info("Inside GenerateCacheController :: getCityVehicleUsedMaster method :: Execution Started");
	       
	       JSONObject masterJSON = genCache.getCityVehicleUsedMaster(arg);

	       logger.info("Inside GenerateCacheController :: getCityVehicleUsedMaster method :: Execution Completed Successfully");
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getCityVehicleUsedMaster Method");
	       }*/
	       //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON.toString();
	}
	
	@RequestMapping(value = "/getsubagentmast/{arg}/{arg1}",  method = RequestMethod.GET)
	@ResponseBody 
	public String getSubAgentMaster(HttpServletRequest httpServletRequest, @PathVariable String arg,@PathVariable String arg1)  throws ReflectiveOperationException{
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("In GenerateCacheController.getSubAgentMaster Method");
	       }*/
	       
	       logger.info("Inside GenerateCacheController :: getSubAgentMaster method :: Execution Started");
	       
	       JSONObject masterJSON = genCache.getSubAgentMaster(arg,arg1);

	       logger.info("Inside GenerateCacheController :: getSubAgentMaster method :: Execution Completed Successfully");
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("Out GenerateCacheController.getSubAgentMaster Method");
	       }*/
	       //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON.toString();
	}
	
	
	@RequestMapping(value = "/getfielduser/",  method = RequestMethod.POST)
	@ResponseBody 
	public FieldUserResponse getFieldUser(@RequestBody FieldUserRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: fetchDealerMaster method :: Execution Started");
	       
	       FieldUserResponse masterJSON = fieldusrserv.getFieldUser(quickReq);
	       return masterJSON;
	}
	
	@RequestMapping(value = "/getprevinsurerdet/",  method = RequestMethod.POST)
	@ResponseBody 
	public List<? extends Object> getPrevInsurer(@RequestBody PrevInsurerRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getPrevInsurer method :: Execution Started");
	       
	       List masterJSON = (ArrayList) previnsurerserv.getPrevInsurer(quickReq);
	       return masterJSON;
	}
	
	@RequestMapping(value = "/getvehmisctype",  method = RequestMethod.GET)
	@ResponseBody 
	public String getMiscType(HttpServletRequest httpServletRequest)  throws ReflectiveOperationException{
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getMiscType Method");
	       }*/
	       
	       logger.info("Inside GenerateCacheController :: getMiscType method :: Execution Started");
	       
	       JSONObject masterJSON =    genCache.getMiscType();

	       logger.info("Inside GenerateCacheController :: getMiscType method :: Execution Completed Successfully");
	       /*
	       if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getMiscType Method");
	       }*/
	              //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON.toString();
	}
	
	@RequestMapping(value = "/getdoclist/",  method = RequestMethod.POST)
	@ResponseBody 
	public DocListResponse getDocList(@RequestBody DocListRequest docreq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getVehicleClass Method");
	       }*/
	       logger.info("Inside GenerateCacheController :: getVehicleClass method :: Execution Started");
	       

	       DocListResponse masterJSON = doclstserv.getDocList(docreq);
	       logger.info("Inside GenerateCacheController :: getVehicleClass method :: Execution Completed Successfully");
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getVehicleClass Method");
	       }*/
	       return masterJSON;
	}
	@RequestMapping(value = "/getgaragecity",  method = RequestMethod.GET)
	@ResponseBody	
	public String getGarageCityMaster(HttpServletRequest httpServletRequest)  throws ReflectiveOperationException{
		
		/*if(logger.isDebugEnabled()){
			logger.debug("In TabServiceController.getGarageCityMaster Method");
		}*/
		
		logger.info("Inside GenerateCacheController :: getGarageCityMaster method :: Execution Started");
		
		JSONObject masterJSON = genCache.getGarageCityMaster();
		
		logger.info("Inside GenerateCacheController :: getGarageCityMaster method :: Execution Completed Successfully");

		/*if(logger.isDebugEnabled()){
			logger.debug("Out TabServiceController.getGarageCityMaster Method");
		}*/
			//System.out.println("xxxxxxx"+masterJSON.toString());			
		return masterJSON.toString();
	
	}
	
	@RequestMapping(value = "/getlonglat/",  method = RequestMethod.POST)
	@ResponseBody 
	public GarageRadiusResponse getLongLat(@RequestBody GarageRadiusRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: fetchDealerMaster method :: Execution Started");
	       
	       GarageRadiusResponse masterJSON = garageradserv.getLongLat(quickReq);
	       return masterJSON;
	}
	
	@RequestMapping(value = "/getclaimdocs/{arg}",  method = RequestMethod.GET)
	@ResponseBody 
	public String getClaimDocs(HttpServletRequest httpServletRequest,@PathVariable String arg)  throws ReflectiveOperationException{
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getVehicleClass Method");
	       }*/
	       
	       logger.info("Inside GenerateCacheController :: getVehicleClass method :: Execution Started");
	       
	       JSONObject masterJSON = genCache.getClaimDocs(arg);
	
	       logger.info("Inside GenerateCacheController :: getVehicleClass method :: Execution Completed Successfully");
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getVehicleClass Method");
	       }*/
	              //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON.toString();	
	}
	
	@RequestMapping(value = "/getemail/{arg}/{arg1}",  method = RequestMethod.GET)
	@ResponseBody 
	public String getEmail(HttpServletRequest httpServletRequest,@PathVariable String arg,@PathVariable Integer arg1)  throws ReflectiveOperationException{
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getEmail Method");
	       }*/
	       
	       logger.info("Inside GenerateCacheController :: getEmail method :: Execution Started");
	       
	       String res= genCache.getEmail(arg,arg1);
	
	       logger.info("Inside GenerateCacheController :: getEmail method :: Execution Completed Successfully");
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getEmail Method");
	       }*/
	              //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return res;	
	}
	
	@RequestMapping(value = "/getcontact/{arg}",  method = RequestMethod.GET)
	@ResponseBody 
	public List<? extends Object> getContactno(HttpServletRequest httpServletRequest,@PathVariable String arg)  throws ReflectiveOperationException{
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getContactno Method");
	       }*/
	       
	       logger.info("Inside GenerateCacheController :: getContactno method :: Execution Started");
	       
	       List masterJSON = (ArrayList) genCache.getContactno(arg);
	
	       logger.info("Inside GenerateCacheController :: getContactno method :: Execution Completed Successfully");
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getContactno Method");
	       }*/
	              //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON;	
	}
	
	@RequestMapping(value = "/getproducerdet/{arg}",  method = RequestMethod.GET)
	@ResponseBody 
	public List<? extends Object> getProducerDet(HttpServletRequest httpServletRequest,@PathVariable String arg)  throws ReflectiveOperationException{
	       
	       /*if(logger.isDebugEnabled()){
	              logger.debug("In TabServiceController.getProducerDet Method");
	       }*/
	       
	       logger.info("Inside GenerateCacheController :: getProducerDet method :: Execution Started");
	       
	       List masterJSON = (ArrayList) genCache.getProducerDet(arg);
	
	       logger.info("Inside GenerateCacheController :: getProducerDet method :: Execution Completed Successfully");
	       
	      /* if(logger.isDebugEnabled()){
	              logger.debug("Out TabServiceController.getProducerDet Method");
	       }*/
	              //System.out.println("xxxxxxx"+masterJSON.toString());               
	       return masterJSON;	
	}
	
	@RequestMapping(value = "/getreports",  method = RequestMethod.GET)
	@ResponseBody	
	public String getReports(HttpServletRequest httpServletRequest)  throws ReflectiveOperationException{
		
		/*if(logger.isDebugEnabled()){
			logger.debug("In TabServiceController.getReports Method");
		}*/
		
		logger.info("Inside GenerateCacheController :: getReports method :: Execution Started");
		
		JSONObject masterJSON = genCache.getReports();
		
		logger.info("Inside GenerateCacheController :: getReports method :: Execution Completed Successfully");

		/*if(logger.isDebugEnabled()){
			logger.debug("Out TabServiceController.getReports Method");
		}*/
			//System.out.println("xxxxxxx"+masterJSON.toString());			
		return masterJSON.toString();
	
	}
	/*-----------------------Added by Nikhil570154 till here-------------------*/
	
	@RequestMapping(value = "/getintermediaryinfo/",  method = RequestMethod.POST)
	@ResponseBody 
	public IntermediaryOfficeCodeServiceResponse fetchIntermediaryOfficeCode(@RequestBody IntermediaryOfficeCodeServiceRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: fetchIntermediaryOfficeCode method :: Execution Started");
	       
	       IntermediaryOfficeCodeServiceResponse masterJSON = interOffcCdServ.fetchIntermediaryOfficeCode(quickReq);
	       return masterJSON;
	}
	
	@RequestMapping(value = "/getPreInspectionAgencyDetails/",  method = RequestMethod.POST)
	@ResponseBody 
	public ArrayList<PreInspectionDetailsResponse> fetchPreInspectionAgencyDetails(@RequestBody PreInspectionDetailsRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: fetchPreInspectionAgencyDetails method :: Execution Started");
	       
	       ArrayList<PreInspectionDetailsResponse> masterJSON = preInspect.fetchPreInspectionAgencyDetails(quickReq);
	       
	       return masterJSON;
	}
	
	@RequestMapping(value = "/getCovernoteReasons/",  method = RequestMethod.POST)
	@ResponseBody 
	public CovernoteOtherReasonResponse getCovernoteReasons(@RequestBody CovernoteOtherReasonRequest securityQuestionRequest,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getCovernoteReasons method :: Execution Started");
	       
	       CovernoteOtherReasonResponse masterJSON = coverNoreServ.getCovernoteReasons(securityQuestionRequest);
	       
	       return masterJSON;
	}
	
	@RequestMapping(value = "/getCovernoteOtherReasons/",  method = RequestMethod.POST)
	@ResponseBody 
	public CovernoteOtherReasonResponse getCovernoteOtherReasons(@RequestBody CovernoteOtherReasonRequest securityQuestionRequest,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getCovernoteOtherReasons method :: Execution Started");
	       
	       CovernoteOtherReasonResponse masterJSON = coverNoreServ.getCovernoteOtherReasons(securityQuestionRequest);
	       
	       return masterJSON;
	}
	
	/*Below Method Added For Issue ID 1864*/
	@RequestMapping(value = "/getProdSupportDetails/",  method = RequestMethod.POST)
	@ResponseBody 
	public ProdSupportContactServiceResponse getProdSupportDetails(@RequestBody ProdSupportContactServiceRequest prodSupportContactServiceReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getProdSupportDetails method :: Execution Started");
	       
	       ProdSupportContactServiceResponse masterJSON = prodSupportService.getProdSupportDetails(prodSupportContactServiceReq);
	       
	       return masterJSON;
	}
	
	/*Below Method Added For Issue ID 1899*/
	@RequestMapping(value = "/getIDVRelaxationDetails/",  method = RequestMethod.POST)
	@ResponseBody 
	public IDVRelaxationResponse getIDVRelaxationDetails(@RequestBody IDVRelaxationRequest idvRelaxationRequest,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getIDVRelaxationDetails method :: Execution Started");
	       
	       IDVRelaxationResponse masterJSON = idvRelaxationService.getIDVRelaxationDetails(idvRelaxationRequest);
	       
	       return masterJSON;
	}
	
	/*Below Method Added For Issue ID 2018*/
	@RequestMapping(value = "/getAnnouncementDetails/",  method = RequestMethod.POST)
	@ResponseBody 
	public AnnouncementDetailsResponse getAnnouncementDetails(HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getAnnouncementDetails method :: Execution Started");
	       
	       AnnouncementDetailsResponse masterJSON = announcementDtlsServ.getAnnouncementDetails();
	       
	       return masterJSON;
	}
	
	
	// 3483 : Start : Vishal : Service for SP Master
	@RequestMapping(value = "/getspmaster/",  method = RequestMethod.POST)
	@ResponseBody 
	public SpMasterResponse getSpMaster(@RequestBody SpMasterRequest quickReq,HttpServletRequest httpServletRequest)  throws Exception{
	       
	       logger.info("Inside GenerateCacheController :: getSpMaster method :: Execution Started");
	       StopWatch watch = new StopWatch();
	       watch.start();
	       
		   SpMasterResponse masterJSON = spmastserv.getSpMaster(quickReq);
	       watch.stop();
	       logger.info("Time Taken by GenerateCacheController--> getSpMaster service in seconds..>>"+watch.getTotalTimeSeconds());
	       return masterJSON;
	}
	// 3483 : End : Vishal : Service for SP Master	
	
	
}
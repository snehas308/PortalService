package com.majesco.dcf.common.tagic.json;

import java.util.List;

public class ResultObject {

	private String resultCode;
	private List<ResponseError> responseError;
	private String message;
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public List<ResponseError> getResponseError() {
		return responseError;
	}
	public void setResponseError(List<ResponseError> responseError) {
		this.responseError = responseError;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}

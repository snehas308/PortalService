package com.majesco.dcf.docmgmt.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author ketan570156
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class QCInspectionResult {
	
	private String strdocmodmapid;
	private String strdocindex;
	private String strdocname;
	private String strfileext;
	private String strfilename;
	private String strfilesize;
	private String strfiletype;
	private String strfilebytestream;
	private String strproposalnumber;
	private String strpolicynumber;
	private String seqid;
	private String strdocstatus;
	private String strremarks;
	public String getStrdocmodmapid() {
		return strdocmodmapid;
	}
	public void setStrdocmodmapid(String strdocmodmapid) {
		this.strdocmodmapid = strdocmodmapid;
	}
	public String getStrdocindex() {
		return strdocindex;
	}
	public void setStrdocindex(String strdocindex) {
		this.strdocindex = strdocindex;
	}
	public String getStrdocname() {
		return strdocname;
	}
	public void setStrdocname(String strdocname) {
		this.strdocname = strdocname;
	}
	public String getStrfileext() {
		return strfileext;
	}
	public void setStrfileext(String strfileext) {
		this.strfileext = strfileext;
	}
	public String getStrfilename() {
		return strfilename;
	}
	public void setStrfilename(String strfilename) {
		this.strfilename = strfilename;
	}
	public String getStrfilesize() {
		return strfilesize;
	}
	public void setStrfilesize(String strfilesize) {
		this.strfilesize = strfilesize;
	}
	public String getStrfiletype() {
		return strfiletype;
	}
	public void setStrfiletype(String strfiletype) {
		this.strfiletype = strfiletype;
	}
	public String getStrfilebytestream() {
		return strfilebytestream;
	}
	public void setStrfilebytestream(String strfilebytestream) {
		this.strfilebytestream = strfilebytestream;
	}
	public String getStrproposalnumber() {
		return strproposalnumber;
	}
	public void setStrproposalnumber(String strproposalnumber) {
		this.strproposalnumber = strproposalnumber;
	}
	public String getStrpolicynumber() {
		return strpolicynumber;
	}
	public void setStrpolicynumber(String strpolicynumber) {
		this.strpolicynumber = strpolicynumber;
	}
	public String getSeqid() {
		return seqid;
	}
	public void setSeqid(String seqid) {
		this.seqid = seqid;
	}
	public String getStrdocstatus() {
		return strdocstatus;
	}
	public void setStrdocstatus(String strdocstatus) {
		this.strdocstatus = strdocstatus;
	}
	public String getStrremarks() {
		return strremarks;
	}
	public void setStrremarks(String strremarks) {
		this.strremarks = strremarks;
	}

}

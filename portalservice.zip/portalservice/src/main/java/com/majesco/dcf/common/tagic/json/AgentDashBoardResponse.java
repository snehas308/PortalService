package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class AgentDashBoardResponse extends ResultObject {

	private PendingQuotesList pendingQuotesList;
	private PendingInspectionList pendingInspectionList;
	private RejectedProposalList rejectedProposalList;
	private PendingApprovalList pendingApprovalList;
	private PendingPaymentList pendingPaymentList;
	private SPLExpiredList payLinkExpiredList;
	
	public PendingApprovalList getPendingApprovalList() {
		return pendingApprovalList;
	}
	public void setPendingApprovalList(PendingApprovalList pendingApprovalList) {
		this.pendingApprovalList = pendingApprovalList;
	}
	public PendingQuotesList getPendingQuotesList() {
		return pendingQuotesList;
	}
	public void setPendingQuotesList(PendingQuotesList pendingQuotesList) {
		this.pendingQuotesList = pendingQuotesList;
	}
	public PendingInspectionList getPendingInspectionList() {
		return pendingInspectionList;
	}
	public void setPendingInspectionList(PendingInspectionList pendingInspectionList) {
		this.pendingInspectionList = pendingInspectionList;
	}
	public RejectedProposalList getRejectedProposalList() {
		return rejectedProposalList;
	}
	public void setRejectedProposalList(RejectedProposalList rejectedProposalList) {
		this.rejectedProposalList = rejectedProposalList;
	}
	public PendingPaymentList getPendingPaymentList() {
		return pendingPaymentList;
	}
	public void setPendingPaymentList(PendingPaymentList pendingPaymentList) {
		this.pendingPaymentList = pendingPaymentList;
	}
	public SPLExpiredList getPayLinkExpiredList() {
		return payLinkExpiredList;
	}
	public void setPayLinkExpiredList(SPLExpiredList payLinkExpiredList) {
		this.payLinkExpiredList = payLinkExpiredList;
	}
	
}

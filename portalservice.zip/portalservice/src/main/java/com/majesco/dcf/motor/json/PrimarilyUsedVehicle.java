package com.majesco.dcf.motor.json;

public class PrimarilyUsedVehicle {
	
	private String city_flag;
	private String citycd;
	private String city_name;
	private Integer parent_cd;
	private String dist_flag;
	private String distrcit_cd;
	private String dist_name;
	private String rtodistrictcd;
	private String rtocitycd;
	private String rtolocationcd;
	private String rtoregistrationcd;
	private String rtolocationdesc;
	public String getCity_flag() {
		return city_flag;
	}
	public void setCity_flag(String city_flag) {
		this.city_flag = city_flag;
	}
	public String getCitycd() {
		return citycd;
	}
	public void setCitycd(String citycd) {
		this.citycd = citycd;
	}
	public String getCity_name() {
		return city_name;
	}
	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}
	public Integer getParent_cd() {
		return parent_cd;
	}
	public void setParent_cd(Integer parent_cd) {
		this.parent_cd = parent_cd;
	}
	public String getDist_flag() {
		return dist_flag;
	}
	public void setDist_flag(String dist_flag) {
		this.dist_flag = dist_flag;
	}
	public String getDistrcit_cd() {
		return distrcit_cd;
	}
	public void setDistrcit_cd(String distrcit_cd) {
		this.distrcit_cd = distrcit_cd;
	}
	public String getDist_name() {
		return dist_name;
	}
	public void setDist_name(String dist_name) {
		this.dist_name = dist_name;
	}
	public String getRtodistrictcd() {
		return rtodistrictcd;
	}
	public void setRtodistrictcd(String rtodistrictcd) {
		this.rtodistrictcd = rtodistrictcd;
	}
	public String getRtocitycd() {
		return rtocitycd;
	}
	public void setRtocitycd(String rtocitycd) {
		this.rtocitycd = rtocitycd;
	}
	public String getRtolocationcd() {
		return rtolocationcd;
	}
	public void setRtolocationcd(String rtolocationcd) {
		this.rtolocationcd = rtolocationcd;
	}
	public String getRtoregistrationcd() {
		return rtoregistrationcd;
	}
	public void setRtoregistrationcd(String rtoregistrationcd) {
		this.rtoregistrationcd = rtoregistrationcd;
	}
	public String getRtolocationdesc() {
		return rtolocationdesc;
	}
	public void setRtolocationdesc(String rtolocationdesc) {
		this.rtolocationdesc = rtolocationdesc;
	}
	
	
	

}

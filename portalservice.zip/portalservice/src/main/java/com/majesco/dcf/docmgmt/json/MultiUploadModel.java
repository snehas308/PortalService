package com.majesco.dcf.docmgmt.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class MultiUploadModel{

	private List<UploadModel>  uploadModelLst;

	public List<UploadModel> getUploadModelLst() {
		return uploadModelLst;
	}

	public void setUploadModelLst(List<UploadModel> uploadModelLst) {
		this.uploadModelLst = uploadModelLst;
	}
	
}

package com.majesco.dcf.common.tagic.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
//@Table(name = "dcf_producer_m",schema="dcfum")	// Commented for Oracle Migration
@Table(name = "dcf_producer_m")						// Added for Oracle Migration
public class ProducerMaster {

	@Id
	@Column(name= "producercode")
	private String producerCode;
	
	@Column(name= "producername")
	private String producerName;
	
	@Column(name= "location")
	private String location;
	
	@Column(name= "usertype")
	private String userType;
	
	@Column(name= "userid")
	private String userid;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtcreated", insertable=false)
	private Date dtCreated;
	
	@Column(name= "dtupdated")
	private Date dtUpdated;
	
	@Column(name= "strcreatedby")
	private String strCreatedBy;
	
	@Column(name= "strupdatedby")
	private String strUpdatedBy;

	public String getProducerCode() {
		return producerCode;
	}

	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}

	public String getProducerName() {
		return producerName;
	}

	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public Date getDtCreated() {
		return dtCreated;
	}

	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}

	public Date getDtUpdated() {
		return dtUpdated;
	}

	public void setDtUpdated(Date dtUpdated) {
		this.dtUpdated = dtUpdated;
	}

	public String getStrCreatedBy() {
		return strCreatedBy;
	}

	public void setStrCreatedBy(String strCreatedBy) {
		this.strCreatedBy = strCreatedBy;
	}

	public String getStrUpdatedBy() {
		return strUpdatedBy;
	}

	public void setStrUpdatedBy(String strUpdatedBy) {
		this.strUpdatedBy = strUpdatedBy;
	}
}

package com.majesco.dcf.common.tagic.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
//@Table(name = "dcf_internal_user",schema="dcfum")		// Commented for Oracle Migration
@Table(name = "dcf_internal_user")						// Added for Oracle Migration
public class InternalUser {

	@Id
	@Column(name= "userid")
	private String userid;
	
	@Column(name= "username")
	private String username;
	
	@Column(name= "nisactive")
	private int nisactive;
	
	@Column(name= "nisadmin")
	private int nisadmin;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtcreated", insertable=false)
	private Date dtcreated;
	
	@Column(name= "dtupdated")
	private Date dtupdated;
	
	@Column(name= "strcreatedby")
	private String strcreatedby;
	
	@Column(name= "strupdatedby")
	private String strupdatedby;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getNisactive() {
		return nisactive;
	}

	public void setNisactive(int nisactive) {
		this.nisactive = nisactive;
	}

	public int getNisadmin() {
		return nisadmin;
	}

	public void setNisadmin(int nisadmin) {
		this.nisadmin = nisadmin;
	}

	public Date getDtcreated() {
		return dtcreated;
	}

	public void setDtcreated(Date dtcreated) {
		this.dtcreated = dtcreated;
	}

	public Date getDtupdated() {
		return dtupdated;
	}

	public void setDtupdated(Date dtupdated) {
		this.dtupdated = dtupdated;
	}

	public String getStrcreatedby() {
		return strcreatedby;
	}

	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}

	public String getStrupdatedby() {
		return strupdatedby;
	}

	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}

	


}

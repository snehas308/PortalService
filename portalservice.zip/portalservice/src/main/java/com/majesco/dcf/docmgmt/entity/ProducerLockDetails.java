package com.majesco.dcf.docmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

/**
 * @author yogesh570158
 *
 */
@Entity
@Table(name = "dcf_document_upload_optn")
public class ProducerLockDetails implements Serializable{

	@Id
	@Column(name = "strproducercd")
	private String strproducercd;
	
	@Column(name = "strlob")
	private String strlob;
	
	@Column(name = "noofdays")
	private int noofdays;
	
	@Column(name = "strdocuploadtype")
	private String strdocuploadtype;
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "startdt", insertable=false)
	private Date startdt;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "enddt", insertable=false)
	private Date enddt;
	
	@Column(name = "strisactive")
	private String strisactive;
	
	@Column(name = "strcreatedby")
	private String strCreatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtcreated", insertable=false)
	private Date dtCreated;
	
	@Column(name = "strupdatedby")
	private String strUpdatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtupdated", insertable=false)
	private Date dtUpdated;

	
	
	
	public String getStrisactive() {
		return strisactive;
	}

	public void setStrisactive(String strisactive) {
		this.strisactive = strisactive;
	}

	public String getStrproducercd() {
		return strproducercd;
	}

	public void setStrproducercd(String strproducercd) {
		this.strproducercd = strproducercd;
	}

	public String getStrlob() {
		return strlob;
	}

	public void setStrlob(String strlob) {
		this.strlob = strlob;
	}

	public int getNoofdays() {
		return noofdays;
	}

	public void setNoofdays(int noofdays) {
		this.noofdays = noofdays;
	}

	public String getStrdocuploadtype() {
		return strdocuploadtype;
	}

	public void setStrdocuploadtype(String strdocuploadtype) {
		this.strdocuploadtype = strdocuploadtype;
	}

	public Date getStartdt() {
		return startdt;
	}

	public void setStartdt(Date startdt) {
		this.startdt = startdt;
	}

	public Date getEnddt() {
		return enddt;
	}

	public void setEnddt(Date enddt) {
		this.enddt = enddt;
	}

	public String getStrCreatedBy() {
		return strCreatedBy;
	}

	public void setStrCreatedBy(String strCreatedBy) {
		this.strCreatedBy = strCreatedBy;
	}

	public Date getDtCreated() {
		return dtCreated;
	}

	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}

	public String getStrUpdatedBy() {
		return strUpdatedBy;
	}

	public void setStrUpdatedBy(String strUpdatedBy) {
		this.strUpdatedBy = strUpdatedBy;
	}

	public Date getDtUpdated() {
		return dtUpdated;
	}

	public void setDtUpdated(Date dtUpdated) {
		this.dtUpdated = dtUpdated;
	}

	
	
	
	
	
}

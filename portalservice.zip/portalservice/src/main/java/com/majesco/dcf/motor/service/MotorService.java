package com.majesco.dcf.motor.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.motor.json.AddOnPlanProducerRequest;
import com.majesco.dcf.motor.json.AddOnPlanProducerResponse;
import com.majesco.dcf.motor.json.CalculatorMotorRequest;
import com.majesco.dcf.motor.json.CalculatorMotorResponse;
import com.majesco.dcf.motor.json.GenerateQuoteMotorRequest;
import com.majesco.dcf.motor.json.GenerateQuoteMotorResponse;
import com.majesco.dcf.motor.json.ProductProposalDataCVRequest;
import com.majesco.dcf.motor.json.ProductProposalDataCVResponse;
import com.majesco.dcf.motor.json.ProductProposalDataPVRequest;
import com.majesco.dcf.motor.json.ProductProposalDataPVResponse;
import com.majesco.dcf.motor.json.ProductProposalDataTWRequest;
import com.majesco.dcf.motor.json.ProductProposalDataTWResponse;
import com.majesco.dcf.motor.json.ProposalGenerationCVRequest;
import com.majesco.dcf.motor.json.ProposalGenerationCVResponse;
import com.majesco.dcf.motor.json.ProposalGenerationPVRequest;
import com.majesco.dcf.motor.json.ProposalGenerationPVResponse;
import com.majesco.dcf.motor.json.ProposalGenerationTWRequest;
import com.majesco.dcf.motor.json.ProposalGenerationTWResponse;

@Service
@Transactional
public interface MotorService {
	
	public CalculatorMotorResponse calculatePremiumMotor(CalculatorMotorRequest calcMotReq);
	
	public ProposalGenerationCVResponse generateProposalCV(ProposalGenerationCVRequest propGenReq);
	
	public ProposalGenerationPVResponse generateProposalPV(ProposalGenerationPVRequest propGenReq);
	
	public ProposalGenerationTWResponse generateProposalTW(ProposalGenerationTWRequest propGenReq);
	
	public GenerateQuoteMotorResponse generateQuoteMotorCV(GenerateQuoteMotorRequest genQuotreq);
	
	public GenerateQuoteMotorResponse generateQuoteMotorPV(GenerateQuoteMotorRequest genQuotreq);
	
	public GenerateQuoteMotorResponse generateQuoteMotorTW(GenerateQuoteMotorRequest genQuotreq);
	
	public ProposalGenerationCVResponse getPremiumCV(ProposalGenerationCVRequest propGenReq);
	
	public ProposalGenerationPVResponse getPremiumPV(ProposalGenerationPVRequest propGenReq);
	
	public ProposalGenerationTWResponse getPremiumTW(ProposalGenerationTWRequest propGenReq);
	
	public GenerateQuoteMotorResponse getPremiumCVQuote(GenerateQuoteMotorRequest propGenReq);
	
	public GenerateQuoteMotorResponse getPremiumPVQuote(GenerateQuoteMotorRequest propGenReq);
	
	public GenerateQuoteMotorResponse getPremiumTWQuote(GenerateQuoteMotorRequest propGenReq);
	
	public ProductProposalDataPVResponse getPolicyDetailByPolicyNoPrvtCar(ProductProposalDataPVRequest prodPropDataReq);
	
	public ProductProposalDataPVResponse getProductProposalDataPrvtCar(ProductProposalDataPVRequest prodPropDataReq) throws Exception;
	
	public ProposalGenerationPVResponse renewalProposalPrvtCar(ProposalGenerationPVRequest propRenewalReq) throws Exception;
	
	public ProductProposalDataTWResponse getPolicyDetailByPolicyNoTwoWheeler(ProductProposalDataTWRequest prodPropDataReq);
	
	public ProductProposalDataTWResponse getProductProposalDataTwoWheeler(ProductProposalDataTWRequest prodPropDataReq);
	
	public ProposalGenerationTWResponse renewalProposalTwoWheeler(ProposalGenerationTWRequest propRenewalReq) throws Exception;
	
	public ProductProposalDataCVResponse getPolicyDetailByPolicyNoComm(ProductProposalDataCVRequest prodPropDataReq);
	
	public ProductProposalDataCVResponse getProductProposalDataComm(ProductProposalDataCVRequest prodPropDataReq);
	
	public ProposalGenerationCVResponse renewalProposalComm(ProposalGenerationCVRequest propRenewalReq) throws Exception;
	
	public ProposalGenerationPVResponse saveInspAfterSaveProposalPV(ProposalGenerationPVRequest propGenReq) throws Exception;
	
	public ProposalGenerationTWResponse saveInspAfterSaveProposalTW(ProposalGenerationTWRequest propGenReq) throws Exception;
	
	public ProposalGenerationCVResponse saveInspAfterSaveProposalCV(ProposalGenerationCVRequest propGenReq) throws Exception;
	//Start:01/09/2017:Rahul:SIT:1947:Added generateRenewalProposalPV for RENEWALMODIFICATION operation as response object for renewal mod is ServiceResult
	public ProposalGenerationPVResponse generateRenewalProposalPV(ProposalGenerationPVRequest propGenReq);
	//end:01/09/2017:Rahul:SIT:1947:Added generateRenewalProposalPV for RENEWALMODIFICATION operation as response object for renewal mod is ServiceResult
	//Start:06/10/2017:Ketan:SIT:1947:Added generateRenewalProposalTW for RENEWALMODIFICATION operation as response object for renewal mod is ServiceResult
	public ProposalGenerationTWResponse generateRenewalProposalTW(ProposalGenerationTWRequest propGenReq);
	//end:06/10/2017:Ketan:SIT:1947:Added generateRenewalProposalTW for RENEWALMODIFICATION operation as response object for renewal mod is ServiceResult
	//Start:16/10/2017:Ketan:SIT:1715:Added generateRenewalProposalCV for RENEWALMODIFICATION operation as response object for renewal mod is ServiceResult
	public ProposalGenerationCVResponse generateRenewalProposalCV(ProposalGenerationCVRequest propGenReq);
	//End:16/10/2017:Ketan:SIT:1715:Added generateRenewalProposalCV for RENEWALMODIFICATION operation as response object for renewal mod is ServiceResult
	//Start: KetanM <SIT 3270>| service exposed for getAddOnPlanBasedOnProducer on 18 Jan 2018
	public AddOnPlanProducerResponse getAddOnPlanBasedOnProducer(AddOnPlanProducerRequest addOnPlanProducerRequest) throws Exception;
	//End: KetanM <SIT 3270>| service exposed for getAddOnPlanBasedOnProducer on 18 Jan 2018
}

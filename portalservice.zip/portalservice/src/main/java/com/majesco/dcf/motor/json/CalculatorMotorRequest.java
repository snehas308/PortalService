package com.majesco.dcf.motor.json;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.common.tagic.util.ServiceUtility;

import java.util.Date;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CalculatorMotorRequest extends UserObject {

private String	vehRegNbr;
private String	vehRegNbr1;
private String	vehRegNbr2;
private String	vehRegNbr3;
private String	registeredCityRTO;
private String	dateOfReg;
private String manufacturer;
private String model;
private String variant;
private String vehicleUseCity;
private String existingCoverExp;
private String expiryDate;
private String lastClaimMade;
private String fuelType;
private String ncb;
private Integer tenure;
private String vehicleType;
private String businessType;
private String tataAIGBranch;
private String seatingCap;
private String cubicCap;
private String varCode;
private String modelCode;
private String rtoCode;
private String rtoGroupCode;
private String prodCD;
private String manufactCode;

private String officeCode;
private String officeName;
private String displayOfficeCode;
private String branchOfficeCode;
private String regMonth;
private String regYear;
private String typeOfBody;
private String vehicleAge;
private String basisOfRating;
private String vehSegment;

/*Newly Added Variables On 10 Jan 2017*/
private String customerType;
private String polIncpDt;
private String polIncpTm;
private String manufactYear;
private String idvOfVehicle;
private String paCoverUnmdPass;
private String sumInsuredUnnamedPass;
private String noOfPersUnnamed;
private String ncbPercent;
private String addOnPlan;
private String addOnChoice;
private String dateOfPurchase;
private String otherProducerCode;
private String valueFornonElec;
private String valForElecAcc;
private String cnglpgKitValue;
private String legalLiability;
private String protCvrNCB;
private String roadAsst;
private String cnglpgInsrdPIP;
/*Newly Added Variables On 10 Jan 2017*/

ServiceUtility serviceUtility = new ServiceUtility();
//private String authenticationToken;



public String getVehicleType() {
	return vehicleType;
}
public String getOtherProducerCode() {
	return otherProducerCode;
}
public void setOtherProducerCode(String otherProducerCode) {
	this.otherProducerCode = otherProducerCode;
}
public void setVehicleType(String vehicleType) {
	vehicleType = serviceUtility.blankToNullCheck(vehicleType);
	this.vehicleType = vehicleType;
}
public String getBusinessType() {
	return businessType;
}
public void setBusinessType(String businessType) {
	businessType = serviceUtility.blankToNullCheck(businessType);
	this.businessType = businessType;
}
public String getTataAIGBranch() {
	return tataAIGBranch;
}
public void setTataAIGBranch(String tataAIGBranch) {
	tataAIGBranch = serviceUtility.blankToNullCheck(tataAIGBranch);
	this.tataAIGBranch = tataAIGBranch;
}
public String getVehRegNbr() {
	return vehRegNbr;
}
public void setVehRegNbr(String vehRegNbr) {
	vehRegNbr = serviceUtility.blankToNullCheck(vehRegNbr);
	this.vehRegNbr = vehRegNbr;
}
public String getVehRegNbr1() {
	return vehRegNbr1;
}
public void setVehRegNbr1(String vehRegNbr1) {
	vehRegNbr1 = serviceUtility.blankToNullCheck(vehRegNbr1);
	this.vehRegNbr1 = vehRegNbr1;
}
public String getVehRegNbr2() {
	return vehRegNbr2;
}
public void setVehRegNbr2(String vehRegNbr2) {
	vehRegNbr2 = serviceUtility.blankToNullCheck(vehRegNbr2);
	this.vehRegNbr2 = vehRegNbr2;
}
public String getVehRegNbr3() {
	return vehRegNbr3;
}
public void setVehRegNbr3(String vehRegNbr3) {
	vehRegNbr3 = serviceUtility.blankToNullCheck(vehRegNbr3);
	this.vehRegNbr3 = vehRegNbr3;
}
public String getRegisteredCityRTO() {
	return registeredCityRTO;
}
public void setRegisteredCityRTO(String registeredCityRTO) {
	registeredCityRTO = serviceUtility.blankToNullCheck(registeredCityRTO);
	this.registeredCityRTO = registeredCityRTO;
}
public String getDateOfReg() {
	return dateOfReg;
}
public void setDateOfReg(String dateOfReg) {
	dateOfReg = serviceUtility.blankToNullCheck(dateOfReg);
	this.dateOfReg = dateOfReg;
}
public String getManufacturer() {
	return manufacturer;
}
public void setManufacturer(String manufacturer) {
	manufacturer = serviceUtility.blankToNullCheck(manufacturer);
	this.manufacturer = manufacturer;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	model = serviceUtility.blankToNullCheck(model);
	this.model = model;
}
public String getVariant() {
	return variant;
}
public void setVariant(String variant) {
	variant = serviceUtility.blankToNullCheck(variant);
	this.variant = variant;
}
public String getVehicleUseCity() {
	return vehicleUseCity;
}
public void setVehicleUseCity(String vehicleUseCity) {
	vehicleUseCity = serviceUtility.blankToNullCheck(vehicleUseCity);
	this.vehicleUseCity = vehicleUseCity;
}
public String getExistingCoverExp() {
	return existingCoverExp;
}
public void setExistingCoverExp(String existingCoverExp) {
	existingCoverExp = serviceUtility.blankToNullCheck(existingCoverExp);
	this.existingCoverExp = existingCoverExp;
}
public String getExpiryDate() {
	return expiryDate;
}
public void setExpiryDate(String expiryDate) {
	expiryDate = serviceUtility.blankToNullCheck(expiryDate);
	this.expiryDate = expiryDate;
}
public String getLastClaimMade() {
	return lastClaimMade;
}
public void setLastClaimMade(String lastClaimMade) {
	lastClaimMade = serviceUtility.blankToNullCheck(lastClaimMade);
	this.lastClaimMade = lastClaimMade;
}
public String getFuelType() {
	return fuelType;
}
public void setFuelType(String fuelType) {
	fuelType = serviceUtility.blankToNullCheck(fuelType);
	this.fuelType = fuelType;
}
public String getNcb() {
	return ncb;
}
public void setNcb(String ncb) {
	ncb = serviceUtility.blankToNullCheck(ncb);
	this.ncb = ncb;
}
public Integer getTenure() {
	return tenure;
}
public void setTenure(Integer tenure) {
	this.tenure = tenure;
}
public String getIdv() {
	return idv;
}
public void setIdv(String idv) {
	idv = serviceUtility.blankToNullCheck(idv);
	this.idv = idv;
}
private String idv;

public String getSeatingCap() {
	return seatingCap;
}
public void setSeatingCap(String seatingCap) {
	seatingCap = serviceUtility.blankToNullCheck(seatingCap);
	this.seatingCap = seatingCap;
}


public String getCubicCap() {
	return cubicCap;
}
public void setCubicCap(String cubicCap) {
	cubicCap = serviceUtility.blankToNullCheck(cubicCap);
	this.cubicCap = cubicCap;
}


public String getVarCode() {
	return varCode;
}
public void setVarCode(String varCode) {
	varCode = serviceUtility.blankToNullCheck(varCode);
	this.varCode = varCode;
}


public String getModelCode() {
	return modelCode;
}
public void setModelCode(String modelCode) {
	modelCode = serviceUtility.blankToNullCheck(modelCode);
	this.modelCode = modelCode;
}


public String getRtoCode() {
	return rtoCode;
}
public void setRtoCode(String rtoCode) {
	rtoCode = serviceUtility.blankToNullCheck(rtoCode);
	this.rtoCode = rtoCode;
}


public String getRtoGroupCode() {
	return rtoGroupCode;
}
public void setRtoGroupCode(String rtoGroupCode) {
	rtoGroupCode = serviceUtility.blankToNullCheck(rtoGroupCode);
	this.rtoGroupCode = rtoGroupCode;
}
public String getProdCD() {
	return prodCD;
}
public void setProdCD(String prodCD) {
	prodCD = serviceUtility.blankToNullCheck(prodCD);
	this.prodCD = prodCD;
}
public String getManufactCode() {
	return manufactCode;
}
public void setManufactCode(String manufactCode) {
	manufactCode = serviceUtility.blankToNullCheck(manufactCode);
	this.manufactCode = manufactCode;
}
public String getOfficeCode() {
	return officeCode;
}
public void setOfficeCode(String officeCode) {
	officeCode = serviceUtility.blankToNullCheck(officeCode);
	this.officeCode = officeCode;
}
public String getOfficeName() {
	return officeName;
}
public void setOfficeName(String officeName) {
	officeName = serviceUtility.blankToNullCheck(officeName);
	this.officeName = officeName;
}
public String getDisplayOfficeCode() {
	return displayOfficeCode;
}
public void setDisplayOfficeCode(String displayOfficeCode) {
	displayOfficeCode = serviceUtility.blankToNullCheck(displayOfficeCode);
	this.displayOfficeCode = displayOfficeCode;
}
public String getBranchOfficeCode() {
	return branchOfficeCode;
}
public void setBranchOfficeCode(String branchOfficeCode) {
	branchOfficeCode = serviceUtility.blankToNullCheck(branchOfficeCode);
	this.branchOfficeCode = branchOfficeCode;
}
public String getRegMonth() {
	return regMonth;
}
public void setRegMonth(String regMonth) {
	regMonth = serviceUtility.blankToNullCheck(regMonth);
	this.regMonth = regMonth;
}
public String getRegYear() {
	return regYear;
}
public void setRegYear(String regYear) {
	regYear = serviceUtility.blankToNullCheck(regYear);
	this.regYear = regYear;
}
public String getTypeOfBody() {
	return typeOfBody;
}
public void setTypeOfBody(String typeOfBody) {
	typeOfBody = serviceUtility.blankToNullCheck(typeOfBody);
	this.typeOfBody = typeOfBody;
}
public String getVehicleAge() {
	return vehicleAge;
}
public void setVehicleAge(String vehicleAge) {
	vehicleAge = serviceUtility.blankToNullCheck(vehicleAge);
	this.vehicleAge = vehicleAge;
}
public String getCustomerType() {
	return customerType;
}
public void setCustomerType(String customerType) {
	this.customerType = customerType;
}
public String getPolIncpDt() {
	return polIncpDt;
}
public void setPolIncpDt(String polIncpDt) {
	this.polIncpDt = polIncpDt;
}
public String getManufactYear() {
	return manufactYear;
}
public void setManufactYear(String manufactYear) {
	this.manufactYear = manufactYear;
}
public String getIdvOfVehicle() {
	return idvOfVehicle;
}
public void setIdvOfVehicle(String idvOfVehicle) {
	this.idvOfVehicle = idvOfVehicle;
}
public String getPaCoverUnmdPass() {
	return paCoverUnmdPass;
}
public void setPaCoverUnmdPass(String paCoverUnmdPass) {
	this.paCoverUnmdPass = paCoverUnmdPass;
}
public String getSumInsuredUnnamedPass() {
	return sumInsuredUnnamedPass;
}
public void setSumInsuredUnnamedPass(String sumInsuredUnnamedPass) {
	this.sumInsuredUnnamedPass = sumInsuredUnnamedPass;
}
public String getNoOfPersUnnamed() {
	return noOfPersUnnamed;
}
public void setNoOfPersUnnamed(String noOfPersUnnamed) {
	this.noOfPersUnnamed = noOfPersUnnamed;
}
public String getNcbPercent() {
	return ncbPercent;
}
public void setNcbPercent(String ncbPercent) {
	this.ncbPercent = ncbPercent;
}
public String getAddOnPlan() {
	return addOnPlan;
}
public void setAddOnPlan(String addOnPlan) {
	this.addOnPlan = addOnPlan;
}
public String getAddOnChoice() {
	return addOnChoice;
}
public void setAddOnChoice(String addOnChoice) {
	this.addOnChoice = addOnChoice;
}
public String getDateOfPurchase() {
	return dateOfPurchase;
}
public void setDateOfPurchase(String dateOfPurchase) {
	this.dateOfPurchase = dateOfPurchase;
}
public String getPolIncpTm() {
	return polIncpTm;
}
public void setPolIncpTm(String polIncpTm) {
	this.polIncpTm = polIncpTm;
}
public String getBasisOfRating() {
	return basisOfRating;
}
public void setBasisOfRating(String basisOfRating) {
	this.basisOfRating = basisOfRating;
}
public String getVehSegment() {
	return vehSegment;
}
public void setVehSegment(String vehSegment) {
	this.vehSegment = vehSegment;
}
public String getValueFornonElec() {
	return valueFornonElec;
}
public void setValueFornonElec(String valueFornonElec) {
	this.valueFornonElec = valueFornonElec;
}
public String getValForElecAcc() {
	return valForElecAcc;
}
public void setValForElecAcc(String valForElecAcc) {
	this.valForElecAcc = valForElecAcc;
}
public String getCnglpgKitValue() {
	return cnglpgKitValue;
}
public void setCnglpgKitValue(String cnglpgKitValue) {
	this.cnglpgKitValue = cnglpgKitValue;
}
public String getLegalLiability() {
	return legalLiability;
}
public void setLegalLiability(String legalLiability) {
	this.legalLiability = legalLiability;
}
public String getProtCvrNCB() {
	return protCvrNCB;
}
public void setProtCvrNCB(String protCvrNCB) {
	this.protCvrNCB = protCvrNCB;
}
public String getRoadAsst() {
	return roadAsst;
}
public void setRoadAsst(String roadAsst) {
	this.roadAsst = roadAsst;
}
public String getCnglpgInsrdPIP() {
	return cnglpgInsrdPIP;
}
public void setCnglpgInsrdPIP(String cnglpgInsrdPIP) {
	this.cnglpgInsrdPIP = cnglpgInsrdPIP;
}

//public String getAuthenticationToken() {
//	return authenticationToken;
//}
//public void setAuthenticationToken(String authenticationToken) {
//	this.authenticationToken = authenticationToken;
//}

	
	
}

package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class IDVRelaxationRequest {
	
	private String strintermediarycd;
	private String strmanufacturercd;
	private String strmodelcd;
	private String strvariantcd;
	private String nvehicleage;
	
	public String getStrintermediarycd() {
		return strintermediarycd;
	}
	public void setStrintermediarycd(String strintermediarycd) {
		this.strintermediarycd = strintermediarycd;
	}
	public String getStrmanufacturercd() {
		return strmanufacturercd;
	}
	public void setStrmanufacturercd(String strmanufacturercd) {
		this.strmanufacturercd = strmanufacturercd;
	}
	public String getStrmodelcd() {
		return strmodelcd;
	}
	public void setStrmodelcd(String strmodelcd) {
		this.strmodelcd = strmodelcd;
	}
	public String getStrvariantcd() {
		return strvariantcd;
	}
	public void setStrvariantcd(String strvariantcd) {
		this.strvariantcd = strvariantcd;
	}
	public String getNvehicleage() {
		return nvehicleage;
	}
	public void setNvehicleage(String nvehicleage) {
		this.nvehicleage = nvehicleage;
	}
	
	
	

	
}

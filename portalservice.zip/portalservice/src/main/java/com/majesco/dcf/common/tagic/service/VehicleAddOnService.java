package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.entity.VehicleAddOn;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.VehicleAddOnRequest;
import com.majesco.dcf.common.tagic.json.VehicleAddOnResponse;


@Service
public class VehicleAddOnService {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(VehicleAddOnService.class);
	
	@SuppressWarnings("null")
	public VehicleAddOnResponse getVehicleAddOn(VehicleAddOnRequest modelreq) throws Exception
	{
		//VehicleAddOnResponse modelres = new VehicleAddOnResponse();
		VehicleAddOnResponse modelres = null;		
		try
		{
		ObjectMapper objMap=new ObjectMapper();
		logger.info("In VehicleAddOnService.getVehicleAddOn() Method Begin()...");
		
		String strplanname=null;
		String strchoice=null;
		BigDecimal ndepreciationreimbursement = null;
		String strnoofclaims=null;
		BigDecimal nenginesecure= null;
		String strenginesecureoption=null;
		BigDecimal ntyresecure= null;
		String strtyresecureoption=null;
		BigDecimal nrepairofglassrubberplasticparts= null;
		BigDecimal nkeyreplacement= null;
		String strkeyreplacementsi=null;
		BigDecimal nconsumableexpenses= null;
		BigDecimal nlossofpersonalbelongings= null;
		String strlossofpersonalbelongingssi=null;
		BigDecimal nroadsideassistance= null;
		String stremergtrnsprtandhotelexpensidv=null;
		String strratioofaoaaoy=null;
		String stremergencytransportsiaoa=null;
		String stremergencytransportsiaoy=null;
		BigDecimal ndailyallowance= null;
		String straccidentallowancedays=null;
		String strtheftallowancedays=null;
		String strfranchisedays=null;
		BigDecimal nreturntoinvoice= null;
		String straddonpremium=null;
		String dtcreated=null;
		String strcreatedby=null;
		String dtupdated=null;
		String strupdatedby=null;
		
		/*List<ResponseError> reserrList = new ArrayList<ResponseError>();
		
		
		ResponseError res = new ResponseError();
		res.setErrorCode("101");
		res.setErrorMMessag("Sorry Authentication Issue....");
		reserrList.add(res);*/
		
		/*@SuppressWarnings("unchecked")*/
		//List<Integer> idvList =  (List<Integer>) dbserv.getVehicleIdv("com.majesco.dcf.common.tagic.entity.VehicleIdv", modelreq);
		List<VehicleAddOn> idvList =  (List<VehicleAddOn>) dbserv.getAddOnFeatures("com.majesco.dcf.common.tagic.entity.VehicleAddOn", modelreq);
		if(idvList!=null && idvList.size()>0){
			modelres = new VehicleAddOnResponse();
			for(VehicleAddOn idv:idvList){
		        
	        	strplanname = idv.getStrplanname();
	        	strchoice = idv.getStrchoice();
	        	ndepreciationreimbursement = idv.getNdepreciationreimbursement();
	    		strnoofclaims= idv.getStrnoofclaims();
	    		nenginesecure= idv.getNenginesecure();
	    		strenginesecureoption = idv.getStrenginesecureoption();
	    		ntyresecure= idv.getNtyresecure();
	    		strtyresecureoption=idv.getStrtyresecureoption() ;
	    		nrepairofglassrubberplasticparts = idv.getNrepairofglassrubberplasticparts();
	    		nkeyreplacement= idv.getNkeyreplacement();
	    		strkeyreplacementsi=idv.getStrkeyreplacementsi();
	    		nconsumableexpenses=idv.getNconsumableexpenses();
	    		nlossofpersonalbelongings= idv.getNlossofpersonalbelongings();
	    		strlossofpersonalbelongingssi= idv.getStrlossofpersonalbelongingssi();
	    		nroadsideassistance= idv.getNroadsideassistance();
	    		stremergtrnsprtandhotelexpensidv= idv.getStremergtrnsprtandhotelexpensidv();
	    		strratioofaoaaoy= idv.getStrratioofaoaaoy();
	    		stremergencytransportsiaoa= idv.getStremergencytransportsiaoa();
	    		stremergencytransportsiaoy= idv.getStremergencytransportsiaoy();
	    		ndailyallowance = idv.getNdailyallowance();
	    		straccidentallowancedays= idv.getStraccidentallowancedays();
	    		strtheftallowancedays= idv.getStrtheftallowancedays();
	    		strfranchisedays=idv.getStrfranchisedays();
	    		nreturntoinvoice= idv.getNreturntoinvoice();
	    		straddonpremium= idv.getStraddonpremium();
	    		dtcreated=idv.getDtcreated();
	    		strcreatedby=idv.getStrcreatedby();
	    		dtupdated=idv.getDtupdated();
	    		strupdatedby=idv.getStrupdatedby();
	        }
	        modelres.setStrplanname(strplanname);
	        modelres.setStrchoice(strchoice);
	        modelres.setNdepreciationreimbursement(ndepreciationreimbursement);
	        modelres.setStrnoofclaims(strnoofclaims);
	        modelres.setNenginesecure(nenginesecure);
	        modelres.setStrenginesecureoption(strenginesecureoption);
	        modelres.setNtyresecure(ntyresecure);
	        modelres.setStrtyresecureoption(strtyresecureoption) ;
	        modelres.setNrepairofglassrubberplasticparts(nrepairofglassrubberplasticparts);
	        modelres.setNkeyreplacement(nkeyreplacement);
	        modelres.setStrkeyreplacementsi(strkeyreplacementsi);
	        modelres.setNconsumableexpenses(nconsumableexpenses);
	        modelres.setNlossofpersonalbelongings(nlossofpersonalbelongings);
	        modelres.setStrlossofpersonalbelongingssi(strlossofpersonalbelongingssi);
	        modelres.setNroadsideassistance(nroadsideassistance);
	        modelres.setStremergtrnsprtandhotelexpensidv(stremergtrnsprtandhotelexpensidv);
	        modelres.setStrratioofaoaaoy(strratioofaoaaoy);
	        modelres.setStremergencytransportsiaoa(stremergencytransportsiaoa);
	        modelres.setStremergencytransportsiaoy(stremergencytransportsiaoy);
	        modelres.setNdailyallowance(ndailyallowance);
	        modelres.setStraccidentallowancedays(straccidentallowancedays);
	        modelres.setStrtheftallowancedays(strtheftallowancedays);
	        modelres.setStrfranchisedays(strfranchisedays);
	        modelres.setNreturntoinvoice(nreturntoinvoice);
			modelres.setStraddonpremium(straddonpremium);
			modelres.setDtcreated(dtcreated);
			modelres.setStrcreatedby(strcreatedby);
			modelres.setDtupdated(dtupdated);
			modelres.setStrupdatedby(strupdatedby);
	        /*modelres.setNidv(lstnidv);
	        modelres.setNlocationexshowroomprice(lstnlocationexshowroomprice);
	        modelres.setNvehiclechassisprice(lstnvehiclechassisprice);
	        modelres.setNvehiclesellingprice(lstnvehiclesellingprice);*/
			//nidv= idvList.get(0);
	        //modelres.setNidv(nidv);
	        //modelres.setStrmodelnumber(lststrmodelnumber);
	        
	        /*pincdres.setStrcitycd(strcitycd);       
	        strcityval = dbserv.getCityNameByCode("com.majesco.dcf.common.tagic.entity.City", strcitycd, "C");
	        pincdres.setStrcityval(strcityval);
	       
	        pincdres.setStrdistrictcd(strdistrictcd);       
	        strdistrictval = dbserv.getDistrictNameByCode("com.majesco.dcf.common.tagic.entity.City", strdistrictcd, "D");
	        pincdres.setStrdistrictval(strdistrictval);
	        
	        pincdres.setStrstatecd(strstatecd);
	        strstateval = dbserv.getStateNameByCode("com.majesco.dcf.common.tagic.entity.State", strstatecd);
	        pincdres.setStrstateval(strstateval);
	        
	        pincdres.setStrcountrycd(strcountrycd);
	        strcountryval = dbserv.getCountryNameByCode("com.majesco.dcf.common.tagic.entity.Country", strcountrycd);
	        pincdres.setStrcountryval(strcountryval);*/
			
			
			//System.out.println(objMap.writeValueAsString(modelres));
			//if(logger.isDebugEnabled()) logger.debug("In VehicleAddOnService.getVehicleAddOn() Method ::: "+objMap.writeValueAsString(modelres));
		}        		
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			logger.error("Exception in VehicleAddOnService.getVehicleAddOn() :- "+e);
		}
		//if(logger.isDebugEnabled()) logger.debug("In VehicleAddOnService.getVehicleAddOn() Method End()...");
		
		return modelres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }
}

package com.majesco.dcf.common.tagic.filter;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponseWrapper;
import org.apache.log4j.Logger;


public class LoggerFilter implements Filter{
	
	private boolean dumpRequest;
	private boolean dumpResponse;
	String body = null;
    StringBuilder stringBuilder = new StringBuilder();
    BufferedReader bufferedReader = null;
    
	
	/*Added To Extract Body From Response*/
	private static class ByteArrayServletStream extends ServletOutputStream {
		 
	    ByteArrayOutputStream baos;
	 
	    ByteArrayServletStream(ByteArrayOutputStream baos) {
	      this.baos = baos;
	    }
	 
	    public void write(int param) throws IOException {
	      baos.write(param);
	    }
	  }
	
	private static class ByteArrayPrintWriter {
		 
	    private ByteArrayOutputStream baos = new ByteArrayOutputStream();
	 
	    private PrintWriter pw = new PrintWriter(baos);
	 
	    private ServletOutputStream sos = new ByteArrayServletStream(baos);
	 
	    public PrintWriter getWriter() {
	      return pw;
	    }
	 
	    public ServletOutputStream getStream() {
	      return sos;
	    }
	 
	    byte[] toByteArray() {
	      return baos.toByteArray();
	    }
	  }
	
	/*Added To Extract Body From Response*/
	final static Logger logger = Logger.getLogger(LoggerFilter.class);
	
	 @Override
	 public void destroy() {
	
	 }
	
 
	  @Override
	  public void init(FilterConfig filterConfig) throws ServletException {
		  
	  }
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		
		if(logger.isDebugEnabled()){
			logger.debug("In LoggerFilter.doFilter Method");
		}
		InputStream inputStream = request.getInputStream();
	    if (inputStream != null) {
            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            char[] charBuffer = new char[1024*1024];
            int bytesRead = -1;
            while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
                stringBuilder.append(charBuffer, 0, bytesRead);
            }
        } else {
            stringBuilder.append("");
        }
	    body = stringBuilder.toString();
		
	        logger.info("REQUEST -> " + body.toString());

	    
	    HttpServletResponse res = (HttpServletResponse) response;
	 
	    final ByteArrayPrintWriter pw = new ByteArrayPrintWriter();
	    HttpServletResponse wrappedResp = new HttpServletResponseWrapper(res) {
	      public PrintWriter getWriter() {
	        return pw.getWriter();
	      }
	 
	      public ServletOutputStream getOutputStream() {
	        return pw.getStream();
	      }
	 
	    };
	 
	    chain.doFilter(request, wrappedResp);
	 
	    byte[] bytes = pw.toByteArray();
	    response.getOutputStream().write(bytes);

	    	logger.info("RESPONSE -> " + new String(bytes));

	    
	    if(logger.isDebugEnabled()){
			logger.debug("Out LoggerFilter.doFilter Method");
		}
	}

}

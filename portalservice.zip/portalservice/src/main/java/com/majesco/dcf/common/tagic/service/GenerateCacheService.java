package com.majesco.dcf.common.tagic.service;

import java.io.FileReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.ehcache.annotations.Cacheable;
import com.majesco.dcf.common.tagic.entity.BranchMaster;
import com.majesco.dcf.common.tagic.entity.City;
import com.majesco.dcf.common.tagic.entity.ClaimDocMaster;
import com.majesco.dcf.common.tagic.entity.CompanyMaster;
import com.majesco.dcf.common.tagic.entity.Country;
import com.majesco.dcf.common.tagic.entity.FinancierMaster;
import com.majesco.dcf.common.tagic.entity.GarageCityMaster;
import com.majesco.dcf.common.tagic.entity.Manufact;
import com.majesco.dcf.common.tagic.entity.Masters;
import com.majesco.dcf.common.tagic.entity.Model;
import com.majesco.dcf.common.tagic.entity.ParameterDetailList;
import com.majesco.dcf.common.tagic.entity.ParameterList;
import com.majesco.dcf.common.tagic.entity.Product;
import com.majesco.dcf.common.tagic.entity.RTOLocation;
import com.majesco.dcf.common.tagic.entity.ReportsMaster;
import com.majesco.dcf.common.tagic.entity.SecurityQuestion;
import com.majesco.dcf.common.tagic.entity.State;
import com.majesco.dcf.common.tagic.entity.SubAgentMaster;
import com.majesco.dcf.common.tagic.entity.UserParameterList;
import com.majesco.dcf.common.tagic.entity.VehicleClass;
import com.majesco.dcf.common.tagic.entity.VehicleSubClass;
import com.majesco.dcf.common.tagic.json.VehicleVariantRequest;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
//import com.majesco.dcf.common.tagic.controller.GenerateCacheController;

@Service
public class GenerateCacheService {
	
	@Autowired
	DBService dBService;
	
	final static Logger logger=Logger.getLogger(GenerateCacheService.class);
	
	@Cacheable(cacheName="masterEhcache")
	public JSONObject getMasterData() {
			JSONObject jsonObject = new JSONObject();
			
			try {
				/*if(logger.isDebugEnabled()){
					logger.debug("In GenerateCacheService.getMasterData Method loading echache...");
				}*/
				
				logger.info("Inside GenerateCacheService :: getMasterData method :: Execution Started");
				
				List<ParameterList> oComMasterList =  (List<ParameterList>) dBService.get("com.majesco.dcf.common.tagic.entity.ParameterList");
				for(ParameterList masterList:oComMasterList){
					
					
					ArrayList allistsystem = new ArrayList();
					ArrayList allistuser = new ArrayList();
					Map<String, String> paramMap = new HashMap<String, String>();
					
					List<ParameterDetailList> oComListDetails =  (List<ParameterDetailList>) dBService.getList("com.majesco.dcf.common.tagic.entity.ParameterDetailList","iparamtypecd",masterList.getIparamtypecd());
					for(ParameterDetailList masterdtl:oComListDetails){
						
						JSONObject childjsonObject = new JSONObject();
						
						
						String strkey = masterdtl.getStrparamcd();
						String strVal = masterdtl.getStrcddesc().trim();

						childjsonObject.put("key",strkey);							
						childjsonObject.put("val",strVal);
						allistsystem.add(childjsonObject);
					}	
					
					
					
					List<UserParameterList> oComListDetails1 =  (List<UserParameterList>) dBService.getList("com.majesco.dcf.common.tagic.entity.UserParameterList","iparamtypecd",masterList.getIparamtypecd());
					for(UserParameterList masterdtl1:oComListDetails1){
						
						JSONObject childjsonObject1 = new JSONObject();
						
						
						String strkey1 = masterdtl1.getStrparamcd();
						String strVa1l = masterdtl1.getStrcddesc().trim();

						childjsonObject1.put("key",strkey1);							
						childjsonObject1.put("val",strVa1l);
						
						allistsystem.add(childjsonObject1);
						
					//allistsystem.add(childjsonObject);
					}	
					
					
					String strid=masterList.getIparamtypecd()!=null?masterList.getIparamtypecd().toString():"";
					String strKey = masterList.getStrtypedesc();
					jsonObject.put(strKey,allistsystem);
					
				}
				
				
			} catch (Exception  e) {
				e.printStackTrace();
				logger.info("Inside GenerateCacheService :: getMasterData method :: Exception Occurred : "+e.toString());
			}
			/*if(logger.isDebugEnabled()){
				logger.debug("Out GenerateCacheService.getMasterData Method ehcache running....."+jsonObject);
			}*/
			
			logger.info("Inside GenerateCacheService :: getMasterData method :: Execution Completed Successfully");
			
			return  jsonObject;
		}
	
	@Cacheable(cacheName="branchEhcache")
	public JSONObject getBranchMaster() {
		JSONObject jsonObject = new JSONObject();
		try {
			/*if(logger.isDebugEnabled()){
				logger.debug("In GenerateCacheService.getBranchMaster Method loading echache...");
			}*/
			
			logger.info("Inside GenerateCacheService :: getBranchMaster method :: Execution Started");
			
			List<BranchMaster> oComMasterList =  (List<BranchMaster>) dBService.getBranch("com.majesco.dcf.common.tagic.entity.BranchMaster");
			for(BranchMaster masterList:oComMasterList){
			
				String strval=masterList.getStrbranchname()!=null?masterList.getStrbranchname().toString():"";
				String strKey = masterList.getStrbranchcd().trim();
				jsonObject.put(strKey,strval);
				
				
			}
		
		
		}
		
		catch (Exception  e) {
				e.printStackTrace();
				logger.info("Inside GenerateCacheService :: getBranchMaster method :: Exception Occurred : "+e.toString());
			}	
			
		logger.info("Inside GenerateCacheService :: getBranchMaster method :: Execution Completed Successfully");		
		
	return 	jsonObject;
	}
	
	
	
	
	@Cacheable(cacheName="branchEhcache")
	public JSONObject getSchema() {
		JSONObject jsonObject = new JSONObject();
		try {
			/*if(logger.isDebugEnabled()){
				logger.debug("In GenerateCacheService.getSchema Method loading echache...");
			}*/
			
			logger.info("Inside GenerateCacheService :: getSchema method :: Execution Started");
			
			List<Masters> oComMasterList =  (List<Masters>) dBService.getSchema("com.majesco.dcf.common.tagic.entity.Masters");
			for(Masters masterList:oComMasterList){
			
				String strval=masterList.getId()!=null?masterList.getId().toString():"";
				String strKey = masterList.getId().trim();
				jsonObject.put(strKey,strval);
			}
		}
			catch (Exception  e) {
				e.printStackTrace();
				logger.info("Inside GenerateCacheService :: getSchema method :: Exception Occurred : "+e.toString());
			}	
		
		logger.info("Inside GenerateCacheService :: getSchema method :: Execution Completed Successfully");
		
	return 	jsonObject;
	}
	
	@Cacheable(cacheName="productEhcache")
    public JSONObject getProductMaster(String arg) {
           JSONObject jsonObject = new JSONObject();
           Map jsonMap = new LinkedHashMap();
           try {
                  /*if(logger.isDebugEnabled()){
                        logger.debug("In GenerateCacheService.getProductMaster Method loading echache...");
                  }*/
                  logger.info("Inside GenerateCacheService :: getProductMaster method :: Execution Started");
                  
                  List<Product> oComProductList =  (List<Product>) dBService.getProduct("com.majesco.dcf.common.tagic.entity.Product","strlobcd",arg);
                  for(Product productList:oComProductList){
                  
                        String strKey=productList.getStrprodcd()!=null?productList.getStrprodcd().toString():"";
                        String strval = productList.getStrprodname()!=null?productList.getStrprodname().toString():"";
                        jsonObject.put(strKey,strval);
                        //jsonMap.put(strKey, strval);
                        //System.out.println("xxxxxxx"+jsonObject.toString());
                        //System.out.println("xxxxxxx inside jsonMap"+jsonMap.toString());
                  }
                  //jsonObject.putAll(jsonMap);
                  //System.out.println("xxxxxxx inside jsonObject"+jsonObject.toString());
           }
                  catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getProductMaster method :: Exception Occurred : "+e.toString());
                  } 
           
           logger.info("Inside GenerateCacheService :: getProductMaster method :: Execution Completed Successfully");
           
    return jsonObject;
    }
    
    
    @Cacheable(cacheName="countryEhcache")
    public JSONObject getCountryMaster() {
           JSONObject jsonObject = new JSONObject();
           try {
                  /*if(logger.isDebugEnabled()){
                        logger.debug("In GenerateCacheService.getCountryMaster Method loading echache...");
                  }*/
                  
                  logger.info("Inside GenerateCacheService :: getCountryMaster method :: Execution Started");
                  
                  List<Country> oComCountryList =  (List<Country>) dBService.getCountry("com.majesco.dcf.common.tagic.entity.Country");
                  for(Country countryList:oComCountryList){
                  
                        String strval=countryList.getStrcountryname()!=null?countryList.getStrcountryname().toString():"";
                        String strKey =countryList.getStrcountrycd()!=null?countryList.getStrcountrycd().toString():""; 
                        jsonObject.put(strKey,strval);
                  
                  }
           }
                  catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getCountryMaster method :: Exception Occurred : "+e.toString());
                  }  
           
           logger.info("Inside GenerateCacheService :: getCountryMaster method :: Execution Completed Successfully");
    return jsonObject;
    }

    
 
    @Cacheable(cacheName="stateEhcache")
    public JSONObject getStateMaster(String countrycd) {
           JSONObject jsonObject = new JSONObject();
           try {
                  /*if(logger.isDebugEnabled()){
                        logger.debug("In GenerateCacheService.getStateMaster Method loading echache...");
                  }*/
                  
                  logger.info("Inside GenerateCacheService :: getStateMaster method :: Execution Started");
                  
                  List<State> oComStateList =  (List<State>) dBService.getState("com.majesco.dcf.common.tagic.entity.State","strcountrycd",countrycd);
                  for(State stateList:oComStateList){
                  
                        String strKey=stateList.getStrstatecd()!=null?stateList.getStrstatecd().toString():"";
                        String strval = stateList.getStrstatename()!=null?stateList.getStrstatename().toString():"";
                        jsonObject.put(strKey,strval);
                  
                  }
           }
                  catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getStateMaster method :: Exception Occurred : "+e.toString());
                  }
           
           logger.info("Inside GenerateCacheService :: getStateMaster method :: Execution Completed Successfully");
    return jsonObject;
    }

    @Cacheable(cacheName="masterEhcache")
    public JSONObject getMaster(String code) {
                  JSONObject jsonObject = new JSONObject();
                  JSONObject childjsonObject = null;
                  String isMasterFromJSONFile = null;
                  
                  try {
                        /*if(logger.isDebugEnabled()){
                               logger.debug("In GenerateCacheService.getMaster Method loading echache...");
                        }*/
                        
                        logger.info("Inside GenerateCacheService :: getMaster method :: Execution Started");
                        
                        List<ParameterList> oComMasterList =  (List<ParameterList>) dBService.get("com.majesco.dcf.common.tagic.entity.ParameterList","nsystemuser",code);

                        ServiceUtility su = new ServiceUtility();
                        JSONParser parser = new JSONParser();
                        isMasterFromJSONFile = su.getPropertyCodeProperty("IsMasterFromJSONFile", "resources.properties");
                        
                        if(isMasterFromJSONFile!=null && isMasterFromJSONFile.equals("true") && code!=null && code.equalsIgnoreCase("sys"))
                        {
                      	  logger.info("Inside GenerateCacheService :: getMaster method :: Getting Master Cache From File : SYS");
                      	  Object obj = parser.parse(new FileReader(su.getPropertyCodeProperty("master.data.json.sys", "resources.properties")));
                      	  jsonObject = (JSONObject) obj;
                        }
                        else if(isMasterFromJSONFile!=null && isMasterFromJSONFile.equals("true") && code!=null && code.equalsIgnoreCase("usr"))
                        {
                 		   logger.info("Inside GenerateCacheService :: getMaster method :: Getting Master Cache From File : USR");
                 		   Object obj = parser.parse(new FileReader(su.getPropertyCodeProperty("master.data.json.usr", "resources.properties")));
                 		  jsonObject = (JSONObject) obj;
                        }
                        else
                        {
	                        for(ParameterList masterList:oComMasterList){
	                               
	                               
	                               ArrayList allistsystem = new ArrayList();
	                               ArrayList allistuser = new ArrayList();
	                               Map<String, String> paramMap = new HashMap<String, String>();
	                               
	           
	                               if(code!=null && code.equalsIgnoreCase("sys"))
	                               {      
		                                    //System.out.println("INside SYStem param  masterList.getIparamtypecd() "+masterList.getIparamtypecd());
		                                    List<ParameterDetailList> oComListDetails =  (List<ParameterDetailList>) dBService.getList("com.majesco.dcf.common.tagic.entity.ParameterDetailList","iparamtypecd",masterList.getIparamtypecd());
		                                    childjsonObject = new JSONObject();
		                                    for(ParameterDetailList masterdtl:oComListDetails){
		                                           
		                                           String strkey = masterdtl.getStrparamcd();
		                                           String strVal = masterdtl.getStrcddesc().trim();
		                                             
		                                           //childjsonObject.put("key",strkey);                                         
		                                           childjsonObject.put(strkey,strVal);
		                                             
		                                    //allistsystem.add(childjsonObject);
		                                    }
	                                      
	                               }
	                               else if(code!=null && code.equalsIgnoreCase("usr"))
	                               {
	                                      List<UserParameterList> oComListDetails1 =  (List<UserParameterList>) dBService.getList("com.majesco.dcf.common.tagic.entity.UserParameterList","iparamtypecd",masterList.getIparamtypecd());
	                                      childjsonObject = new JSONObject();
	                                      for(UserParameterList masterdtl1:oComListDetails1){
	   
	                                             String strkey1 = masterdtl1.getStrparamcd();
	                                             String strVa1l = masterdtl1.getStrcddesc().trim();
	                                             
	                                             //childjsonObject1.put("key",strkey1);                                              
	                                             childjsonObject.put(strkey1,strVa1l);
	                                             
	                                             //allistsystem.add(childjsonObject);
	                                      }   
	                                      
	                               }
	                               String strid=masterList.getIparamtypecd()!=null?masterList.getIparamtypecd().toString():"";
	                               String strKey = masterList.getStrtypename();
	                               jsonObject.put(strKey,childjsonObject);
	                        }
                        }
                        
                        
                        
                  } catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getMaster method :: Exception Occurred : "+e.toString());
                  }
                  
                  logger.info("Inside GenerateCacheService :: getMaster method :: Execution Completed Successfully");
                  
                  /*if(logger.isDebugEnabled()){
                        logger.debug("Out GenerateCacheService.getMaster Method ehcache running....."+jsonObject);
                  }*/
                  return  jsonObject;
           }

    
    @Cacheable(cacheName="cityEhcache")
    public JSONObject getCityMaster(String stid,String type,String parentID) {
           JSONObject jsonObject = new JSONObject();
           try {
                  /*if(logger.isDebugEnabled()){
                        logger.debug("In GenerateCacheService.getCityMaster Method loading echache...");
                  }*/
                  
                  logger.info("Inside GenerateCacheService :: getCityMaster method :: Execution Started");
                  
                  List<City> oComCityList =  (List<City>) dBService.getCity("com.majesco.dcf.common.tagic.entity.City","strstatecd",stid,"ndistrictcityflag",type,"nparentid",parentID);
                  for(City cityList:oComCityList){
                  
                        String strKey=cityList.getStrcitycd()!=null?cityList.getStrcitycd().toString():"";
                        String strval = cityList.getStrcityname()!=null?cityList.getStrcityname().toString():"";
                        jsonObject.put(strKey,strval);
                  
                  }
           }
                  catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getCityMaster method :: Exception Occurred : "+e.toString());
                  } 
           
           logger.info("Inside GenerateCacheService :: getCityMaster method :: Execution Completed Successfully");
           
    return jsonObject;
    }
    
    
    @Cacheable(cacheName="manufEhcache")
    public JSONObject getManuFactMaster(String arg) {
           JSONObject jsonObject = new JSONObject();
           try {
                  /*if(logger.isDebugEnabled()){
                        logger.debug("In GenerateCacheService.getManuFactMaster Method loading echache...");
                  }*/
                  
                  logger.info("Inside GenerateCacheService :: getManuFactMaster method :: Execution Started");
                  
                  List<Manufact> oComManufactList =  (List<Manufact>) dBService.getManufact("com.majesco.dcf.common.tagic.entity.Manufact",arg);
                  for(Manufact manufactList:oComManufactList){
                  
                        String strval=manufactList.getStrmanufacturername()!=null?manufactList.getStrmanufacturername():"";
                        String strKey =manufactList.getStrmanufacturercd()!=null?manufactList.getStrmanufacturercd():""; 
                        jsonObject.put(strKey,strval);
                  
                  }
           }
                  catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getManuFactMaster method :: Exception Occurred : "+e.toString());
                  }   
           
           logger.info("Inside GenerateCacheService :: getManuFactMaster method :: Execution Completed Successfully");
           
    return jsonObject;
    }
    
    
    /*@Cacheable(cacheName="modelEhcache")
    public JSONObject getModelInfo(ModelRequest modelreq) {
           JSONObject jsonObject = new JSONObject();
           try {
                  if(logger.isDebugEnabled()){
                        logger.debug("In GenerateCacheService.getModelInfo Method loading echache...");
                  }
                  
                  logger.info("Inside GenerateCacheService :: getModelInfo method :: Execution Started");
                  
                  List<Model> oComMotorList =  (List<Model>) dBService.getModelInfo("com.majesco.dcf.common.tagic.entity.Model", modelreq);
                  for(Model motorList:oComMotorList){
                  
                        String strKey=motorList.getStrmodelcd()!=null?motorList.getStrmodelcd().toString():"";
                        String strval = motorList.getStrmodelnumber()!=null?motorList.getStrmodelnumber().toString():"";
                        jsonObject.put(strKey,strval);
                  
                  }
           }
                  catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getModelInfo method :: Exception Occurred : "+e.toString());
                  }   
           
           logger.info("Inside GenerateCacheService :: getModelInfo method :: Execution Completed Successfully");
           
    return jsonObject;
    }*/
    
    
    
    public JSONObject getVarInfo(VehicleVariantRequest modelreq) {
           JSONObject jsonObject = new JSONObject();
           try {
                  /*if(logger.isDebugEnabled()){
                        logger.debug("In GenerateCacheService.getVarInfo Method loading echache...");
                  }*/
                  
                  logger.info("Inside GenerateCacheService :: getModelInfo method :: Execution Started");
                  
                  List<Model> oComMotorList =  (List<Model>) dBService.getVarInfo("com.majesco.dcf.common.tagic.entity.Model",modelreq);
                  for(Model motorList:oComMotorList){
                  
                        String strKey=motorList.getStrvariant()!=null?motorList.getStrvariant():"";
                        String strval = motorList.getStrvariant()!=null?motorList.getStrvariant():"";
                        jsonObject.put(strKey,strval);
                  
                  }
           }
                  catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getModelInfo method :: Exception Occurred : "+e.toString());
                  }  
           
           logger.info("Inside GenerateCacheService :: getModelInfo method :: Execution Completed Successfully");
           
    return jsonObject;
    }
    
    
    @Cacheable(cacheName="vehclfEhcache")
    public JSONObject getVehicleClass(String arg) {
           JSONObject jsonObject = new JSONObject();
           try {
                  /*if(logger.isDebugEnabled()){
                        logger.debug("In GenerateCacheService.getVehicleClass Method loading echache...");
                  }*/
                  
                  logger.info("Inside GenerateCacheService :: getVehicleClass method :: Execution Started");
                  
                  List<VehicleClass> oComvehclList =  (List<VehicleClass>) dBService.getVehicleClass("com.majesco.dcf.common.tagic.entity.VehicleClass","strvehiclecatcd",arg);
                  for(VehicleClass vehclList:oComvehclList){
                  
                        String strKey=vehclList.getStrvehicleclasscd()!=null?vehclList.getStrvehicleclasscd():"";
                        String strval = vehclList.getStrvehicleclassdesc()!=null?vehclList.getStrvehicleclassdesc():"";
                        jsonObject.put(strKey,strval);
                  
                  }
           }
                  catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getVehicleClass method :: Exception Occurred : "+e.toString());
                  }   
           
           logger.info("Inside GenerateCacheService :: getVehicleClass method :: Execution Completed Successfully");
           
    return jsonObject;
    }
	
    
    @Cacheable(cacheName="vehsubclfEhcache")
    public JSONObject getVehicleSubClass(String arg) {
           JSONObject jsonObject = new JSONObject();
           try {
                  /*if(logger.isDebugEnabled()){
                        logger.debug("In GenerateCacheService.getVehicleSubClass Method loading echache...");
                  }*/
                  
                  logger.info("Inside GenerateCacheService :: getVehicleSubClass method :: Execution Started");
                  
                  List<VehicleSubClass> oComvehsbclList =  (List<VehicleSubClass>) dBService.getVehicleSubClass("com.majesco.dcf.common.tagic.entity.VehicleSubClass","strvehicleclasscd",arg);
                  for(VehicleSubClass vehsbclList:oComvehsbclList){
                  
                        String strKey=vehsbclList.getStrvehiclesubclasscd() .toString()!=null?vehsbclList.getStrvehiclesubclasscd().toString():"";
                        String strval = vehsbclList.getStrvehiclesubclassdesc()!=null?vehsbclList.getStrvehiclesubclassdesc():"";
                        jsonObject.put(strKey,strval);
                  
                  }
           }
                  catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getVehicleSubClass method :: Exception Occurred : "+e.toString());
                  }
           
           logger.info("Inside GenerateCacheService :: getVehicleSubClass method :: Execution Completed Successfully");
           
    return jsonObject;
    }
    
    
    @Cacheable(cacheName="rtolocclfEhcache")
    public JSONObject getRTOLocation() {
           JSONObject jsonObject = new JSONObject();
           try {
                  /*if(logger.isDebugEnabled()){
                        logger.debug("In GenerateCacheService.getRTOLocation Method loading echache...");
                  }*/
                  
                  logger.info("Inside GenerateCacheService :: getRTOLocation method :: Execution Started");
                  
                  List<RTOLocation> oComrtoList =  (List<RTOLocation>) dBService.getRTOLocation("com.majesco.dcf.common.tagic.entity.RTOLocation");
                  for(RTOLocation rtoList:oComrtoList){
                  
                        String strKey=rtoList.getStrrtolocationcd().toString()!=null?rtoList.getStrrtolocationcd().toString():"";
                        String strval = rtoList.getStrrtolocationdesc()!=null?rtoList.getStrrtolocationdesc():"";
                        jsonObject.put(strKey,strval);
                  
                  }
           }
                  catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getRTOLocation method :: Exception Occurred : "+e.toString());
                  }
           
           logger.info("Inside GenerateCacheService :: getRTOLocation method :: Execution Completed Successfully");
    return jsonObject;
    }
    
    
//    public String getWSDLURL(String interfaceid) {
//    	
//    	String wsdlURL = "";
//    	
//           try {
//        	   
//        	   wsdlURL = dBService.getWSDLURL(interfaceid, "com.majesco.dcf.common.tagic.entity.InterfaceParam");
//                  
//           }
//                  catch (Exception  e) {
//                        e.printStackTrace();
//                        logger.info("Inside GenerateCacheService :: getWSDLURL method :: Exception Occurred : "+e.toString());
//                  }
//           
//           logger.info("Inside GenerateCacheService :: getWSDLURL method :: Execution Completed Successfully");
//    return wsdlURL;
//    }
    
    
    @Cacheable(cacheName="secquestEhcache")
    public JSONObject getSecurityQuestion() {
           JSONObject jsonObject = new JSONObject();
           try {
                  /*if(logger.isDebugEnabled()){
                        logger.debug("In GenerateCacheService.getSecurityQuestion Method loading echache...");
                  }*/
                  
                  logger.info("Inside GenerateCacheService :: getSecurityQuestion method :: Execution Started");
                  
                  List<SecurityQuestion> oComrtoList =  (List<SecurityQuestion>) dBService.getSecurityQuestion("com.majesco.dcf.common.tagic.entity.SecurityQuestion");
                  for(SecurityQuestion rtoList:oComrtoList){
                  
                        Integer strKey=(Integer) (rtoList.getNquestioncd()!=null?rtoList.getNquestioncd():"");
                        String strval = rtoList.getStrquesdesc()!=null?rtoList.getStrquesdesc():"";
                        jsonObject.put(strKey,strval);
                  
                  }
           }
                  catch (Exception  e) {
                        e.printStackTrace();
                        logger.info("Inside GenerateCacheService :: getSecurityQuestion method :: Exception Occurred : "+e.toString());
                  }
           
           logger.info("Inside GenerateCacheService :: getSecurityQuestion method :: Execution Completed Successfully");
    return jsonObject;
    }

   /*@Cacheable(cacheName="subcategoryEhcache")
   public JSONObject getSubCategory(String arg) {
	   JSONObject jsonObject = new JSONObject();
       try {
              if(logger.isDebugEnabled()){
                    logger.debug("In GenerateCacheService.getSubCategory Method loading echache...");
              }
              
              logger.info("Inside GenerateCacheService :: getSubCategory method :: Execution Started");
              
              List<SubCategory> subcategoryList =  (List<SubCategory>) dBService.getSubCategory("com.majesco.dcf.common.tagic.entity.SubCategory","strcategorycd",arg);
              for(SubCategory lst:subcategoryList){
                  
                  String strKey=lst.getStrsubcategorycd().toString()!=null?lst.getStrsubcategorycd().toString():"";
                  String strval = lst.getStrsubcategorydesc()!=null?lst.getStrsubcategorydesc():"";
                  jsonObject.put(strKey,strval);
            
            }
       }
      catch (Exception  e) {
            e.printStackTrace();
            logger.info("Inside GenerateCacheService :: getSubCategory method :: Exception Occurred : "+e.toString());
      }          
       logger.info("Inside GenerateCacheService :: getSubCategory method :: Execution Completed Successfully");
       
       return jsonObject;
   }*/
   /*-----------------------Added by Nikhil570154 from here-------------------*/
   @Cacheable(cacheName="companymasterEhcache")
   public JSONObject getCompanyMaster() {
          JSONObject jsonObject = new JSONObject();
          try {
                 /*if(logger.isDebugEnabled()){
                       logger.debug("In GenerateCacheService.getCompanyMaster Method loading echache...");
                 }*/
                 
                 logger.info("Inside GenerateCacheService :: getCompanyMaster method :: Execution Started");
                 
                 List<CompanyMaster> oComrtoList =  (List<CompanyMaster>) dBService.getCompanyMaster("com.majesco.dcf.common.tagic.entity.CompanyMaster");
                 for(CompanyMaster rtoList:oComrtoList){
                 
                       String strKey = rtoList.getStrcompanycd()!=null?rtoList.getStrcompanycd():"";
                       String strval = rtoList.getStrcompanyname()!=null?rtoList.getStrcompanyname():"";
                       jsonObject.put(strKey,strval);
                 }
          }
                 catch (Exception  e) {
                       e.printStackTrace();
                       logger.info("Inside GenerateCacheService :: getCompanyMaster method :: Exception Occurred : "+e.toString());
                 }
          
          logger.info("Inside GenerateCacheService :: getCompanyMaster method :: Execution Completed Successfully");
          return jsonObject;
   }
   
   @Cacheable(cacheName="financierEhcache")
   public JSONObject genFinancierMaster(String arg) {
          JSONObject jsonObject = new JSONObject();
          try {
                 /*if(logger.isDebugEnabled()){
                       logger.debug("In GenerateCacheService.genFinancierMaster Method loading echache...");
                 }*/
                 
                 logger.info("Inside GenerateCacheService :: genFinancierMaster method :: Execution Started");
                 
                 List<FinancierMaster> oComrtoList =  (List<FinancierMaster>) dBService.getFinancierMaster("com.majesco.dcf.common.tagic.entity.FinancierMaster",arg);
                 for(FinancierMaster rtoList:oComrtoList){
                 
                       String strKey = rtoList.getStrfinanciercd()!=null?rtoList.getStrfinanciercd():"";
                       String strval = rtoList.getStrfinanciername() !=null?rtoList.getStrfinanciername():"";
                       jsonObject.put(strKey,strval);
                 }
          }
         catch (Exception  e) {
              e.printStackTrace();
              logger.info("Inside GenerateCacheService :: genFinancierMaster method :: Exception Occurred : "+e.toString());
         }
          
         logger.info("Inside GenerateCacheService :: genFinancierMaster method :: Execution Completed Successfully");
         return jsonObject;
   }
   
   /*@Cacheable(cacheName="officemasterEhcache")
   public List getOfficeMaster() {
          JSONObject jsonObject = new JSONObject();
          List<String> office = new ArrayList<String>();
          List<String> officeccode = new ArrayList<String>();
          List<String> parentofficecode = new ArrayList<String>();
          List<String> officedesc= new ArrayList<String>();
          List<String> strofficecode = new ArrayList<String>();
          List<String> strparentofccode = new ArrayList<String>();
          ArrayList<String> returnlist = new ArrayList<String>();
          try {
                 if(logger.isDebugEnabled()){
                       logger.debug("In GenerateCacheService.getOfficeMaster Method loading echache...");
                 }
                 
                 logger.info("Inside GenerateCacheService :: getOfficeMaster method :: Execution Started");
                 
                 List<OfficeMaster> oComrtoList =  (List<OfficeMaster>) dBService.getOfficeMaster("com.majesco.dcf.common.tagic.entity.OfficeMaster");
                 for(OfficeMaster rtoList:oComrtoList){
                	 	
                       //String strKey = rtoList.getNofficecd() !=null?rtoList.getNofficecd().toString():"";
                       //String strval = rtoList.getStrofficedesc() !=null?rtoList.getStrofficedesc():"";
                       office.add(rtoList.getOffice());
                       officeccode.add(rtoList.getNofficecd().toString());
                       parentofficecode.add(rtoList.getNparentofficecd().toString());
                       officedesc.add(rtoList.getStrofficedesc());
                       strofficecode.add(rtoList.getStrofficecd());
                       strparentofccode.add(rtoList.getStrparentofficecd());
                       //jsonObject.put(strKey,strval);
                 }
                 returnlist.addAll(office);
                 returnlist.addAll(officeccode);
                 returnlist.addAll(parentofficecode);
                 returnlist.addAll(officedesc);
                 returnlist.addAll(strofficecode);
                 returnlist.addAll(strparentofccode);
                 
                 for(int i=0;i<returnlist.size();i++){
                	 
                	 jsonObject.put(i,returnlist.get(i));
                 }
                 jsonObject.put("Office",office);
                 jsonObject.put("nofficecd",officeccode);
                 jsonObject.put("nparentofficecd",parentofficecode);
                 jsonObject.put("strofficedesc",officedesc);
                 jsonObject.put("strofficecd",strofficecode);
                 //jsonObject.put("strparentofficecd",strparentofccode);
          }
         catch (Exception  e) {
              e.printStackTrace();
              logger.info("Inside GenerateCacheService :: getOfficeMaster method :: Exception Occurred : "+e.toString());
         }
          
         logger.info("Inside GenerateCacheService :: getOfficeMaster method :: Execution Completed Successfully");
         return returnlist;
   }*/
   
@SuppressWarnings("unchecked")
@Cacheable(cacheName="cityEhcache")
   public JSONObject getCityVehicleUsedMaster(String cityName) {
          JSONObject jsonObject = new JSONObject();
          ArrayList<Object[]> resultData = new ArrayList();
          ObjectMapper objMapper = new ObjectMapper();
          List<City> responseList = new ArrayList<City>();
          try {
                 /*if(logger.isDebugEnabled()){
                       logger.debug("In GenerateCacheService.getSecurityQuestion Method loading echache...");
                 }*/
                 
                 logger.info("Inside GenerateCacheService :: getSecurityQuestion method :: Execution Started");
                 
                 //****Old***
                 /*List<City> oComrtoList =  (List<City>) dBService.getCityVehUsed("com.majesco.dcf.common.tagic.entity.City", "%"+cityName+"%");
                 for(City rtoList:oComrtoList){
                 
                       String strKey=rtoList.getStrcitycd()!=null?rtoList.getStrcitycd():"";
                       String strval = rtoList.getStrcityname()!=null?rtoList.getStrcityname():"";
                       jsonObject.put(strKey,strval);
                 
                 }*/
                 
               //Start:17-12-2016 New Impl with parameterized method @yogesh
                 resultData = dBService.getCityVehUsed("com.majesco.dcf.common.tagic.entity.City", "%"+cityName+"%");
                 logger.info("getCityVehicleUsedMasterList :: response-JSON--> " + objMapper.writeValueAsString(resultData));
                 
                 for(Object[] row : resultData)
 				{
 					//ArrayList testArray = new ArrayList();
 					logger.info("getCityVehicleUsedMasterList :: row--> " + objMapper.writeValueAsString(row));
 					City response = new City();
 					
 					BigInteger bigInt = new BigInteger(row[0].toString());
 					
 					response.setStrcitycd((String) nullCheckString(row[0])); 
 		            response.setStrcityname((String) nullCheckString(row[1]));
 					responseList.add(response);
 				}
 				logger.info("getCityVehicleUsedMasterList :: response Object--> " + objMapper.writeValueAsString(responseList));
 				//End:17-12-2016 New Impl with parameterized method  @yogesh 
 				
 				for(City rtoList:responseList){
 	                 
                    String strKey=rtoList.getStrcitycd()!=null?rtoList.getStrcitycd():"";
                    String strval = rtoList.getStrcityname()!=null?rtoList.getStrcityname():"";
                    jsonObject.put(strKey,strval);
              
              }
                 
                 
          }
                 catch (Exception  e) {
                       e.printStackTrace();
                       logger.info("Inside GenerateCacheService :: getSecurityQuestion method :: Exception Occurred : "+e.toString());
                 }
          
          logger.info("Inside GenerateCacheService :: getSecurityQuestion method :: Execution Completed Successfully");
   return jsonObject;
   }
   
   @Cacheable(cacheName="subagentEhcache")
   public JSONObject getSubAgentMaster(String arg,String arg1) {
          JSONObject jsonObject = new JSONObject();
          try {
                 /*if(logger.isDebugEnabled()){
                       logger.debug("In GenerateCacheService.getSubAgentMaster Method loading echache...");
                 }*/
                 
                 logger.info("Inside GenerateCacheService :: getSubAgentMaster method :: Execution Started");
                 
                 List<SubAgentMaster> oComrtoList =  (List<SubAgentMaster>) dBService.getSubAgentMaster("com.majesco.dcf.common.tagic.entity.SubAgentMaster",arg,arg1);
                 for(SubAgentMaster rtoList:oComrtoList){
                       String strKey=rtoList.getStrsubagentcd()!=null?rtoList.getStrsubagentcd():"";
                       String strval = rtoList.getStrsubagentname()!=null?rtoList.getStrsubagentname():"";
                       jsonObject.put(strKey,strval);
                 }
          }
                 catch (Exception  e) {
                       e.printStackTrace();
                       logger.info("Inside GenerateCacheService :: getSubAgentMaster method :: Exception Occurred : "+e.toString());
                 }
          
          logger.info("Inside GenerateCacheService :: getSubAgentMaster method :: Execution Completed Successfully");
          return jsonObject;
   }
   
   @Cacheable(cacheName="misctypevehEhcache")
   public JSONObject getMiscType() {
          JSONObject jsonObject = new JSONObject();
          try {
                /* if(logger.isDebugEnabled()){
                       logger.debug("In GenerateCacheService.getMiscType Method loading echache...");
                 }*/
                 logger.info("Inside GenerateCacheService :: getMiscType method :: Execution Started");
                 
                 List<VehicleSubClass> oComvehsbclList =  (List<VehicleSubClass>) dBService.getMiscType("com.majesco.dcf.common.tagic.entity.VehicleSubClass");
                 for(VehicleSubClass vehsbclList:oComvehsbclList){
                 
                       String strKey=vehsbclList.getStrvehiclesubclasscd().toString()!=null?vehsbclList.getStrvehiclesubclasscd().toString():"";
                       String strval = vehsbclList.getStrvehiclesubclassdesc()!=null?vehsbclList.getStrvehiclesubclassdesc():"";
                       jsonObject.put(strKey,strval);
                 }
          }
         catch (Exception  e) {
               e.printStackTrace();
               logger.info("Inside GenerateCacheService :: getMiscType method :: Exception Occurred : "+e.toString());
         }
          
          logger.info("Inside GenerateCacheService :: getMiscType method :: Execution Completed Successfully");
          
          return jsonObject;
   }
   
   @Cacheable(cacheName="garagecitymasterEhcache")
   public JSONObject getGarageCityMaster(){
          JSONObject jsonObject = new JSONObject();
          List<String> strsettlingoffice = new ArrayList<String>();
          List<BigDecimal> nserviceofficecd = new ArrayList<BigDecimal>();
          List<BigDecimal> ncitycd = new ArrayList<BigDecimal>();

          List returnlist = new ArrayList();
		try {
                /* if(logger.isDebugEnabled()){
                       logger.debug("In GenerateCacheService.getGarageCityMaster Method loading echache...");
                 }*/
                 
                 logger.info("Inside GenerateCacheService :: getGarageCityMaster method :: Execution Started");
                 
                 List<GarageCityMaster> oComrtoList =  (List<GarageCityMaster>) dBService.getGarageCityMaster("com.majesco.dcf.common.tagic.entity.GarageCityMaster");
                 for(GarageCityMaster rtoList:oComrtoList){
                	 	
                       //String strKey = rtoList.getNofficecd() !=null?rtoList.getNofficecd().toString():"";
                       //String strval = rtoList.getStrofficedesc() !=null?rtoList.getStrofficedesc():"";
                	 strsettlingoffice.add(rtoList.getStrsettlingoffice());
                	 nserviceofficecd.add(rtoList.getNserviceofficecd());
                	 ncitycd.add(rtoList.getNcitycd());
                       
                       //jsonObject.put(strKey,strval);
                 }
                 returnlist.addAll(strsettlingoffice);
                 returnlist.addAll(nserviceofficecd);
                 returnlist.addAll(ncitycd);
                 
                 
                 /*for(int i=0;i<returnlist.size();i++){
                	 
                	 jsonObject.put(i,returnlist.get(i));
                 }*/
                 jsonObject.put("strsettlingoffice",strsettlingoffice);
                 jsonObject.put("nserviceofficecd",nserviceofficecd);
                 jsonObject.put("ncitycd",ncitycd);
                 
          }
         catch (Exception  e) {
              e.printStackTrace();
              logger.info("Inside GenerateCacheService :: getGarageCityMaster method :: Exception Occurred : "+e.toString());
         }
          
         logger.info("Inside GenerateCacheService :: getOfficeMaster method :: Execution Completed Successfully");
         return jsonObject;
   }
   
   @Cacheable(cacheName="claimDocEhcache")
   public JSONObject getClaimDocs(String arg) {
          JSONObject jsonObject = new JSONObject();
          try {
                 /*if(logger.isDebugEnabled()){
                       logger.debug("In GenerateCacheService.getClaimDocs Method loading echache...");
                 }*/
                 
                 logger.info("Inside GenerateCacheService :: getClaimDocs method :: Execution Started");
                 
                 List<ClaimDocMaster> oComrtoList =  (List<ClaimDocMaster>) dBService.getClaimDocs("com.majesco.dcf.common.tagic.entity.ClaimDocMaster", arg);
                 for(ClaimDocMaster rtoList:oComrtoList){
                     String strKey = rtoList.getStrdoccd() !=null?rtoList.getStrdoccd().toString():"";
                     String strval = rtoList.getStrdcodesc() !=null?rtoList.getStrdcodesc():"";
                     jsonObject.put(strKey,strval);
               }
                 //jsonObject.put(lst);
          }	
                 catch (Exception  e) {
                       e.printStackTrace();
                       logger.info("Inside GenerateCacheService :: getClaimDocs method :: Exception Occurred : "+e.toString());
                 }   
          
          logger.info("Inside GenerateCacheService :: getClaimDocs method :: Execution Completed Successfully");
          
   return jsonObject;
   }
   @Cacheable(cacheName="getEmailEhcache")
   public String getEmail(String arg,Integer arg1) {
          JSONObject jsonObject = new JSONObject();
          try {
                 /*if(logger.isDebugEnabled()){
                       logger.debug("In GenerateCacheService.getEmail Method loading echache...");
                 }*/
                 
                 logger.info("Inside GenerateCacheService :: getEmail method :: Execution Started");
                 String email;
                 email = dBService.getEmail(arg,arg1);
                //email = lst.get(0);
                jsonObject.put("email",email);
          	}	
                 catch (Exception  e) {
                       e.printStackTrace();
                       logger.info("Inside GenerateCacheService :: getEmail method :: Exception Occurred : "+e.toString());
                 }   
          
          logger.info("Inside GenerateCacheService :: getEmail method :: Execution Completed Successfully");
          
   return jsonObject.toString();
   }
   
   @Cacheable(cacheName="getContactNoEhcache")
   public List<? extends Object> getContactno(String arg) {
          //JSONObject jsonObject = new JSONObject();
          List arr = new ArrayList();
          try {
                 /*if(logger.isDebugEnabled()){
                       logger.debug("In GenerateCacheService.getContactno Method loading echache...");
                 }*/
                 
                 logger.info("Inside GenerateCacheService :: getContactno method :: Execution Started");
                 
                 arr = dBService.getContactno(arg);
                //email = lst.get(0);
                //jsonObject.put("res",arr);
          	}	
                 catch (Exception  e) {
                       e.printStackTrace();
                       logger.info("Inside GenerateCacheService :: getContactno method :: Exception Occurred : "+e.toString());
                 }   
          
          logger.info("Inside GenerateCacheService :: getContactno method :: Execution Completed Successfully");
          
   return arr;
   }
   
   @Cacheable(cacheName="getProducerDetEhcache")
   public List<? extends Object> getProducerDet(String arg) {
          //JSONObject jsonObject = new JSONObject();
          List arr = new ArrayList();
          try {
                 /*if(logger.isDebugEnabled()){
                       logger.debug("In GenerateCacheService.getProducerDet Method loading echache...");
                 }*/
                 
                 logger.info("Inside GenerateCacheService :: getProducerDet method :: Execution Started");
                 
                 arr = dBService.getProducerDet(arg);
                //email = lst.get(0);
                //jsonObject.put("res",arr);
          	}	
                 catch (Exception  e) {
                       e.printStackTrace();
                       logger.info("Inside GenerateCacheService :: getProducerDet method :: Exception Occurred : "+e.toString());
                 }   
          
          logger.info("Inside GenerateCacheService :: getProducerDet method :: Execution Completed Successfully");
          
          return arr;
   }
   
   @Cacheable(cacheName="reportsEhcache")
   public JSONObject getReports(){
	   JSONObject jsonObject = new JSONObject();
       try {
              /*if(logger.isDebugEnabled()){
                    logger.debug("In GenerateCacheService.getReports Method loading echache...");
              }*/
              
              logger.info("Inside GenerateCacheService :: getReports method :: Execution Started");
              
              List<ReportsMaster> oComrtoList =  (List<ReportsMaster>) dBService.getReports("com.majesco.dcf.common.tagic.entity.ReportsMaster");
              for(ReportsMaster rtoList:oComrtoList){
              
                    String strKey = rtoList.getNrepid() !=null?rtoList.getNrepid().toString():"";
                    String strval = rtoList.getStrrepname()!=null?rtoList.getStrrepname():"";
                    jsonObject.put(strKey,strval);
              }
       }
              catch (Exception  e) {
                    e.printStackTrace();
                    logger.info("Inside GenerateCacheService :: getReports method :: Exception Occurred : "+e.toString());
              }
       
       logger.info("Inside GenerateCacheService :: getReports method :: Execution Completed Successfully");
       return jsonObject;
   }
   /*-----------------------Added by Nikhil570154 till here-------------------*/
   
   @Cacheable(cacheName="propStatusCache")
   public JSONObject getProposalStatusCache(DBService dbService){
		HashMap statusMap = new HashMap();
		JSONObject childjsonObject = null;
       try {
              /*if(logger.isDebugEnabled()){
                    logger.debug("In GenerateCacheService.getProposalStatusCache Method loading echache...");
              }*/
              
              logger.info("Inside GenerateCacheService :: getProposalStatusCache method :: Execution Started");
              
              List<ParameterDetailList> oComListDetails =  (List<ParameterDetailList>) dbService.getList("com.majesco.dcf.common.tagic.entity.ParameterDetailList","iparamtypecd",1097);
              childjsonObject = new JSONObject();
              for(ParameterDetailList masterdtl:oComListDetails){
                     
                     String strkey = masterdtl.getStrparamcd();
                     String strVal = masterdtl.getStrcddesc().trim();
                                                               
                     childjsonObject.put(strkey,strVal);
              }
       }
              catch (Exception  e) {
                    e.printStackTrace();
                    logger.error("Inside GenerateCacheService :: getProposalStatusCache method :: Exception Occurred : "+e.toString());
              }
       
       logger.info("Inside GenerateCacheService :: getProposalStatusCache method :: Execution Completed Successfully");
       return childjsonObject;
   }
   
   public String nullCheckString(Object obj)
   {
 	  if(obj==null)
 		  return "";
 	  else
 		  return (String) obj;
   }
   
}
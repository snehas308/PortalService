package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "dcf_pmtflow_flags")
public class PmtFlowFlags implements Serializable {
	
	@Id
	@Column(name = "str_proposal_no")
	private String strproposalno;
	
	@Column(name = "str_created_by")
	private String strcreatedby;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "dt_created" )
	private Date dtcreated;
			
	@Column(name = "str_lob_type")
	private String strlobtype;
	
	@Type(type="org.hibernate.type.StringClobType")
	@Column(name = "str_proposal_req")
	private String strproposalreq;
		
	@Column(name = "str_proposal_flag")
	private String strproposalflag;
	
	
	@Column(name = "str_receipt_entry_flag")
	private String strreceiptentryflag;
	
	@Column(name = "str_proposal_tagging_flag")
	private String strproposaltaggingflag;
	
	@Type(type="org.hibernate.type.StringClobType")
	@Column(name = "str_pdf_gen_req")
	private String strpdfgenreq;

	@Column(name = "str_pdf_gen_flag")
	private String strpdfgenflag;
	
	@Column(name = "str_final_status")
	private String strfinalstatus;

	@Column(name = "str_payment_no")
	private String strpaymnetno;
	
	@Column(name = "str_screen_ref_no")
	private String strscreenrefno;
	
	@Column(name = "str_receipt_no")
	private String strreceiptno;
	
	@Column(name = "str_policy_no")
	private String strpolicyno;
	
	@Column(name = "str_count")
	private String strcount;

	@Column(name = "str_error_msg_receipt_BFL")
	private String strerrormsginreceiptBfl;
	
	@Column(name = "str_error_msg_prop_tag")
	private String strerrormsginproptag;
	
	@Column(name = "str_error_msg_pdf_gen")
	private String strerrormsginpdfgen;

	
	public String getStrproposalno() {
		return strproposalno;
	}

	public void setStrproposalno(String strproposalno) {
		this.strproposalno = strproposalno;
	}

	public String getStrcreatedby() {
		return strcreatedby;
	}

	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}

	public Date getDtcreated() {
		return dtcreated;
	}

	public void setDtcreated(Date dtcreated) {
		this.dtcreated = dtcreated;
	}

	public String getStrlobtype() {
		return strlobtype;
	}

	public void setStrlobtype(String strlobtype) {
		this.strlobtype = strlobtype;
	}

	public String getStrproposalreq() {
		return strproposalreq;
	}

	public void setStrproposalreq(String strproposalreq) {
		this.strproposalreq = strproposalreq;
	}

	public String getStrproposalflag() {
		return strproposalflag;
	}

	public void setStrproposalflag(String strproposalflag) {
		this.strproposalflag = strproposalflag;
	}

	public String getStrreceiptentryflag() {
		return strreceiptentryflag;
	}

	public void setStrreceiptentryflag(String strreceiptentryflag) {
		this.strreceiptentryflag = strreceiptentryflag;
	}



	public String getStrfinalstatus() {
		return strfinalstatus;
	}

	public void setStrfinalstatus(String strfinalstatus) {
		this.strfinalstatus = strfinalstatus;
	}

	public String getStrpaymnetno() {
		return strpaymnetno;
	}

	public void setStrpaymnetno(String strpaymnetno) {
		this.strpaymnetno = strpaymnetno;
	}

	public String getStrscreenrefno() {
		return strscreenrefno;
	}

	public void setStrscreenrefno(String strscreenrefno) {
		this.strscreenrefno = strscreenrefno;
	}

	public String getStrreceiptno() {
		return strreceiptno;
	}

	public void setStrreceiptno(String strreceiptno) {
		this.strreceiptno = strreceiptno;
	}

	public String getStrpolicyno() {
		return strpolicyno;
	}

	public void setStrpolicyno(String strpolicyno) {
		this.strpolicyno = strpolicyno;
	}

	public String getStrcount() {
		return strcount;
	}

	public void setStrcount(String strcount) {
		this.strcount = strcount;
	}


	
	public String getStrpdfgenreq() {
		return strpdfgenreq;
	}

	public void setStrpdfgenreq(String strpdfgenreq) {
		this.strpdfgenreq = strpdfgenreq;
	}

	public String getStrpdfgenflag() {
		return strpdfgenflag;
	}

	public void setStrpdfgenflag(String strpdfgenflag) {
		this.strpdfgenflag = strpdfgenflag;
	}
	
	public String getStrproposaltaggingflag() {
		return strproposaltaggingflag;
	}

	public void setStrproposaltaggingflag(String strproposaltaggingflag) {
		this.strproposaltaggingflag = strproposaltaggingflag;
	}
	
	public String getStrerrormsginreceiptBfl() {
		return strerrormsginreceiptBfl;
	}

	public void setStrerrormsginreceiptBfl(String strerrormsginreceiptBfl) {
		this.strerrormsginreceiptBfl = strerrormsginreceiptBfl;
	}

	public String getStrerrormsginproptag() {
		return strerrormsginproptag;
	}

	public void setStrerrormsginproptag(String strerrormsginproptag) {
		this.strerrormsginproptag = strerrormsginproptag;
	}

	public String getStrerrormsginpdfgen() {
		return strerrormsginpdfgen;
	}

	public void setStrerrormsginpdfgen(String strerrormsginpdfgen) {
		this.strerrormsginpdfgen = strerrormsginpdfgen;
	}
	

}



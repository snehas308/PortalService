package com.majesco.dcf.paproduct.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.CustomerDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PAQuickQuotPrmResponse {
	private String resultCode; 
	private String planCode;
	private String qutationNo;
	private PremiumDetailsQuot premDetlst;
	private CustomerDetails proposerDet;
	private List<ResponseError> resErr;
	
	
	
	public CustomerDetails getProposerDet() {
		return proposerDet;
	}
	public void setProposerDet(CustomerDetails proposerDet) {
		this.proposerDet = proposerDet;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getQutationNo() {
		return qutationNo;
	}
	public void setQutationNo(String qutationNo) {
		this.qutationNo = qutationNo;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public PremiumDetailsQuot getPremDetlst() {
		return premDetlst;
	}
	public void setPremDetlst(PremiumDetailsQuot premDetlst) {
		this.premDetlst = premDetlst;
	}
	
	
}

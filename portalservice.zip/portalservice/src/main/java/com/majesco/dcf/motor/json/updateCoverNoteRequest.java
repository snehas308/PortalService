package com.majesco.dcf.motor.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class updateCoverNoteRequest extends UserObject{
	private String cancelledRsn;
	private String updatedStatus;
	private String startLeafNo;
	
	public String getCancelledRsn() {
		return cancelledRsn;
	}
	public void setCancelledRsn(String cancelledRsn) {
		this.cancelledRsn = cancelledRsn;
	}
	public String getUpdatedStatus() {
		return updatedStatus;
	}
	public void setUpdatedStatus(String updatedStatus) {
		this.updatedStatus = updatedStatus;
	}
	public String getStartLeafNo() {
		return startLeafNo;
	}
	public void setStartLeafNo(String startLeafNo) {
		this.startLeafNo = startLeafNo;
	}

}

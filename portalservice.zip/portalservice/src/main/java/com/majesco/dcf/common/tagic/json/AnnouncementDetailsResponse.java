package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class AnnouncementDetailsResponse {
	
	private ArrayList<AnnouncementDetails> lstAnnouncementDtls;
	private String errorCode;

	public ArrayList<AnnouncementDetails> getLstAnnouncementDtls() {
		return lstAnnouncementDtls;
	}

	public void setLstAnnouncementDtls(
			ArrayList<AnnouncementDetails> lstAnnouncementDtls) {
		this.lstAnnouncementDtls = lstAnnouncementDtls;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	

}

package com.majesco.dcf.common.tagic.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.majesco.dcf.common.tagic.json.CalculateHomeRequest;
import com.majesco.dcf.common.tagic.json.CalculateHomeResponse;
import com.majesco.dcf.common.tagic.service.CalculateHomeService;
import com.majesco.dcf.motor.json.GenerateQuoteMotorRequest;
import com.majesco.dcf.motor.json.GenerateQuoteMotorResponse;
//import com.majesco.dcf.motor.service.GenerateQuoteMotorService;
import com.majesco.dcf.paproduct.json.QuotationPARequest;
import com.majesco.dcf.paproduct.json.QuotationPAResponse;
import com.majesco.dcf.paproduct.service.QuotationPAService;

@Controller
@RequestMapping(value="/GenerateQuote")
public class GenerateQuoteController {
	
	
	/*Call To generate Quotation for Home product*/
	@Autowired
	CalculateHomeService quickQuoteHome;
	
	final static Logger logger = Logger.getLogger(GenerateQuoteController.class);
	
	@RequestMapping(value="/getHomeQuote/", method = RequestMethod.POST)
	@ResponseBody	
	public CalculateHomeResponse fetchQuote(@RequestBody CalculateHomeRequest quickReq,HttpServletRequest httpServletRequest) throws Exception
	{	
		
		logger.info("Inside CalculateHealthController :: fetchQuote method :: Execution Started");
		
		CalculateHomeResponse result = quickQuoteHome.CalculatePremiumHome(quickReq);
		
		logger.info("Inside CalculateHealthController :: fetchQuote method :: Execution Completed Successfully");
					
		return result;
	}
	
	
	@Autowired
	QuotationPAService quickQuotePA;
	
	
	@RequestMapping(value="/getPAQuote/", method = RequestMethod.POST)
	@ResponseBody	
	public QuotationPAResponse GetPAQuote(@RequestBody QuotationPARequest quickReq,HttpServletRequest httpServletRequest) throws Exception
	{	
		logger.info("Inside CalculateHealthController :: GetPAQuote method :: Execution Started");	 								
		
		QuotationPAResponse result = quickQuotePA.getQuoteforPA(quickReq);
		
		logger.info("Inside CalculateHealthController :: GetPAQuote method :: Execution Completed Successfully");
					
		return result;
	}
	

}

package com.majesco.dcf.motor.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ProposalGenerationCVResponse {

	
	private String resultCode;
	private String proposalNumber;
	private String proposalStatus;
	private List<ResponseError> resErr;
	private List<PremiumBreakup> prmbrk;
	private PremiumDetails premDet;
	private String proposalSystemId; // WFSystemId from create proposal response.WFSystemID
	private String businessLocation; // From proposal response; PropGeneralProposalInformation_OfficeCode
	private String depositOfficeCode; // From proposal response PropGeneralProposalInformation_OfficeCode
	private String bussLocName; // From proposal response.PropGeneralProposalInformation_OfficeName
	private String proposalDate;
	private String isPreInspection;
	private String rulesWarning;
	private String proposalStatusDesc;	
	private String propInfoPolicyNumberChar;
	private String propInfoPolicyNo;
	private String propInfoNumCovernoteNo;

	public String getRulesWarning() {
	return rulesWarning;
}
public void setRulesWarning(String rulesWarning) {
	this.rulesWarning = rulesWarning;
}
	public String getIsPreInspection() {
		return isPreInspection;
	}
	public void setIsPreInspection(String isPreInspection) {
		this.isPreInspection = isPreInspection;
	}
	public String getProposalSystemId() {
		return proposalSystemId;
	}
	public void setProposalSystemId(String proposalSystemId) {
		this.proposalSystemId = proposalSystemId;
	}
	public String getBusinessLocation() {
		return businessLocation;
	}
	public void setBusinessLocation(String businessLocation) {
		this.businessLocation = businessLocation;
	}
	public String getDepositOfficeCode() {
		return depositOfficeCode;
	}
	public void setDepositOfficeCode(String depositOfficeCode) {
		this.depositOfficeCode = depositOfficeCode;
	}
	public String getBussLocName() {
		return bussLocName;
	}
	public void setBussLocName(String bussLocName) {
		this.bussLocName = bussLocName;
	}
	public String getProposalDate() {
		return proposalDate;
	}
	public void setProposalDate(String proposalDate) {
		this.proposalDate = proposalDate;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getProposalNumber() {
		return proposalNumber;
	}
	public void setProposalNumber(String proposalNumber) {
		this.proposalNumber = proposalNumber;
	}
	public String getProposalStatus() {
		return proposalStatus;
	}
	public void setProposalStatus(String proposalStatus) {
		this.proposalStatus = proposalStatus;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public PremiumDetails getPremDet() {
		return premDet;
	}
	public void setPremDet(PremiumDetails premDet) {
		this.premDet = premDet;
	}
	public List<PremiumBreakup> getPrmbrk() {
		return prmbrk;
	}
	public void setPrmbrk(List<PremiumBreakup> prmbrk) {
		this.prmbrk = prmbrk;
	}
	public String getProposalStatusDesc() {
		return proposalStatusDesc;
	}
	public void setProposalStatusDesc(String proposalStatusDesc) {
		this.proposalStatusDesc = proposalStatusDesc;
	}
	public String getPropInfoPolicyNumberChar() {
		return propInfoPolicyNumberChar;
	}
	public void setPropInfoPolicyNumberChar(String propInfoPolicyNumberChar) {
		this.propInfoPolicyNumberChar = propInfoPolicyNumberChar;
	}
	public String getPropInfoPolicyNo() {
		return propInfoPolicyNo;
	}
	public void setPropInfoPolicyNo(String propInfoPolicyNo) {
		this.propInfoPolicyNo = propInfoPolicyNo;
	}
	public String getPropInfoNumCovernoteNo() {
		return propInfoNumCovernoteNo;
	}
	public void setPropInfoNumCovernoteNo(String propInfoNumCovernoteNo) {
		this.propInfoNumCovernoteNo = propInfoNumCovernoteNo;
	}
	
	
}

package com.majesco.dcf.common.tagic.entity;


import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
//@Table(name = "dcf_vehicle_subclass_m",schema="dcf_master")			// Commented for Oracle Migration
@Table(name = "dcf_vehicle_subclass_m")									// Added for Oracle Migration
public class VehicleSubClass implements Serializable{
	
	private Integer nvehiclesubclassseq;
	private String strvehicleclasscd;
	private String strvehiclesubclasscd;
	private String strvehiclesubclassdesc;
	private String strsubclasscategory;
	private String dtstart;
	private String dtend;
	private String strstatus;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	
	
	@Column(name = "nvehiclesubclassseq")
	public Integer getNvehiclesubclassseq() {
		return nvehiclesubclassseq;
	}
	public void setNvehiclesubclassseq(Integer nvehiclesubclassseq) {
		this.nvehiclesubclassseq = nvehiclesubclassseq;
	}
	
	
	@Id
	@Column(name = "strvehicleclasscd")
	public String getStrvehicleclasscd() {
		return strvehicleclasscd;
	}
	public void setStrvehicleclasscd(String strvehicleclasscd) {
		this.strvehicleclasscd = strvehicleclasscd;
	}
	
	
	@Id
	@Column(name = "strvehiclesubclasscd")
	public String getStrvehiclesubclasscd() {
		return strvehiclesubclasscd;
	}
	public void setStrvehiclesubclasscd(String strvehiclesubclasscd) {
		this.strvehiclesubclasscd = strvehiclesubclasscd;
	}
	
	
	@Column(name = "strvehiclesubclassdesc")
	public String getStrvehiclesubclassdesc() {
		return strvehiclesubclassdesc;
	}
	public void setStrvehiclesubclassdesc(String strvehiclesubclassdesc) {
		this.strvehiclesubclassdesc = strvehiclesubclassdesc;
	}
	
	
	@Column(name = "strsubclasscategory")
	public String getStrsubclasscategory() {
		return strsubclasscategory;
	}
	public void setStrsubclasscategory(String strsubclasscategory) {
		this.strsubclasscategory = strsubclasscategory;
	}
	
	
	@Column(name = "dtstart")
	public String getDtstart() {
		return dtstart;
	}
	public void setDtstart(String dtstart) {
		this.dtstart = dtstart;
	}
	
	
	@Column(name = "dtend")
	public String getDtend() {
		return dtend;
	}
	public void setDtend(String dtend) {
		this.dtend = dtend;
	}
	
	
	@Column(name = "strstatus")
	public String getStrstatus() {
		return strstatus;
	}
	public void setStrstatus(String strstatus) {
		this.strstatus = strstatus;
	}
	
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}

}

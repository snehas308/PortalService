package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class UserObject {

	private String userID;
	private String password;
	private String authToken;
	private String systemIP;
	private String userName;
	private String userRole;
	private String producerCode;
	private String producerName;
	private String producerMobile;
	private String userType;
	private String userSubType;
	private boolean isAdmin;
	private String producerEmail;
	private String defaultBranchCode;
	private String dealerCode;
	private String dealerName;
	//Start : 3365 : VishalJ
	private String bussinessChannelType;
	
	public String getBussinessChannelType() {
		return bussinessChannelType;
	}
	public void setBussinessChannelType(String bussinessChannelType) {
		this.bussinessChannelType = bussinessChannelType;
	}
	//End : 3365 : VishalJ	
	public String getProducerCode() {
		return producerCode;
	}
	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID!=null?userID.trim():null;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAuthToken() {
		return authToken;
	}
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}
	public String getSystemIP() {
		return systemIP;
	}
	public void setSystemIP(String systemIP) {
		this.systemIP = systemIP;
	}
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	public String getProducerMobile() {
		return producerMobile;
	}
	public void setProducerMobile(String producerMobile) {
		this.producerMobile = producerMobile;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getUserSubType() {
		return userSubType;
	}
	public void setUserSubType(String userSubType) {
		this.userSubType = userSubType;
	}
	public boolean isAdmin() {
		return isAdmin;
	}
	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	public String getProducerEmail() {
		return producerEmail;
	}
	public void setProducerEmail(String producerEmail) {
		this.producerEmail = producerEmail;
	}
	public String getDefaultBranchCode() {
		return defaultBranchCode;
	}
	public void setDefaultBranchCode(String defaultBranchCode) {
		this.defaultBranchCode = defaultBranchCode;
	}
	public String getDealerCode() {
		return dealerCode;
	}
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}
	public String getDealerName() {
		return dealerName;
	}
	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}
		
}

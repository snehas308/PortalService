package com.majesco.dcf.motor.json;


public class PrivateCarInsurancePolicyLite {

	
	private String insuredType;
	private String insuredTitle;
	private String insuredONAME;
	private String insuredLName;
	private String insuredMName;
	private String insuredFName;
	private String insuredDOB;
	private String insuredmSTAT;
	private String insuredGEND;
	private String insuredOCCP;
	private String insuredPHME;
	private String insuredMWRK;
	private String insuredemal;
	private String insuredadd1;
	private String insuredadd2;
	private String insuredadd3;
	private String insuredAREA;
	private String insuredCITY;
	private String insuredSTATE;
	private String insuredDSTCT;
	private String insuredPIN;
	private String insuredUID;
	private String insuredPCUST;
	private String insuredGSTIN;
	private String proposalNO;
	private String proposalDT;
	private String proposalIncptDt;
	private String proposalEXPtDt;
	private String proposalAPPtDt;
	private String policy_Inc_Time;
	private String policy_Exp_Time;
	private String proposalPROD;
	private String proposalCOVD;
	private String proposalTYPE;
	private String proposalPRODUC;
	private String proposalEMP;
	private String proposalSOLID;
	private String proposalLD;
	private String proposalPREM;
	private String basisOfRating;
	private String proposalPUP;
	private String proposalAadhaarNo;
	private String proposalPANNo;
	private String vehno;
	private String vehmyr;
	private String vehmake;
	private String vehmodel;
	private String vehvariant;
	private String vehbody;
	private String vehvtyp;
	private String vehfuel;
	private String vehregn;
	private String vehrdat;
	private String vehrcity;
	private String vehrsame;
	private String vehradd1;
	private String vehradd2;
	private String vehradd3;
	private String vehrpin;
	private String vehengn;
	private String vehchss;
	private String vehcccc;
	private String vehscap;
	private String vehidv;
	private String vehnbacco;
	private String veheavalu;
	private String vehlpgv;
	private String vehnncbm;
	private String vehnncbc;
	private String vehdtpur;
	private String rtogroupcode;
	private String prevpolcomp;
	private String prevpoltype;
	private String prevpolexdt;
	private String prevpolno;
	private String previnsname;
	private String prevbranch;
	private String prevcoadd1;
	private String prevcoadd2;
	private String prevcoadd3;
	private String driefflicns;
	private String drivsame;
	private String drivfname;
	private String drivlname;
	private String drivage;
	private String drivlyr;
	private String drivexp;
	private String drivoccp;
	private String drivgend;
	private String drivmstat;
	private String drivqual;
	private String covimt17y;
	private String covimt17;
	private String covimt17v;
	private String covwidelg;
	private String covpanyes;
	private String covpaunam;
	private String covpancsi;
	private String covemliabfg;
	private String covemliab;
	private String covssailr;
	private String covvolded;
	private String covaaimemtyp;
	private String covaaimem;
	private String covamemno;
	private String covaemexd;
	private String covroadas;
	private String covhabdic;
	private String covownprm;
	private String covfinnam;
	private String covfintyp;
	private String covfinadd;
	private String covfincity;
	private String covfpin;
	private String covpropdm;
	private String covantit;
	private String covtution;
	private String covvintag;
	private String covwidenum;
	private String owndamfib;
	private String vehextnterr;
	private String vehextnterrincpdt;
	private String vehextnterrexpdt;
	private String owppntrel;
	private String ownrela;
	private String ownnomin;
	private String ownnage;
	private String owndname;
	private String ownappnt;
	private String nmdperson;
	private String nmd1name;
	private String nmd1csum;
	private String nmd1age1;
	private String nmd1nom1;
	private String nmd1rel1;
	private String nmd1appn;
	private String nmd1aprl;
	private String nmd2name;
	private String nmd2csum;
	private String nmd2age1;
	private String nmd2nom1;
	private String nmd2rel1;
	private String nmd2appn;
	private String nmd2aprl;
	private String nmd3name;
	private String nmd3csum;
	private String nmd3age1;
	private String nmd3nom1;
	private String nmd3rel1;
	private String nmd3appn;
	private String nmd3aprl;
	private String addonplan;
	private String addontyp;
	private String addondepr;
	private String addclaim;
	private String addloequ;
	private String addonldis;
	private String addondail;
	private String addonreti;
	private String addonlper;
	private String addontran;
	private String addonkeyr;
	private String addonrepg;
	private String addncbper;
	private String pepppertr;
	private String pepphomew;
	private String peppcardt;
	private String peppcnume;
	private String peppissnm;
	private String addontyre;
	private String addontyreopt;
	private String addoneng;
	private String addonengopt;
	private String addonexpen;
	private String vinsptdt;
	private String vinsptno;
	private String vinspttm;
	private String vinsptag;
	private String vinsptft;
	private String pymttaxid;
	private String policyno;
	private String transactionid;
	private String confirmpayment;
	private String pymtmode;
	private String pymtdate;
	private String pymtamnt;
	private String pymtchno;
	private String pymtbrnc;
	private String dpstslpno;
	private String cdaccountno;
	private String print_flag;
	
	public String getInsuredType() {
		return insuredType;
	}
	public void setInsuredType(String insuredType) {
		this.insuredType = insuredType;
	}
	public String getInsuredTitle() {
		return insuredTitle;
	}
	public void setInsuredTitle(String insuredTitle) {
		this.insuredTitle = insuredTitle;
	}
	public String getInsuredONAME() {
		return insuredONAME;
	}
	public void setInsuredONAME(String insuredONAME) {
		this.insuredONAME = insuredONAME;
	}
	public String getInsuredLName() {
		return insuredLName;
	}
	public void setInsuredLName(String insuredLName) {
		this.insuredLName = insuredLName;
	}
	public String getInsuredMName() {
		return insuredMName;
	}
	public void setInsuredMName(String insuredMName) {
		this.insuredMName = insuredMName;
	}
	public String getInsuredFName() {
		return insuredFName;
	}
	public void setInsuredFName(String insuredFName) {
		this.insuredFName = insuredFName;
	}
	public String getInsuredDOB() {
		return insuredDOB;
	}
	public void setInsuredDOB(String insuredDOB) {
		this.insuredDOB = insuredDOB;
	}
	public String getInsuredmSTAT() {
		return insuredmSTAT;
	}
	public void setInsuredmSTAT(String insuredmSTAT) {
		this.insuredmSTAT = insuredmSTAT;
	}
	public String getInsuredGEND() {
		return insuredGEND;
	}
	public void setInsuredGEND(String insuredGEND) {
		this.insuredGEND = insuredGEND;
	}
	public String getInsuredOCCP() {
		return insuredOCCP;
	}
	public void setInsuredOCCP(String insuredOCCP) {
		this.insuredOCCP = insuredOCCP;
	}
	public String getInsuredPHME() {
		return insuredPHME;
	}
	public void setInsuredPHME(String insuredPHME) {
		this.insuredPHME = insuredPHME;
	}
	public String getInsuredMWRK() {
		return insuredMWRK;
	}
	public void setInsuredMWRK(String insuredMWRK) {
		this.insuredMWRK = insuredMWRK;
	}
	public String getInsuredemal() {
		return insuredemal;
	}
	public void setInsuredemal(String insuredemal) {
		this.insuredemal = insuredemal;
	}
	public String getInsuredadd1() {
		return insuredadd1;
	}
	public void setInsuredadd1(String insuredadd1) {
		this.insuredadd1 = insuredadd1;
	}
	public String getInsuredadd2() {
		return insuredadd2;
	}
	public void setInsuredadd2(String insuredadd2) {
		this.insuredadd2 = insuredadd2;
	}
	public String getInsuredadd3() {
		return insuredadd3;
	}
	public void setInsuredadd3(String insuredadd3) {
		this.insuredadd3 = insuredadd3;
	}
	public String getInsuredAREA() {
		return insuredAREA;
	}
	public void setInsuredAREA(String insuredAREA) {
		this.insuredAREA = insuredAREA;
	}
	public String getInsuredCITY() {
		return insuredCITY;
	}
	public void setInsuredCITY(String insuredCITY) {
		this.insuredCITY = insuredCITY;
	}
	public String getInsuredSTATE() {
		return insuredSTATE;
	}
	public void setInsuredSTATE(String insuredSTATE) {
		this.insuredSTATE = insuredSTATE;
	}
	public String getInsuredDSTCT() {
		return insuredDSTCT;
	}
	public void setInsuredDSTCT(String insuredDSTCT) {
		this.insuredDSTCT = insuredDSTCT;
	}
	public String getInsuredPIN() {
		return insuredPIN;
	}
	public void setInsuredPIN(String insuredPIN) {
		this.insuredPIN = insuredPIN;
	}
	public String getInsuredUID() {
		return insuredUID;
	}
	public void setInsuredUID(String insuredUID) {
		this.insuredUID = insuredUID;
	}
	public String getInsuredPCUST() {
		return insuredPCUST;
	}
	public void setInsuredPCUST(String insuredPCUST) {
		this.insuredPCUST = insuredPCUST;
	}
	public String getInsuredGSTIN() {
		return insuredGSTIN;
	}
	public void setInsuredGSTIN(String insuredGSTIN) {
		this.insuredGSTIN = insuredGSTIN;
	}
	public String getProposalNO() {
		return proposalNO;
	}
	public void setProposalNO(String proposalNO) {
		this.proposalNO = proposalNO;
	}
	public String getProposalDT() {
		return proposalDT;
	}
	public void setProposalDT(String proposalDT) {
		this.proposalDT = proposalDT;
	}
	public String getProposalIncptDt() {
		return proposalIncptDt;
	}
	public void setProposalIncptDt(String proposalIncptDt) {
		this.proposalIncptDt = proposalIncptDt;
	}
	public String getProposalEXPtDt() {
		return proposalEXPtDt;
	}
	public void setProposalEXPtDt(String proposalEXPtDt) {
		this.proposalEXPtDt = proposalEXPtDt;
	}
	public String getProposalAPPtDt() {
		return proposalAPPtDt;
	}
	public void setProposalAPPtDt(String proposalAPPtDt) {
		this.proposalAPPtDt = proposalAPPtDt;
	}
	public String getPolicy_Inc_Time() {
		return policy_Inc_Time;
	}
	public void setPolicy_Inc_Time(String policy_Inc_Time) {
		this.policy_Inc_Time = policy_Inc_Time;
	}
	public String getPolicy_Exp_Time() {
		return policy_Exp_Time;
	}
	public void setPolicy_Exp_Time(String policy_Exp_Time) {
		this.policy_Exp_Time = policy_Exp_Time;
	}
	public String getProposalPROD() {
		return proposalPROD;
	}
	public void setProposalPROD(String proposalPROD) {
		this.proposalPROD = proposalPROD;
	}
	public String getProposalCOVD() {
		return proposalCOVD;
	}
	public void setProposalCOVD(String proposalCOVD) {
		this.proposalCOVD = proposalCOVD;
	}
	public String getProposalTYPE() {
		return proposalTYPE;
	}
	public void setProposalTYPE(String proposalTYPE) {
		this.proposalTYPE = proposalTYPE;
	}
	public String getProposalPRODUC() {
		return proposalPRODUC;
	}
	public void setProposalPRODUC(String proposalPRODUC) {
		this.proposalPRODUC = proposalPRODUC;
	}
	public String getProposalEMP() {
		return proposalEMP;
	}
	public void setProposalEMP(String proposalEMP) {
		this.proposalEMP = proposalEMP;
	}
	public String getProposalSOLID() {
		return proposalSOLID;
	}
	public void setProposalSOLID(String proposalSOLID) {
		this.proposalSOLID = proposalSOLID;
	}
	public String getProposalLD() {
		return proposalLD;
	}
	public void setProposalLD(String proposalLD) {
		this.proposalLD = proposalLD;
	}
	public String getProposalPREM() {
		return proposalPREM;
	}
	public void setProposalPREM(String proposalPREM) {
		this.proposalPREM = proposalPREM;
	}

	public String getProposalPUP() {
		return proposalPUP;
	}
	public void setProposalPUP(String proposalPUP) {
		this.proposalPUP = proposalPUP;
	}
	public String getProposalAadhaarNo() {
		return proposalAadhaarNo;
	}
	public void setProposalAadhaarNo(String proposalAadhaarNo) {
		this.proposalAadhaarNo = proposalAadhaarNo;
	}
	public String getProposalPANNo() {
		return proposalPANNo;
	}
	public void setProposalPANNo(String proposalPANNo) {
		this.proposalPANNo = proposalPANNo;
	}
	public String getVehno() {
		return vehno;
	}
	public void setVehno(String vehno) {
		this.vehno = vehno;
	}
	public String getVehmyr() {
		return vehmyr;
	}
	public void setVehmyr(String vehmyr) {
		this.vehmyr = vehmyr;
	}
	public String getVehmake() {
		return vehmake;
	}
	public void setVehmake(String vehmake) {
		this.vehmake = vehmake;
	}
	public String getVehmodel() {
		return vehmodel;
	}
	public void setVehmodel(String vehmodel) {
		this.vehmodel = vehmodel;
	}
	public String getVehvariant() {
		return vehvariant;
	}
	public void setVehvariant(String vehvariant) {
		this.vehvariant = vehvariant;
	}
	public String getVehbody() {
		return vehbody;
	}
	public void setVehbody(String vehbody) {
		this.vehbody = vehbody;
	}
	public String getVehvtyp() {
		return vehvtyp;
	}
	public void setVehvtyp(String vehvtyp) {
		this.vehvtyp = vehvtyp;
	}
	public String getVehfuel() {
		return vehfuel;
	}
	public void setVehfuel(String vehfuel) {
		this.vehfuel = vehfuel;
	}
	public String getVehregn() {
		return vehregn;
	}
	public void setVehregn(String vehregn) {
		this.vehregn = vehregn;
	}
	public String getVehrdat() {
		return vehrdat;
	}
	public void setVehrdat(String vehrdat) {
		this.vehrdat = vehrdat;
	}
	public String getVehrcity() {
		return vehrcity;
	}
	public void setVehrcity(String vehrcity) {
		this.vehrcity = vehrcity;
	}
	public String getVehrsame() {
		return vehrsame;
	}
	public void setVehrsame(String vehrsame) {
		this.vehrsame = vehrsame;
	}
	public String getVehradd1() {
		return vehradd1;
	}
	public void setVehradd1(String vehradd1) {
		this.vehradd1 = vehradd1;
	}
	public String getVehradd2() {
		return vehradd2;
	}
	public void setVehradd2(String vehradd2) {
		this.vehradd2 = vehradd2;
	}
	public String getVehradd3() {
		return vehradd3;
	}
	public void setVehradd3(String vehradd3) {
		this.vehradd3 = vehradd3;
	}
	public String getVehrpin() {
		return vehrpin;
	}
	public void setVehrpin(String vehrpin) {
		this.vehrpin = vehrpin;
	}
	public String getVehengn() {
		return vehengn;
	}
	public void setVehengn(String vehengn) {
		this.vehengn = vehengn;
	}
	public String getVehchss() {
		return vehchss;
	}
	public void setVehchss(String vehchss) {
		this.vehchss = vehchss;
	}
	public String getVehcccc() {
		return vehcccc;
	}
	public void setVehcccc(String vehcccc) {
		this.vehcccc = vehcccc;
	}
	public String getVehscap() {
		return vehscap;
	}
	public void setVehscap(String vehscap) {
		this.vehscap = vehscap;
	}
	public String getVehidv() {
		return vehidv;
	}
	public void setVehidv(String vehidv) {
		this.vehidv = vehidv;
	}
	public String getVehnbacco() {
		return vehnbacco;
	}
	public void setVehnbacco(String vehnbacco) {
		this.vehnbacco = vehnbacco;
	}
	public String getVeheavalu() {
		return veheavalu;
	}
	public void setVeheavalu(String veheavalu) {
		this.veheavalu = veheavalu;
	}
	public String getVehlpgv() {
		return vehlpgv;
	}
	public void setVehlpgv(String vehlpgv) {
		this.vehlpgv = vehlpgv;
	}
	public String getVehnncbm() {
		return vehnncbm;
	}
	public void setVehnncbm(String vehnncbm) {
		this.vehnncbm = vehnncbm;
	}
	public String getVehnncbc() {
		return vehnncbc;
	}
	public void setVehnncbc(String vehnncbc) {
		this.vehnncbc = vehnncbc;
	}
	public String getVehdtpur() {
		return vehdtpur;
	}
	public void setVehdtpur(String vehdtpur) {
		this.vehdtpur = vehdtpur;
	}
	public String getRtogroupcode() {
		return rtogroupcode;
	}
	public void setRtogroupcode(String rtogroupcode) {
		this.rtogroupcode = rtogroupcode;
	}
	public String getPrevpolcomp() {
		return prevpolcomp;
	}
	public void setPrevpolcomp(String prevpolcomp) {
		this.prevpolcomp = prevpolcomp;
	}
	public String getPrevpoltype() {
		return prevpoltype;
	}
	public void setPrevpoltype(String prevpoltype) {
		this.prevpoltype = prevpoltype;
	}
	public String getPrevpolexdt() {
		return prevpolexdt;
	}
	public void setPrevpolexdt(String prevpolexdt) {
		this.prevpolexdt = prevpolexdt;
	}
	public String getPrevpolno() {
		return prevpolno;
	}
	public void setPrevpolno(String prevpolno) {
		this.prevpolno = prevpolno;
	}
	public String getPrevinsname() {
		return previnsname;
	}
	public void setPrevinsname(String previnsname) {
		this.previnsname = previnsname;
	}
	public String getPrevbranch() {
		return prevbranch;
	}
	public void setPrevbranch(String prevbranch) {
		this.prevbranch = prevbranch;
	}
	public String getPrevcoadd1() {
		return prevcoadd1;
	}
	public void setPrevcoadd1(String prevcoadd1) {
		this.prevcoadd1 = prevcoadd1;
	}
	public String getPrevcoadd2() {
		return prevcoadd2;
	}
	public void setPrevcoadd2(String prevcoadd2) {
		this.prevcoadd2 = prevcoadd2;
	}
	public String getPrevcoadd3() {
		return prevcoadd3;
	}
	public void setPrevcoadd3(String prevcoadd3) {
		this.prevcoadd3 = prevcoadd3;
	}
	public String getDriefflicns() {
		return driefflicns;
	}
	public void setDriefflicns(String driefflicns) {
		this.driefflicns = driefflicns;
	}
	public String getDrivsame() {
		return drivsame;
	}
	public void setDrivsame(String drivsame) {
		this.drivsame = drivsame;
	}
	public String getDrivfname() {
		return drivfname;
	}
	public void setDrivfname(String drivfname) {
		this.drivfname = drivfname;
	}
	public String getDrivlname() {
		return drivlname;
	}
	public void setDrivlname(String drivlname) {
		this.drivlname = drivlname;
	}
	public String getDrivage() {
		return drivage;
	}
	public void setDrivage(String drivage) {
		this.drivage = drivage;
	}
	public String getDrivlyr() {
		return drivlyr;
	}
	public void setDrivlyr(String drivlyr) {
		this.drivlyr = drivlyr;
	}
	public String getDrivexp() {
		return drivexp;
	}
	public void setDrivexp(String drivexp) {
		this.drivexp = drivexp;
	}
	public String getDrivoccp() {
		return drivoccp;
	}
	public void setDrivoccp(String drivoccp) {
		this.drivoccp = drivoccp;
	}
	public String getDrivgend() {
		return drivgend;
	}
	public void setDrivgend(String drivgend) {
		this.drivgend = drivgend;
	}
	public String getDrivmstat() {
		return drivmstat;
	}
	public void setDrivmstat(String drivmstat) {
		this.drivmstat = drivmstat;
	}
	public String getDrivqual() {
		return drivqual;
	}
	public void setDrivqual(String drivqual) {
		this.drivqual = drivqual;
	}
	public String getCovimt17y() {
		return covimt17y;
	}
	public void setCovimt17y(String covimt17y) {
		this.covimt17y = covimt17y;
	}
	public String getCovimt17() {
		return covimt17;
	}
	public void setCovimt17(String covimt17) {
		this.covimt17 = covimt17;
	}
	public String getCovimt17v() {
		return covimt17v;
	}
	public void setCovimt17v(String covimt17v) {
		this.covimt17v = covimt17v;
	}
	public String getCovwidelg() {
		return covwidelg;
	}
	public void setCovwidelg(String covwidelg) {
		this.covwidelg = covwidelg;
	}
	public String getCovpanyes() {
		return covpanyes;
	}
	public void setCovpanyes(String covpanyes) {
		this.covpanyes = covpanyes;
	}
	public String getCovpaunam() {
		return covpaunam;
	}
	public void setCovpaunam(String covpaunam) {
		this.covpaunam = covpaunam;
	}
	public String getCovpancsi() {
		return covpancsi;
	}
	public void setCovpancsi(String covpancsi) {
		this.covpancsi = covpancsi;
	}
	public String getCovemliabfg() {
		return covemliabfg;
	}
	public void setCovemliabfg(String covemliabfg) {
		this.covemliabfg = covemliabfg;
	}
	public String getCovemliab() {
		return covemliab;
	}
	public void setCovemliab(String covemliab) {
		this.covemliab = covemliab;
	}
	public String getCovssailr() {
		return covssailr;
	}
	public void setCovssailr(String covssailr) {
		this.covssailr = covssailr;
	}
	public String getCovvolded() {
		return covvolded;
	}
	public void setCovvolded(String covvolded) {
		this.covvolded = covvolded;
	}
	public String getCovaaimemtyp() {
		return covaaimemtyp;
	}
	public void setCovaaimemtyp(String covaaimemtyp) {
		this.covaaimemtyp = covaaimemtyp;
	}
	public String getCovaaimem() {
		return covaaimem;
	}
	public void setCovaaimem(String covaaimem) {
		this.covaaimem = covaaimem;
	}
	public String getCovamemno() {
		return covamemno;
	}
	public void setCovamemno(String covamemno) {
		this.covamemno = covamemno;
	}
	public String getCovaemexd() {
		return covaemexd;
	}
	public void setCovaemexd(String covaemexd) {
		this.covaemexd = covaemexd;
	}
	public String getCovroadas() {
		return covroadas;
	}
	public void setCovroadas(String covroadas) {
		this.covroadas = covroadas;
	}
	public String getCovhabdic() {
		return covhabdic;
	}
	public void setCovhabdic(String covhabdic) {
		this.covhabdic = covhabdic;
	}
	public String getCovownprm() {
		return covownprm;
	}
	public void setCovownprm(String covownprm) {
		this.covownprm = covownprm;
	}
	public String getCovfinnam() {
		return covfinnam;
	}
	public void setCovfinnam(String covfinnam) {
		this.covfinnam = covfinnam;
	}
	public String getCovfintyp() {
		return covfintyp;
	}
	public void setCovfintyp(String covfintyp) {
		this.covfintyp = covfintyp;
	}
	public String getCovfinadd() {
		return covfinadd;
	}
	public void setCovfinadd(String covfinadd) {
		this.covfinadd = covfinadd;
	}
	public String getCovfincity() {
		return covfincity;
	}
	public void setCovfincity(String covfincity) {
		this.covfincity = covfincity;
	}
	public String getCovfpin() {
		return covfpin;
	}
	public void setCovfpin(String covfpin) {
		this.covfpin = covfpin;
	}
	public String getCovpropdm() {
		return covpropdm;
	}
	public void setCovpropdm(String covpropdm) {
		this.covpropdm = covpropdm;
	}
	public String getCovantit() {
		return covantit;
	}
	public void setCovantit(String covantit) {
		this.covantit = covantit;
	}
	public String getCovtution() {
		return covtution;
	}
	public void setCovtution(String covtution) {
		this.covtution = covtution;
	}
	public String getCovvintag() {
		return covvintag;
	}
	public void setCovvintag(String covvintag) {
		this.covvintag = covvintag;
	}
	public String getCovwidenum() {
		return covwidenum;
	}
	public void setCovwidenum(String covwidenum) {
		this.covwidenum = covwidenum;
	}
	public String getOwndamfib() {
		return owndamfib;
	}
	public void setOwndamfib(String owndamfib) {
		this.owndamfib = owndamfib;
	}
	public String getVehextnterr() {
		return vehextnterr;
	}
	public void setVehextnterr(String vehextnterr) {
		this.vehextnterr = vehextnterr;
	}
	public String getVehextnterrincpdt() {
		return vehextnterrincpdt;
	}
	public void setVehextnterrincpdt(String vehextnterrincpdt) {
		this.vehextnterrincpdt = vehextnterrincpdt;
	}
	public String getVehextnterrexpdt() {
		return vehextnterrexpdt;
	}
	public void setVehextnterrexpdt(String vehextnterrexpdt) {
		this.vehextnterrexpdt = vehextnterrexpdt;
	}
	public String getOwppntrel() {
		return owppntrel;
	}
	public void setOwppntrel(String owppntrel) {
		this.owppntrel = owppntrel;
	}
	public String getOwnrela() {
		return ownrela;
	}
	public void setOwnrela(String ownrela) {
		this.ownrela = ownrela;
	}
	public String getOwnnomin() {
		return ownnomin;
	}
	public void setOwnnomin(String ownnomin) {
		this.ownnomin = ownnomin;
	}
	public String getOwnnage() {
		return ownnage;
	}
	public void setOwnnage(String ownnage) {
		this.ownnage = ownnage;
	}
	public String getOwndname() {
		return owndname;
	}
	public void setOwndname(String owndname) {
		this.owndname = owndname;
	}
	public String getOwnappnt() {
		return ownappnt;
	}
	public void setOwnappnt(String ownappnt) {
		this.ownappnt = ownappnt;
	}
	public String getNmdperson() {
		return nmdperson;
	}
	public void setNmdperson(String nmdperson) {
		this.nmdperson = nmdperson;
	}
	public String getNmd1name() {
		return nmd1name;
	}
	public void setNmd1name(String nmd1name) {
		this.nmd1name = nmd1name;
	}
	public String getNmd1csum() {
		return nmd1csum;
	}
	public void setNmd1csum(String nmd1csum) {
		this.nmd1csum = nmd1csum;
	}
	public String getNmd1age1() {
		return nmd1age1;
	}
	public void setNmd1age1(String nmd1age1) {
		this.nmd1age1 = nmd1age1;
	}
	public String getNmd1nom1() {
		return nmd1nom1;
	}
	public void setNmd1nom1(String nmd1nom1) {
		this.nmd1nom1 = nmd1nom1;
	}
	public String getNmd1rel1() {
		return nmd1rel1;
	}
	public void setNmd1rel1(String nmd1rel1) {
		this.nmd1rel1 = nmd1rel1;
	}
	public String getNmd1appn() {
		return nmd1appn;
	}
	public void setNmd1appn(String nmd1appn) {
		this.nmd1appn = nmd1appn;
	}
	public String getNmd1aprl() {
		return nmd1aprl;
	}
	public void setNmd1aprl(String nmd1aprl) {
		this.nmd1aprl = nmd1aprl;
	}
	public String getNmd2name() {
		return nmd2name;
	}
	public void setNmd2name(String nmd2name) {
		this.nmd2name = nmd2name;
	}
	public String getNmd2csum() {
		return nmd2csum;
	}
	public void setNmd2csum(String nmd2csum) {
		this.nmd2csum = nmd2csum;
	}
	public String getNmd2age1() {
		return nmd2age1;
	}
	public void setNmd2age1(String nmd2age1) {
		this.nmd2age1 = nmd2age1;
	}
	public String getNmd2nom1() {
		return nmd2nom1;
	}
	public void setNmd2nom1(String nmd2nom1) {
		this.nmd2nom1 = nmd2nom1;
	}
	public String getNmd2rel1() {
		return nmd2rel1;
	}
	public void setNmd2rel1(String nmd2rel1) {
		this.nmd2rel1 = nmd2rel1;
	}
	public String getNmd2appn() {
		return nmd2appn;
	}
	public void setNmd2appn(String nmd2appn) {
		this.nmd2appn = nmd2appn;
	}
	public String getNmd2aprl() {
		return nmd2aprl;
	}
	public void setNmd2aprl(String nmd2aprl) {
		this.nmd2aprl = nmd2aprl;
	}
	public String getNmd3name() {
		return nmd3name;
	}
	public void setNmd3name(String nmd3name) {
		this.nmd3name = nmd3name;
	}
	public String getNmd3csum() {
		return nmd3csum;
	}
	public void setNmd3csum(String nmd3csum) {
		this.nmd3csum = nmd3csum;
	}
	public String getNmd3age1() {
		return nmd3age1;
	}
	public void setNmd3age1(String nmd3age1) {
		this.nmd3age1 = nmd3age1;
	}
	public String getNmd3nom1() {
		return nmd3nom1;
	}
	public void setNmd3nom1(String nmd3nom1) {
		this.nmd3nom1 = nmd3nom1;
	}
	public String getNmd3rel1() {
		return nmd3rel1;
	}
	public void setNmd3rel1(String nmd3rel1) {
		this.nmd3rel1 = nmd3rel1;
	}
	public String getNmd3appn() {
		return nmd3appn;
	}
	public void setNmd3appn(String nmd3appn) {
		this.nmd3appn = nmd3appn;
	}
	public String getNmd3aprl() {
		return nmd3aprl;
	}
	public void setNmd3aprl(String nmd3aprl) {
		this.nmd3aprl = nmd3aprl;
	}
	public String getAddonplan() {
		return addonplan;
	}
	public void setAddonplan(String addonplan) {
		this.addonplan = addonplan;
	}
	public String getAddontyp() {
		return addontyp;
	}
	public void setAddontyp(String addontyp) {
		this.addontyp = addontyp;
	}
	public String getAddondepr() {
		return addondepr;
	}
	public void setAddondepr(String addondepr) {
		this.addondepr = addondepr;
	}
	public String getAddclaim() {
		return addclaim;
	}
	public void setAddclaim(String addclaim) {
		this.addclaim = addclaim;
	}
	public String getAddloequ() {
		return addloequ;
	}
	public void setAddloequ(String addloequ) {
		this.addloequ = addloequ;
	}
	public String getAddonldis() {
		return addonldis;
	}
	public void setAddonldis(String addonldis) {
		this.addonldis = addonldis;
	}
	public String getAddondail() {
		return addondail;
	}
	public void setAddondail(String addondail) {
		this.addondail = addondail;
	}
	public String getAddonreti() {
		return addonreti;
	}
	public void setAddonreti(String addonreti) {
		this.addonreti = addonreti;
	}
	public String getAddonlper() {
		return addonlper;
	}
	public void setAddonlper(String addonlper) {
		this.addonlper = addonlper;
	}
	public String getAddontran() {
		return addontran;
	}
	public void setAddontran(String addontran) {
		this.addontran = addontran;
	}
	public String getAddonkeyr() {
		return addonkeyr;
	}
	public void setAddonkeyr(String addonkeyr) {
		this.addonkeyr = addonkeyr;
	}
	public String getAddonrepg() {
		return addonrepg;
	}
	public void setAddonrepg(String addonrepg) {
		this.addonrepg = addonrepg;
	}
	public String getAddncbper() {
		return addncbper;
	}
	public void setAddncbper(String addncbper) {
		this.addncbper = addncbper;
	}
	public String getPepppertr() {
		return pepppertr;
	}
	public void setPepppertr(String pepppertr) {
		this.pepppertr = pepppertr;
	}
	public String getPepphomew() {
		return pepphomew;
	}
	public void setPepphomew(String pepphomew) {
		this.pepphomew = pepphomew;
	}
	public String getPeppcardt() {
		return peppcardt;
	}
	public void setPeppcardt(String peppcardt) {
		this.peppcardt = peppcardt;
	}
	public String getPeppcnume() {
		return peppcnume;
	}
	public void setPeppcnume(String peppcnume) {
		this.peppcnume = peppcnume;
	}
	public String getPeppissnm() {
		return peppissnm;
	}
	public void setPeppissnm(String peppissnm) {
		this.peppissnm = peppissnm;
	}
	public String getAddontyre() {
		return addontyre;
	}
	public void setAddontyre(String addontyre) {
		this.addontyre = addontyre;
	}
	public String getAddontyreopt() {
		return addontyreopt;
	}
	public void setAddontyreopt(String addontyreopt) {
		this.addontyreopt = addontyreopt;
	}
	public String getAddoneng() {
		return addoneng;
	}
	public void setAddoneng(String addoneng) {
		this.addoneng = addoneng;
	}
	public String getAddonengopt() {
		return addonengopt;
	}
	public void setAddonengopt(String addonengopt) {
		this.addonengopt = addonengopt;
	}
	public String getAddonexpen() {
		return addonexpen;
	}
	public void setAddonexpen(String addonexpen) {
		this.addonexpen = addonexpen;
	}
	public String getVinsptdt() {
		return vinsptdt;
	}
	public void setVinsptdt(String vinsptdt) {
		this.vinsptdt = vinsptdt;
	}
	public String getVinsptno() {
		return vinsptno;
	}
	public void setVinsptno(String vinsptno) {
		this.vinsptno = vinsptno;
	}
	public String getVinspttm() {
		return vinspttm;
	}
	public void setVinspttm(String vinspttm) {
		this.vinspttm = vinspttm;
	}
	public String getVinsptag() {
		return vinsptag;
	}
	public void setVinsptag(String vinsptag) {
		this.vinsptag = vinsptag;
	}
	public String getVinsptft() {
		return vinsptft;
	}
	public void setVinsptft(String vinsptft) {
		this.vinsptft = vinsptft;
	}
	public String getPymttaxid() {
		return pymttaxid;
	}
	public void setPymttaxid(String pymttaxid) {
		this.pymttaxid = pymttaxid;
	}
	public String getPolicyno() {
		return policyno;
	}
	public void setPolicyno(String policyno) {
		this.policyno = policyno;
	}
	public String getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}
	public String getConfirmpayment() {
		return confirmpayment;
	}
	public void setConfirmpayment(String confirmpayment) {
		this.confirmpayment = confirmpayment;
	}
	public String getPymtmode() {
		return pymtmode;
	}
	public void setPymtmode(String pymtmode) {
		this.pymtmode = pymtmode;
	}
	public String getPymtdate() {
		return pymtdate;
	}
	public void setPymtdate(String pymtdate) {
		this.pymtdate = pymtdate;
	}
	public String getPymtamnt() {
		return pymtamnt;
	}
	public void setPymtamnt(String pymtamnt) {
		this.pymtamnt = pymtamnt;
	}
	public String getPymtchno() {
		return pymtchno;
	}
	public void setPymtchno(String pymtchno) {
		this.pymtchno = pymtchno;
	}
	public String getPymtbrnc() {
		return pymtbrnc;
	}
	public void setPymtbrnc(String pymtbrnc) {
		this.pymtbrnc = pymtbrnc;
	}
	public String getDpstslpno() {
		return dpstslpno;
	}
	public void setDpstslpno(String dpstslpno) {
		this.dpstslpno = dpstslpno;
	}
	public String getCdaccountno() {
		return cdaccountno;
	}
	public void setCdaccountno(String cdaccountno) {
		this.cdaccountno = cdaccountno;
	}
	public String getPrint_flag() {
		return print_flag;
	}
	public void setPrint_flag(String print_flag) {
		this.print_flag = print_flag;
	}
	public String getBasisOfRating() {
		return basisOfRating;
	}
	public void setBasisOfRating(String basisOfRating) {
		this.basisOfRating = basisOfRating;
	}

}

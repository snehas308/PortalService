package com.majesco.dcf.motor.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class GenerateMoratoriumRequest extends UserObject{

	private String strprodcd;
	private VehicleRegDetails lstvecReg;
	public String getStrprodcd() {
		return strprodcd;
	}
	public void setStrprodcd(String strprodcd) {
		this.strprodcd = strprodcd;
	}
	public VehicleRegDetails getLstvecReg() {
		return lstvecReg;
	}
	public void setLstvecReg(VehicleRegDetails lstvecReg) {
		this.lstvecReg = lstvecReg;
	}	
}

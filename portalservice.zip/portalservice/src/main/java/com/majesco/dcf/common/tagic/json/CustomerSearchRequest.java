package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CustomerSearchRequest extends UserObject {

	private String customerCode;
	private String firstName;
	private String lastName;
	private String quotationNo;
	private String proposalNo;
	private String policyNo;
	private String dateOfBirth;
	private String mobileNo;
	private String pinCode;
	private String cityCode;
	private String cityName;
	private String stateCode;
	private String stateName;
	private String receiptNo;
	private String claimNo;
	private String createDateFrom;
	private String createDateTo;
	private String registrationNo;
	private String cusoType;
	private String vehicleRegistrationNumber1;
	private String vehicleRegistrationNumber2;
	private String vehicleRegistrationNumber3;
	private String vehicleRegistrationNumber4;
	private String strgstnumber;			//1449: GST changes
	
	public String getVehicleRegistrationNumber1() {
		return vehicleRegistrationNumber1;
	}
	public void setVehicleRegistrationNumber1(String vehicleRegistrationNumber1) {
		this.vehicleRegistrationNumber1 = vehicleRegistrationNumber1;
	}
	public String getVehicleRegistrationNumber2() {
		return vehicleRegistrationNumber2;
	}
	public void setVehicleRegistrationNumber2(String vehicleRegistrationNumber2) {
		this.vehicleRegistrationNumber2 = vehicleRegistrationNumber2;
	}
	public String getVehicleRegistrationNumber3() {
		return vehicleRegistrationNumber3;
	}
	public void setVehicleRegistrationNumber3(String vehicleRegistrationNumber3) {
		this.vehicleRegistrationNumber3 = vehicleRegistrationNumber3;
	}
	
	
	public String getVehicleRegistrationNumber4() {
		return vehicleRegistrationNumber4;
	}
	public void setVehicleRegistrationNumber4(String vehicleRegistrationNumber4) {
		this.vehicleRegistrationNumber4 = vehicleRegistrationNumber4;
	}
	
	public String getCusoType() {
		return cusoType;
	}
	public void setCusoType(String cusoType) {
		this.cusoType = cusoType;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getQuotationNo() {
		return quotationNo;
	}
	public void setQuotationNo(String quotationNo) {
		this.quotationNo = quotationNo;
	}
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getReceiptNo() {
		return receiptNo;
	}
	public void setReceiptNo(String receiptNo) {
		this.receiptNo = receiptNo;
	}
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public String getCreateDateFrom() {
		return createDateFrom;
	}
	public void setCreateDateFrom(String createDateFrom) {
		this.createDateFrom = createDateFrom;
	}
	public String getCreateDateTo() {
		return createDateTo;
	}
	public void setCreateDateTo(String createDateTo) {
		this.createDateTo = createDateTo;
	}
	public String getRegistrationNo() {
		return registrationNo;
	}
	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}
	public String getStrgstnumber() {
		return strgstnumber;
	}
	public void setStrgstnumber(String strgstnumber) {
		this.strgstnumber = strgstnumber;
	}
	
}

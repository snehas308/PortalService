package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

public class CoverDetailsMaster implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String strcover_name;
	private String strcover_type;
	private String strcover_code;
	public String getStrcover_name() {
		return strcover_name;
	}
	public void setStrcover_name(String strcover_name) {
		this.strcover_name = strcover_name;
	}
	public String getStrcover_type() {
		return strcover_type;
	}
	public void setStrcover_type(String strcover_type) {
		this.strcover_type = strcover_type;
	}
	public String getStrcover_code() {
		return strcover_code;
	}
	public void setStrcover_code(String strcover_code) {
		this.strcover_code = strcover_code;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

	
	
	

}

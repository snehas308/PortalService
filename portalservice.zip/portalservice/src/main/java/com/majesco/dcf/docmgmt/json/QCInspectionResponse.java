package com.majesco.dcf.docmgmt.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;


/**
 * @author ketan570156
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class QCInspectionResponse extends ResponseError{
	
	ArrayList<QCInspectionResult> lstQCInspectionResult;

	public ArrayList<QCInspectionResult> getLstQCInspectionResult() {
		return lstQCInspectionResult;
	}

	public void setLstQCInspectionResult(
			ArrayList<QCInspectionResult> lstQCInspectionResult) {
		this.lstQCInspectionResult = lstQCInspectionResult;
	}

}

package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.entity.AccFinancierMaster;
import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class AccFinancierBranchResponse {
	
	private String strbranchname="";
	
	private String strfinanciername = ""; 
	
	private String strmicrcd = "";
	
	private Integer nfinanciercd;
	
	public String getStrmicrcd() {
		return strmicrcd;
	}
	public void setStrmicrcd(String strmicrcd) {
		this.strmicrcd = strmicrcd;
	}
	public Integer getNfinanciercd() {
		return nfinanciercd;
	}
	public void setNfinanciercd(Integer nfinanciercd) {
		this.nfinanciercd = nfinanciercd;
	}
	public String getStrbranchname() {
		return strbranchname;
	}
	public void setStrbranchname(String strbranchname) {
		this.strbranchname = strbranchname;
	}
	
	public String getStrfinanciername() {
		return strfinanciername;
	}
	public void setStrfinanciername(String strfinanciername) {
		this.strfinanciername = strfinanciername;
	}
	
	private String bank_branch_nm = "";

	public String getBank_branch_nm() {
		return bank_branch_nm;
	}

	public void setBank_branch_nm(String bank_branch_nm) {
		this.bank_branch_nm = bank_branch_nm;
	}

	private List<ResponseError> resErr;
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
}

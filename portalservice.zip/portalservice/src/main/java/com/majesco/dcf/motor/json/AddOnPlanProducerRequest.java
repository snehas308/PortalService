package com.majesco.dcf.motor.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

/**
 * @author ketan570156
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class AddOnPlanProducerRequest extends UserObject {
	
	private String id;
	private String name;
	private String startDate;
	private String startTime;
	private String addOnPlan;
	private String branchCode;
	private String makeCode;
	private String modelCode;
	private String rtoCode;
	private String segmentCode;
	private String transactionDate;
	private String variantCode;
	private String vahicleAge;
	private String vehicleIDV;
	private String registrationAuthLoc;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getAddOnPlan() {
		return addOnPlan;
	}
	public void setAddOnPlan(String addOnPlan) {
		this.addOnPlan = addOnPlan;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getMakeCode() {
		return makeCode;
	}
	public void setMakeCode(String makeCode) {
		this.makeCode = makeCode;
	}
	public String getModelCode() {
		return modelCode;
	}
	public void setModelCode(String modelCode) {
		this.modelCode = modelCode;
	}
	public String getRtoCode() {
		return rtoCode;
	}
	public void setRtoCode(String rtoCode) {
		this.rtoCode = rtoCode;
	}
	public String getSegmentCode() {
		return segmentCode;
	}
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getVariantCode() {
		return variantCode;
	}
	public void setVariantCode(String variantCode) {
		this.variantCode = variantCode;
	}
	public String getVahicleAge() {
		return vahicleAge;
	}
	public void setVahicleAge(String vahicleAge) {
		this.vahicleAge = vahicleAge;
	}
	public String getVehicleIDV() {
		return vehicleIDV;
	}
	public void setVehicleIDV(String vehicleIDV) {
		this.vehicleIDV = vehicleIDV;
	}
	public String getRegistrationAuthLoc() {
		return registrationAuthLoc;
	}
	public void setRegistrationAuthLoc(String registrationAuthLoc) {
		this.registrationAuthLoc = registrationAuthLoc;
	}
	
}

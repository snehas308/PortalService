package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PinCodeRequest {
	
	private Integer npincodeseq;
	private String strcountrycd;
	private String strstatecd;
	private String strdistrictcd;
	private String strcitycd;
	private Integer npincode;
	private String strpincodelocality;
	private String nisrural;
	private String dtstart;
	private String dtend;
	private Integer nisactive;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	//private String authenticationToken;
	
	public Integer getNpincodeseq() {
		return npincodeseq;
	}
	public void setNpincodeseq(Integer npincodeseq) {
		this.npincodeseq = npincodeseq;
	}
	
	
	public String getStrcountrycd() {
		return strcountrycd;
	}
	public void setStrcountrycd(String strcountrycd) {
		this.strcountrycd = strcountrycd;
	}
	
	
	public String getStrstatecd() {
		return strstatecd;
	}
	public void setStrstatecd(String strstatecd) {
		this.strstatecd = strstatecd;
	}
	
	
	public String getStrdistrictcd() {
		return strdistrictcd;
	}
	public void setStrdistrictcd(String strdistrictcd) {
		this.strdistrictcd = strdistrictcd;
	}
	
	
	public String getStrcitycd() {
		return strcitycd;
	}
	public void setStrcitycd(String strcitycd) {
		this.strcitycd = strcitycd;
	}
	
	
	public Integer getNpincode() {
		return npincode;
	}
	public void setNpincode(Integer npincode) {
		this.npincode = npincode;
	}
	
	
	public String getStrpincodelocality() {
		return strpincodelocality;
	}
	public void setStrpincodelocality(String strpincodelocality) {
		this.strpincodelocality = strpincodelocality;
	}
	
	
	public String getNisrural() {
		return nisrural;
	}
	public void setNisrural(String nisrural) {
		this.nisrural = nisrural;
	}
	
	
	public String getDtstart() {
		return dtstart;
	}
	public void setDtstart(String dtstart) {
		this.dtstart = dtstart;
	}
	
	
	public String getDtend() {
		return dtend;
	}
	public void setDtend(String dtend) {
		this.dtend = dtend;
	}
	
	
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
	
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	
//	public String getAuthenticationToken() {
//		return authenticationToken;
//	}
//	public void setAuthenticationToken(String authenticationToken) {
//		this.authenticationToken = authenticationToken;
//	}
	
	

}

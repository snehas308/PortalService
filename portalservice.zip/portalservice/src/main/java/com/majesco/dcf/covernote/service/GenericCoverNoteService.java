package com.majesco.dcf.covernote.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.covernote.json.AgentCoverNoteBook;
import com.majesco.dcf.covernote.json.CancelMissingCNRequest;
import com.majesco.dcf.covernote.json.CancelMissingCNResponse;
import com.majesco.dcf.covernote.json.GenericCoverNoteRequest;
import com.majesco.dcf.covernote.json.GenericCoverNoteResponse;
import com.majesco.dcf.covernote.json.GetPolicyNoRequest;
import com.majesco.dcf.covernote.json.NextUnusedLeafNoRequest;
import com.majesco.dcf.covernote.json.NextUnusedLeafNoResponse;
import com.majesco.dcf.covernote.json.PhyCancelledRsnForCNLeafRequest;
import com.majesco.dcf.covernote.json.PhyCancelledRsnForCNLeafResponse;
import com.majesco.dcf.covernote.json.SaveOpenCNRequest;
import com.majesco.dcf.covernote.json.SaveOpenCNResponse;
import com.majesco.dcf.covernote.json.TagPaymentCNRequest;
import com.majesco.dcf.covernote.json.TagPaymentCNResponse;

@Service
@Transactional
public interface GenericCoverNoteService {
	
	public List<GenericCoverNoteResponse> getSavedCoverNoteDtl(GenericCoverNoteRequest getCoverNoteReq) throws Exception;
	public GenericCoverNoteResponse saveCoverNoteForCoreProcessing(GenericCoverNoteRequest getCoverNoteReq) throws Exception;
	public CancelMissingCNResponse cancelMissingCoverNote(CancelMissingCNRequest getCoverNoteReq) throws Exception;
	public SaveOpenCNResponse saveOpenCoverNoteAccService(SaveOpenCNRequest getCoverNoteReq) throws Exception;
	public AgentCoverNoteBook getBookListFromAgentID(UserObject agentDtl) throws Exception;
	public NextUnusedLeafNoResponse getNextUnusedLeafNoFromBookNo(NextUnusedLeafNoRequest bookNoDtl) throws Exception;
	//public TagPaymentCNResponse tagPayment(TagPaymentCNRequest tagPaymentRequest) throws Exception;
	//public String getPolicyNo(GetPolicyNoRequest policyRequest) throws Exception;
	public List<PhyCancelledRsnForCNLeafResponse> phyCancelledRsnForCNLeaf(PhyCancelledRsnForCNLeafRequest phyCancelledRsnForCNLeafRequest) throws Exception;
}

package com.majesco.dcf.paproduct.serviceImpl;


import java.io.File;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.majesco.dcf.common.tagic.entity.OnlineAccountService;
import com.majesco.dcf.common.tagic.entity.Product;
import com.majesco.dcf.common.tagic.entity.UserTransaction;
import com.majesco.dcf.common.tagic.json.AuthenticationResponse;
import com.majesco.dcf.common.tagic.json.CommunicationRequest;
import com.majesco.dcf.common.tagic.json.CustomerDetailRequest;
import com.majesco.dcf.common.tagic.json.CustomerDetailResponse;
import com.majesco.dcf.common.tagic.json.EmailAttachment;
import com.majesco.dcf.common.tagic.json.IdDetails;
import com.majesco.dcf.common.tagic.json.PendingPropListRequest;
import com.majesco.dcf.common.tagic.json.PendingPropListResponse;
import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ProposalStatus;
import com.majesco.dcf.common.tagic.json.ProposalStatusReq;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.SOAPInfo;
import com.majesco.dcf.common.tagic.service.AuthenticationService;
import com.majesco.dcf.common.tagic.service.CustomerService;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.TagicCommonService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;
import com.majesco.dcf.common.tagic.util.CommonHelper;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.motor.json.InspectionRequest;
import com.majesco.dcf.motor.json.InspectionResponse;
import com.majesco.dcf.motor.json.PreInspectionResultDetails;
import com.majesco.dcf.motor.serviceImpl.MotorServiceImpl;
import com.majesco.dcf.paproduct.entity.QuotationPA;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Age;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.DateofBirth;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.GenderofNominee;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.InsuredPerson;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Nominee;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeContribution;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeGuardianName;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineeGuardianwithNominee;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineewithInsuredPerson;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.WhethertheNomineeisaminor;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.PropRisks_Col;
import com.majesco.dcf.paproduct.jaxb.accidentguard.AccidentGuardProductProposalPolicy.PropRisks_Col.Risks;
import com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy;
import com.majesco.dcf.paproduct.jaxb.accidentguard.search.request.AccidentGuardPolicyProposalRequest;
import com.majesco.dcf.paproduct.jaxb.accidentguard.search.result.UserData_AccidentGuard_ABC;
import com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct;
import com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy;
import com.majesco.dcf.paproduct.jaxb.accidentshield.search.request.AccidentShieldInsuranceProposalRequest;
import com.majesco.dcf.paproduct.jaxb.accidentshield.search.result.UserDataAccidentShieldABC;
import com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal;
import com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy;
import com.majesco.dcf.paproduct.jaxb.secureplan.search.request.SecureFuturePlanProposalRequest;
import com.majesco.dcf.paproduct.jaxb.secureplan.search.result.UserDataSecuredFuturePlanABC;
import com.majesco.dcf.paproduct.json.IPAProposalDataRequest;
import com.majesco.dcf.paproduct.json.IPAProposalDataResponse;
import com.majesco.dcf.paproduct.json.IPAProposalRequest;
import com.majesco.dcf.paproduct.json.IPAProposalResponse;
import com.majesco.dcf.paproduct.json.InsuredDetails;
import com.majesco.dcf.paproduct.json.NomineeDetails;
import com.majesco.dcf.paproduct.json.PAQuickQuotPrmRequest;
import com.majesco.dcf.paproduct.json.PAQuickQuotPrmResponse;
import com.majesco.dcf.paproduct.json.SearchIPAQuotRequest;
import com.majesco.dcf.paproduct.json.SearchIPAQuotResponse;
import com.majesco.dcf.paproduct.service.IPAService;
import com.majesco.dcf.paproduct.util.IPAProductConstants;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;
import com.majesco.dcf.receipt.json.ReceiptPaymentDetails;
import com.majesco.dcf.receipt.json.ReceiptProposalDetails;
import com.majesco.dcf.util.CXFInBoundInterceptor;
import com.majesco.dcf.util.CXFOutInterceptor;
import com.majesco.dcf.common.chp.util.CdataWriterInterceptor;
import com.majesco.dcf.common.chp.util.JAXBXMLHandler;
import com.unotechsoft.stub.ipaservice.client.IPAService_Service;
import com.unotechsoft.stub.ipaservice.client.accidentguard.result.UWProductServiceResult;
import com.unotechsoft.stub.policysearch.client.LOVType;

@Service
@Transactional
public class IPAServiceImpl implements IPAService {
	
	final static Logger logger=Logger.getLogger(IPAServiceImpl.class);
	
	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/
	
	@Autowired
	DBService dbserv;
	
	@Autowired
	AuthenticationService authServ;
	
	@Autowired
	TagicCommonService commonService;
	
	@Autowired
	TagicCommunicationService communicationService;
	
	@Autowired
	CustomerService customerService;
	
public String propValue="";
	
	
	public String getWSDLURL(String param)
	{
		String propVal="";
		try
		{
			propVal = dbserv.getWSDLURL(param,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			return propVal;
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorServiceImpl :: getWSDLURL() method ::",ae);
		}
		return propVal;
	}

	
	private static Properties prop = new Properties();
	
	static{
		try{
	InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream("resource.properties");
	prop.load(inputStream);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	@Override
	public IPAProposalResponse getIPAProposalAG(IPAProposalRequest propPAReq) throws Exception
	{
		ObjectMapper objMap = new ObjectMapper();
		logger.info("Inside IPAServiceImpl :: getIPAProposalAG :: Entered"+objMap.writeValueAsString(propPAReq));
		
		
		IPAProposalResponse propPARes = new IPAProposalResponse();
		
		long transId=propPAReq.getLocalTransId();
		List<ResponseError> lstResErr  = new ArrayList<ResponseError>();
		ResponseError reserr = new ResponseError();
		PremiumDetails prmdet = new PremiumDetails();
		CXFInBoundInterceptor cxfInInterceptor =null;
		CXFOutInterceptor cxfOutInterceptor= null;
//		AccidentGuardProductProposalPolicy obj = new AccidentGuardProductProposalPolicy();
//		obj.getPropRisksCol().getRisks().get(0).
		
		JAXBXMLHandler jaxbHandler=new JAXBXMLHandler();
		String jaxbXML = "";
		List<String> list = new ArrayList<String>();
		Mapper mapper =null;
		String strProposalNo =null;		//10112016
		ReceiptProposalDetails proposalDtl = new ReceiptProposalDetails();	//10112016
		String emailId = "";
		String mobileNo = "";
		CommonHelper helper = new CommonHelper();
       
		try{
			list.add("IPAMapping.xml");
			mapper = (Mapper) new DozerBeanMapper(list);
			/*reserr.setErrorCode("101");
			reserr.setErrorMMessag("Sorry Authentication Issue....");
			lstResErr.add(reserr);
			
			prmdet.setNetPremium("100000");
			prmdet.setDiscount("100");
			prmdet.setPremiumPayable("400.00");
			prmdet.setServiceTax("200");
			prmdet.setSumInsured("10000");
			
			propPARes.setResultCode("0");
			propPARes.setResErr(lstResErr);
			propPARes.setPremDet(prmdet);*/
			
			//IPAProposalRequest genQuotrequest = motorUtil.getMotorExternalMapCalculator(calcMotReq);
			//TravelObjectConvertor travelConvertor = null;
			AccidentGuardProductProposalPolicy p2Dto = new AccidentGuardProductProposalPolicy();
//			mapper.map(propPAReq, p2Dto,"IPAProposalAG");
			//p2Dto = travelConvertor.getJaxbReqObjForTravQuot(propPAReq);
			
			propPAReq=mapToExternalCode(propPAReq);
			//if(logger.isDebugEnabled())
			logger.debug("Inside IPAServiceImpl :: getIPAProposalAG :: aftter external data map: "+objMap.writeValueAsString(propPAReq));
			
			if(propPAReq!=null && propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getCoreSumInsured()!=null){
				propPAReq.getLstcvrgDet().setCoreSumInsured("500000");
			}
			
			mapper.map(propPAReq, p2Dto,"IPAProposalAG");
			
			//Start:28/02/2017:Added for full name required by GC
			StringBuffer strFullName=new StringBuffer();
			strFullName.append(propPAReq.getFirstName());
			if(propPAReq.getMiddleName()!=null && !propPAReq.getMiddleName().equals(CommonConstants.BLANK_STRING))
				strFullName.append(" "+propPAReq.getMiddleName());
			if(propPAReq.getLastName()!=null && !propPAReq.getLastName().equals(CommonConstants.BLANK_STRING))
				strFullName.append(" "+propPAReq.getLastName());
			//End:28/02/2017:Added for full name required by GC
			p2Dto.setPropCustomerDtls_CustomerName(strFullName.toString().toUpperCase());
			PropRisks_Col riskCol=new PropRisks_Col();
			
			for(InsuredDetails insuredDet:propPAReq.getLstInsurDet()){
				Risks riskObj=new Risks();
				if (insuredDet!= null && insuredDet.getOtherPAInsurancePolNum()!= null && insuredDet.getOtherPAInsurancePolNum().equals("0")){
					insuredDet.setOtherPAInsurancePolNum(null);
				}
				mapper.map(insuredDet, riskObj, "IPAInsuredAG");
				riskObj.setPropRisks_OtherRiskPrem1("0");
				riskObj.setPropRisks_OtherRiskPrem2("0");
				riskObj.setPropRisks_Month("364"); // Currently defaulted to 364 as per ESB sample from unotechsoft.
				if(riskObj.getPropRisks_DoyouhaveanyOtherPAinsurance()==null || riskObj.getPropRisks_DoyouhaveanyOtherPAinsurance().equalsIgnoreCase(""))
					riskObj.setPropRisks_DoyouhaveanyOtherPAinsurance("false");
				
				if(riskObj.getPropRisks_AnyPEDillnesstreated()==null || riskObj.getPropRisks_AnyPEDillnesstreated().equalsIgnoreCase(""))
					riskObj.setPropRisks_AnyPEDillnesstreated("false");
				//riskObj.setPropRisks_InsuredName(strFullName.toString().toUpperCase());
				riskObj.setPropRisks_InsuredName(insuredDet.getInsuName());
				riskCol.getRisks().add(riskObj);
				//p2Dto.getPropRisks_Col().getRisks().add(riskObj);
			}
			p2Dto.setPropRisks_Col(riskCol);
			
			//Setting nominee details
			if(propPAReq.getLstNomDet()!=null && propPAReq.getLstNomDet().size()>0){
				OtherDetailsGrid othGrid=new OtherDetailsGrid();
				
				for(NomineeDetails nomineeDet:propPAReq.getLstNomDet()){
					
				NomineeDetailsGrid nomineeGrid=new NomineeDetailsGrid();
				nomineeGrid.setName(IPAProductConstants.IPA_NOMINEE_GRID_NAME);
				nomineeGrid.setValue(IPAProductConstants.IPA_NOMINEE_GRID_VALUE);
				
				NomineeDetailsGrid1 nomineeGrid1=new NomineeDetailsGrid1();
				nomineeGrid1.setType(IPAProductConstants.IPA_NOMINEE_TYPE);
				
				InsuredPerson insPerson=new InsuredPerson();
				insPerson.setName(IPAProductConstants.IPA_NOMINEE_InsuredPerson);
				insPerson.setValue(nomineeDet.getInsuPerson());
				//insPerson.setValue(strFullName.toString().toUpperCase());
				insPerson.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nomineeGrid1.setInsuredPerson(insPerson);
				
				Nominee nominee=new Nominee();
				nominee.setName(IPAProductConstants.IPA_NOMINEE_Nominee);
				nominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nominee.setValue(nomineeDet.getNomName());
				nomineeGrid1.setNominee(nominee);
				
				Age age=new Age();
				age.setName(IPAProductConstants.IPA_NOMINEE_Age);
				age.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				age.setValue(nomineeDet.getNomAge());
				nomineeGrid1.setAge(age);
				
				DateofBirth dtBirth=new DateofBirth();
				dtBirth.setName(IPAProductConstants.IPA_NOMINEE_DateofBirth);
				dtBirth.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				dtBirth.setValue(nomineeDet.getNomDOB());
				nomineeGrid1.setDateofBirth(dtBirth);
				
				GenderofNominee genderNominee=new GenderofNominee();
				genderNominee.setName(IPAProductConstants.IPA_NOMINEE_GenderofNominee);
				genderNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				genderNominee.setValue(nomineeDet.getNomGender());
				nomineeGrid1.setGenderofNominee(genderNominee);
				
				RelationshipofNomineeGuardianwithNominee relationshipNominee=new RelationshipofNomineeGuardianwithNominee();
				relationshipNominee.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineeGuardianwithNominee);
				relationshipNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				relationshipNominee.setValue(nomineeDet.getNomGaurdRelation()==null?"":nomineeDet.getNomGaurdRelation());
				nomineeGrid1.setRelationshipofNomineeGuardianwithNominee(relationshipNominee);
				
				RelationshipofNomineewithInsuredPerson relationshipInsured=new RelationshipofNomineewithInsuredPerson();
				relationshipInsured.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineewithInsuredPerson);
				relationshipInsured.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				relationshipInsured.setValue(nomineeDet.getNomRelation());
				nomineeGrid1.setRelationshipofNomineewithInsuredPerson(relationshipInsured);
				
				WhethertheNomineeisaminor nomineeMinor=new WhethertheNomineeisaminor();
				nomineeMinor.setName(IPAProductConstants.IPA_NOMINEE_WhethertheNomineeisaminor);
				nomineeMinor.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				//nomineeMinor.setValue(nomineeDet.getNomMinor());
				if(nomineeDet.getNomMinor().equalsIgnoreCase("true"))
					nomineeMinor.setValue("1");
				else
					nomineeMinor.setValue("0");
				nomineeGrid1.setWhethertheNomineeisaminor(nomineeMinor);
				
				NomineeGuardianName nomineeGuardName=new NomineeGuardianName();
				nomineeGuardName.setName(IPAProductConstants.IPA_NOMINEE_NomineeGuardianName);
				nomineeGuardName.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nomineeGuardName.setValue(nomineeDet.getNomGaurdian());
				nomineeGrid1.setNomineeGuardianName(nomineeGuardName);
				
				NomineeContribution nomineeContri=new NomineeContribution();
				nomineeContri.setName(IPAProductConstants.IPA_NOMINEE_NomineeContribution);
				nomineeContri.setType(IPAProductConstants.IPA_NOMINEE_FieldType_Double);
				nomineeContri.setValue(nomineeDet.getNomContribtn());
				nomineeGrid1.setNomineeContribution(nomineeContri);
				
				nomineeGrid.setNomineeDetailsGrid1(nomineeGrid1);
				othGrid.getNomineeDetailsGrid().add(nomineeGrid);
				}
				
				p2Dto.setOtherDetailsGrid(othGrid);
				
				
				
			}
			
			//Done hardcoding for testing purpose
			p2Dto.setPropIntermediaryDetails_IntermediaryCode(propPAReq.getProducerCode());
			p2Dto.setPropIntermediaryDetails_IntermediaryName(propPAReq.getProducerName());
//			p2Dto.setPropIntermediaryDetails_IntermediaryName("TAGIC");
			
			/*p2Dto.setPropGeneralProposalInformation_DisplayOfficeCode("0200");
			
			p2Dto.setPropGeneralProposalInformation_OfficeCode("90900");
			p2Dto.setPropGeneralProposalInformation_OfficeName("MUMBAI");
			p2Dto.setPropGeneralProposalInformation_BranchOfficeCode("90200");
			p2Dto.setPropGeneralProposalInformation_BusinessType_Mandatary("New Business");*/
			String remarks="";
			if (propPAReq!=null && (propPAReq.getQuoteNo()!=null && !propPAReq.getQuoteNo().equalsIgnoreCase(""))){
				remarks=propPAReq.getQuoteNo();
			}
			remarks=remarks.concat(":"+propPAReq.getRemarks());
			p2Dto.setPropGeneralProposalInformation_Remarks(remarks);
			p2Dto.setPropRisks_DifferentialSI("0");
			
			if(propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getCoreSumInsured()!=null)
			p2Dto.setPropRisks_BaseSIUnit(propPAReq.getLstcvrgDet().getCoreSumInsured());
			
			if(propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getSelfIsPolicyHolder()!=null)
				p2Dto.setPropRisks_SelfisPolicyHolderHimself(propPAReq.getLstcvrgDet().getSelfIsPolicyHolder());
			
			if(propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getOccuptnClassOfSelf()!=null)
				p2Dto.setPropRisks_OccupationClassOfSelf(propPAReq.getLstcvrgDet().getOccuptnClassOfSelf());
			if(propPAReq.getLstInsurDet()!=null && propPAReq.getLstInsurDet().size()>0){
				if(propPAReq.getLstInsurDet().get(0)!=null && propPAReq.getLstInsurDet().get(0).getOccupation()!=null)
				p2Dto.setPropRisks_Occupation(propPAReq.getLstInsurDet().get(0).getOccupation());
			}
			
			p2Dto.setPropEndorsementDtls_ISUWCompleted("True");
			p2Dto.setPropMODetails_TertiaryMOCode(CommonConstants.TERTIARY_MO_CODE);
			
			if(p2Dto.getPropRisks_Col()!=null && p2Dto.getPropRisks_Col().getRisks()!=null && p2Dto.getPropRisks_Col().getRisks().size()>0){
				for(int i=0;i<p2Dto.getPropRisks_Col().getRisks().size();i++){
					if(p2Dto.getPropRisks_Col().getRisks().get(i)!=null){
						p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_DifferentialSI("0");
						p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_EndorsementAmount("0"); // Endorsement amount / premium amount set default to 0.
						p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_Premium("0"); // Endorsement amount / premium amount set default to 0.
						if(p2Dto.getPropRisks_Col().getRisks().get(i).getPropRisks_OtherPAInsurancePolicyNo()==null){
							p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_OtherPAInsurancePolicyNo(CommonConstants.BLANK_STRING);
						}
						if(p2Dto.getPropRisks_Col().getRisks().get(i).getPropRisks_NameOftheInsurer()==null){
							p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_NameOftheInsurer(CommonConstants.BLANK_STRING);	
						}						
						if(p2Dto.getPropRisks_Col().getRisks().get(i).getPropRisks_IdentityProofType()==null)
							p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_IdentityProofType(CommonConstants.BLANK_STRING);
						if(p2Dto.getPropRisks_Col().getRisks().get(i).getPropRisks_IdentityProofNumber()==null)
							p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_IdentityProofNumber(CommonConstants.BLANK_STRING);
						
						p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_IsDataDeleted("false");
						p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_IsOldDataDeleted("false");
						p2Dto.getPropRisks_Col().getRisks().get(i).setIsOptionalCover("true");
					}
				}
			}
			
			if(propPAReq != null && propPAReq.getProposerDet()!= null && propPAReq.getProposerDet().getAddressDetList()!=null && p2Dto!=null && p2Dto.getPermanentLocation()!=null){
				
				String district[] = propPAReq.getProposerDet().getAddressDetList().getDistrict().split("-");
				if(district!=null && district.length>0){
					
					p2Dto.getPermanentLocation().setCityDistrictName(district[0].trim());
					p2Dto.getPermanentLocation().setCityDistrictCode(district[1].trim());
				}
				
				String state[] = propPAReq.getProposerDet().getAddressDetList().getState().split("-");
				if(state!=null && state.length>0){
					
					p2Dto.getPermanentLocation().setStateName(state[0].trim());
					p2Dto.getPermanentLocation().setStateCode(state[1].trim());
				}
				
				String city[] = propPAReq.getProposerDet().getAddressDetList().getCity().split("-");
				if(city!=null && city.length>0){
					
					p2Dto.getPermanentLocation().setCityName(city[0].trim());
					p2Dto.getPermanentLocation().setCityId(city[1].trim());
				}
				
				String pin[]=propPAReq.getProposerDet().getAddressDetList().getPincode().split("-");
				if(pin!=null && pin.length>0){
					p2Dto.getPermanentLocation().setPinCodeLocality(pin[0].trim());
					p2Dto.getPermanentLocation().setPinCode(pin[1].trim());
				}
				String country[]=propPAReq.getProposerDet().getAddressDetList().getCountry().split("-");
				if(country!=null && country.length>0){
					p2Dto.getPermanentLocation().setCountryName(country[0].trim());
					p2Dto.getPermanentLocation().setCountryID(country[1].trim());

				}
			}
			
           if(propPAReq != null && propPAReq.getProposerDet()!= null && propPAReq.getProposerDet().getAddressDetList()!=null && p2Dto!=null && p2Dto.getMailLocation()!=null){
				
				String district[] = propPAReq.getProposerDet().getAddressDetList().getDistrict().split("-");
				if(district!=null && district.length>0){
					
					p2Dto.getMailLocation().setCityDistrictName(district[0].trim());
					p2Dto.getMailLocation().setCityDistrictCode(district[1].trim());
				}
				
				String state[] = propPAReq.getProposerDet().getAddressDetList().getState().split("-");
				if(state!=null && state.length>0){
					
					p2Dto.getMailLocation().setStateName(state[0].trim());
					p2Dto.getMailLocation().setStateCode(state[1].trim());
				}
				
				String city[] = propPAReq.getProposerDet().getAddressDetList().getCity().split("-");
				if(city!=null && city.length>0){
					
					p2Dto.getMailLocation().setCityName(city[0].trim());
					p2Dto.getMailLocation().setCityId(city[1].trim());
				}
				
				String pin[]=propPAReq.getProposerDet().getAddressDetList().getPincode().split("-");
				if(pin!=null && pin.length>0){
					p2Dto.getMailLocation().setPinCodeLocality(pin[0].trim());
					p2Dto.getMailLocation().setPinCode(pin[1].trim());
				}
				String country[]=propPAReq.getProposerDet().getAddressDetList().getCountry().split("-");
				if(country!=null && country.length>0){
					p2Dto.getMailLocation().setCountryName(country[0].trim());
					p2Dto.getMailLocation().setCountryID(country[1].trim());

				}
			}
           
           //Start: 27122016| Added to retrieve Email & mobile no of proposal owner
           if(propPAReq != null && propPAReq.getProposerDet()!= null && propPAReq.getProposerDet().getContDetList()!=null){
        	   emailId = propPAReq.getProposerDet().getContDetList().getEmailID();
        	   mobileNo = propPAReq.getProposerDet().getContDetList().getMobileNumber();
        	   proposalDtl.setEmailId(emailId);
        	   proposalDtl.setMobileNo(mobileNo);
        	   proposalDtl.setPolicyEffDt(propPAReq.getPolInceptionDt());
        	   proposalDtl.setPolicyEndDt(propPAReq.getPolExpiryDt());
        	   proposalDtl.setCustomerName(propPAReq.getProposerDet().getTitle()+" "+propPAReq.getProposerDet().getFirstName()+" "+propPAReq.getProposerDet().getLastName());
        	   proposalDtl.setPlanName(propPAReq.getLstcvrgDet().getPlan());
        	   proposalDtl.setVehRegNo(null);
        	   
           }
           //End: 27122016| Added to retrieve Email & mobile no of proposal owner   
			
			jaxbXML=jaxbHandler.marshal(p2Dto);
			
			//if(logger.isDebugEnabled())
			logger.debug("Inside IPAServiceImpl :: getIPAProposalAG method :: jaxbXML :: "+jaxbXML);
			propValue=getWSDLURL(IPAProductConstants.IPA_ACCIDENTGUARD_SERVICE_WSDL);
			//propValue="http://172.17.203.45:9595/IPAService_SOAPOverHTTP?wsdl";
			URL url = new URL(propValue);
			IPAService_Service stub = new IPAService_Service(url);
			com.unotechsoft.stub.ipaservice.client.PolicyRequest reqQ = new com.unotechsoft.stub.ipaservice.client.PolicyRequest(); 
			
			/*Getting Authentication Token Starts Here*/
			//String propFileName = "resource.properties";
			String userID="";
			String password="";
			String responseFrom = "";
			/*Properties prop = new Properties();
			InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
			prop.load(inputStream);*/
			userID=propPAReq.getUserID();
			password=propPAReq.getPassword();
			responseFrom=prop.getProperty("ResponseFrom");
			
			//Start:Vishal<VAPT comments>| code added to set GC token into user object 
			if (propPAReq.getAuthToken()!=null ){
				reqQ.setAuthenticationToken(propPAReq.getAuthToken());
			}
			else{
				AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
				/*Getting Authentication Token Stops Here*/	
				reqQ.setAuthenticationToken(authRes.getResultRes());
			}
			//End:Vishal<VAPT comments>| code added to set GC token into user object				
						
			reqQ.setSource(smc_source);
			reqQ.setProductCode("4251");
			if (propPAReq.getIsRenew()!=null && propPAReq.getIsRenew().equalsIgnoreCase("true"))
				reqQ.setModeOfOperation("RENEWPOLICY");
			else
				reqQ.setModeOfOperation("NEWPOLICY");
			reqQ.setCampaign(smc_campaign);
			reqQ.setMedium(smc_medium);
			reqQ.setCIAName("");
			reqQ.setHashKey("");
			reqQ.setHostAddress("");
			reqQ.setInputXML(jaxbXML);
			reqQ.setIsBankDataRequired(false);
			reqQ.setIsCutomerAddressRequired(false);
			reqQ.setIsFinanciarDataRequired(false);
			reqQ.setIsManufacturerMappingRequired(false);
			reqQ.setIsRTOMappingRequired(false);
			reqQ.setUserId(propPAReq.getUserID());
			reqQ.setUserRole("ADMIN");
			
			com.unotechsoft.stub.ipaservice.client.IPAService port=stub.getSOAPOverHTTP();
			
			/*Client client=ClientProxy.getClient(port);
			PrintWriter writer = new PrintWriter(System.out);
			
			client.getOutInterceptors().add(new CdataWriterInterceptor());
			
			client.getInInterceptors().add(new LoggingInInterceptor(writer));
			
			client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
			//Service Time out code
			HTTPConduit conduit=(HTTPConduit)client.getConduit();
			HTTPClientPolicy clientPolicy=new HTTPClientPolicy();
			clientPolicy.setReceiveTimeout(60000);
			clientPolicy.setConnectionTimeout(30000);
			conduit.setClient(clientPolicy);
			//End:Service Time out code
*/			
			// Code added to save info abt SOAP in DB Start
			SOAPInfo soapInfo = new SOAPInfo();
			soapInfo.setTransactionID(transId);
			soapInfo.setLobService("saveProposal");
			soapInfo.setLobtype("42");
			soapInfo.setCreatedBy(propPAReq.getUserID());
			soapInfo.setProducerCode(propPAReq.getProducerCode());
			soapInfo.setSystemIP(propPAReq.getSystemIP());
			soapInfo.setTransactionEvent("SaveProposal / IPA-AG");
			soapInfo.setJsonRequest(objMap.writeValueAsString(propPAReq));
			soapInfo.setProductCode(propPAReq.getProdCode());
			
			
			cxfInInterceptor =new CXFInBoundInterceptor(soapInfo);
			cxfOutInterceptor= new CXFOutInterceptor(soapInfo);
			
			ServiceUtility utility = new ServiceUtility();
			utility.addClientInterceptorDB(port,cxfInInterceptor,cxfOutInterceptor);
			
			com.unotechsoft.stub.ipaservice.client.PolicyResponce response = port.saveProposal(reqQ);
			//if(logger.isDebugEnabled())
			logger.debug("Adding Out Logs to DB");
			dbserv.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
			//if(logger.isDebugEnabled())
			logger.debug("Adding In Logs to DB");
			dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());				
			
//Code end for Saving SOAP Data to DB.	
			
			String responseXML = null;
			responseXML=response.getResponseXML();
			responseXML=responseXML.replaceAll("ns2:", "");
			
			propPARes.setProposalNumber(response.getProposalNumber());
			propPARes.setResultCode("1");
			
			UWProductServiceResult uwResult=new UWProductServiceResult();
			if(responseXML!=null){
				if(responseFrom!=null && responseFrom.equalsIgnoreCase("TataAIG"))
				{
					uwResult=(UWProductServiceResult)jaxbHandler.unmarshal(responseXML, uwResult);
				}
				
				else if(responseFrom!=null && responseFrom.equalsIgnoreCase("MajescoQC"))
				{	
					uwResult=(UWProductServiceResult)jaxbHandler.unmarshalTest(new File("/responseAccidentGaurd.xml"), uwResult);
				}
			}
			if(uwResult!=null && uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().size()>0 && uwResult.getUWOperationResult().get(0)!=null){
				if(uwResult.getUWOperationResult().get(0).getErrorText()!=null && !uwResult.getUWOperationResult().get(0).getErrorText().equals(""))
				{
					propPARes.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR");
					errorRes.setErrorMMessag(uwResult.getUWOperationResult().get(0).getErrorText());
					errorList.add(errorRes);
					propPARes.setResErr(errorList);
					if(cxfInInterceptor!=null){
						cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(propPARes));
						dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());	
					}
					return propPARes;
				}
				else{
					
                    //Start:Added to set proposal response field to be used in AccountService
					
					
					ReceiptPaymentDetails paymentDtl = new ReceiptPaymentDetails();
					//if(logger.isDebugEnabled())
					logger.debug("before check for  getUWOperationResult" );
					
					if(uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().get(0)!=null){
						//if(logger.isDebugEnabled())
						logger.debug("before check for getUWOperationResult "+objMap.writeValueAsString(uwResult.getUWOperationResult().get(0)) );
						
						if(uwResult.getUWOperationResult().get(0).getConfWFHelper()!=null && uwResult.getUWOperationResult().get(0).getConfWFHelper().get(0)!=null){
							propPARes.setProposalSystemId(uwResult.getUWOperationResult().get(0).getConfWFHelper().get(0).getWFSystemID());
							//RahulT: code added to remove W from prefix.
							if(propPARes.getProposalSystemId()!=null){
								propPARes.setProposalSystemId(propPARes.getProposalSystemId().substring(1, propPARes.getProposalSystemId().length()));
							}
							//RahulT: code added to remove W from prefix.
							//Start:07-Sep-2016:Added UW rules warning text from GC
							if(uwResult.getUWOperationResult().get(0).getWarningText()!=null)
								propPARes.setRulesWarning(uwResult.getUWOperationResult().get(0).getWarningText());
							//End:07-Sep-2016:Added UW rules warning text from GC
						}
						
						if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null){
						propPARes.setBusinessLocation(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
						propPARes.setDepositOfficeCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
						propPARes.setBussLocName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeName());
						}
						
					
					propPARes.setProposalNumber(uwResult.getUWOperationResult().get(0).getProposalNo());
					propPARes.setProposalDate(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationProposalDateMandatary());
					
					if(uwResult.getUWOperationResult().get(0).getNetPremium()!=null)
						prmdet.setNetPremium(uwResult.getUWOperationResult().get(0).getNetPremium());
					if(uwResult.getUWOperationResult().get(0).getTotalPremium()!=null)
						prmdet.setTotalPremium(uwResult.getUWOperationResult().get(0).getTotalPremium());
					if(uwResult.getUWOperationResult().get(0).getTotalSI()!=null)
						prmdet.setSumInsured(uwResult.getUWOperationResult().get(0).getTotalSI());
					if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null)
						prmdet.setServiceTax(uwResult.getUWOperationResult().get(0).getServiceTax());
					
					}//End:Added to set proposal response field to be used in AccountService
					
					// set values in response
					if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null){
						//Start:TAGIC:21/12/2016:Changes done for account service branch location.
						/*propPARes.setBusinessLocation(respObj.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
						propPARes.setDepositOfficeCode(respObj.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());*/
						propPARes.setBusinessLocation(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationBranchOfficeCode());	
						propPARes.setDepositOfficeCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationBranchOfficeCode());
						//Start:TAGIC:21/12/2016:Changes done for account service branch location.
						propPARes.setBussLocName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeName());
						proposalDtl.setCustomerId(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropCustomerDtlsCustomerIDMandatary());	//10112016
						//proposalDtl.setCustomerName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropCustomerDtlsCustomerName());	//10112016
						proposalDtl.setProductCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationProductCode());	//10112016
						proposalDtl.setProposalSystemId(propPARes.getProposalSystemId());	//10112016
						proposalDtl.setBusinessLocation(propPARes.getBusinessLocation());	//10112016
						proposalDtl.setDepositOfficeCode(propPARes.getDepositOfficeCode());	//10112016
						proposalDtl.setBussLocName(propPARes.getBussLocName());	//10112016
						proposalDtl.setProductLine("Accident Guard");
						proposalDtl.setProductCode("4251");
					}
					
					/*Added To Send Application Number To UI*/
					if(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodesApplicationNo()!=null)
					{
						propPARes.setApplcationNo(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodesApplicationNo());
					}
					else
					{
						propPARes.setApplcationNo("");
					}
					/*Added To Send Application Number To UI*/
					
//################## Calling getPendingProposalList service to stop proceed to pay call IPA: 09/03/2017 : Start #################################
					
					String declinedStatus=null,transactionType=null;
					PendingPropListRequest pendingPropListRequest = new PendingPropListRequest();
					PendingPropListResponse pendingPropListResponse = new PendingPropListResponse();
					
					pendingPropListRequest.setEntityType(propPAReq.getUserType()==null ? "INTERMEDIARY":propPAReq.getUserType());
					pendingPropListRequest.setEntityCode(propPAReq.getProducerCode()==null ? "" : propPAReq.getProducerCode());
					
					pendingPropListRequest.setProposalNo(propPARes.getProposalNumber());
					//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: getIPAProposalAG() method :: Calling Service For getPendingProposalList: for  "+ propPARes.getProposalNumber());
					pendingPropListResponse = commonService.getPendingProposalList(pendingPropListRequest);
										
					if(pendingPropListResponse!=null){
						declinedStatus = pendingPropListResponse.getDeclinedStatus();
						transactionType = pendingPropListResponse.getTransactionType();
						if(declinedStatus != null && transactionType !=null){
							//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalAG() method :: Calling Service For declinedStatus: for  "+ declinedStatus);
							if(declinedStatus.equalsIgnoreCase("NPDP") || declinedStatus.equalsIgnoreCase("NMTD") || declinedStatus.equalsIgnoreCase("NR") || transactionType.equalsIgnoreCase("DECLINED")){
								
								 if (pendingPropListResponse!=null && pendingPropListResponse.getDeclinedStatus()!=null) 
			                     {								
			                    	 propPARes.setProposalStatus(pendingPropListResponse.getDeclinedStatus()==null?"":pendingPropListResponse.getDeclinedStatus());
			                     }
			                     if (pendingPropListResponse!=null && pendingPropListResponse.getDeclinedStatusDesc()!=null) 
			                     {
			                    	 //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: getIPAProposalAG() method :: VJ : " + pendingPropListResponse.getDeclinedStatusDesc());
			                    	 propPARes.setProposalStatusDesc(pendingPropListResponse.getDeclinedStatusDesc()==null?"":pendingPropListResponse.getDeclinedStatusDesc());
			                     }
			                     
								
							}else{								
								//To set proposalStatus in propRes Start														
			                    if (propPARes.getProposalNumber() != null && !propPARes.getProposalNumber().equalsIgnoreCase("")) 
			                    {
			                    	try{
			                    	
						                   ProposalStatusReq proposalStatusReq = new ProposalStatusReq();
						                   proposalStatusReq.setProposalNo(propPARes.getProposalNumber());
						                   strProposalNo = propPARes.getProposalNumber();	//10112016
						                   proposalDtl.setProposalNo(strProposalNo);	//10112016
						                 //Start:TAGIC:20/12/2016:Added for new proposal status search service.
						                   proposalStatusReq.setAuthToken(reqQ.getAuthenticationToken());
						                   proposalStatusReq.setProducerCode(propPAReq.getProducerCode());
						                   proposalStatusReq.setProductCode(propPAReq.getProdCode());
						                   proposalStatusReq.setUserID(userID);
						                 //End:TAGIC:20/12/2016:Added for new proposal status search service.
						                   ProposalStatus proposalStatus = new ProposalStatus();
						                   proposalStatus = commonService.getProposalStatus(proposalStatusReq);
						                   
						                    //logger.info("TransactionID:"+transId+" :: Inside IPAServiceImpl :: getIPAProposalAG() method :: ProposalStatus: " + proposalStatus.getProposalStatus() + " :: ProposalStatusDesc : " + proposalStatus.getProposalStatusDesc());
						                   
						                    if (proposalStatus.getProposalStatus()!=null) 
						                    {
						                    	propPARes.setProposalStatus(proposalStatus.getProposalStatus());
						                    }
						                    if (proposalStatus.getProposalStatusDesc()!=null) 
						                    {
						                    	propPARes.setProposalStatusDesc(proposalStatus.getProposalStatusDesc());
						                    }
			                    	}
			                    	catch(Exception e){
			                    		e.printStackTrace();
			                    	}
			                    }
			                    //To set proposalStatus in propRes End
							}
						}else{
							//To set proposalStatus in propRes Start														
		                    if (propPARes.getProposalNumber() != null && !propPARes.getProposalNumber().equalsIgnoreCase("")) 
		                    {
		                    	try{
		                    	
					                   ProposalStatusReq proposalStatusReq = new ProposalStatusReq();
					                   proposalStatusReq.setProposalNo(propPARes.getProposalNumber());
					                   strProposalNo = propPARes.getProposalNumber();	//10112016
					                   proposalDtl.setProposalNo(strProposalNo);	//10112016
					                 //Start:TAGIC:20/12/2016:Added for new proposal status search service.
					                   proposalStatusReq.setAuthToken(reqQ.getAuthenticationToken());
					                   proposalStatusReq.setProducerCode(propPAReq.getProducerCode());
					                   proposalStatusReq.setProductCode(propPAReq.getProdCode());
					                   proposalStatusReq.setUserID(userID);
					                 //End:TAGIC:20/12/2016:Added for new proposal status search service.
					                   ProposalStatus proposalStatus = new ProposalStatus();
					                   proposalStatus = commonService.getProposalStatus(proposalStatusReq);
					                   
					                    //logger.info("TransactionID:"+transId+" :: Inside IPAServiceImpl :: getIPAProposalAG() method :: ProposalStatus: " + proposalStatus.getProposalStatus() + " :: ProposalStatusDesc : " + proposalStatus.getProposalStatusDesc());
					                   
					                    if (proposalStatus.getProposalStatus()!=null) 
					                    {
					                    	propPARes.setProposalStatus(proposalStatus.getProposalStatus());
					                    }
					                    if (proposalStatus.getProposalStatusDesc()!=null) 
					                    {
					                    	propPARes.setProposalStatusDesc(proposalStatus.getProposalStatusDesc());
					                    }
		                    	}
		                    	catch(Exception e){
		                    		e.printStackTrace();
		                    	}
		                    }
		                    //To set proposalStatus in propRes End
						}
						
					}
					
	//################## Calling getPendingProposalList service to stop proceed to pay call IPA: 08/03/2017 : End   #################################
   
					propPARes.setPremDet(prmdet);
				}
			}
			
            //Start: 10112016
			if (propPARes.getProposalNumber() != null && !propPARes.getProposalNumber().equalsIgnoreCase("")) {
				//Persisting data into transaction table for Save customer service.
				int updateCount = 0;
				try{
					updateCount = dbserv.updateUserTransForProposal(strProposalNo,propPAReq.getQuoteNo());	//RahulT| user transaction changes	
					dbserv.updateQuotForProposal(strProposalNo,propPAReq.getQuoteNo());	//RahulT| update quotation detail table
				}
				catch(Exception e){
					e.printStackTrace();
				}	
				if (updateCount == 0){
					UserTransaction transaction = new UserTransaction();
					transaction.setStrPropNumber(strProposalNo);
					transaction.setDtCreated(new Date());
					transaction.setDtTrans(new Date());
					transaction.setStrCreatedBy(userID);
					transaction.setStrlob("IPA");
					transaction.setStrProducercd(propPAReq.getProducerCode());	// 27122016
					transaction.setStrTranstype("Save Proposal");
					transaction.setStrUserid(userID);
					transaction.setDtotSA(new Double(prmdet.getSumInsured()));
					transaction.setStrIPAddress(propPAReq.getSystemIP());
					transaction.setTotalPremium(prmdet.getTotalPremium());
					transaction.setStrCustomerId(propPAReq.getCustCode());
					transaction.setStrWorkflowId(propPARes.getProposalSystemId());
					dbserv.saveOrUpdate(transaction);
				}
				//Persisting data into online staging table for Save customer service.
				ReceiptCumPolicyRequest accountServReq = new ReceiptCumPolicyRequest();
				accountServReq.setProposalDetails(proposalDtl);
				
				/*OnlineAccountService entity = new OnlineAccountService();
				entity.setStrOrderID(proposalDtl.getProposalNo());
				entity.setStrRequestMsg(objMap.writeValueAsString(accountServReq));
				logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: Saving Entity for Billdesk --> online Entity Request Object::"+entity.getStrRequestMsg());
				dbserv.saveOrUpdate(entity);*/
				
				// send mail
				String payAmount = null;
				if (propPAReq.getIsRenew()== null || !propPAReq.getIsRenew().equalsIgnoreCase("true")){
					if (emailId!=null && !emailId.equals("")){
						try{
							if (prmdet.getTotalPremium()!=null && !prmdet.getTotalPremium().equals("")){
								double d = Double.valueOf(prmdet.getTotalPremium()).doubleValue();
								payAmount = new String(""+Math.round(d));
								
							}
							CommunicationRequest commRequest = new CommunicationRequest();
							EmailAttachment attachment = new EmailAttachment(); 
							commRequest.setAlertType(CommonConstants.SEND_EMAIL);
							commRequest.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA);
							commRequest.setReceipient(emailId);
							commRequest.setParam1(proposalDtl.getCustomerName());
							commRequest.setParam2(proposalDtl.getProposalNo());
							commRequest.setParam3("Accident Guard");
							commRequest.setParam4(propPAReq.getLstcvrgDet().getPlan()==null?"":propPAReq.getLstcvrgDet().getPlan());
							commRequest.setParam5(payAmount==null?"":payAmount);
							commRequest.setParam6(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
							commRequest.setParam7(propPAReq.getProducerCode()==null?"":propPAReq.getProducerCode());
							commRequest.setParam8(propPAReq.getPolInceptionDt()==null?"":propPAReq.getPolInceptionDt());
							commRequest.setParam9(propPAReq.getPolExpiryDt()==null?"":propPAReq.getPolExpiryDt());
							
							commRequest.setParam10(proposalDtl.getCustomerName()==null?"":proposalDtl.getCustomerName());
							commRequest.setParam11("Accident Guard");	
							commRequest.setParam12(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
							commRequest.setParam13(propPAReq.getProducerMobile()==null ?"1800 - 266 - 7780":propPAReq.getProducerMobile());
							
							attachment.setCustomerID(propPAReq.getCustCode()==null?"":propPAReq.getCustCode());
							attachment.setProposalNumber(strProposalNo);
							attachment.setProductCode(proposalDtl.getProductCode()==null?"":proposalDtl.getProductCode());
							attachment.setProposalDate(propPARes.getProposalDate()==null?"":propPARes.getProposalDate());
							commRequest.setEmailAttachment(attachment);
							commRequest.setUserID(propPAReq.getUserID());
							commRequest.setPassword(propPAReq.getPassword());
							//communicationService.sendCommunication(commRequest);   // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAG method ::: Mail sent successfully to "+emailId);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
						// sending mail to producer
						try{
							if(propPAReq.getProducerEmail()!=null && !propPAReq.getProducerEmail().equals("")){
								if (prmdet.getTotalPremium()!=null && !prmdet.getTotalPremium().equals("")){
									double d = Double.valueOf(prmdet.getTotalPremium()).doubleValue();
									payAmount = new String(""+Math.round(d));
									
								}
								CommunicationRequest commRequestProducer = new CommunicationRequest();
								EmailAttachment attachmentProducer = new EmailAttachment(); 
								commRequestProducer.setAlertType(CommonConstants.SEND_EMAIL);
								commRequestProducer.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA_PRODUCER);
								commRequestProducer.setReceipient(propPAReq.getProducerEmail());
								commRequestProducer.setParam1(proposalDtl.getCustomerName());
								commRequestProducer.setParam2(proposalDtl.getProposalNo());
								commRequestProducer.setParam3("Accident Guard");
								commRequestProducer.setParam4(propPAReq.getLstcvrgDet().getPlan()==null?"":propPAReq.getLstcvrgDet().getPlan());
								commRequestProducer.setParam5(payAmount==null?"":payAmount);
								commRequestProducer.setParam6(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
								commRequestProducer.setParam7(propPAReq.getProducerCode()==null?"":propPAReq.getProducerCode());
								commRequestProducer.setParam8(propPAReq.getPolInceptionDt()==null?"":propPAReq.getPolInceptionDt());
								commRequestProducer.setParam9(propPAReq.getPolExpiryDt()==null?"":propPAReq.getPolExpiryDt());
								
								commRequestProducer.setParam10(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
								commRequestProducer.setParam11(proposalDtl.getCustomerName()==null?"":proposalDtl.getCustomerName());
								commRequestProducer.setParam12("Accident Guard");
								
								attachmentProducer.setCustomerID(propPAReq.getCustCode()==null?"":propPAReq.getCustCode());
								attachmentProducer.setProposalNumber(strProposalNo);
								attachmentProducer.setProductCode(proposalDtl.getProductCode()==null?"":proposalDtl.getProductCode());
								attachmentProducer.setProposalDate(propPARes.getProposalDate()==null?"":propPARes.getProposalDate());
								commRequestProducer.setEmailAttachment(attachmentProducer);
								commRequestProducer.setUserID(propPAReq.getUserID());
								commRequestProducer.setPassword(propPAReq.getPassword());
								//communicationService.sendCommunication(commRequestProducer); // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
								//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAG method ::: Mail sent successfully to Producer on "+propPAReq.getProducerEmail());

							}
						}
						catch(Exception e){
							e.printStackTrace();
						}
						//sending SMS to producer
						if (propPAReq.getProducerMobile()!=null && !propPAReq.getProducerMobile().equals("")){
							try{
								CommunicationRequest commRequestSMSProducer = new CommunicationRequest();
								//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
								commRequestSMSProducer.setAlertType(CommonConstants.SEND_SMS);
								commRequestSMSProducer.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA_PRODUCER);
								commRequestSMSProducer.setReceipient(propPAReq.getProducerMobile());
								commRequestSMSProducer.setParam1(propPAReq.getProducerName());
								commRequestSMSProducer.setParam2(proposalDtl.getCustomerName());
								commRequestSMSProducer.setParam3("Accident Guard");	//plan name
								commRequestSMSProducer.setParam4(emailId== null ? "" :emailId);
								commRequestSMSProducer.setParam5(propPARes.getProposalNumber());	
								commRequestSMSProducer.setParam6(payAmount==null?"-":payAmount);
								commRequestSMSProducer.setUserID(propPAReq.getUserID());
								commRequestSMSProducer.setPassword(propPAReq.getPassword());
								//communicationService.sendCommunication(commRequestSMSProducer); // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
								//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAG method ::: SMS sent successfully to producer on "+propPAReq.getProducerMobile());

							}
							catch(Exception e){
								e.printStackTrace();
							}
						}
					
					if (mobileNo!=null && !mobileNo.equals("")){
						//Start: changes done to set values for sms in fresh instance
						try{
							CommunicationRequest commRequestSMS = new CommunicationRequest();
							//End: changes done to set values for sms in fresh instance
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
							commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMS.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA);
							commRequestSMS.setReceipient(mobileNo);
							commRequestSMS.setParam1(proposalDtl.getCustomerName());
							commRequestSMS.setParam2("Accident Guard");
							commRequestSMS.setParam3(emailId== null ? "" :emailId);	//plan name
							commRequestSMS.setParam4(propPARes.getProposalNumber());
							commRequestSMS.setParam5(payAmount==null?"":payAmount);	
							commRequestSMS.setParam6(propPAReq.getProducerName());
							commRequestSMS.setParam7(propPAReq.getProducerMobile()==null ?"1800 - 266 - 7780":propPAReq.getProducerMobile());
							commRequestSMS.setUserID(propPAReq.getUserID());
							commRequestSMS.setPassword(propPAReq.getPassword());
							//communicationService.sendCommunication(commRequestSMS); // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAG method ::: SMS sent successfully to "+mobileNo);

						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
				}
				
				//Start: RahulT| code changes for sending mail/sms fo renewal cases
				else if (propPAReq.getIsRenew()!= null && propPAReq.getIsRenew().equalsIgnoreCase("true")){
					//helper.sendCommunicationRenewalIPAProp(proposalDtl,prmdet,propPAReq,propPARes,communicationService); // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
				}
			}
			
						
			//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: getIPAProposalAG :: response"+objMap.writeValueAsString(propPARes));
			
		}
		
		catch(Exception e)
		{
			propPARes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR");
			errorRes.setErrorMMessag(e.getMessage()+".Transaction ID::"+transId);
			errorList.add(errorRes);
			propPARes.setResErr(errorList);
			e.printStackTrace();
			logger.error("Inside IPAServiceImpl :: getIPAProposalAG method :: Exception Occurred : "+e+".Transaction ID::"+transId);
		}
		
		logger.info("End::"+transId+" :: IPAServiceImpl :: getIPAProposalAG :: Exit");
		if(cxfInInterceptor!=null){
			cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(propPARes));
			cxfInInterceptor.getInBound().setStrrefno(propPARes.getProposalNumber());
			dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());	
		}
		return propPARes;
	}
	
	public IPAProposalResponse generateIPAProposalAS(IPAProposalRequest propPAReq) throws Exception{
		
		ObjectMapper objMap = new ObjectMapper();
				
		IPAProposalResponse propPARes = new IPAProposalResponse();
		long transId=propPAReq.getLocalTransId();
		List<ResponseError> lstResErr  = new ArrayList<ResponseError>();
		ResponseError reserr = new ResponseError();
		PremiumDetails prmdet = new PremiumDetails();
		JAXBXMLHandler jaxbHandler=new JAXBXMLHandler();
		String jaxbXML = "";
		List<String> list = new ArrayList<String>();
		Mapper mapper=null;
		String strProposalNo =null;		//10112016
		String emailId = "";
		String mobileNo = "";
		ReceiptProposalDetails proposalDtl = new ReceiptProposalDetails();	//10112016
		logger.info("Start::"+transId+" :: IPAServiceImpl :: generateIPAProposalAS :: Entered"+objMap.writeValueAsString(propPAReq));
		CommonHelper helper = new CommonHelper();
		
		CXFInBoundInterceptor cxfInInterceptor =null;
		CXFOutInterceptor cxfOutInterceptor= null;
		
		
		try{
			list.add("IPAMapping.xml");
			
			mapper = (Mapper) new DozerBeanMapper(list);

			AccidentShieldCustomerCreateProduct p2Dto=new AccidentShieldCustomerCreateProduct();
//			mapper.map(propPAReq, p2Dto,"IPAProposalAG");
			//p2Dto = travelConvertor.getJaxbReqObjForTravQuot(propPAReq);
			propPAReq=mapToExternalCode(propPAReq);
			
			// Start: RahulT| Code added to send Plan description based on GC's Requirement
				if(propPAReq.getLstcvrgDet()!= null && propPAReq.getLstcvrgDet().getPlan()!= null){
					if (propPAReq.getLstcvrgDet().getPlan().equalsIgnoreCase("self")){
						propPAReq.getLstcvrgDet().setPlan(null);
				}
				else if(!propPAReq.getLstcvrgDet().getPlan().equals("") && !propPAReq.getLstcvrgDet().getPlan().equalsIgnoreCase("self")){
					propPAReq.getLstcvrgDet().setPlan("Family");
				}
			}
			//End: RahulT| Code added to send Plan description based on GC's Requirement
			
			//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: generateIPAProposalAS :: aftter external data map: "+objMap.writeValueAsString(propPAReq));
			
			mapper.map(propPAReq, p2Dto,"IPAProposalAS");
			//Start:28/02/2017:Added for full name required by GC
			StringBuffer strFullName=new StringBuffer();
			strFullName.append(propPAReq.getFirstName());
			if(propPAReq.getMiddleName()!=null && !propPAReq.getMiddleName().equals(CommonConstants.BLANK_STRING))
				strFullName.append(" "+propPAReq.getMiddleName());
			if(propPAReq.getLastName()!=null && !propPAReq.getLastName().equals(CommonConstants.BLANK_STRING))
				strFullName.append(" "+propPAReq.getLastName());
			//End:28/02/2017:Added for full name required by GC	
			
			p2Dto.setPropCustomerDtls_CustomerName(strFullName.toString().toUpperCase());
			
			com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.PropRisks_Col riskCol=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.PropRisks_Col();
			
			for(InsuredDetails insuredDet:propPAReq.getLstInsurDet()){
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.PropRisks_Col.Risks riskObj=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.PropRisks_Col.Risks();
				mapper.map(insuredDet, riskObj, "IPAInsuredAS");
				riskObj.setPropRisks_OtherRiskPrem1("0");
				riskObj.setPropRisks_OtherRiskPrem2("0");
				//Start: RahulT| Hardcoding to generate Accident shield proposal
				riskObj.setPropRisks_IdentityProofNumber(CommonConstants.BLANK_STRING);
				riskObj.setPropRisks_IdentityProofType(CommonConstants.BLANK_STRING);
				riskObj.setPropRisks_EndorsementAmount("0");
				riskObj.setPropRisks_Premium("0");
				riskObj.setPropRisks_Rate("0");
				//17092016
								
				if(riskObj.getPropRisks_AnyPEDillnesstreated()==null || riskObj.getPropRisks_AnyPEDillnesstreated().equalsIgnoreCase(""))
					riskObj.setPropRisks_AnyPEDillnesstreated("false");
				//riskObj.setPropRisks_Gender("Male");
				//riskObj.setPropRisks_Relationship(CommonConstants.BLANK_STRING);
				//riskObj.setPropRisks_Relationshipcode("01");
//				riskObj.setPropRisks_InsuredTitle("Mr");
				riskObj.setPropRisks_DifferentialSI("0");
//				riskObj.setPropRisks_MaritalStatus("Married");
				//riskObj.setPropRisks_Person("0");
				riskObj.setPropRisks_IsDataDeleted("false");
				riskObj.setPropRisks_IsOldDataDeleted("false");
				riskObj.setIsOptionalCover("true");
				//End: RahulT| Hardcoding to generate Accident shield proposal
				
				// RahulT: changes incorporated based on customer portal
				riskObj.setPropRisks_SumInsured(insuredDet.getSumInsured());
				riskObj.setPropRisks_Relationship(CommonConstants.BLANK_STRING);
				//End RahulT: changes incorporated based on customer portal
				//riskObj.setPropRisks_InsuredNameInsuredName(strFullName.toString().toUpperCase());
				riskObj.setPropRisks_InsuredNameInsuredName(insuredDet.getInsuName());
				riskCol.getRisks().add(riskObj);
				//p2Dto.getPropRisks_Col().getRisks().add(riskObj);
			}
			p2Dto.setPropRisks_Col(riskCol);
			
			//Setting nominee details
			if(propPAReq.getLstNomDet()!=null && propPAReq.getLstNomDet().size()>0){
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid othGrid=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid();
				
				for(NomineeDetails nomineeDet:propPAReq.getLstNomDet()){
					
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid nomineeGrid=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid();
				nomineeGrid.setName(IPAProductConstants.IPA_NOMINEE_GRID_NAME);
				nomineeGrid.setValue(IPAProductConstants.IPA_NOMINEE_GRID_VALUE);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1 nomineeGrid1=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1();
				nomineeGrid1.setType(IPAProductConstants.IPA_NOMINEE_TYPE);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.InsuredPerson insPerson=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.InsuredPerson();
				insPerson.setName(IPAProductConstants.IPA_NOMINEE_InsuredPerson);
				insPerson.setValue(nomineeDet.getInsuPerson());
				//insPerson.setValue(strFullName.toString().toUpperCase());
				insPerson.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nomineeGrid1.setInsuredPerson(insPerson);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Nominee nominee=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Nominee();
				nominee.setName(IPAProductConstants.IPA_NOMINEE_Nominee);
				nominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nominee.setValue(nomineeDet.getNomName());
				nomineeGrid1.setNominee(nominee);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Age age=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Age();
				age.setName(IPAProductConstants.IPA_NOMINEE_Age);
				age.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				age.setValue(nomineeDet.getNomAge());
				nomineeGrid1.setAge(age);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.DateofBirth dtBirth=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.DateofBirth();
				dtBirth.setName(IPAProductConstants.IPA_NOMINEE_DateofBirth);
				dtBirth.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				dtBirth.setValue(nomineeDet.getNomDOB());
				nomineeGrid1.setDateofBirth(dtBirth);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.GenderofNominee genderNominee=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.GenderofNominee();
				genderNominee.setName(IPAProductConstants.IPA_NOMINEE_GenderofNominee);
				genderNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				genderNominee.setValue(nomineeDet.getNomGender());
				nomineeGrid1.setGenderofNominee(genderNominee);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineeGuardianwithNominee relationshipNominee=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineeGuardianwithNominee();
				relationshipNominee.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineeGuardianwithNominee);
				relationshipNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				relationshipNominee.setValue(nomineeDet.getNomGaurdRelation()==null?"":nomineeDet.getNomGaurdRelation());
				nomineeGrid1.setRelationshipofNomineeGuardianwithNominee(relationshipNominee);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineewithInsuredPerson relationshipInsured=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineewithInsuredPerson();
				relationshipInsured.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineewithInsuredPerson);
				relationshipInsured.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				relationshipInsured.setValue(nomineeDet.getNomRelation());
				nomineeGrid1.setRelationshipofNomineewithInsuredPerson(relationshipInsured);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.WhethertheNomineeisaminor nomineeMinor=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.WhethertheNomineeisaminor();
				nomineeMinor.setName(IPAProductConstants.IPA_NOMINEE_WhethertheNomineeisaminor);
				nomineeMinor.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				//nomineeMinor.setValue(nomineeDet.getNomMinor());
				if(nomineeDet.getNomMinor().equalsIgnoreCase("true"))
					nomineeMinor.setValue("1");
				else
					nomineeMinor.setValue("0");
				nomineeGrid1.setWhethertheNomineeisaminor(nomineeMinor);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeGuardianName nomineeGuardName=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeGuardianName();
				nomineeGuardName.setName(IPAProductConstants.IPA_NOMINEE_NomineeGuardianName);
				nomineeGuardName.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nomineeGuardName.setValue(nomineeDet.getNomGaurdian());
				nomineeGrid1.setNomineeGuardianName(nomineeGuardName);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeContribution nomineeContri=new com.majesco.dcf.paproduct.jaxb.accidentshield.AccidentShieldCustomerCreateProduct.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeContribution();
				nomineeContri.setName(IPAProductConstants.IPA_NOMINEE_NomineeContribution);
				nomineeContri.setType(IPAProductConstants.IPA_NOMINEE_FieldType_Double);
				nomineeContri.setValue(nomineeDet.getNomContribtn());
				nomineeGrid1.setNomineeContribution(nomineeContri);
				
				nomineeGrid.setNomineeDetailsGrid1(nomineeGrid1);
				othGrid.getNomineeDetailsGrid().add(nomineeGrid);
				}
				
				p2Dto.setOtherDetailsGrid(othGrid);;
				
			}
			
			
			//Done hardcoding for testing purpose
			
			p2Dto.setPropIntermediaryDetails_IntermediaryCode(propPAReq.getProducerCode());
			p2Dto.setPropIntermediaryDetails_IntermediaryName(propPAReq.getProducerName());
//			p2Dto.setPropIntermediaryDetails_IntermediaryName("TAGIC");
			//Start: RahulT| Hardcoding to generate Accident shield proposal
			String defaultSysDate1 = new SimpleDateFormat(CommonConstants.UNIQUE_SEQUENCE).format(new java.util.Date());
			Date startDate=new Date();
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy", Locale.US);
			p2Dto.setPropSerIntermediaryDetails_SerIntermediaryCode(CommonConstants.BLANK_STRING);
			p2Dto.setPropSerIntermediaryDetails_SerIntermediaryName(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_PolicySchedule_Mandatary("Yes");
			p2Dto.setPropReferenceNoDate_ReferenceNo_Mandatary(defaultSysDate1);
			p2Dto.setPropPremiumCalculation_NetPremium("0");	// need to check this default value
			p2Dto.setPropPremiumCalculation_ServiceTax("0");
			p2Dto.setPropPremiumCalculation_TotalPremium("0");
			p2Dto.setPropPremiumCalculation_StampDuty("0");
			p2Dto.setPropMODetails_TertiaryMOName(CommonConstants.BLANK_STRING);
//			p2Dto.setPropIntermediaryDetails_IntermediaryType("Non-DM");	// need to check this default value
			p2Dto.setPropGeneralProposalInformation_Iscovernoteused("false");
			p2Dto.setPropGeneralProposalInformation_ManualCovernoteNo(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_Covernoteissuedate(sdf.format(startDate));
			p2Dto.setPropGeneralProposalInformation_Covernoteissuetime("21:04");
			p2Dto.setPropGeneralProposalInformation_QuoteNumber(CommonConstants.BLANK_STRING);
			///p2Dto.setPropRisks_AnnualGrossIncomePolicyHolder("0");		// RahulT: changes incorporated based on customer portal
			p2Dto.setPropGeneralProposalInformation_ManualCovernoteNo(CommonConstants.BLANK_STRING);
			//End: RahulT| Hardcoding to generate Accident shield proposal
			p2Dto.setPropGeneralProposalInformation_BusinessType_Mandatary("New Business");	// RahulT: Added during SIT. 
			
			
			String remarks="";
			if (propPAReq!=null && (propPAReq.getQuoteNo()!=null && !propPAReq.getQuoteNo().equalsIgnoreCase(""))){
				remarks=propPAReq.getQuoteNo();
			}
			remarks=remarks.concat(":"+propPAReq.getRemarks());
			p2Dto.setPropGeneralProposalInformation_Remarks(remarks);
			p2Dto.setPropRisks_DifferentialSI("0");
			
			if(propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getSelfIsPolicyHolder()!=null)
				p2Dto.setPropRisks_SelfisPolicyHolderHimself(propPAReq.getLstcvrgDet().getSelfIsPolicyHolder());
			
			if(propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getOccuptnClassOfSelf()!=null)
				p2Dto.setPropRisks_OccupationClassOfSelf(propPAReq.getLstcvrgDet().getOccuptnClassOfSelf());
			if(propPAReq.getLstInsurDet()!=null && propPAReq.getLstInsurDet().size()>0){
				if(propPAReq.getLstInsurDet().get(0)!=null && propPAReq.getLstInsurDet().get(0).getOccupation()!=null)
				p2Dto.setPropRisks_Occupation(propPAReq.getLstInsurDet().get(0).getOccupation());
			}
			
			p2Dto.setPropEndorsementDtls_ISUWCompleted("True");
			p2Dto.setPropMODetails_TertiaryMOCode(CommonConstants.TERTIARY_MO_CODE);
			
			
if(propPAReq != null && propPAReq.getProposerDet()!= null && propPAReq.getProposerDet().getAddressDetList()!=null && p2Dto!=null && p2Dto.getPermanentLocation()!=null){
				
				String district[] = propPAReq.getProposerDet().getAddressDetList().getDistrict().split("-");
				if(district!=null && district.length>0){
					
					p2Dto.getPermanentLocation().setCityDistrictName(district[0].trim());
					p2Dto.getPermanentLocation().setCityDistrictCode(district[1].trim());
				}
				
				String state[] = propPAReq.getProposerDet().getAddressDetList().getState().split("-");
				if(state!=null && state.length>0){
					
					p2Dto.getPermanentLocation().setStateName(state[0].trim());
					p2Dto.getPermanentLocation().setStateCode(state[1].trim());
				}
				
				String city[] = propPAReq.getProposerDet().getAddressDetList().getCity().split("-");
				if(city!=null && city.length>0){
					
					p2Dto.getPermanentLocation().setCityName(city[0].trim());
					p2Dto.getPermanentLocation().setCityId(city[1].trim());
				}
				
				String pin[]=propPAReq.getProposerDet().getAddressDetList().getPincode().split("-");
				if(pin!=null && pin.length>0){
					p2Dto.getPermanentLocation().setPinCodeLocality(pin[0].trim());
					p2Dto.getPermanentLocation().setPinCode(pin[1].trim());
				}
				String country[]=propPAReq.getProposerDet().getAddressDetList().getCountry().split("-");
				if(country!=null && country.length>0){
					p2Dto.getPermanentLocation().setCountryName(country[0].trim());
					p2Dto.getPermanentLocation().setCountryID(country[1].trim());

				}
			}
			
           if(propPAReq != null && propPAReq.getProposerDet()!= null && propPAReq.getProposerDet().getAddressDetList()!=null && p2Dto!=null && p2Dto.getMailLocation()!=null){
				
				String district[] = propPAReq.getProposerDet().getAddressDetList().getDistrict().split("-");
				if(district!=null && district.length>0){
					
					p2Dto.getMailLocation().setCityDistrictName(district[0].trim());
					p2Dto.getMailLocation().setCityDistrictCode(district[1].trim());
				}
				
				String state[] = propPAReq.getProposerDet().getAddressDetList().getState().split("-");
				if(state!=null && state.length>0){
					
					p2Dto.getMailLocation().setStateName(state[0].trim());
					p2Dto.getMailLocation().setStateCode(state[1].trim());
				}
				
				String city[] = propPAReq.getProposerDet().getAddressDetList().getCity().split("-");
				if(city!=null && city.length>0){
					
					p2Dto.getMailLocation().setCityName(city[0].trim());
					p2Dto.getMailLocation().setCityId(city[1].trim());
				}
				
				String pin[]=propPAReq.getProposerDet().getAddressDetList().getPincode().split("-");
				if(pin!=null && pin.length>0){
					p2Dto.getMailLocation().setPinCodeLocality(pin[0].trim());
					p2Dto.getMailLocation().setPinCode(pin[1].trim());
				}
				String country[]=propPAReq.getProposerDet().getAddressDetList().getCountry().split("-");
				if(country!=null && country.length>0){
					p2Dto.getMailLocation().setCountryName(country[0].trim());
					p2Dto.getMailLocation().setCountryID(country[1].trim());

				}
			}
           
         //Start: 27122016| Added to retrieve Email & mobile no of proposal owner
           if(propPAReq != null && propPAReq.getProposerDet()!= null && propPAReq.getProposerDet().getContDetList()!=null){
        	   emailId = propPAReq.getProposerDet().getContDetList().getEmailID();
        	   mobileNo = propPAReq.getProposerDet().getContDetList().getMobileNumber();
        	   proposalDtl.setEmailId(emailId);
        	   proposalDtl.setMobileNo(mobileNo);
        	   proposalDtl.setPolicyEffDt(propPAReq.getPolInceptionDt());
        	   proposalDtl.setPolicyEndDt(propPAReq.getPolExpiryDt());
        	   proposalDtl.setCustomerName(propPAReq.getProposerDet().getTitle()+" "+propPAReq.getProposerDet().getFirstName()+" "+propPAReq.getProposerDet().getLastName());
        	   proposalDtl.setPlanName(propPAReq.getLstcvrgDet().getPlan());
        	   proposalDtl.setVehRegNo(null);
           }
           //End: 27122016| Added to retrieve Email & mobile no of proposal owner   
			
			jaxbXML=JAXBXMLHandler.marshal(p2Dto);
			//System.out.println(jaxbXML);
			//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: generateIPAProposalAS method :: jaxbXML :: "+jaxbXML);
			propValue=getWSDLURL(IPAProductConstants.IPA_ACCIDENTSHIELD_SERVICE_WSDL);
			//propValue="http://172.17.203.45:9595/IPAService_SOAPOverHTTP?wsdl";
			URL url = new URL(propValue);
			IPAService_Service stub = new IPAService_Service(url);
			com.unotechsoft.stub.ipaservice.client.PolicyRequest reqQ = new com.unotechsoft.stub.ipaservice.client.PolicyRequest(); 
			
			/*Getting Authentication Token Starts Here*/
			//String propFileName = "resource.properties";
			String userID="";
			String password="";
			String responseFrom = "";
			/*Properties prop = new Properties();
			InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
			prop.load(inputStream);*/
			userID=propPAReq.getUserID();
			password=propPAReq.getPassword();;
			responseFrom=prop.getProperty("ResponseFrom");
			

			//Start:Vishal<VAPT comments>| code added to set GC token into user object 
			if (propPAReq.getAuthToken()!=null ){
				reqQ.setAuthenticationToken(propPAReq.getAuthToken());
			}
			else{
				AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
				/*Getting Authentication Token Stops Here*/	
				reqQ.setAuthenticationToken(authRes.getResultRes());
			}
			//End:Vishal<VAPT comments>| code added to set GC token into user object
			
			
			reqQ.setSource(smc_source);
			reqQ.setProductCode("4254");
			if (propPAReq.getIsRenew()!=null && propPAReq.getIsRenew().equalsIgnoreCase("true"))
				reqQ.setModeOfOperation("RENEWPOLICY");
			else
				reqQ.setModeOfOperation("NEWPOLICY");
			reqQ.setCampaign(smc_campaign);
			reqQ.setMedium(smc_medium);
			reqQ.setCIAName("");
			reqQ.setHashKey("");
			reqQ.setHostAddress("");
			reqQ.setInputXML(jaxbXML);
			reqQ.setIsBankDataRequired(false);
			reqQ.setIsCutomerAddressRequired(false);
			reqQ.setIsFinanciarDataRequired(false);
			reqQ.setIsManufacturerMappingRequired(false);
			reqQ.setIsRTOMappingRequired(false);
			reqQ.setUserId(propPAReq.getUserID());
			reqQ.setUserRole("ADMIN");
			
			com.unotechsoft.stub.ipaservice.client.IPAService port=stub.getSOAPOverHTTP();
			
			/*Client client=ClientProxy.getClient(port);
			PrintWriter writer = new PrintWriter(System.out);
			
			client.getOutInterceptors().add(new CdataWriterInterceptor());
			
			client.getInInterceptors().add(new LoggingInInterceptor(writer));
			
			client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
			//Service Time out code
			HTTPConduit conduit=(HTTPConduit)client.getConduit();
			HTTPClientPolicy clientPolicy=new HTTPClientPolicy();
			clientPolicy.setReceiveTimeout(60000);
			clientPolicy.setConnectionTimeout(30000);
			conduit.setClient(clientPolicy);
			//End:Service Time out code
*/			
			
			SOAPInfo soapInfo = new SOAPInfo();
			soapInfo.setTransactionID(transId);
			soapInfo.setLobService("saveProposal");
			soapInfo.setLobtype("42");
			soapInfo.setCreatedBy(propPAReq.getUserID());
			soapInfo.setProducerCode(propPAReq.getProducerCode());
			soapInfo.setSystemIP(propPAReq.getSystemIP());
			soapInfo.setTransactionEvent("saveProposal / IPA-AS");
			soapInfo.setJsonRequest(objMap.writeValueAsString(propPAReq));
			soapInfo.setProductCode(propPAReq.getProdCode());
			
			
			cxfInInterceptor =new CXFInBoundInterceptor(soapInfo);
			cxfOutInterceptor= new CXFOutInterceptor(soapInfo);
			
			ServiceUtility utility = new ServiceUtility();
			utility.addClientInterceptorDB(port,cxfInInterceptor,cxfOutInterceptor);
							
			
			com.unotechsoft.stub.ipaservice.client.PolicyResponce response = port.saveProposal(reqQ);
			
			//if(logger.isDebugEnabled())logger.debug("Adding Out Logs to DB");
			dbserv.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
			//if(logger.isDebugEnabled())logger.debug("Adding In Logs to DB");
			dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());				
			
//Code end for Saving SOAP Data to DB.			
			
			propPARes.setProposalNumber(response.getProposalNumber());
			propPARes.setResultCode("1");
			
			
			com.unotechsoft.stub.ipaservice.client.accidentshield.result.UWProductServiceResult uwResult=new com.unotechsoft.stub.ipaservice.client.accidentshield.result.UWProductServiceResult();
			String responseXML = null;
			if(response!=null && response.getResponseXML()!=null){
			responseXML=response.getResponseXML();
			responseXML=responseXML.replaceAll("ns2:", "");
			}
			
			if(responseXML!=null){
				if(responseFrom!=null && responseFrom.equalsIgnoreCase("TataAIG"))
				{
					uwResult=(com.unotechsoft.stub.ipaservice.client.accidentshield.result.UWProductServiceResult)jaxbHandler.unmarshal(responseXML, uwResult);
				}
				else if(responseFrom!=null && responseFrom.equalsIgnoreCase("MajescoQC"))
				{	
					uwResult=(com.unotechsoft.stub.ipaservice.client.accidentshield.result.UWProductServiceResult)jaxbHandler.unmarshalTest(new File("/responseAccidentShield.xml"), uwResult);
				}
			}
			if(uwResult!=null && uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().size()>0 && uwResult.getUWOperationResult().get(0)!=null){
				if(uwResult.getUWOperationResult().get(0).getErrorText()!=null && !uwResult.getUWOperationResult().get(0).getErrorText().equals(""))
				{
					propPARes.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR");
					errorRes.setErrorMMessag(uwResult.getUWOperationResult().get(0).getErrorText());
					errorList.add(errorRes);
					propPARes.setResErr(errorList);
					if(cxfInInterceptor!=null){
						cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(propPARes));
						dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());	
					}
					return propPARes;
				}
				else{
					
					if(uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().get(0)!=null){
						
						if(uwResult.getUWOperationResult().get(0).getConfWFHelper()!=null && uwResult.getUWOperationResult().get(0).getConfWFHelper().get(0)!=null){
							propPARes.setProposalSystemId(uwResult.getUWOperationResult().get(0).getConfWFHelper().get(0).getWFSystemID());
							//RahulT: code added to remove W from prefix.
							if(propPARes.getProposalSystemId()!=null){
								propPARes.setProposalSystemId(propPARes.getProposalSystemId().substring(1, propPARes.getProposalSystemId().length()));
							}
							//RahulT: code added to remove W from prefix.
							//Start:07-Sep-2016:Added UW rules warning text from GC
							if(uwResult.getUWOperationResult().get(0).getWarningText()!=null)
								propPARes.setRulesWarning(uwResult.getUWOperationResult().get(0).getWarningText());
							//End:07-Sep-2016:Added UW rules warning text from GC
						}
						
						if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null){
							//Start:TAGIC:21/12/2016:Changes done for account service branch location.
							/*propPARes.setBusinessLocation(respObj.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
							propPARes.setDepositOfficeCode(respObj.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());*/
							propPARes.setBusinessLocation(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_BranchOfficeCode());	
							propPARes.setDepositOfficeCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_BranchOfficeCode());
							//Start:TAGIC:21/12/2016:Changes done for account service branch location.
							propPARes.setBussLocName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_OfficeName());
							proposalDtl.setCustomerId(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropCustomerDtls_CustomerID_Mandatary());	//10112016
							//proposalDtl.setCustomerName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropCustomerDtls_CustomerName());	//10112016
							proposalDtl.setProductCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_ProductCode());	//10112016
							proposalDtl.setProposalSystemId(propPARes.getProposalSystemId());	//10112016
							proposalDtl.setBusinessLocation(propPARes.getBusinessLocation());	//10112016
							proposalDtl.setDepositOfficeCode(propPARes.getDepositOfficeCode());	//10112016
							proposalDtl.setBussLocName(propPARes.getBussLocName());	//10112016
							proposalDtl.setProductLine("Accident Shield");
							proposalDtl.setProductCode("4254");
						}
						
					
					propPARes.setProposalNumber(uwResult.getUWOperationResult().get(0).getProposalNo());
					propPARes.setProposalDate(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_ProposalDate_Mandatary());
					
					if(uwResult.getUWOperationResult().get(0).getNetPremium()!=null)
						prmdet.setNetPremium(uwResult.getUWOperationResult().get(0).getNetPremium());
					if(uwResult.getUWOperationResult().get(0).getTotalPremium()!=null)
						prmdet.setTotalPremium(uwResult.getUWOperationResult().get(0).getTotalPremium());
					if(uwResult.getUWOperationResult().get(0).getTotalSI()!=null)
						prmdet.setSumInsured(uwResult.getUWOperationResult().get(0).getTotalSI());
					if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null)
						prmdet.setServiceTax(uwResult.getUWOperationResult().get(0).getServiceTax());
					
					}//End:Added to set proposal response field to be used in AccountService
					
					/*Added To Send Application Number To UI*/
					if(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodes_ApplicationNo()!=null)
					{
						propPARes.setApplcationNo(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodes_ApplicationNo());
					}
					else
					{
						propPARes.setApplcationNo("");
					}
					/*Added To Send Application Number To UI*/
					
					// set values in response
					/*if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null){
						propPARes.setBusinessLocation(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
						propPARes.setDepositOfficeCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
						propPARes.setBussLocName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeName());
					}*/
					
//################## Calling getPendingProposalList service to stop proceed to pay call IPA AS: 09/03/2017 : Start #################################
					
					String declinedStatus=null,transactionType=null;
					PendingPropListRequest pendingPropListRequest = new PendingPropListRequest();
					PendingPropListResponse pendingPropListResponse = new PendingPropListResponse();
					
					pendingPropListRequest.setEntityType(propPAReq.getUserType()==null ? "INTERMEDIARY":propPAReq.getUserType());
					pendingPropListRequest.setEntityCode(propPAReq.getProducerCode()==null ? "" : propPAReq.getProducerCode());
					
					pendingPropListRequest.setProposalNo(propPARes.getProposalNumber());
					//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalAS() method :: Calling Service For getPendingProposalList: for  "+ propPARes.getProposalNumber());
					pendingPropListResponse = commonService.getPendingProposalList(pendingPropListRequest);
										
					if(pendingPropListResponse!=null){
						declinedStatus = pendingPropListResponse.getDeclinedStatus();
						transactionType = pendingPropListResponse.getTransactionType();
						if(declinedStatus != null && transactionType !=null){
							//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalAS() method :: Calling Service For declinedStatus: for  "+ declinedStatus);
							if(declinedStatus.equalsIgnoreCase("NPDP") || declinedStatus.equalsIgnoreCase("NMTD") || declinedStatus.equalsIgnoreCase("NR") || transactionType.equalsIgnoreCase("DECLINED")){
								
								 if (pendingPropListResponse!=null && pendingPropListResponse.getDeclinedStatus()!=null) 
			                     {
			                    	 
			                    	 propPARes.setProposalStatus(pendingPropListResponse.getDeclinedStatus()==null?"":pendingPropListResponse.getDeclinedStatus());
			                     }
			                     if (pendingPropListResponse!=null && pendingPropListResponse.getDeclinedStatusDesc()!=null) 
			                     {
			                    	 
			                    	 propPARes.setProposalStatusDesc(pendingPropListResponse.getDeclinedStatusDesc());
			                     }
			                     
								
							}else{
								
								//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalAS() method :: ELSE");
								
								
								//To set proposalStatus in propRes Start
						        if (propPARes.getProposalNumber() != null && !propPARes.getProposalNumber().equalsIgnoreCase("")) 
						        {
						        	try{
								       ProposalStatusReq proposalStatusReq = new ProposalStatusReq();
								       proposalStatusReq.setProposalNo(propPARes.getProposalNumber());
								       strProposalNo = propPARes.getProposalNumber();	//10112016
					                   proposalDtl.setProposalNo(strProposalNo);	//10112016
					                 //Start:TAGIC:20/12/2016:Added for new proposal status search service.
					                   proposalStatusReq.setAuthToken(reqQ.getAuthenticationToken());
					                   proposalStatusReq.setProducerCode(propPAReq.getProducerCode());
					                   proposalStatusReq.setProductCode(propPAReq.getProdCode());
					                   proposalStatusReq.setUserID(userID);
					                 //End:TAGIC:20/12/2016:Added for new proposal status search service.
								       ProposalStatus proposalStatus = new ProposalStatus();
								       proposalStatus = commonService.getProposalStatus(proposalStatusReq);
								       
								       //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalAS() method :: ProposalStatus: " + proposalStatus.getProposalStatus() + " :: ProposalStatusDesc : " + proposalStatus.getProposalStatusDesc());
								       
								        if (proposalStatus.getProposalStatus()!=null) 
								        {
								        	propPARes.setProposalStatus(proposalStatus.getProposalStatus());
								        }
								        if (proposalStatus.getProposalStatusDesc()!=null) 
								        {
								        	propPARes.setProposalStatusDesc(proposalStatus.getProposalStatusDesc());
								        }
						        	}
						        	catch(Exception e){
						        		e.printStackTrace();
						        	}
						        }
						        //To set proposalStatus in propRes End
							}
						}else{
							//To set proposalStatus in propRes Start														
		                    if (propPARes.getProposalNumber() != null && !propPARes.getProposalNumber().equalsIgnoreCase("")) 
		                    {
		                    	try{
		                    	
					                   ProposalStatusReq proposalStatusReq = new ProposalStatusReq();
					                   proposalStatusReq.setProposalNo(propPARes.getProposalNumber());
					                   strProposalNo = propPARes.getProposalNumber();	//10112016
					                   proposalDtl.setProposalNo(strProposalNo);	//10112016
					                 //Start:TAGIC:20/12/2016:Added for new proposal status search service.
					                   proposalStatusReq.setAuthToken(reqQ.getAuthenticationToken());
					                   proposalStatusReq.setProducerCode(propPAReq.getProducerCode());
					                   proposalStatusReq.setProductCode(propPAReq.getProdCode());
					                   proposalStatusReq.setUserID(userID);
					                 //End:TAGIC:20/12/2016:Added for new proposal status search service.
					                   ProposalStatus proposalStatus = new ProposalStatus();
					                   proposalStatus = commonService.getProposalStatus(proposalStatusReq);
					                   
					                    //logger.info("TransactionID:"+transId+" :: Inside IPAServiceImpl :: getIPAProposalAG() method :: ProposalStatus: " + proposalStatus.getProposalStatus() + " :: ProposalStatusDesc : " + proposalStatus.getProposalStatusDesc());
					                   
					                    if (proposalStatus.getProposalStatus()!=null) 
					                    {
					                    	propPARes.setProposalStatus(proposalStatus.getProposalStatus());
					                    }
					                    if (proposalStatus.getProposalStatusDesc()!=null) 
					                    {
					                    	propPARes.setProposalStatusDesc(proposalStatus.getProposalStatusDesc());
					                    }
		                    	}
		                    	catch(Exception e){
		                    		e.printStackTrace();
		                    	}
		                    }
		                    //To set proposalStatus in propRes End
						}
						
					}
					
	//################## Calling getPendingProposalList service to stop proceed to pay call IPA AS: 09/03/2017 : End   #################################								
					
					
					propPARes.setPremDet(prmdet);
				}
			}
			
			//Start: 10112016
			if (propPARes.getProposalNumber() != null && !propPARes.getProposalNumber().equalsIgnoreCase("")) {
				//Persisting data into transaction table for Save customer service.
				int updateCount = 0;
				try{
					updateCount = dbserv.updateUserTransForProposal(strProposalNo,propPAReq.getQuoteNo());	//RahulT| user transaction changes	
				}
				catch(Exception e){
					e.printStackTrace();
				}
				if (updateCount == 0){
					UserTransaction transaction = new UserTransaction();
					transaction.setStrPropNumber(strProposalNo);
					transaction.setDtCreated(new Date());
					transaction.setDtTrans(new Date());
					transaction.setStrCreatedBy(userID);
					transaction.setStrlob("IPA");
					transaction.setStrProducercd(propPAReq.getProducerCode());	// 27122016
					transaction.setStrTranstype("Save Proposal");
					transaction.setStrUserid(userID);
					transaction.setDtotSA(new Double(prmdet.getSumInsured()));
					transaction.setStrIPAddress(propPAReq.getSystemIP());
					transaction.setTotalPremium(prmdet.getTotalPremium());
					transaction.setStrCustomerId(propPAReq.getCustCode());
					transaction.setStrWorkflowId(propPARes.getProposalSystemId());
					dbserv.saveOrUpdate(transaction);
				}
				
				//Persisting data into online staging table for Save customer service.
				ReceiptCumPolicyRequest accountServReq = new ReceiptCumPolicyRequest();
				accountServReq.setProposalDetails(proposalDtl);
				
				/*OnlineAccountService entity = new OnlineAccountService();
				entity.setStrOrderID(proposalDtl.getProposalNo());
				entity.setStrRequestMsg(objMap.writeValueAsString(accountServReq));
				logger.info("In IPAServiceImpl :: getIPAProposalAS method ::: Saving Entity for Billdesk --> online Entity Request Object::"+entity.getStrRequestMsg());
				dbserv.saveOrUpdate(entity);*/
				
				// send mail
				String payAmount = null;
				if (propPAReq.getIsRenew()== null || !propPAReq.getIsRenew().equalsIgnoreCase("true")){
					if (emailId!=null && !emailId.equals("")){
						try{
							if (prmdet.getTotalPremium()!=null && !prmdet.getTotalPremium().equals("")){
								double d = Double.valueOf(prmdet.getTotalPremium()).doubleValue();
								payAmount = new String(""+Math.round(d));
								
							}
							CommunicationRequest commRequest = new CommunicationRequest();
							EmailAttachment attachment = new EmailAttachment(); 
							commRequest.setAlertType(CommonConstants.SEND_EMAIL);
							commRequest.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA);
							commRequest.setReceipient(emailId);
							commRequest.setParam1(proposalDtl.getCustomerName());
							commRequest.setParam2(proposalDtl.getProposalNo());
							commRequest.setParam3("Accident Shield");
							commRequest.setParam4(propPAReq.getLstcvrgDet().getPlan()==null?"":propPAReq.getLstcvrgDet().getPlan());
							commRequest.setParam5(payAmount==null?"":payAmount);
							commRequest.setParam6(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
							commRequest.setParam7(propPAReq.getProducerCode()==null?"":propPAReq.getProducerCode());
							commRequest.setParam8(propPAReq.getPolInceptionDt()==null?"":propPAReq.getPolInceptionDt());
							commRequest.setParam9(propPAReq.getPolExpiryDt()==null?"":propPAReq.getPolExpiryDt());	// Policy expiration date
							
							commRequest.setParam10(proposalDtl.getCustomerName()==null?"":proposalDtl.getCustomerName());
							commRequest.setParam11("Accident Shield");	
							commRequest.setParam12(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
							commRequest.setParam13(propPAReq.getProducerMobile()==null ?"1800 - 266 - 7780":propPAReq.getProducerMobile());
							
							attachment.setCustomerID(propPAReq.getCustCode()==null?"":propPAReq.getCustCode());
							attachment.setProposalNumber(strProposalNo);
							attachment.setProductCode(proposalDtl.getProductCode()==null?"":proposalDtl.getProductCode());
							attachment.setProposalDate(propPARes.getProposalDate()==null?"":propPARes.getProposalDate());
							commRequest.setEmailAttachment(attachment);
							commRequest.setUserID(propPAReq.getUserID());
							commRequest.setPassword(propPAReq.getPassword());
							//communicationService.sendCommunication(commRequest);  // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAS method ::: Mail sent successfully to "+emailId);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					// sending mail to producer
					try{
						if(propPAReq.getProducerEmail()!=null && !propPAReq.getProducerEmail().equals("")){
							if (prmdet.getTotalPremium()!=null && !prmdet.getTotalPremium().equals("")){
								double d = Double.valueOf(prmdet.getTotalPremium()).doubleValue();
								payAmount = new String(""+Math.round(d));
								
							}
							CommunicationRequest commRequestProducer = new CommunicationRequest();
							EmailAttachment attachmentProducer = new EmailAttachment(); 
							commRequestProducer.setAlertType(CommonConstants.SEND_EMAIL);
							commRequestProducer.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA_PRODUCER);
							commRequestProducer.setReceipient(propPAReq.getProducerEmail());
							commRequestProducer.setParam1(proposalDtl.getCustomerName());
							commRequestProducer.setParam2(proposalDtl.getProposalNo());
							commRequestProducer.setParam3("Accident Shield");
							commRequestProducer.setParam4(propPAReq.getLstcvrgDet().getPlan()==null?"":propPAReq.getLstcvrgDet().getPlan());
							commRequestProducer.setParam5(payAmount==null?"":payAmount);
							commRequestProducer.setParam6(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
							commRequestProducer.setParam7(propPAReq.getProducerCode()==null?"":propPAReq.getProducerCode());
							commRequestProducer.setParam8(propPAReq.getPolInceptionDt()==null?"":propPAReq.getPolInceptionDt());
							commRequestProducer.setParam9(propPAReq.getPolExpiryDt()==null?"":propPAReq.getPolExpiryDt());
							
							commRequestProducer.setParam10(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
							commRequestProducer.setParam11(proposalDtl.getCustomerName()==null?"":proposalDtl.getCustomerName());
							commRequestProducer.setParam12("Accident Shield");
							
							attachmentProducer.setCustomerID(propPAReq.getCustCode()==null?"":propPAReq.getCustCode());
							attachmentProducer.setProposalNumber(strProposalNo);
							attachmentProducer.setProductCode(proposalDtl.getProductCode()==null?"":proposalDtl.getProductCode());
							attachmentProducer.setProposalDate(propPARes.getProposalDate()==null?"":propPARes.getProposalDate());
							commRequestProducer.setEmailAttachment(attachmentProducer);
							commRequestProducer.setUserID(propPAReq.getUserID());
							commRequestProducer.setPassword(propPAReq.getPassword());
							//communicationService.sendCommunication(commRequestProducer); // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAS method ::: Mail sent successfully to Producer on "+propPAReq.getProducerEmail());

						}
					}
					catch(Exception e){
						e.printStackTrace();
					}
					//sending SMS to producer
					if (propPAReq.getProducerMobile()!=null && !propPAReq.getProducerMobile().equals("")){
						try{
							CommunicationRequest commRequestSMSProducer = new CommunicationRequest();
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAS method ::: sending SMS to  "+ mobileNo);
							commRequestSMSProducer.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMSProducer.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA_PRODUCER);
							commRequestSMSProducer.setReceipient(propPAReq.getProducerMobile());
							commRequestSMSProducer.setParam1(propPAReq.getProducerName());
							commRequestSMSProducer.setParam2(proposalDtl.getCustomerName());
							commRequestSMSProducer.setParam3("Accident Shield");	//plan name
							commRequestSMSProducer.setParam4(emailId== null ? "" :emailId);
							commRequestSMSProducer.setParam5(propPARes.getProposalNumber());	
							commRequestSMSProducer.setParam6(payAmount==null?"-":payAmount);
							commRequestSMSProducer.setUserID(propPAReq.getUserID());
							commRequestSMSProducer.setPassword(propPAReq.getPassword());
							//communicationService.sendCommunication(commRequestSMSProducer); // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAS method ::: SMS sent successfully to producer on "+propPAReq.getProducerMobile());

						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					if (mobileNo!=null && !mobileNo.equals("")){
						try{
							//Start: changes done to set values for sms in fresh instance
							CommunicationRequest commRequestSMS = new CommunicationRequest();
							//End: changes done to set values for sms in fresh instance
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
							commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMS.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA);
							commRequestSMS.setReceipient(mobileNo);
							commRequestSMS.setParam1(proposalDtl.getCustomerName());
							commRequestSMS.setParam2("Accident Shield");
							commRequestSMS.setParam3(emailId== null ? "" :emailId);	//plan name
							commRequestSMS.setParam4(propPARes.getProposalNumber());
							commRequestSMS.setParam5(payAmount==null?"":payAmount);	
							commRequestSMS.setParam6(propPAReq.getProducerName());
							commRequestSMS.setParam7(propPAReq.getProducerMobile()==null ?"1800 - 266 - 7780":propPAReq.getProducerMobile()); 
							commRequestSMS.setUserID(propPAReq.getUserID());
							commRequestSMS.setPassword(propPAReq.getPassword());
							//communicationService.sendCommunication(commRequestSMS); // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal

						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
				}
				//Start: RahulT| code changes for sending mail/sms fo renewal cases
				else if (propPAReq.getIsRenew()!= null && propPAReq.getIsRenew().equalsIgnoreCase("true")){
					//helper.sendCommunicationRenewalIPAProp(proposalDtl,prmdet,propPAReq,propPARes,communicationService); // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
				}
			}
			
			//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: generateIPAProposalAS :: response"+objMap.writeValueAsString(propPARes));
			
		}
		
		catch(Exception e)
		{
			propPARes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR");
			errorRes.setErrorMMessag(e.getMessage()+".Transaction ID::"+transId);
			errorList.add(errorRes);
			propPARes.setResErr(errorList);
			e.printStackTrace();
			logger.error("Inside IPAServiceImpl :: generateIPAProposalAS method :: Exception Occurred : "+e.toString()+".Transaction ID::"+transId);
		}
		
		logger.info("End::"+transId+" :: IPAServiceImpl :: generateIPAProposalAS :: Exit");
		if(cxfInInterceptor!=null){
			cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(propPARes));
			cxfInInterceptor.getInBound().setStrrefno(propPARes.getProposalNumber());
			dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());	
		}
		return propPARes;
	}

	public IPAProposalResponse generateIPAProposalSecurePlan(IPAProposalRequest propPAReq) throws Exception{
		
		IPAProposalResponse propPARes = new IPAProposalResponse();
		
		long transId=propPAReq.getLocalTransId();
		List<ResponseError> lstResErr  = new ArrayList<ResponseError>();
		ResponseError reserr = new ResponseError();
		PremiumDetails prmdet = new PremiumDetails();
		String strMethod="generateIPAProposalSecurePlan";
		JAXBXMLHandler jaxbHandler=new JAXBXMLHandler();
		String jaxbXML = "";
		List<String> list = new ArrayList<String>();
		ObjectMapper objMapper = new ObjectMapper();
		Mapper mapper=null;
		String strProposalNo =null;		//10112016
		ReceiptProposalDetails proposalDtl = new ReceiptProposalDetails();	//10112016
		String emailId = "";
		String mobileNo = "";
		CommonHelper helper = new CommonHelper();
		
		CXFInBoundInterceptor cxfInInterceptor =null;
		CXFOutInterceptor cxfOutInterceptor= null;
				
		logger.info("Start::"+transId+" :: IPAServiceImpl :: "+strMethod+" :: Entered :: JSONRequest :- "+objMapper.writeValueAsString(propPAReq));
		
		try{
			list.add("IPAMapping.xml");
			
			mapper = (Mapper) new DozerBeanMapper(list);

			SecureFuturePlanProposal p2Dto=new SecureFuturePlanProposal();
//			mapper.map(propPAReq, p2Dto,"IPAProposalAG");
			//p2Dto = travelConvertor.getJaxbReqObjForTravQuot(propPAReq);
			propPAReq=mapToExternalCode(propPAReq);
			mapper.map(propPAReq, p2Dto,"IPAProposalSecurePlan");
			
			//Start:28/02/2017:Added for full name required by GC
			StringBuffer strFullName=new StringBuffer();
			strFullName.append(propPAReq.getFirstName());
			if(propPAReq.getMiddleName()!=null && !propPAReq.getMiddleName().equals(CommonConstants.BLANK_STRING))
				strFullName.append(" "+propPAReq.getMiddleName());
			if(propPAReq.getLastName()!=null && !propPAReq.getLastName().equals(CommonConstants.BLANK_STRING))
				strFullName.append(" "+propPAReq.getLastName());
			//End:28/02/2017:Added for full name required by GC	
			
			p2Dto.setPropCustomerDtls_CustomerName(strFullName.toString().toUpperCase());
			
			com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.PropRisks_Col riskCol=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.PropRisks_Col();
			
			for(InsuredDetails insuredDet:propPAReq.getLstInsurDet()){
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.PropRisks_Col.Risks riskObj=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.PropRisks_Col.Risks();
				mapper.map(insuredDet, riskObj, "IPAInsuredSecurePlan");
				//Start: RahulT| Hardcoding to generate Accident shield proposal
				riskObj.setPropRisks_IdentityProofNumber(CommonConstants.BLANK_STRING);
				riskObj.setPropRisks_IdentityProofType(CommonConstants.BLANK_STRING);
				riskObj.setPropRisks_DifferentialSI("0");
				riskObj.setPropRisks_EndorsementAmount("0");
				riskObj.setPropRisks_Premium("0");
				riskObj.setPropRisks_Rate("0");
				riskObj.setPropRisks_IsDataDeleted("False");
				riskObj.setPropRisks_IsOldDataDeleted("False");
				riskObj.setIsOptionalCover("true");
				riskObj.setPropRisks_Relationship("Self");
				//End: RahulT| Hardcoding to generate Accident shield proposal
				//riskObj.setPropRisks_InsuredName(strFullName.toString().toUpperCase());
				riskObj.setPropRisks_InsuredName(insuredDet.getInsuName());
				riskCol.getRisks().add(riskObj);
				//p2Dto.getPropRisks_Col().getRisks().add(riskObj);
			}
			p2Dto.setPropRisks_Col(riskCol);
			
			//Setting nominee details
			if(propPAReq.getLstNomDet()!=null && propPAReq.getLstNomDet().size()>0){
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid othGrid=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid();
				
				for(NomineeDetails nomineeDet:propPAReq.getLstNomDet()){
					
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid nomineeGrid=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid();
				nomineeGrid.setName(IPAProductConstants.IPA_NOMINEE_GRID_NAME);
				nomineeGrid.setValue(IPAProductConstants.IPA_NOMINEE_GRID_VALUE);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1 nomineeGrid1=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1();
				nomineeGrid1.setType(IPAProductConstants.IPA_NOMINEE_TYPE);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.InsuredPerson insPerson=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.InsuredPerson();
				insPerson.setName(IPAProductConstants.IPA_NOMINEE_InsuredPerson);
				insPerson.setValue(nomineeDet.getInsuPerson());
				//insPerson.setValue(strFullName.toString().toUpperCase());
				insPerson.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nomineeGrid1.setInsuredPerson(insPerson);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Nominee nominee=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Nominee();
				nominee.setName(IPAProductConstants.IPA_NOMINEE_Nominee);
				nominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nominee.setValue(nomineeDet.getNomName());
				nomineeGrid1.setNominee(nominee);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Age age=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Age();
				age.setName(IPAProductConstants.IPA_NOMINEE_Age);
				age.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				age.setValue(nomineeDet.getNomAge());
				nomineeGrid1.setAge(age);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.DateofBirth dtBirth=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.DateofBirth();
				dtBirth.setName(IPAProductConstants.IPA_NOMINEE_DateofBirth);
				dtBirth.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				dtBirth.setValue(nomineeDet.getNomDOB());
				nomineeGrid1.setDateofBirth(dtBirth);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.GenderofNominee genderNominee=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.GenderofNominee();
				genderNominee.setName(IPAProductConstants.IPA_NOMINEE_GenderofNominee);
				genderNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				genderNominee.setValue(nomineeDet.getNomGender());
				nomineeGrid1.setGenderofNominee(genderNominee);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineeGuardianwithNominee relationshipNominee=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineeGuardianwithNominee();
				relationshipNominee.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineeGuardianwithNominee);
				relationshipNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				relationshipNominee.setValue(nomineeDet.getNomGaurdRelation()==null?"":nomineeDet.getNomGaurdRelation());
				nomineeGrid1.setRelationshipofNomineeGuardianwithNominee(relationshipNominee);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineewithInsuredPerson relationshipInsured=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineewithInsuredPerson();
				relationshipInsured.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineewithInsuredPerson);
				relationshipInsured.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				relationshipInsured.setValue(nomineeDet.getNomRelation());
				nomineeGrid1.setRelationshipofNomineewithInsuredPerson(relationshipInsured);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.WhethertheNomineeisaminor nomineeMinor=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.WhethertheNomineeisaminor();
				nomineeMinor.setName(IPAProductConstants.IPA_NOMINEE_WhethertheNomineeisaminor);
				nomineeMinor.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				//nomineeMinor.setValue(nomineeDet.getNomMinor());
				if(nomineeDet.getNomMinor().equalsIgnoreCase("true"))
					nomineeMinor.setValue("1");
				else
					nomineeMinor.setValue("0");
				nomineeGrid1.setWhethertheNomineeisaminor(nomineeMinor);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeGuardianName nomineeGuardName=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeGuardianName();
				nomineeGuardName.setName(IPAProductConstants.IPA_NOMINEE_NomineeGuardianName);
				nomineeGuardName.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nomineeGuardName.setValue(nomineeDet.getNomGaurdian());
				nomineeGrid1.setNomineeGuardianName(nomineeGuardName);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeContribution nomineeContri=new com.majesco.dcf.paproduct.jaxb.secureplan.SecureFuturePlanProposal.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeContribution();
				nomineeContri.setName(IPAProductConstants.IPA_NOMINEE_NomineeContribution);
				nomineeContri.setType(IPAProductConstants.IPA_NOMINEE_FieldType_Double);
				nomineeContri.setValue(nomineeDet.getNomContribtn());
				nomineeGrid1.setNomineeContribution(nomineeContri);
				
				nomineeGrid.setNomineeDetailsGrid1(nomineeGrid1);
				othGrid.getNomineeDetailsGrid().add(nomineeGrid);
				}
				
				p2Dto.setOtherDetailsGrid(othGrid);;
				
			}
			
			p2Dto.setPropRisks_Plan("Self"); // Defaulted to Self
			p2Dto.setPropRisks_PaymentType("Annual"); // Defaulted to Annual
			
			//Start: RahulT| Hardcoding to generate Accident shield proposal
			String defaultSysDate1 = new SimpleDateFormat(CommonConstants.UNIQUE_SEQUENCE).format(new java.util.Date());
			Date startDate=new Date();
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy", Locale.US);
			p2Dto.setPropSerIntermediaryDetails_SerIntermediaryCode(CommonConstants.BLANK_STRING);
			p2Dto.setPropSerIntermediaryDetails_SerIntermediaryName(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_PolicySchedule_Mandatary("Yes");
			p2Dto.setPropReferenceNoDate_ReferenceNo_Mandatary(defaultSysDate1); //TODO:It should be proposal number which needs to be passed through this tag.
			p2Dto.setPropPremiumCalculation_NetPremium("0");	// need to check this default value
			p2Dto.setPropPremiumCalculation_ServiceTax("0");
			p2Dto.setPropPremiumCalculation_TotalPremium("0");
			p2Dto.setPropPremiumCalculation_StampDuty("0");
			p2Dto.setPropMODetails_TertiaryMOName(CommonConstants.BLANK_STRING);
			p2Dto.setPropMODetails_TertiaryMOCode(CommonConstants.BLANK_STRING);
//			p2Dto.setPropIntermediaryDetails_IntermediaryType("Non-DM");	// need to check this default value
			p2Dto.setPropGeneralProposalInformation_Iscovernoteused("False");
			p2Dto.setPropGeneralProposalInformation_ManualCovernoteNo(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_Covernoteissuedate(sdf.format(startDate));
			p2Dto.setPropGeneralProposalInformation_Covernoteissuetime("21:04");
			p2Dto.setPropGeneralProposalInformation_QuoteNumber(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_ManualCovernoteNo(CommonConstants.BLANK_STRING);
			/*p2Dto.setPropGeneralProposalInformation_DisplayOfficeCode("0200");*//*Commented For Issue ID 2527*/
			p2Dto.setPropEndorsementDtls_ISUWCompleted("False");
			/*p2Dto.setPropGeneralProposalInformation_OfficeCode("90900");
			p2Dto.setPropGeneralProposalInformation_BranchOfficeCode("90200");*//*Commented For Issue ID 2527*/
			p2Dto.setPropRisks_NumberOfEMIs(CommonConstants.BLANK_STRING);
			p2Dto.setPropRisks_IsEMIApplicable("False");
			p2Dto.setPropRisks_SellType(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_ProposalDate_Mandatary(sdf.format(startDate));
			//End: RahulT| Hardcoding to generate Accident shield proposal
			
			jaxbXML=jaxbHandler.marshal(p2Dto);
			//System.out.println(jaxbXML);
			//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: "+strMethod+ ":: jaxbXML :: "+jaxbXML);
			propValue=getWSDLURL(IPAProductConstants.IPA_SECUREPLAN_SERVICE_WSDL);
			//propValue="http://172.17.203.45:9595/IPAService_SOAPOverHTTP?wsdl";
			URL url = new URL(propValue);
			IPAService_Service stub = new IPAService_Service(url);
			com.unotechsoft.stub.ipaservice.client.PolicyRequest reqQ = new com.unotechsoft.stub.ipaservice.client.PolicyRequest(); 
			/*Getting Authentication Token Starts Here*/
			//String propFileName = "resource.properties";
			String userID="";
			String password="";
			String responseFrom = "";
			/*Properties prop = new Properties();
			InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
			prop.load(inputStream);*/
			userID=propPAReq.getUserID();
			password=propPAReq.getPassword();
			responseFrom=prop.getProperty("ResponseFrom");
			
			//Start:Vishal<VAPT comments>| code added to set GC token into user object 
			if (propPAReq.getAuthToken()!=null ){
				reqQ.setAuthenticationToken(propPAReq.getAuthToken());
			}
			else{
				AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
				/*Getting Authentication Token Stops Here*/	
				reqQ.setAuthenticationToken(authRes.getResultRes());
			}
			//End:Vishal<VAPT comments>| code added to set GC token into user object
			
			reqQ.setSource(smc_source);
			reqQ.setProductCode("4255");
			if (propPAReq.getIsRenew()!=null && propPAReq.getIsRenew().equalsIgnoreCase("true"))
				reqQ.setModeOfOperation("RENEWPOLICY");
			else
				reqQ.setModeOfOperation("NEWPOLICY");
			reqQ.setCampaign(smc_campaign);
			reqQ.setMedium(smc_medium);
			reqQ.setCIAName("");
			reqQ.setHashKey("");
			reqQ.setHostAddress("");
			reqQ.setInputXML(jaxbXML);
			reqQ.setIsBankDataRequired(false);
			reqQ.setIsCutomerAddressRequired(false);
			reqQ.setIsFinanciarDataRequired(false);
			reqQ.setIsManufacturerMappingRequired(false);
			reqQ.setIsRTOMappingRequired(false);
			reqQ.setUserId(propPAReq.getUserID());
			reqQ.setUserRole("ADMIN");
			
			com.unotechsoft.stub.ipaservice.client.IPAService port=stub.getSOAPOverHTTP();
			
			/*ServiceUtility util=new ServiceUtility();
			Client client = util.addClientInterceptor(port);
			Client client=ClientProxy.getClient(port);
			PrintWriter writer = new PrintWriter(System.out);
			
			client.getOutInterceptors().add(new CdataWriterInterceptor());
			
			client.getInInterceptors().add(new LoggingInInterceptor(writer));
			
			client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
			//Service Time out code
			HTTPConduit conduit=(HTTPConduit)client.getConduit();
			HTTPClientPolicy clientPolicy=new HTTPClientPolicy();
			clientPolicy.setReceiveTimeout(60000);
			clientPolicy.setConnectionTimeout(30000);
			conduit.setClient(clientPolicy);
			//End:Service Time out code
*/			

			// Code added to save info abt SOAP in DB Start
			SOAPInfo soapInfo = new SOAPInfo();
			soapInfo.setTransactionID(transId);
			soapInfo.setLobService("saveProposal");
			soapInfo.setLobtype("42");
			soapInfo.setCreatedBy(propPAReq.getUserID());
			soapInfo.setProducerCode(propPAReq.getProducerCode());
			soapInfo.setSystemIP(propPAReq.getSystemIP());
			soapInfo.setTransactionEvent("GetPremium / Motor-Calculator");
			soapInfo.setJsonRequest(objMapper.writeValueAsString(propPAReq));
			soapInfo.setProductCode(propPAReq.getProdCode());
																
			cxfInInterceptor =new CXFInBoundInterceptor(soapInfo);
			cxfOutInterceptor= new CXFOutInterceptor(soapInfo);
								
			ServiceUtility utility = new ServiceUtility();
			utility.addClientInterceptorDB(port,cxfInInterceptor,cxfOutInterceptor);
																	
			com.unotechsoft.stub.ipaservice.client.PolicyResponce response = port.saveProposal(reqQ);
			
			//if(logger.isDebugEnabled())logger.debug("Adding Out Logs to DB");
			dbserv.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
			//if(logger.isDebugEnabled())logger.debug("Adding In Logs to DB");
			dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());				
			
			//Code end for Saving SOAP Data to DB.	
			
			com.unotechsoft.stub.ipaservice.client.secureplan.result.UWProductServiceResult uwResult=new com.unotechsoft.stub.ipaservice.client.secureplan.result.UWProductServiceResult();
			String responseXML = null;
			if(response!=null && response.getResponseXML()!=null){
			responseXML=response.getResponseXML();
			responseXML=responseXML.replaceAll("ns2:", "");
			}
			
			if(responseXML!=null){
			uwResult=(com.unotechsoft.stub.ipaservice.client.secureplan.result.UWProductServiceResult)jaxbHandler.unmarshal(responseXML, uwResult);
			}
			if(uwResult!=null && uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().size()>0 && uwResult.getUWOperationResult().get(0)!=null){
				if(uwResult.getUWOperationResult().get(0).getErrorText()!=null && !uwResult.getUWOperationResult().get(0).getErrorText().equals(""))
				{
					propPARes.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR");
					errorRes.setErrorMMessag(uwResult.getUWOperationResult().get(0).getErrorText());
					errorList.add(errorRes);
					propPARes.setResErr(errorList);
					if(cxfInInterceptor!=null){
						cxfInInterceptor.getInBound().setStrjsonobj(objMapper.writeValueAsString(propPARes));
						dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());	
					}
					return propPARes;
				}
				else{
					if(uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().get(0)!=null){
						
						if(uwResult.getUWOperationResult().get(0).getConfWFHelper()!=null && uwResult.getUWOperationResult().get(0).getConfWFHelper()!=null){
							propPARes.setProposalSystemId(uwResult.getUWOperationResult().get(0).getConfWFHelper().get(0).getWFSystemID());
							
							//RahulT: code added to remove W from prefix.
							if(propPARes.getProposalSystemId()!=null){
								propPARes.setProposalSystemId(propPARes.getProposalSystemId().substring(1, propPARes.getProposalSystemId().length()));
							}
							//RahulT: code added to remove W from prefix.
							//Start:07-Sep-2016:Added UW rules warning text from GC
							if(uwResult.getUWOperationResult().get(0).getWarningText()!=null)
								propPARes.setRulesWarning(uwResult.getUWOperationResult().get(0).getWarningText());
							//End:07-Sep-2016:Added UW rules warning text from GC
						}
						
						if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null){
							//Start:TAGIC:21/12/2016:Changes done for account service branch location.
							/*propPARes.setBusinessLocation(respObj.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
							propPARes.setDepositOfficeCode(respObj.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());*/
							propPARes.setBusinessLocation(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_BranchOfficeCode());	
							propPARes.setDepositOfficeCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_BranchOfficeCode());
							//Start:TAGIC:21/12/2016:Changes done for account service branch location.
							propPARes.setBussLocName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_OfficeName());
							proposalDtl.setCustomerId(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropCustomerDtls_CustomerID_Mandatary());	//10112016
							//proposalDtl.setCustomerName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropCustomerDtls_CustomerName());	//10112016
							proposalDtl.setProductCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_ProductCode());	//10112016
							proposalDtl.setProposalSystemId(propPARes.getProposalSystemId());	//10112016
							proposalDtl.setBusinessLocation(propPARes.getBusinessLocation());	//10112016
							proposalDtl.setDepositOfficeCode(propPARes.getDepositOfficeCode());	//10112016
							proposalDtl.setBussLocName(propPARes.getBussLocName());	//10112016
							proposalDtl.setProductLine("Secure Future Plan");
							proposalDtl.setProductCode("4255");
						}
						
					
					propPARes.setProposalNumber(uwResult.getUWOperationResult().get(0).getProposalNo());
					propPARes.setProposalDate(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_ProposalDate_Mandatary());
					
					if(uwResult.getUWOperationResult().get(0).getNetPremium()!=null)
						prmdet.setNetPremium(uwResult.getUWOperationResult().get(0).getNetPremium());
					if(uwResult.getUWOperationResult().get(0).getTotalPremium()!=null)
						prmdet.setTotalPremium(uwResult.getUWOperationResult().get(0).getTotalPremium());
					if(uwResult.getUWOperationResult().get(0).getTotalSI()!=null)
						prmdet.setSumInsured(uwResult.getUWOperationResult().get(0).getTotalSI());
					if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null)
						prmdet.setServiceTax(uwResult.getUWOperationResult().get(0).getServiceTax());
					
					}//End:Added to set proposal response field to be used in AccountService
					
					/*Added To Send Application Number To UI*/
					if(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodes_ApplicationNo()!=null)
					{
						propPARes.setApplcationNo(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodes_ApplicationNo());
					}
					else
					{
						propPARes.setApplcationNo("");
					}
					/*Added To Send Application Number To UI*/
					
//################## Calling getPendingProposalList service to stop proceed to pay call IPA AS: 09/03/2017 : Start #################################
					
					String declinedStatus=null,transactionType=null;
					PendingPropListRequest pendingPropListRequest = new PendingPropListRequest();
					PendingPropListResponse pendingPropListResponse = new PendingPropListResponse();
					
					pendingPropListRequest.setEntityType(propPAReq.getUserType()==null ? "INTERMEDIARY":propPAReq.getUserType());
					pendingPropListRequest.setEntityCode(propPAReq.getProducerCode()==null ? "" : propPAReq.getProducerCode());
					
					pendingPropListRequest.setProposalNo(propPARes.getProposalNumber());
					//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalSFP() method :: Calling Service For getPendingProposalList: for  "+ propPARes.getProposalNumber());
					pendingPropListResponse = commonService.getPendingProposalList(pendingPropListRequest);
										
					if(pendingPropListResponse!=null){
						declinedStatus = pendingPropListResponse.getDeclinedStatus();
						transactionType = pendingPropListResponse.getTransactionType();
						if(declinedStatus != null && transactionType !=null){
							//logger.info("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalSFP() method :: Calling Service For declinedStatus: for  "+ declinedStatus);
							if(declinedStatus.equalsIgnoreCase("NPDP") || declinedStatus.equalsIgnoreCase("NMTD") || declinedStatus.equalsIgnoreCase("NR") || transactionType.equalsIgnoreCase("DECLINED")){
								//logger.info("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalSFP() method :: IF");
								 if (pendingPropListResponse!=null && pendingPropListResponse.getDeclinedStatus()!=null) 
			                     {
			                    	 
			                    	 propPARes.setProposalStatus(pendingPropListResponse.getDeclinedStatus());
			                     }
			                     if (pendingPropListResponse!=null && pendingPropListResponse.getDeclinedStatusDesc()!=null) 
			                     {
			                    	 
			                    	 propPARes.setProposalStatusDesc(pendingPropListResponse.getDeclinedStatusDesc());
			                     }
			                     
								
							}else{
								
								
								
								//To set proposalStatus in propRes Start
						        if (propPARes.getProposalNumber() != null && !propPARes.getProposalNumber().equalsIgnoreCase("")) 
						        {
						        	try{
								       ProposalStatusReq proposalStatusReq = new ProposalStatusReq();
								       proposalStatusReq.setProposalNo(propPARes.getProposalNumber());
								       strProposalNo = propPARes.getProposalNumber();	//10112016
					                   proposalDtl.setProposalNo(strProposalNo);	//10112016
					                 //Start:TAGIC:20/12/2016:Added for new proposal status search service.
					                   proposalStatusReq.setAuthToken(reqQ.getAuthenticationToken());
					                   proposalStatusReq.setProducerCode(propPAReq.getProducerCode());
					                   proposalStatusReq.setProductCode(propPAReq.getProdCode());
					                   proposalStatusReq.setUserID(userID);
					                 //End:TAGIC:20/12/2016:Added for new proposal status search service.
								       ProposalStatus proposalStatus = new ProposalStatus();
								       proposalStatus = commonService.getProposalStatus(proposalStatusReq);
								       
								      // if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalSFP() method :: ProposalStatus: " + proposalStatus.getProposalStatus() + " :: ProposalStatusDesc : " + proposalStatus.getProposalStatusDesc());
								       
								        if (proposalStatus.getProposalStatus()!=null) 
								        {
								        	propPARes.setProposalStatus(proposalStatus.getProposalStatus());
								        }
								        if (proposalStatus.getProposalStatusDesc()!=null) 
								        {
								        	propPARes.setProposalStatusDesc(proposalStatus.getProposalStatusDesc());
								        }
						        	}
						        	catch(Exception e){
						        		e.printStackTrace();
						        	}
						        }
						        //To set proposalStatus in propRes End
							}
						}else{
							//To set proposalStatus in propRes Start														
		                    if (propPARes.getProposalNumber() != null && !propPARes.getProposalNumber().equalsIgnoreCase("")) 
		                    {
		                    	try{
		                    	
					                   ProposalStatusReq proposalStatusReq = new ProposalStatusReq();
					                   proposalStatusReq.setProposalNo(propPARes.getProposalNumber());
					                   strProposalNo = propPARes.getProposalNumber();	//10112016
					                   proposalDtl.setProposalNo(strProposalNo);	//10112016
					                 //Start:TAGIC:20/12/2016:Added for new proposal status search service.
					                   proposalStatusReq.setAuthToken(reqQ.getAuthenticationToken());
					                   proposalStatusReq.setProducerCode(propPAReq.getProducerCode());
					                   proposalStatusReq.setProductCode(propPAReq.getProdCode());
					                   proposalStatusReq.setUserID(userID);
					                 //End:TAGIC:20/12/2016:Added for new proposal status search service.
					                   ProposalStatus proposalStatus = new ProposalStatus();
					                   proposalStatus = commonService.getProposalStatus(proposalStatusReq);
					                   
					                    //logger.info("TransactionID:"+transId+" :: Inside IPAServiceImpl :: getIPAProposalAG() method :: ProposalStatus: " + proposalStatus.getProposalStatus() + " :: ProposalStatusDesc : " + proposalStatus.getProposalStatusDesc());
					                   
					                    if (proposalStatus.getProposalStatus()!=null) 
					                    {
					                    	propPARes.setProposalStatus(proposalStatus.getProposalStatus());
					                    }
					                    if (proposalStatus.getProposalStatusDesc()!=null) 
					                    {
					                    	propPARes.setProposalStatusDesc(proposalStatus.getProposalStatusDesc());
					                    }
		                    	}
		                    	catch(Exception e){
		                    		e.printStackTrace();
		                    	}
		                    }
		                    //To set proposalStatus in propRes End
						}
						
					}
					
	//################## Calling getPendingProposalList service to stop proceed to pay call IPA AS: 09/03/2017 : End   #################################								
					
					propPARes.setPremDet(prmdet);
				}
			}
			//Start: 27122016| Added to retrieve Email & mobile no of proposal owner
	           if(propPAReq != null && propPAReq.getProposerDet()!= null && propPAReq.getProposerDet().getContDetList()!=null){
	        	   emailId = propPAReq.getProposerDet().getContDetList().getEmailID();
	        	   mobileNo = propPAReq.getProposerDet().getContDetList().getMobileNumber();
	        	   proposalDtl.setEmailId(emailId);
	        	   proposalDtl.setMobileNo(mobileNo);
	        	   proposalDtl.setPolicyEffDt(propPAReq.getPolInceptionDt());
	        	   proposalDtl.setPolicyEndDt(propPAReq.getPolExpiryDt());
	        	   proposalDtl.setCustomerName(propPAReq.getProposerDet().getTitle()+" "+propPAReq.getProposerDet().getFirstName()+" "+propPAReq.getProposerDet().getLastName());
	        	   proposalDtl.setPlanName(propPAReq.getLstcvrgDet().getPlan());
	        	   proposalDtl.setVehRegNo(null);
	           }
	           //End: 27122016| Added to retrieve Email & mobile no of proposal owner
	           
			if (propPARes.getProposalNumber() != null && !propPARes.getProposalNumber().equalsIgnoreCase("")) {
				//Persisting data into transaction table for Save customer service.
				int updateCount = 0;
				try{
					updateCount = dbserv.updateUserTransForProposal(strProposalNo,propPAReq.getQuoteNo());	//RahulT| user transaction changes	
				}
				catch(Exception e){
					e.printStackTrace();
				}
				if (updateCount == 0){
					UserTransaction transaction = new UserTransaction();
					transaction.setStrPropNumber(strProposalNo);
					transaction.setDtCreated(new Date());
					transaction.setDtTrans(new Date());
					transaction.setStrCreatedBy(userID);
					transaction.setStrlob("IPA");
					transaction.setStrProducercd(propPAReq.getProducerCode());	// 27122016
					transaction.setStrTranstype("Save Proposal");
					transaction.setStrUserid(userID);
					transaction.setDtotSA(new Double(prmdet.getSumInsured()));
					transaction.setStrIPAddress(propPAReq.getSystemIP());
					transaction.setTotalPremium(prmdet.getTotalPremium());
					transaction.setStrCustomerId(propPAReq.getCustCode());
					transaction.setStrWorkflowId(propPARes.getProposalSystemId());
					dbserv.saveOrUpdate(transaction);
				}
				//Persisting data into online staging table for Save customer service.
				ReceiptCumPolicyRequest accountServReq = new ReceiptCumPolicyRequest();
				accountServReq.setProposalDetails(proposalDtl);
				
				/*OnlineAccountService entity = new OnlineAccountService();
				entity.setStrOrderID(proposalDtl.getProposalNo());
				entity.setStrRequestMsg(objMapper.writeValueAsString(accountServReq));
				logger.info("In IPAServiceImpl :: getIPAProposalSFP method ::: Saving Entity for Billdesk --> online Entity Request Object::"+entity.getStrRequestMsg());
				dbserv.saveOrUpdate(entity);*/
				
				// send mail
				String payAmount = null;
				if (propPAReq.getIsRenew()== null || !propPAReq.getIsRenew().equalsIgnoreCase("true")){
					if (emailId!=null && !emailId.equals("")){
						try{
							if (prmdet.getTotalPremium()!=null && !prmdet.getTotalPremium().equals("")){
								double d = Double.valueOf(prmdet.getTotalPremium()).doubleValue();
								payAmount = new String(""+Math.round(d));
								
							}
							CommunicationRequest commRequest = new CommunicationRequest();
							EmailAttachment attachment = new EmailAttachment(); 
							commRequest.setAlertType(CommonConstants.SEND_EMAIL);
							commRequest.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA);
							commRequest.setReceipient(emailId);
							commRequest.setParam1(proposalDtl.getCustomerName());
							commRequest.setParam2(proposalDtl.getProposalNo());
							commRequest.setParam3("Secure Future Plan");
							commRequest.setParam4(propPAReq.getLstcvrgDet().getPlan()==null?"":propPAReq.getLstcvrgDet().getPlan());
							commRequest.setParam5(payAmount==null?"":payAmount);
							commRequest.setParam6(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
							commRequest.setParam7(propPAReq.getProducerCode()==null?"":propPAReq.getProducerCode());
							commRequest.setParam8(propPAReq.getPolInceptionDt()==null?"":propPAReq.getPolInceptionDt());
							commRequest.setParam9(propPAReq.getPolExpiryDt()==null?"":propPAReq.getPolExpiryDt());	// Policy expiration date
							
							commRequest.setParam10(proposalDtl.getCustomerName()==null?"":proposalDtl.getCustomerName());
							commRequest.setParam11("Secure Future Plan");	
							commRequest.setParam12(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
							commRequest.setParam13(propPAReq.getProducerMobile()==null ?"1800 - 266 - 7780":propPAReq.getProducerMobile());
							
							attachment.setCustomerID(propPAReq.getCustCode()==null?"":propPAReq.getCustCode());
							attachment.setProposalNumber(strProposalNo);
							attachment.setProductCode(proposalDtl.getProductCode()==null?"":proposalDtl.getProductCode());
							attachment.setProposalDate(propPARes.getProposalDate()==null?"":propPARes.getProposalDate());
							commRequest.setEmailAttachment(attachment);
							commRequest.setUserID(propPAReq.getUserID());
							commRequest.setPassword(propPAReq.getPassword());
							//communicationService.sendCommunication(commRequest); // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalSFP method ::: Mail sent successfully to "+emailId);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					// sending mail to producer
					try{
						if(propPAReq.getProducerEmail()!=null && !propPAReq.getProducerEmail().equals("")){
							if (prmdet.getTotalPremium()!=null && !prmdet.getTotalPremium().equals("")){
								double d = Double.valueOf(prmdet.getTotalPremium()).doubleValue();
								payAmount = new String(""+Math.round(d));
								
							}
							CommunicationRequest commRequestProducer = new CommunicationRequest();
							EmailAttachment attachmentProducer = new EmailAttachment(); 
							commRequestProducer.setAlertType(CommonConstants.SEND_EMAIL);
							commRequestProducer.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA_PRODUCER);
							commRequestProducer.setReceipient(propPAReq.getProducerEmail());
							commRequestProducer.setParam1(proposalDtl.getCustomerName());
							commRequestProducer.setParam2(proposalDtl.getProposalNo());
							commRequestProducer.setParam3("Secure Future Plan");
							commRequestProducer.setParam4(propPAReq.getLstcvrgDet().getPlan()==null?"":propPAReq.getLstcvrgDet().getPlan());
							commRequestProducer.setParam5(payAmount==null?"":payAmount);
							commRequestProducer.setParam6(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
							commRequestProducer.setParam7(propPAReq.getProducerCode()==null?"":propPAReq.getProducerCode());
							commRequestProducer.setParam8(propPAReq.getPolInceptionDt()==null?"":propPAReq.getPolInceptionDt());
							commRequestProducer.setParam9(propPAReq.getPolExpiryDt()==null?"":propPAReq.getPolExpiryDt());
							
							commRequestProducer.setParam10(propPAReq.getProducerName()==null?"":propPAReq.getProducerName());
							commRequestProducer.setParam11(proposalDtl.getCustomerName()==null?"":proposalDtl.getCustomerName());
							commRequestProducer.setParam12("Secure Future Plan");
							
							attachmentProducer.setCustomerID(propPAReq.getCustCode()==null?"":propPAReq.getCustCode());
							attachmentProducer.setProposalNumber(strProposalNo);
							attachmentProducer.setProductCode(proposalDtl.getProductCode()==null?"":proposalDtl.getProductCode());
							attachmentProducer.setProposalDate(propPARes.getProposalDate()==null?"":propPARes.getProposalDate());
							commRequestProducer.setEmailAttachment(attachmentProducer);
							commRequestProducer.setUserID(propPAReq.getUserID());
							commRequestProducer.setPassword(propPAReq.getPassword());
							//communicationService.sendCommunication(commRequestProducer);  // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAS method ::: Mail sent successfully to Producer on "+propPAReq.getProducerEmail());

						}
					}
					catch(Exception e){
						e.printStackTrace();
					}
					//sending SMS to producer
					if (propPAReq.getProducerMobile()!=null && !propPAReq.getProducerMobile().equals("")){
						try{
							CommunicationRequest commRequestSMSProducer = new CommunicationRequest();
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAS method ::: sending SMS to  "+ mobileNo);
							commRequestSMSProducer.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMSProducer.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA_PRODUCER);
							commRequestSMSProducer.setReceipient(propPAReq.getProducerMobile());
							commRequestSMSProducer.setParam1(propPAReq.getProducerName());
							commRequestSMSProducer.setParam2(proposalDtl.getCustomerName());
							commRequestSMSProducer.setParam3("Accident Shield");	//plan name
							commRequestSMSProducer.setParam4(emailId== null ? "" :emailId);
							commRequestSMSProducer.setParam5(propPARes.getProposalNumber());	
							commRequestSMSProducer.setParam6(payAmount==null?"-":payAmount);
							commRequestSMSProducer.setUserID(propPAReq.getUserID());
							commRequestSMSProducer.setPassword(propPAReq.getPassword());
							//communicationService.sendCommunication(commRequestSMSProducer);  // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAS method ::: SMS sent successfully to producer on "+propPAReq.getProducerMobile());

						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					if (mobileNo!=null && !mobileNo.equals("")){
						try{
							//Start: changes done to set values for sms in fresh instance
							CommunicationRequest commRequestSMS = new CommunicationRequest();
							//End: changes done to set values for sms in fresh instance
							//if(logger.isDebugEnabled())logger.debug("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
							commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMS.setEventType(CommonConstants.EVENT_CREATE_PROPOSAL_IPA);
							commRequestSMS.setReceipient(mobileNo);
							commRequestSMS.setParam1(proposalDtl.getCustomerName());
							commRequestSMS.setParam2("Secure Future Plan");
							commRequestSMS.setParam3(emailId== null ? "" :emailId);	//plan name
							commRequestSMS.setParam4(propPARes.getProposalNumber());
							commRequestSMS.setParam5(payAmount==null?"":payAmount);	
							commRequestSMS.setParam6(propPAReq.getProducerName());
							commRequestSMS.setParam7(propPAReq.getProducerMobile()==null ?"1800 - 266 - 7780":propPAReq.getProducerMobile());
							commRequestSMS.setUserID(propPAReq.getUserID());
							commRequestSMS.setPassword(propPAReq.getPassword());
							//communicationService.sendCommunication(commRequestSMS);  // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal

						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
				}
				//Start: RahulT| code changes for sending mail/sms fo renewal cases
				else if (propPAReq.getIsRenew()!= null && propPAReq.getIsRenew().equalsIgnoreCase("true")){
					//helper.sendCommunicationRenewalIPAProp(proposalDtl,prmdet,propPAReq,propPARes,communicationService); // 06-Apr-1017 : Commented to stop sending involuntarily mail as suggested by TAGIC Team. : Vishal
				}
			}
			
		}
		
		catch(Exception e)
		{
			propPARes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR");
			errorRes.setErrorMMessag(e.getMessage()+".Transaction ID::"+transId);
			errorList.add(errorRes);
			propPARes.setResErr(errorList);
			e.printStackTrace();
			logger.error("Inside IPAServiceImpl :: "+strMethod+" method :: Exception Occurred : "+e.toString()+".Transaction ID::"+transId);
		}
		
		logger.info("Start::"+transId+" :: IPAServiceImpl :: "+strMethod+" :: Exit :: response :-"+objMapper.writeValueAsString(propPARes));
		if(cxfInInterceptor!=null){
			cxfInInterceptor.getInBound().setStrjsonobj(objMapper.writeValueAsString(propPARes));
			cxfInInterceptor.getInBound().setStrrefno(propPARes.getProposalNumber());
			dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());	
		}
		return propPARes;

	}
	
	
	private IPAProposalRequest mapToExternalCode(IPAProposalRequest propPAReq){
		try{
		if(propPAReq!=null){
			if(propPAReq.getBusinessType()!=null && !propPAReq.getBusinessType().equalsIgnoreCase(""))
			propPAReq.setBusinessType(dbserv.getExternalMapCode(null, propPAReq.getBusinessType(), CommonConstants.BUSINESSTYPE_IPA_SYSTEM_PARAMCD));
			
			if(propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getOccuptnClassOfSelf()!=null && !propPAReq.getLstcvrgDet().getOccuptnClassOfSelf().equalsIgnoreCase("")){
				propPAReq.getLstcvrgDet().setOccuptnClassOfSelf(dbserv.getExternalMapCode(null, propPAReq.getLstcvrgDet().getOccuptnClassOfSelf(), IPAProductConstants.OCCUPATION_CLASS_PARAM));
			}
				
					
			
			if(propPAReq.getLstInsurDet()!=null && propPAReq.getLstInsurDet().size()>0){
				//InsuredDetails insured=propPAReq.getLstInsurDet().get(0);
				for (InsuredDetails insured: propPAReq.getLstInsurDet()){
					if(insured.getGender()!=null && !insured.getGender().equalsIgnoreCase(""))
					insured.setGender(dbserv.getExternalMapCode(null, insured.getGender(), CommonConstants.GENDERCD_SYSTEM_PARAMCD));
					
					if(insured.getOccupation()!=null && !insured.getOccupation().equalsIgnoreCase(""))
					insured.setOccupation(dbserv.getExternalMapCode(null, insured.getOccupation(), CommonConstants.OCCUPATION_SYSTEM_PARAMCD));
					
					if(insured.getMaritalStatus()!=null && !insured.getMaritalStatus().equalsIgnoreCase(""))
					insured.setMaritalStatus(dbserv.getExternalMapCode(null, insured.getMaritalStatus(), CommonConstants.MARITALSTATUS_SYSTEM_PARAMCD));
					
					if(insured.getInsuTitle()!=null && !insured.getInsuTitle().equalsIgnoreCase(""))
					insured.setInsuTitle(dbserv.getExternalMapCode(null, insured.getInsuTitle(), CommonConstants.TITLE_SYSTEM_PARAMCD));
					
					if(insured.getRelationship()!=null && !insured.getRelationship().equalsIgnoreCase(""))
					insured.setRelationship(dbserv.getExternalMapCode(null, insured.getRelationship(), IPAProductConstants.RELATIONSHIP_CODE_AG));
				}
				
			}
			
			if(propPAReq.getProposerDet()!=null){
				
				if(propPAReq.getProposerDet().getGender()!=null && !propPAReq.getProposerDet().getGender().equalsIgnoreCase(""))
					propPAReq.getProposerDet().setGender(dbserv.getExternalMapCode(null, propPAReq.getProposerDet().getGender(), CommonConstants.GENDERCD_SYSTEM_PARAMCD));
				
				if(propPAReq.getProposerDet().getOccupation()!=null && !propPAReq.getProposerDet().getOccupation().equalsIgnoreCase(""))
					propPAReq.getProposerDet().setOccupation(dbserv.getExternalMapCode(null, propPAReq.getProposerDet().getOccupation(), CommonConstants.OCCUPATION_SYSTEM_PARAMCD));
					
					if(propPAReq.getProposerDet().getMaritalstatus()!=null && !propPAReq.getProposerDet().getMaritalstatus().equalsIgnoreCase(""))
						propPAReq.getProposerDet().setMaritalstatus(dbserv.getExternalMapCode(null, propPAReq.getProposerDet().getMaritalstatus(), CommonConstants.MARITALSTATUS_SYSTEM_PARAMCD));
					
					if(propPAReq.getProposerDet()!=null && !propPAReq.getProposerDet().getTitle().equalsIgnoreCase(""))
						propPAReq.getProposerDet().setTitle(dbserv.getExternalMapCode(null, propPAReq.getProposerDet().getTitle(), CommonConstants.TITLE_SYSTEM_PARAMCD));
			}
			
			if(propPAReq.getLstNomDet()!=null && propPAReq.getLstNomDet().size() > 0){
				
				List<NomineeDetails> nomineeList=propPAReq.getLstNomDet();
				if(nomineeList!=null){
					for(int i=0;i<propPAReq.getLstNomDet().size();i++){
						if(propPAReq.getLstNomDet().get(i)!=null && propPAReq.getLstNomDet().get(i).getNomGender()!=null){
						propPAReq.getLstNomDet().get(i).setNomGender(dbserv.getExternalMapCode(null, propPAReq.getLstNomDet().get(i).getNomGender(), CommonConstants.GENDERCD_SYSTEM_PARAMCD));
						}
						
						if(propPAReq.getLstNomDet().get(i)!=null && propPAReq.getLstNomDet().get(i).getNomAge()!=null){
							//String nomineeAge=propPAReq.getLstNomDet().get(i).getNomAge();
							
							Integer intAge=new Integer(propPAReq.getLstNomDet().get(i).getNomAge());
							
							if(intAge < IPAProductConstants.NOMINEE_MINOR_AGE){
								propPAReq.getLstNomDet().get(i).setNomMinor("True");
							}else{
								propPAReq.getLstNomDet().get(i).setNomMinor("False");
							}
						}
						
						if(propPAReq.getLstNomDet().get(i)!=null && propPAReq.getLstNomDet().get(i).getNomRelation()!=null){
							propPAReq.getLstNomDet().get(i).setNomRelation(dbserv.getExternalMapCode(null, propPAReq.getLstNomDet().get(i).getNomRelation(), IPAProductConstants.NOMINEE_RELATIONSHIP_PARAM));
						}
						
						if(propPAReq.getLstNomDet().get(i)!=null && propPAReq.getLstNomDet().get(i).getNomGaurdRelation()!=null){
							propPAReq.getLstNomDet().get(i).setNomGaurdRelation(dbserv.getExternalMapCode(null, propPAReq.getLstNomDet().get(i).getNomGaurdRelation(), IPAProductConstants.NOMINEE_RELATIONSHIP_PARAM));
						}
					}
				}
				
			}
		}
		}catch(Exception ex){
			ex.printStackTrace();
			logger.error("mapToExternalCode ::", ex);
		}
		return propPAReq;
	}

	@Override
	public IPAProposalResponse generateIPAPremiumAS(IPAProposalRequest propPAReq)
			throws Exception {
		
		ObjectMapper objMap = new ObjectMapper();
		logger.info("Inside IPAServiceImpl :: generateIPAPremiumAS :: Entered"+objMap.writeValueAsString(propPAReq));
		
		IPAProposalResponse propPARes = new IPAProposalResponse();
		
		long transId=propPAReq.getLocalTransId();
		List<ResponseError> lstResErr  = new ArrayList<ResponseError>();
		ResponseError reserr = new ResponseError();
		PremiumDetails prmdet = new PremiumDetails();
		CXFInBoundInterceptor cxfInInterceptor =null;
		CXFOutInterceptor cxfOutInterceptor=null;
//		AccidentGuardProductProposalPolicy obj = new AccidentGuardProductProposalPolicy();
//		obj.getPropRisksCol().getRisks().get(0).
		
		JAXBXMLHandler jaxbHandler=new JAXBXMLHandler();
		String jaxbXML = "";
		List<String> list = new ArrayList<String>();
		
		Mapper mapper=null;
		
		//if(logger.isDebugEnabled())logger.debug("Start::"+transId+" :: IPAServiceImpl :: generateIPAPremiumAS :: Entered");
		
		try{
			list.add("IPAMapping.xml");
			
			mapper = (Mapper) new DozerBeanMapper(list);

			AccidentShieldPolicy p2Dto = new AccidentShieldPolicy();
//			mapper.map(propPAReq, p2Dto,"IPAProposalAG");
			//p2Dto = travelConvertor.getJaxbReqObjForTravQuot(propPAReq);
			propPAReq=mapToExternalCode(propPAReq);
			
			// Start: RahulT| Code added to send Plan description based on GC's Requirement
			if(propPAReq.getLstcvrgDet()!= null && propPAReq.getLstcvrgDet().getPlan()!= null){
				if (propPAReq.getLstcvrgDet().getPlan().equalsIgnoreCase("self")){
					propPAReq.getLstcvrgDet().setPlan(null);
				}
				else if(!propPAReq.getLstcvrgDet().getPlan().equals("") && !propPAReq.getLstcvrgDet().getPlan().equalsIgnoreCase("self")){
					propPAReq.getLstcvrgDet().setPlan("Family");
				}
			}
			//End: RahulT| Code added to send Plan description based on GC's Requirement
			
			mapper.map(propPAReq, p2Dto,"IPAPremiumAS");
			
			//Start:28/02/2017:Added for full name required by GC
			StringBuffer strFullName=new StringBuffer();
			strFullName.append(propPAReq.getFirstName());
			if(propPAReq.getMiddleName()!=null && !propPAReq.getMiddleName().equals(CommonConstants.BLANK_STRING))
				strFullName.append(" "+propPAReq.getMiddleName());
			if(propPAReq.getLastName()!=null && !propPAReq.getLastName().equals(CommonConstants.BLANK_STRING))
				strFullName.append(" "+propPAReq.getLastName());
			//End:28/02/2017:Added for full name required by GC
			p2Dto.setPropCustomerDtls_CustomerName(strFullName.toString().toUpperCase());
			com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.PropRisks_Col riskCol=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.PropRisks_Col();
			
			for(InsuredDetails insuredDet:propPAReq.getLstInsurDet()){
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.PropRisks_Col.Risks riskObj=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.PropRisks_Col.Risks();
				mapper.map(insuredDet, riskObj, "IPAPremiumInsuredAS");
				riskObj.setPropRisks_OtherRiskPrem1("0");
				riskObj.setPropRisks_OtherRiskPrem2("0");
				//Start: RahulT| Hardcoding to generate Accident shield premium
				riskObj.setPropRisks_IdentityProofNumber(CommonConstants.BLANK_STRING);
				riskObj.setPropRisks_IdentityProofType(CommonConstants.BLANK_STRING);
				riskObj.setPropRisks_EndorsementAmount("0");
				riskObj.setPropRisks_Premium("0");
				riskObj.setPropRisks_Rate("0");
				//17092016| Changes done 
				//riskObj.setPropRisks_SumInsured("500000");
				riskObj.setPropRisks_SumInsured(insuredDet.getSumInsured());
				if(riskObj.getPropRisks_AnyPEDillnesstreated()==null || riskObj.getPropRisks_AnyPEDillnesstreated().equalsIgnoreCase(""))
					riskObj.setPropRisks_AnyPEDillnesstreated("false");
				//riskObj.setPropRisks_Gender("Male");
				//riskObj.setPropRisks_Relationship(CommonConstants.BLANK_STRING);
				//riskObj.setPropRisks_Relationshipcode("01");
				riskObj.setPropRisks_DifferentialSI("0");
				//riskObj.setPropRisks_MaritalStatus("Married");
				//17092016| Changes done 
				riskObj.setPropRisks_IsDataDeleted("false");
				riskObj.setPropRisks_IsOldDataDeleted("false");
				riskObj.setIsOptionalCover("true");
				//End: RahulT| Hardcoding to generate Accident shield premium
				//riskObj.setPropRisks_InsuredNameInsuredName(strFullName.toString().toUpperCase());
				riskObj.setPropRisks_InsuredNameInsuredName(insuredDet.getInsuName());
				riskCol.getRisks().add(riskObj);
				//p2Dto.getPropRisks_Col().getRisks().add(riskObj);
			}
			p2Dto.setPropRisks_Col(riskCol);
			
			//Setting nominee details
			if(propPAReq.getLstNomDet()!=null && propPAReq.getLstNomDet().size()>0){
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid othGrid=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid();
				
				for(NomineeDetails nomineeDet:propPAReq.getLstNomDet()){
					
					com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid nomineeGrid=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid();
				nomineeGrid.setName(IPAProductConstants.IPA_NOMINEE_GRID_NAME);
				nomineeGrid.setValue(IPAProductConstants.IPA_NOMINEE_GRID_VALUE);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1 nomineeGrid1=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1();
				nomineeGrid1.setType(IPAProductConstants.IPA_NOMINEE_TYPE);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.InsuredPerson insPerson=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.InsuredPerson();
				insPerson.setName(IPAProductConstants.IPA_NOMINEE_InsuredPerson);
				insPerson.setValue(nomineeDet.getInsuPerson());
				//insPerson.setValue(strFullName.toString().toUpperCase());
				insPerson.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nomineeGrid1.setInsuredPerson(insPerson);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Nominee nominee=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Nominee();
				nominee.setName(IPAProductConstants.IPA_NOMINEE_Nominee);
				nominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nominee.setValue(nomineeDet.getNomName());
				nomineeGrid1.setNominee(nominee);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Age age=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Age();
				age.setName(IPAProductConstants.IPA_NOMINEE_Age);
				age.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				age.setValue(nomineeDet.getNomAge());
				nomineeGrid1.setAge(age);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.DateofBirth dtBirth=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.DateofBirth();
				dtBirth.setName(IPAProductConstants.IPA_NOMINEE_DateofBirth);
				dtBirth.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				dtBirth.setValue(nomineeDet.getNomDOB());
				nomineeGrid1.setDateofBirth(dtBirth);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.GenderofNominee genderNominee=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.GenderofNominee();
				genderNominee.setName(IPAProductConstants.IPA_NOMINEE_GenderofNominee);
				genderNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				genderNominee.setValue(nomineeDet.getNomGender());
				nomineeGrid1.setGenderofNominee(genderNominee);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineeGuardianwithNominee relationshipNominee=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineeGuardianwithNominee();
				relationshipNominee.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineeGuardianwithNominee);
				relationshipNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				relationshipNominee.setValue(nomineeDet.getNomGaurdRelation()==null?"":nomineeDet.getNomGaurdRelation());
				nomineeGrid1.setRelationshipofNomineeGuardianwithNominee(relationshipNominee);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineewithInsuredPerson relationshipInsured=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineewithInsuredPerson();
				relationshipInsured.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineewithInsuredPerson);
				relationshipInsured.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				relationshipInsured.setValue(nomineeDet.getNomRelation());
				nomineeGrid1.setRelationshipofNomineewithInsuredPerson(relationshipInsured);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.WhethertheNomineeisaminor nomineeMinor=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.WhethertheNomineeisaminor();
				nomineeMinor.setName(IPAProductConstants.IPA_NOMINEE_WhethertheNomineeisaminor);
				nomineeMinor.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				//nomineeMinor.setValue(nomineeDet.getNomMinor());
				if(nomineeDet.getNomMinor().equalsIgnoreCase("true"))
					nomineeMinor.setValue("1");
				else
					nomineeMinor.setValue("0");
				nomineeGrid1.setWhethertheNomineeisaminor(nomineeMinor);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeGuardianName nomineeGuardName=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeGuardianName();
				nomineeGuardName.setName(IPAProductConstants.IPA_NOMINEE_NomineeGuardianName);
				nomineeGuardName.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nomineeGuardName.setValue(nomineeDet.getNomGaurdian());
				nomineeGrid1.setNomineeGuardianName(nomineeGuardName);
				
				com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeContribution nomineeContri=new com.majesco.dcf.paproduct.jaxb.accidentshield.premium.AccidentShieldPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeContribution();
				nomineeContri.setName(IPAProductConstants.IPA_NOMINEE_NomineeContribution);
				nomineeContri.setType(IPAProductConstants.IPA_NOMINEE_FieldType_Double);
				nomineeContri.setValue(nomineeDet.getNomContribtn());
				nomineeGrid1.setNomineeContribution(nomineeContri);
				
				nomineeGrid.setNomineeDetailsGrid1(nomineeGrid1);
				othGrid.getNomineeDetailsGrid().add(nomineeGrid);
				}
				
				p2Dto.setOtherDetailsGrid(othGrid);;
				
			}
			
			
			//Done hardcoding for testing purpose
			p2Dto.setPropIntermediaryDetails_IntermediaryCode(propPAReq.getProducerCode());
			p2Dto.setPropIntermediaryDetails_IntermediaryName(propPAReq.getProducerName());
//			p2Dto.setPropIntermediaryDetails_IntermediaryName("TAGIC");
			
			//Start: RahulT| Hardcoding to generate Accident shield premium
			String defaultSysDate1 = new SimpleDateFormat(CommonConstants.UNIQUE_SEQUENCE).format(new java.util.Date());
			Date startDate=new Date();
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy", Locale.US);
			p2Dto.setPropSerIntermediaryDetails_SerIntermediaryCode(CommonConstants.BLANK_STRING);
			p2Dto.setPropSerIntermediaryDetails_SerIntermediaryName(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_PolicySchedule_Mandatary("Yes");
			p2Dto.setPropReferenceNoDate_ReferenceNo_Mandatary(defaultSysDate1);
			p2Dto.setPropPremiumCalculation_NetPremium("0");	// need to check this default value
			p2Dto.setPropPremiumCalculation_ServiceTax("0");
			p2Dto.setPropPremiumCalculation_TotalPremium("0");
			p2Dto.setPropPremiumCalculation_StampDuty("0");
			p2Dto.setPropMODetails_TertiaryMOName(CommonConstants.BLANK_STRING);
//			p2Dto.setPropIntermediaryDetails_IntermediaryType("Non-DM");
			p2Dto.setPropGeneralProposalInformation_Iscovernoteused("false");
			p2Dto.setPropGeneralProposalInformation_ManualCovernoteNo(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_Covernoteissuedate(sdf.format(startDate));
			p2Dto.setPropGeneralProposalInformation_Covernoteissuetime("21:04");
			p2Dto.setPropGeneralProposalInformation_QuoteNumber(CommonConstants.BLANK_STRING);
			//p2Dto.setPropRisks_AnnualGrossIncomePolicyHolder("0");
			p2Dto.setPropGeneralProposalInformation_ManualCovernoteNo(CommonConstants.BLANK_STRING);
			p2Dto.setPropRisks_AnualGrosIncmeOfPolicyHlder("500");
			//End: RahulT| Hardcoding to generate Accident shield premium
			p2Dto.setPropGeneralProposalInformation_BusinessType_Mandatary("New Business");	// RahulT: Added during SIT. 
			
			/*p2Dto.setPropGeneralProposalInformation_DisplayOfficeCode("0200");
			
			p2Dto.setPropGeneralProposalInformation_OfficeCode("90900");
			p2Dto.setPropGeneralProposalInformation_OfficeName("MUMBAI");
			p2Dto.setPropGeneralProposalInformation_BranchOfficeCode("90200");*/
			
			String remarks="";
			if (propPAReq!=null && (propPAReq.getQuoteNo()!=null && !propPAReq.getQuoteNo().equalsIgnoreCase(""))){
				remarks=propPAReq.getQuoteNo();
			}
			remarks=remarks.concat(":"+propPAReq.getRemarks());
			p2Dto.setPropGeneralProposalInformation_Remarks(remarks);
			//p2Dto.setPropRisks_DifferentialSI("0");
			
			if(propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getSelfIsPolicyHolder()!=null)
				//p2Dto.setPropRisks_SelfisPolicyHolderHimself(propPAReq.getLstcvrgDet().getSelfIsPolicyHolder());
			
			if(propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getOccuptnClassOfSelf()!=null)
				//p2Dto.setPropRisks_OccupationClassOfSelf(propPAReq.getLstcvrgDet().getOccuptnClassOfSelf());
			if(propPAReq.getLstInsurDet()!=null && propPAReq.getLstInsurDet().size()>0){
				/*if(propPAReq.getLstInsurDet().get(0)!=null && propPAReq.getLstInsurDet().get(0).getOccupation()!=null)
				p2Dto.setPropRisks_Occupation(propPAReq.getLstInsurDet().get(0).getOccupation());*/
			}
			
			p2Dto.setPropEndorsementDtls_ISUWCompleted("false");
			p2Dto.setPropMODetails_TertiaryMOCode(CommonConstants.TERTIARY_MO_CODE);
			
			
/*if(propPAReq != null && propPAReq.getProposerDet()!= null && propPAReq.getProposerDet().getAddressDetList()!=null && p2Dto!=null && p2Dto.getPermanentLocation()!=null){
				
				String district[] = propPAReq.getProposerDet().getAddressDetList().getDistrict().split("-");
				if(district!=null && district.length>0){
					
					p2Dto.getPermanentLocation().setCityDistrictName(district[0].trim());
					p2Dto.getPermanentLocation().setCityDistrictCode(district[1].trim());
				}
				
				String state[] = propPAReq.getProposerDet().getAddressDetList().getState().split("-");
				if(state!=null && state.length>0){
					
					p2Dto.getPermanentLocation().setStateName(state[0].trim());
					p2Dto.getPermanentLocation().setStateCode(state[1].trim());
				}
				
				String city[] = propPAReq.getProposerDet().getAddressDetList().getCity().split("-");
				if(city!=null && city.length>0){
					
					p2Dto.getPermanentLocation().setCityName(city[0].trim());
					p2Dto.getPermanentLocation().setCityId(city[1].trim());
				}
				
				String pin[]=propPAReq.getProposerDet().getAddressDetList().getPincode().split("-");
				if(pin!=null && pin.length>0){
					p2Dto.getPermanentLocation().setPinCodeLocality(pin[0].trim());
					p2Dto.getPermanentLocation().setPinCode(pin[1].trim());
				}
				String country[]=propPAReq.getProposerDet().getAddressDetList().getCountry().split("-");
				if(country!=null && country.length>0){
					p2Dto.getPermanentLocation().setCountryName(country[0].trim());
					p2Dto.getPermanentLocation().setCountryID(country[1].trim());

				}
			}
			
           if(propPAReq != null && propPAReq.getProposerDet()!= null && propPAReq.getProposerDet().getAddressDetList()!=null && p2Dto!=null && p2Dto.getMailLocation()!=null){
				
				String district[] = propPAReq.getProposerDet().getAddressDetList().getDistrict().split("-");
				if(district!=null && district.length>0){
					
					p2Dto.getMailLocation().setCityDistrictName(district[0].trim());
					p2Dto.getMailLocation().setCityDistrictCode(district[1].trim());
				}
				
				String state[] = propPAReq.getProposerDet().getAddressDetList().getState().split("-");
				if(state!=null && state.length>0){
					
					p2Dto.getMailLocation().setStateName(state[0].trim());
					p2Dto.getMailLocation().setStateCode(state[1].trim());
				}
				
				String city[] = propPAReq.getProposerDet().getAddressDetList().getCity().split("-");
				if(city!=null && city.length>0){
					
					p2Dto.getMailLocation().setCityName(city[0].trim());
					p2Dto.getMailLocation().setCityId(city[1].trim());
				}
				
				String pin[]=propPAReq.getProposerDet().getAddressDetList().getPincode().split("-");
				if(pin!=null && pin.length>0){
					p2Dto.getMailLocation().setPinCodeLocality(pin[0].trim());
					p2Dto.getMailLocation().setPinCode(pin[1].trim());
				}
				String country[]=propPAReq.getProposerDet().getAddressDetList().getCountry().split("-");
				if(country!=null && country.length>0){
					p2Dto.getMailLocation().setCountryName(country[0].trim());
					p2Dto.getMailLocation().setCountryID(country[1].trim());

				}
			}*/
			
			jaxbXML=JAXBXMLHandler.marshal(p2Dto);
			//System.out.println(jaxbXML);
			//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: generateIPAPremiumAS method :: jaxbXML :: "+jaxbXML);
			propValue=getWSDLURL(IPAProductConstants.IPA_ACCIDENTSHIELD_SERVICE_WSDL);
			//propValue="http://172.17.203.45:9595/IPAService_SOAPOverHTTP?wsdl";
			URL url = new URL(propValue);
			IPAService_Service stub = new IPAService_Service(url);
			com.unotechsoft.stub.ipaservice.client.QuotationRequest reqQ = new com.unotechsoft.stub.ipaservice.client.QuotationRequest(); 
			
			/*Getting Authentication Token Starts Here*/
			//String propFileName = "resource.properties";
			String userID="";
			String password="";
			String responseFrom = "";
			/*Properties prop = new Properties();
			InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
			prop.load(inputStream);*/
			userID=propPAReq.getUserID();
			password=propPAReq.getPassword();
			responseFrom=prop.getProperty("ResponseFrom");
			
			//Start:Vishal<VAPT comments>| code added to set GC token into user object 
			if (propPAReq.getAuthToken()!=null ){
				reqQ.setAuthenticationToken(propPAReq.getAuthToken());
			}
			else{
				AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
				/*Getting Authentication Token Stops Here*/	
				reqQ.setAuthenticationToken(authRes.getResultRes());
			}
			//End:Vishal<VAPT comments>| code added to set GC token into user object			
			
			reqQ.setSource(smc_source);
			reqQ.setProductCode("4254");
			reqQ.setModeOfOperation("NEWPOLICY");
			reqQ.setCampaign(smc_campaign);
			reqQ.setMedium(smc_medium);
			reqQ.setCIAName("");
			reqQ.setHashKey("");
			reqQ.setHostAddress("");
			reqQ.setInputXML(jaxbXML);
			reqQ.setIsBankDataRequired(false);
			reqQ.setIsCutomerAddressRequired(false);
			reqQ.setIsFinanciarDataRequired(false);
			reqQ.setIsManufacturerMappingRequired(false);
			reqQ.setIsRTOMappingRequired(false);
			reqQ.setUserId(propPAReq.getUserID());
			reqQ.setUserRole("ADMIN");
			
			com.unotechsoft.stub.ipaservice.client.IPAService port=stub.getSOAPOverHTTP();
			
			/*Client client=ClientProxy.getClient(port);
			PrintWriter writer = new PrintWriter(System.out);
			
			client.getOutInterceptors().add(new CdataWriterInterceptor());
			
			client.getInInterceptors().add(new LoggingInInterceptor(writer));
			
			client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
			//Service Time out code
			HTTPConduit conduit=(HTTPConduit)client.getConduit();
			HTTPClientPolicy clientPolicy=new HTTPClientPolicy();
			clientPolicy.setReceiveTimeout(60000);
			clientPolicy.setConnectionTimeout(30000);
			conduit.setClient(clientPolicy);
			//End:Service Time out code
*/			
			// Code added to save info abt SOAP in DB Start
			SOAPInfo soapInfo = new SOAPInfo();
			soapInfo.setTransactionID(transId);
			soapInfo.setLobService("getQuickQuote");
			soapInfo.setLobtype("42");
			soapInfo.setCreatedBy(propPAReq.getUserID());
			soapInfo.setProducerCode(propPAReq.getProducerCode());
			soapInfo.setSystemIP(propPAReq.getSystemIP());
			soapInfo.setTransactionEvent("GetPremium / IPA-AS");
			soapInfo.setJsonRequest(objMap.writeValueAsString(propPAReq));
			soapInfo.setProductCode(propPAReq.getProdCode());
			
			
			cxfInInterceptor =new CXFInBoundInterceptor(soapInfo);
			cxfOutInterceptor= new CXFOutInterceptor(soapInfo);
			
			ServiceUtility utility = new ServiceUtility();
			utility.addClientInterceptorDB(port,cxfInInterceptor,cxfOutInterceptor);
			
			com.unotechsoft.stub.ipaservice.client.QuotationResponse response = port.getQuickQuote(reqQ);
			
			//if(logger.isDebugEnabled())logger.debug("Adding Out Logs to DB");
			dbserv.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
			//if(logger.isDebugEnabled())logger.debug("Adding In Logs to DB");
			dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());				
			
//Code end for Saving SOAP Data to DB.	
			
			com.unotechsoft.stub.ipaservice.client.accidentshield.result.UWProductServiceResult uwResult=new com.unotechsoft.stub.ipaservice.client.accidentshield.result.UWProductServiceResult();
			if(response.getResponseXML()!=null){
			uwResult=(com.unotechsoft.stub.ipaservice.client.accidentshield.result.UWProductServiceResult)jaxbHandler.unmarshal(response.getResponseXML(), uwResult);
			}
			if(uwResult!=null && uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().size()>0 && uwResult.getUWOperationResult().get(0)!=null){
				if(uwResult.getUWOperationResult().get(0).getErrorText()!=null && !uwResult.getUWOperationResult().get(0).getErrorText().equals(""))
				{
					propPARes.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR");
					errorRes.setErrorMMessag(uwResult.getUWOperationResult().get(0).getErrorText());
					errorList.add(errorRes);
					propPARes.setResErr(errorList);
					if(cxfInInterceptor!=null){
						cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(propPARes));
						dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());	
					}
					return propPARes;
				}
				else{
					
                    //Start:Added to set proposal response field to be used in AccountService
					
					if(uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().get(0)!=null){
						
						if(uwResult.getUWOperationResult().get(0).getConfWFHelper()!=null && uwResult.getUWOperationResult().get(0).getConfWFHelper().get(0)!=null){
							propPARes.setProposalSystemId(uwResult.getUWOperationResult().get(0).getConfWFHelper().get(0).getWFSystemID());
						}
						
						if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null){
						propPARes.setBusinessLocation(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_OfficeCode());
						propPARes.setDepositOfficeCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_OfficeCode());
						propPARes.setBussLocName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_OfficeName());
						}
						
						//Start:07-Sep-2016:Added UW rules warning text from GC
						if(uwResult != null && uwResult.getUWOperationResult() != null && uwResult.getUWOperationResult().get(0)!=null && uwResult.getUWOperationResult().get(0).getWarningText()!=null)
							propPARes.setRulesWarning(uwResult.getUWOperationResult().get(0).getWarningText());
						//End:07-Sep-2016:Added UW rules warning text from GC
						
					
					propPARes.setProposalNumber(uwResult.getUWOperationResult().get(0).getProposalNo());
					propPARes.setProposalDate(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_ProposalDate_Mandatary());
					
					if(uwResult.getUWOperationResult().get(0).getNetPremium()!=null)
						prmdet.setNetPremium(uwResult.getUWOperationResult().get(0).getNetPremium());
					if(uwResult.getUWOperationResult().get(0).getTotalPremium()!=null)
						prmdet.setTotalPremium(uwResult.getUWOperationResult().get(0).getTotalPremium());
					if(uwResult.getUWOperationResult().get(0).getTotalSI()!=null)
						prmdet.setSumInsured(uwResult.getUWOperationResult().get(0).getTotalSI());
					if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null)
						prmdet.setServiceTax(uwResult.getUWOperationResult().get(0).getServiceTax());
					
					}//End:Added to set proposal response field to be used in AccountService
					
					/*Added To Send Application Number To UI*/
					if(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodes_ApplicationNo()!=null)
					{
						propPARes.setApplcationNo(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodes_ApplicationNo());
					}
					else
					{
						propPARes.setApplcationNo("");
					}
					/*Added To Send Application Number To UI*/
					
					// set values in response
					/*if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null){
						propPARes.setBusinessLocation(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
						propPARes.setDepositOfficeCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
						propPARes.setBussLocName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeName());
					}*/
					
					propPARes.setPremDet(prmdet);
				}
			}
			//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: generateIPAPremiumAS :: Entered"+objMap.writeValueAsString(propPARes));
			
		}
		
		catch(Exception e)
		{
			propPARes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR");
			errorRes.setErrorMMessag(e.getMessage()+".Transaction ID::"+transId);
			errorList.add(errorRes);
			propPARes.setResErr(errorList);
			e.printStackTrace();
			logger.error("Inside IPAServiceImpl :: generateIPAPremiumAS method :: Exception Occurred : "+e.toString()+".Transaction ID::"+transId);
		}
		
		logger.info("Start::"+transId+" :: IPAServiceImpl :: generateIPAPremiumAS :: Exit :: "+objMap.writeValueAsString(propPARes));
		if(cxfInInterceptor!=null){
			cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(propPARes));
			dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());	
		}
		return propPARes;
	}
	
	
public IPAProposalResponse getIPAPremiumAG(IPAProposalRequest propPAReq) throws Exception{
	ObjectMapper objMap = new ObjectMapper();
	logger.info("Inside IPAServiceImpl :: getIPAPremiumAG :: Entered"+objMap.writeValueAsString(propPAReq));
	
	
	IPAProposalResponse propPARes = new IPAProposalResponse();
	
	long transId=propPAReq.getLocalTransId();
	List<ResponseError> lstResErr  = new ArrayList<ResponseError>();
	ResponseError reserr = new ResponseError();
	PremiumDetails prmdet = new PremiumDetails();
	CXFInBoundInterceptor cxfInInterceptor =null;
	CXFOutInterceptor cxfOutInterceptor= null;
//	AccidentGuardProductProposalPolicy obj = new AccidentGuardProductProposalPolicy();
//	obj.getPropRisksCol().getRisks().get(0).
	
	JAXBXMLHandler jaxbHandler=new JAXBXMLHandler();
	String jaxbXML = "";
	List<String> list = new ArrayList<String>();
	Mapper mapper =null;
	
   
	try{
		list.add("IPAMapping.xml");
		mapper = (Mapper) new DozerBeanMapper(list);
		/*reserr.setErrorCode("101");
		reserr.setErrorMMessag("Sorry Authentication Issue....");
		lstResErr.add(reserr);
		
		prmdet.setNetPremium("100000");
		prmdet.setDiscount("100");
		prmdet.setPremiumPayable("400.00");
		prmdet.setServiceTax("200");
		prmdet.setSumInsured("10000");
		
		propPARes.setResultCode("0");
		propPARes.setResErr(lstResErr);
		propPARes.setPremDet(prmdet);*/
		
		//IPAProposalRequest genQuotrequest = motorUtil.getMotorExternalMapCalculator(calcMotReq);
		//TravelObjectConvertor travelConvertor = null;
		AccidentGuardPolicy p2Dto = new AccidentGuardPolicy();
//		mapper.map(propPAReq, p2Dto,"IPAProposalAG");
		//p2Dto = travelConvertor.getJaxbReqObjForTravQuot(propPAReq);
		
		propPAReq=mapToExternalCode(propPAReq);
		
		//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: getIPAPremiumAG :: aftter external data map: "+objMap.writeValueAsString(propPAReq));
		if(propPAReq!=null && propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getCoreSumInsured()!=null){
			propPAReq.getLstcvrgDet().setCoreSumInsured("500000");
		}
		
		
		mapper.map(propPAReq, p2Dto,"IPAGetPremiumAG");
		
		//Start:28/02/2017:Added for full name required by GC
		StringBuffer strFullName=new StringBuffer();
		strFullName.append(propPAReq.getFirstName());
		if(propPAReq.getMiddleName()!=null && !propPAReq.getMiddleName().equals(CommonConstants.BLANK_STRING))
			strFullName.append(" "+propPAReq.getMiddleName());
		if(propPAReq.getLastName()!=null && !propPAReq.getLastName().equals(CommonConstants.BLANK_STRING))
			strFullName.append(" "+propPAReq.getLastName());
		//End:28/02/2017:Added for full name required by GC
		
		p2Dto.setPropCustomerDtls_CustomerName(strFullName.toString().toUpperCase());
		
		com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.PropRisks_Col riskCol=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.PropRisks_Col();
		
		for(InsuredDetails insuredDet:propPAReq.getLstInsurDet()){
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.PropRisks_Col.Risks riskObj=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.PropRisks_Col.Risks();
			mapper.map(insuredDet, riskObj, "IPAInsuredGetPremiumAG");
			riskObj.setPropRisks_OtherRiskPrem1("0");
			riskObj.setPropRisks_OtherRiskPrem2("0");
			riskObj.setPropRisks_Month("364"); // Currently defaulted to 364 as per ESB sample from unotechsoft.
			if(riskObj.getPropRisks_DoyouhaveanyOtherPAinsurance()==null || riskObj.getPropRisks_DoyouhaveanyOtherPAinsurance().equalsIgnoreCase(""))
				riskObj.setPropRisks_DoyouhaveanyOtherPAinsurance("false");
			
			if(riskObj.getPropRisks_AnyPEDillnesstreated()==null || riskObj.getPropRisks_AnyPEDillnesstreated().equalsIgnoreCase(""))
				riskObj.setPropRisks_AnyPEDillnesstreated("false");
			
			//riskObj.setPropRisks_InsuredName(strFullName.toString().toUpperCase());
			riskObj.setPropRisks_InsuredName(insuredDet.getInsuName());
			riskCol.getRisks().add(riskObj);
			//p2Dto.getPropRisks_Col().getRisks().add(riskObj);
		}
				
		p2Dto.setPropRisks_Col(riskCol);
		
		//Setting nominee details
		if(propPAReq.getLstNomDet()!=null && propPAReq.getLstNomDet().size()>0){
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid othGrid=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid();
			
			for(NomineeDetails nomineeDet:propPAReq.getLstNomDet()){
				
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid nomineeGrid=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid();
			nomineeGrid.setName(IPAProductConstants.IPA_NOMINEE_GRID_NAME);
			nomineeGrid.setValue(IPAProductConstants.IPA_NOMINEE_GRID_VALUE);
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1 nomineeGrid1=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1();
			nomineeGrid1.setType(IPAProductConstants.IPA_NOMINEE_TYPE);
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.InsuredPerson insPerson=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.InsuredPerson();
			insPerson.setName(IPAProductConstants.IPA_NOMINEE_InsuredPerson);
			insPerson.setValue(nomineeDet.getInsuPerson());
			//insPerson.setValue(strFullName.toString().toUpperCase());
			insPerson.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
			nomineeGrid1.setInsuredPerson(insPerson);
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Nominee nominee=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Nominee();
			nominee.setName(IPAProductConstants.IPA_NOMINEE_Nominee);
			nominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
			nominee.setValue(nomineeDet.getNomName());
			nomineeGrid1.setNominee(nominee);
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Age age=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Age();
			age.setName(IPAProductConstants.IPA_NOMINEE_Age);
			age.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
			age.setValue(nomineeDet.getNomAge());
			nomineeGrid1.setAge(age);
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.DateofBirth dtBirth=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.DateofBirth();
			dtBirth.setName(IPAProductConstants.IPA_NOMINEE_DateofBirth);
			dtBirth.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
			dtBirth.setValue(nomineeDet.getNomDOB());
			nomineeGrid1.setDateofBirth(dtBirth);
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.GenderofNominee genderNominee=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.GenderofNominee();
			genderNominee.setName(IPAProductConstants.IPA_NOMINEE_GenderofNominee);
			genderNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
			genderNominee.setValue(nomineeDet.getNomGender());
			nomineeGrid1.setGenderofNominee(genderNominee);
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineeGuardianwithNominee relationshipNominee=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineeGuardianwithNominee();
			relationshipNominee.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineeGuardianwithNominee);
			relationshipNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
			relationshipNominee.setValue(nomineeDet.getNomGaurdRelation()==null?"":nomineeDet.getNomGaurdRelation());
			nomineeGrid1.setRelationshipofNomineeGuardianwithNominee(relationshipNominee);
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineewithInsuredPerson relationshipInsured=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineewithInsuredPerson();
			relationshipInsured.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineewithInsuredPerson);
			relationshipInsured.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
			relationshipInsured.setValue(nomineeDet.getNomRelation());
			nomineeGrid1.setRelationshipofNomineewithInsuredPerson(relationshipInsured);
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.WhethertheNomineeisaminor nomineeMinor=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.WhethertheNomineeisaminor();
			nomineeMinor.setName(IPAProductConstants.IPA_NOMINEE_WhethertheNomineeisaminor);
			nomineeMinor.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
			if(nomineeDet.getNomMinor().equalsIgnoreCase("true"))
				nomineeMinor.setValue("1");
			else
				nomineeMinor.setValue("0");
			nomineeGrid1.setWhethertheNomineeisaminor(nomineeMinor);
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeGuardianName nomineeGuardName=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeGuardianName();
			nomineeGuardName.setName(IPAProductConstants.IPA_NOMINEE_NomineeGuardianName);
			nomineeGuardName.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
			nomineeGuardName.setValue(nomineeDet.getNomGaurdian());
			nomineeGrid1.setNomineeGuardianName(nomineeGuardName);
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeContribution nomineeContri=new com.majesco.dcf.paproduct.jaxb.accidentguard.premium.AccidentGuardPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeContribution();
			nomineeContri.setName(IPAProductConstants.IPA_NOMINEE_NomineeContribution);
			nomineeContri.setType(IPAProductConstants.IPA_NOMINEE_FieldType_Double);
			nomineeContri.setValue(nomineeDet.getNomContribtn());
			nomineeGrid1.setNomineeContribution(nomineeContri);
			
			nomineeGrid.setNomineeDetailsGrid1(nomineeGrid1);
			othGrid.getNomineeDetailsGrid().add(nomineeGrid);
			}
			
			p2Dto.setOtherDetailsGrid(othGrid);
			
			
			
		}
		
		
		//Done hardcoding for testing purpose
		p2Dto.setPropIntermediaryDetails_IntermediaryCode(propPAReq.getProducerCode());
		p2Dto.setPropIntermediaryDetails_IntermediaryName(propPAReq.getProducerName());
//		p2Dto.setPropIntermediaryDetails_IntermediaryName("TAGIC");
		
		/*p2Dto.setPropGeneralProposalInformation_DisplayOfficeCode("0200");
		
		p2Dto.setPropGeneralProposalInformation_OfficeCode("90900");
		p2Dto.setPropGeneralProposalInformation_OfficeName("MUMBAI");
		p2Dto.setPropGeneralProposalInformation_BranchOfficeCode("90200");
		p2Dto.setPropGeneralProposalInformation_BusinessType_Mandatary("New Business");*/
		String remarks="";
		if (propPAReq!=null && (propPAReq.getQuoteNo()!=null && !propPAReq.getQuoteNo().equalsIgnoreCase(""))){
			remarks=propPAReq.getQuoteNo();
		}
		remarks=remarks.concat(":"+propPAReq.getRemarks());
		p2Dto.setPropGeneralProposalInformation_Remarks(remarks);
		p2Dto.setPropRisks_DifferentialSI("0");
		
		if(propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getCoreSumInsured()!=null)
		p2Dto.setPropRisks_BaseSIUnit(propPAReq.getLstcvrgDet().getCoreSumInsured());
		
		if(propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getSelfIsPolicyHolder()!=null)
			p2Dto.setPropRisks_SelfisPolicyHolderHimself(propPAReq.getLstcvrgDet().getSelfIsPolicyHolder());
		
		if(propPAReq.getLstcvrgDet()!=null && propPAReq.getLstcvrgDet().getOccuptnClassOfSelf()!=null)
			p2Dto.setPropRisks_OccupationClassOfSelf(propPAReq.getLstcvrgDet().getOccuptnClassOfSelf());
		if(propPAReq.getLstInsurDet()!=null && propPAReq.getLstInsurDet().size()>0){
			if(propPAReq.getLstInsurDet().get(0)!=null && propPAReq.getLstInsurDet().get(0).getOccupation()!=null)
			p2Dto.setPropRisks_Occupation(propPAReq.getLstInsurDet().get(0).getOccupation());
		}
		
		p2Dto.setPropEndorsementDtls_ISUWCompleted("True");
		p2Dto.setPropMODetails_TertiaryMOCode(CommonConstants.TERTIARY_MO_CODE);
		
		if(p2Dto.getPropRisks_Col()!=null && p2Dto.getPropRisks_Col().getRisks()!=null && p2Dto.getPropRisks_Col().getRisks().size()>0){
			for(int i=0;i<p2Dto.getPropRisks_Col().getRisks().size();i++){
				if(p2Dto.getPropRisks_Col().getRisks().get(i)!=null){
					p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_DifferentialSI("0");
					p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_EndorsementAmount("0"); // Endorsement amount / premium amount set default to 0.
					p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_Premium("0"); // Endorsement amount / premium amount set default to 0.
					if(p2Dto.getPropRisks_Col().getRisks().get(i).getPropRisks_OtherPAInsurancePolicyNo()==null){
						p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_OtherPAInsurancePolicyNo(CommonConstants.BLANK_STRING);
					}
					if(p2Dto.getPropRisks_Col().getRisks().get(i).getPropRisks_NameOftheInsurer()==null){
						p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_NameOftheInsurer(CommonConstants.BLANK_STRING);	
					}					
					if(p2Dto.getPropRisks_Col().getRisks().get(i).getPropRisks_IdentityProofType()==null)
						p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_IdentityProofType(CommonConstants.BLANK_STRING);
					if(p2Dto.getPropRisks_Col().getRisks().get(i).getPropRisks_IdentityProofNumber()==null)
						p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_IdentityProofNumber(CommonConstants.BLANK_STRING);
					
					p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_IsDataDeleted("false");
					p2Dto.getPropRisks_Col().getRisks().get(i).setPropRisks_IsOldDataDeleted("false");
					p2Dto.getPropRisks_Col().getRisks().get(i).setIsOptionalCover("true");
				}
			}
		}
		
		if(propPAReq != null && propPAReq.getProposerDet()!= null && propPAReq.getProposerDet().getAddressDetList()!=null && p2Dto!=null && p2Dto.getPermanentLocation()!=null){
			
			if(propPAReq.getProposerDet().getAddressDetList().getDistrict() != null && ! propPAReq.getProposerDet().getAddressDetList().getDistrict().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				String district[] = propPAReq.getProposerDet().getAddressDetList().getDistrict().split("-");				
				if(district!=null && district.length>0){
					
					p2Dto.getPermanentLocation().setCityDistrictName(district[0].trim());
					p2Dto.getPermanentLocation().setCityDistrictCode(district[1].trim());
				}
			}
				
			if(propPAReq.getProposerDet().getAddressDetList().getState() != null && ! propPAReq.getProposerDet().getAddressDetList().getState().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				String state[] = propPAReq.getProposerDet().getAddressDetList().getState().split("-");
				if(state!=null && state.length>0){
					
					p2Dto.getPermanentLocation().setStateName(state[0].trim());
					p2Dto.getPermanentLocation().setStateCode(state[1].trim());
				}	
			}
			
			
			if( propPAReq.getProposerDet().getAddressDetList().getCity() != null && ! propPAReq.getProposerDet().getAddressDetList().getCity().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				String city[] = propPAReq.getProposerDet().getAddressDetList().getCity().split("-");
				if(city!=null && city.length>0){
					
					p2Dto.getPermanentLocation().setCityName(city[0].trim());
					p2Dto.getPermanentLocation().setCityId(city[1].trim());
				}				
			}

			if( propPAReq.getProposerDet().getAddressDetList().getPincode() != null && ! propPAReq.getProposerDet().getAddressDetList().getPincode().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				String pin[]=propPAReq.getProposerDet().getAddressDetList().getPincode().split("-");
				if(pin!=null && pin.length>0){
					p2Dto.getPermanentLocation().setPinCodeLocality(pin[0].trim());
					p2Dto.getPermanentLocation().setPinCode(pin[1].trim());
				}	
			}
			
			if( propPAReq.getProposerDet().getAddressDetList().getCountry() != null && ! propPAReq.getProposerDet().getAddressDetList().getCountry().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				String country[]=propPAReq.getProposerDet().getAddressDetList().getCountry().split("-");
				if(country!=null && country.length>0){
					p2Dto.getPermanentLocation().setCountryName(country[0].trim());
					p2Dto.getPermanentLocation().setCountryID(country[1].trim());

				}				
			}
			

		}
		
       if(propPAReq != null && propPAReq.getProposerDet()!= null && propPAReq.getProposerDet().getAddressDetList()!=null && p2Dto!=null && p2Dto.getMailLocation()!=null){
			
    	   
    	   if(propPAReq.getProposerDet().getAddressDetList().getDistrict() != null && ! propPAReq.getProposerDet().getAddressDetList().getDistrict().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				String district[] = propPAReq.getProposerDet().getAddressDetList().getDistrict().split("-");				
				if(district!=null && district.length>0){
					
					p2Dto.getMailLocation().setCityDistrictName(district[0].trim());
					p2Dto.getMailLocation().setCityDistrictCode(district[1].trim());
				}
			}    	       	  	
			
    	   	
    	   if(propPAReq.getProposerDet().getAddressDetList().getState() != null && ! propPAReq.getProposerDet().getAddressDetList().getState().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				String state[] = propPAReq.getProposerDet().getAddressDetList().getState().split("-");
				if(state!=null && state.length>0){
					
					p2Dto.getMailLocation().setStateName(state[0].trim());
					p2Dto.getMailLocation().setStateCode(state[1].trim());
				}	
			}
    	   	
    	   if( propPAReq.getProposerDet().getAddressDetList().getCity() != null && ! propPAReq.getProposerDet().getAddressDetList().getCity().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				String city[] = propPAReq.getProposerDet().getAddressDetList().getCity().split("-");
				if(city!=null && city.length>0){
					
					p2Dto.getMailLocation().setCityName(city[0].trim());
					p2Dto.getMailLocation().setCityId(city[1].trim());
				}				
			}
    	  			
    	   if( propPAReq.getProposerDet().getAddressDetList().getPincode() != null && ! propPAReq.getProposerDet().getAddressDetList().getPincode().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				String pin[]=propPAReq.getProposerDet().getAddressDetList().getPincode().split("-");
				if(pin!=null && pin.length>0){
					p2Dto.getMailLocation().setPinCodeLocality(pin[0].trim());
					p2Dto.getMailLocation().setPinCode(pin[1].trim());
				}	
			}
    	   
    	   if( propPAReq.getProposerDet().getAddressDetList().getCountry() != null && ! propPAReq.getProposerDet().getAddressDetList().getCountry().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				String country[]=propPAReq.getProposerDet().getAddressDetList().getCountry().split("-");
				if(country!=null && country.length>0){
					p2Dto.getMailLocation().setCountryName(country[0].trim());
					p2Dto.getMailLocation().setCountryID(country[1].trim());

				}				
			}
					
		}
		
		jaxbXML=jaxbHandler.marshal(p2Dto);
		//System.out.println(jaxbXML);
		//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: getIPAPremiumAG method :: jaxbXML :: "+jaxbXML);
		propValue=getWSDLURL(IPAProductConstants.IPA_ACCIDENTGUARD_SERVICE_WSDL);
		//propValue="http://172.17.203.45:9595/IPAService_SOAPOverHTTP?wsdl";
		URL url = new URL(propValue);
		IPAService_Service stub = new IPAService_Service(url);
		com.unotechsoft.stub.ipaservice.client.QuotationRequest reqQ = new com.unotechsoft.stub.ipaservice.client.QuotationRequest();  
		
		/*Getting Authentication Token Starts Here*/
		//String propFileName = "resource.properties";
		String userID="";
		String password="";
		String responseFrom = "";
		/*Properties prop = new Properties();
		InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
		prop.load(inputStream);*/
		userID=propPAReq.getUserID();
		password=propPAReq.getPassword();
		responseFrom=prop.getProperty("ResponseFrom");
		
		//Start:Vishal<VAPT comments>| code added to set GC token into user object 
		if (propPAReq.getAuthToken()!=null ){
			reqQ.setAuthenticationToken(propPAReq.getAuthToken());
		}
		else{
			AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
			/*Getting Authentication Token Stops Here*/	
			reqQ.setAuthenticationToken(authRes.getResultRes());
		}
		//End:Vishal<VAPT comments>| code added to set GC token into user object
		
		reqQ.setSource(smc_source);
		reqQ.setProductCode("4251");
		reqQ.setModeOfOperation("NEWPOLICY");
		reqQ.setCampaign(smc_campaign);
		reqQ.setMedium(smc_medium);
		reqQ.setCIAName("");
		reqQ.setHashKey("");
		reqQ.setHostAddress("");
		reqQ.setInputXML(jaxbXML);
		reqQ.setIsBankDataRequired(false);
		reqQ.setIsCutomerAddressRequired(false);
		reqQ.setIsFinanciarDataRequired(false);
		reqQ.setIsManufacturerMappingRequired(false);
		reqQ.setIsRTOMappingRequired(false);
		reqQ.setUserId(propPAReq.getUserID());
		reqQ.setUserRole("ADMIN");
		
		com.unotechsoft.stub.ipaservice.client.IPAService port=stub.getSOAPOverHTTP();
		
		/*Client client=ClientProxy.getClient(port);
		PrintWriter writer = new PrintWriter(System.out);
		
		client.getOutInterceptors().add(new CdataWriterInterceptor());
		
		client.getInInterceptors().add(new LoggingInInterceptor(writer));
		
		client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
		//Service Time out code
		HTTPConduit conduit=(HTTPConduit)client.getConduit();
		HTTPClientPolicy clientPolicy=new HTTPClientPolicy();
		clientPolicy.setReceiveTimeout(60000);
		clientPolicy.setConnectionTimeout(30000);
		conduit.setClient(clientPolicy);
		//End:Service Time out code*/		
		
		// Code added to save info abt SOAP in DB Start
		SOAPInfo soapInfo = new SOAPInfo();
		soapInfo.setTransactionID(transId);
		soapInfo.setLobService("getQuickQuote");
		soapInfo.setLobtype("42");
		soapInfo.setCreatedBy(propPAReq.getUserID());
		soapInfo.setProducerCode(propPAReq.getProducerCode());
		soapInfo.setSystemIP(propPAReq.getSystemIP());
		soapInfo.setTransactionEvent("GetPremium / IPA-AG");
		soapInfo.setJsonRequest(objMap.writeValueAsString(propPAReq));
		soapInfo.setProductCode(propPAReq.getProdCode());
		
		
		cxfInInterceptor =new CXFInBoundInterceptor(soapInfo);
		cxfOutInterceptor= new CXFOutInterceptor(soapInfo);
		
		ServiceUtility utility = new ServiceUtility();
		utility.addClientInterceptorDB(port,cxfInInterceptor,cxfOutInterceptor);
		
		com.unotechsoft.stub.ipaservice.client.QuotationResponse response = port.getQuickQuote(reqQ);
		
		//propPARes.setProposalNumber(response.getProposalNumber());	//Commented As This is GetPremium Method For AG
		//if(logger.isDebugEnabled())logger.debug("Adding Out Logs to DB");
		dbserv.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
		//if(logger.isDebugEnabled())logger.debug("Adding In Logs to DB");
		dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());				
		
		//Code end for Saving SOAP Data to DB.
		
		propPARes.setResultCode("1");
		
		UWProductServiceResult uwResult=new UWProductServiceResult();
		if(response.getResponseXML()!=null){
			if(responseFrom!=null && responseFrom.equalsIgnoreCase("TataAIG"))
			{
				uwResult=(UWProductServiceResult)jaxbHandler.unmarshal(response.getResponseXML(), uwResult);
			}
			
			else if(responseFrom!=null && responseFrom.equalsIgnoreCase("MajescoQC"))
			{	
				uwResult=(UWProductServiceResult)jaxbHandler.unmarshalTest(new File("/responseAccidentGaurd.xml"), uwResult);
			}
		}
		if(uwResult!=null && uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().size()>0 && uwResult.getUWOperationResult().get(0)!=null){
			if(uwResult.getUWOperationResult().get(0).getErrorText()!=null && !uwResult.getUWOperationResult().get(0).getErrorText().equals(""))
			{
				propPARes.setResultCode("0");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError errorRes=new ResponseError();
				errorRes.setErrorCode("ERR");
				errorRes.setErrorMMessag(uwResult.getUWOperationResult().get(0).getErrorText());
				errorList.add(errorRes);
				propPARes.setResErr(errorList);
				if(cxfInInterceptor!=null){
					cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(propPARes));
					dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());	
				}				
				return propPARes;
			}
			else{
				
                //Start:Added to set proposal response field to be used in AccountService
				
				if(uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().get(0)!=null){
					
					if(uwResult.getUWOperationResult().get(0).getConfWFHelper()!=null && uwResult.getUWOperationResult().get(0).getConfWFHelper().get(0)!=null){
						propPARes.setProposalSystemId(uwResult.getUWOperationResult().get(0).getConfWFHelper().get(0).getWFSystemID());
					}
					
					if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null){
					propPARes.setBusinessLocation(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
					propPARes.setDepositOfficeCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
					propPARes.setBussLocName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeName());
					}
					
					//Start:07-Sep-2016:Added UW rules warning text from GC
					if(uwResult != null && uwResult.getUWOperationResult() != null && uwResult.getUWOperationResult().get(0)!=null && uwResult.getUWOperationResult().get(0).getWarningText()!=null)
						propPARes.setRulesWarning(uwResult.getUWOperationResult().get(0).getWarningText());
					//End:07-Sep-2016:Added UW rules warning text from GC	
					
				
				propPARes.setProposalNumber(uwResult.getUWOperationResult().get(0).getProposalNo());
				propPARes.setProposalDate(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationProposalDateMandatary());
				
				if(uwResult.getUWOperationResult().get(0).getNetPremium()!=null)
					prmdet.setNetPremium(uwResult.getUWOperationResult().get(0).getNetPremium());
				if(uwResult.getUWOperationResult().get(0).getTotalPremium()!=null)
					prmdet.setTotalPremium(uwResult.getUWOperationResult().get(0).getTotalPremium());
				if(uwResult.getUWOperationResult().get(0).getTotalSI()!=null)
					prmdet.setSumInsured(uwResult.getUWOperationResult().get(0).getTotalSI());
				if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null)
					prmdet.setServiceTax(uwResult.getUWOperationResult().get(0).getServiceTax());
				
				}//End:Added to set proposal response field to be used in AccountService
				
				// set values in response
				if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null){
					propPARes.setBusinessLocation(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
					propPARes.setDepositOfficeCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeCode());
					propPARes.setBussLocName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformationOfficeName());
				}
				/*Added To Send Application Number To UI*/
				if(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodesApplicationNo()!=null)
				{
					propPARes.setApplcationNo(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodesApplicationNo());
				}
				else
				{
					propPARes.setApplcationNo("");
				}
				/*Added To Send Application Number To UI*/
				propPARes.setPremDet(prmdet);
			}
		}
		//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: getIPAPremiumAG :: response"+objMap.writeValueAsString(propPARes));
		
	}
	
	catch(Exception e)
	{
		propPARes.setResultCode("0");
		List<ResponseError> errorList=new ArrayList<ResponseError>();
		ResponseError errorRes=new ResponseError();
		errorRes.setErrorCode("ERR");
		errorRes.setErrorMMessag(e.getMessage()+".Transaction ID::"+transId);
		errorList.add(errorRes);
		propPARes.setResErr(errorList);
		e.printStackTrace();
		//logger.info("Inside IPAServiceImpl :: getIPAPremiumAG method :: Exception Occurred : "+e.toString()+".Transaction ID::"+transId);
		logger.error("Inside IPAServiceImpl :: getIPAPremiumAG method :: Exception Occurred : "+e.toString()+".Transaction ID::"+transId, e);
	}
	
	logger.info("Start::"+transId+" :: IPAServiceImpl :: getIPAPremiumAG :: Exit :: "+objMap.writeValueAsString(propPARes));
	if(cxfInInterceptor!=null){
		cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(propPARes));	
		dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());
	}
	return propPARes;
}
	
	public IPAProposalResponse getIPAPremiumSecurePlan(IPAProposalRequest propPAReq) throws Exception{
		
		IPAProposalResponse propPARes = new IPAProposalResponse();
		ObjectMapper objMap = new ObjectMapper();
		long transId=propPAReq.getLocalTransId();
		List<ResponseError> lstResErr  = new ArrayList<ResponseError>();
		ResponseError reserr = new ResponseError();
		PremiumDetails prmdet = new PremiumDetails();
		String strMethod="getIPAPremiumSecurePlan";
		CXFInBoundInterceptor cxfInInterceptor =null;
		CXFOutInterceptor cxfOutInterceptor= null;
//		AccidentGuardProductProposalPolicy obj = new AccidentGuardProductProposalPolicy();
//		obj.getPropRisksCol().getRisks().get(0).
		
		JAXBXMLHandler jaxbHandler=new JAXBXMLHandler();
		String jaxbXML = "";
		List<String> list = new ArrayList<String>();
		
		Mapper mapper=null;
		
		logger.info("Start::"+transId+" :: IPAServiceImpl :: "+strMethod+" :: Entered");
		
		try{
			list.add("IPAMapping.xml");
			
			mapper = (Mapper) new DozerBeanMapper(list);

			SecureFuturePlanPolicy p2Dto=new SecureFuturePlanPolicy();
//			mapper.map(propPAReq, p2Dto,"IPAProposalAG");
			//p2Dto = travelConvertor.getJaxbReqObjForTravQuot(propPAReq);
			propPAReq=mapToExternalCode(propPAReq);
			mapper.map(propPAReq, p2Dto,"IPAPremiumSecurePlan");
			
			//Start:28/02/2017:Added for full name required by GC
			StringBuffer strFullName=new StringBuffer();
			strFullName.append(propPAReq.getFirstName());
			if(propPAReq.getMiddleName()!=null && !propPAReq.getMiddleName().equals(CommonConstants.BLANK_STRING))
				strFullName.append(" "+propPAReq.getMiddleName());
			if(propPAReq.getLastName()!=null && !propPAReq.getLastName().equals(CommonConstants.BLANK_STRING))
				strFullName.append(" "+propPAReq.getLastName());
			//End:28/02/2017:Added for full name required by GC
			p2Dto.setPropCustomerDtls_CustomerName(strFullName.toString().toUpperCase());
			
			com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.PropRisks_Col riskCol=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.PropRisks_Col();
			
			for(InsuredDetails insuredDet:propPAReq.getLstInsurDet()){
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.PropRisks_Col.Risks riskObj=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.PropRisks_Col.Risks();
				mapper.map(insuredDet, riskObj, "IPAPremiumInsuredSecurePlan");
				//Start: RahulT| Hardcoding to generate Accident shield proposal
				riskObj.setPropRisks_IdentityProofNumber(CommonConstants.BLANK_STRING);
				riskObj.setPropRisks_IdentityProofType(CommonConstants.BLANK_STRING);
				riskObj.setPropRisks_DifferentialSI("0");
				riskObj.setPropRisks_EndorsementAmount("0");
				riskObj.setPropRisks_Premium("0");
				riskObj.setPropRisks_Rate("0");
				riskObj.setPropRisks_IsDataDeleted("False");
				riskObj.setPropRisks_IsOldDataDeleted("False");
				riskObj.setIsOptionalCover("true");
				riskObj.setPropRisks_Relationship("Self");
				//End: RahulT| Hardcoding to generate Accident shield proposal
				//riskObj.setPropRisks_InsuredName(strFullName.toString().toUpperCase());
				riskObj.setPropRisks_InsuredName(insuredDet.getInsuName());
				riskCol.getRisks().add(riskObj);
				//p2Dto.getPropRisks_Col().getRisks().add(riskObj);
			}
			p2Dto.setPropRisks_Col(riskCol);
			
			
			//Setting nominee details
			if(propPAReq.getLstNomDet()!=null && propPAReq.getLstNomDet().size()>0){
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid othGrid=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid();
				
				for(NomineeDetails nomineeDet:propPAReq.getLstNomDet()){
					
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid nomineeGrid=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid();
				nomineeGrid.setName(IPAProductConstants.IPA_NOMINEE_GRID_NAME);
				nomineeGrid.setValue(IPAProductConstants.IPA_NOMINEE_GRID_VALUE);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1 nomineeGrid1=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1();
				nomineeGrid1.setType(IPAProductConstants.IPA_NOMINEE_TYPE);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.InsuredPerson insPerson=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.InsuredPerson();
				insPerson.setName(IPAProductConstants.IPA_NOMINEE_InsuredPerson);
				insPerson.setValue(nomineeDet.getInsuPerson());
				//insPerson.setValue(strFullName.toString().toUpperCase());
				insPerson.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nomineeGrid1.setInsuredPerson(insPerson);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Nominee nominee=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Nominee();
				nominee.setName(IPAProductConstants.IPA_NOMINEE_Nominee);
				nominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nominee.setValue(nomineeDet.getNomName());
				nomineeGrid1.setNominee(nominee);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Age age=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.Age();
				age.setName(IPAProductConstants.IPA_NOMINEE_Age);
				age.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				age.setValue(nomineeDet.getNomAge());
				nomineeGrid1.setAge(age);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.DateofBirth dtBirth=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.DateofBirth();
				dtBirth.setName(IPAProductConstants.IPA_NOMINEE_DateofBirth);
				dtBirth.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				dtBirth.setValue(nomineeDet.getNomDOB());
				nomineeGrid1.setDateofBirth(dtBirth);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.GenderofNominee genderNominee=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.GenderofNominee();
				genderNominee.setName(IPAProductConstants.IPA_NOMINEE_GenderofNominee);
				genderNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				genderNominee.setValue(nomineeDet.getNomGender());
				nomineeGrid1.setGenderofNominee(genderNominee);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineeGuardianwithNominee relationshipNominee=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineeGuardianwithNominee();
				relationshipNominee.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineeGuardianwithNominee);
				relationshipNominee.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				relationshipNominee.setValue(nomineeDet.getNomGaurdRelation()==null?"":nomineeDet.getNomGaurdRelation());
				nomineeGrid1.setRelationshipofNomineeGuardianwithNominee(relationshipNominee);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineewithInsuredPerson relationshipInsured=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.RelationshipofNomineewithInsuredPerson();
				relationshipInsured.setName(IPAProductConstants.IPA_NOMINEE_RelationshipofNomineewithInsuredPerson);
				relationshipInsured.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				relationshipInsured.setValue(nomineeDet.getNomRelation());
				nomineeGrid1.setRelationshipofNomineewithInsuredPerson(relationshipInsured);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.WhethertheNomineeisaminor nomineeMinor=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.WhethertheNomineeisaminor();
				nomineeMinor.setName(IPAProductConstants.IPA_NOMINEE_WhethertheNomineeisaminor);
				nomineeMinor.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				//nomineeMinor.setValue(nomineeDet.getNomMinor());
				if(nomineeDet.getNomMinor().equalsIgnoreCase("true"))
					nomineeMinor.setValue("1");
				else
					nomineeMinor.setValue("0");
				nomineeGrid1.setWhethertheNomineeisaminor(nomineeMinor);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeGuardianName nomineeGuardName=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeGuardianName();
				nomineeGuardName.setName(IPAProductConstants.IPA_NOMINEE_NomineeGuardianName);
				nomineeGuardName.setType(IPAProductConstants.IPA_NOMINEE_FieldType_String);
				nomineeGuardName.setValue(nomineeDet.getNomGaurdian());
				nomineeGrid1.setNomineeGuardianName(nomineeGuardName);
				
				com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeContribution nomineeContri=new com.majesco.dcf.paproduct.jaxb.secureplan.premium.SecureFuturePlanPolicy.OtherDetailsGrid.NomineeDetailsGrid.NomineeDetailsGrid1.NomineeContribution();
				nomineeContri.setName(IPAProductConstants.IPA_NOMINEE_NomineeContribution);
				nomineeContri.setType(IPAProductConstants.IPA_NOMINEE_FieldType_Double);
				nomineeContri.setValue(nomineeDet.getNomContribtn());
				nomineeGrid1.setNomineeContribution(nomineeContri);
				
				nomineeGrid.setNomineeDetailsGrid1(nomineeGrid1);
				othGrid.getNomineeDetailsGrid().add(nomineeGrid);
				}
				
				p2Dto.setOtherDetailsGrid(othGrid);;
				
			}
			
			p2Dto.setPropRisks_Plans("Self"); // Defaulted to Self
			p2Dto.setPropRisks_PaymentType("Annual"); // Defaulted to Annual
			
			//Start: RahulT| Hardcoding to generate Accident shield proposal
			String defaultSysDate1 = new SimpleDateFormat(CommonConstants.UNIQUE_SEQUENCE).format(new java.util.Date());
			Date startDate=new Date();
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy", Locale.US);
			p2Dto.setPropProductDetails_ProductCode("4255");
			p2Dto.setPropSerIntermediaryDetails_SerIntermediaryCode(CommonConstants.BLANK_STRING);
			p2Dto.setPropSerIntermediaryDetails_SerIntermediaryName(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_PolicySchedule_Mandatary("Yes");
			p2Dto.setPropPremiumCalculation_NetPremium("0");	// need to check this default value
			p2Dto.setPropPremiumCalculation_ServiceTax("0");
			p2Dto.setPropPremiumCalculation_TotalPremium("0");
			p2Dto.setPropPremiumCalculation_StampDuty("0");
			p2Dto.setPropMODetails_TertiaryMOName(CommonConstants.BLANK_STRING);
			p2Dto.setPropMODetails_TertiaryMOCode(CommonConstants.BLANK_STRING);
//			p2Dto.setPropIntermediaryDetails_IntermediaryType("Non-DM");	// need to check this default value
			p2Dto.setPropGeneralProposalInformation_Iscovernoteused("False");
			p2Dto.setPropGeneralProposalInformation_ManualCovernoteNo(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_Covernoteissuedate(sdf.format(startDate));
			p2Dto.setPropGeneralProposalInformation_Covernoteissuetime("21:04");
			p2Dto.setPropGeneralProposalInformation_QuoteNumber(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_ManualCovernoteNo(CommonConstants.BLANK_STRING);
			/*p2Dto.setPropGeneralProposalInformation_DisplayOfficeCode("0200");//TODO:need to set this from UI*//*Commented For Issue ID 2527*/
			p2Dto.setPropEndorsementDtls_ISUWCompleted("False");
			/*p2Dto.setPropGeneralProposalInformation_OfficeCode("90900");//TODO:need to set this from UI
			p2Dto.setPropGeneralProposalInformation_BranchOfficeCode("90200");//TODO:need to set this from UI*//*Commented For Issue ID 2527*/
			p2Dto.setPropRisks_NumberOfEMIs(CommonConstants.BLANK_STRING);
			p2Dto.setPropRisks_IsEMIApplicable("False");
			p2Dto.setPropRisks_SellType(CommonConstants.BLANK_STRING);
			p2Dto.setPropGeneralProposalInformation_ProposalDate_Mandatary(sdf.format(startDate));
			//End: RahulT| Hardcoding to generate Accident shield proposal
			
			jaxbXML=jaxbHandler.marshal(p2Dto);
			//System.out.println(jaxbXML);
			
			//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: "+strMethod+ ":: jaxbXML :: "+jaxbXML);
			propValue=getWSDLURL(IPAProductConstants.IPA_SECUREPLAN_SERVICE_WSDL);
			//propValue="http://172.17.203.45:9595/IPAService_SOAPOverHTTP?wsdl";
			URL url = new URL(propValue);
			IPAService_Service stub = new IPAService_Service(url);
			com.unotechsoft.stub.ipaservice.client.QuotationRequest reqQ = new com.unotechsoft.stub.ipaservice.client.QuotationRequest(); 
			/*Getting Authentication Token Starts Here*/
			//String propFileName = "resource.properties";
			String userID="";
			String password="";
			String responseFrom = "";
			/*Properties prop = new Properties();
			InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
			prop.load(inputStream);*/
			userID=propPAReq.getUserID();
			password=propPAReq.getPassword();
			responseFrom=prop.getProperty("ResponseFrom");
			//Start:Vishal<VAPT comments>| code added to set GC token into user object 
			if (propPAReq.getAuthToken()!=null ){
				reqQ.setAuthenticationToken(propPAReq.getAuthToken());
			}
			else{
				AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
				/*Getting Authentication Token Stops Here*/	
				reqQ.setAuthenticationToken(authRes.getResultRes());
			}
			//End:Vishal<VAPT comments>| code added to set GC token into user object
			
			reqQ.setSource(smc_source);
			reqQ.setProductCode("4255");
			reqQ.setModeOfOperation("NEWPOLICY");
			reqQ.setCampaign(smc_campaign);
			reqQ.setMedium(smc_medium);
			reqQ.setCIAName("");
			reqQ.setHashKey("");
			reqQ.setHostAddress("");
			reqQ.setInputXML(jaxbXML);
			reqQ.setIsBankDataRequired(false);
			reqQ.setIsCutomerAddressRequired(false);
			reqQ.setIsFinanciarDataRequired(false);
			reqQ.setIsManufacturerMappingRequired(false);
			reqQ.setIsRTOMappingRequired(false);
			reqQ.setUserId(propPAReq.getUserID());
			reqQ.setUserRole("ADMIN");
			
			com.unotechsoft.stub.ipaservice.client.IPAService port=stub.getSOAPOverHTTP();
			
			/*Client client=ClientProxy.getClient(port);
			PrintWriter writer = new PrintWriter(System.out);
			
			client.getOutInterceptors().add(new CdataWriterInterceptor());
			
			client.getInInterceptors().add(new LoggingInInterceptor(writer));
			
			client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
			//Service Time out code
			HTTPConduit conduit=(HTTPConduit)client.getConduit();
			HTTPClientPolicy clientPolicy=new HTTPClientPolicy();
			clientPolicy.setReceiveTimeout(60000);
			clientPolicy.setConnectionTimeout(30000);
			conduit.setClient(clientPolicy);
			//End:Service Time out code
*/			
			// Code added to save info abt SOAP in DB Start
			SOAPInfo soapInfo = new SOAPInfo();
			soapInfo.setTransactionID(transId);
			soapInfo.setLobService("getQuickQuote");
			soapInfo.setLobtype("42");
			soapInfo.setCreatedBy(propPAReq.getUserID());
			soapInfo.setProducerCode(propPAReq.getProducerCode());
			soapInfo.setSystemIP(propPAReq.getSystemIP());
			soapInfo.setTransactionEvent("GetPremium / IPA-SFP");
			soapInfo.setJsonRequest(objMap.writeValueAsString(propPAReq));
			soapInfo.setProductCode(propPAReq.getProdCode());
			
			
			cxfInInterceptor =new CXFInBoundInterceptor(soapInfo);
			cxfOutInterceptor= new CXFOutInterceptor(soapInfo);
			
			ServiceUtility utility = new ServiceUtility();
			utility.addClientInterceptorDB(port,cxfInInterceptor,cxfOutInterceptor);
						
			com.unotechsoft.stub.ipaservice.client.QuotationResponse response = port.getQuickQuote(reqQ);  // ESB-Webservice
			
			//if(logger.isDebugEnabled())logger.debug("Adding Out Logs to DB");
			dbserv.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
			//if(logger.isDebugEnabled())logger.debug("Adding In Logs to DB");
			dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());				
			
			//Code end for Saving SOAP Data to DB.					

			com.unotechsoft.stub.ipaservice.client.secureplan.result.UWProductServiceResult uwResult=new com.unotechsoft.stub.ipaservice.client.secureplan.result.UWProductServiceResult();
			if(response.getResponseXML()!=null){
			uwResult=(com.unotechsoft.stub.ipaservice.client.secureplan.result.UWProductServiceResult)jaxbHandler.unmarshal(response.getResponseXML(), uwResult);
			}
			if(uwResult!=null && uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().size()>0 && uwResult.getUWOperationResult().get(0)!=null){
				if(uwResult.getUWOperationResult().get(0).getErrorText()!=null && !uwResult.getUWOperationResult().get(0).getErrorText().equals(""))
				{
					propPARes.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR");
					errorRes.setErrorMMessag(uwResult.getUWOperationResult().get(0).getErrorText());
					errorList.add(errorRes);
					propPARes.setResErr(errorList);
					if(cxfInInterceptor!=null){
						cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(propPARes));
						dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());	
					}
					return propPARes;
				}
				else{
					
                    //Start:Added to set proposal response field to be used in AccountService
					
					if(uwResult.getUWOperationResult()!=null && uwResult.getUWOperationResult().get(0)!=null){
						
						/*if(uwResult.getUWOperationResult().get(0).getConfWFHelper()!=null && uwResult.getUWOperationResult().get(0).getConfWFHelper().get(0)!=null){
							propPARes.setProposalSystemId(uwResult.getUWOperationResult().get(0).getConfWFHelper().get(0).getWFSystemID());
						}*/
						
						if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null){
						propPARes.setBusinessLocation(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_OfficeCode());
						propPARes.setDepositOfficeCode(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_OfficeCode());
						propPARes.setBussLocName(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_OfficeName());
						}
						
						//Start:07-Sep-2016:Added UW rules warning text from GC
						if(uwResult != null && uwResult.getUWOperationResult() != null && uwResult.getUWOperationResult().get(0)!=null && uwResult.getUWOperationResult().get(0).getWarningText()!=null)
							propPARes.setRulesWarning(uwResult.getUWOperationResult().get(0).getWarningText());
						//End:07-Sep-2016:Added UW rules warning text from GC	
						
					
					propPARes.setProposalNumber(uwResult.getUWOperationResult().get(0).getProposalNo());
					propPARes.setProposalDate(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralProposalInformation_ProposalDate_Mandatary());
					
					if(uwResult.getUWOperationResult().get(0).getNetPremium()!=null)
						prmdet.setNetPremium(uwResult.getUWOperationResult().get(0).getNetPremium());
					if(uwResult.getUWOperationResult().get(0).getTotalPremium()!=null)
						prmdet.setTotalPremium(uwResult.getUWOperationResult().get(0).getTotalPremium());
					if(uwResult.getUWOperationResult().get(0).getTotalSI()!=null)
						prmdet.setSumInsured(uwResult.getUWOperationResult().get(0).getTotalSI());
					if(uwResult.getUWOperationResult().get(0).getGetUserData()!=null && uwResult.getUWOperationResult().get(0).getGetUserData().get(0)!=null)
						prmdet.setServiceTax(uwResult.getUWOperationResult().get(0).getServiceTax());
					
					}//End:Added to set proposal response field to be used in AccountService
					
					/*Added To Send Application Number To UI*/
					if(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodes_ApplicationNo()!=null)
					{
						propPARes.setApplcationNo(uwResult.getUWOperationResult().get(0).getGetUserData().get(0).getPropGeneralNodes_ApplicationNo());
					}
					else
					{
						propPARes.setApplcationNo("");
					}
					/*Added To Send Application Number To UI*/
				}
			}
			
		}
		
		catch(Exception e)
		{
			propPARes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR");
			errorRes.setErrorMMessag(e.getMessage()+".Transaction ID::"+transId);
			errorList.add(errorRes);
			propPARes.setResErr(errorList);
			e.printStackTrace();
			logger.error("Inside IPAServiceImpl :: "+strMethod+" method :: Exception Occurred : "+e.toString()+".Transaction ID::"+transId);
		}
		
		logger.info("Start::"+transId+" :: IPAServiceImpl :: "+strMethod+" :: Exit :: "+objMap.writeValueAsString(propPARes));
		/*PremiumDetails premDet=new PremiumDetails();
		premDet.setNetPremium("445");
		premDet.setTotalPremium("445");
		premDet.setServiceTax("15");
		propPARes.setPremDet(premDet);*/
		propPARes.setPremDet(prmdet);
		if(cxfInInterceptor!=null){
			cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(propPARes));
			dbserv.saveInSoapInfo(cxfInInterceptor.getInBound());	
		}
		return propPARes;
	}

//	@Override
//	public ArrayList<QuotationPA1> getQuotationDetails(SearchQuoteDetailsRequest searchQuoteDetails)throws Exception {
//		logger.info("Inside IPAServiceImpl :: getQuotationDetails method :: Execution Started");
//		ArrayList<QuotationPA1> quotePA=null;
//		
//		List<String> paramName=new ArrayList<String>();
//		paramName.add("firstName");
//		paramName.add("lastName");
//
//		List<Object> paramValue=new ArrayList<Object>();
//		paramValue.add(searchQuoteDetails.getFirstName());
//		paramValue.add(searchQuoteDetails.getLastName());
//
//
//		quotePA=(ArrayList<QuotationPA1>) dbserv.getQuotationDtlList("com.majesco.dcf.paproduct.entity.QuotationPA1", paramName, paramValue);
//		
//		logger.info("Inside IPAServiceImpl :: getQuotationDetails method :: Execution Completed Successfully");
//		return quotePA;
//	}
	
	@Override
	public QuotationPA getQuotationDetails(QuotationPA quoteDetails)throws Exception {
		logger.info("Inside IPAServiceImpl :: getQuotationDetails method :: Execution Started");
		QuotationPA quotePA=new QuotationPA();
		List<String> paramName=new ArrayList<String>();
		List<Object> paramValue=new ArrayList<Object>();
		
		quotePA=(QuotationPA) dbserv.getList("com.majesco.dcf.paproduct.entity.QuotationPA", paramName, paramValue);
		
		logger.info("Inside IPAServiceImpl :: getQuotationDetails method :: Execution Completed Successfully");
		return null;
	}

	@Override
	public IPAProposalDataResponse getIPAProposalDataAG(
			IPAProposalDataRequest prodPropDataReq) throws Exception {
		
		long transId = System.nanoTime();
		String responseFrom ="";
		UserData_AccidentGuard_ABC respObj = null;
        
        
        ObjectMapper objMapper = new ObjectMapper();
        logger.info("TransactionID:"+transId+" :: Inside IPAServiceImpl :: getProductProposalDataPrvtCar() method :: Execution Started ::"+objMapper.writeValueAsString(prodPropDataReq));        
		//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalDataAG() Request JSONObj :: \n " + objMapper.writeValueAsString(prodPropDataReq)); // To print UI req
		
        
		propValue=getWSDLURL(IPAProductConstants.IPA_ACCIDENTGUARD_SERVICE_WSDL);
		//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl.getIPAProductProposalDataAG() :: propValue: " + propValue);
		List<IPAProposalDataResponse> responseList = new ArrayList<IPAProposalDataResponse>();
		
		IPAProposalDataResponse genQuotRes = new IPAProposalDataResponse();
		List<ResponseError> lstResErr  = new ArrayList<ResponseError>();
		ResponseError reserr = new ResponseError();
		PremiumDetails prmdet = new PremiumDetails();
		String jaxbXML = "";
		Mapper mapper = null;
		List<String> list = new ArrayList<String>();
		InsuredDetails insuredDet= null;
		List<InsuredDetails> lstInsured = new ArrayList<InsuredDetails>();
		String sumAssured = null;
		
		list.add("IPAMapping.xml");
		//Mapper mapper = (Mapper) new DozerBeanMapper(list);
		//DozerService dozer=IPABundleActivator.getDozerService();
		mapper = (Mapper) new DozerBeanMapper(list);
		
		try{			
			
			AccidentGuardPolicyProposalRequest p2Dto = new AccidentGuardPolicyProposalRequest();
			URL url = new URL(propValue);
			
			if(prodPropDataReq.getPolicyNumber() != null && !prodPropDataReq.getPolicyNumber().equalsIgnoreCase("")){
				  // if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProductProposalDataAG :: prodPropDataReq.getPolicyNumber():" + prodPropDataReq.getPolicyNumber());
	     		   this.getGCProposalNo(prodPropDataReq); 
	     	}
			
			if(prodPropDataReq.getQuotaionNumber() != null && !prodPropDataReq.getQuotaionNumber().equalsIgnoreCase("")){
     		   p2Dto.setPropProductDetailsQuotationNumber(prodPropDataReq.getQuotaionNumber());
     	   	}
			
     	    if(prodPropDataReq.getProposalNumber() != null && !prodPropDataReq.getProposalNumber().equalsIgnoreCase("")){
     	    	//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProductProposalDataAG :: prodPropDataReq.getProposalNumber():" + prodPropDataReq.getProposalNumber());
     	    	p2Dto.setPropProductDetailsProposalNumber(prodPropDataReq.getProposalNumber());   
     	    }
     		
     	   jaxbXML=JAXBXMLHandler.marshal(p2Dto);
     	   //if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: getIPAProductProposalDataAG() method :: JAXB XML :: "+jaxbXML);
		
     	   com.unotechsoft.stub.ipaservice.client.QuotationRequest reqQ = new com.unotechsoft.stub.ipaservice.client.QuotationRequest();
     				
     	   /*Getting Authentication Token Starts Here*/
			String propFileName = "resource.properties";
			String userID="";
			String password="";
			Properties prop = new Properties();
			InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
			prop.load(inputStream);
			userID=prodPropDataReq.getUserID();
			password=prodPropDataReq.getPassword();
			responseFrom=prop.getProperty("ResponseFrom");
			//Start:Vishal<VAPT comments>| code added to set GC token into user object 
			if (prodPropDataReq.getAuthToken()!=null ){
				reqQ.setAuthenticationToken(prodPropDataReq.getAuthToken());
			}
			else{
				AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
				/*Getting Authentication Token Stops Here*/	
				reqQ.setAuthenticationToken(authRes.getResultRes());
			}
			//End:Vishal<VAPT comments>| code added to set GC token into user object
			
			reqQ.setSource(smc_source);
			reqQ.setProductCode("4251");
			
			if (prodPropDataReq.getIsRenew()!=null && prodPropDataReq.getIsRenew().equalsIgnoreCase("True")) {
					reqQ.setModeOfOperation("RENEWPOLICY");
			} else {
					reqQ.setModeOfOperation("NEWPOLICY");
			}
			
			reqQ.setMedium(smc_medium);
			reqQ.setCampaign(smc_campaign);
			reqQ.setCIAName("");
			reqQ.setHashKey("");
			reqQ.setHostAddress("");
			reqQ.setInputXML(jaxbXML);
			reqQ.setIsBankDataRequired(false);
			reqQ.setIsCutomerAddressRequired(false);
			reqQ.setIsFinanciarDataRequired(false);
			reqQ.setIsManufacturerMappingRequired(false);
			reqQ.setIsRTOMappingRequired(false);
			reqQ.setUserRole("ADMIN");
			reqQ.setUserId(prodPropDataReq.getUserID());
			
			//if(logger.isDebugEnabled())logger.debug("TransactionID: " + transId + " :: IPAServiceImpl :: After CDATA Injection :: \n " + reqQ.getInputXML()); // To print InputXML()
			
			responseFrom=prop.getProperty("ResponseFrom");
			
			com.unotechsoft.stub.ipaservice.client.IPAService_Service stub = new com.unotechsoft.stub.ipaservice.client.IPAService_Service(url);
			com.unotechsoft.stub.ipaservice.client.IPAService port = stub.getSOAPOverHTTP();
			
			ServiceUtility utility=new ServiceUtility();
			utility.addClientInterceptor(port);
			
			com.unotechsoft.stub.ipaservice.client.QuotationResponse response = port.getProductProposalData(reqQ);
			//START:13/10/2017:Fix for defect 2319.Done by SAILESH
			if (prodPropDataReq.getProposalNumber() != null && !prodPropDataReq.getProposalNumber().equalsIgnoreCase("")) 
	        {
	        	try{
			       ProposalStatusReq proposalStatusReq = new ProposalStatusReq();
			       proposalStatusReq.setProposalNo(prodPropDataReq.getProposalNumber());			      
                   proposalStatusReq.setAuthToken(prodPropDataReq.getAuthToken());
                   proposalStatusReq.setProducerCode(prodPropDataReq.getProducerCode());
                   proposalStatusReq.setProductCode(prodPropDataReq.getProductCode());
                   proposalStatusReq.setUserID(userID);
			       ProposalStatus proposalStatus = new ProposalStatus();
			       proposalStatus = commonService.getProposalStatus(proposalStatusReq);
			       //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalDataAG() method :: ProposalStatus: " + proposalStatus.getProposalStatus() + " :: ProposalStatusDesc : " + proposalStatus.getProposalStatusDesc());
			        if (proposalStatus.getProposalStatus()!=null) 
			        {
			        	genQuotRes.setProposalStatus(proposalStatus.getProposalStatus());
			        }
			        if (proposalStatus.getProposalStatusDesc()!=null) 
			        {
			        	genQuotRes.setProposalStatusDesc(proposalStatus.getProposalStatusDesc());
			        }
	        	}
	        	catch(Exception e){
	        		e.printStackTrace();
	        	}
	        }
			//END   
			//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalAG() :: getResponseXML :: " + response.getResponseXML()); //To print response XML
			
			UserData_AccidentGuard_ABC result = new UserData_AccidentGuard_ABC();
			com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid resultOtherDetGrid = new com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid();
			String responseXML = response.getResponseXML();
			String responseXMLOtherDetGrid=response.getOtherDetailsGridXML();
			
			//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalAG() :: getresponseXMLOtherDetGrid :: " +responseXMLOtherDetGrid); //To print responseXMLOtherDetGrid
			com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid respObjOtherDetGrid = null;
			
			
			
			if(responseFrom!=null && responseFrom.equalsIgnoreCase("MajescoQC")){
				respObj = (UserData_AccidentGuard_ABC) JAXBXMLHandler.unmarshalTest(new File("D:\\AGIPA_search_response.xml"),result);
				respObjOtherDetGrid = (com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid) JAXBXMLHandler.unmarshalTest(new File("D:\\AGIPA_search_response1.xml"),resultOtherDetGrid);
			}
			else if(responseFrom!=null && responseFrom.equalsIgnoreCase("TataAIG"))
			{	
				respObj = (UserData_AccidentGuard_ABC) JAXBXMLHandler.unmarshal(responseXML,result);
				respObjOtherDetGrid = (com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid)JAXBXMLHandler.unmarshal(responseXMLOtherDetGrid,resultOtherDetGrid);
			}
						
			
			mapper.map(respObj,genQuotRes,"IPAGetProductProposalAG");
			
			// Code added for Otherdetails grid integration by Vishal:: 10/02/2017 :: Start
			if(respObjOtherDetGrid!=null && respObjOtherDetGrid.getNomineeDetailsGrid()!=null ){
				NomineeDetails nomDet = null;
				List<NomineeDetails> nomDetList = new ArrayList<NomineeDetails>();
				
				List<com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid.NomineeDetailsGrid> detailsListGrid1 = respObjOtherDetGrid
						.getNomineeDetailsGrid();
				//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalAG() :: Before For Loop OtherDetailGridlist :: "); //To print responseXMLOtherDetGrid
				for (com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid.NomineeDetailsGrid detailsGrid1 : detailsListGrid1) {
					nomDet = new NomineeDetails();
					//logger.info("IPAServiceImpl :: getIPAProposalAG() :: inside For OtherDetailGridlist :: "); //To print responseXMLOtherDetGrid
					if (detailsGrid1 != null && detailsGrid1.getNomineeDetailsGrid1()!=null) {
						if (detailsGrid1.getNomineeDetailsGrid1().getInsuredPerson() != null && !detailsGrid1.getNomineeDetailsGrid1().getInsuredPerson().equals(""))
							nomDet.setInsuPerson(detailsGrid1.getNomineeDetailsGrid1().getInsuredPerson()
									.getValue());

						if (detailsGrid1.getNomineeDetailsGrid1().getNominee() != null )
							nomDet.setNomName(detailsGrid1.getNomineeDetailsGrid1().getNominee().getValue());

						if (detailsGrid1.getNomineeDetailsGrid1().getDateofBirth() != null)
							nomDet.setNomDOB(detailsGrid1.getNomineeDetailsGrid1().getDateofBirth()
									.getValue());

						if (detailsGrid1.getNomineeDetailsGrid1().getAge() != null)
							nomDet.setNomAge(detailsGrid1.getNomineeDetailsGrid1().getAge().getValue());

						if (detailsGrid1.getNomineeDetailsGrid1().getGenderofNominee() != null)
							nomDet.setNomGender(detailsGrid1.getNomineeDetailsGrid1().getGenderofNominee()
									.getValue());

						if (detailsGrid1
								.getNomineeDetailsGrid1().getRelationshipofNomineewithInsuredPerson() != null)
							nomDet.setNomRelation(detailsGrid1
									.getNomineeDetailsGrid1().getRelationshipofNomineewithInsuredPerson()
									.getValue());

						if (detailsGrid1.getNomineeDetailsGrid1().getWhethertheNomineeisaminor() != null)
							nomDet.setNomMinor(detailsGrid1
									.getNomineeDetailsGrid1().getWhethertheNomineeisaminor().getValue());

						if (detailsGrid1.getNomineeDetailsGrid1().getNomineeGuardianName() != null)
							nomDet.setNomGaurdian(detailsGrid1
									.getNomineeDetailsGrid1().getNomineeGuardianName().getValue());

						if (detailsGrid1
								.getNomineeDetailsGrid1().getRelationshipofNomineeGuardianwithNominee() != null)
							nomDet.setNomGaurdRelation(detailsGrid1
									.getNomineeDetailsGrid1().getRelationshipofNomineeGuardianwithNominee()
									.getValue());

						if (detailsGrid1.getNomineeDetailsGrid1().getNomineeContribution() != null)
							nomDet.setNomContribtn(detailsGrid1
									.getNomineeDetailsGrid1().getNomineeContribution().getValue());

					}

					nomDetList.add(nomDet);
				}
				//logger.info("IPAServiceImpl :: getIPAProposalAG() :: Assigning to json response for NomineeDetails"); //To print responseXMLOtherDetGrid
				genQuotRes.setLstNomDet(nomDetList);
			}
			// Code added for Otherdetails grid integration by Vishal:: 10/02/2017 :: End
			genQuotRes.setProdCode("4251");
			
						
			if (respObj.getPropRisks_Col() !=null && respObj.getPropRisks_Col().getRisks()!=null){
				UserData_AccidentGuard_ABC.PropRisks_Col.Risks riskObj = respObj.getPropRisks_Col().getRisks();
				insuredDet=new InsuredDetails();
				mapper.map(riskObj, insuredDet, "IPAInsuredProductProposalAG");
				mapToInternalCode(insuredDet);
				sumAssured = riskObj.getPropRisks_BaseSumInsured()+"";
				
				lstInsured.add(insuredDet);
				//p2Dto.getPropRisks_Col().getRisks().add(riskObj);
			}
			genQuotRes.setLstInsurDet(lstInsured);
			
			// Setting ID type in IPA Proposal response
			if (genQuotRes!= null && genQuotRes.getProposerDet()!= null
					&& respObj.getPropRisks_Col() !=null && respObj.getPropRisks_Col().getRisks()!=null){
				IdDetails idDetail = new IdDetails();
				idDetail.setIdNumber(respObj.getPropRisks_Col().getRisks().getPropRisks_IdentityProofNumber());
				idDetail.setIdType(dbserv.getReverseExternalMapCode(null, respObj.getPropRisks_Col().getRisks().getPropRisks_IdentityProofType(), CommonConstants.IDTYPE_SYSTEM_PARAMCD));
				genQuotRes.getProposerDet().setIdList(idDetail);
				
				if (genQuotRes.getLstcvrgDet()!= null){
					genQuotRes.getLstcvrgDet().setOccuptnClassOfSelf(dbserv.getReverseExternalMapCode
						(null, respObj.getPropRisks_Col().getRisks().getPropRisks_Occupation(), CommonConstants.OCCUPATION_SYSTEM_PARAMCD));
					genQuotRes.getLstcvrgDet().setCoreSumInsured(sumAssured);
				}
				
				
			}
			
			//logger.info("getProductProposalDataPrvtCar :: Maped ProductPropRes :: " + prodPropDataResp.toString());
			
			//Start : 17/03/2017  : To send productName to JSON response
			 String strval="";
             
             List<Product> oComProductList =  (List<Product>) dbserv.getProduct("com.majesco.dcf.common.tagic.entity.Product","strprodcd",prodPropDataReq.getProductCode());
             if(oComProductList.size()>0){
             	for(Product productList:oComProductList){	                            		                                  
                       strval = productList.getStrprodname()!=null?productList.getStrprodname().toString():"";                       
                 }	
             }	                              
             //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getProductProposalData TW :: Fetching Product Name To Go In Response"+strval);
             genQuotRes.setProductName(strval);	
			//End : 17/03/2017  : To send productName to JSON response			
           //Start:07/03/2017:To search customer details by customer id and populate full customer details data from GC
             if(genQuotRes.getCustCode()!=null && !genQuotRes.getCustCode().equals(CommonConstants.BLANK_STRING)){
             	CustomerDetailRequest customerDetailRequest=new CustomerDetailRequest();
             	customerDetailRequest.setAuthToken(reqQ.getAuthenticationToken());
             	customerDetailRequest.setCustomerID(genQuotRes.getCustCode());
             	//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getProductProposalDataComm :: Fetching Customer Details"+genQuotRes.getCustCode());
             	CustomerDetailResponse customerDetailResponse=customerService.getCustomerDetails(customerDetailRequest);
             	
             	if(customerDetailResponse!=null && customerDetailResponse.getCustDetails()!=null && customerDetailResponse.getCustDetails().size()>0){
             		genQuotRes.setProposerDet(customerDetailResponse.getCustDetails().get(0));
             	}
             }
           //End:07/03/2017:To search customer details by customer id and populate full customer details data from GC
           //Start : 13-Apr-2017 : To fetch workflowId from Channel Portal DB
             String workFlowId = "";
             workFlowId = dbserv.getWorkFlowIdFromProposalNo(prodPropDataReq.getProposalNumber());
             if(workFlowId != null && !workFlowId.equalsIgnoreCase(CommonConstants.BLANK_STRING)){
            	 genQuotRes.setProposalSystemId(workFlowId);
             }	                           	                            
             //End : 13-Apr-2017 : To fetch workflowId from Channel Portal DB
             //Start : 26-Apr-2017 : To Send key for OccupationClassof Self 
             if(genQuotRes.getLstcvrgDet().getOccuptnClassOfSelf()!=null && ! genQuotRes.getLstcvrgDet().getOccuptnClassOfSelf().equalsIgnoreCase(CommonConstants.BLANK_STRING))
            	 genQuotRes.getLstcvrgDet().setOccuptnClassOfSelf(dbserv.getReverseExternalMapCode(null, CommonConstants.OCCUPATONCLASSOFSELF_SYSTEM_PARAMCD , genQuotRes.getLstcvrgDet().getOccuptnClassOfSelf()));                         
             //End : 26-Apr-2017 : To Send key for OccupationClassof Self
             
             // Start : 04-May-207 :Code added to send premium details to UI
             	Double totPrem=0.0; 
             	prmdet = new PremiumDetails();
				if(respObj.getPropPremiumCalculation_NetPremium()!=null)
					prmdet.setNetPremium(respObj.getPropPremiumCalculation_NetPremium());
				if(respObj.getPropPremiumCalculation_TotalPremium()!=null)
					prmdet.setTotalPremium(respObj.getPropPremiumCalculation_TotalPremium());
				if(respObj.getPropGeneralProposalInformation_TotalSi()!=null)
					prmdet.setSumInsured(respObj.getPropGeneralProposalInformation_TotalSi());
				if(respObj.getPropPremiumCalculation_ServiceTax()!=null)
					prmdet.setServiceTax(respObj.getPropPremiumCalculation_ServiceTax());										
				if(respObj.getPropPremiumCalculation_TotalPremium()!=null)
					totPrem = Double.parseDouble(respObj.getPropPremiumCalculation_TotalPremium());
					
				prmdet.setPremiumPayable(""+totPrem);
				
				//genquotres.setPrmdet(prmdet);
				genQuotRes.setPremDet(prmdet);
			// End : 04-May-207 :Code added to send premium details to UI	
				
             
             
			 ObjectMapper objMap=new ObjectMapper();
             
                //START:Code changes for defect 2443.
				genQuotRes.setBranchOfficeCode(respObj.getPropGeneralProposalInformation_BranchOfficeCode());
				genQuotRes.setDisplayOfficeCode(respObj.getPropGeneralProposalInformation_DisplayOfficeCode());
				genQuotRes.setOfficeName(respObj.getPropGeneralProposalInformation_OfficeName());
				genQuotRes.setProposalNumber(prodPropDataReq.getProposalNumber());
				genQuotRes.setProposalSystemId(workFlowId);
				//genQuotRes.setOccupation(occupation);
				//END code changes for defect 493.
				
			//END
             //return genQuotRes;   // For 1908 :  VishalJ : return statement is Commented.
				
				//04-July-2018 :Code added to setResultCode 1 to UI
	     		if(genQuotRes!=null){
	     		genQuotRes.setResultCode("1");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError errorRes=new ResponseError();
				errorRes.setErrorCode("NOERR");
				errorRes.setErrorMMessag("NO ERROR");
				errorList.add(errorRes);
				genQuotRes.setResErr(errorList);
				
				logger.info("TransactionID:"+transId+" :: Inside IPAServiceImpl :: getIPAProductProposalDataAG :: Response Sent to UI JSON Object :: "+objMap.writeValueAsString(genQuotRes));  //  1908 : VishalJ :  Printing Response JSon in GetProductProposalData
	     		}
		}
	
		catch(Exception e)
		{
			//genQuotRes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR");
			errorRes.setErrorMMessag(e.getMessage()+".Transaction ID::"+transId);
			errorList.add(errorRes);
			genQuotRes.setResErr(errorList);
			e.printStackTrace();
			logger.error("Inside IPAServiceImpl :: getIPAProposalAG method :: Exception Occurred : "+e.toString()+".Transaction ID::"+transId);
		}
		 
	return genQuotRes;
	}
	
	//Start: RahulT | added to get policy/proposal details For Accident Shield
	@Override
	public IPAProposalDataResponse getIPAProposalDataAS(
			IPAProposalDataRequest prodPropDataReq) throws Exception {
		
		long transId = System.nanoTime();
		String responseFrom ="";
		UserDataAccidentShieldABC respObj = null;
        
        
        ObjectMapper objMapper = new ObjectMapper();
        logger.info("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getIPAProposalDataAS() method :: Execution Started"+objMapper.writeValueAsString(prodPropDataReq));		
		
        
		propValue=getWSDLURL(IPAProductConstants.IPA_ACCIDENTSHIELD_SERVICE_WSDL);
		//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl.getIPAProposalDataAS() :: propValue: " + propValue);
		List<IPAProposalDataResponse> responseList = new ArrayList<IPAProposalDataResponse>();
		
		IPAProposalDataResponse genQuotRes = new IPAProposalDataResponse();
		List<ResponseError> lstResErr  = new ArrayList<ResponseError>();
		ResponseError reserr = new ResponseError();
		PremiumDetails prmdet = new PremiumDetails();
		String jaxbXML = "";
		Mapper mapper = null;
		List<String> list = new ArrayList<String>();
		InsuredDetails insuredDet= null;
		List<InsuredDetails> lstInsured = new ArrayList<InsuredDetails>();
		
		list.add("IPAMapping.xml");
		mapper = (Mapper) new DozerBeanMapper(list);
		String sumAssured = null;
		
		try{		
			
			
			URL url = new URL(propValue);
			
			AccidentShieldInsuranceProposalRequest p2Dto = new AccidentShieldInsuranceProposalRequest();
			
			if(prodPropDataReq.getPolicyNumber() != null && !prodPropDataReq.getPolicyNumber().equalsIgnoreCase("")){
				//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalDataAS :: prodPropDataReq.getPolicyNumber():" + prodPropDataReq.getPolicyNumber());
	     		   this.getGCProposalNo(prodPropDataReq); 
	     	}
			
			if(prodPropDataReq.getQuotaionNumber() != null && !prodPropDataReq.getQuotaionNumber().equalsIgnoreCase("")){
	     		   p2Dto.setPropProductDetailsQuotationNumber(prodPropDataReq.getQuotaionNumber());
	     	}
			
     	   if(prodPropDataReq.getProposalNumber() != null && !prodPropDataReq.getProposalNumber().equalsIgnoreCase("")){
     		  //if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalDataAS :: prodPropDataReq.getProposalNumber():" + prodPropDataReq.getProposalNumber());
     		   p2Dto.setPropProductDetailsProposalNumber(prodPropDataReq.getProposalNumber());   
     	   }
     		   
     	   jaxbXML=JAXBXMLHandler.marshal(p2Dto);
     	  //if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: getIPAProposalDataAS() method :: JAXB XML :: "+jaxbXML);
			   
		
     	   	com.unotechsoft.stub.ipaservice.client.QuotationRequest reqQ = new com.unotechsoft.stub.ipaservice.client.QuotationRequest();
     				
     	   /*Getting Authentication Token Starts Here*/
			String propFileName = "resource.properties";
			String userID="";
			String password="";
			Properties prop = new Properties();
			InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
			prop.load(inputStream);
			userID=prodPropDataReq.getUserID();
			password=prodPropDataReq.getPassword();
			responseFrom=prop.getProperty("ResponseFrom");
			
			//Start:Vishal<VAPT comments>| code added to set GC token into user object 
			if (prodPropDataReq.getAuthToken()!=null ){
				reqQ.setAuthenticationToken(prodPropDataReq.getAuthToken());
			}
			else{
				AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
				/*Getting Authentication Token Stops Here*/	
				reqQ.setAuthenticationToken(authRes.getResultRes());
			}
			//End:Vishal<VAPT comments>| code added to set GC token into user object
			
			reqQ.setSource(smc_source);
			reqQ.setProductCode("4254");
			
			if (prodPropDataReq.getIsRenew()!=null && prodPropDataReq.getIsRenew().equalsIgnoreCase("True")) {
					reqQ.setModeOfOperation("RENEWPOLICY");
				 } else {
					reqQ.setModeOfOperation("NEWPOLICY");
				 }
			
			reqQ.setMedium(smc_medium);
			reqQ.setCampaign(smc_campaign);
			reqQ.setCIAName("");
			reqQ.setHashKey("");
			reqQ.setHostAddress("");
			reqQ.setInputXML(jaxbXML);
			reqQ.setIsBankDataRequired(false);
			reqQ.setIsCutomerAddressRequired(false);
			reqQ.setIsFinanciarDataRequired(false);
			reqQ.setIsManufacturerMappingRequired(false);
			reqQ.setIsRTOMappingRequired(false);
			reqQ.setUserRole("ADMIN");
			reqQ.setUserId(prodPropDataReq.getUserID());
			
			//if(logger.isDebugEnabled())logger.debug("TransactionID: " + transId + " :: IPAServiceImpl :: After CDATA Injection :: \n " + reqQ.getInputXML()); // To print InputXML()
			
			responseFrom=prop.getProperty("ResponseFrom");
			com.unotechsoft.stub.ipaservice.client.IPAService_Service stub = new com.unotechsoft.stub.ipaservice.client.IPAService_Service(url);
			//unotechsoft.stub.ipaservice.client.IPAService port=stub.getSOAPOverHTTP();
			com.unotechsoft.stub.ipaservice.client.IPAService port=stub.getSOAPOverHTTP();
			
			ServiceUtility utility=new ServiceUtility();
			utility.addClientInterceptor(port);
			
			com.unotechsoft.stub.ipaservice.client.QuotationResponse response = port.getProductProposalData(reqQ);
			//START:13/10/2017:Fixes done for defect 2319 by SAILESH.
			 if (prodPropDataReq.getProposalNumber() != null && !prodPropDataReq.getProposalNumber().equalsIgnoreCase("")) 
		        {
		        	try{
				       ProposalStatusReq proposalStatusReq = new ProposalStatusReq();
				       proposalStatusReq.setProposalNo(prodPropDataReq.getProposalNumber());
	                   proposalStatusReq.setAuthToken(prodPropDataReq.getAuthToken());
	                   proposalStatusReq.setProducerCode(prodPropDataReq.getProducerCode());
	                   proposalStatusReq.setProductCode(prodPropDataReq.getProductCode());
	                   proposalStatusReq.setUserID(userID);
				       ProposalStatus proposalStatus = new ProposalStatus();
				       proposalStatus = commonService.getProposalStatus(proposalStatusReq);
				       
				       //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalSFP() method :: ProposalStatus: " + proposalStatus.getProposalStatus() + " :: ProposalStatusDesc : " + proposalStatus.getProposalStatusDesc());
				       
				        if (proposalStatus.getProposalStatus()!=null) 
				        {
				        	genQuotRes.setProposalStatus(proposalStatus.getProposalStatus());
				        }
				        if (proposalStatus.getProposalStatusDesc()!=null) 
				        {
				        	genQuotRes.setProposalStatusDesc(proposalStatus.getProposalStatusDesc());
				        }
		        	}
		        	catch(Exception e){
		        		e.printStackTrace();
		        	}
		        }
			 //END
			
			//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalDataAS() :: getResponseXML :: " + response.getResponseXML()); //To print response XML
			
			UserDataAccidentShieldABC result = new UserDataAccidentShieldABC();
			com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid resultOtherDetGrid = new com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid();
			
			String responseXML = response.getResponseXML();
			String responseXMLOtherDetGrid=response.getOtherDetailsGridXML();
			//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalDataAS() :: responseXMLOtherDetGrid :: " + responseXMLOtherDetGrid); //To print response XML
			
			com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid respObjOtherDetGrid = null;
			
			if(responseFrom!=null && responseFrom.equalsIgnoreCase("MajescoQC")){
				respObj = (UserDataAccidentShieldABC) JAXBXMLHandler.unmarshalTest(new File("D:\\AGIPA_search_response.xml"),result);
				respObjOtherDetGrid = (com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid) JAXBXMLHandler.unmarshalTest(new File("D:\\AGIPA_search_response1.xml"),resultOtherDetGrid);
			}
			else if(responseFrom!=null && responseFrom.equalsIgnoreCase("TataAIG"))
			{	
				respObj = (UserDataAccidentShieldABC) JAXBXMLHandler.unmarshal(responseXML,result);
				respObjOtherDetGrid = (com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid) JAXBXMLHandler.unmarshal(responseXMLOtherDetGrid,resultOtherDetGrid);
			}
			
			mapper.map(respObj,genQuotRes,"IPAGetProductProposalAS");
			
			
			// Code added for Otherdetails grid integration for AccidentalShield by Vishal:: 10/02/2017 :: Start
						if(respObjOtherDetGrid!=null && respObjOtherDetGrid.getNomineeDetailsGrid()!=null && respObjOtherDetGrid.getNomineeDetailsGrid()!=null){
							NomineeDetails nomDet = null;
							List<NomineeDetails> nomDetList = new ArrayList<NomineeDetails>();
							
							List<com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid.NomineeDetailsGrid> detailsListGrid1 = respObjOtherDetGrid
									.getNomineeDetailsGrid();
							logger.info("IPAServiceImpl :: getIPAProposalDataAS() :: Before For Loop OtherDetailGridlist :: "); //To print responseXMLOtherDetGrid
							for (com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid.NomineeDetailsGrid detailsGrid1 : detailsListGrid1) {
								nomDet = new NomineeDetails();
								//logger.info("IPAServiceImpl :: getIPAProposalDataAS() :: inside For OtherDetailGridlist :: "); //To print responseXMLOtherDetGrid
								if (detailsGrid1 != null && detailsGrid1.getNomineeDetailsGrid1()!=null) {
									if (detailsGrid1.getNomineeDetailsGrid1().getInsuredPerson() != null)
										nomDet.setInsuPerson(detailsGrid1.getNomineeDetailsGrid1().getInsuredPerson()
												.getValue());

									if (detailsGrid1.getNomineeDetailsGrid1().getNominee() != null)
										nomDet.setNomName(detailsGrid1.getNomineeDetailsGrid1().getNominee().getValue());

									if (detailsGrid1.getNomineeDetailsGrid1().getDateofBirth() != null)
										nomDet.setNomDOB(detailsGrid1.getNomineeDetailsGrid1().getDateofBirth()
												.getValue());

									if (detailsGrid1.getNomineeDetailsGrid1().getAge() != null)
										nomDet.setNomAge(detailsGrid1.getNomineeDetailsGrid1().getAge().getValue());

									if (detailsGrid1.getNomineeDetailsGrid1().getGenderofNominee() != null)
										nomDet.setNomGender(detailsGrid1.getNomineeDetailsGrid1().getGenderofNominee()
												.getValue());

									if (detailsGrid1
											.getNomineeDetailsGrid1().getRelationshipofNomineewithInsuredPerson() != null)
										nomDet.setNomRelation(detailsGrid1
												.getNomineeDetailsGrid1().getRelationshipofNomineewithInsuredPerson()
												.getValue());

									if (detailsGrid1.getNomineeDetailsGrid1().getWhethertheNomineeisaminor() != null)
										nomDet.setNomMinor(detailsGrid1
												.getNomineeDetailsGrid1().getWhethertheNomineeisaminor().getValue());

									if (detailsGrid1.getNomineeDetailsGrid1().getNomineeGuardianName() != null)
										nomDet.setNomGaurdian(detailsGrid1
												.getNomineeDetailsGrid1().getNomineeGuardianName().getValue());

									if (detailsGrid1
											.getNomineeDetailsGrid1().getRelationshipofNomineeGuardianwithNominee() != null)
										nomDet.setNomGaurdRelation(detailsGrid1
												.getNomineeDetailsGrid1().getRelationshipofNomineeGuardianwithNominee()
												.getValue());

									if (detailsGrid1.getNomineeDetailsGrid1().getNomineeContribution() != null)
										nomDet.setNomContribtn(detailsGrid1
												.getNomineeDetailsGrid1().getNomineeContribution().getValue());

								}

								nomDetList.add(nomDet);
							}
							//logger.info("IPAServiceImpl :: getIPAProposalDataAS() :: Assigning to json response for NomineeDetails"); //To print responseXMLOtherDetGrid
							genQuotRes.setLstNomDet(nomDetList);
						}
						// Code added for Otherdetails grid integration For AccidentalShield by Vishal:: 10/02/2017 :: End
			
			
			
			genQuotRes.setProdCode("4254");
			
						
			if (respObj.getPropRisksCol() !=null && respObj.getPropRisksCol().getRisks()!=null){
				UserDataAccidentShieldABC.PropRisksCol.Risks riskObj = respObj.getPropRisksCol().getRisks();
				insuredDet=new InsuredDetails();
				mapper.map(riskObj, insuredDet, "IPAInsuredProductProposalAS");
				
				mapToInternalCode(insuredDet);
				sumAssured = riskObj.getPropRisksSumInsured();
				lstInsured.add(insuredDet);
				//p2Dto.getPropRisks_Col().getRisks().add(riskObj);
				
			}
			genQuotRes.setLstInsurDet(lstInsured);
			
			// Setting ID type in IPA Proposal response
			if (genQuotRes!= null && genQuotRes.getProposerDet()!= null
					&& respObj.getPropRisksCol() !=null && respObj.getPropRisksCol().getRisks()!=null){
				IdDetails idDetail = new IdDetails();
				idDetail.setIdNumber(respObj.getPropRisksCol().getRisks().getPropRisksIdentityProofNumber());
				idDetail.setIdType(dbserv.getReverseExternalMapCode(null, respObj.getPropRisksCol().getRisks().getPropRisksIdentityProofType(), CommonConstants.IDTYPE_SYSTEM_PARAMCD));
				genQuotRes.getProposerDet().setIdList(idDetail);
				
				if (genQuotRes.getLstcvrgDet()!= null){
					genQuotRes.getLstcvrgDet().setOccuptnClassOfSelf(dbserv.getReverseExternalMapCode
						(null, respObj.getPropRisksCol().getRisks().getPropRisksOccupation(), CommonConstants.OCCUPATION_SYSTEM_PARAMCD));
					genQuotRes.getLstcvrgDet().setCoreSumInsured(sumAssured);
				}		
			}			
			
			//logger.info("getProductProposalDataPrvtCar :: Maped ProductPropRes :: " + prodPropDataResp.toString());
			//logger.info("getProductProposalDataPrvtCar :: maped ProductPropRes JSONObj :: \n " + objMapper.writeValueAsString(genQuotRes));
			//Start : 17/03/2017  : To send productName to JSON response
			 String strval="";
            //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getProductProposalData TW :: Checking For Product Name");
            List<Product> oComProductList =  (List<Product>) dbserv.getProduct("com.majesco.dcf.common.tagic.entity.Product","strprodcd",prodPropDataReq.getProductCode());
            if(oComProductList.size()>0){
            	for(Product productList:oComProductList){	                            		                                  
                      strval = productList.getStrprodname()!=null?productList.getStrprodname().toString():"";                     
                }	
            }	                              
            //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getProductProposalData TW :: Fetching Product Name To Go In Response"+strval);
            genQuotRes.setProductName(strval);	
			//End : 17/03/2017  : To send productName to JSON response	
            //Start:07/03/2017:To search customer details by customer id and populate full customer details data from GC
            if(genQuotRes.getCustCode()!=null && !genQuotRes.getCustCode().equals(CommonConstants.BLANK_STRING)){
            	CustomerDetailRequest customerDetailRequest=new CustomerDetailRequest();
            	customerDetailRequest.setAuthToken(reqQ.getAuthenticationToken());
            	customerDetailRequest.setCustomerID(genQuotRes.getCustCode());
            	//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getProductProposalDataComm :: Fetching Customer Details"+genQuotRes.getCustCode());
            	CustomerDetailResponse customerDetailResponse=customerService.getCustomerDetails(customerDetailRequest);
            	
            	if(customerDetailResponse!=null && customerDetailResponse.getCustDetails()!=null && customerDetailResponse.getCustDetails().size()>0){
            		genQuotRes.setProposerDet(customerDetailResponse.getCustDetails().get(0));
            	}
            }
          //End:07/03/2017:To search customer details by customer id and populate full customer details data from GC
          //Start : 13-Apr-2017 : To fetch workflowId from Channel Portal DB
            String workFlowId = "";
            workFlowId = dbserv.getWorkFlowIdFromProposalNo(prodPropDataReq.getProposalNumber());
            if(workFlowId != null && !workFlowId.equalsIgnoreCase(CommonConstants.BLANK_STRING)){
           	 genQuotRes.setProposalSystemId(workFlowId);
            }	                           	                            
            //End : 13-Apr-2017 : To fetch workflowId from Channel Portal DB
            // Start : 04-May-207 :Code added to send premium details to UI
         	Double totPrem=0.0; 
         	prmdet = new PremiumDetails();
			if(respObj.getPropPremiumCalculationNetPremium()!=null)
				prmdet.setNetPremium(respObj.getPropPremiumCalculationNetPremium());
			if(respObj.getPropPremiumCalculationTotalPremium()!=null)
				prmdet.setTotalPremium(respObj.getPropPremiumCalculationTotalPremium());
			if(respObj.getPropGeneralProposalInformationTotalSi()!=null)
				prmdet.setSumInsured(respObj.getPropGeneralProposalInformationTotalSi());
			if(respObj.getPropPremiumCalculationServiceTax()!=null)
				prmdet.setServiceTax(respObj.getPropPremiumCalculationServiceTax());										
			if(respObj.getPropPremiumCalculationTotalPremium()!=null)
				totPrem = Double.parseDouble(respObj.getPropPremiumCalculationTotalPremium());
				
			prmdet.setPremiumPayable(""+totPrem);
			
			//genquotres.setPrmdet(prmdet);
			genQuotRes.setPremDet(prmdet);
		// End : 04-May-207 :Code added to send premium details to UI	
             
           //START:Code changes for defect 2443.
     	    genQuotRes.setBranchOfficeCode(respObj.getPropGeneralProposalInformationBranchOfficeCode());
     		genQuotRes.setOfficeCode(respObj.getPropGeneralProposalInformationOfficeCode());
     		genQuotRes.setOfficeName(respObj.getPropGeneralProposalInformationOfficeName());
     		genQuotRes.setProposalNumber(prodPropDataReq.getProposalNumber());
     		//genQuotRes.setOccupation(occupation);
     		 //END:Code change for defect 493
            //return genQuotRes;   // For 1908 :  VishalJ : return statement is Commented.
     		
     		//04-July-2018 :Code added to setResultCode 1 to UI
     		if(genQuotRes!=null){
     		genQuotRes.setResultCode("1");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("NOERR");
			errorRes.setErrorMMessag("NO ERROR");
			errorList.add(errorRes);
			genQuotRes.setResErr(errorList);
			
     		logger.info("TransactionID:"+transId+" :: Inside IPAServiceImpl :: getIPAProductProposalDataAS :: Response Sent to UI JSON Object :: "+objMapper.writeValueAsString(genQuotRes));  // 1908 : Printing AS resposne JSON       		     				
     		}
     		}
	
		catch(Exception e)
		{
			//genQuotRes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR");
			errorRes.setErrorMMessag(e.getMessage()+".Transaction ID::"+transId);
			errorList.add(errorRes);
			genQuotRes.setResErr(errorList);
			e.printStackTrace();
			logger.error("Inside IPAServiceImpl :: getIPAProposalAG method :: Exception Occurred : "+e.toString()+".Transaction ID::"+transId);
		}
		
		//END
	return genQuotRes;
	}
	//End: RahulT | added to get policy/proposal details For Accident Shield
	
	//Start: RahulT | added to get policy/proposal details For Secure Future plan
		@Override
		public IPAProposalDataResponse getIPAProposalDataSFP(
				IPAProposalDataRequest prodPropDataReq) throws Exception {
			
			long transId = System.nanoTime();
			String responseFrom ="";
			UserDataSecuredFuturePlanABC respObj = null;

	        
	        ObjectMapper objMapper = new ObjectMapper();
	        logger.info("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getIPAProposalDataSFP() method :: Execution Started"+ objMapper.writeValueAsString(prodPropDataReq));
			//logger.info("IPAServiceImpl :: getIPAProposalDataSFP() Request JSONObj :: \n " + objMapper.writeValueAsString(prodPropDataReq)); // To print UI req
			
	        
			propValue=getWSDLURL(IPAProductConstants.IPA_SECUREPLAN_SERVICE_WSDL);
			//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl.getIPAProposalDataSFP() :: propValue: " + propValue);
			List<IPAProposalDataResponse> responseList = new ArrayList<IPAProposalDataResponse>();
			
			IPAProposalDataResponse genQuotRes = new IPAProposalDataResponse();
			List<ResponseError> lstResErr  = new ArrayList<ResponseError>();
			ResponseError reserr = new ResponseError();
			PremiumDetails prmdet = new PremiumDetails();
			String jaxbXML = "";
			Mapper mapper = null;
			List<String> list = new ArrayList<String>();
			InsuredDetails insuredDet= null;
			List<InsuredDetails> lstInsured = new ArrayList<InsuredDetails>();
			
			list.add("IPAMapping.xml");
			mapper = (Mapper) new DozerBeanMapper(list);
			String sumAssured = null;
			
			try{			
				
				SecureFuturePlanProposalRequest p2Dto = new SecureFuturePlanProposalRequest();
				
				URL url = new URL(propValue);
				
				if(prodPropDataReq.getPolicyNumber() != null && !prodPropDataReq.getPolicyNumber().equalsIgnoreCase("")){
					//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalDataSFP :: prodPropDataReq.getPolicyNumber():" + prodPropDataReq.getPolicyNumber());
		     		this.getGCProposalNo(prodPropDataReq); 
		     	}
				
				if(prodPropDataReq.getQuotaionNumber() != null && !prodPropDataReq.getQuotaionNumber().equalsIgnoreCase("")){
	     		   p2Dto.setPropProductDetailsQuotationNumber(prodPropDataReq.getQuotaionNumber());
	     	   }
	     	   if(prodPropDataReq.getProposalNumber() != null && !prodPropDataReq.getProposalNumber().equalsIgnoreCase("")){
	     		   //if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalDataSFP :: prodPropDataReq.getProposalNumber():" + prodPropDataReq.getProposalNumber());
	     		   p2Dto.setPropProductDetailsProposalNumber(prodPropDataReq.getProposalNumber());   
	     	   }
	     		   
	     	   jaxbXML=JAXBXMLHandler.marshal(p2Dto);
	     	   //if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: getIPAProposalDataSFP() method :: JAXB XML :: "+jaxbXML);
	     	   com.unotechsoft.stub.ipaservice.client.QuotationRequest reqQ = new com.unotechsoft.stub.ipaservice.client.QuotationRequest();
	     				
	     	   /*Getting Authentication Token Starts Here*/
				String propFileName = "resource.properties";
				String userID="";
				String password="";
				Properties prop = new Properties();
				InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
				prop.load(inputStream);
				userID=prodPropDataReq.getUserID();
				password=prodPropDataReq.getPassword();
				responseFrom=prop.getProperty("ResponseFrom");
				
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				if (prodPropDataReq.getAuthToken()!=null ){
					reqQ.setAuthenticationToken(prodPropDataReq.getAuthToken());
				}
				else{
					AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
					/*Getting Authentication Token Stops Here*/	
					reqQ.setAuthenticationToken(authRes.getResultRes());
				}
				//End:Vishal<VAPT comments>| code added to set GC token into user object
				
				reqQ.setSource(smc_source);
				reqQ.setProductCode("4255");
				
				if (prodPropDataReq.getIsRenew()!=null && prodPropDataReq.getIsRenew().equalsIgnoreCase("True")) {
						reqQ.setModeOfOperation("RENEWPOLICY");
					 } else {
						reqQ.setModeOfOperation("NEWPOLICY");
					 }
				
				reqQ.setMedium(smc_medium);
				reqQ.setCampaign(smc_campaign);
				reqQ.setCIAName("");
				reqQ.setHashKey("");
				reqQ.setHostAddress("");
				reqQ.setInputXML(jaxbXML);
				reqQ.setIsBankDataRequired(false);
				reqQ.setIsCutomerAddressRequired(false);
				reqQ.setIsFinanciarDataRequired(false);
				reqQ.setIsManufacturerMappingRequired(false);
				reqQ.setIsRTOMappingRequired(false);
				reqQ.setUserRole("ADMIN");
				reqQ.setUserId(prodPropDataReq.getUserID());
				
				//if(logger.isDebugEnabled())logger.debug("TransactionID: " + transId + " :: IPAServiceImpl :: After CDATA Injection :: \n " + reqQ.getInputXML()); // To print InputXML()
				
				responseFrom=prop.getProperty("ResponseFrom");
				
				com.unotechsoft.stub.ipaservice.client.IPAService_Service stub = new com.unotechsoft.stub.ipaservice.client.IPAService_Service(url);
				com.unotechsoft.stub.ipaservice.client.IPAService port=stub.getSOAPOverHTTP();
				
				ServiceUtility utility=new ServiceUtility();
				utility.addClientInterceptor(port);
								
				com.unotechsoft.stub.ipaservice.client.QuotationResponse response = port.getProductProposalData(reqQ);
				//START:13-10-2017:Code changes for defect 2319.
				 if (prodPropDataReq.getProposalNumber() != null && !prodPropDataReq.getProposalNumber().equalsIgnoreCase("")) 
			        {
			        	try{
					       ProposalStatusReq proposalStatusReq = new ProposalStatusReq();
					       proposalStatusReq.setProposalNo(prodPropDataReq.getProposalNumber());
		                   proposalStatusReq.setAuthToken(reqQ.getAuthenticationToken());
		                   proposalStatusReq.setProducerCode(prodPropDataReq.getProducerCode());
		                   proposalStatusReq.setProductCode(prodPropDataReq.getProductCode());
		                   proposalStatusReq.setUserID(userID);
		                 //End:TAGIC:20/12/2016:Added for new proposal status search service.
					       ProposalStatus proposalStatus = new ProposalStatus();
					       proposalStatus = commonService.getProposalStatus(proposalStatusReq);
					       
					       //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside IPAServiceImpl :: generateIPAProposalSFP() method :: ProposalStatus: " + proposalStatus.getProposalStatus() + " :: ProposalStatusDesc : " + proposalStatus.getProposalStatusDesc());
					       
					        if (proposalStatus.getProposalStatus()!=null) 
					        {
					        	genQuotRes.setProposalStatus(proposalStatus.getProposalStatus());
					        }
					        if (proposalStatus.getProposalStatusDesc()!=null) 
					        {
					        	genQuotRes.setProposalStatusDesc(proposalStatus.getProposalStatusDesc());
					        }
			        	}
			        	//END
			        	catch(Exception e){
			        		e.printStackTrace();
			        	}
			        }
				//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalSFP() :: getResponseXML :: " + response.getResponseXML()); //To print response XML
				
				UserDataSecuredFuturePlanABC result = new UserDataSecuredFuturePlanABC();
				com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid resultOtherDetGrid = new com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid();
				String responseXML = response.getResponseXML();
				String responseXMLOtherDetGrid=response.getOtherDetailsGridXML(); // get Other details Grid xml from response
				
				//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalDataSFP() :: responseXMLOtherDetGrid :: " + responseXMLOtherDetGrid); //To print response XML
				
				com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid respObjOtherDetGrid = null;
				
				if(responseFrom!=null && responseFrom.equalsIgnoreCase("MajescoQC")){
					respObj = (UserDataSecuredFuturePlanABC) JAXBXMLHandler.unmarshalTest(new File("D:\\AGIPA_search_response.xml"),result);
					respObjOtherDetGrid = (com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid) JAXBXMLHandler.unmarshalTest(new File("D:\\AGIPA_search_response1.xml"),resultOtherDetGrid);
				}
				else if(responseFrom!=null && responseFrom.equalsIgnoreCase("TataAIG"))
				{	
					respObj = (UserDataSecuredFuturePlanABC) JAXBXMLHandler.unmarshal(responseXML,result);
					respObjOtherDetGrid = (com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid) JAXBXMLHandler.unmarshal(responseXMLOtherDetGrid,resultOtherDetGrid);
				}
				
				mapper.map(respObj,genQuotRes,"IPAGetProductProposalSFP");
				
				
				// Code added for Otherdetails grid integration for SFP by Vishal:: 27/02/2017 :: Start
				if(respObjOtherDetGrid!=null && respObjOtherDetGrid.getNomineeDetailsGrid()!=null && respObjOtherDetGrid.getNomineeDetailsGrid()!=null){
					NomineeDetails nomDet = null;
					List<NomineeDetails> nomDetList = new ArrayList<NomineeDetails>();
					
					List<com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid.NomineeDetailsGrid> detailsListGrid1 = respObjOtherDetGrid
							.getNomineeDetailsGrid();
					//if(logger.isDebugEnabled())logger.debug("IPAServiceImpl :: getIPAProposalSFP() :: Before For Loop OtherDetailGridlist :: "); //To print responseXMLOtherDetGrid
					for (com.majesco.dcf.paproduct.jaxb.accidentguard.search.otherdetailsgrid.OtherDetailsGrid.NomineeDetailsGrid detailsGrid1 : detailsListGrid1) {
						nomDet = new NomineeDetails();
						//logger.info("IPAServiceImpl :: getIPAProposalSFP() :: inside For OtherDetailGridlist :: "); //To print responseXMLOtherDetGrid
						if (detailsGrid1 != null && detailsGrid1.getNomineeDetailsGrid1()!=null) {
							if (detailsGrid1.getNomineeDetailsGrid1().getInsuredPerson() != null)
								nomDet.setInsuPerson(detailsGrid1.getNomineeDetailsGrid1().getInsuredPerson()
										.getValue());

							if (detailsGrid1.getNomineeDetailsGrid1().getNominee() != null)
								nomDet.setNomName(detailsGrid1.getNomineeDetailsGrid1().getNominee().getValue());

							if (detailsGrid1.getNomineeDetailsGrid1().getDateofBirth() != null)
								nomDet.setNomDOB(detailsGrid1.getNomineeDetailsGrid1().getDateofBirth()
										.getValue());

							if (detailsGrid1.getNomineeDetailsGrid1().getAge() != null)
								nomDet.setNomAge(detailsGrid1.getNomineeDetailsGrid1().getAge().getValue());

							if (detailsGrid1.getNomineeDetailsGrid1().getGenderofNominee() != null)
								nomDet.setNomGender(detailsGrid1.getNomineeDetailsGrid1().getGenderofNominee()
										.getValue());

							if (detailsGrid1
									.getNomineeDetailsGrid1().getRelationshipofNomineewithInsuredPerson() != null)
								nomDet.setNomRelation(detailsGrid1
										.getNomineeDetailsGrid1().getRelationshipofNomineewithInsuredPerson()
										.getValue());

							if (detailsGrid1.getNomineeDetailsGrid1().getWhethertheNomineeisaminor() != null)
								nomDet.setNomMinor(detailsGrid1
										.getNomineeDetailsGrid1().getWhethertheNomineeisaminor().getValue());

							if (detailsGrid1.getNomineeDetailsGrid1().getNomineeGuardianName() != null)
								nomDet.setNomGaurdian(detailsGrid1
										.getNomineeDetailsGrid1().getNomineeGuardianName().getValue());

							if (detailsGrid1
									.getNomineeDetailsGrid1().getRelationshipofNomineeGuardianwithNominee() != null)
								nomDet.setNomGaurdRelation(detailsGrid1
										.getNomineeDetailsGrid1().getRelationshipofNomineeGuardianwithNominee()
										.getValue());

							if (detailsGrid1.getNomineeDetailsGrid1().getNomineeContribution() != null)
								nomDet.setNomContribtn(detailsGrid1
										.getNomineeDetailsGrid1().getNomineeContribution().getValue());

						}

						nomDetList.add(nomDet);
					}
					//logger.info("IPAServiceImpl :: getIPAProposalSFP() :: Assigning to json response for NomineeDetails"); //To print responseXMLOtherDetGrid
					genQuotRes.setLstNomDet(nomDetList);
				}
				// Code added for Otherdetails grid integration For SFP by Vishal:: 27/02/2017 :: End
									
				genQuotRes.setProdCode("4255");
				
							
				if (respObj.getPropRisksCol() !=null && respObj.getPropRisksCol().getRisks()!=null){
					UserDataSecuredFuturePlanABC.PropRisksCol.Risks riskObj = respObj.getPropRisksCol().getRisks();
					insuredDet=new InsuredDetails();
					mapper.map(riskObj, insuredDet, "IPAInsuredProductProposalSPF");
					
					mapToInternalCode(insuredDet);
					sumAssured = riskObj.getPropRisksSumInsured();
					lstInsured.add(insuredDet);
					//p2Dto.getPropRisks_Col().getRisks().add(riskObj);
					
				}
				genQuotRes.setLstInsurDet(lstInsured);
				
				// Setting ID type in IPA Proposal response
				if (genQuotRes!= null && genQuotRes.getProposerDet()!= null
						&& respObj.getPropRisksCol() !=null && respObj.getPropRisksCol().getRisks()!=null){
					IdDetails idDetail = new IdDetails();
					idDetail.setIdNumber(respObj.getPropRisksCol().getRisks().getPropRisksIdentityProofNumber());
					idDetail.setIdType(dbserv.getReverseExternalMapCode(null, respObj.getPropRisksCol().getRisks().getPropRisksIdentityProofType(), CommonConstants.IDTYPE_SYSTEM_PARAMCD));
					genQuotRes.getProposerDet().setIdList(idDetail);
					
					if (genQuotRes.getLstcvrgDet()!= null){
						genQuotRes.getLstcvrgDet().setOccuptnClassOfSelf(dbserv.getReverseExternalMapCode
							(null, respObj.getPropRisksCol().getRisks().getPropRisksOccupation(), CommonConstants.OCCUPATION_SYSTEM_PARAMCD));
						genQuotRes.getLstcvrgDet().setCoreSumInsured(sumAssured);
					}
				}
				
				//logger.info("getProductProposalDataPrvtCar :: Maped ProductPropRes :: " + prodPropDataResp.toString());
				//logger.info("IPAServiceImpl :: maped ProductPropRes JSONObj :: \n " + objMapper.writeValueAsString(genQuotRes));
				//Start : 17/03/2017  : To send productName to JSON response
				 String strval="";
				 //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getProductProposalData TW :: Checking For Product Name");
	             List<Product> oComProductList =  (List<Product>) dbserv.getProduct("com.majesco.dcf.common.tagic.entity.Product","strprodcd",prodPropDataReq.getProductCode());
	             if(oComProductList != null || oComProductList.size()>0){
	             	for(Product productList:oComProductList){	                            		                                  
	                       strval = productList.getStrprodname()!=null?productList.getStrprodname().toString():"";
	                       //logger.info("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getProductProposalData TW :: Fetching Product Name"+strval);
	                 }	
	             }	                              
	             //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getProductProposalData TW :: Fetching Product Name To Go In Response"+strval);
	             genQuotRes.setProductName(strval);	
				 //End : 17/03/2017  : To send productName to JSON response	
	             //Start:07/03/2017:To search customer details by customer id and populate full customer details data from GC
	             if(genQuotRes.getCustCode()!=null && !genQuotRes.getCustCode().equals(CommonConstants.BLANK_STRING)){
	             	CustomerDetailRequest customerDetailRequest=new CustomerDetailRequest();
	             	customerDetailRequest.setAuthToken(reqQ.getAuthenticationToken());
	             	customerDetailRequest.setCustomerID(genQuotRes.getCustCode());
	             	//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside MotorServiceImpl :: getProductProposalDataComm :: Fetching Customer Details"+genQuotRes.getCustCode());
	             	CustomerDetailResponse customerDetailResponse=customerService.getCustomerDetails(customerDetailRequest);
	             	
	             	if(customerDetailResponse!=null && customerDetailResponse.getCustDetails()!=null && customerDetailResponse.getCustDetails().size()>0){
	             		genQuotRes.setProposerDet(customerDetailResponse.getCustDetails().get(0));
	             	}
	             }
	           //End:07/03/2017:To search customer details by customer id and populate full customer details data from GC
	             //Start : 13-Apr-2017 : To fetch workflowId from Channel Portal DB
	             String workFlowId = "";
	             workFlowId = dbserv.getWorkFlowIdFromProposalNo(prodPropDataReq.getProposalNumber());
	             if(workFlowId != null && !workFlowId.equalsIgnoreCase(CommonConstants.BLANK_STRING)){
	            	 genQuotRes.setProposalSystemId(workFlowId);
	             }	                           	                            
	             //End : 13-Apr-2017 : To fetch workflowId from Channel Portal DB
	             
	          // Start : 04-May-207 :Code added to send premium details to UI
	             	Double totPrem=0.0; 
	             	prmdet = new PremiumDetails();
					if(respObj.getPropPremiumCalculationNetPremium()!=null)
						prmdet.setNetPremium(respObj.getPropPremiumCalculationNetPremium());
					if(respObj.getPropPremiumCalculationTotalPremium()!=null)
						prmdet.setTotalPremium(respObj.getPropPremiumCalculationTotalPremium());
					if(respObj.getPropGeneralProposalInformationTotalSi()!=null)
						prmdet.setSumInsured(respObj.getPropGeneralProposalInformationTotalSi());
					if(respObj.getPropPremiumCalculationServiceTax()!=null)
						prmdet.setServiceTax(respObj.getPropPremiumCalculationServiceTax());										
					if(respObj.getPropPremiumCalculationTotalPremium()!=null)
						totPrem = Double.parseDouble(respObj.getPropPremiumCalculationTotalPremium());
						
					prmdet.setPremiumPayable(""+totPrem);
					
					//genquotres.setPrmdet(prmdet);
					genQuotRes.setPremDet(prmdet);
				// End : 04-May-207 :Code added to send premium details to UI	
	             
				 ObjectMapper objMap=new ObjectMapper();
				 
				    //START:Code changes for defect 2443.
				    genQuotRes.setBranchOfficeCode(respObj.getPropGeneralProposalInformationBranchOfficeCode());
					genQuotRes.setOfficeCode(respObj.getPropGeneralProposalInformationOfficeCode());
					genQuotRes.setOfficeName(respObj.getPropGeneralProposalInformationOfficeName());
					genQuotRes.setProposalNumber(prodPropDataReq.getProposalNumber());
					//genQuotRes.setOccupation(occupation);
					//END code changes for defect 493.
					//return genQuotRes;   // For 1908 :  VishalJ : return statement is Commented.
					
					//04-July-2018 :Code added to setResultCode 1 to UI
		     		if(genQuotRes!=null){
		     		genQuotRes.setResultCode("1");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("NOERR");
					errorRes.setErrorMMessag("NO ERROR");
					errorList.add(errorRes);
					genQuotRes.setResErr(errorList);
					logger.info("TransactionID:"+transId+" :: Inside IPAServiceImpl :: getIPAProposalDataSFP :: Response Sent to UI JSON Object :: "+objMap.writeValueAsString(genQuotRes));   // 1908 : VishalJ  : Printing SFP JSON.				
		     		}
			}
		
			catch(Exception e)
			{
				//genQuotRes.setResultCode("0");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError errorRes=new ResponseError();
				errorRes.setErrorCode("ERR");
				errorRes.setErrorMMessag(e.getMessage()+".Transaction ID::"+transId);
				errorList.add(errorRes);
				genQuotRes.setResErr(errorList);
				e.printStackTrace();
				logger.error("Inside IPAServiceImpl :: getIPAProposalDataSFP method :: Exception Occurred : "+e.toString()+".Transaction ID::"+transId);
			}
		return genQuotRes;
		}
		//End: RahulT | added to get policy/proposal details For Secure Future plan
		
		//Start: RahulT | added to get reverse mapping code
		private InsuredDetails mapToInternalCode(InsuredDetails insuredDet){
			ObjectMapper mapper=new ObjectMapper();
			try{
			if(insuredDet!=null){
					//if(logger.isDebugEnabled())logger.debug("Ins Object :- "+mapper.writeValueAsString(insuredDet));
					//gender
					if(insuredDet.getGender()!=null && !insuredDet.getGender().equalsIgnoreCase(""))
						insuredDet.setGender(dbserv.getReverseExternalMapCode(null, CommonConstants.GENDERCD_SYSTEM_PARAMCD, insuredDet.getGender()));
					//occupation
					/*if(objCreateCust.getCustomerDet().getOccupation()!=null && !objCreateCust.getCustomerDet().getOccupation().equalsIgnoreCase(""))
						objCreateCust.getCustomerDet().setOccupation(dbserv.getExternalMapCode(null, objCreateCust.getCustomerDet().getOccupation(), CommonConstants.OCCUPATION_SYSTEM_PARAMCD));*/
					//marital status
					if(insuredDet.getMaritalStatus()!=null && !insuredDet.getMaritalStatus().equalsIgnoreCase(""))
						insuredDet.setMaritalStatus(dbserv.getReverseExternalMapCode(null, CommonConstants.MARITALSTATUS_SYSTEM_PARAMCD, insuredDet.getMaritalStatus()));
					// title
					if(insuredDet.getInsuTitle()!=null && !insuredDet.getInsuTitle().equalsIgnoreCase(""))
						insuredDet.setInsuTitle(dbserv.getReverseExternalMapCode(null, CommonConstants.TITLE_SYSTEM_PARAMCD, insuredDet.getInsuTitle()));
					//ID type
					if(insuredDet.getIdList()!=null && insuredDet.getIdList().getIdType()!=null){
						insuredDet.getIdList().setIdType(dbserv.getReverseExternalMapCode(null, insuredDet.getIdList().getIdType(), CommonConstants.IDTYPE_SYSTEM_PARAMCD));
					}
					//Start : 25-Apr-2017 : Code added for Giving Reverse Mapping For Relationship & Occupation : Vishal
					if(insuredDet.getRelationship()!=null && !insuredDet.getRelationship().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
						insuredDet.setRelationship(dbserv.getReverseExternalMapCode(null, CommonConstants.RELATIONSHIP_SYSTEM_PARAMCD ,insuredDet.getRelationship()));
					}
					if(insuredDet.getOccupation()!=null && !insuredDet.getOccupation().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
						//if(logger.isDebugEnabled())logger.debug("insuredDet.getOccupation 11:- "+insuredDet.getOccupation());
						insuredDet.setOccupation(dbserv.getReverseExternalMapCode(null, CommonConstants.OCCUPATION_SYSTEM_PARAMCD , insuredDet.getOccupation()));
						//if(logger.isDebugEnabled())logger.debug("insuredDet.getOccupation 22:- "+insuredDet.getOccupation());
					}
					//End : 25-Apr-2017 : Code added for Giving Reverse Mapping For Relationship & Occupation : Vishal					
			}
			}catch(Exception ex){
				ex.printStackTrace();
				logger.error("mapToExternalCode ::", ex);
			}
			return insuredDet;
		}
		//End: RahulT | added to get reverse mapping code
		
		// Start: RahulT| added to get proposal no from GC
		private IPAProposalDataRequest getGCProposalNo(IPAProposalDataRequest prodPropDataReq){
			
			
			try{
				propValue = this.getWSDLURL(CommonConstants.POLICY_SEARCH);
				URL url = new URL(propValue);
				ObjectMapper objectMapper = new ObjectMapper();
				//GetPolicyDetailByPolicyNo p2DtoReq = new GetPolicyDetailByPolicyNo();
				logger.info("Inside IPAServiceImpl :: getGCProposalNo :: Start ::"+objectMapper.writeValueAsString(prodPropDataReq));
				com.majesco.dcf.motor.jaxb.policy.request.GetPolicyDetailByPolicyNo p2DtoReq = new com.majesco.dcf.motor.jaxb.policy.request.GetPolicyDetailByPolicyNo();
				if(prodPropDataReq.getPolicyNumber() != null && !prodPropDataReq.getPolicyNumber().equalsIgnoreCase("")){
         		   p2DtoReq.setStrPolicyNo(prodPropDataReq.getPolicyNumber());
         	   	}
				String jaxbXML = JAXBXMLHandler.marshal(p2DtoReq);
				//if(logger.isDebugEnabled())logger.debug("Inside IPAServiceImpl :: getGCProposalNo() method :: JAXB XML :: "+jaxbXML);
				
				com.unotechsoft.stub.policysearch.client.SearchStubService_Service stub = new com.unotechsoft.stub.policysearch.client.SearchStubService_Service(url);
				
				com.unotechsoft.stub.policysearch.client.QuotationRequest reqQ = new com.unotechsoft.stub.policysearch.client.QuotationRequest();
				//Getting Authentication Token Starts Here
                String propFileName = "resource.properties";
                String userID="";
                String password="";
                String responseFrom = "";
                Properties prop = new Properties();
                InputStream inputStream = MotorServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
                prop.load(inputStream);
                userID=prodPropDataReq.getUserID();
                password=prodPropDataReq.getPassword();
                responseFrom=prop.getProperty("ResponseFrom");
                AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
                //Getting Authentication Token Stops Here
                reqQ.setAuthenticationToken(authRes.getResultRes());
                reqQ.setSource(smc_source);
                reqQ.setProductCode("3121");
				 reqQ.setModeOfOperation("NEWPOLICY");
                reqQ.setCampaign(smc_campaign);
                reqQ.setMedium(smc_medium);
                reqQ.setCIAName("");
                reqQ.setHashKey("");
                reqQ.setHostAddress("");
                reqQ.setInputXML(jaxbXML);
                reqQ.setIsBankDataRequired(false);
                reqQ.setIsCutomerAddressRequired(false);
                reqQ.setIsFinanciarDataRequired(false);
                reqQ.setIsManufacturerMappingRequired(false);
                reqQ.setIsRTOMappingRequired(false);
                reqQ.setUserId(prodPropDataReq.getUserID());
				reqQ.setUserRole("ADMIN");
				
				com.unotechsoft.stub.policysearch.client.SearchStubService port = stub.getSOAPOverHTTP();
	            Client client=ClientProxy.getClient(port);
	            PrintWriter writer = new PrintWriter(System.out);
	            
	            client.getOutInterceptors().add(new CdataWriterInterceptor());
	            client.getInInterceptors().add(new LoggingInInterceptor(writer));
	            client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
	            
	            //if(logger.isDebugEnabled())logger.debug("Requesting For Proposal number for Policy "+prodPropDataReq.getPolicyNumber());
	            com.unotechsoft.stub.policysearch.client.GenericResult genericResult = port.getPolicyDetailByPolicyNo(reqQ);
	            
	            List<LOVType> lovTypeList = genericResult.getLOVTypes().getLOVType();
	            com.unotechsoft.stub.policysearch.client.LOVTypePolicyDetail response = (com.unotechsoft.stub.policysearch.client.LOVTypePolicyDetail) lovTypeList.get(0);      
	         
	            if (response != null) 
	            {
	             //if(logger.isDebugEnabled())logger.debug("getGCProposalNo :: response.getProposalNo(): " + response.getProposalNo());
	           	 response.getProposalNo();
	           	 
	           	 prodPropDataReq.setProposalNumber(response.getProposalNo());
				 }
	             logger.info("Inside IPAServiceImpl :: getGCProposalNo :: Exit ::"+objectMapper.writeValueAsString(prodPropDataReq));
			}
			catch(Exception ex){
				ex.printStackTrace();
			}
			
			return prodPropDataReq;
			
		}

		@SuppressWarnings({ "rawtypes", "unchecked" })
		@Override
		public List<SearchIPAQuotResponse> searchIPAQuotationList(SearchIPAQuotRequest ipaQuotRequest)
				throws Exception {
			List<SearchIPAQuotResponse> responseList = new ArrayList<SearchIPAQuotResponse>();
			ArrayList<Object[]> resultData = new ArrayList();
			ArrayList finalData = null;
			//Map row = null;
			ObjectMapper objMapper = new ObjectMapper();
			
			try{
				resultData = dbserv.searchIPAQuotationList(ipaQuotRequest);
				logger.info("searchIPAQuotationList :: request Object--> " + objMapper.writeValueAsString(resultData));
				
				for(Object[] row : resultData)
				{
					//ArrayList testArray = new ArrayList();
					/*if (logger.isDebugEnabled())
						logger.debug("searchIPAQuotationList :: row--> " + objMapper.writeValueAsString(row));*/
					SearchIPAQuotResponse response = new SearchIPAQuotResponse();
					
					//BigInteger bigInt = new BigInteger(row[0].toString());
					
					response.setCustomerId((String) nullCheckString(row[7])); 
		            response.setQuotionNo((String) nullCheckString(row[0]));
		            response.setFirstName((String) nullCheckString(row[2]));
		            response.setLastName((String) nullCheckString(row[3]));
		            //Start 17-07-2018: code added for IPA changes 
		            if(row[8] != null){
		            Date date = new Date();
					date.setTime(((Date) row[8]).getTime());
					String formattedDate = new SimpleDateFormat("yyyyMMdd").format(date);
					response.setCreationDate(formattedDate);}
		            //END 17-07-2018: code added for IPA changes 
		            //response.setCreationDate((String)row[8]);
					responseList.add(response);
				}
				/*if (logger.isDebugEnabled())
					logger.debug("searchIPAQuotationList :: response Object--> " + objMapper.writeValueAsString(responseList));*/
			}
			
			catch (Exception e){
				e.printStackTrace();
			}
			logger.info("MY LIST HAS THE OBJECTS,IM VERYFYING THEM" +responseList);
			return responseList;
		}

		@Override
		public SearchIPAQuotResponse getIPAQuotation(SearchIPAQuotRequest ipaQuotRequest) throws Exception {
			SearchIPAQuotResponse response = new SearchIPAQuotResponse();
			ObjectMapper objMapper = new ObjectMapper();
			HashMap resultMap = new HashMap();
			String paQuoteRequestjson = null;
			String paQuoteResponsejson = null;
			PAQuickQuotPrmRequest quoteReq = new PAQuickQuotPrmRequest();
			PAQuickQuotPrmResponse quoteRes = new PAQuickQuotPrmResponse(); 
			Gson gson = new Gson();
			
			try{
				logger.info("getIPAQuotation :: request Object from UI--> " + objMapper.writeValueAsString(ipaQuotRequest));
				
				if (ipaQuotRequest!=null & ipaQuotRequest.getQuotationNo()!=null && !ipaQuotRequest.getQuotationNo().equals("")){
					resultMap = dbserv.getIPAQuotation(ipaQuotRequest.getQuotationNo());
					
					Date date = (Date)resultMap.get("createddate");					
					DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
					
					String quotationDate = df.format(date);
					
					response.setCustomerId((String)nullCheckString(resultMap.get("customerid")));
					response.setQuotionNo((String)nullCheckString(resultMap.get("quoteNumber")));
					response.setProductCd((String)nullCheckString(resultMap.get("productcode")));
					response.setFirstName((String)nullCheckString(resultMap.get("firstname")));
					response.setLastName((String)nullCheckString(resultMap.get("lastname")));
					response.setPlan((String)nullCheckString(resultMap.get("plancode")));
					response.setMobileNo((String)nullCheckString(resultMap.get("mobilenumber")));
					response.setQuotationDate(nullCheckString(quotationDate));
					paQuoteRequestjson = (String)nullCheckString(resultMap.get("requesttransdata"));
					paQuoteResponsejson = (String)nullCheckString(resultMap.get("responsetransdata"));
					quoteReq = gson.fromJson(paQuoteRequestjson, PAQuickQuotPrmRequest.class);
					quoteRes = gson.fromJson(paQuoteResponsejson, PAQuickQuotPrmResponse.class);
					response.setQuoteRequestData(quoteReq);
					response.setQuoteResponseData(quoteRes);
					// Start: RahulT| code added to get customer details along with IPA quote details
					if (response.getCustomerId()!=null){
						CustomerDetailRequest customer = new CustomerDetailRequest();
						customer.setCustomerID(response.getCustomerId());
						customer.setAuthToken(ipaQuotRequest.getAuthToken());
						CustomerDetailResponse customerDetailResponse=customerService.getCustomerDetails(customer);
		             	
		             	if(customerDetailResponse!=null && customerDetailResponse.getCustDetails()!=null && customerDetailResponse.getCustDetails().size()>0){
		             		response.setCustDetails(customerDetailResponse.getCustDetails().get(0));
		             	}
					}
				}
				
				logger.info("getIPAQuotation :: response Object from UI--> " + objMapper.writeValueAsString(response));
				
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
			return response;
		}
		
		public String nullCheckString(Object obj)
        {
      	  if(obj==null)
      		  return "";
      	  else
      		  return (String) obj;
        }
	}

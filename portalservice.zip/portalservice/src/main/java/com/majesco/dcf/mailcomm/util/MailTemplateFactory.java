package com.majesco.dcf.mailcomm.util;

import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.mailcomm.service.MailTemplateService;

public class MailTemplateFactory {

	private static Properties prop = new Properties();
	final static Logger logger=Logger.getLogger(MailTemplateFactory.class);
	private static String _strCLassName="MailTemplateFactory";
	static{
		try{
	InputStream inputStream = MailTemplateFactory.class.getClassLoader().getResourceAsStream("mailhandler.properties");
	prop.load(inputStream);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static MailTemplateService getEmailTemplateHandler(String strEventId) throws Exception{
		
		MailTemplateService mailTempateService=null;
		String strHandlerClass=null;
		String strMethodName="getEmailTemplateHandler";
		try{
			logger.info("Inside "+_strCLassName+"::"+strMethodName+"::Entered");
			strHandlerClass=prop.getProperty("TemplateHandler");
			
			if(strHandlerClass!=null && !strHandlerClass.equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				
				Class handlerClass=Class.forName(strHandlerClass);
				mailTempateService=(MailTemplateService)handlerClass.newInstance();
			}
			logger.info("Inside "+_strCLassName+"::"+strMethodName+"::Exit");
		}catch(InstantiationException insEx){
			logger.error("Inside "+_strCLassName+"::"+strMethodName+"::Exception::",insEx);
		}catch(IllegalAccessException illEx){
			logger.error("Inside "+_strCLassName+"::"+strMethodName+"::Exception::",illEx);
		}catch(ClassNotFoundException clsEx){
			logger.error("Inside "+_strCLassName+"::"+strMethodName+"::Exception::",clsEx);
		}
		catch(Exception ex){
			logger.error("Inside "+_strCLassName+"::"+strMethodName+"::Exception::",ex);
		}
		return mailTempateService;
		
	}
	
}

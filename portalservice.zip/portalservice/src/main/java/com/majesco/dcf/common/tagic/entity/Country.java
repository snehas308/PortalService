package com.majesco.dcf.common.tagic.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_country_m",schema="dcf_master")			// Commented for Oracle Migration
@Table(name = "dcf_country_m")									// Added for Oracle Migration
public class Country {
	
	private String strcountrycd;
	private String strcountryname;
	private Integer nisdcd;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	private String strcurrency;
	
	
	@Id
	@Column(name = "strcountrycd")
	public String getStrcountrycd() {
		return strcountrycd;
	}
	public void setStrcountrycd(String strcountrycd) {
		this.strcountrycd = strcountrycd;
	}
	
	
	@Column(name = "strcountryname")
	public String getStrcountryname() {
		return strcountryname;
	}
	public void setStrcountryname(String strcountryname) {
		this.strcountryname = strcountryname;
	}
	
	
	@Column(name = "nisdcd")
	public Integer getNisdcd() {
		return nisdcd;
	}
	public void setNisdcd(Integer nisdcd) {
		this.nisdcd = nisdcd;
	}
	
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	
	@Column(name = "strcurrency")
	public String getStrcurrency() {
		return strcurrency;
	}
	public void setStrcurrency(String strcurrency) {
		this.strcurrency = strcurrency;
	}

}

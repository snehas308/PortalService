package com.majesco.dcf.common.tagic.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.json.CoverNoteReasons;
import com.majesco.dcf.common.tagic.json.CovernoteOtherReasonRequest;
import com.majesco.dcf.common.tagic.json.CovernoteOtherReasonResponse;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.usermgmt.json.SecurityQuestion;
import com.majesco.dcf.usermgmt.json.SecurityQuestionRequest;
import com.majesco.dcf.usermgmt.json.SecurityQuestionResponse;

@Service
public class CoverNoteServices {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(IntermediaryOfficeCodeService.class);
	
	@SuppressWarnings("unchecked")
	public CovernoteOtherReasonResponse getCovernoteReasons(CovernoteOtherReasonRequest securityQuestionRequest) throws Exception{
		
		CovernoteOtherReasonResponse securityQuestionResponse=null;
		String strMethodName="getCovernoteReasons";
		
		try{
			
			logger.info("Inside CoverNoteServices ::"+strMethodName+"::Entered");
			
			List securityQuestionParamList=dbserv.getSystemUserParamCodes(new Integer("2004"), "1");
			
			if(securityQuestionParamList!=null){
				securityQuestionResponse=new CovernoteOtherReasonResponse();
				ArrayList<CoverNoteReasons> securityQuestionList=new ArrayList<CoverNoteReasons>();
				Iterator securityQuestionItr=securityQuestionParamList.iterator();
				
				if(securityQuestionItr!=null){
					HashMap<String, String> resultMap =new HashMap<String, String>();
					
					while(securityQuestionItr.hasNext()){
						resultMap=(HashMap<String, String>)securityQuestionItr.next();
						CoverNoteReasons securityQuestion=new CoverNoteReasons();
						if(resultMap!=null){
							securityQuestion.setQuestionID(resultMap.get("strparamcd"));
							securityQuestion.setQuestion(resultMap.get("strcddesc"));
						}
						
						securityQuestionList.add(securityQuestion);
					}
				}
				
				securityQuestionResponse.setSecurityQuestionList(securityQuestionList);
				securityQuestionResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
			}
			
		ObjectMapper objectMap=new ObjectMapper();
		logger.info("Inside CoverNoteServices ::"+strMethodName+":: JSON Output::"+objectMap.writeValueAsString(securityQuestionResponse));
		logger.info("Inside CoverNoteServices ::"+strMethodName+"::Exit");
		}catch(Exception ex){
			logger.error("Inside CoverNoteServices ::"+strMethodName+"::Exception",ex);
			securityQuestionResponse=new CovernoteOtherReasonResponse();
			securityQuestionResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			securityQuestionResponse.setMessage(ex.getMessage());
		}
		return securityQuestionResponse;
	}
	
	
	@SuppressWarnings("unchecked")
	public CovernoteOtherReasonResponse getCovernoteOtherReasons(CovernoteOtherReasonRequest securityQuestionRequest) throws Exception{
		
		CovernoteOtherReasonResponse securityQuestionResponse=null;
		String strMethodName="getCovernoteOtherReasons";
		ObjectMapper objectMap=new ObjectMapper();
		
		logger.info("Inside CoverNoteServices ::"+strMethodName+":: JSON Input::"+objectMap.writeValueAsString(securityQuestionRequest));
		
		try{
			
			logger.info("Inside CoverNoteServices ::"+strMethodName+"::Entered");
			
			List securityQuestionParamList=dbserv.getCovernoteOtherReasons(new Integer("2004"), securityQuestionRequest.getReasonId());
			
			if(securityQuestionParamList!=null){
				securityQuestionResponse=new CovernoteOtherReasonResponse();
				ArrayList<CoverNoteReasons> securityQuestionList=new ArrayList<CoverNoteReasons>();
				Iterator securityQuestionItr=securityQuestionParamList.iterator();
				
				if(securityQuestionItr!=null){
					HashMap<String, String> resultMap =new HashMap<String, String>();
					
					while(securityQuestionItr.hasNext()){
						resultMap=(HashMap<String, String>)securityQuestionItr.next();
						CoverNoteReasons securityQuestion=new CoverNoteReasons();
						if(resultMap!=null){
							securityQuestion.setQuestionID(resultMap.get("strotherreasoncd"));
							securityQuestion.setQuestion(resultMap.get("strotherreasondesc"));
						}
						
						securityQuestionList.add(securityQuestion);
					}
				}
				
				securityQuestionResponse.setSecurityQuestionList(securityQuestionList);
				securityQuestionResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
			}
			
		
		logger.info("Inside CoverNoteServices ::"+strMethodName+":: JSON Output::"+objectMap.writeValueAsString(securityQuestionResponse));
		logger.info("Inside CoverNoteServices ::"+strMethodName+"::Exit");
		}catch(Exception ex){
			logger.error("Inside CoverNoteServices ::"+strMethodName+"::Exception",ex);
			securityQuestionResponse=new CovernoteOtherReasonResponse();
			securityQuestionResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			securityQuestionResponse.setMessage(ex.getMessage());
		}
		return securityQuestionResponse;
	}
}

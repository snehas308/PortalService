package com.majesco.dcf.docmgmt.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "dcf_cust_doc_upload")
public class CustDocUploadEntity {
	
	private Integer custLinkSeq;
	private String transId;
	private String customerId;
	private String propPolNbr;
	private String email;
	private String mobile;
/*	private String landlineno;
	private String alternateno;*/
	private double proposalAmount;	
	private String custlinkURL;
	private String productCd;
	private String producerCd;
	private String status;
	private Date dtCreated;
	private String createdby;
	private Date dtUpdated;
	private String updatedBy;
	private String custLinkUsed;
	private String producerName;
	private String errorCode;
	private String errorMsg;
	private String customerName;
	private String vegRegNo;
	private String planName;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="dcf_cust_upload_custlink_seq")     //sequence to be change
	@SequenceGenerator(name="dcf_cust_upload_custlink_seq",sequenceName="dcf_cust_upload_custlink_seq",allocationSize=1,initialValue=1)
	@Column(name="custlinkseq", nullable=false)
	public Integer getCustLinkSeq() {
		return custLinkSeq;
	}
	public void setCustLinkSeq(Integer custLinkSeq) {
		this.custLinkSeq = custLinkSeq;
	}
	
	@Column(name="producername")
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	
	@Column(name = "strtransid")
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	
	
	@Column(name = "strcustomerid")
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}	
	
	@Column(name = "stremail")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(name = "strmobile")
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
/*	@Column(name = "strlandline")
	public String getLandlineno() {
		return landlineno;
	}
	public void setLandlineno(String landlineno) {
		this.landlineno = landlineno;
	}
	
	@Column(name = "stralternateno")
	public String getAlternateno() {
		return alternateno;
	}
	public void setAlternateno(String alternateno) {
		this.alternateno = alternateno;
	}*/
	
	@Column(name = "proposalamt")
	public double getProposalAmount() {
		return proposalAmount;
	}
	public void setProposalAmount(double proposalAmount) {
		this.proposalAmount = proposalAmount;
	}
	
	
	@Column(name = "custlinkurl")
	public String getCustlinkURL() {
		return custlinkURL;
	}
	public void setCustlinkURL(String custlinkURL) {
		this.custlinkURL = custlinkURL;
	}	
	
	@Column(name = "strstatus")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Column(name = "dtcreated")
	public Date getDtCreated() {
		return dtCreated;
	}
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	
	@Column(name = "strcreatedby")
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	
	@Column(name = "dtupdated")
	public Date getDtUpdated() {
		return dtUpdated;
	}
	public void setDtUpdated(Date dtUpdated) {
		this.dtUpdated = dtUpdated;
	}
	
	@Column(name = "strupdatedby")
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Column(name = "strproppolno")
	public String getPropPolNbr() {
		return propPolNbr;
	}
	public void setPropPolNbr(String propPolNbr) {
		this.propPolNbr = propPolNbr;
	}
	@Column(name = "productcd")
	public String getProductCd() {
		return productCd;
	}
	public void setProductCd(String productCd) {
		this.productCd = productCd;
	}
	
	@Column(name = "producercd")
	public String getProducerCd() {
		return producerCd;
	}
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}
	
	@Column(name = "custlinkused")
	public String getCustLinkUsed() {
		return custLinkUsed;
	}
	public void setCustLinkUsed(String payLinkUsed) {
		this.custLinkUsed = payLinkUsed;
	}
	
	@Column(name = "errorcode")
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	@Column(name = "errormsg")
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	@Column(name = "strcustomername")
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	@Column(name = "strvehregno")
	public String getVegRegNo() {
		return vegRegNo;
	}
	public void setVegRegNo(String vegRegNo) {
		this.vegRegNo = vegRegNo;
	}
	@Column(name = "strplanname")
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}

	
	
}

package com.majesco.dcf.docmgmt.json;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

/**
 * @author yogesh570158
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocUploadOptionObj extends UserObject{

	//private long ndocid;
	//private Integer activeStatus;
	private String proposalNo;
	private String policyNo;
	private String option;
	private String status;
	

	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	
		
	
	
}

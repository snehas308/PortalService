package com.majesco.dcf.common.tagic.json;

public class PendingPayInSlipResponse {
	private String portalLockMsg;
	private Integer totalPendingCount;
	
	public String getPortalLockMsg() {
		return portalLockMsg;
	}
	public void setPortalLockMsg(String portalLockMsg) {
		this.portalLockMsg = portalLockMsg;
	}
	public Integer getTotalPendingCount() {
		return totalPendingCount;
	}
	public void setTotalPendingCount(Integer totalPendingCount) {
		this.totalPendingCount = totalPendingCount;
	}
	
}

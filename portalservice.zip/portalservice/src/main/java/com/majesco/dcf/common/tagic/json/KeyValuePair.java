package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author ketan570156
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class KeyValuePair {
	
	private String key;
	private String pair;
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getPair() {
		return pair;
	}
	public void setPair(String pair) {
		this.pair = pair;
	}

}

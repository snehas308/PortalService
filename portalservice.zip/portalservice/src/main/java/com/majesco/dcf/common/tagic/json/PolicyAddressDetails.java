package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PolicyAddressDetails {
	
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String areaVillageCode;
	private String areaVillageName;
	private String cityDistrictCode;
	private String cityDistrictName;
	private String cityId;
	private String cityName;
	private String countryID;
	private String countryName;
	private String districtName;
	private String division;
	private String divisionCode;
	private String endDate;
	private String errorText;
	private String id;
	private String landMark;
	private String mediatorName;
	private String name;
	private String poBox;
	private String pincode;
	private String pincodeLocality;
	private String region;
	private String startDate;
	private String stateCode;
	private String stateName;
	private String userId;
	private String apartmentName;
	private String locationCode;
	private String streetName;
	private String titleBarName;
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getAreaVillageCode() {
		return areaVillageCode;
	}
	public void setAreaVillageCode(String areaVillageCode) {
		this.areaVillageCode = areaVillageCode;
	}
	public String getAreaVillageName() {
		return areaVillageName;
	}
	public void setAreaVillageName(String areaVillageName) {
		this.areaVillageName = areaVillageName;
	}
	public String getCityDistrictCode() {
		return cityDistrictCode;
	}
	public void setCityDistrictCode(String cityDistrictCode) {
		this.cityDistrictCode = cityDistrictCode;
	}
	public String getCityDistrictName() {
		return cityDistrictName;
	}
	public void setCityDistrictName(String cityDistrictName) {
		this.cityDistrictName = cityDistrictName;
	}
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCountryID() {
		return countryID;
	}
	public void setCountryID(String countryID) {
		this.countryID = countryID;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getDivisionCode() {
		return divisionCode;
	}
	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getErrorText() {
		return errorText;
	}
	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLandMark() {
		return landMark;
	}
	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}
	public String getMediatorName() {
		return mediatorName;
	}
	public void setMediatorName(String mediatorName) {
		this.mediatorName = mediatorName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPoBox() {
		return poBox;
	}
	public void setPoBox(String poBox) {
		this.poBox = poBox;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getPincodeLocality() {
		return pincodeLocality;
	}
	public void setPincodeLocality(String pincodeLocality) {
		this.pincodeLocality = pincodeLocality;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getApartmentName() {
		return apartmentName;
	}
	public void setApartmentName(String apartmentName) {
		this.apartmentName = apartmentName;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getTitleBarName() {
		return titleBarName;
	}
	public void setTitleBarName(String titleBarName) {
		this.titleBarName = titleBarName;
	}
	
	
	
	
}

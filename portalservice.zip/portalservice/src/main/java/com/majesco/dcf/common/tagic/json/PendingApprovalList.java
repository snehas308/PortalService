package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

public class PendingApprovalList {

	private int noOfPendingApproval;
	private ArrayList<DashBoardSummaryDetails> dashBoardPendingApprovalList;
	public int getNoOfPendingApproval() {
		return noOfPendingApproval;
	}
	public void setNoOfPendingApproval(int noOfPendingApproval) {
		this.noOfPendingApproval = noOfPendingApproval;
	}
	public ArrayList<DashBoardSummaryDetails> getDashBoardPendingApprovalList() {
		return dashBoardPendingApprovalList;
	}
	public void setDashBoardPendingApprovalList(
			ArrayList<DashBoardSummaryDetails> dashBoardPendingApprovalList) {
		this.dashBoardPendingApprovalList = dashBoardPendingApprovalList;
	}
	
	
}

package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "dcf_payment_dtls_m")
public class PaymentDetails implements Serializable{

	@Column(name= "ltransid")
	private Long ltransId;
	
	@Column(name= "strproposalno")
	private String strproposalno;
	
	@Column(name= "strpolicyno")
	private String strpolicyno;
	
	@Column(name= "strworkflowid")
	private String strworkflowid;
	
	@Column(name= "strpaymentmode")
	private String strpaymentmode;
	
	@Column(name= "strpaymentamount")
	private String strpaymentamount;
	
	@Column(name= "strbalanceamt")
	private String strbalanceamt;
	
	@Column(name= "strpaymentinstrumentdt")
	private Date strpaymentinstrumentdt;
	
	@Column(name= "strinstrumentno")
	private String strinstrumentno;
	
	@Column(name= "strinstrumenttype")
	private String strinstrumenttype;
	
	@Column(name= "stradreceiptno")
	private String stradreceiptno;
	
	@Column(name= "stradreceiptamt")
	private String stradreceiptamt;
	
	@Column(name= "stradbalanceamt")
	private String stradbalanceamt;
	
	@Column(name= "strifsccd")
	private String strifsccd;
	
	@Column(name= "strcustid")
	private String strcustid;
	
	@Column(name= "strproducercd")
	private String strproducercd;
	
	@Column(name= "strproductcd")
	private String strproductcd;
	
	@Column(name= "strgcreceiptno")
	private String strgcreceiptno;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtcreated", insertable=false)
	private Date dtcreated;
	
	@Column(name= "strcreatedby")
	private String strcreatedby;
	
	@Column(name= "dtupdated")
	private Date dtupdated;
	
	@Column(name= "strupdatedby")
	private String strupdatedby;
	
	@Column(name= "stripaddress")
	private String stripaddress;
	
	@Column(name= "strpolicystartdt")
	private Date strpolicystartdt;
	
	@Column(name= "strpolicyenddt")
	private Date strpolicyenddt;
	
	@Column(name= "strispayinslipgenerated")
	private String strispayinslipgenerated;
	
	@Column(name= "dtpayinslipgenerated")
	private Date dtpayinslipgenerated;
	
	@Column(name= "strbusinessLocation")
	private String strbusinessLocation;
	
	@Column(name= "strdepositofficecode")
	private String strdepositofficecode;
	
	@Column(name= "strbusslocname")
	private String strbusslocname;
	
	@Column(name= "strgcsubreceiptno")
	private String strgcsubreceiptno;
	
	/*Added New Column strnewrenewflag starts here*/
	@Column(name= "strnewrenewflag")
	private String strnewrenewflag;
	/*Added New Column strnewrenewflag ends here*/
	
	/*Added For Issue ID 2717 - ICICI/AXIS bank Change - Starts Here*/
	@Column(name= "strhousebranchname")
	private String strhousebranchname;
	
	@Column(name= "strhousebranchcode")
	private String strhousebranchcode;
	
	@Column(name= "straccountno")
	private String straccountno;
	/*Added For Issue ID 2717 - ICICI/AXIS bank Change - Ends Here*/
	/* commented changes done for dispaying receipt details for SPL part payment cases 
	 * @Column(name= "strlob")
	private String strlob;
	
	@Column(name= "strmodeofoperation")
	private String strmodeofoperation;
	
	@Column(name= "isreceiptdeallocated",columnDefinition="text default 0")
	private String isreceiptdeallocated;*/
	/*Added For Issue ID 2717 - ICICI/AXIS bank Change - Starts Here*/
	public String getStrhousebranchname() {
		return strhousebranchname;
	}

	public void setStrhousebranchname(String strhousebranchname) {
		this.strhousebranchname = strhousebranchname;
	}

	public String getStrhousebranchcode() {
		return strhousebranchcode;
	}

	public void setStrhousebranchcode(String strhousebranchcode) {
		this.strhousebranchcode = strhousebranchcode;
	}

	public String getStraccountno() {
		return straccountno;
	}

	public void setStraccountno(String straccountno) {
		this.straccountno = straccountno;
	}
	/*Added For Issue ID 2717 - ICICI/AXIS bank Change - Ends Here*/
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="dcf_payment_dtls_m_seq")
	@SequenceGenerator(
			name="dcf_payment_dtls_m_seq",
			sequenceName="dcf_payment_dtls_m_seq",
			allocationSize=1
			)
	/*@AttributeOverrides({
	@AttributeOverride(name = "STRQUOTNUMBER",
	column = @Column(name="STRQUOTNUMBER")),
	@AttributeOverride(name = "STRPROPNUMBER",
	column = @Column(name="STRPROPNUMBER"))
	})*/
	public Long getLtransId() {
		return ltransId;
	}

	public void setLtransId(Long ltransId) {
		this.ltransId = ltransId;
	}
	
	public String getStrproposalno() {
		return strproposalno;
	}

	public void setStrproposalno(String strproposalno) {
		this.strproposalno = strproposalno;
	}

	public String getStrpolicyno() {
		return strpolicyno;
	}

	public void setStrpolicyno(String strpolicyno) {
		this.strpolicyno = strpolicyno;
	}

	public String getStrworkflowid() {
		return strworkflowid;
	}

	public void setStrworkflowid(String strworkflowid) {
		this.strworkflowid = strworkflowid;
	}

	public String getStrpaymentmode() {
		return strpaymentmode;
	}

	public void setStrpaymentmode(String strpaymentmode) {
		this.strpaymentmode = strpaymentmode;
	}

	public String getStrpaymentamount() {
		return strpaymentamount;
	}

	public void setStrpaymentamount(String strpaymentamount) {
		this.strpaymentamount = strpaymentamount;
	}

	public String getStrbalanceamt() {
		return strbalanceamt;
	}

	public void setStrbalanceamt(String strbalanceamt) {
		this.strbalanceamt = strbalanceamt;
	}

	public Date getStrpaymentinstrumentdt() {
		return strpaymentinstrumentdt;
	}

	public void setStrpaymentinstrumentdt(Date strpaymentinstrumentdt) {
		this.strpaymentinstrumentdt = strpaymentinstrumentdt;
	}

	public String getStrinstrumentno() {
		return strinstrumentno;
	}

	public void setStrinstrumentno(String strinstrumentno) {
		this.strinstrumentno = strinstrumentno;
	}

	public String getStrinstrumenttype() {
		return strinstrumenttype;
	}

	public void setStrinstrumenttype(String strinstrumenttype) {
		this.strinstrumenttype = strinstrumenttype;
	}

	public String getStradreceiptno() {
		return stradreceiptno;
	}

	public void setStradreceiptno(String stradreceiptno) {
		this.stradreceiptno = stradreceiptno;
	}

	public String getStradreceiptamt() {
		return stradreceiptamt;
	}

	public void setStradreceiptamt(String stradreceiptamt) {
		this.stradreceiptamt = stradreceiptamt;
	}

	public String getStradbalanceamt() {
		return stradbalanceamt;
	}

	public void setStradbalanceamt(String stradbalanceamt) {
		this.stradbalanceamt = stradbalanceamt;
	}

	public String getStrifsccd() {
		return strifsccd;
	}

	public void setStrifsccd(String strifsccd) {
		this.strifsccd = strifsccd;
	}

	public String getStrcustid() {
		return strcustid;
	}

	public void setStrcustid(String strcustid) {
		this.strcustid = strcustid;
	}

	public String getStrproducercd() {
		return strproducercd;
	}

	public void setStrproducercd(String strproducercd) {
		this.strproducercd = strproducercd;
	}

	public String getStrproductcd() {
		return strproductcd;
	}

	public void setStrproductcd(String strproductcd) {
		this.strproductcd = strproductcd;
	}

	public String getStrgcreceiptno() {
		return strgcreceiptno;
	}

	public void setStrgcreceiptno(String strgcreceiptno) {
		this.strgcreceiptno = strgcreceiptno;
	}

	public Date getDtcreated() {
		return dtcreated;
	}

	public void setDtcreated(Date dtcreated) {
		this.dtcreated = dtcreated;
	}

	public String getStrcreatedby() {
		return strcreatedby;
	}

	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}

	public Date getDtupdated() {
		return dtupdated;
	}

	public void setDtupdated(Date dtupdated) {
		this.dtupdated = dtupdated;
	}

	public String getStrupdatedby() {
		return strupdatedby;
	}

	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}

	public String getStripaddress() {
		return stripaddress;
	}

	public void setStripaddress(String stripaddress) {
		this.stripaddress = stripaddress;
	}

	public Date getStrpolicystartdt() {
		return strpolicystartdt;
	}

	public void setStrpolicystartdt(Date strpolicystartdt) {
		this.strpolicystartdt = strpolicystartdt;
	}

	public Date getStrpolicyenddt() {
		return strpolicyenddt;
	}

	public void setStrpolicyenddt(Date strpolicyenddt) {
		this.strpolicyenddt = strpolicyenddt;
	}

	public String getStrispayinslipgenerated() {
		return strispayinslipgenerated;
	}

	public void setStrispayinslipgenerated(String strispayinslipgenerated) {
		this.strispayinslipgenerated = strispayinslipgenerated;
	}

	public Date getDtpayinslipgenerated() {
		return dtpayinslipgenerated;
	}

	public void setDtpayinslipgenerated(Date dtpayinslipgenerated) {
		this.dtpayinslipgenerated = dtpayinslipgenerated;
	}

	public String getStrbusinessLocation() {
		return strbusinessLocation;
	}

	public void setStrbusinessLocation(String strbusinessLocation) {
		this.strbusinessLocation = strbusinessLocation;
	}

	public String getStrdepositofficecode() {
		return strdepositofficecode;
	}

	public void setStrdepositofficecode(String strdepositofficecode) {
		this.strdepositofficecode = strdepositofficecode;
	}

	public String getStrbusslocname() {
		return strbusslocname;
	}

	public void setStrbusslocname(String strbusslocname) {
		this.strbusslocname = strbusslocname;
	}

	public String getStrgcsubreceiptno() {
		return strgcsubreceiptno;
	}

	public void setStrgcsubreceiptno(String strgcsubreceiptno) {
		this.strgcsubreceiptno = strgcsubreceiptno;
	}

	/*Added New Column strnewrenewflag starts here*/
	public String getStrnewrenewflag() {
		return strnewrenewflag;
	}

	public void setStrnewrenewflag(String strnewrenewflag) {
		this.strnewrenewflag = strnewrenewflag;
	}
	/*Added New Column strnewrenewflag starts here*/

	/*public String getStrlob() {
		return strlob;
	}

	public void setStrlob(String strlob) {
		this.strlob = strlob;
	}

	public String getStrmodeofoperation() {
		return strmodeofoperation;
	}

	public void setStrmodeofoperation(String strmodeofoperation) {
		this.strmodeofoperation = strmodeofoperation;
	}

	public String getIsreceiptdeallocated() {
		return isreceiptdeallocated;
	}

	public void setIsreceiptdeallocated(String isreceiptdeallocated) {
		this.isreceiptdeallocated = isreceiptdeallocated;
	}*/

}

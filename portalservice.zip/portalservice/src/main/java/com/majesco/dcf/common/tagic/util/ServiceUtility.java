package com.majesco.dcf.common.tagic.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.log4j.Logger;

import com.majesco.dcf.common.tagic.errorhandler.ErrorHandlerUtility;
import com.majesco.dcf.common.tagic.impl.TagicCommonServiceImpl;
import com.majesco.dcf.common.tagic.json.EmailAttachment;
import com.majesco.dcf.common.tagic.json.PrintProposalReq;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;
import com.majesco.dcf.communication.json.MailVO;
import com.majesco.dcf.motor.serviceImpl.MotorServiceImpl;
import com.majesco.dcf.paproduct.serviceImpl.IPAServiceImpl;
import com.majesco.dcf.util.CXFInBoundInterceptor;
import com.majesco.dcf.util.CXFOutInterceptor;
import com.majesco.dcf.common.chp.util.CdataWriterInterceptor;

public class ServiceUtility {

	
private static Properties prop = new Properties();

final static Logger logger = Logger.getLogger(ServiceUtility.class);
	
	static{
		try{
	InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream("resource.properties");
	prop.load(inputStream);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public Client addClientInterceptor(Object portObj){  // Old method commented By Vishal
		
		Client client=ClientProxy.getClient(portObj);
		
		PrintWriter writer = new PrintWriter(System.out);
		client.getOutInterceptors().add(new CdataWriterInterceptor());
		client.getInInterceptors().add(new LoggingInInterceptor(writer));
		client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
		return client;
	}

	/*
	 *	New  method commented to Add logs into DB : Vishal : 14/03/2017 
	 */
	public Client addClientInterceptorDB(Object portObj,CXFInBoundInterceptor inBoundInterceptor,CXFOutInterceptor outInterceptor){  
		
		Client client=ClientProxy.getClient(portObj);
		
		PrintWriter writer = new PrintWriter(System.out);
		client.getOutInterceptors().add(new CdataWriterInterceptor());
		//client.getInInterceptors().add(new LoggingInInterceptor(writer));
		client.getInInterceptors().add(inBoundInterceptor);
		//client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
		client.getOutInterceptors().add(outInterceptor);
		
		HTTPConduit conduit=(HTTPConduit)client.getConduit();
		HTTPClientPolicy clientPolicy=new HTTPClientPolicy();
		clientPolicy.setReceiveTimeout(60000);
		clientPolicy.setConnectionTimeout(30000);
		conduit.setClient(clientPolicy);
		
		return client;
	}
	
	public String blankToNullCheck(String value)
	{
		if(value!=null && value.equalsIgnoreCase(""))
		{
			return null;
		}
		else if(value == null)
		{
			return null;
		}
		else
		{
			return value;
		}
	}
	
	public static String getClientIpAddr(HttpServletRequest request) 
	{
	   String ip = request.getHeader("X-Forwarded-For");
	   
	        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
	            ip = request.getHeader("Proxy-Client-IP");
	        }
	        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
	            ip = request.getHeader("WL-Proxy-Client-IP");
	        }
	        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
	            ip = request.getHeader("HTTP_CLIENT_IP");
	        }
	        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
	            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
	        }
	        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
	            ip = request.getRemoteAddr();
	        }
	        
	        return ip;
	}
	
	
	/**
	 * @return
	 */
	public String getPropertyCodeProperty(String propName, String propertyFileName){

		String responseFrom="";
		
		try {
		
			logger.info("getPropertyCodeProperty.getPropertyCodeProperty :: propFileName: " + propertyFileName);
			String propFileName = propertyFileName;
			Properties prop = new Properties();
			InputStream inputStream = MotorServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
			prop.load(inputStream);
			responseFrom=prop.getProperty(propName);
			logger.info("getPropertyCodeProperty.getPropertyCodeProperty :: response propValue: " + responseFrom);
		
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("getPropertyCodeProperty.getPropertyCodeProperty :: IOException: ", e);
		} catch (Exception ex){
			ex.printStackTrace();
			logger.error("getPropertyCodeProperty.getPropertyCodeProperty :: Exception: ", ex);
		}
		
		return responseFrom;	
	}
	
}

package com.majesco.dcf.common.tagic.impl;

import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.majesco.dcf.common.tagic.entity.CustomerEntity;
import com.majesco.dcf.common.tagic.entity.PaymentDetails;
import com.majesco.dcf.common.tagic.entity.UserTransaction;
import com.majesco.dcf.common.tagic.json.AddressDetails;
import com.majesco.dcf.common.tagic.json.AuthenticationResponse;
import com.majesco.dcf.common.tagic.json.BankDetails;
import com.majesco.dcf.common.tagic.json.ContactDetails;
import com.majesco.dcf.common.tagic.json.CreateCustomerRequest;
import com.majesco.dcf.common.tagic.json.CreateCustomerResponse;
import com.majesco.dcf.common.tagic.json.CustomerDetailRequest;
import com.majesco.dcf.common.tagic.json.CustomerDetailResponse;
import com.majesco.dcf.common.tagic.json.CustomerDetails;
import com.majesco.dcf.common.tagic.json.CustomerSearchDetails;
import com.majesco.dcf.common.tagic.json.CustomerSearchLiteRequest;
import com.majesco.dcf.common.tagic.json.CustomerSearchLiteResponse;
import com.majesco.dcf.common.tagic.json.CustomerSearchRequest;
import com.majesco.dcf.common.tagic.json.CustomerSearchResponse;
import com.majesco.dcf.common.tagic.json.IdDetails;
import com.majesco.dcf.common.tagic.json.PinCodeRequest;
import com.majesco.dcf.common.tagic.json.PinCodeResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.UpdateCustomerRequest;
import com.majesco.dcf.common.tagic.json.UpdateCustomerResponse;
import com.majesco.dcf.common.tagic.service.AuthenticationService;
import com.majesco.dcf.common.tagic.service.CustomerService;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.PinCodeService;
import com.majesco.dcf.common.tagic.util.CommonHelper;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.unotechsoft.stub.commonservice.generic.client.ArrayOfclsCustomerSearchForPortalGrid;
import com.unotechsoft.stub.commonservice.generic.client.ClsCustomerSearchForPortalGrid;
import com.unotechsoft.stub.commonservice.generic.client.ClsUserData;
import com.unotechsoft.stub.commonservice.generic.client.GenericIntegration;
import com.unotechsoft.stub.commonservice.generic.client.GenericIntegration_Service;
import com.unotechsoft.stub.customerservice.client.AddCustomer2;
import com.unotechsoft.stub.customerservice.client.AddCustomerResponse2;
import com.unotechsoft.stub.customerservice.client.ArrayOfLOVType;
import com.unotechsoft.stub.customerservice.client.Customer;
import com.unotechsoft.stub.customerservice.client.CustomerService_Service;
import com.unotechsoft.stub.customerservice.client.EditCustomer2;
import com.unotechsoft.stub.customerservice.client.EditCustomerResponse2;
import com.unotechsoft.stub.customerservice.client.GenericResult;
import com.unotechsoft.stub.customerservice.client.LOVType;
import com.unotechsoft.stub.customerservice.client.LOVTypeCustomer;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{
final static Logger logger = Logger.getLogger(CustomerServiceImpl.class);

	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/
	
	@Autowired
	AuthenticationService authServ;
	
	@Autowired
	DBService dbserv;
	
	@Autowired
	PinCodeService pinserv;
	
private String propValue;
	
private static Properties prop = new Properties();

static{
	try{
InputStream inputStream = CustomerServiceImpl.class.getClassLoader().getResourceAsStream("resource.properties");
prop.load(inputStream);
	}catch(Exception ex){
		ex.printStackTrace();
	}
}
	
	private String getWSDLURL(String param)
	{
		try
		{
			propValue = dbserv.getWSDLURL(param,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			return propValue;
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorServiceImpl :: getWSDLURL() method ::",ae);
		}
		return propValue;
	}

	
	@Override
	public CustomerDetailResponse getCustomerDetails(
			CustomerDetailRequest custoReq) throws Exception {
		
		CustomerDetailResponse custoRes = new CustomerDetailResponse();
		CustomerDetails customerDtl = new CustomerDetails();
		List<CustomerDetails> customerList = new ArrayList<CustomerDetails>();
		String inputReq = null;
		String responseStr= null;
		ObjectMapper objMap = new ObjectMapper();
				
		try{
			inputReq=objMap.writeValueAsString(custoReq);
			logger.info("Inside CreateCustomerService :: getCustomerDetails method :: Request from UI :: "+inputReq);
			
			String strURL=getWSDLURL(CommonConstants.CREATECUSTOMER_SERVICE);
			CustomerService_Service stub = new CustomerService_Service(new URL(strURL));
			com.unotechsoft.stub.customerservice.client.CustomerService port = stub.getSOAPOverHTTP();
			
			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(port);
			//if(logger.isDebugEnabled())logger.debug("Inside CustomerDetailService :: getCustomerDetails() method :: trying to connect to core system");
			
			StopWatch watch = new StopWatch();
			watch.start();
			
			Customer customerResponse=port.getCustomer(smc_source, smc_medium, smc_campaign, custoReq.getAuthToken(), custoReq.getCustomerID());
			watch.stop();
			logger.info("Time Taken by getCustomer service in seconds..>>"+watch.getTotalTimeSeconds());
			
			List<String> list = new ArrayList<String>();
			list.add("CustomerMapping.xml");
			Mapper mapper = (Mapper) new DozerBeanMapper(list);
			if(customerResponse!=null){
				//if(logger.isDebugEnabled())logger.debug("Inside CustomerDetailService :: getCustomerListDetails() method :: loading dozer mapping File..");
				mapper.map(customerResponse, customerDtl, "SearchCustomerID");
				
				//if(logger.isDebugEnabled())logger.debug("Inside CustomerDetailService :: getCustomerListDetails() method :: after dozer mapping::"+objMap.writeValueAsString(customerDtl));
				customerDtl = mapToInternalCode(customerDtl);
				customerDtl.setisThinCust(customerResponse.isIsThinCustomer());
				
				//Rahul Start: Added to retrieve email & sms values| Dozer issue
				if (customerResponse.getContactDetails()!=null ){
					ContactDetails contactDtlTagic = new ContactDetails();
					IdDetails idTagic = new IdDetails();
					AddressDetails addrsDtlsTagic = new AddressDetails(); //Changes By Ketan 07/11/2016
					BankDetails bankDtlsTagic = new BankDetails(); //Changes By Ketan 07/11/2016
					
					contactDtlTagic.setMobileNumber(customerResponse.getMailLocation().getContactDetails().getMobileNo()==null?"":customerResponse.getMailLocation().getContactDetails().getMobileNo()); //Changes By Ketan 07/11/2016
					contactDtlTagic.setEmailID(customerResponse.getEmailId());
					/*Changes By Ketan 07/11/2016*/
					if(customerResponse.getMailLocation()!=null && customerResponse.getMailLocation().getContactDetails()!=null && customerResponse.getMailLocation().getContactDetails().getLandLineSTD()!=null && customerResponse.getMailLocation().getContactDetails().getLandLineNo()!=null)
					{
						contactDtlTagic.setLandlinenumber(customerResponse.getMailLocation().getContactDetails().getLandLineNo());
						contactDtlTagic.setStd(customerResponse.getMailLocation().getContactDetails().getLandLineSTD());
					}
					/*Changes By Ketan 07/11/2016*/
					customerDtl.setContDetList(contactDtlTagic);
					
					idTagic.setIdType(String.valueOf(customerResponse.getIDProof()));
					idTagic.setIdNumber(customerResponse.getIDProofDetails());
					customerDtl.setIdList(idTagic);
					//addrsDtlsTagic.setNearLandmark(customerResponse.getMailLocation().getLandmark());
					
					// Start : 05-Apr-2017 : Changes done by Vishal for required address details
					//if(logger.isDebugEnabled())logger.debug("Inside CustomerDetailService :: getCustomerDetails() method :: LandMark::"+customerResponse.getPermanentLocation().getLandmark());
					if(customerDtl.getAddressDetList()!=null ){
							if(customerResponse.getPermanentLocation()!=null)
								customerDtl.getAddressDetList().setNearLandmark(customerResponse.getPermanentLocation().getLandmark()==null?"":customerResponse.getPermanentLocation().getLandmark());
						//customerDtl.getAddressDetList().setState(customerResponse.getPermanentLocation().getStateName()==null?"":customerResponse.getPermanentLocation().getStateName());	
					}					
					// Start : 05-Apr-2017 : Changes done by Vishal for required address details
					
//					addrsDtlsTagic.setCoName(customerResponse.getMailLocation().getMediatorName()); //Changes By Ketan 07/11/2016
//					addrsDtlsTagic.setNearLandmark(customerResponse.getMailLocation().getLandmark()); //Changes By Ketan 07/11/2016
//					customerDtl.setAddressDetList(addrsDtlsTagic); //Changes By Ketan 07/11/2016
					
					bankDtlsTagic.setNameasinBankAccount(customerResponse.getBankDetails().getAccountHolderName()==null?"":customerResponse.getBankDetails().getAccountHolderName()); //Changes By Ketan 07/11/2016
					bankDtlsTagic.setAccountNumber(customerResponse.getBankDetails().getBankAccNumber()==null?"":customerResponse.getBankDetails().getBankAccNumber()); //Changes By Ketan 07/11/2016
					bankDtlsTagic.setBranchName(customerResponse.getBankDetails().getBankBranchName()==null?"":customerResponse.getBankDetails().getBankBranchName()); //Changes By Ketan 07/11/2016
					bankDtlsTagic.setBankName(customerResponse.getBankDetails().getBankName()==null?"":customerResponse.getBankDetails().getBankName()); //Changes By Ketan 07/11/2016
					bankDtlsTagic.setIfsccode(customerResponse.getBankDetails().getIFSCCode()==null?"":customerResponse.getBankDetails().getIFSCCode()); //Changes By Ketan 07/11/2016   // for 1097 :Vishal : 04-Jul-2017
					bankDtlsTagic.setMicrcode(customerResponse.getBankDetails().getMICRCode()==null?"":customerResponse.getBankDetails().getMICRCode()); //Changes By Ketan 07/11/2016    // for 1097 :Vishal : 04-Jul-2017
					customerDtl.setBankdetList(bankDtlsTagic); //Changes By Ketan 07/11/2016
					
				}
				//Start:13/12/2016:Changes done to set ID details and bank details in response.
				IdDetails idTagic = new IdDetails();
				BankDetails bankDtlsTagic = new BankDetails(); //Changes By Ketan 07/11/2016
				idTagic.setIdType(String.valueOf(customerResponse.getIDProof()));
				idTagic.setIdNumber(customerResponse.getIDProofDetails());
				customerDtl.setIdList(idTagic);
				bankDtlsTagic.setNameasinBankAccount(customerResponse.getBankDetails().getAccountHolderName()==null?"":customerResponse.getBankDetails().getAccountHolderName()); //Changes By Ketan 07/11/2016
				bankDtlsTagic.setAccountNumber(customerResponse.getBankDetails().getBankAccNumber()==null?"":customerResponse.getBankDetails().getBankAccNumber()); //Changes By Ketan 07/11/2016
				bankDtlsTagic.setBranchName(customerResponse.getBankDetails().getBankBranchName()==null?"":customerResponse.getBankDetails().getBankBranchName()); //Changes By Ketan 07/11/2016
				bankDtlsTagic.setBankName(customerResponse.getBankDetails().getBankName()==null?"":customerResponse.getBankDetails().getBankName()); //Changes By Ketan 07/11/2016
				bankDtlsTagic.setIfsccode(customerResponse.getBankDetails().getIFSCCode()==null?"":customerResponse.getBankDetails().getIFSCCode()); //Changes By Ketan 07/11/2016 // for 1097 :Vishal : 04-Jul-2017
				bankDtlsTagic.setMicrcode(customerResponse.getBankDetails().getMICRCode()==null?"":customerResponse.getBankDetails().getMICRCode()); //Changes By Ketan 07/11/2016 // for 1097 :Vishal : 04-Jul-2017
				customerDtl.setBankdetList(bankDtlsTagic); //Changes By Ketan 07/11/2016
				//End:13/12/2016:Changes done to set ID details and bank details in response.
				//Rahul End:Added to retrieve email & sms values| Dozer issue 
				
				//Start: RahulT<1213>| Added to fetch customer GST number & Aadhar number
				customerDtl.setGstNumber(customerResponse.getGSTNumber());
				//End: RahulT<1213>| Added to fetch customer GST number & Aadhar number
				
				// Start : 11-May-2017 :Code added to give City,District & Country info into address details : by Vishal 
				PinCodeRequest pinReq = new PinCodeRequest();
				pinReq.setNpincode(Integer.parseInt(customerDtl.getAddressDetList().getPincode()));
				PinCodeResponse pinRes   =    pinserv.FetchPinCodeInfo(pinReq);
				customerDtl.getAddressDetList().setCity(pinRes.getStrcityval());
				customerDtl.getAddressDetList().setDistrict(pinRes.getStrdistrictval());
				customerDtl.getAddressDetList().setCountry(pinRes.getStrcountryval());
				customerDtl.getAddressDetList().setState(pinRes.getStrstateval());
				// End : 11-May-2017 :Code added to give City,District & Country info into address details : by Vishal
				
				customerList.add(customerDtl);
				custoRes.setCustDetails(customerList);
				custoRes.setResultCode("1");
			}else{
				//if(logger.isDebugEnabled())logger.debug("Inside CustomerDetailService :: getCustomerDetails() method :: null response returned from core system..");
				custoRes.setResultCode("0");
				List<ResponseError> resErr=new ArrayList<ResponseError>();
				ResponseError error=new ResponseError();
				error.setErrorCode("ERR001");
				error.setErrorMMessag("No data found !!");
				resErr.add(error);
				custoRes.setResErr(resErr);
			}
			
			responseStr=objMap.writeValueAsString(custoRes);
			logger.info("Inside CreateCustomerService :: getCustomerDetails method :: Response Object :: "+responseStr);
			
		}catch(Exception ex){
			logger.error("Inside CustomerDetailService :: getCustomerDetails() method ::",ex);
			ex.printStackTrace();
			custoRes.setResultCode("0");
			List<ResponseError> resErr=new ArrayList<ResponseError>();
			ResponseError error=new ResponseError();
			error.setErrorCode("ERR100");
			error.setErrorMMessag(ex.getMessage());
			resErr.add(error);
			custoRes.setResErr(resErr);
		}
		return custoRes;
	}

	@Override
	public CustomerDetailResponse getCustomerListDetails(
			CustomerDetailRequest custoReq) throws Exception {
		
		CustomerDetailResponse response=new CustomerDetailResponse();
		List<CustomerDetails> custList=null;
		ObjectMapper objMap=new ObjectMapper();
		String responseStr =null;
		try{
			
			String strURL=getWSDLURL(CommonConstants.CREATECUSTOMER_SERVICE);
			CustomerService_Service customerStub=new CustomerService_Service(new URL(strURL));
			//CustomerService_Service customerStub=new CustomerService_Service(new URL("http://172.17.203.26:9595/CustomerService_SOAPOverHTTP?wsdl"));
			com.unotechsoft.stub.customerservice.client.CustomerService customerPort=customerStub.getSOAPOverHTTP();
			String source=smc_source;
			String medium=smc_medium;
			String campaingn=smc_campaign;
			String strLVTokenID=null; // authentication token
			String strLVCustomerName=null;
			String strLVCustomerId=null;
			String strLVCustomerType=null;
			String strLVState=null;
			String strLVCityDistrict=null;
			String strLVAreaVillage=null;
			String strLVPincode=null;
			String strLVPincodeLocality=null;
			String strLVIntrEmpTag=null;
			String strLVUserId=null;
			String strJsonInput=null;
			
			ObjectMapper jsonMap=new ObjectMapper();
			strJsonInput=jsonMap.writeValueAsString(custoReq);
			
			logger.info("Inside CustomerDetailService :: getCustomerListDetails() input request ::"+strJsonInput);
			
			if(custoReq!=null && custoReq.getAuthToken()!=null)
				strLVTokenID=custoReq.getAuthToken();
			
			if(custoReq!=null && custoReq.getCustomerID()!=null && !custoReq.getCustomerID().equalsIgnoreCase(""))
				strLVCustomerId=custoReq.getCustomerID();
			
			if(custoReq!=null && custoReq.getPinCode()!=null && !custoReq.getPinCode().equalsIgnoreCase(""))
				strLVPincode=custoReq.getPinCode();
			if(custoReq!=null && custoReq.getCustomerDetails()!=null && custoReq.getUserID()!=null && !custoReq.getUserID().equalsIgnoreCase(""))
				strLVUserId=custoReq.getUserID();
			
			if(custoReq!=null && custoReq.getCustomerType()!=null && !custoReq.getCustomerType().equalsIgnoreCase("")){
				strLVCustomerType=custoReq.getCustomerType();
			}
			
			/*if(custoReq!=null && custoReq.getCustomerType()!=null && custoReq.getCustomerType().equals("I")){
				strLVCustomerType="Individual";
			}
			else if (custoReq!= null && custoReq.getCustomerType()!=null && custoReq.getCustomerType().equals("O")){
				strLVCustomerType="Organization";
			}*/
			
			strLVCustomerName=custoReq.getFirstName();
			if(strLVCustomerName!=null && !strLVCustomerName.equalsIgnoreCase("")){
				
				if(custoReq.getLastName()!=null && !custoReq.getLastName().equalsIgnoreCase("")){
					strLVCustomerName=strLVCustomerName+" "+custoReq.getLastName();
				}
			}
			
			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(customerPort);
			
			//if(logger.isDebugEnabled())logger.debug("Inside CustomerDetailService :: getCustomerListDetails() method trying to call getLOVCustomer()::");
			StopWatch watch = new StopWatch();
			watch.start();
			GenericResult result= customerPort.getLOVCustomer(source, medium, campaingn, strLVTokenID, strLVCustomerName, strLVCustomerId, strLVCustomerType, strLVState, strLVCityDistrict, strLVAreaVillage, strLVPincode, strLVPincodeLocality, strLVIntrEmpTag, strLVUserId);
			watch.stop();
			logger.info("Time Taken by getLOVCustomer service in seconds..>>"+watch.getTotalTimeSeconds());
			//GenericResult result = new GenericResult();
			ArrayOfLOVType arrLovType=result.getLOVTypes();
			List<LOVType> customerList=arrLovType.getLOVType();
			if(customerList!=null && customerList.size()>0){
				//if(logger.isDebugEnabled())logger.debug("Inside CustomerDetailService :: getCustomerListDetails() method :: received response from core system");
				
				LOVTypeCustomer customer=null;
				custList=new ArrayList<CustomerDetails>();
				CustomerDetails custDetails=null;
				AddressDetails address=null;
				IdDetails idDetail=null;
				for(int i=0;i<customerList.size();i++){
					customer=(LOVTypeCustomer)customerList.get(i);
					
					if(customer!=null){
						//if(logger.isDebugEnabled())logger.debug("Inside CustomerDetailService :: getCustomerListDetails() method :: Customer ID "+customer.getCustomerID());
						custDetails=new CustomerDetails();
						address=new AddressDetails();
						idDetail=new IdDetails();
						
						custDetails.setCustId(customer.getCustomerID());
						custDetails.setFirstName(customer.getCustomerName());
						//custDetails.setCusoType(customer.getCustomerType());
						if (customer.getCustomerType()!=null && customer.getCustomerType().equalsIgnoreCase("Individual"))
							custDetails.setCusoType("I");
						if (customer.getCustomerType()!=null && customer.getCustomerType().equalsIgnoreCase("Organization"))
							custDetails.setCusoType("O");
						custDetails.setCreationDate(customer.getInsertDate());
						address.setCity(customer.getCityDistrict());
						address.setPincode(customer.getPinCode());
						custDetails.setAddressDetList(address);
						if(customer.getStartDate()!=null)
						custDetails.setCreationDate(customer.getStartDate());
						else
							custDetails.setCreationDate(CommonConstants.BLANK_STRING);
					custList.add(custDetails);
					
					}
				}
				
				response.setCustDetails(custList);
				response.setResultCode("1");
				
			}else{
				//if(logger.isDebugEnabled())logger.debug("Inside CustomerDetailService :: getCustomerListDetails() method :: no customer list data received from core system");
				response.setResultCode("0");
				List<ResponseError> resErr=new ArrayList<>();
				ResponseError error=new ResponseError();
				error.setErrorCode("ERR001");
				error.setErrorMMessag("No Data Found !!");
				resErr.add(error);
				response.setResErr(resErr);
			}
			
			responseStr=objMap.writeValueAsString(custoReq);
			//if(logger.isDebugEnabled())logger.debug("Inside CreateCustomerService :: getCustomerListDetails method :: Request from UI :: "+responseStr);
			
			try{
				CustomerSearchRequest customerSearchRequest=new CustomerSearchRequest();
			
			customerSearchRequest.setFirstName(custoReq.getFirstName());
			customerSearchRequest.setLastName(custoReq.getLastName());
			customerSearchRequest.setPinCode(custoReq.getPinCode());
			customerSearchRequest.setProducerCode(custoReq.getProducerCode());
			List<CustomerEntity> customerEntityList=dbserv.getCustomerSearchDetailsFromPortal(CommonConstants.CUSTOMER_ENTITY_CLASSNAME, customerSearchRequest);
			}catch(Exception ex){
				logger.error("Inside CustomerDetailService :: getCustomerListDetails() method ::",ex);
			}
		}catch(Exception ex){
			logger.error("Inside CustomerDetailService :: getCustomerListDetails() method ::",ex);
			ex.printStackTrace();
			response.setResultCode("0");
			List<ResponseError> resErr=new ArrayList<>();
			ResponseError error=new ResponseError();
			error.setErrorCode("ERR100");
			error.setErrorMMessag(ex.getMessage());
			resErr.add(error);
			response.setResErr(resErr);
		}
		
		return response;
	}
	
	// Create customer code 
	@Override
	public CreateCustomerResponse createCustomer(CreateCustomerRequest objCreateCust) throws Exception
 {

		logger.info("Inside CreateCustomerService :: createCustomer method :: Execution Started");
		CreateCustomerResponse cretRes = new CreateCustomerResponse();
		String inputReq = null;
		String responseStr = null;
		String customerIDGC = null;
		String errorText = null;
		boolean thinCust = false;
		CustomerDetails custDet = null;
		ObjectMapper objMap = new ObjectMapper();
		String strFullName=null;
		try {
			String uniqueCustID = null;

			inputReq = objMap.writeValueAsString(objCreateCust);
			//if(logger.isDebugEnabled())logger.debug("Inside CreateCustomerService :: createCustomer method :: Request from UI :: "+ inputReq);
			
			custDet = objCreateCust.getCustomerDet();
			
			objCreateCust = mapToExternalCode(objCreateCust);
			if (objCreateCust != null && objCreateCust.getCustomerDet() != null) {
				// objCreateCust.getCustomerDet().setisThinCust(true);
				if (objCreateCust.getCustomerDet().getIsThinCust())
					thinCust = true;
			}

			Customer customer = CommonHelper.TransformCreateCustReqObj(objCreateCust);
			if (customer != null && objCreateCust != null && objCreateCust.getCustomerType().equals("I")) {
				customer.setSourceOfFund("SALARY");
			}
			
			//Rahul Start: Added to retrieve email & sms values| Dozer issue
			// commented since below has been handled in commonHelper.java
			/*if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getContDetList()!=null){
				com.unotechsoft.stub.customerservice.client.ContactDetails contactDtlGc =  new com.unotechsoft.stub.customerservice.client.ContactDetails();
				contactDtlGc.setMobileNo(objCreateCust.getCustomerDet().getContDetList().getMobileNumber());
				customer.setContactDetails(contactDtlGc);
				customer.setEmailId(objCreateCust.getCustomerDet().getContDetList().getEmailID());
				
				if (objCreateCust.getCustomerDet().getIdList() != null){
					customer.setIDProof(Integer.parseInt(objCreateCust.getCustomerDet().getIdList().getIdType()));
					customer.setIDProofDetails(objCreateCust.getCustomerDet().getIdList().getIdNumber());
				}
			}*/
			// End: commented since below has been handled in commonHelper.java
			//Rahul End:Added to retrieve email & sms values| Dozer issue 

			if(objCreateCust.getUserID()!=null && !objCreateCust.getUserID().equalsIgnoreCase(""))
				customer.setUserID(objCreateCust.getUserID());
			else
			customer.setUserID("gcwinuat05");
			// customer.setIsThinCustomer(true);
			customer.setIsThinCustomer(thinCust);

			if(customer.getCustomerType()!=null && customer.getCustomerType().equalsIgnoreCase("O")){
				customer.setCustomerType("C");
			
			}
			
			inputReq = objMap.writeValueAsString(objCreateCust);
			//if(logger.isDebugEnabled())logger.debug("Inside CreateCustomerService :: createCustomer method :: UI Object after external code mapping :: "+ inputReq);
			List<ResponseError> reserrList;
			reserrList = new ArrayList<ResponseError>();
			ResponseError res = new ResponseError();
			CustomerService_Service stub = new CustomerService_Service(new URL(
							this.getWSDLURL(CommonConstants.CREATECUSTOMER_SERVICE)));
			com.unotechsoft.stub.customerservice.client.CustomerService port = stub.getSOAPOverHTTP();

			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);

			String userID = objCreateCust.getUserID();
			String password = objCreateCust.getPassword();
			//AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
			
			if(objCreateCust.getCustomerDet().getCustId() == null || objCreateCust.getCustomerDet().getCustId().equalsIgnoreCase("")){
				
				AddCustomer2 addCustomer = new AddCustomer2();
				addCustomer.setStrLVTokenID(objCreateCust.getAuthToken());

				if (customer != null && customer.getPermanentLocation() != null) {
					customer.setMailLocation(customer.getPermanentLocation());
				}

				addCustomer.setObjCVCustomer(customer);
				StopWatch watch = new StopWatch();
				watch.start();
				AddCustomerResponse2 objResponse = port.addCustomer(addCustomer);
				watch.stop();
				logger.info("Time Taken by addCustomer service in seconds..>>"+watch.getTotalTimeSeconds());
				if (objResponse.getAddCustomerResult() != null) {
					uniqueCustID = objResponse.getAddCustomerResult().getID();
					errorText = objResponse.getAddCustomerResult()
							.getErrorText();
				}
				
				//Changes done for reverse mapping
				custDet = mapToInternalCode(objCreateCust.getCustomerDet());

				cretRes.setCustomerDet(custDet);

				if (uniqueCustID != null && !uniqueCustID.equals("")
						&& (errorText == null || errorText.equalsIgnoreCase(""))) {
					String parts[] = uniqueCustID.split("\\$\\$");
					customerIDGC = parts[0];
					cretRes.setCustomerID(customerIDGC);
					cretRes.setResultCode("1");
					reserrList.add(res);
					
					// Setting customer ID in inner Customer object
					cretRes.getCustomerDet().setCustId(customerIDGC);

					//Persisting data into transaction table for Save customer service.
					UserTransaction transaction = new UserTransaction();
					transaction.setStrCustomerId(customerIDGC);
					transaction.setDtCreated(new Date());
					transaction.setDtTrans(new Date());
					transaction.setStrCreatedBy(userID);
					transaction.setStrlob("Common");
					transaction.setStrProducercd(userID);
					transaction.setStrTranstype("Create Customer");
					transaction.setStrUserid(userID);
					dbserv.saveOrUpdate(transaction);
					
					
					
					//Start:21/02/2017:Added to save customer key data into portal DB
					try{
						//if(logger.isDebugEnabled())
						logger.debug("Inside CustomerServiceImpl :: createCustomer method :: Saving Customer Entity");
					CustomerEntity customerEntity=new CustomerEntity();
					customerEntity.setStrcustomerid(customerIDGC);
					if(objCreateCust.getCustomerType()!=null)
					customerEntity.setStrcustomertype(objCreateCust.getCustomerType());
					
					if(objCreateCust.getCustomerDet()!=null)
					customerEntity.setStrdob(objCreateCust.getCustomerDet().getDob());
					
					if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getContDetList()!=null)
					customerEntity.setStremail(objCreateCust.getCustomerDet().getContDetList().getEmailID());
					
					if(objCreateCust.getCustomerDet()!=null){
						if(objCreateCust.getCustomerDet().getCusoType()!=null && objCreateCust.getCustomerDet().getCusoType().equalsIgnoreCase(CommonConstants.IndividualCustomer))
							customerEntity.setStrfirstname(objCreateCust.getCustomerDet().getFirstName());
						else if(objCreateCust.getCustomerDet().getCusoType()!=null && objCreateCust.getCustomerDet().getCusoType().equalsIgnoreCase(CommonConstants.OrganizationCustomer))
							customerEntity.setStrfirstname(objCreateCust.getCustomerDet().getOrganizationName());
					}
					
					
					if(objCreateCust.getCustomerDet()!=null)
						customerEntity.setStrmiddlename(objCreateCust.getCustomerDet().getMiddleName());
						
						if(objCreateCust.getCustomerDet()!=null)
							customerEntity.setStrlastname(objCreateCust.getCustomerDet().getLastName());
						
						if(objCreateCust.getCustomerDet()!=null)
						customerEntity.setStrgender(objCreateCust.getCustomerDet().getGender());
						
						if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getIdList()!=null)
						customerEntity.setStridnumber(objCreateCust.getCustomerDet().getIdList().getIdNumber());
						
						if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getIdList()!=null)
						customerEntity.setStridtype(objCreateCust.getCustomerDet().getIdList().getIdType());
						
						if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getContDetList()!=null)
						customerEntity.setStrmobile(objCreateCust.getCustomerDet().getContDetList().getMobileNumber());
						
						if(customer.getPermanentLocation()!=null && customer.getPermanentLocation().getPinCode()!=null)
						customerEntity.setStrpincode(customer.getPermanentLocation().getPinCode());
						
						if(customer.getPermanentLocation()!=null && customer.getPermanentLocation().getStateCode()!=null)
							customerEntity.setStrstatecode(customer.getPermanentLocation().getStateCode());
							
						if(customer.getPermanentLocation()!=null && customer.getPermanentLocation().getCityId()!=null)
							customerEntity.setStrcitycode(customer.getPermanentLocation().getCityId());
						
						customerEntity.setStrproducercode(objCreateCust.getProducerCode());
						
						customerEntity.setDtcreated(new Date());
						customerEntity.setStrcreatedby(objCreateCust.getUserID());
						customerEntity.setStripaddress(objCreateCust.getSystemIP());
						
						if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getAadharNo()!=null)
							customerEntity.setStraadharno(objCreateCust.getCustomerDet().getAadharNo());
						
						//Start: RahulT <Production 1213>| code added to send GST Number in add customer request
						if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getGstNumber()!=null)
							customerEntity.setStrgstnumber(objCreateCust.getCustomerDet().getGstNumber());
						//End: RahulT <Production 1213>| code added to send GST Number in add customer request
						
						dbserv.saveOrUpdate(customerEntity);
						//if(logger.isDebugEnabled())
							logger.debug("Inside CustomerServiceImpl :: createCustomer method :: After Saving Customer Entity");
					}catch(Exception ex){
						logger.error("Inside CustomerServiceImpl :: createCustomer method :: Saving Customer Entity", ex);
					}
					//End:21/02/2017:Added to save customer key data into portal DB
					
				} else {

					res.setErrorCode("ERR");
					res.setErrorMMessag(errorText);
					reserrList.add(res);
					cretRes.setResultCode("0");
				}
			} else {
				
				//Start: @Yogesh added if-block for isCustModified flag for DefectID-1841 31/08/2017 
				if (objCreateCust.getIsCustModified()!=null && objCreateCust.getIsCustModified().equalsIgnoreCase("true")) {
								
					//Start| RahulT <1257> | code commented to invoke editCustomer service call.
					//Start|Showbhik|1841|SIT|Code uncommented to invoke editCustomer service call.
					//if(customer.isIsThinCustomer()){
						EditCustomer2 editCustomer = new EditCustomer2();
						editCustomer.setStrLVTokenID(objCreateCust.getAuthToken());  // Vishal : <1841>
	
						if (customer != null && customer.getPermanentLocation() != null) {
							customer.setMailLocation(customer.getPermanentLocation());
						}
						customer.setCustomerUniqueID(objCreateCust.getCustomerDet().getCustId());
						customer.setIsThinCustomer(false);
						customer.setID(objCreateCust.getCustomerDet().getCustId());		// Added, based on Amol's mail on Wed 5/10/2017 12:07 PM
						editCustomer.setObjCVCustomer(customer);
						EditCustomerResponse2 objResponse = port.editCustomer(editCustomer);
						//port.editCustomer(editCustomer);
						if (objResponse.getEditCustomerResult() != null) {
							uniqueCustID = objResponse.getEditCustomerResult().getID();
							errorText = objResponse.getEditCustomerResult()
									.getErrorText();
						}
						
					//}//End|Showbhik|1841|SIT|Code uncommented to invoke editCustomer service call.
					//End| RahulT <1257> | code commented to invoke editCustomer service call.
					//Changes done for reverse mapping
					custDet = mapToInternalCode(objCreateCust.getCustomerDet());
					
					
					if(errorText==null || errorText.equalsIgnoreCase("")){
						cretRes.setCustomerDet(custDet);
						cretRes.setCustomerID(objCreateCust.getCustomerDet()
								.getCustId());
						cretRes.setResultCode("1");
					}else{
						cretRes.setCustomerDet(custDet);
						cretRes.setCustomerID(objCreateCust.getCustomerDet()
								.getCustId());
						cretRes.setResultCode("0");
						res.setErrorCode("ERR01");
						res.setErrorMMessag(errorText);
					}
				
				}  
				else{
					custDet = mapToInternalCode(objCreateCust.getCustomerDet());
					cretRes.setCustomerDet(custDet);
					cretRes.setCustomerID(objCreateCust.getCustomerDet()
							.getCustId());
					cretRes.setResultCode("1");
				}//End: @Yogesh added if-block for isCustModified flag for DefectID-1841 31/08/2017
			}
			reserrList.add(res);
			cretRes.setErrList(reserrList);
			
		} catch (Exception e) {
			e.printStackTrace();
			List<ResponseError> reserrList;
			reserrList = new ArrayList<ResponseError>();
			ResponseError res = new ResponseError();
			res.setErrorCode("ERR");
			res.setErrorMMessag(e.getMessage());
			reserrList.add(res);
			cretRes.setErrList(reserrList);
		}
		responseStr = objMap.writeValueAsString(cretRes);
		/*if(logger.isDebugEnabled())logger.debug("Inside CreateCustomerService :: createCustomer method :: response from GC :: "
				+ responseStr);*/
		logger.info("Inside CreateCustomerService :: createCustomer method :: Execution Completed Successfully");

		return cretRes;
	}
	
	private CreateCustomerRequest mapToExternalCode(CreateCustomerRequest objCreateCust){
		try{
		if(objCreateCust!=null){
			if(objCreateCust.getCustomerDet()!=null){
				//gender
				if(objCreateCust.getCustomerDet().getGender()!=null && !objCreateCust.getCustomerDet().getGender().equalsIgnoreCase(""))
					objCreateCust.getCustomerDet().setGender(dbserv.getExternalMapCode(null, objCreateCust.getCustomerDet().getGender(), CommonConstants.GENDERCD_SYSTEM_PARAMCD));
				//occupation
				/*if(objCreateCust.getCustomerDet().getOccupation()!=null && !objCreateCust.getCustomerDet().getOccupation().equalsIgnoreCase(""))
					objCreateCust.getCustomerDet().setOccupation(dbserv.getExternalMapCode(null, objCreateCust.getCustomerDet().getOccupation(), CommonConstants.OCCUPATION_SYSTEM_PARAMCD));*/
				//marital status
				if(objCreateCust.getCustomerDet().getMaritalstatus()!=null && !objCreateCust.getCustomerDet().getMaritalstatus().equalsIgnoreCase(""))
					objCreateCust.getCustomerDet().setMaritalstatus(dbserv.getExternalMapCode(null, objCreateCust.getCustomerDet().getMaritalstatus(), CommonConstants.MARITALSTATUS_SYSTEM_PARAMCD));
				// title
				if(objCreateCust.getCustomerDet().getTitle()!=null && !objCreateCust.getCustomerDet().getTitle().equalsIgnoreCase(""))
					objCreateCust.getCustomerDet().setTitle(dbserv.getExternalMapCode(null, objCreateCust.getCustomerDet().getTitle(), CommonConstants.TITLE_SYSTEM_PARAMCD));
				//nationality
				if(objCreateCust.getCustomerDet().getNationality()!=null && !objCreateCust.getCustomerDet().getNationality().equalsIgnoreCase(""))
					objCreateCust.getCustomerDet().setNationality(dbserv.getExternalMapCode(null, objCreateCust.getCustomerDet().getNationality(), CommonConstants.NATIONALITY_SYSTEM_PARAMCD));
				
				//ID type
				if(objCreateCust.getCustomerDet().getIdList()!=null && objCreateCust.getCustomerDet().getIdList().getIdType()!=null
						&& !objCreateCust.getCustomerDet().getIdList().getIdType().equalsIgnoreCase("")){
					if (objCreateCust.getCustomerDet().getIdList().getIdType().equals("1")){
						objCreateCust.setPancardNum(objCreateCust.getCustomerDet().getIdList().getIdNumber());
					}
					//objCreateCust.getCustomerDet().getIdList().setIdType(dbserv.getExternalMapCode(null, objCreateCust.getCustomerDet().getIdList().getIdType(), CommonConstants.IDTYPE_SYSTEM_PARAMCD));
				}
				
			}
		}
		}catch(Exception ex){
			ex.printStackTrace();
			logger.error("mapToExternalCode ::", ex);
		}
		return objCreateCust;
	}
	
	@Override
	public CustomerSearchLiteResponse getLightCustomerDetails(CustomerSearchLiteRequest custreq) throws Exception
	{
		
		logger.info("Inside CustomerSearchLiteService :: getCustomerDetails method :: Execution Started");
		
		CustomerSearchLiteResponse cusres = new CustomerSearchLiteResponse();
		cusres.setProducercode("AGT11023");
		List<CustomerDetails> lstCustDet = new ArrayList<CustomerDetails>();
		List<IdDetails> lstidDetails = new ArrayList<IdDetails>();
		List<AddressDetails> lstaddDet = new ArrayList<AddressDetails>();
		CustomerDetails custDet = new CustomerDetails();
		IdDetails idDet = new IdDetails();
		AddressDetails addDet = new AddressDetails ();
		idDet.setIdNumber("H2511200");
		idDet.setIdType("PASSPORT");
		lstidDetails.add(idDet);
		addDet.setCity("MUMBAI");
		lstaddDet.add(addDet);

		custDet.setFirstName("Ankit");
		custDet.setMiddleName("K");
		custDet.setLastName("Sharma");
		custDet.setCustId("1000034986");
		custDet.setCreationDate("27-JUNE-1986");
		
		lstCustDet.add(custDet);
		cusres.setLstCustDet(lstCustDet);
		
		List<ResponseError>reserrList = new ArrayList<ResponseError>();
		
		ResponseError res = new ResponseError();
		res.setErrorCode("101");
		res.setErrorMMessag("Sorry Authentication Issue....");
		reserrList.add(res);
		cusres.setLstResErr(reserrList);
		
		logger.info("Inside CustomerSearchLiteService :: getCustomerDetails method :: Execution Completed Successfully");
		
		return cusres;
	}
	
	@Override
	public UpdateCustomerResponse updateCustomer(UpdateCustomerRequest updtreq) throws Exception
	{
		
		logger.info("Inside UpdateCustomerService :: updateCustomer method :: Execution Started");
		
		UpdateCustomerResponse updtres = new UpdateCustomerResponse();
		
		List<ResponseError> reserrList;
		
		updtres.setCustomerDet(updtreq.getCustomerDet());
		
		reserrList = new ArrayList<ResponseError>();
		
		ResponseError res = new ResponseError();
		res.setErrorCode("101");
		res.setErrorMMessag("Sorry Authentication Issue....");
		reserrList.add(res);
		updtres.setErrList(reserrList);
		
		logger.info("Inside UpdateCustomerService :: updateCustomer method :: Execution Completed Successfully");
		
		return updtres;
	}
	
	public CustomerSearchLiteResponse getCustomerDetails(CustomerSearchLiteRequest custreq) throws Exception
	{
		
		logger.info("Inside CustomerSearchLiteService :: getCustomerDetails method :: Execution Started");
		
		CustomerSearchLiteResponse cusres = new CustomerSearchLiteResponse();
		cusres.setProducercode("AGT11023");
		List<CustomerDetails> lstCustDet = new ArrayList<CustomerDetails>();
		List<IdDetails> lstidDetails = new ArrayList<IdDetails>();
		List<AddressDetails> lstaddDet = new ArrayList<AddressDetails>();
		CustomerDetails custDet = new CustomerDetails();
		IdDetails idDet = new IdDetails();
		AddressDetails addDet = new AddressDetails ();
		idDet.setIdNumber("H2511200");
		idDet.setIdType("PASSPORT");
		lstidDetails.add(idDet);
		addDet.setCity("MUMBAI");
		lstaddDet.add(addDet);

		custDet.setFirstName("Ankit");
		custDet.setMiddleName("K");
		custDet.setLastName("Sharma");
		custDet.setCustId("1000034986");
		custDet.setCreationDate("27-JUNE-1986");
		
		lstCustDet.add(custDet);
		cusres.setLstCustDet(lstCustDet);
		
		List<ResponseError>reserrList = new ArrayList<ResponseError>();
		
		ResponseError res = new ResponseError();
		res.setErrorCode("101");
		res.setErrorMMessag("Sorry Authentication Issue....");
		reserrList.add(res);
		cusres.setLstResErr(reserrList);
		
		logger.info("Inside CustomerSearchLiteService :: getCustomerDetails method :: Execution Completed Successfully");
		
		return cusres;
	}
	
	private CustomerDetails mapToInternalCode(CustomerDetails customerDtl){
		try{
		if(customerDtl!=null){
				//gender
				if(customerDtl.getGender()!=null && !customerDtl.getGender().equalsIgnoreCase(""))
					customerDtl.setGender(dbserv.getReverseExternalMapCode(null, CommonConstants.GENDERCD_SYSTEM_PARAMCD, customerDtl.getGender()));
				//occupation
				/*if(objCreateCust.getCustomerDet().getOccupation()!=null && !objCreateCust.getCustomerDet().getOccupation().equalsIgnoreCase(""))
					objCreateCust.getCustomerDet().setOccupation(dbserv.getExternalMapCode(null, objCreateCust.getCustomerDet().getOccupation(), CommonConstants.OCCUPATION_SYSTEM_PARAMCD));*/
				//marital status
				if(customerDtl.getMaritalstatus()!=null && !customerDtl.getMaritalstatus().equalsIgnoreCase(""))
					customerDtl.setMaritalstatus(dbserv.getReverseExternalMapCode(null, CommonConstants.MARITALSTATUS_SYSTEM_PARAMCD, customerDtl.getMaritalstatus()));
				// title
				if(customerDtl.getTitle()!=null && !customerDtl.getTitle().equalsIgnoreCase(""))
					customerDtl.setTitle(dbserv.getReverseExternalMapCode(null, CommonConstants.TITLE_SYSTEM_PARAMCD, customerDtl.getTitle()));
				//nationality
				if(customerDtl.getNationality()!=null && !customerDtl.getNationality().equalsIgnoreCase(""))
					customerDtl.setNationality(dbserv.getReverseExternalMapCode(null, CommonConstants.NATIONALITY_SYSTEM_PARAMCD, customerDtl.getNationality()));
				
				//ID type
				/*if(customerDtl.getIdList()!=null && customerDtl.getIdList().getIdType()!=null){
					customerDtl.getIdList().setIdType(dbserv.getReverseExternalMapCode(null, customerDtl.getIdList().getIdType(), CommonConstants.IDTYPE_SYSTEM_PARAMCD));
				}*/
				if (customerDtl.getCusoType()!=null && customerDtl.getCusoType().equals("Individual")){
					customerDtl.setCusoType("I");
				}
				else if (customerDtl.getCusoType()!=null && customerDtl.getCusoType().equals("Organization")){
					customerDtl.setCusoType("O");
				}
		}
		}catch(Exception ex){
			ex.printStackTrace();
			logger.error("mapToExternalCode ::", ex);
		}
		return customerDtl;
	}
	
	private static String _strClassName="CustomerServiceImpl";
	
	public CustomerSearchResponse searchCustomer(CustomerSearchRequest customerSearchRequest) throws Exception{
		
		CustomerSearchResponse customerSearchResponse=null;
		String strMethodName="searchCustomer";
		
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			
			dbserv.getCustomerIdUserTrans(CommonConstants.USERTRANSACTION_ENTITY_CLASSNAME, customerSearchRequest);
			
			String serviceUrl=getWSDLURL(CommonConstants.GENERIC_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			GenericIntegration_Service genericService=new GenericIntegration_Service(wsdlUrl);
			GenericIntegration port=genericService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);
			
			String _customerSearchForPortalGetObjectData_source = smc_source;
	        String _customerSearchForPortalGetObjectData_medium = smc_medium;
	        String _customerSearchForPortalGetObjectData_campaingn = smc_campaign;
	        String _customerSearchForPortalGetObjectData_strLVTokenID = "";
	        if(customerSearchRequest!=null && customerSearchRequest.getAuthToken()!=null)
	        	_customerSearchForPortalGetObjectData_strLVTokenID=customerSearchRequest.getAuthToken();
	        String _customerSearchForPortalGetObjectData_strCustomerID = "";
	        if(customerSearchRequest.getCustomerCode()!=null)
	        	_customerSearchForPortalGetObjectData_strCustomerID=customerSearchRequest.getCustomerCode();
	        String _customerSearchForPortalGetObjectData_strCustomerName = customerSearchRequest.getFirstName();
	        if(_customerSearchForPortalGetObjectData_strCustomerName!=null && !_customerSearchForPortalGetObjectData_strCustomerName.equals("")){
	        	
	        	if(customerSearchRequest.getLastName()!=null && !customerSearchRequest.getLastName().equals(""))
	        		_customerSearchForPortalGetObjectData_strCustomerName=_customerSearchForPortalGetObjectData_strCustomerName.concat(" ").concat(customerSearchRequest.getLastName());
	        }
	        String _customerSearchForPortalGetObjectData_strVehRegdNo = customerSearchRequest.getRegistrationNo();
	        String _customerSearchForPortalGetObjectData_strQuotationNo = customerSearchRequest.getQuotationNo();
	        String _customerSearchForPortalGetObjectData_strProposalNo = customerSearchRequest.getProposalNo();
	        String _customerSearchForPortalGetObjectData_strPolicyNo = customerSearchRequest.getPolicyNo();
	        String _customerSearchForPortalGetObjectData_strDOB = customerSearchRequest.getDateOfBirth();
	        String _customerSearchForPortalGetObjectData_strMobileNo = customerSearchRequest.getMobileNo();
	        String _customerSearchForPortalGetObjectData_strPincode = customerSearchRequest.getPinCode();
	        String _customerSearchForPortalGetObjectData_strCity = customerSearchRequest.getCityCode();
	        String _customerSearchForPortalGetObjectData_strReceiptNo = customerSearchRequest.getReceiptNo();
	        String _customerSearchForPortalGetObjectData_strClaimNo = customerSearchRequest.getClaimNo();
	        String _customerSearchForPortalGetObjectData_strCreatedDate = customerSearchRequest.getCreateDateFrom();
	        String _customerSearchForPortalGetObjectData_strProducerCode = customerSearchRequest.getProducerCode();
	        String _customerSearchForPortalGetObjectData_strUserId = customerSearchRequest.getUserID();
	        String _customerSearchForPortalGetObjectData_strCreatedToDate = customerSearchRequest.getCreateDateTo();
	        String _customerSearchForPortalGetObjectData_strState = customerSearchRequest.getStateCode();
			
	        StopWatch watch = new StopWatch();
	        watch.start();
	        
			com.unotechsoft.stub.commonservice.generic.client.ServiceResult _customerSearchForPortalGetObjectData__return = port.customerSearchForPortalGetObjectData(_customerSearchForPortalGetObjectData_source, _customerSearchForPortalGetObjectData_medium, _customerSearchForPortalGetObjectData_campaingn, _customerSearchForPortalGetObjectData_strLVTokenID, _customerSearchForPortalGetObjectData_strCustomerID, _customerSearchForPortalGetObjectData_strCustomerName, _customerSearchForPortalGetObjectData_strVehRegdNo, _customerSearchForPortalGetObjectData_strQuotationNo, _customerSearchForPortalGetObjectData_strProposalNo, _customerSearchForPortalGetObjectData_strPolicyNo, _customerSearchForPortalGetObjectData_strDOB, _customerSearchForPortalGetObjectData_strMobileNo, _customerSearchForPortalGetObjectData_strPincode, _customerSearchForPortalGetObjectData_strState, _customerSearchForPortalGetObjectData_strCity, _customerSearchForPortalGetObjectData_strReceiptNo, _customerSearchForPortalGetObjectData_strClaimNo, _customerSearchForPortalGetObjectData_strCreatedDate, _customerSearchForPortalGetObjectData_strCreatedToDate, _customerSearchForPortalGetObjectData_strProducerCode, _customerSearchForPortalGetObjectData_strUserId);
			watch.stop();
			logger.info("Time Taken by customerSearchForPortalGetObjectData service in seconds..>>"+watch.getTotalTimeSeconds());
			if(_customerSearchForPortalGetObjectData__return!=null && _customerSearchForPortalGetObjectData__return.getUserData()!=null){
				customerSearchResponse = new CustomerSearchResponse();
				ClsUserData clsUserData= _customerSearchForPortalGetObjectData__return.getUserData();
				if(clsUserData!=null && clsUserData.getCustomerSearchForPortalGrid()!=null){
					ArrayOfclsCustomerSearchForPortalGrid arrayOfclsCustomerSearchForPortalGrid=clsUserData.getCustomerSearchForPortalGrid();
					
					if(arrayOfclsCustomerSearchForPortalGrid.getClsCustomerSearchForPortalGrid()!=null && arrayOfclsCustomerSearchForPortalGrid.getClsCustomerSearchForPortalGrid().size()>0){
						List<ClsCustomerSearchForPortalGrid> clsCustomerSearchForPortalGridList=arrayOfclsCustomerSearchForPortalGrid.getClsCustomerSearchForPortalGrid();
						int listSize=clsCustomerSearchForPortalGridList.size();
						ClsCustomerSearchForPortalGrid clsCustomerSearchForPortalGrid=null;
						ArrayList<CustomerSearchDetails> customerSearchDetailsList=new ArrayList<CustomerSearchDetails>();
						CustomerSearchDetails customerSearchDetails=null;
						for(int i=0;i<listSize;i++){
							customerSearchDetails=new CustomerSearchDetails();
							clsCustomerSearchForPortalGrid=clsCustomerSearchForPortalGridList.get(i);
							
							customerSearchDetails.setCustomerCode(clsCustomerSearchForPortalGrid.getCustomerId());
							customerSearchDetails.setCityName(clsCustomerSearchForPortalGrid.getCityName());
							customerSearchDetails.setCustomerName(clsCustomerSearchForPortalGrid.getCustomerName());
							customerSearchDetails.setCreateDate(clsCustomerSearchForPortalGrid.getCreatedDate());
							customerSearchDetails.setDateOfBirth(clsCustomerSearchForPortalGrid.getDateofBirth());
							customerSearchDetails.setMobileNo(clsCustomerSearchForPortalGrid.getMobileNo());
							customerSearchDetails.setNoOfPolicy(clsCustomerSearchForPortalGrid.getNoOfPolicy());
							customerSearchDetails.setNoOfProposal(clsCustomerSearchForPortalGrid.getNoOfProposal());
							customerSearchDetails.setNoOfQuote(clsCustomerSearchForPortalGrid.getNoOfQuotes());
							customerSearchDetails.setPinCode(clsCustomerSearchForPortalGrid.getPinCode());
							customerSearchDetails.setIntermediaryCode(clsCustomerSearchForPortalGrid.getProducerCode());
							
							customerSearchDetailsList.add(customerSearchDetails);
						}
						
						customerSearchResponse.setCustomerSearchDetailsList(customerSearchDetailsList);
						customerSearchResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
					}
				}
			}
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
		}catch(Exception ex){
			logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
			customerSearchResponse = new CustomerSearchResponse();
			customerSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			throw ex;
		}
		
		return customerSearchResponse;
	}
	
	
	public CustomerDetailResponse getCustomerListDetailsFromPortal(CustomerDetailRequest custoReq) throws Exception{
		
		CustomerDetailResponse response=new CustomerDetailResponse();
		List<CustomerDetails> custList=null;
		ObjectMapper objMap=new ObjectMapper();
		String responseStr =null;
		String strMethodName="getCustomerListDetailsFromPortal";
		try{
			logger.info("Inside ::"+_strClassName+"::"+strMethodName+"::Entered");
			//if(logger.isDebugEnabled())logger.debug("Inside ::"+_strClassName+"::"+strMethodName+"::JSON Request "+objMap.writeValueAsString(custoReq));
			CustomerSearchRequest customerSearchRequest=new CustomerSearchRequest();
		/*if(custoReq.getCustomerDetails().getCusoType() != null && custoReq.getCustomerDetails().getCusoType().equalsIgnoreCase(CommonConstants.IndividualCustomer)){
			customerSearchRequest.setFirstName(custoReq.getFirstName());	
		}else if(custoReq.getCustomerDetails().getCusoType() != null && custoReq.getCustomerDetails().getCusoType().equalsIgnoreCase(CommonConstants.OrganizationCustomer)){
			customerSearchRequest.setFirstName(custoReq.getCustomerDetails().getOrganizationName()==null ? "" : custoReq.getCustomerDetails().getOrganizationName());
		}*/		
		customerSearchRequest.setFirstName(custoReq.getFirstName());
		customerSearchRequest.setLastName(custoReq.getLastName());
		customerSearchRequest.setPinCode(custoReq.getPinCode());
		customerSearchRequest.setProducerCode(custoReq.getProducerCode());
		customerSearchRequest.setCusoType(custoReq.getCustomerType());
		List<CustomerEntity> customerEntityList=dbserv.getCustomerSearchDetailsFromPortal(CommonConstants.CUSTOMER_ENTITY_CLASSNAME, customerSearchRequest);
		if(customerEntityList!=null && customerEntityList.size()>0){
		custList=new ArrayList<CustomerDetails>();
		CustomerDetails custDetails=null;
		AddressDetails address=null;
		IdDetails idDetail=null;
		String strCityName=null;
		for(CustomerEntity customerEntity:customerEntityList){
			
			if(customerEntity!=null){
				custDetails=new CustomerDetails();
				custDetails.setCustId(customerEntity.getStrcustomerid());
				custDetails.setFirstName(customerEntity.getStrfirstname()!=null?customerEntity.getStrfirstname().toUpperCase():CommonConstants.BLANK_STRING);
				custDetails.setLastName(customerEntity.getStrlastname()!=null?customerEntity.getStrlastname().toUpperCase():CommonConstants.BLANK_STRING);
				custDetails.setMiddleName(customerEntity.getStrmiddlename()!=null?customerEntity.getStrmiddlename().toUpperCase():CommonConstants.BLANK_STRING);
				custDetails.setCusoType(customerEntity.getStrcustomertype());
				SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
				sdf.format(customerEntity.getDtcreated());
				custDetails.setCreationDate(sdf.format(customerEntity.getDtcreated()));
				if(customerEntity.getStrcustomertype().equalsIgnoreCase(CommonConstants.OrganizationCustomer)){
					custDetails.setOrganizationName(customerEntity.getStrfirstname()!=null?customerEntity.getStrfirstname().toUpperCase():CommonConstants.BLANK_STRING);	
				}				
				address=new AddressDetails();
				
				address.setPincode(customerEntity.getStrpincode());
				//strCityName=dbserv.getDistrictCityNameByCode(CommonConstants.CITY_ENTITY_CLASSNAME, customerEntity.getStrcitycode(), "C");
				strCityName=dbserv.getCityNameByCode(CommonConstants.CITY_ENTITY_CLASSNAME, customerEntity.getStrcitycode(), "C");
				address.setCity(strCityName);
				
				custDetails.setAddressDetList(address);
				custList.add(custDetails);
			}
		}
		
		response.setCustDetails(custList);
		response.setResultCode("1");
		
		}else{
			//if(logger.isDebugEnabled())logger.debug("Inside CustomerDetailService :: getCustomerListDetails() method :: no customer list data received from core system");
			response.setResultCode("0");
			List<ResponseError> resErr=new ArrayList<>();
			ResponseError error=new ResponseError();
			error.setErrorCode("ERR001");
			error.setErrorMMessag("No Data Found !!");
			resErr.add(error);
			response.setResErr(resErr);
		}
		}catch(Exception ex){
			logger.error("Inside ::"+_strClassName+"::"+strMethodName+"::",ex);
		}
		
		responseStr=objMap.writeValueAsString(response);
		//if(logger.isDebugEnabled())
		logger.debug("Inside ::"+_strClassName+"::"+strMethodName+":: Response::"+responseStr);
		
		logger.info("Inside ::"+_strClassName+"::"+strMethodName+"::Exit");
		return response;
	}
	
	public CustomerSearchResponse searchCustomerFromPortal(CustomerSearchRequest customerSearchRequest) throws Exception{
        
        CustomerSearchResponse customerSearchResponse=null;
        String strMethodName="searchCustomerFromPortal";
        String strClientCd=null;
        String receiptNumber =null;
        HashMap<String, UserTransaction> clientIdMap = null; // Code changes for issue 1226 : 30/06/2017 : VishalJ : **
        List<String> customerSearchReqUTStr=null;
        List<CustomerEntity> customerEntityList=new ArrayList<CustomerEntity>();
        List<CustomerEntity> customerEntityListDB=new ArrayList<CustomerEntity>();
        ObjectMapper mapper = new ObjectMapper();
        PaymentDetails paymentDet = new PaymentDetails();
        try{
                        logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
                        //if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+":: Request Customer Search :- "+mapper.writeValueAsString(customerSearchRequest));
                        if(customerSearchRequest!=null){
                        	       if(customerSearchRequest.getReceiptNo()==null||customerSearchRequest.getReceiptNo().equals( CommonConstants.BLANK_STRING)){
                        		   receiptNumber =""; 		
                        	       }
                        	      else
                                	{
                        		  receiptNumber =customerSearchRequest.getReceiptNo();
                        		  paymentDet = dbserv.getCustomerDetails(receiptNumber);
                                  customerSearchRequest.setPolicyNo(paymentDet.getStrpolicyno());
                        	       }
                                                  	//Code changes for defect 1240.
                                        
                                        if ((customerSearchRequest.getQuotationNo() != null && !customerSearchRequest
                                                                        .getQuotationNo().equals(CommonConstants.BLANK_STRING))
                                                                        || (customerSearchRequest.getProposalNo() != null && !customerSearchRequest
                                                                                                        .getProposalNo().equals(
                                                                                                                                        CommonConstants.BLANK_STRING))
                                                                        || (customerSearchRequest.getPolicyNo() != null && !customerSearchRequest
                                                                                                        .getPolicyNo().equals(
                                                                                                                                        CommonConstants.BLANK_STRING))
                                                                        // Code changes for issue 1226 : 30/06/2017 : VishalJ : Start                                                               		
                                                                        ||(customerSearchRequest.getVehicleRegistrationNumber1() != null && !customerSearchRequest
                                                                                .getVehicleRegistrationNumber1().equals(
                                                                                        CommonConstants.BLANK_STRING))
                                                                        ||(customerSearchRequest.getVehicleRegistrationNumber2() != null && !customerSearchRequest
                                                                                .getVehicleRegistrationNumber2().equals(
                                                                                        CommonConstants.BLANK_STRING))
                                                                        ||(customerSearchRequest.getVehicleRegistrationNumber3() != null && !customerSearchRequest
                                                                                .getVehicleRegistrationNumber3().equals(
                                                                                        CommonConstants.BLANK_STRING))
                                                                        ||(customerSearchRequest.getVehicleRegistrationNumber4() != null && !customerSearchRequest
                                                                                .getVehicleRegistrationNumber4().equals(
                                                                                        CommonConstants.BLANK_STRING))) 
                                            							// Code changes for issue 1226 : 30/06/2017 : VishalJ : End
                                        			{
                                                        
                                                        clientIdMap=dbserv.getCustomerIdUserTrans(CommonConstants.USERTRANSACTION_ENTITY_CLASSNAME, customerSearchRequest); // Code changes for issue 1226 : 30/06/2017 : VishalJ : **
                                                        
                                                        if(clientIdMap!=null && clientIdMap.size()>0){
                                                        				logger.debug("Inside ::"+_strClassName+"::"+strMethodName+":: VJ 0"+clientIdMap.size());
                                                                        Set<String> clientCdKeySet=clientIdMap.keySet();
                                                                        logger.debug("Inside ::"+_strClassName+"::"+strMethodName+":: VJ 0.0"+clientCdKeySet.size());
                                                                        if(clientCdKeySet!=null){
                                                                                        Iterator<String> clientCdItr=clientCdKeySet.iterator();
                                                                                        customerSearchReqUTStr = new ArrayList<String>(); // Code changes for issue 1226 : 30/06/2017 : VishalJ : **	
                                                                                        while(clientCdItr.hasNext()){
                                                                                                        strClientCd=clientCdItr.next();
                                                                                                        logger.debug("Inside ::"+_strClassName+"::"+strMethodName+":: VJ 0.1"+strClientCd);
                                                                                                        if(strClientCd!=null)
                                                                                                        {
                                                                                                        	//customerSearchRequest.setCustomerCode(strClientCd);
                                                                                                        	customerSearchReqUTStr.add(strClientCd);// Code changes for issue 1226 : 30/06/2017 : VishalJ : **
                                                                                                        }
                                                                                        }
                                                                        }
                                                        }

                                        }
                                        
                                     // Code changes for issue 1226 : 30/06/2017 : VishalJ : Start  
                                        if(clientIdMap!=null && clientIdMap.size()>0){
                                        	logger.debug("Inside ::"+_strClassName+"::"+strMethodName+":: VJ 1"+customerSearchReqUTStr.size());
                                        	for (String customerNoTempStr : customerSearchReqUTStr) {                   
                                        		customerSearchRequest.setCustomerCode(customerNoTempStr);
                                        		logger.debug("Inside ::"+_strClassName+"::"+strMethodName+":: VJ 1.1 Fetching details for Customer No #####:- "+customerSearchRequest.getCustomerCode());	
                                        		customerEntityListDB=dbserv.getCustomerSearchDetailsFromPortal(CommonConstants.CUSTOMER_ENTITY_CLASSNAME, customerSearchRequest);
                                        		
                                        		logger.debug("Inside ::"+_strClassName+"::"+strMethodName+":: VJ 2"+customerEntityListDB.size());
                                        		
                                        		if(customerEntityListDB!=null &&customerEntityListDB.size()>0) 
                                        			customerEntityList.add(customerEntityListDB.get(0));	
											}
                                        	
                                        	logger.debug("Inside ::"+_strClassName+"::"+strMethodName+":: VJ 3"+customerEntityList.size());
                                        }else{                                     // Code changes for issue 1226 : 30/06/2017 : VishalJ : End
                                        	
                                        	logger.debug("Inside ::"+_strClassName+"::"+strMethodName+":: JV 1"+customerEntityList.size());
                                        	customerEntityList=dbserv.getCustomerSearchDetailsFromPortal(CommonConstants.CUSTOMER_ENTITY_CLASSNAME, customerSearchRequest);	
                                        }                                                                               
                                        
                                        if(customerEntityList!=null && customerEntityList.size()>0){
                                                        customerSearchResponse = new CustomerSearchResponse();
                                                        CustomerSearchDetails customerSearchDetails=null;
                                                        ArrayList<CustomerSearchDetails> customerSearchDetailsList=new ArrayList<CustomerSearchDetails>();
                                                        StringBuffer strFullName=null;
                                                        SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
                                                        String strCityName="";
                                                        for(CustomerEntity customerEntity:customerEntityList){
                                                                        
                                                                        if(customerEntity!=null){
                                                                                        customerSearchDetails=new CustomerSearchDetails();
                                                                                        strFullName = new StringBuffer();                                                                                                           
                                                                                        customerSearchDetails.setCustomerCode(customerEntity.getStrcustomerid());
                                                                                        strCityName=dbserv.getCityNameByCode(CommonConstants.CITY_ENTITY_CLASSNAME, customerEntity.getStrcitycode(), "C");
                                                                                        customerSearchDetails.setCityName(strCityName);
                                                                                        strFullName.append(customerEntity.getStrfirstname());
                                                                                        if(customerEntity.getStrmiddlename()!=null && !customerEntity.getStrmiddlename().equals(CommonConstants.BLANK_STRING))
                                                                                                        strFullName.append(" "+customerEntity.getStrmiddlename());
                                                                                        if(customerEntity.getStrlastname()!=null && !customerEntity.getStrlastname().equals(CommonConstants.BLANK_STRING))
                                                                                                        strFullName.append(" "+customerEntity.getStrlastname());
                                                                                        customerSearchDetails.setCustomerName(strFullName.toString().toUpperCase());
                                                                                        customerSearchDetails.setCreateDate(sdf.format(customerEntity.getDtcreated()));
                                                                                        customerSearchDetails.setDateOfBirth(customerEntity.getStrdob());
                                                                                        customerSearchDetails.setMobileNo(customerEntity.getStrmobile());
                                                                                        /*customerSearchDetails.setNoOfPolicy(clsCustomerSearchForPortalGrid.getNoOfPolicy());
                                                                                        customerSearchDetails.setNoOfProposal(clsCustomerSearchForPortalGrid.getNoOfProposal());
                                                                                        customerSearchDetails.setNoOfQuote(clsCustomerSearchForPortalGrid.getNoOfQuotes());*/
                                                                                        customerSearchDetails.setPinCode(customerEntity.getStrpincode());
                                                                                        customerSearchDetails.setIntermediaryCode(customerEntity.getStrproducercode());
                                                                                        
                                                                                        customerSearchDetailsList.add(customerSearchDetails);
                                                                                        
                                                                        }
                                                        }
                                                        
                                                        customerSearchResponse.setCustomerSearchDetailsList(customerSearchDetailsList);
                                                        customerSearchResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
                                        }else{
                                                        customerSearchResponse = new CustomerSearchResponse();
                                                        customerSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
                                                        List<ResponseError> resErr=new ArrayList<>();
                                                        ResponseError error=new ResponseError();
                                                        error.setErrorCode("ERR001");
                                                        error.setErrorMMessag("No Data Found !!");
                                                        resErr.add(error);
                                                        customerSearchResponse.setResponseError(resErr);
                                                        customerSearchResponse.setMessage("No Data Found!");                                                                        
                                        }

                        }
                        
                        
        }catch(Exception ex){
                        logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
                        customerSearchResponse = new CustomerSearchResponse();
                        customerSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
                        throw ex;
        }
        logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
        return customerSearchResponse;
	}

  //<1840> : Vishal J : Method to edit customer deatails. : Start
 	@Override
	public CreateCustomerResponse editCustomer(CreateCustomerRequest objCreateCust) throws Exception
 {

		logger.info("Inside CustomerServiceImpl :: editCustomer method :: Execution Started");
		CreateCustomerResponse cretRes = new CreateCustomerResponse();
		String inputReq = null;
		String responseStr = null;
		String customerIDGC = null;
		String errorText = null;
		boolean thinCust = false;
		CustomerDetails custDet = null;
		ObjectMapper objMap = new ObjectMapper();
		String strFullName=null;
		try {
			String uniqueCustID = null;

			inputReq = objMap.writeValueAsString(objCreateCust);
			//if(logger.isDebugEnabled())logger.debug("Inside CustomerServiceImpl :: editCustomer method :: Request from UI :: "+ inputReq);
			
			custDet = objCreateCust.getCustomerDet();
			
			objCreateCust = mapToExternalCode(objCreateCust);
			if (objCreateCust != null && objCreateCust.getCustomerDet() != null) {
				// objCreateCust.getCustomerDet().setisThinCust(true);
				if (objCreateCust.getCustomerDet().getIsThinCust())
					thinCust = true;
			}

			Customer customer = CommonHelper.TransformCreateCustReqObj(objCreateCust);
			if (customer != null && objCreateCust != null && objCreateCust.getCustomerType().equals("I")) {
				customer.setSourceOfFund("SALARY");
			}
			
			//Rahul Start: Added to retrieve email & sms values| Dozer issue
			// commented since below has been handled in commonHelper.java
			/*if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getContDetList()!=null){
				com.unotechsoft.stub.customerservice.client.ContactDetails contactDtlGc =  new com.unotechsoft.stub.customerservice.client.ContactDetails();
				contactDtlGc.setMobileNo(objCreateCust.getCustomerDet().getContDetList().getMobileNumber());
				customer.setContactDetails(contactDtlGc);
				customer.setEmailId(objCreateCust.getCustomerDet().getContDetList().getEmailID());
				
				if (objCreateCust.getCustomerDet().getIdList() != null){
					customer.setIDProof(Integer.parseInt(objCreateCust.getCustomerDet().getIdList().getIdType()));
					customer.setIDProofDetails(objCreateCust.getCustomerDet().getIdList().getIdNumber());
				}
			}*/
			// End: commented since below has been handled in commonHelper.java
			//Rahul End:Added to retrieve email & sms values| Dozer issue 

			if(objCreateCust.getUserID()!=null && !objCreateCust.getUserID().equalsIgnoreCase(""))
				customer.setUserID(objCreateCust.getUserID());
			else
			customer.setUserID("gcwinuat05");
			// customer.setIsThinCustomer(true);
			customer.setIsThinCustomer(thinCust);

			if(customer.getCustomerType()!=null && customer.getCustomerType().equalsIgnoreCase("O")){
				customer.setCustomerType("C");
			
			}
			
			inputReq = objMap.writeValueAsString(objCreateCust);
			//if(logger.isDebugEnabled())logger.debug("Inside CustomerServiceImpl :: editCustomer method :: UI Object after external code mapping :: "+ inputReq);
			List<ResponseError> reserrList;
			reserrList = new ArrayList<ResponseError>();
			ResponseError res = new ResponseError();
			CustomerService_Service stub = new CustomerService_Service(new URL(
							this.getWSDLURL(CommonConstants.CREATECUSTOMER_SERVICE)));
			com.unotechsoft.stub.customerservice.client.CustomerService port = stub.getSOAPOverHTTP();

			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);

			String userID = objCreateCust.getUserID();
			String password = objCreateCust.getPassword();
			//AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
			
			if(objCreateCust.getCustomerDet().getCustId() == null || objCreateCust.getCustomerDet().getCustId().equalsIgnoreCase("")){
				
				AddCustomer2 addCustomer = new AddCustomer2();
				addCustomer.setStrLVTokenID(objCreateCust.getAuthToken());

				if (customer != null && customer.getPermanentLocation() != null) {
					customer.setMailLocation(customer.getPermanentLocation());
				}
				
				addCustomer.setObjCVCustomer(customer);
				StopWatch watch = new StopWatch();
				watch.start();
				AddCustomerResponse2 objResponse = port.addCustomer(addCustomer);
				watch.stop();
				logger.info("Time Taken by addCustomer service in seconds..>>"+watch.getTotalTimeSeconds());
				if (objResponse.getAddCustomerResult() != null) {
					uniqueCustID = objResponse.getAddCustomerResult().getID();
					errorText = objResponse.getAddCustomerResult()
							.getErrorText();
				}
				
				//Changes done for reverse mapping
				custDet = mapToInternalCode(objCreateCust.getCustomerDet());

				cretRes.setCustomerDet(custDet);

				if (uniqueCustID != null && !uniqueCustID.equals("")
						&& (errorText == null || errorText.equalsIgnoreCase(""))) {
					String parts[] = uniqueCustID.split("\\$\\$");
					customerIDGC = parts[0];
					cretRes.setCustomerID(customerIDGC);
					cretRes.setResultCode("1");
					reserrList.add(res);
					
					// Setting customer ID in inner Customer object
					cretRes.getCustomerDet().setCustId(customerIDGC);

					//Persisting data into transaction table for Save customer service.
					UserTransaction transaction = new UserTransaction();
					transaction.setStrCustomerId(customerIDGC);
					transaction.setDtCreated(new Date());
					transaction.setDtTrans(new Date());
					transaction.setStrCreatedBy(userID);
					transaction.setStrlob("Common");
					transaction.setStrProducercd(userID);
					transaction.setStrTranstype("Create Customer");
					transaction.setStrUserid(userID);
					dbserv.saveOrUpdate(transaction);
					
					
					
					//Start:21/02/2017:Added to save customer key data into portal DB
					try{
						//if(logger.isDebugEnabled())
						logger.debug("Inside ServiceImpl :: editCustomer method :: Saving Customer Entity");
					CustomerEntity customerEntity=new CustomerEntity();
					customerEntity.setStrcustomerid(customerIDGC);
					if(objCreateCust.getCustomerType()!=null)
					customerEntity.setStrcustomertype(objCreateCust.getCustomerType());
					
					if(objCreateCust.getCustomerDet()!=null)
					customerEntity.setStrdob(objCreateCust.getCustomerDet().getDob());
					
					if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getContDetList()!=null)
					customerEntity.setStremail(objCreateCust.getCustomerDet().getContDetList().getEmailID());
					
					if(objCreateCust.getCustomerDet()!=null){
						if(objCreateCust.getCustomerDet().getCusoType()!=null && objCreateCust.getCustomerDet().getCusoType().equalsIgnoreCase(CommonConstants.IndividualCustomer))
							customerEntity.setStrfirstname(objCreateCust.getCustomerDet().getFirstName());
						else if(objCreateCust.getCustomerDet().getCusoType()!=null && objCreateCust.getCustomerDet().getCusoType().equalsIgnoreCase(CommonConstants.OrganizationCustomer))
							customerEntity.setStrfirstname(objCreateCust.getCustomerDet().getOrganizationName());
					}
					
					
					if(objCreateCust.getCustomerDet()!=null)
						customerEntity.setStrmiddlename(objCreateCust.getCustomerDet().getMiddleName());
						
						if(objCreateCust.getCustomerDet()!=null)
							customerEntity.setStrlastname(objCreateCust.getCustomerDet().getLastName());
						
						if(objCreateCust.getCustomerDet()!=null)
						customerEntity.setStrgender(objCreateCust.getCustomerDet().getGender());
						
						if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getIdList()!=null)
						customerEntity.setStridnumber(objCreateCust.getCustomerDet().getIdList().getIdNumber());
						
						if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getIdList()!=null)
						customerEntity.setStridtype(objCreateCust.getCustomerDet().getIdList().getIdType());
						
						if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getContDetList()!=null)
						customerEntity.setStrmobile(objCreateCust.getCustomerDet().getContDetList().getMobileNumber());
						
						if(customer.getPermanentLocation()!=null && customer.getPermanentLocation().getPinCode()!=null)
						customerEntity.setStrpincode(customer.getPermanentLocation().getPinCode());
						
						if(customer.getPermanentLocation()!=null && customer.getPermanentLocation().getStateCode()!=null)
							customerEntity.setStrstatecode(customer.getPermanentLocation().getStateCode());
							
						if(customer.getPermanentLocation()!=null && customer.getPermanentLocation().getCityId()!=null)
							customerEntity.setStrcitycode(customer.getPermanentLocation().getCityId());
						
						customerEntity.setStrproducercode(objCreateCust.getProducerCode());
						
						customerEntity.setDtcreated(new Date());
						customerEntity.setStrcreatedby(objCreateCust.getUserID());
						customerEntity.setStripaddress(objCreateCust.getSystemIP());
						
						if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getAadharNo()!=null)
							customerEntity.setStraadharno(objCreateCust.getCustomerDet().getAadharNo());
						
						//Start: RahulT <Production 1213>| code added to send GST Number in add customer request
						if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getGstNumber()!=null)
							customerEntity.setStrgstnumber(objCreateCust.getCustomerDet().getGstNumber());
						//End: RahulT <Production 1213>| code added to send GST Number in add customer request
						
						dbserv.saveOrUpdate(customerEntity);
						//if(logger.isDebugEnabled())
							logger.debug("Inside CustomerServiceImpl :: editCustomer method :: After Saving Customer Entity");
					}catch(Exception ex){
						logger.error("Inside CustomerServiceImpl :: editCustomer method :: Saving Customer Entity", ex);
					}
					//End:21/02/2017:Added to save customer key data into portal DB
					
				} else {

					res.setErrorCode("ERR");
					res.setErrorMMessag(errorText);
					reserrList.add(res);
					cretRes.setResultCode("0");
				}
			} else {
				//Start| RahulT <1257> | code commented to invoke editCustomer service call.
				//if(customer.isIsThinCustomer()){
					EditCustomer2 editCustomer = new EditCustomer2();
					editCustomer.setStrLVTokenID(objCreateCust.getAuthToken());

					if (customer != null && customer.getPermanentLocation() != null) {
						customer.setMailLocation(customer.getPermanentLocation());
					}
					customer.setCustomerUniqueID(objCreateCust.getCustomerDet().getCustId());
					customer.setIsThinCustomer(false);
					customer.setID(objCreateCust.getCustomerDet().getCustId());		// Added, based on Amol's mail on Wed 5/10/2017 12:07 PM
					editCustomer.setObjCVCustomer(customer);
					EditCustomerResponse2 objResponse = port.editCustomer(editCustomer);
					//port.editCustomer(editCustomer);
					if (objResponse.getEditCustomerResult() != null) {
						uniqueCustID = objResponse.getEditCustomerResult().getID();
						errorText = objResponse.getEditCustomerResult()
								.getErrorText();
					}
					
				//}
				//End| RahulT <1257> | code commented to invoke editCustomer service call.
				//Changes done for reverse mapping
				custDet = mapToInternalCode(objCreateCust.getCustomerDet());
				
				
				if(errorText==null || errorText.equalsIgnoreCase("")){
					cretRes.setCustomerDet(custDet);
					cretRes.setCustomerID(objCreateCust.getCustomerDet()
							.getCustId());
					cretRes.setResultCode("1");
				}else{
					cretRes.setCustomerDet(custDet);
					cretRes.setCustomerID(objCreateCust.getCustomerDet()
							.getCustId());
					cretRes.setResultCode("0");
					res.setErrorCode("ERR01");
					res.setErrorMMessag(errorText);
				}
			}
			reserrList.add(res);
			cretRes.setErrList(reserrList);
			
		} catch (Exception e) {
			e.printStackTrace();
			List<ResponseError> reserrList;
			reserrList = new ArrayList<ResponseError>();
			ResponseError res = new ResponseError();
			res.setErrorCode("ERR");
			res.setErrorMMessag(e.getMessage());
			reserrList.add(res);
			cretRes.setErrList(reserrList);
		}
		responseStr = objMap.writeValueAsString(cretRes);
		/*if(logger.isDebugEnabled())logger.debug("Inside CustomerServiceImpl :: editCustomer method :: response from GC :: "
				+ responseStr);*/
		logger.info("Inside CustomerServiceImpl :: editCustomer method :: Execution Completed Successfully");

		return cretRes;
	}
 	  //<1840> : Vishal J : Method to edit customer deatails. : End
	
}

package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.entity.AccFinancierMaster;
import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PrevInsurerResponse {
	private Integer nofficeid;
	private String strcompanytype="";
	private String strofficecd="";
	private String branch = ""; 
	private String straddline1 = "";
	private String straddline2 = "";
	private String straddline3 = "";
	private String strlandmark = "";
	private String strstatecd = ""; 
	private String strstatename = "";
	private String strcitycd = ""; 
	private String strcityname = "";
	private Integer npincode;
	private List<ResponseError> resErr;
	
	public Integer getNofficeid() {
		return nofficeid;
	}
	public void setNofficeid(Integer nofficeid) {
		this.nofficeid = nofficeid;
	}
	public String getStrofficecd() {
		return strofficecd;
	}
	public void setStrofficecd(String strofficecd) {
		this.strofficecd = strofficecd;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	
	public String getStrstatecd() {
		return strstatecd;
	}
	public void setStrstatecd(String strstatecd) {
		this.strstatecd = strstatecd;
	}
	public String getStrstatename() {
		return strstatename;
	}
	public void setStrstatename(String strstatename) {
		this.strstatename = strstatename;
	}
	public String getStrcitycd() {
		return strcitycd;
	}
	public void setStrcitycd(String strcitycd) {
		this.strcitycd = strcitycd;
	}
	public String getStrcityname() {
		return strcityname;
	}
	public void setStrcityname(String strcityname) {
		this.strcityname = strcityname;
	}
	public Integer getNpincode() {
		return npincode;
	}
	public void setNpincode(Integer npincode) {
		this.npincode = npincode;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public String getStrcompanytype() {
		return strcompanytype;
	}
	public void setStrcompanytype(String strcompanytype) {
		this.strcompanytype = strcompanytype;
	}
	public String getStraddline1() {
		return straddline1;
	}
	public void setStraddline1(String straddline1) {
		this.straddline1 = straddline1;
	}
	public String getStraddline2() {
		return straddline2;
	}
	public void setStraddline2(String straddline2) {
		this.straddline2 = straddline2;
	}
	public String getStraddline3() {
		return straddline3;
	}
	public void setStraddline3(String straddline3) {
		this.straddline3 = straddline3;
	}
	public String getStrlandmark() {
		return strlandmark;
	}
	public void setStrlandmark(String strlandmark) {
		this.strlandmark = strlandmark;
	}
	
	
}

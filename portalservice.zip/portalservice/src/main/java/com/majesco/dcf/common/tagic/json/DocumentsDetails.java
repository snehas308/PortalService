package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include= JsonSerialize.Inclusion.NON_EMPTY)
public class DocumentsDetails
{
  private Long module;
  private String functionId;
  private String userId;
  private String errorMsg;
  List<DocumentUpload> uploadDownloadList;
  
  public Long getModule()
  {
    return this.module;
  }
  
  public void setModule(Long module)
  {
    this.module = module;
  }
  
  public String getFunctionId()
  {
    return this.functionId;
  }
  
  public void setFunctionId(String functionId)
  {
    this.functionId = functionId;
  }
  
  public String getUserId()
  {
    return this.userId;
  }
  
  public void setUserId(String userId)
  {
    this.userId = userId;
  }
  
  public List<DocumentUpload> getUploadDownloadList()
  {
    return this.uploadDownloadList;
  }
  
  public void setUploadDownloadList(List<DocumentUpload> uploadDownloadList)
  {
    this.uploadDownloadList = uploadDownloadList;
  }
  
  public String getErrorMsg()
  {
    return this.errorMsg;
  }
  
  public void setErrorMsg(String errorMsg)
  {
    this.errorMsg = errorMsg;
  }
}
package com.majesco.dcf.common.tagic.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_security_ques_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_security_ques_m")							// Added for Oracle Migration
public class SecurityQuestion {
	private Integer nquestioncd;
	private String strquesdesc;
	private Integer nisactive;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;	
	private String strupdatedby;
	
	@Id
	@Column(name = "nquestioncd")
	public Integer getNquestioncd() {
		return nquestioncd;
	}
	public void setNquestioncd(Integer nquestioncd) {
		this.nquestioncd = nquestioncd;
	}
	
	@Column(name = "strquesdesc")
	public String getStrquesdesc() {
		return strquesdesc;
	}
	public void setStrquesdesc(String strquesdesc) {
		this.strquesdesc = strquesdesc;
	}
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}

}

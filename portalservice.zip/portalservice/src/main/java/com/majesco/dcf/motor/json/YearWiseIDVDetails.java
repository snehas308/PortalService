package com.majesco.dcf.motor.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class YearWiseIDVDetails {
	
	private String idvOfVehicleY1;
	private String idvOfVehicleY2;
	private String idvOfVehicleY3;
	private String idvOfSideCarY1;
	private String idvOfSideCarY2;
	private String idvOfSideCarY3;
	private String biFuelCNGLPGY1;
	private String biFuelCNGLPGY2;
	private String biFuelCNGLPGY3;
	private String idvElectAccessY1;
	private String idvElectAccessY2;
	private String idvElectAccessY3;
	private String idvNonElectAccessY1;
	private String idvNonElectAccessY2;
	private String idvNonElectAccessY3;
	private String totalIDVOfVehicleY1;
	private String totalIDVOfVehicleY2;
	private String totalIDVOfVehicleY3;
	
	public String getIdvOfVehicleY1() {
		return idvOfVehicleY1;
	}
	public void setIdvOfVehicleY1(String idvOfVehicleY1) {
		this.idvOfVehicleY1 = idvOfVehicleY1;
	}
	public String getIdvOfVehicleY2() {
		return idvOfVehicleY2;
	}
	public void setIdvOfVehicleY2(String idvOfVehicleY2) {
		this.idvOfVehicleY2 = idvOfVehicleY2;
	}
	public String getIdvOfVehicleY3() {
		return idvOfVehicleY3;
	}
	public void setIdvOfVehicleY3(String idvOfVehicleY3) {
		this.idvOfVehicleY3 = idvOfVehicleY3;
	}
	public String getIdvOfSideCarY1() {
		return idvOfSideCarY1;
	}
	public void setIdvOfSideCarY1(String idvOfSideCarY1) {
		this.idvOfSideCarY1 = idvOfSideCarY1;
	}
	public String getIdvOfSideCarY2() {
		return idvOfSideCarY2;
	}
	public void setIdvOfSideCarY2(String idvOfSideCarY2) {
		this.idvOfSideCarY2 = idvOfSideCarY2;
	}
	public String getIdvOfSideCarY3() {
		return idvOfSideCarY3;
	}
	public void setIdvOfSideCarY3(String idvOfSideCarY3) {
		this.idvOfSideCarY3 = idvOfSideCarY3;
	}
	public String getBiFuelCNGLPGY1() {
		return biFuelCNGLPGY1;
	}
	public void setBiFuelCNGLPGY1(String biFuelCNGLPGY1) {
		this.biFuelCNGLPGY1 = biFuelCNGLPGY1;
	}
	public String getBiFuelCNGLPGY2() {
		return biFuelCNGLPGY2;
	}
	public void setBiFuelCNGLPGY2(String biFuelCNGLPGY2) {
		this.biFuelCNGLPGY2 = biFuelCNGLPGY2;
	}
	public String getBiFuelCNGLPGY3() {
		return biFuelCNGLPGY3;
	}
	public void setBiFuelCNGLPGY3(String biFuelCNGLPGY3) {
		this.biFuelCNGLPGY3 = biFuelCNGLPGY3;
	}
	public String getIdvElectAccessY1() {
		return idvElectAccessY1;
	}
	public void setIdvElectAccessY1(String idvElectAccessY1) {
		this.idvElectAccessY1 = idvElectAccessY1;
	}
	public String getIdvElectAccessY2() {
		return idvElectAccessY2;
	}
	public void setIdvElectAccessY2(String idvElectAccessY2) {
		this.idvElectAccessY2 = idvElectAccessY2;
	}
	public String getIdvElectAccessY3() {
		return idvElectAccessY3;
	}
	public void setIdvElectAccessY3(String idvElectAccessY3) {
		this.idvElectAccessY3 = idvElectAccessY3;
	}
	public String getIdvNonElectAccessY1() {
		return idvNonElectAccessY1;
	}
	public void setIdvNonElectAccessY1(String idvNonElectAccessY1) {
		this.idvNonElectAccessY1 = idvNonElectAccessY1;
	}
	public String getIdvNonElectAccessY2() {
		return idvNonElectAccessY2;
	}
	public void setIdvNonElectAccessY2(String idvNonElectAccessY2) {
		this.idvNonElectAccessY2 = idvNonElectAccessY2;
	}
	public String getIdvNonElectAccessY3() {
		return idvNonElectAccessY3;
	}
	public void setIdvNonElectAccessY3(String idvNonElectAccessY3) {
		this.idvNonElectAccessY3 = idvNonElectAccessY3;
	}
	public String getTotalIDVOfVehicleY1() {
		return totalIDVOfVehicleY1;
	}
	public void setTotalIDVOfVehicleY1(String totalIDVOfVehicleY1) {
		this.totalIDVOfVehicleY1 = totalIDVOfVehicleY1;
	}
	public String getTotalIDVOfVehicleY2() {
		return totalIDVOfVehicleY2;
	}
	public void setTotalIDVOfVehicleY2(String totalIDVOfVehicleY2) {
		this.totalIDVOfVehicleY2 = totalIDVOfVehicleY2;
	}
	public String getTotalIDVOfVehicleY3() {
		return totalIDVOfVehicleY3;
	}
	public void setTotalIDVOfVehicleY3(String totalIDVOfVehicleY3) {
		this.totalIDVOfVehicleY3 = totalIDVOfVehicleY3;
	}
	
	
}

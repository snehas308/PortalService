package com.majesco.dcf.common.tagic.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "dcf_sp_mst")
public class SpMaster {
	      
	@Id
	@Column(name= "NUM_MAPPING_ID")
	private int num_mapping_id;
	
	@Column(name= "TXT_SP_NAME")
	private String txt_sp_name;	
	
	@Column(name= "TXT_INSURANCE_TYPE")
	private String txt_insurance_type;	
		
	@Column(name= "TXT_SP_CERT_NO")
	private String txt_sp_cert_no;
	
	@Column(name= "TXT_PRODUCER_CODE")
	private String txt_producer_code;
	
	@Column(name= "TXT_PRODUCER_NAME")
	private String txt_producer_name;
	
	@Column(name= "DAT_START_DATE")
	private Date dat_start_date;
	
	@Column(name= "DAT_END_DATE")
	private Date dat_end_date;
	
	@Column(name= "TXT_ACTIVE_FLAG")
	private String txt_active_flag;
	
	@Column(name= "NUM_TRANS_ID")
	private int num_trans_id;
	
	@Column(name= "DAT_INSERT_DATE")
	private Date dat_insert_date;
	
	@Column(name= "DAT_MODIFIED_DATE")
	private Date dat_modified_date;
	
	@Column(name= "TXT_USER_ID")
	private String txt_user_id;
	
	@Column(name= "TXT_USER_ROLE")
	private String txt_user_role;
	
	@Column(name= "TXT_IP_ADDRESS")
	private String txt_ip_address;
	
	@Column(name= "NUM_UPDATE_NO")
	private String num_update_no;
	
	@Column(name= "TXT_STATUS")
	private String txt_status;

	public int getNum_mapping_id() {
		return num_mapping_id;
	}

	public void setNum_mapping_id(int num_mapping_id) {
		this.num_mapping_id = num_mapping_id;
	}

	public String getTxt_sp_name() {
		return txt_sp_name;
	}

	public void setTxt_sp_name(String txt_sp_name) {
		this.txt_sp_name = txt_sp_name;
	}

	public String getTxt_insurance_type() {
		return txt_insurance_type;
	}

	public void setTxt_insurance_type(String txt_insurance_type) {
		this.txt_insurance_type = txt_insurance_type;
	}

	public String getTxt_sp_cert_no() {
		return txt_sp_cert_no;
	}

	public void setTxt_sp_cert_no(String txt_sp_cert_no) {
		this.txt_sp_cert_no = txt_sp_cert_no;
	}

	public String getTxt_producer_code() {
		return txt_producer_code;
	}

	public void setTxt_producer_code(String txt_producer_code) {
		this.txt_producer_code = txt_producer_code;
	}

	public String getTxt_producer_name() {
		return txt_producer_name;
	}

	public void setTxt_producer_name(String txt_producer_name) {
		this.txt_producer_name = txt_producer_name;
	}

	public Date getDat_start_date() {
		return dat_start_date;
	}

	public void setDat_start_date(Date dat_start_date) {
		this.dat_start_date = dat_start_date;
	}

	public Date getDat_end_date() {
		return dat_end_date;
	}

	public void setDat_end_date(Date dat_end_date) {
		this.dat_end_date = dat_end_date;
	}

	public String getTxt_active_flag() {
		return txt_active_flag;
	}

	public void setTxt_active_flag(String txt_active_flag) {
		this.txt_active_flag = txt_active_flag;
	}

	public int getNum_trans_id() {
		return num_trans_id;
	}

	public void setNum_trans_id(int num_trans_id) {
		this.num_trans_id = num_trans_id;
	}

	public Date getDat_insert_date() {
		return dat_insert_date;
	}

	public void setDat_insert_date(Date dat_insert_date) {
		this.dat_insert_date = dat_insert_date;
	}

	public Date getDat_modified_date() {
		return dat_modified_date;
	}

	public void setDat_modified_date(Date dat_modified_date) {
		this.dat_modified_date = dat_modified_date;
	}

	public String getTxt_user_id() {
		return txt_user_id;
	}

	public void setTxt_user_id(String txt_user_id) {
		this.txt_user_id = txt_user_id;
	}

	public String getTxt_user_role() {
		return txt_user_role;
	}

	public void setTxt_user_role(String txt_user_role) {
		this.txt_user_role = txt_user_role;
	}

	public String getTxt_ip_address() {
		return txt_ip_address;
	}

	public void setTxt_ip_address(String txt_ip_address) {
		this.txt_ip_address = txt_ip_address;
	}

	public String getNum_update_no() {
		return num_update_no;
	}

	public void setNum_update_no(String num_update_no) {
		this.num_update_no = num_update_no;
	}

	public String getTxt_status() {
		return txt_status;
	}

	public void setTxt_status(String txt_status) {
		this.txt_status = txt_status;
	}
		
		
}

package com.majesco.dcf.common.tagic.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.majesco.dcf.paproduct.controller.IPAController;


@Controller
@RequestMapping(value="/AccountService")
public class AccountController {
	
	
	
	final static Logger logger=Logger.getLogger(IPAController.class);

}

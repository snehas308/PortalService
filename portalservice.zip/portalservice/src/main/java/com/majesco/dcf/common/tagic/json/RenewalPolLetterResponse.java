package com.majesco.dcf.common.tagic.json;

public class RenewalPolLetterResponse extends ResultObject{
		
	private String strRenewalLetter;
	private String resultCode;
	private String policyNumber;
	public String getStrRenewalLetter() {
		return strRenewalLetter;
	}
	public void setStrRenewalLetter(String strRenewalLetter) {
		this.strRenewalLetter = strRenewalLetter;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	
	
	
}

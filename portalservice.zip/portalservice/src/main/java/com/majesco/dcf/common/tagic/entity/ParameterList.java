package com.majesco.dcf.common.tagic.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;


@Entity
//@Table(name = "dcf_parameter_lst",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_parameter_lst")								// Added for Oracle Migration
public class ParameterList {

	
	private Integer iparamtypecd;
	

	private String  strtypename ;
	private String  strtypedesc ;
	private Integer  nsystemuser ;
    private String dtcreated ;
    private String strcreatedby ;
	private String dtupdated ;
	private String strupdatedby ;
	
	@Column(name = "strtypename")
	public String getStrtypename() {
		return strtypename;
	}

	public void setStrtypename(String strtypename) {
		this.strtypename = strtypename;
	}

	@Id
	@Column(name = "nparamtypecd")
	public Integer getIparamtypecd() {
		return iparamtypecd;
	}

	public void setIparamtypecd(Integer iparamtypecd) {
		this.iparamtypecd = iparamtypecd;
	}

	
	

	@Column(name = "strtypedesc")
	public String getStrtypedesc() {
		return strtypedesc;
	}

	public void setStrtypedesc(String strtypedesc) {
		this.strtypedesc = strtypedesc;
	}

	@Column(name = "nsystemuser")
	public Integer getNsystemuser() {
		return nsystemuser;
	}

	public void setNsystemuser(Integer nsystemuser) {
		this.nsystemuser = nsystemuser;
	}

	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}

	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}

	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}

	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}

	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}

	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}

	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}

	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}

	
	
	
}

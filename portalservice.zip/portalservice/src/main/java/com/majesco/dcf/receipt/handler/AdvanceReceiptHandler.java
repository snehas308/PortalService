package com.majesco.dcf.receipt.handler;

import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.SOAPInfo;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyResponse;
import com.majesco.dcf.receipt.json.ReceiptPaymentDetails;
import com.majesco.dcf.receipt.json.ReceiptResponse;
import com.majesco.dcf.receipt.util.ReceiptConstants;
import com.majesco.dcf.util.CXFInBoundInterceptor;
import com.majesco.dcf.util.CXFOutInterceptor;
import com.unotechsoft.stub.accountservice.client.AccountService;
import com.unotechsoft.stub.accountservice.client.AccountService_Service;
import com.unotechsoft.stub.accountservice.client.ArrayOfClsPolicyIdGrid;
import com.unotechsoft.stub.accountservice.client.ArrayOfKeyValueOfstringint;
import com.unotechsoft.stub.accountservice.client.ArrayOfKeyValueOfstringint.KeyValueOfstringint;
import com.unotechsoft.stub.accountservice.client.ArrayOfKeyValueOfstringstring;
import com.unotechsoft.stub.accountservice.client.ArrayOfKeyValueOfstringstring.KeyValueOfstringstring;
import com.unotechsoft.stub.accountservice.client.ArrayOfUserDataExistPayments;
import com.unotechsoft.stub.accountservice.client.ArrayOfUserDataPaymentEntry;
import com.unotechsoft.stub.accountservice.client.ClsPolicyIdGrid;
import com.unotechsoft.stub.accountservice.client.PaymentEntryCumPolicyGen2;
import com.unotechsoft.stub.accountservice.client.PaymentEntryCumPolicyGenResponse2;
import com.unotechsoft.stub.accountservice.client.PaymentEntryServiceResult;
import com.unotechsoft.stub.accountservice.client.UserDataExistPayments;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentEntry;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentTaging;
import com.unotechsoft.stub.accountservice.client.UserDataSubReceipt;
import java.io.InputStream;

@Service
@Transactional
public class AdvanceReceiptHandler implements ReceiptHandlerIntf {

final static Logger logger=Logger.getLogger(AdvanceReceiptHandler.class);

private static Properties prop = new Properties();

static{
	try{
InputStream inputStream = TagicCommunicationService.class.getClassLoader().getResourceAsStream("resources.properties");
prop.load(inputStream);
	}catch(Exception ex){
		ex.printStackTrace();
	}
}
	
	
	public  String serviceURL=ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING;
	
	@Override
	public ReceiptCumPolicyResponse callReceiptCumPolicyProcess(
			ReceiptCumPolicyRequest receiptReq, DBService dbService)
			throws Exception {
		ReceiptCumPolicyResponse response=new ReceiptCumPolicyResponse();
		ReceiptPaymentDetails receiptPayDtls=null;
		String localTransId=receiptReq.getProcessTransId();
		CXFInBoundInterceptor cxfInInterceptor =null;
		CXFOutInterceptor cxfOutInterceptor= null;
		ObjectMapper objMap=new ObjectMapper();
		
		try{
			logger.info("Start::"+localTransId+"::AdvanceReceiptHandler::callReceiptCumPolicyProcess::Entered");
			//if(logger.isDebugEnabled())logger.debug("Input::"+localTransId+"::AdvanceReceiptHandler::callReceiptCumPolicyProcess::"+objMap.writeValueAsString(receiptReq));
			receiptPayDtls = receiptReq.getPaymentDetails().get(0);
			String userId=receiptReq.getUserID();
			
			// This is done for testing purpose. Code needs to be removed.
			//userId = ReceiptConstants.DEFAULT_USERID;
			if(userId == null || userId.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
				userId = ReceiptConstants.DEFAULT_USERID;
			}
				
			
		if(serviceURL==null || serviceURL.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
			serviceURL=dbService.getWSDLURL(ReceiptConstants.ACCOUNTSERVICE_ID,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			//serviceURL="http://172.17.203.45:9393/AccountService_SOAPOverHTTP?wsdl";
			//serviceURL=wsdlURL;
		}
		AccountService_Service accService=new AccountService_Service(new URL(serviceURL));
		
		AccountService accServClient=accService.getSOAPOverHTTP();
		PaymentEntryCumPolicyGen2 polGen2=new PaymentEntryCumPolicyGen2();
		//ArrayOfUserDataPaymentEntry userDatPayEntryList=null;
		ArrayOfUserDataPaymentEntry userDatPayEntryList = new ArrayOfUserDataPaymentEntry();
		UserDataPaymentEntry userDatPayEntry=new UserDataPaymentEntry();
		
		// commented as for Advance deposit  userDatPayEntry will be null
		/*userDatPayEntry.setAllocationReqd("Y"); // Default to Y
		userDatPayEntry.setBGTag(new Integer(ReceiptConstants.ACCOUNTSERVICE_BGTAG));
		userDatPayEntry.setBckDtVal(ReceiptConstants.ACCOUNTSERVICE_BCKDTVAL);
		userDatPayEntry.setBusinessLocation(Integer.parseInt(receiptReq.getProposalDetails().getBusinessLocation()));
		userDatPayEntry.setDepositOfficeCode(Integer.parseInt(receiptReq.getProposalDetails().getDepositOfficeCode()));
		userDatPayEntry.setBusinessLocationName(receiptReq.getProposalDetails().getBussLocName());
		userDatPayEntry.setBusinessType(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPE_CASH);
		userDatPayEntry.setBusinessTypeCd(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPECD);
		userDatPayEntry.setCallEnv(ReceiptConstants.ACCOUNTSERVICE_CALLENV);
		userDatPayEntry.setDecimalPaymentAmount(BigDecimal.valueOf(Double.parseDouble(receiptReq.getProposalDetails().getProposalAmount()))); // receiptReq.getProposalDetails().getProposalAmount()
		userDatPayEntry.setGenPolicyNo(ReceiptConstants.ACCOUNTSERVICE_GENPOLNO);
		userDatPayEntry.setMultiCustomerFlag("N"); // Hard coded to N for Cash
		
		userDatPayEntry.setPayerCustomerId(receiptReq.getProposalDetails().getCustomerId());
		userDatPayEntry.setPayerName(receiptReq.getProposalDetails().getCustomerName());
		userDatPayEntry.setPayerTypeCd(Integer.parseInt(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CD));
		userDatPayEntry.setPayerType(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CASH);
		userDatPayEntry.setPaymentMode(ReceiptConstants.ACCOUNTSERVICE_PAYMENT_MODE_CASH);
		userDatPayEntry.setPaymentType(Long.parseLong("-1")); // Hard coded to -1 as it's mandatory to GC
		
		Date date1 = new Date();
		SimpleDateFormat sdf1=new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a", Locale.US);
		
		Date payDate=new Date();
		SimpleDateFormat sdfPay=new SimpleDateFormat("dd/MM/yyyy", Locale.US);
		
		//Changes done to handle data type issue
		Double payAmount=new Double(receiptPayDtls.getPaymentAmount());
		userDatPayEntry.setPaymentAmount(payAmount.longValue());
		userDatPayEntry.setPaymentDate(sdfPay.format(payDate));
		
		if(receiptReq.getProducerCode()!=null && !receiptReq.getProducerCode().equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
		userDatPayEntry.setProducerCode(receiptReq.getProducerCode());
		}else{
			userDatPayEntry.setProducerCode(ReceiptConstants.DEFAULT_PRODUCERCODE);
		}
		
		
		
		userDatPayEntry.setReceiptDate(sdf1.format(date1));
		userDatPayEntry.setTransactionType(Integer.parseInt(ReceiptConstants.ACCOUNTSERVICE_TRANS_TYPE_CASH));
		userDatPayEntry.setTransactionTime(sdf1.format(date1));
		userDatPayEntry.setTransactionId(Long.parseLong(receiptReq.getProposalDetails().getProposalSystemId()));
		userDatPayEntry.setUserRole(ReceiptConstants.DEFAULT_GC_ROLE);
		userDatPayEntry.setUserId(userId);
		
		//Setting other default values required in GC
				userDatPayEntry.setAcceptanceDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setAcceptanceVoucherNumber(new Long(0));
				userDatPayEntry.setAuthorizationCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setBackDateAcc(new Long(0));
				userDatPayEntry.setBalanceAmount(new Long(0));
				//userDatPayEntry.setBankAccountNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setBankAccountNo("983009830"); // Defaulted to 983009830. Master to be shared by TAGIC as per mail on 10/09/2016
				userDatPayEntry.setBankCode(new Long(0));
				userDatPayEntry.setBankName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setBatchDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setBatchNumber(new Long(0));
				userDatPayEntry.setCMSSlipNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setCardHolderName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setConversionAmount(new BigDecimal(0));
				userDatPayEntry.setCounterNo(new Integer(0));
				userDatPayEntry.setCurrencyAmount(new BigDecimal(0));
				userDatPayEntry.setCurrencyConcateString(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setCurrencyConvertRate(new BigDecimal(0));
				userDatPayEntry.setDealerCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setDealerName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				//userDatPayEntry.setDepositAdviceDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setDepositAdviceDate(sdf1.format(date1)); // Defaulted to system date as per logic provided by TAGIC on 10/09/2016
				userDatPayEntry.setDeptCode(new Long(0));
				userDatPayEntry.setDraweeBankLoc(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setEnable_Pol_Issue_Role_Wise(false);
				userDatPayEntry.setEncodedCardNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setEntryDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setExpiryDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setForeignCurrencyAmount(new BigDecimal(0));
				userDatPayEntry.setHoRefDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setHoRefNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				//userDatPayEntry.setHouseBankBranchCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setHouseBankBranchCode(ReceiptConstants.ACCOUNTSERVICE_HOUSE_BRANCH_CODE); // Defaulted 10001 as per mail from TAGIC on 10/09/2016. To be changed once master is received.
				userDatPayEntry.setIFSCCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setILPosPaymentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setITSPaymentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setInsertedTransID(new Long(0));
				userDatPayEntry.setInsertedTransIDDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setInstrumentType(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setInstrumentTypeCd(new Integer(0));
				userDatPayEntry.setIntermediaryCode(ReceiptConstants.DEFAULT_PRODUCERCODE);
				userDatPayEntry.setIntermediaryName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setInvoiceId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setInwardNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setIsAcceptanceApplicable(false);
				userDatPayEntry.setIsDepositSlipNoGenerate(false);
				userDatPayEntry.setIsPortalReceipt(false);
				userDatPayEntry.setMICRNumber("0");
				userDatPayEntry.setMICRTag(0);
				userDatPayEntry.setMerchantId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setModifiedTransID(new Long(0));
				userDatPayEntry.setModifiedTransIDDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setMonthEndExtension(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setMultiCustomerApplicability(true); // Hard coded to true
				userDatPayEntry.setMultiCustomerConcat(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				//userDatPayEntry.setMultiCustomerFlag("N"); // Already hard coded at set to N
				userDatPayEntry.setNsurPlusPaymentID(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setPayinSlipDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setPayinSlipNumber(new Long(0));
				userDatPayEntry.setPaymentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setPolicyNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setPostAuthCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setPropCount(0);
				userDatPayEntry.setReconcileDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setRelationShip(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setRemarks(ReceiptConstants.ACCOUNTSERVICE_REMARKS); // Defaulted to generic remark provide by TAGIC on 10/09/2016
				userDatPayEntry.setStatus(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setTAGICAccNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setVoucherNoAlternation(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
				userDatPayEntry.setYNOthersType(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		
		ArrayOfKeyValueOfstringint arrKeyValNote=new ArrayOfKeyValueOfstringint();
		KeyValueOfstringint keyValTotalAmount=new KeyValueOfstringint();
		keyValTotalAmount.setKey(ReceiptConstants.ACCOUNTSERVICE_TotalAmount);
		keyValTotalAmount.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTotalAmount);
		
		
		KeyValueOfstringint keyValThousand=new KeyValueOfstringint();
		keyValThousand.setKey(ReceiptConstants.ACCOUNTSERVICE_Thousand);
		keyValThousand.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValThousand);
		
		
		KeyValueOfstringint keyValFivehundred=new KeyValueOfstringint();
		keyValFivehundred.setKey(ReceiptConstants.ACCOUNTSERVICE_Fivehundred);
		keyValFivehundred.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValFivehundred);
		
		
		KeyValueOfstringint keyValHundred=new KeyValueOfstringint();
		keyValHundred.setKey(ReceiptConstants.ACCOUNTSERVICE_Hundred);
		keyValHundred.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValHundred);
		
		
		KeyValueOfstringint keyValFifty=new KeyValueOfstringint();
		keyValFifty.setKey(ReceiptConstants.ACCOUNTSERVICE_Fifty);
		keyValFifty.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValFifty);
		
		KeyValueOfstringint keyValTwenty=new KeyValueOfstringint();
		keyValTwenty.setKey(ReceiptConstants.ACCOUNTSERVICE_Twenty);
		keyValTwenty.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTwenty);
		
		KeyValueOfstringint keyValTen=new KeyValueOfstringint();
		keyValTen.setKey(ReceiptConstants.ACCOUNTSERVICE_Ten);
		keyValTen.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTen);
		
		KeyValueOfstringint keyValFive=new KeyValueOfstringint();
		keyValFive.setKey(ReceiptConstants.ACCOUNTSERVICE_Five);
		keyValFive.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValFive);
		
		KeyValueOfstringint keyValTwo=new KeyValueOfstringint();
		keyValTwo.setKey(ReceiptConstants.ACCOUNTSERVICE_Two);
		keyValTwo.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValTwo);
		
		KeyValueOfstringint keyValOne=new KeyValueOfstringint();
		keyValOne.setKey(ReceiptConstants.ACCOUNTSERVICE_One);
		keyValOne.setValue(0);
		arrKeyValNote.getKeyValueOfstringint().add(keyValOne);
		
		userDatPayEntry.setNoteNumber(arrKeyValNote);*/ 
		
		Date date = new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a", Locale.US);
		
		ArrayOfKeyValueOfstringint arrKeyValNote=new ArrayOfKeyValueOfstringint();
		//userDatPayEntry.setNoteNumber(arrKeyValNote);
		//userDatPayEntryList.getUserDataPaymentEntry().add(userDatPayEntry);
		polGen2.setObjLVUserDataPEntryLst(userDatPayEntryList);
		
		//polGen2.setObjLVUserDataPEntryLst(null); // As suggested by TAGIC objLVUserDataPEntryLst is to be sent blank / null for advance receipt deposit (single transaction).
		UserDataSubReceipt subReceipt=new UserDataSubReceipt();
		subReceipt.setCallSLEnv(ReceiptConstants.ACCOUNTSERVICE_CALLENV);
		subReceipt.setTransactionID(receiptReq.getProposalDetails().getProposalSystemId());
		subReceipt.setUserID(userId);
		subReceipt.setIsCheckSubReceipt(ReceiptConstants.FALSE_BOOLEAN);	//Added By ketan On 15 Nov 2016
	//	subReceipt.setGuidWorkFlow(new Long(ReceiptConstants.GUID_WORKFLOW)); //Added By ketan On 15 Nov 2016
	//	subReceipt.setSlNo(ReceiptConstants.SL_NO); //Added By ketan On 15 Nov 2016
		polGen2.setObjUserDataSubReceipt(subReceipt);
		
		UserDataPaymentTaging payTag=new UserDataPaymentTaging();
		//Start:13/12/2016
		payTag.setAutoAcceptanceApplicable(0);
		payTag.setBankChargeAmt(new Long(0));
		
		payTag.setBusinessType(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPECD);
		payTag.setCallSLEnv(ReceiptConstants.ACCOUNTSERVICE_CALLENV);
		payTag.setCheckAutopayment(1); // Hard coded to 1 for CASH
		payTag.setCheckAutoProposal(1); // Hard coded to 1 for CASH
		ArrayOfClsPolicyIdGrid proposalGrid=new ArrayOfClsPolicyIdGrid();
		ClsPolicyIdGrid policyGrid=new ClsPolicyIdGrid();
		policyGrid.setBankCharge("0");
		policyGrid.setIsChecked(true);
		//policyGrid.setProposalDate(receiptReq.getProposalDetails().getProposalDate()); //Commented For Issue ID 1576
		/*Added For Issue ID 1576 Starts Here*/
		SimpleDateFormat sdfPropDate = null;
		sdfPropDate = new SimpleDateFormat("dd/MM/yyyy");
		Date propDate = new Date();
		if(receiptReq!=null && receiptReq.getIsManualCovernoteChk()!=null && receiptReq.getIsManualCovernoteChk().equalsIgnoreCase("true"))
		{
			policyGrid.setProposalDate(sdfPropDate.format(propDate));
		}
		else
		{
			policyGrid.setProposalDate(receiptReq.getProposalDetails().getProposalDate());
		}
		/*Added For Issue ID 1576 Ends Here*/
		policyGrid.setProposalNo(receiptReq.getProposalDetails().getProposalNo());
		payTag.setModeOfEntry(ReceiptConstants.ACCOUNTSERVICE_BGTAG);
		payTag.setOfficeCode(receiptReq.getProposalDetails().getDepositOfficeCode());
		//payTag.setOfficeCodeUnmasked(receiptReq.getProposalDetails().getDepositOfficeCode()); //Added By ketan On 15 Nov 2016
		payTag.setPayerId(receiptReq.getProposalDetails().getCustomerId());
		//Start:13/12/2016:Hardcoding to 1 for time being
		//payTag.setPayerType(receiptPayDtls.getPayerType());
		payTag.setPayerType(ReceiptConstants.ACCOUNTSERVICE_PAYERTYPE_CD_PRODUCER);
		payTag.setProposalId(receiptReq.getProposalDetails().getProposalNo());
		payTag.setProposalAmount((long)Double.parseDouble(receiptReq.getProposalDetails().getProposalAmount()==null?"0":receiptReq.getProposalDetails().getProposalAmount())); //Added By ketan On 15 Nov 2016
		payTag.setTransactionId(receiptReq.getProposalDetails().getProposalSystemId());
		payTag.setTransactionTime(sdf.format(date));
		payTag.setUserId(userId);
		
		//Defaulting other values for paytag
		payTag.setAutoAcceptanceApplicable(0);
		payTag.setBankChargeAmt(new Long(0));
		//payTag.setDealerId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); //Commented By ketan On 15 Nov 2016
		payTag.setDealerId(ReceiptConstants.DEALER_ID); //Added By ketan On 15 Nov 2016
		payTag.setDealerName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		payTag.setFinancierID(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		payTag.setGenPolicy(0);
		payTag.setGUIDWorkFlow("W"+receiptReq.getProposalDetails().getProposalSystemId()); //Added By ketan On 15 Nov 2016
		payTag.setInstrumentAmount(new Long(0));
		payTag.setInstrumentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		payTag.setIntermediaryId("0");
		payTag.setIs64VbAllowed(false);
		payTag.setIsAutoPaymentChecked(false);
		payTag.setIsAutoPropChecked(false);
		payTag.setIsCreditPolicy(false);
		payTag.setIsShortFallNonAllowedFlg(false);
		payTag.setIsShortPremAllowedFlg(false);
		payTag.setMaxPremium(new Long(0));
		payTag.setMonthlyExtension(0);
		payTag.setOtherBankApplicability("0");
		payTag.setProposalUnPaidAmount(new Long(0));
		payTag.setShortPremium("0");
		payTag.setTagSequence(0);
		payTag.setTotalInstrumentBalanceAmount(new Long(0));
		payTag.setWorkflowName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		
		proposalGrid.getClsPolicyIdGrid().add(policyGrid);
		payTag.setClsProposalDetailsGrd(proposalGrid);
		
		polGen2.setObjUserDataPaymentTaging(payTag);
		
		
		ArrayOfKeyValueOfstringstring arrLVWF=new ArrayOfKeyValueOfstringstring();
		
		KeyValueOfstringstring keyValue1=new KeyValueOfstringstring();
		keyValue1.setKey(ReceiptConstants.ACCOUNTSERVICE_GUID_WORKFLOW_KEY);
		//keyValue1.setValue(ReceiptConstants.ACCOUNTSERVICE_GUID_WORKFLOW_VALUE);
		keyValue1.setValue(payTag.getGUIDWorkFlow());
		arrLVWF.getKeyValueOfstringstring().add(keyValue1);
		
		KeyValueOfstringstring keyValue2=new KeyValueOfstringstring();
		keyValue2.setKey(ReceiptConstants.ACCOUNTSERVICE_CURRENT_STATE_KEY);
		keyValue2.setValue(ReceiptConstants.ACCOUNTSERVICE_CURRENT_STATE_VALUE);
		arrLVWF.getKeyValueOfstringstring().add(keyValue2);
		
		KeyValueOfstringstring keyValue3=new KeyValueOfstringstring();
		keyValue3.setKey(ReceiptConstants.ACCOUNTSERVICE_PAGE_ACTION_KEY);
		keyValue3.setValue(ReceiptConstants.ACCOUNTSERVICE_PAGE_ACTION_VALUE);
		arrLVWF.getKeyValueOfstringstring().add(keyValue3);
		
		KeyValueOfstringstring keyValue4=new KeyValueOfstringstring();
		keyValue4.setKey(ReceiptConstants.ACCOUNTSERVICE_WORKFLOW_NAME_KEY);
		keyValue4.setValue(ReceiptConstants.ACCOUNTSERVICE_WORKFLOW_NAME_VALUE);
		arrLVWF.getKeyValueOfstringstring().add(keyValue4);
		
		//Setting existing payment tag for advance deposit receipt.
		ArrayOfUserDataExistPayments arrExistPay=new ArrayOfUserDataExistPayments();
		UserDataExistPayments userDataExistPay=new UserDataExistPayments();
		
		/*Code Added By Ketan On 04/05/2017*/
		if(receiptReq!=null && receiptReq.getPaymentDetails()!=null && receiptReq.getPaymentDetails().size()>0)
		{
			List<ReceiptPaymentDetails> lstPayDtls = new ArrayList<ReceiptPaymentDetails>();
			ReceiptPaymentDetails payDtls = new ReceiptPaymentDetails();
			
			lstPayDtls = receiptReq.getPaymentDetails();
			
			for(int i=0;i<lstPayDtls.size();i++)
			{
				payDtls = lstPayDtls.get(i);
				if(payDtls!=null && payDtls.getPaymentType()!=null && payDtls.getPaymentType().equalsIgnoreCase("AD"))
				{
					userDataExistPay=new UserDataExistPayments();
					userDataExistPay.setPaymentAmt(payDtls.getPaymentAmount());
					userDataExistPay.setPaymentGenFlag(false);
					userDataExistPay.setPaymentID(payDtls.getInstrumentNo());
					userDataExistPay.setSubReceiptID(null);
					arrExistPay.getUserDataExistPayments().add(userDataExistPay);
				}
			}
		}
		/*Code Added By Ketan On 04/05/2017*/
		
		/*userDataExistPay.setPaymentAmt(receiptReq.getAdvanceReceiptDtls().getReceiptAmount());
		userDataExistPay.setPaymentGenFlag(false);
		userDataExistPay.setPaymentID(receiptReq.getAdvanceReceiptDtls().getReceiptNo());
		userDataExistPay.setSubReceiptID(null);
		arrExistPay.getUserDataExistPayments().add(userDataExistPay);*/
		polGen2.setLstExistPayments(arrExistPay);
		/*polGen2.setDicLVWFParams(arrLVWF);*/ //Commented On 18 Jan 2017 As Changes Received From ESB
		polGen2.setDicLVWFParams(null); //Added On 18 Jan 2017 As Changes Received From ESB
		
		
		polGen2.setSource(prop.getProperty("smc.source"));
		polGen2.setCampaign(prop.getProperty("smc.medium"));
		polGen2.setMedium(prop.getProperty("smc.campaign"));
		
		if(receiptReq.getAuthToken()!=null && !receiptReq.getAuthToken().equalsIgnoreCase(""))
			polGen2.setStrLVTokenID(receiptReq.getAuthToken());
		else
		polGen2.setStrLVTokenID(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		
		// Code added to save info abt SOAP in DB Start
		SOAPInfo soapInfo = new SOAPInfo();
		soapInfo.setTransactionID(Long.parseLong(receiptReq.getProcessTransId()));
		soapInfo.setLobService("paymentEntryCumPolicyGen");
		soapInfo.setLobtype(receiptReq.getStrLOB());
		soapInfo.setCreatedBy(receiptReq.getUserID());
		soapInfo.setProducerCode(receiptReq.getProducerCode());
		soapInfo.setSystemIP(receiptReq.getSystemIP());
		soapInfo.setTransactionEvent(CommonConstants.POLICY_CREATION_EVENT);
		soapInfo.setJsonRequest(objMap.writeValueAsString(receiptReq));
		soapInfo.setProductCode(receiptReq.getProposalDetails().getProductCode());
		
		
		cxfInInterceptor =new CXFInBoundInterceptor(soapInfo);
		cxfOutInterceptor= new CXFOutInterceptor(soapInfo);
		
		ServiceUtility utility = new ServiceUtility();
		utility.addClientInterceptorDB(accServClient,cxfInInterceptor,cxfOutInterceptor);
		
		/*ServiceUtility serviceUtil=new ServiceUtility();
		serviceUtil.addClientInterceptor(accServClient);*/
		/*Client client=ClientProxy.getClient(accServClient);
		PrintWriter writer = new PrintWriter(System.out);
		
		client.getOutInterceptors().add(new CdataWriterInterceptor());
		
		client.getInInterceptors().add(new LoggingInInterceptor(writer));
		
		client.getOutInterceptors().add(new LoggingOutInterceptor(writer));*/
		
		//if(logger.isDebugEnabled())logger.debug("Start::"+localTransId+"::AdvanceReceiptHandler::Calling AccountService-->paymentEntryCumPolicyGen::Entered");
		PaymentEntryCumPolicyGenResponse2 receiptResponse=accServClient.paymentEntryCumPolicyGen(polGen2);
		//if(logger.isDebugEnabled())logger.debug("End::"+localTransId+"::AdvanceReceiptHandler::After Calling AccountService-->paymentEntryCumPolicyGen::Exit");
		PaymentEntryServiceResult payResult=null;
		
		//if(logger.isDebugEnabled())logger.debug("Adding Out Logs to DB");
		dbService.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
		//if(logger.isDebugEnabled())logger.debug("Adding In Logs to DB");
		dbService.saveInSoapInfo(cxfInInterceptor.getInBound());				
		
//Code end for Saving SOAP Data to DB.		
		
		payResult=receiptResponse.getReturn();
		if(payResult!=null && payResult.getErrorCode()!=null && payResult.getErrorCode().equalsIgnoreCase("0") && payResult.getErrorMsg()!=null && payResult.getErrorMsg().equalsIgnoreCase("-1")){
			
		response.setPolicyNo(payResult.getPolicyNo());
		ReceiptResponse receiptRes=new ReceiptResponse();
		receiptRes.setReceiptNo(payResult.getNewlyCreatedReceipts());
		receiptRes.setSubReceiptId(payResult.getTaggedSubReceipt());
		
		response.setReceiptDtls(receiptRes);
		response.setResultCode("1");
		
		}else if(payResult!=null && payResult.getErrorMsg()!=null && !payResult.getErrorMsg().equalsIgnoreCase("-1") && payResult.getErrorCode()!=null && !payResult.getErrorCode().equalsIgnoreCase("0")){
			response.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError error=new ResponseError();
			error.setErrorCode(payResult.getErrorCode());
			error.setErrorMMessag(payResult.getErrorMsg());
			errorList.add(error);
			response.setErrorList(errorList);
		}
		
		}catch(Exception ex){
			logger.error("Exception::"+localTransId+"::AdvanceReceiptHandler::callReceiptCumPolicyProcess::Exit", ex);
			response.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError error=new ResponseError();
			error.setErrorCode("ERR01");
			error.setErrorMMessag("Failed to call service !!."+ex.getMessage()+".Transaction ID "+localTransId);
			errorList.add(error);
			response.setErrorList(errorList);
		}
		//if(logger.isDebugEnabled())logger.debug("Response::"+localTransId+"::AdvanceReceiptHandler::callReceiptCumPolicyProcess::"+objMap.writeValueAsString(response));
		logger.info("End::"+localTransId+"::AdvanceReceiptHandler::callReceiptCumPolicyProcess::Exit");
		
		if(cxfInInterceptor!=null){
			cxfInInterceptor.getInBound().setStrjsonobj(objMap.writeValueAsString(response));
			cxfInInterceptor.getInBound().setStrrefno(receiptReq.getProposalDetails().getProposalNo() == null ? "":receiptReq.getProposalDetails().getProposalNo());
			dbService.saveInSoapInfo(cxfInInterceptor.getInBound());	
		}					
        if(cxfOutInterceptor!=null){
			cxfOutInterceptor.getOutBound().setStrrefno(receiptReq.getProposalDetails().getProposalNo() == null ? "":receiptReq.getProposalDetails().getProposalNo());						
			dbService.saveOutSoapInfo(cxfOutInterceptor.getOutBound());
		}
		
		return response;
	}

	@Override
	public ReceiptCumPolicyResponse createReceipt(
			ReceiptCumPolicyRequest receiptReq, DBService dbService)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}

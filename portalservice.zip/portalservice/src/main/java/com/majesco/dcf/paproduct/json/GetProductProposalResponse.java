package com.majesco.dcf.paproduct.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResultObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class GetProductProposalResponse extends ResultObject{

	private IPAProposalRequest result;

	public IPAProposalRequest getResult() {
		return result;
	}

	public void setResult(IPAProposalRequest result) {
		this.result = result;
	}
}

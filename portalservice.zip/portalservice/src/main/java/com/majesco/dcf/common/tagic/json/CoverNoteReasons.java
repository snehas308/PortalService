package com.majesco.dcf.common.tagic.json;

public class CoverNoteReasons {
	
	private String questionID;
	private String question;
	public String getQuestionID() {
		return questionID;
	}
	public void setQuestionID(String questionID) {
		this.questionID = questionID;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	
	

}

package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PortalLockDetails {

	private String message;
	private List<String> lstPrivilege;
	private boolean isPortalLock;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<String> getLstPrivilege() {
		if (lstPrivilege == null)
			lstPrivilege = new ArrayList<String>();
		return lstPrivilege;
	}
	public void setLstPrivilege(List<String> lstPrivilege) {
		this.lstPrivilege = lstPrivilege;
	}
	public boolean isPortalLock() {
		return isPortalLock;
	}
	public void setPortalLock(boolean isPortalLock) {
		this.isPortalLock = isPortalLock;
	}
	
}

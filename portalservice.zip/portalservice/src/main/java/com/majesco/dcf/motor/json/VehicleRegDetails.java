package com.majesco.dcf.motor.json;

import java.util.Date;

import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class VehicleRegDetails {

	
	public String vehicleRegNumber1;
	public String vehicleRegNumber2;
	public String vehicleRegNumber3;
	public String vehicleRegNumber4;
	public String manufacturer;
	public String strModel;
	public String vehicleVariant;
	public String manufactureYear;
	public String registrationAuthLoc;
	public String iDVoftheVehicle;
	public String fuelType; 
	public String dateDelivPurc;
	public String dateofReg;
	public String vehicleAge;
	public String subProduct;
	public String externallyBuiltBody;
	public String trailerIDV;
	public String basisofRating;
	public String NoofTrailerundertow;
	public String towedby;
	public String typeofBus;
	public String typeofBody;
	public String paCoverOwnerDriver;
	public String paCoverPaidDriver;
	public String numberofpersons;
	public String SIPaidDriver;
	public String othercovers; //Cover for lamps, tyres/tubes mudguards/Bonnet/side parts  
	public String noClaimBonusdisc;
	public String existingClaimMade;
	public String vehUse;//Vehicle Use
	public String seatCap;//Seating Capacity
	public String cubCap;//Cubic Capacity
	public String gvw;//GVW
	public String covAddAcc;//Do you want to cover additional accessories
	public String paCoverUnmdPass;//PA Cover to Unnamed Passanger
	public String engineNo;
	public String chasisNo;
	public String cityVehicleUsed;
	public String cityVehicleUsedCode;
	public String fincrId;
	public String fincrName;
	public String loanNo;
	public String loanType;
	public String govtStateTranspVeh;//Govt/State Transport Vehicle
	public String natOfGoods;//Nature of Goods Normally Carried
	public String trailRegDet;//Trailer Registration Details
	public String trailRegNo;//Trailer Registration No.
	public String trailChasNo;//Trailor Chassis Number
	public String trailMake;//Trailor Make
	public String trailModel;//Trailor Model
	public String manufacturerCode;
	public String modelCode;//Added For Issue ID 1497
	public String vehSeg;
	public String useOfVehiclesConfined;
	public String typeOfMiscVeh;
	public String adjustedIDV;
	ServiceUtility serviceUtility = new ServiceUtility();
	
	public String getGrossVehWeight() {
		return grossVehWeight;
	}
	public void setGrossVehWeight(String grossVehWeight) {
		grossVehWeight = serviceUtility.blankToNullCheck(grossVehWeight);
		this.grossVehWeight = grossVehWeight;
	}
	public String getLampsTyrePaint() {
		return lampsTyrePaint;
	}
	public void setLampsTyrePaint(String lampsTyrePaint) {
		lampsTyrePaint = serviceUtility.blankToNullCheck(lampsTyrePaint);
		this.lampsTyrePaint = lampsTyrePaint;
	}
	public String sumInsuredPass;//Sum Insured for Passenger
	public String grossVehWeight;//Gross Vehicle Weight
	public String lampsTyrePaint;//Lamps/Tyres/ Mudguards/ Bonnet / Bumper/ Painting
	public String getPaCoverUnmdPass() {
		return paCoverUnmdPass;
	}
	public void setPaCoverUnmdPass(String paCoverUnmdPass) {
		paCoverUnmdPass = serviceUtility.blankToNullCheck(paCoverUnmdPass);
		this.paCoverUnmdPass = paCoverUnmdPass;
	}
	public String getSumInsuredPass() {
		return sumInsuredPass;
	}
	public void setSumInsuredPass(String sumInsuredPass) {
		sumInsuredPass = serviceUtility.blankToNullCheck(sumInsuredPass);
		this.sumInsuredPass = sumInsuredPass;
	}
	public String getSeatCap() {
		return seatCap;
	}
	public void setSeatCap(String seatCap) {
		seatCap = serviceUtility.blankToNullCheck(seatCap);
		this.seatCap = seatCap;
	}
	public String getCubCap() {
		return cubCap;
	}
	public void setCubCap(String cubCap) {
		cubCap = serviceUtility.blankToNullCheck(cubCap);
		this.cubCap = cubCap;
	}
	public String getGvw() {
		return gvw;
	}
	public void setGvw(String gvw) {
		gvw = serviceUtility.blankToNullCheck(gvw);
		this.gvw = gvw;
	}
	public String getCovAddAcc() {
		return covAddAcc;
	}
	public void setCovAddAcc(String covAddAcc) {
		covAddAcc = serviceUtility.blankToNullCheck(covAddAcc);
		this.covAddAcc = covAddAcc;
	}
	public String getVehUse() {
		return vehUse;
	}
	public void setVehUse(String vehUse) {
		vehUse = serviceUtility.blankToNullCheck(vehUse);
		this.vehUse = vehUse;
	}
	public String getVehicleRegNumber1() {
		return vehicleRegNumber1;
	}
	public void setVehicleRegNumber1(String vehicleRegNumber1) {
		vehicleRegNumber1 = serviceUtility.blankToNullCheck(vehicleRegNumber1);
		this.vehicleRegNumber1 = vehicleRegNumber1;
	}
	public String getVehicleRegNumber2() {
		return vehicleRegNumber2;
	}
	public void setVehicleRegNumber2(String vehicleRegNumber2) {
		vehicleRegNumber2 = serviceUtility.blankToNullCheck(vehicleRegNumber2);
		this.vehicleRegNumber2 = vehicleRegNumber2;
	}
	public String getVehicleRegNumber3() {
		return vehicleRegNumber3;
	}
	public void setVehicleRegNumber3(String vehicleRegNumber3) {
		vehicleRegNumber3 = serviceUtility.blankToNullCheck(vehicleRegNumber3);
		this.vehicleRegNumber3 = vehicleRegNumber3;
	}
	public String getVehicleRegNumber4() {
		return vehicleRegNumber4;
	}
	public void setVehicleRegNumber4(String vehicleRegNumber4) {
		vehicleRegNumber4 = serviceUtility.blankToNullCheck(vehicleRegNumber4);
		this.vehicleRegNumber4 = vehicleRegNumber4;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		manufacturer = serviceUtility.blankToNullCheck(manufacturer);
		this.manufacturer = manufacturer;
	}
	public String getStrModel() {
		return strModel;
	}
	public void setStrModel(String strModel) {
		strModel = serviceUtility.blankToNullCheck(strModel);
		this.strModel = strModel;
	}
	public String getVehicleVariant() {
		return vehicleVariant;
	}
	public void setVehicleVariant(String vehicleVariant) {
		vehicleVariant = serviceUtility.blankToNullCheck(vehicleVariant);
		this.vehicleVariant = vehicleVariant;
	}
	public String getManufactureYear() {
		return manufactureYear;
	}
	public void setManufactureYear(String manufactureYear) {
		manufactureYear = serviceUtility.blankToNullCheck(manufactureYear);
		this.manufactureYear = manufactureYear;
	}
	public String getRegistrationAuthLoc() {
		return registrationAuthLoc;
	}
	public void setRegistrationAuthLoc(String registrationAuthLoc) {
		registrationAuthLoc = serviceUtility.blankToNullCheck(registrationAuthLoc);
		this.registrationAuthLoc = registrationAuthLoc;
	}
	public String getiDVoftheVehicle() {
		return iDVoftheVehicle;
	}
	public void setiDVoftheVehicle(String iDVoftheVehicle) {
		iDVoftheVehicle = serviceUtility.blankToNullCheck(iDVoftheVehicle);
		this.iDVoftheVehicle = iDVoftheVehicle;
	}
	public String getFuelType() {
		return fuelType;
	}
	public void setFuelType(String fuelType) {
		fuelType = serviceUtility.blankToNullCheck(fuelType);
		this.fuelType = fuelType;
	}
	public String getDateDelivPurc() {
		return dateDelivPurc;
	}
	public void setDateDelivPurc(String dateDelivPurc) {
		dateDelivPurc = serviceUtility.blankToNullCheck(dateDelivPurc);
		this.dateDelivPurc = dateDelivPurc;
	}
	public String getDateofReg() {
		return dateofReg;
	}
	public void setDateofReg(String dateofReg) {
		dateofReg = serviceUtility.blankToNullCheck(dateofReg);
		this.dateofReg = dateofReg;
	}
	public String getVehicleAge() {
		return vehicleAge;
	}
	public void setVehicleAge(String vehicleAge) {
		vehicleAge = serviceUtility.blankToNullCheck(vehicleAge);
		this.vehicleAge = vehicleAge;
	}
	public String getSubProduct() {
		return subProduct;
	}
	public void setSubProduct(String subProduct) {
		subProduct = serviceUtility.blankToNullCheck(subProduct);
		this.subProduct = subProduct;
	}
	public String getExternallyBuiltBody() {
		return externallyBuiltBody;
	}
	public void setExternallyBuiltBody(String externallyBuiltBody) {
		externallyBuiltBody = serviceUtility.blankToNullCheck(externallyBuiltBody);
		this.externallyBuiltBody = externallyBuiltBody;
	}
	public String getTrailerIDV() {
		return trailerIDV;
	}
	public void setTrailerIDV(String trailerIDV) {
		trailerIDV = serviceUtility.blankToNullCheck(trailerIDV);
		this.trailerIDV = trailerIDV;
	}
	public String getBasisofRating() {
		return basisofRating;
	}
	public void setBasisofRating(String basisofRating) {
		basisofRating = serviceUtility.blankToNullCheck(basisofRating);
		this.basisofRating = basisofRating;
	}
	public String getNoofTrailerundertow() {
		return NoofTrailerundertow;
	}
	public void setNoofTrailerundertow(String noofTrailerundertow) {
		noofTrailerundertow = serviceUtility.blankToNullCheck(noofTrailerundertow);
		NoofTrailerundertow = noofTrailerundertow;
	}
	public String getTowedby() {
		return towedby;
	}
	public void setTowedby(String towedby) {
		towedby = serviceUtility.blankToNullCheck(towedby);
		this.towedby = towedby;
	}
	public String getTypeofBus() {
		return typeofBus;
	}
	public void setTypeofBus(String typeofBus) {
		typeofBus = serviceUtility.blankToNullCheck(typeofBus);
		this.typeofBus = typeofBus;
	}
	public String getTypeofBody() {
		return typeofBody;
	}
	public void setTypeofBody(String typeofBody) {
		typeofBody = serviceUtility.blankToNullCheck(typeofBody);
		this.typeofBody = typeofBody;
	}
	public String getPaCoverOwnerDriver() {
		return paCoverOwnerDriver;
	}
	public void setPaCoverOwnerDriver(String paCoverOwnerDriver) {
		paCoverOwnerDriver = serviceUtility.blankToNullCheck(paCoverOwnerDriver);
		this.paCoverOwnerDriver = paCoverOwnerDriver;
	}
	public String getPaCoverPaidDriver() {
		return paCoverPaidDriver;
	}
	public void setPaCoverPaidDriver(String paCoverPaidDriver) {
		paCoverPaidDriver = serviceUtility.blankToNullCheck(paCoverPaidDriver);
		this.paCoverPaidDriver = paCoverPaidDriver;
	}
	public String getNumberofpersons() {
		return numberofpersons;
	}
	public void setNumberofpersons(String numberofpersons) {
		numberofpersons = serviceUtility.blankToNullCheck(numberofpersons);
		this.numberofpersons = numberofpersons;
	}
	public String getSIPaidDriver() {
		return SIPaidDriver;
	}
	public void setSIPaidDriver(String sIPaidDriver) {
		sIPaidDriver = serviceUtility.blankToNullCheck(sIPaidDriver);
		SIPaidDriver = sIPaidDriver;
	}
	public String getOthercovers() {
		return othercovers;
	}
	public void setOthercovers(String othercovers) {
		othercovers = serviceUtility.blankToNullCheck(othercovers);
		this.othercovers = othercovers;
	}
	public String getNoClaimBonusdisc() {
		return noClaimBonusdisc;
	}
	public void setNoClaimBonusdisc(String noClaimBonusdisc) {
		noClaimBonusdisc = serviceUtility.blankToNullCheck(noClaimBonusdisc);
		this.noClaimBonusdisc = noClaimBonusdisc;
	}
	public String getExistingClaimMade() {
		return existingClaimMade;
	}
	public void setExistingClaimMade(String existingClaimMade) {
		existingClaimMade = serviceUtility.blankToNullCheck(existingClaimMade);
		this.existingClaimMade = existingClaimMade;
	}
	public String getEngineNo() {
		return engineNo;
	}
	public void setEngineNo(String engineNo) {
		engineNo = serviceUtility.blankToNullCheck(engineNo);
		this.engineNo = engineNo;
	}
	public String getChasisNo() {
		return chasisNo;
	}
	public void setChasisNo(String chasisNo) {
		chasisNo = serviceUtility.blankToNullCheck(chasisNo);
		this.chasisNo = chasisNo;
	}
	public String getCityVehicleUsed() {
		return cityVehicleUsed;
	}
	public void setCityVehicleUsed(String cityVehicleUsed) {
		cityVehicleUsed = serviceUtility.blankToNullCheck(cityVehicleUsed);
		this.cityVehicleUsed = cityVehicleUsed;
	}
	public String getLoanNo() {
		return loanNo;
	}
	public void setLoanNo(String loanNo) {
		loanNo = serviceUtility.blankToNullCheck(loanNo);
		this.loanNo = loanNo;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		loanType = serviceUtility.blankToNullCheck(loanType);
		this.loanType = loanType;
	}
	public String getFincrName() {
		return fincrName;
	}
	public void setFincrName(String fincrName) {
		fincrName = serviceUtility.blankToNullCheck(fincrName);
		this.fincrName = fincrName;
	}
	public String getGovtStateTranspVeh() {
		return govtStateTranspVeh;
	}
	public void setGovtStateTranspVeh(String govtStateTranspVeh) {
		govtStateTranspVeh = serviceUtility.blankToNullCheck(govtStateTranspVeh);
		this.govtStateTranspVeh = govtStateTranspVeh;
	}
	public String getNatOfGoods() {
		return natOfGoods;
	}
	public void setNatOfGoods(String natOfGoods) {
		natOfGoods = serviceUtility.blankToNullCheck(natOfGoods);
		this.natOfGoods = natOfGoods;
	}
	public String getTrailRegDet() {
		return trailRegDet;
	}
	public void setTrailRegDet(String trailRegDet) {
		trailRegDet = serviceUtility.blankToNullCheck(trailRegDet);
		this.trailRegDet = trailRegDet;
	}
	public String getTrailRegNo() {
		return trailRegNo;
	}
	public void setTrailRegNo(String trailRegNo) {
		trailRegNo = serviceUtility.blankToNullCheck(trailRegNo);
		this.trailRegNo = trailRegNo;
	}
	public String getTrailChasNo() {
		return trailChasNo;
	}
	public void setTrailChasNo(String trailChasNo) {
		trailChasNo = serviceUtility.blankToNullCheck(trailChasNo);
		this.trailChasNo = trailChasNo;
	}
	public String getTrailMake() {
		return trailMake;
	}
	public void setTrailMake(String trailMake) {
		trailMake = serviceUtility.blankToNullCheck(trailMake);
		this.trailMake = trailMake;
	}
	public String getTrailModel() {
		return trailModel;
	}
	public void setTrailModel(String trailModel) {
		trailModel = serviceUtility.blankToNullCheck(trailModel);
		this.trailModel = trailModel;
	}
	public String getManufacturerCode() {
		return manufacturerCode;
	}
	public void setManufacturerCode(String manufacturerCode) {
		manufacturerCode = serviceUtility.blankToNullCheck(manufacturerCode);
		this.manufacturerCode = manufacturerCode;
	}
	public String getVehSeg() {
		return vehSeg;
	}
	public void setVehSeg(String vehSeg) {
		vehSeg = serviceUtility.blankToNullCheck(vehSeg);
		this.vehSeg = vehSeg;
	}
	public String getUseOfVehiclesConfined() {
		return useOfVehiclesConfined;
	}
	public void setUseOfVehiclesConfined(String useOfVehiclesConfined) {
		useOfVehiclesConfined = serviceUtility.blankToNullCheck(useOfVehiclesConfined);
		this.useOfVehiclesConfined = useOfVehiclesConfined;
	}
	public String getTypeOfMiscVeh() {
		return typeOfMiscVeh;
	}
	public void setTypeOfMiscVeh(String typeOfMiscVeh) {
		typeOfMiscVeh = serviceUtility.blankToNullCheck(typeOfMiscVeh);
		this.typeOfMiscVeh = typeOfMiscVeh;
	}
	public String getAdjustedIDV() {
		return adjustedIDV;
	}
	public void setAdjustedIDV(String adjustedIDV) {
		adjustedIDV = serviceUtility.blankToNullCheck(adjustedIDV);
		this.adjustedIDV = adjustedIDV;
	}
	public String getCityVehicleUsedCode() {
		return cityVehicleUsedCode;
	}
	public void setCityVehicleUsedCode(String cityVehicleUsedCode) {
		cityVehicleUsedCode = serviceUtility.blankToNullCheck(cityVehicleUsedCode);
		this.cityVehicleUsedCode = cityVehicleUsedCode;
	}
	public String getFincrId() {
		return fincrId;
	}
	public void setFincrId(String fincrId) {
		fincrId = serviceUtility.blankToNullCheck(fincrId);
		this.fincrId = fincrId;
	}
	/*Code Added For Issue ID 1497 - Starts Here*/
	public String getModelCode() {
		return modelCode;
	}
	public void setModelCode(String modelCode) {
		modelCode = serviceUtility.blankToNullCheck(modelCode);
		this.modelCode = modelCode;
	}
	/*Code Added For Issue ID 1497 - Ends Here*/
	
}

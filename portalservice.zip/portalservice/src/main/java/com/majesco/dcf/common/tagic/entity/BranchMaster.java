package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_branch_m",schema="dcf_master")			// Commented for Oracle Migration
@Table(name = "dcf_branch_m")								// Added for Oracle Migration
public class BranchMaster implements Serializable{

	  private Integer nbranchseq;
	  private String strbranchcd;
	  private String strbranchname;
	  private String strentitycd;
	  private String dtstart;
	  private String dtend;
	  private Integer nisactive;
	  private String strmicrcd;
	  private String strifsccd;
	  private String strlisenceno;
	  private String strpanno;
	  private String dtcreated;
	  private String strcreatedby;
	  private String dtupdated;
	  private String strupdatedby;
	  
	  
	@Column(name = "nbranchseq")  
	public Integer getNbranchseq() {
		return nbranchseq;
	}
	public void setNbranchseq(Integer nbranchseq) {
		this.nbranchseq = nbranchseq;
	}
	
	
	@Id
	@Column(name = "strbranchcd")
	public String getStrbranchcd() {
		return strbranchcd;
	}
	public void setStrbranchcd(String strbranchcd) {
		this.strbranchcd = strbranchcd;
	}
	
	
	@Column(name = "strbranchname")
	public String getStrbranchname() {
		return strbranchname;
	}
	public void setStrbranchname(String strbranchname) {
		this.strbranchname = strbranchname;
	}
	
	
	@Id
	@Column(name = "strentitycd")
	public String getStrentitycd() {
		return strentitycd;
	}
	public void setStrentitycd(String strentitycd) {
		this.strentitycd = strentitycd;
	}
	
	
	@Column(name = "dtstart")
	public String getDtstart() {
		return dtstart;
	}
	public void setDtstart(String dtstart) {
		this.dtstart = dtstart;
	}
	
	
	@Column(name = "dtend")
	public String getDtend() {
		return dtend;
	}
	public void setDtend(String dtend) {
		this.dtend = dtend;
	}
	
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
	
	@Column(name = "strmicrcd")
	public String getStrmicrcd() {
		return strmicrcd;
	}
	public void setStrmicrcd(String strmicrcd) {
		this.strmicrcd = strmicrcd;
	}
	
	
	@Column(name = "strifsccd")
	public String getStrifsccd() {
		return strifsccd;
	}
	public void setStrifsccd(String strifsccd) {
		this.strifsccd = strifsccd;
	}
	
	
	@Column(name = "strlisenceno")
	public String getStrlisenceno() {
		return strlisenceno;
	}
	public void setStrlisenceno(String strlisenceno) {
		this.strlisenceno = strlisenceno;
	}
	
	
	@Column(name = "strpanno")
	public String getStrpanno() {
		return strpanno;
	}
	public void setStrpanno(String strpanno) {
		this.strpanno = strpanno;
	}
	
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	  
	  
	
}

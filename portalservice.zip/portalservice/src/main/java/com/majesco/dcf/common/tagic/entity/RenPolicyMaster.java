package com.majesco.dcf.common.tagic.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
//@Table(name = "dcf_ren_policy_m",schema="dcf_master")			// Commented for Oracle Migration
@Table(name = "dcf_ren_policy_m")								// Added for Oracle Migration
public class RenPolicyMaster {
	      
	@Id
	@Column(name= "strpolicynumber")
	private String policynumber;
	
	@Column(name= "strworkflowid")
	private String workflowid;	
	
	@Column(name= "nproposalno")
	private long proposalno;	
		
	@Column(name= "strcustno")
	private String custno;
	
	@Column(name= "strproducercd")
	private String producercd;
	
	@Column(name= "strproducername")
	private String producername;
	
	@Column(name= "strsubproducercd")
	private String subproducercd;
	
	@Column(name= "strsubproducername")
	private String subproducername;
	
	@Column(name= "strofficeloc")
	private String strofficeloc;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "polstartdt", insertable=false)
	private Date polstartdt;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "polenddt", insertable=false)
	private Date polenddt;
	
	@Column(name= "totalpremium")
	private double totalpremium;
	
	@Column(name= "strproductcd")
	private String strproductcd;
	
	@Column(name= "strproductname")
	private String strproductname;
	
	@Column(name= "straddonplan")
	private String straddonplan;
	
	@Column(name= "strrenstatus")
	private String strrenstatus;
	
	@Column(name= "strstatus")
	private String strstatus;
	
	@Column(name= "strlob")
	private String strlob;
	
	@Column(name= "mobileno")
	private String mobileno;
		
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dateofbirth", insertable=false)
	private Date dateofbirth;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtcreated", insertable=false)
	private Date dtCreated;
	
	@Column(name= "dtupdated")
	private Date dtUpdated;
	
	@Column(name= "strcreatedby")
	private String strCreatedBy;
	
	@Column(name= "strupdatedby")
	private String strUpdatedBy;
	
	// 3520 : Vishal : 19-Mar-2018 : Start
	@Column(name= "VEH_REG_NO")
	private String veh_reg_no;
	
	@Column(name = "make")
	private String make;
	
	@Column(name = "model")
	private String model;
	
	@Column(name = "ren_status_cd")
	private String ren_status_cd;
	
	@Column(name = "txt_customer_name")
	private String txt_customer_name;
	
	

	public String getTxt_customer_name() {
		return txt_customer_name;
	}

	public void setTxt_customer_name(String txt_customer_name) {
		this.txt_customer_name = txt_customer_name;
	}

	public String getVeh_reg_no() {
		return veh_reg_no;
	}

	public void setVeh_reg_no(String veh_reg_no) {
		this.veh_reg_no = veh_reg_no;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getRen_status_cd() {
		return ren_status_cd;
	}

	public void setRen_status_cd(String ren_status_cd) {
		this.ren_status_cd = ren_status_cd;
	}

	// 3520 : Vishal : 19-Mar-2018 : End
	
	public String getWorkflowid() {
		return workflowid;
	}

	public void setWorkflowid(String workflowid) {
		this.workflowid = workflowid;
	}

	public long getProposalno() {
		return proposalno;
	}

	public void setProposalno(long proposalno) {
		this.proposalno = proposalno;
	}

	public String getPolicynumber() {
		return policynumber;
	}

	public void setPolicynumber(String policynumber) {
		this.policynumber = policynumber;
	}

	public String getCustno() {
		return custno;
	}

	public void setCustno(String custno) {
		this.custno = custno;
	}

	public String getProducercd() {
		return producercd;
	}

	public void setProducercd(String producercd) {
		this.producercd = producercd;
	}

	public String getProducername() {
		return producername;
	}

	public void setProducername(String producername) {
		this.producername = producername;
	}

	public String getSubproducercd() {
		return subproducercd;
	}

	public void setSubproducercd(String subproducercd) {
		this.subproducercd = subproducercd;
	}

	public String getSubproducername() {
		return subproducername;
	}

	public void setSubproducername(String subproducername) {
		this.subproducername = subproducername;
	}

	public String getStrofficeloc() {
		return strofficeloc;
	}

	public void setStrofficeloc(String strofficeloc) {
		this.strofficeloc = strofficeloc;
	}

	public Date getPolstartdt() {
		return polstartdt;
	}

	public void setPolstartdt(Date polstartdt) {
		this.polstartdt = polstartdt;
	}

	public Date getPolenddt() {
		return polenddt;
	}

	public void setPolenddt(Date polenddt) {
		this.polenddt = polenddt;
	}

	public double getTotalpremium() {
		return totalpremium;
	}

	public void setTotalpremium(double totalpremium) {
		this.totalpremium = totalpremium;
	}

	public String getStrproductcd() {
		return strproductcd;
	}

	public void setStrproductcd(String strproductcd) {
		this.strproductcd = strproductcd;
	}

	public String getStrproductname() {
		return strproductname;
	}

	public void setStrproductname(String strproductname) {
		this.strproductname = strproductname;
	}

	public String getStraddonplan() {
		return straddonplan;
	}

	public void setStraddonplan(String straddonplan) {
		this.straddonplan = straddonplan;
	}

	public String getStrrenstatus() {
		return strrenstatus;
	}

	public void setStrrenstatus(String strrenstatus) {
		this.strrenstatus = strrenstatus;
	}

	public String getStrstatus() {
		return strstatus;
	}

	public void setStrstatus(String strstatus) {
		this.strstatus = strstatus;
	}

	public String getStrlob() {
		return strlob;
	}

	public void setStrlob(String strlob) {
		this.strlob = strlob;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public Date getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public Date getDtCreated() {
		return dtCreated;
	}

	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}

	public Date getDtUpdated() {
		return dtUpdated;
	}

	public void setDtUpdated(Date dtUpdated) {
		this.dtUpdated = dtUpdated;
	}

	public String getStrCreatedBy() {
		return strCreatedBy;
	}

	public void setStrCreatedBy(String strCreatedBy) {
		this.strCreatedBy = strCreatedBy;
	}

	public String getStrUpdatedBy() {
		return strUpdatedBy;
	}

	public void setStrUpdatedBy(String strUpdatedBy) {
		this.strUpdatedBy = strUpdatedBy;
	}

	
}

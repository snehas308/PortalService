package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author ketan570156
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class FastLaneResponse extends ResultObject{

	private String stateCode;
	private String vehicleCode;
	private String rtoName;
	private String flaSeatingCapacity;
	private String strVariant;
	private String cubicCapacity;
	private String manufacturerDesc;
	private String flaFuelTypeDesc;
	private String strModel;
	private String rtoCode;
	private String strManufacturer;
	private String engineNumber;
	private String makerModel;
	private String color;
	private String purchaseDate;
	private String flaCubicCapacity;
	private String fuelTypeDesc;
	private String seatingCapacity;
	private String registrationDate;
	private String chasisNumber;
	private String flaVehClassDesc;
	private String vehClassDesc;
	private String manufacturerYear;
	private String registrationNumber;
	private String strManufacturerCd;
	private String strModelCd;
	
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getVehicleCode() {
		return vehicleCode;
	}
	public void setVehicleCode(String vehicleCode) {
		this.vehicleCode = vehicleCode;
	}
	public String getRtoName() {
		return rtoName;
	}
	public void setRtoName(String rtoName) {
		this.rtoName = rtoName;
	}
	public String getFlaSeatingCapacity() {
		return flaSeatingCapacity;
	}
	public void setFlaSeatingCapacity(String flaSeatingCapacity) {
		this.flaSeatingCapacity = flaSeatingCapacity;
	}
	public String getStrVariant() {
		return strVariant;
	}
	public void setStrVariant(String strVariant) {
		this.strVariant = strVariant;
	}
	public String getCubicCapacity() {
		return cubicCapacity;
	}
	public void setCubicCapacity(String cubicCapacity) {
		this.cubicCapacity = cubicCapacity;
	}
	public String getManufacturerDesc() {
		return manufacturerDesc;
	}
	public void setManufacturerDesc(String manufacturerDesc) {
		this.manufacturerDesc = manufacturerDesc;
	}
	public String getFlaFuelTypeDesc() {
		return flaFuelTypeDesc;
	}
	public void setFlaFuelTypeDesc(String flaFuelTypeDesc) {
		this.flaFuelTypeDesc = flaFuelTypeDesc;
	}
	public String getStrModel() {
		return strModel;
	}
	public void setStrModel(String strModel) {
		this.strModel = strModel;
	}
	public String getRtoCode() {
		return rtoCode;
	}
	public void setRtoCode(String rtoCode) {
		this.rtoCode = rtoCode;
	}
	public String getStrManufacturer() {
		return strManufacturer;
	}
	public void setStrManufacturer(String strManufacturer) {
		this.strManufacturer = strManufacturer;
	}
	public String getEngineNumber() {
		return engineNumber;
	}
	public void setEngineNumber(String engineNumber) {
		this.engineNumber = engineNumber;
	}
	public String getMakerModel() {
		return makerModel;
	}
	public void setMakerModel(String makerModel) {
		this.makerModel = makerModel;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public String getFlaCubicCapacity() {
		return flaCubicCapacity;
	}
	public void setFlaCubicCapacity(String flaCubicCapacity) {
		this.flaCubicCapacity = flaCubicCapacity;
	}
	public String getFuelTypeDesc() {
		return fuelTypeDesc;
	}
	public void setFuelTypeDesc(String fuelTypeDesc) {
		this.fuelTypeDesc = fuelTypeDesc;
	}
	public String getSeatingCapacity() {
		return seatingCapacity;
	}
	public void setSeatingCapacity(String seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}
	public String getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}
	public String getChasisNumber() {
		return chasisNumber;
	}
	public void setChasisNumber(String chasisNumber) {
		this.chasisNumber = chasisNumber;
	}
	public String getFlaVehClassDesc() {
		return flaVehClassDesc;
	}
	public void setFlaVehClassDesc(String flaVehClassDesc) {
		this.flaVehClassDesc = flaVehClassDesc;
	}
	public String getVehClassDesc() {
		return vehClassDesc;
	}
	public void setVehClassDesc(String vehClassDesc) {
		this.vehClassDesc = vehClassDesc;
	}
	public String getManufacturerYear() {
		return manufacturerYear;
	}
	public void setManufacturerYear(String manufacturerYear) {
		this.manufacturerYear = manufacturerYear;
	}
	public String getRegistrationNumber() {
		return registrationNumber;
	}
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}
	public String getStrManufacturerCd() {
		return strManufacturerCd;
	}
	public void setStrManufacturerCd(String strManufacturerCd) {
		this.strManufacturerCd = strManufacturerCd;
	}
	public String getStrModelCd() {
		return strModelCd;
	}
	public void setStrModelCd(String strModelCd) {
		this.strModelCd = strModelCd;
	}
	
}

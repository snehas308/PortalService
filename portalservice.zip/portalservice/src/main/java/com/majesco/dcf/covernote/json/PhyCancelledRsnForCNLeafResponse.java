package com.majesco.dcf.covernote.json;

public class PhyCancelledRsnForCNLeafResponse {
	public String errorText;
	public String reason;
	public String Id;
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getErrorText() {
		return errorText;
	}
	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

	
	
	
}

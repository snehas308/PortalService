package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CPIPayment {
	
	private String cpi_txn_id;
	private String consumer_txn_id;
	private String application_number;
	private String payment_amount;
	private String payment_mode_desc;
	private String payment_mode_code;
	private String gateway_name;
	private String card_issuer_desc;
	private String txn_start_time;
	private String txn_status;
	private String gateway_response_msg;
	private String gateway_txn_id;
	
	
	public String getGateway_txn_id() {
		return gateway_txn_id;
	}
	public void setGateway_txn_id(String gateway_txn_id) {
		this.gateway_txn_id = gateway_txn_id;
	}
	public String getCpi_txn_id() {
		return cpi_txn_id;
	}
	public void setCpi_txn_id(String cpi_txn_id) {
		this.cpi_txn_id = cpi_txn_id;
	}
	public String getConsumer_txn_id() {
		return consumer_txn_id;
	}
	public void setConsumer_txn_id(String consumer_txn_id) {
		this.consumer_txn_id = consumer_txn_id;
	}
	public String getApplication_number() {
		return application_number;
	}
	public void setApplication_number(String application_number) {
		this.application_number = application_number;
	}
	public String getPayment_amount() {
		return payment_amount;
	}
	public void setPayment_amount(String payment_amount) {
		this.payment_amount = payment_amount;
	}
	public String getPayment_mode_desc() {
		return payment_mode_desc;
	}
	public void setPayment_mode_desc(String payment_mode_desc) {
		this.payment_mode_desc = payment_mode_desc;
	}
	public String getPayment_mode_code() {
		return payment_mode_code;
	}
	public void setPayment_mode_code(String payment_mode_code) {
		this.payment_mode_code = payment_mode_code;
	}
	public String getGateway_name() {
		return gateway_name;
	}
	public void setGateway_name(String gateway_name) {
		this.gateway_name = gateway_name;
	}
	public String getCard_issuer_desc() {
		return card_issuer_desc;
	}
	public void setCard_issuer_desc(String card_issuer_desc) {
		this.card_issuer_desc = card_issuer_desc;
	}
	public String getTxn_start_time() {
		return txn_start_time;
	}
	public void setTxn_start_time(String txn_start_time) {
		this.txn_start_time = txn_start_time;
	}
	public String getTxn_status() {
		return txn_status;
	}
	public void setTxn_status(String txn_status) {
		this.txn_status = txn_status;
	}
	public String getGateway_response_msg() {
		return gateway_response_msg;
	}
	public void setGateway_response_msg(String gateway_response_msg) {
		this.gateway_response_msg = gateway_response_msg;
	}
	

}

package com.majesco.dcf.motor.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.majesco.dcf.common.tagic.json.AuthenticationRequest;
import com.majesco.dcf.common.tagic.json.AuthenticationResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.service.AuthenticationService;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.motor.json.InspectionRequest;
import com.majesco.dcf.motor.json.InspectionResponse;
import com.majesco.dcf.motor.service.InspectionCoverNoteService;

@Controller
@RequestMapping(value = "/inspectionservice")
public class InspectionServiceController {

	final static Logger logger = Logger
			.getLogger(InspectionServiceController.class);
	
	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/

	@Autowired
	AuthenticationService authService;

	@Autowired
	InspectionCoverNoteService inspectionService;
	private String _strClassName = "InspectionServiceController";

	@RequestMapping(value = "/saveInspection/", method = RequestMethod.POST)
	@ResponseBody
	public InspectionResponse saveInspectionDetails(
			@RequestBody InspectionRequest inspectionReq,
			HttpServletRequest httpServletRequest) throws Exception {

		AuthenticationRequest authReq = new AuthenticationRequest();
		authReq.setSource(smc_source);
		authReq.setMedium(smc_medium);
		authReq.setCampain(smc_campaign);
		authReq.setUserID(inspectionReq.getUserID());
		authReq.setPassword(inspectionReq.getPassword());
		AuthenticationResponse authResponse = null;
		InspectionResponse response = new InspectionResponse();
		String strMethodName = "saveInspectionDetails";
		try {
			logger.info("Inside " + _strClassName + "::" + strMethodName+ "::Entered");
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				inspectionReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
				logger.info("Auth token received from Request Header..--> "+inspectionReq.getAuthToken());
				//End:Vishal<VAPT comments>| code added to set GC token into user object	
			}else{
				logger.info("Inside " + _strClassName + "::" + strMethodName+ "::Calling authentication service");
				authResponse = authService.getAuthenticationToken(authReq);
				if (authResponse != null
						&& !authResponse.getResultRes().equalsIgnoreCase(""))
					inspectionReq.setAuthToken(authResponse.getResultRes());
				logger.info("Inside " + _strClassName + "::" + strMethodName
						+ "::after authentication service call !!!");	
			}			
			logger.info("Inside " + _strClassName + "::" + strMethodName
					+ "::Calling inspection service");
			response = inspectionService.triggerPreInspection(inspectionReq);
		} catch (Exception ex) {
			logger.error("Inside " + _strClassName + "::" + strMethodName
					+ ":: Exception ::", ex);
			response.setResultCode(CommonConstants.FAILURE_STATUS);
			List<ResponseError> errorList = new ArrayList<ResponseError>();
			ResponseError error = new ResponseError();
			error.setErrorCode(ex.getMessage());
			error.setErrorMMessag(ex.getMessage()); // Need to change error
													// description
			errorList.add(error);
			response.setResponseError(errorList);
		}
		logger.info("Inside " + _strClassName + "::" + strMethodName + "::Exit");
		return response;
	}
}

package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_servreq_doc_map",schema="dcf_master")			// Commented for Oracle Migration
@Table(name = "dcf_servreq_doc_map")								// Added for Oracle Migration
public class ClaimDocMaster implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4283262705828869203L;
	
	
	/*private Integer npincodeseq;*/
	private String strdoccd;
	private String strdcodesc;
	private String nservreqdocmapseq;
	private String nservreqcatmapseq;
	private Integer nisactive;
	private String stripacovertype;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	
	@Id
	@Column(name = "strdoccd")
	public String getStrdoccd() {
		return strdoccd;
	}
	public void setStrdoccd(String strdoccd) {
		this.strdoccd = strdoccd;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	@Column(name = "nservreqdocmapseq")
	public String getNservreqdocmapseq() {
		return nservreqdocmapseq;
	}
	public void setNservreqdocmapseq(String nservreqdocmapseq) {
		this.nservreqdocmapseq = nservreqdocmapseq;
	}
	
	@Column(name = "nservreqcatmapseq")
	public String getNservreqcatmapseq() {
		return nservreqcatmapseq;
	}
	public void setNservreqcatmapseq(String nservreqcatmapseq) {
		this.nservreqcatmapseq = nservreqcatmapseq;
	}
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
	@Column(name = "stripacovertype")
	public String getStripacovertype() {
		return stripacovertype;
	}
	public void setStripacovertype(String stripacovertype) {
		this.stripacovertype = stripacovertype;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Column(name = "strdcodesc")
	public String getStrdcodesc() {
		return strdcodesc;
	}
	public void setStrdcodesc(String strdcodesc) {
		this.strdcodesc = strdcodesc;
	}
	
	
	
}

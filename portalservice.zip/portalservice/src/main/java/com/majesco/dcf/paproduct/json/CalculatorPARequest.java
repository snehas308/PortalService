package com.majesco.dcf.paproduct.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CalculatorPARequest extends UserObject {

	private String productcd;//ProductCode	strprodcd
	private String insuranceFor;//InsuranceFor strcovertype
	private String plantype;//PlanType	strplan
	private String cbenunit;//CoreBenUnit	nsa
	private Integer units;//NoOfUnits	no condition
	private String addoncoverApp;//AddOnCoverAppl	------
	private String unitsAddon;//NoOfUnitsAddOn		------
	private String tenure;	//					ntenure
	private Integer familySize;//SizeOfFamily	strfamilysize
	private String benperMonth;//BenefitPerMonth	nbenefitpermonth
	private Integer payPeriod;//PayoutPeriod		nnoofmonths
	private String sumAssured;//					------


	public String getSumAssured() {
		return sumAssured;
	}
	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}
	public String getProductcd() {
		return productcd;
	}
	public void setProductcd(String productcd) {
		this.productcd = productcd;
	}
	public String getInsuranceFor() {
		return insuranceFor;
	}
	public void setInsuranceFor(String insuranceFor) {
		this.insuranceFor = insuranceFor;
	}
	public String getPlantype() {
		return plantype;
	}
	public void setPlantype(String plantype) {
		this.plantype = plantype;
	}
	public String getCbenunit() {
		return cbenunit;
	}
	public void setCbenunit(String cbenunit) {
		this.cbenunit = cbenunit;
	}
	public Integer getUnits() {
		return units;
	}
	public void setUnits(Integer units) {
		this.units = units;
	}
	public String getAddoncoverApp() {
		return addoncoverApp;
	}
	public void setAddoncoverApp(String addoncoverApp) {
		this.addoncoverApp = addoncoverApp;
	}
	public String getUnitsAddon() {
		return unitsAddon;
	}
	public void setUnitsAddon(String unitsAddon) {
		this.unitsAddon = unitsAddon;
	}
	public String getTenure() {
		return tenure;
	}
	public void setTenure(String tenure) {
		this.tenure = tenure;
	}
	public Integer getFamilySize() {
		return familySize;
	}
	public void setFamilySize(Integer familySize) {
		this.familySize = familySize;
	}
	public String getBenperMonth() {
		return benperMonth;
	}
	public void setBenperMonth(String benperMonth) {
		this.benperMonth = benperMonth;
	}
	public Integer getPayPeriod() {
		return payPeriod;
	}
	public void setPayPeriod(Integer payPeriod) {
		this.payPeriod = payPeriod;
	}

	
	
}

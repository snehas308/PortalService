package com.majesco.dcf.common.tagic.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.exception.DCFException;
import com.majesco.dcf.common.tagic.json.CommunicationRequest;
import com.majesco.dcf.common.tagic.json.EmailAttachment;
import com.majesco.dcf.common.tagic.json.PrintProposalReq;
import com.majesco.dcf.communication.json.CommunicationReqst;
import com.majesco.dcf.communication.json.MailVO;
import com.majesco.dcf.communication.json.SmsDetails;
import com.majesco.dcf.communication.services.MailHandlerService;
import com.majesco.dcf.communication.services.SmsService;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.mailcomm.json.EmailTemplateParam;
import com.majesco.dcf.mailcomm.service.MailTemplateService;
import com.majesco.dcf.mailcomm.util.MailTemplateFactory;


@Service
@Transactional
public class TagicCommunicationService {

	@Autowired
	MailHandlerService mailHandlerService;
	@Autowired
	SmsService smsService;
	@Autowired
	TagicCommonService commonService;
	
	final static Logger logger = Logger.getLogger(TagicCommunicationService.class);
	
private static Properties prop = new Properties();
	
	static{
		try{
	InputStream inputStream = TagicCommunicationService.class.getClassLoader().getResourceAsStream("mailhandler.properties");
	prop.load(inputStream);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	@Async
	public void sendCommunication(CommunicationRequest commRequest) throws DCFException, IOException{
		
		
        MailVO mailvo = null;
        SmsDetails smsDetails = null;
        String statusMsg = "Success";
        CommunicationReqst  invokeRemoteCommReq = new CommunicationReqst();
        BufferedReader br = null;
        String cinNumber="";
        String uinNumber="";
        boolean policyReciept = false;
        try{
	        ObjectMapper objMapper = new ObjectMapper();
	        logger.debug("Inside CommunicationController.sendEmail method:: JSON Object "+objMapper.writeValueAsString(commRequest));
	
	        HashMap<String,String> paramMap = new HashMap<String,String>();
	        paramMap.put("param1", commRequest.getParam1());
	        paramMap.put("param2", commRequest.getParam2());
	        paramMap.put("param3", commRequest.getParam3());
	        paramMap.put("param4", commRequest.getParam4());
	        paramMap.put("param5", commRequest.getParam5());
	        paramMap.put("param6", commRequest.getParam6());
	        paramMap.put("param7", commRequest.getParam7());
	        paramMap.put("param8", commRequest.getParam8());
	        paramMap.put("param9", commRequest.getParam9());
	        paramMap.put("param10", commRequest.getParam10());
	        paramMap.put("param11", commRequest.getParam11());
	        paramMap.put("param12", commRequest.getParam12());
	        paramMap.put("param13", commRequest.getParam13());
	        paramMap.put("param14", commRequest.getParam14());
	        paramMap.put("param15", commRequest.getParam15());
	        paramMap.put("param16", commRequest.getParam16());
	        paramMap.put("param17", commRequest.getParam17());
	        paramMap.put("param18", commRequest.getParam18());
	        paramMap.put("param19", commRequest.getParam19());
	        paramMap.put("param20", commRequest.getParam20());
	        //Start: <RahulT> | Added for UIN & CIN number
	        if(commRequest.getProductCode()!=null && !commRequest.getProductCode().equals("")){
	        	if(commRequest.getProductCode().equals("4251")){
	        		uinNumber = "IRDA/NL-HLT/TAGI/P-P/V.I/195/13-14";
	        		cinNumber = "U85110MH2000PLC128425";
	        	}
	        	else if(commRequest.getProductCode().equals("4254")){
	        		uinNumber = "IRDAI/HLT/TAGI/P-P/V.II/200/15-16";
	        		cinNumber = "U85110MH2000PLC128425";
	        	}
	        	else if(commRequest.getProductCode().equals("4255")){
	        		uinNumber = "IRDA/NL-HLT/TAGI/P-P/V.I/197/13-14";
	        		cinNumber = "U85110MH2000PLC128425";
	        	}
	        	else if(commRequest.getProductCode().equals("3122")){	// Two wheeler
	        		uinNumber = "IRDAN108P0001V01200001";
	        		cinNumber = "U85110MH2000PLC128425";
	        	}
	        	else if(commRequest.getProductCode().equals("3121")){	// Private Car
	        		uinNumber = "IRDAN108P0002V01200001";
	        		cinNumber = "U85110MH2000PLC128425";
	        	}
	        	paramMap.put("uinNumber", uinNumber);
		        paramMap.put("cinNumber", cinNumber);
	        }
	        
	        //End: <RahulT> | Added for UIN & CIN number
	        invokeRemoteCommReq.setAlertType(commRequest.getAlertType());
	        invokeRemoteCommReq.setEventType(commRequest.getEventType());    
	        invokeRemoteCommReq.setParamMap(paramMap);
	        
	        if (commRequest.getAlertType()!=null && commRequest.getAlertType().equals("EMAIL")){
	        	logger.debug("getting mail content.... ");
		        mailvo = mailHandlerService.getMailContent(invokeRemoteCommReq);
		        logger.debug("Fetching mail content process completed ");
		        if(mailvo!=null)
		        {
		     //Start: RahulT| added for sending Email attachment
	        	if (commRequest.getEmailAttachment()!=null &&  mailvo.getAttachmentType()!=null){
	        		List<String> fileLocation = new ArrayList<String>();
	        		String filePath = "";
	        		EmailAttachment attachment = commRequest.getEmailAttachment();
	        		String userId = commRequest.getUserID();
	        		String password = commRequest.getPassword();
	        		for(String attachmentType : mailvo.getAttachmentType()){
	        			
	        			policyReciept = false;		//1928
	        			
	        			logger.debug("Sending mail with Attachment Type--> "+attachmentType);
		        		int triggerFlag = 0; 
		        		if (attachmentType.equalsIgnoreCase("quotation") && attachment.getEncodedString()!= null){
			        			triggerFlag =1;
			        			filePath = this.getEmailAttachment(attachment.getQuotNumber(),attachment, attachment.getEncodedString().getBytes(), triggerFlag, userId, password);
		        			
		        		}
			        		else if (attachmentType.equalsIgnoreCase("proposal")){
			        			triggerFlag =2;
			        			filePath = this.getEmailAttachment(attachment.getProposalNumber(),attachment,null,triggerFlag, userId, password);
		        			
		        		}
			        		else if (attachmentType.equalsIgnoreCase("policy")){
			        			triggerFlag = 3;
			        			filePath = this.getEmailAttachment(attachment.getPolicyNumber(),attachment,null,triggerFlag, userId, password);
		        			
		        		}
			        		else if (attachmentType.equalsIgnoreCase("worksheet")){
			        			triggerFlag =4;
			        			filePath = this.getEmailAttachment(attachment.getProposalNumber(),attachment,null,triggerFlag, userId, password);
		        			
		        		}
			        		else if (attachmentType.equalsIgnoreCase("printreceipt")){
			        			triggerFlag =5;
			        			//Start: RahulT <1928>| added for sending multiple email attachment for Part payment cases.
			        			String[] arrayStr=null;
			        			if (attachment.getReceiptNo()!=null && !attachment.getReceiptNo().equals(CommonConstants.BLANK_STRING)){
			        				arrayStr = attachment.getReceiptNo().split("\\|");
			        				for (String gcReceiptNo : arrayStr){
			        					filePath = this.getEmailAttachment(gcReceiptNo,attachment,null,triggerFlag, userId, password);
			        					
			        					br = new BufferedReader(new FileReader(filePath));
						        		if(br.readLine()!=null)
						        			fileLocation.add(filePath);
						        		br.close();
			        				}
			        				policyReciept = true;
			        			}
		        			
			        			//End: RahulT <1928>| added for sending multiple email attachment for Part payment cases.
			        			logger.info("PRODUCER IS SENDING THE ATTACHEMNT" +triggerFlag+"FilePath"+filePath+"attachmentType"+attachmentType);
		        		}
			        		// 1704 | Vishal J | 11-Aug-2017 | To Send Renewal Notice to Customer  | Start
			        		else if (attachmentType.equalsIgnoreCase("renewalNotice")){
			        			triggerFlag =6;
			        			filePath = this.getEmailAttachment(attachment.getPolicyNumber(),attachment,null,triggerFlag, userId, password);
		        			
		        		}
			        		// 1704 | Vishal J | 11-Aug-2017 | To Send Renewal Notice to Customer | End
			        		//get file size, If empty then dont send empty attachment
			        		if(!policyReciept){
			        		br = new BufferedReader(new FileReader(filePath));
			        		if(br.readLine()!=null)
			        			fileLocation.add(filePath);
			        		br.close();
		        		}
		        		}
	        		if (fileLocation!=null && !fileLocation.isEmpty())
	        			mailvo.setAttachment(fileLocation);
	        		else
	        			mailvo.setAttachment(null);
	        	}
	        	//End: RahulT| added for sending Email attachment
		        	//if(commRequest.getHtmlMsgTemplate()!=null && !commRequest.getHtmlMsgTemplate().equalsIgnoreCase("")){
		        	//	String decodedHtml=new String(Base64.decodeBase64(commRequest.getHtmlMsgTemplate()));
		        		//if(logger.isDebugEnabled())
		        	//	logger.debug("Inside TagicCommunicationService::Email HTML::"+decodedHtml);
		        		
		        		MailTemplateService mailTemplateService=MailTemplateFactory.getEmailTemplateHandler(commRequest.getEventType());
		        		EmailTemplateParam emailTemplateParam=new EmailTemplateParam();
		        		emailTemplateParam.setEventID(commRequest.getEventType());
		        		HashMap<String, String> tempValParam=new HashMap<String, String>();
		        		String strParam=prop.getProperty(commRequest.getEventType()+"_PARAM");
		        		String [] strParamList=strParam.split(",");
		        		
		        		if(strParamList!=null && strParamList.length>0){
		        			for(int i=0;i<strParamList.length;i++){
		        				tempValParam.put(strParamList[i], paramMap.get(strParamList[i]));
		        			}
					} 
		        		logger.debug("Inside TagicCommunicationService::: tempValParam .... "+tempValParam);
		        		logger.debug("Inside TagicCommunicationService::: emailTemplateParam.getEventID .... "+emailTemplateParam.getEventID());
		        		emailTemplateParam.setParameterMap(tempValParam);
		        		Object htmlObj= mailTemplateService.getHtmlMsgTemplate(emailTemplateParam);
		        		
		        		if(htmlObj!=null)
		        		mailvo.setHtmlMsgTemplate(htmlObj.toString());
		        		
		        		HashMap<String, String> imageIDMap=new HashMap<String, String>();
		        		
		        		imageIDMap.put("Image01", prop.getProperty("Image01"));
		        		imageIDMap.put("Image02", prop.getProperty("Image02"));
		        		imageIDMap.put("Image03", prop.getProperty("Image03"));
		        		
		        		mailvo.setContentIDImage(imageIDMap);
		        	//}
		        		//End:TAGIC:16/12/2016
			        mailvo.setRecipient(commRequest.getReceipient());
			        mailvo.setRecipientBCC(commRequest.getProducerEmail());
			        logger.debug("Inside TagicCommunicationService::: trying to send mail BCC.... "+commRequest.getProducerEmail());
			        String result = mailHandlerService.sendmail(mailvo);
			        logger.debug("message after invoking send email service--> "+ result);
			        if (result.matches("error")) {
			        	
			        	statusMsg = commRequest.getAlertType()+" communication failed due to some internal issue.";
		        	result = statusMsg;
			        }
		        }
	        }
	        else if (commRequest.getAlertType()!=null && commRequest.getAlertType().equals("SMS")){
	        		smsDetails = mailHandlerService.getSMSContent(invokeRemoteCommReq);
		 	        if(smsDetails!=null)
		 	        {
		 	        	smsDetails.setNumbers(commRequest.getReceipient());
		 		        String result = smsService.sendSMS(smsDetails);
		 		       logger.debug("message after invoking send sms service--> "+ result);
		 		        if (result.matches("error")) {
		 		        	
		 		        	statusMsg = commRequest.getAlertType()+" communication failed due to some internal issue.";
		 		        }
		 	        }
	        }
	        
	        logger.debug("Inside CommunicationController.sendEmail method.. ");
        }
        catch(Exception ex){
        	 logger.error("Inside CommunicationController.sendEmail method..Error ",ex);
        }
        finally{
        	if(br!=null)
        	br.close();
        }
	}
	
public String getEmailAttachment(String strSuffix, EmailAttachment attachmentDtl, byte[] encodedString, int triggerFlag, String userId, String password) throws IOException{
		
		
		String pdfSeries = new SimpleDateFormat("yyyyMMddHHmmss").format(new java.util.Date());
		//TagicCommonServiceImpl service = new TagicCommonServiceImpl(); 
		File file = null;
		FileOutputStream fos = null;
		String pdfPath = null;
		BufferedReader br = null;
		
		try{
			//File catalinaBase = new File( System.getProperty( "catalina.base" ) ).getAbsoluteFile();
			pdfPath = prop.getProperty("attachmentPath");
			
			logger.debug("Location for saving attachement --> "+pdfPath);
			
			PrintProposalReq printProposalReq = new PrintProposalReq(); 
			printProposalReq.setProposalNumber(attachmentDtl.getProposalNumber());
			printProposalReq.setCustomerID(attachmentDtl.getCustomerID());
			printProposalReq.setProductCode(attachmentDtl.getProductCode());
			printProposalReq.setProposalDate(attachmentDtl.getProposalDate());
			printProposalReq.setUserID(userId);
			printProposalReq.setPassword(password);
			//Need to set value from input, if blank then default User id / password to be used.
			//Start: RahulT|<1959:Production Issue> | code added to set default userName & password when UI does not sent userName
			if (printProposalReq.getUserID()==null || printProposalReq.getUserID().equals("")){
				printProposalReq.setUserID(prop.getProperty("userId"));
				printProposalReq.setPassword(prop.getProperty("password"));
			}
			//End: RahulT|<1959:Production Issue> | code added to set default userName & password when UI does not sent userName
						
			logger.debug("Save attachment process completed Physical path of PDF --> "+pdfPath);
		
			if(triggerFlag ==1) { //Print Quotation
				encodedString = Base64.decodeBase64(encodedString); //encoding  byte array into base 64
				if (strSuffix!= null && !strSuffix.equals("")){
					pdfPath = pdfPath + pdfSeries +"_"+ strSuffix +".pdf" ;
				}
				else{
					pdfPath = pdfPath + pdfSeries +".pdf" ;
				}
				
				file = new File (pdfPath);
				fos = new FileOutputStream(file);
			}
			else if (triggerFlag == 2){ //Print Proposal
					encodedString = commonService.printProposalAttachment(printProposalReq);
					pdfPath = pdfPath + pdfSeries +"_"+ strSuffix +".pdf" ;
					file = new File (pdfPath);
					fos = new FileOutputStream(file);
			}
			else if (triggerFlag == 3){ //Print policy
				encodedString = commonService.printPolicyAttachment(printProposalReq);	
				pdfPath = pdfPath + pdfSeries +"_"+ strSuffix +".pdf" ;
				file = new File (pdfPath);
				fos = new FileOutputStream(file);
			}
			else if (triggerFlag == 4){ //worksheet
				//Start: RahulT|<1959:Production Issue> | code added to set default userName & password
				printProposalReq.setUserID(prop.getProperty("userId"));
				printProposalReq.setPassword(prop.getProperty("password"));
				//End: RahulT|<1959:Production Issue> | code added to set default userName & password
				encodedString = commonService.printWorksheetAttachment(printProposalReq);
				pdfPath = pdfPath + pdfSeries +"_"+ strSuffix +".pdf" ;
				file = new File (pdfPath);
				fos = new FileOutputStream(file);
			}
			else if (triggerFlag == 5){	// Print receipt
				//Start: RahulT<Production 1928>| changes done to send single receipt number in part payment cases. 
				encodedString = commonService.printReceiptAttachment(strSuffix,printProposalReq.getUserID(),printProposalReq.getPassword(), attachmentDtl.getProposalNumber());
				pdfPath = pdfPath + pdfSeries +"_"+ strSuffix +".html" ;
				file = new File (pdfPath);
				fos = new FileOutputStream(file);
			}// 1704 : VishalJ | 11-Aug-2017 | To Send Attachment into Renewal SMS. | Start
			else if (triggerFlag == 6){	// Print receipt
				encodedString = commonService.printRenewalNoticeAttachment(attachmentDtl.getPolicyNumber(), printProposalReq.getUserID(), printProposalReq.getPassword());
				pdfPath = pdfPath + pdfSeries +"_"+ strSuffix +".html" ;
				file = new File (pdfPath);
				fos = new FileOutputStream(file);
			}
			// 1704 : VishalJ | 11-Aug-2017 | To Send Attachment into Renewal SMS. | End
			//br = new BufferedReader(new FileReader(pdfPath));
		
		if(fos!=null && encodedString!=null){
			logger.debug("File writting in progress..");
			fos.write(encodedString);
			fos.close();
		}
		//br.close();
		
			return pdfPath;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			if(br!=null)
				br.close();
			if(fos!=null)
				fos.close();
		}
		return pdfPath;
	}

}

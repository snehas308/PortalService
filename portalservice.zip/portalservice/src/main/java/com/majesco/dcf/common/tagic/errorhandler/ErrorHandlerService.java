package com.majesco.dcf.common.tagic.errorhandler;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public interface ErrorHandlerService {
	
	public String getErrorCodeByPropName(String propName) throws Exception;

}

package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CustomerDetails{
	private String title;
	private String firstName;
	private String middleName;
	private String lastName;
	private String dob;
	private String nationality;
	
	private String occupation;
	private String maritalstatus;
	private String gender;
	private String annualIncome;
	private String sourceOfIncome;
	private String organizationName;
	private String typeofCompany;
	private String spocName;
	private String custId;
	private String creationDate;
	private boolean isThinCust;
	
	private String cusoType;
	private String noOfpolprop;
	private AddressDetails addressDetList = null;
	private ContactDetails contDetList = null;
	private BankDetails bankdetList = null;
	private IdDetails idList = null;
	private String aadharNo;
	private String pancardNo;
	private String gstNumber;	//<Production 1213>
	
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public boolean getIsThinCust() {
		return isThinCust;
	}
	public void setisThinCust(boolean isThinCust) {
		this.isThinCust = isThinCust;
	}
	
	public String getCusoType() {
		return cusoType;
	}
	public void setCusoType(String cusoType) {
		this.cusoType = cusoType;
	}
	public String getNoOfpolprop() {
		return noOfpolprop;
	}
	public void setNoOfpolprop(String noOfpolprop) {
		this.noOfpolprop = noOfpolprop;
	}
	
	
	
	public AddressDetails getAddressDetList() {
		return addressDetList;
	}
	public void setAddressDetList(AddressDetails addressDetList) {
		this.addressDetList = addressDetList;
	}
	public ContactDetails getContDetList() {
		return contDetList;
	}
	public void setContDetList(ContactDetails contDetList) {
		this.contDetList = contDetList;
	}
	public BankDetails getBankdetList() {
		return bankdetList;
	}
	public void setBankdetList(BankDetails bankdetList) {
		this.bankdetList = bankdetList;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public IdDetails getIdList() {
		return idList;
	}
	public void setIdList(IdDetails idList) {
		this.idList = idList;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		if(firstName!=null)
			firstName=firstName.toUpperCase();
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		if(middleName!=null)
			middleName=middleName.toUpperCase();
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		if(lastName!=null)
			lastName=lastName.toUpperCase();
		this.lastName = lastName;
	}
	
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getMaritalstatus() {
		return maritalstatus;
	}
	public void setMaritalstatus(String maritalstatus) {
		this.maritalstatus = maritalstatus;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAnnualIncome() {
		return annualIncome;
	}
	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}
	public String getSourceOfIncome() {
		return sourceOfIncome;
	}
	public void setSourceOfIncome(String sourceOfIncome) {
		this.sourceOfIncome = sourceOfIncome;
	}
	public String getOrganizationName() {
		return organizationName;
	}
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	public String getTypeofCompany() {
		return typeofCompany;
	}
	public void setTypeofCompany(String typeofCompany) {
		this.typeofCompany = typeofCompany;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getSpocName() {
		return spocName;
	}
	public void setSpocName(String spocName) {
		this.spocName = spocName;
	}
	
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public void setThinCust(boolean isThinCust) {
		this.isThinCust = isThinCust;
	}
	public String getGstNumber() {
		return gstNumber;
	}
	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}
	
	
}

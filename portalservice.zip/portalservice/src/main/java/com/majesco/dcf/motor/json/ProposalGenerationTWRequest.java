package com.majesco.dcf.motor.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.CustomerDetails;
import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.common.tagic.util.ServiceUtility;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ProposalGenerationTWRequest extends UserObject {
	
	private String productCode;
	private String newPolStartDate;
	private String strcustID;
	private String strcustName;
	private String printFlag;
	private String isHardCopyReq;
	private CustomerDetails lstcustDet;
	private RiskDetails lstRiskdet;
	private VehicleRegDetails lstvecReg;
	private VehicleAdditionalDetails lsdaddDet;
	private DiscountDeatils lstdiscdet;
	private AddOnCoverDetails lstAddonCover;
	private PrevExistingPolDetails prvExisPolDet;
	private DriverDetails lstDrivrDet;
	private InsuredDetails lstInsuDet;
	private NomineeDetails lstNomDet;
	private ChannelDetails lstChanlDet;
	private CoverNoteDetails lstCvrNtDet;
	private DocumentChecklistDetails lstDocChkDet;
	private PreInspectionResultDetails lstPreInspResDet;
	
	private String posPanNo;
	private String posAdhaarNo;
	private String isPUP;
	//Additional Fields
	private String policyNumber;
	private String proposalNumber;
	private String quotationNumber;
	private String isRenew;
	private ProposalGenerationTWResponse proposalResponse;
	private String propInfoPolicyNumberChar;
	private String propInfoPolicyNo;
	private String propInfoNumCovernoteNo;
	private String generalApplicationNumber; //Added For Defect ID 1424
	ServiceUtility serviceUtility = new ServiceUtility();
	//private String authenticationToken;
				
	public String getProductCode() {
		return productCode;
	}
	public ProposalGenerationTWResponse getProposalResponse() {
		return proposalResponse;
	}
	public void setProposalResponse(ProposalGenerationTWResponse proposalResponse) {
		this.proposalResponse = proposalResponse;
	}
	public String getIsPUP() {
		return isPUP;
	}
	public void setIsPUP(String isPUP) {
		isPUP = serviceUtility.blankToNullCheck(isPUP);
		this.isPUP = isPUP;
	}
	public String getPosPanNo() {
		return posPanNo;
	}
	public void setPosPanNo(String posPanNo) {
		posPanNo = serviceUtility.blankToNullCheck(posPanNo);
		this.posPanNo = posPanNo;
	}
	public String getPosAdhaarNo() {
		return posAdhaarNo;
	}
	public void setPosAdhaarNo(String posAdhaarNo) {
		posAdhaarNo = serviceUtility.blankToNullCheck(posAdhaarNo);
		this.posAdhaarNo = posAdhaarNo;
	}
	public void setProductCode(String productCode) {
		policyNumber = serviceUtility.blankToNullCheck(policyNumber);
		this.productCode = productCode;
	}
	public String getNewPolStartDate() {
		return newPolStartDate;
	}
	public void setNewPolStartDate(String newPolStartDate) {
		newPolStartDate = serviceUtility.blankToNullCheck(newPolStartDate);
		this.newPolStartDate = newPolStartDate;
	}
	public String getStrcustID() {
		return strcustID;
	}
	public void setStrcustID(String strcustID) {
		strcustID = serviceUtility.blankToNullCheck(strcustID);
		this.strcustID = strcustID;
	}
	public String getStrcustName() {
		return strcustName;
	}
	public void setStrcustName(String strcustName) {
		strcustName = serviceUtility.blankToNullCheck(strcustName);
		this.strcustName = strcustName;
	}
	public String getPrintFlag() {
		return printFlag;
	}
	public void setPrintFlag(String printFlag) {
		printFlag = serviceUtility.blankToNullCheck(printFlag);
		this.printFlag = printFlag;
	}
	public String getIsHardCopyReq() {
		return isHardCopyReq;
	}
	public void setIsHardCopyReq(String isHardCopyReq) {
		isHardCopyReq = serviceUtility.blankToNullCheck(isHardCopyReq);
		this.isHardCopyReq = isHardCopyReq;
	}
	public CustomerDetails getLstcustDet() {
		return lstcustDet;
	}
	public void setLstcustDet(CustomerDetails lstcustDet) {
		this.lstcustDet = lstcustDet;
	}
	public RiskDetails getLstRiskdet() {
		return lstRiskdet;
	}
	public void setLstRiskdet(RiskDetails lstRiskdet) {
		this.lstRiskdet = lstRiskdet;
	}
	public VehicleRegDetails getLstvecReg() {
		return lstvecReg;
	}
	public void setLstvecReg(VehicleRegDetails lstvecReg) {
		this.lstvecReg = lstvecReg;
	}
	public VehicleAdditionalDetails getLsdaddDet() {
		return lsdaddDet;
	}
	public void setLsdaddDet(VehicleAdditionalDetails lsdaddDet) {
		this.lsdaddDet = lsdaddDet;
	}
	public DiscountDeatils getLstdiscdet() {
		return lstdiscdet;
	}
	public void setLstdiscdet(DiscountDeatils lstdiscdet) {
		this.lstdiscdet = lstdiscdet;
	}
	public AddOnCoverDetails getLstAddonCover() {
		return lstAddonCover;
	}
	public void setLstAddonCover(AddOnCoverDetails lstAddonCover) {
		this.lstAddonCover = lstAddonCover;
	}
	public PrevExistingPolDetails getPrvExisPolDet() {
		return prvExisPolDet;
	}
	public void setPrvExisPolDet(PrevExistingPolDetails prvExisPolDet) {
		this.prvExisPolDet = prvExisPolDet;
	}
	public DriverDetails getLstDrivrDet() {
		return lstDrivrDet;
	}
	public void setLstDrivrDet(DriverDetails lstDrivrDet) {
		this.lstDrivrDet = lstDrivrDet;
	}
	public InsuredDetails getLstInsuDet() {
		return lstInsuDet;
	}
	public void setLstInsuDet(InsuredDetails lstInsuDet) {
		this.lstInsuDet = lstInsuDet;
	}
	public NomineeDetails getLstNomDet() {
		return lstNomDet;
	}
	public void setLstNomDet(NomineeDetails lstNomDet) {
		this.lstNomDet = lstNomDet;
	}
	public ChannelDetails getLstChanlDet() {
		return lstChanlDet;
	}
	public void setLstChanlDet(ChannelDetails lstChanlDet) {
		this.lstChanlDet = lstChanlDet;
	}
	public CoverNoteDetails getLstCvrNtDet() {
		return lstCvrNtDet;
	}
	public void setLstCvrNtDet(CoverNoteDetails lstCvrNtDet) {
		this.lstCvrNtDet = lstCvrNtDet;
	}
	public DocumentChecklistDetails getLstDocChkDet() {
		return lstDocChkDet;
	}
	public void setLstDocChkDet(DocumentChecklistDetails lstDocChkDet) {
		this.lstDocChkDet = lstDocChkDet;
	}
	public PreInspectionResultDetails getLstPreInspResDet() {
		return lstPreInspResDet;
	}
	public void setLstPreInspResDet(PreInspectionResultDetails lstPreInspResDet) {
		this.lstPreInspResDet = lstPreInspResDet;
	}
	public String getProposalNumber() {
		return proposalNumber;
	}
	public void setProposalNumber(String proposalNumber) {
		proposalNumber = serviceUtility.blankToNullCheck(proposalNumber);
		this.proposalNumber = proposalNumber;
	}
	public String getQuotationNumber() {
		return quotationNumber;
	}
	public void setQuotationNumber(String quotationNumber) {
		quotationNumber = serviceUtility.blankToNullCheck(quotationNumber);
		this.quotationNumber = quotationNumber;
	}
	public String getIsRenew() {
		return isRenew;
	}
	public void setIsRenew(String isRenew) {
		isRenew = serviceUtility.blankToNullCheck(isRenew);
		this.isRenew = isRenew;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		policyNumber = serviceUtility.blankToNullCheck(policyNumber);
		this.policyNumber = policyNumber;
	}
	public String getPropInfoPolicyNumberChar() {
		return propInfoPolicyNumberChar;
	}
	public void setPropInfoPolicyNumberChar(String propInfoPolicyNumberChar) {
		propInfoPolicyNumberChar = serviceUtility.blankToNullCheck(propInfoPolicyNumberChar);
		this.propInfoPolicyNumberChar = propInfoPolicyNumberChar;
	}
	public String getPropInfoPolicyNo() {
		return propInfoPolicyNo;
	}
	public void setPropInfoPolicyNo(String propInfoPolicyNo) {
		propInfoPolicyNo = serviceUtility.blankToNullCheck(propInfoPolicyNo);
		this.propInfoPolicyNo = propInfoPolicyNo;
	}
	public String getPropInfoNumCovernoteNo() {
		return propInfoNumCovernoteNo;
	}
	public void setPropInfoNumCovernoteNo(String propInfoNumCovernoteNo) {
		propInfoNumCovernoteNo = serviceUtility.blankToNullCheck(propInfoNumCovernoteNo);
		this.propInfoNumCovernoteNo = propInfoNumCovernoteNo;
	}
	
//	public String getAuthenticationToken() {
//		return authenticationToken;
//	}
//	public void setAuthenticationToken(String authenticationToken) {
//		this.authenticationToken = authenticationToken;
//	}
	/*Added For Defect ID 1424 - Starts Here*/
	public String getGeneralApplicationNumber() {
		return generalApplicationNumber;
	}
	public void setGeneralApplicationNumber(String generalApplicationNumber) {
		generalApplicationNumber = serviceUtility.blankToNullCheck(generalApplicationNumber);
		this.generalApplicationNumber = generalApplicationNumber;
	}
	/*Added For Defect ID 1424 - Ends Here*/
	

}

package com.majesco.dcf.motor.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class GenerateQuoteMotorResponse {

	private String resultCode;
	private String quoteNumber;
	private String quotever;
	private PremiumDetails prmdet;
	private String isPreInspection;
	private String rulesWarning;
	private String campaignCode;
	private YearWiseIDVDetails yearWiseIDVDtls;	//Added For Issue ID 1318;
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}
	public String getRulesWarning() {
		return rulesWarning;
	}
	public void setRulesWarning(String rulesWarning) {
		this.rulesWarning = rulesWarning;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getQuoteNumber() {
		return quoteNumber;
	}
	public void setQuoteNumber(String quoteNumber) {
		this.quoteNumber = quoteNumber;
	}
	public String getQuotever() {
		return quotever;
	}
	public void setQuotever(String quotever) {
		this.quotever = quotever;
	}
	public PremiumDetails getPrmdet() {
		return prmdet;
	}
	public void setPrmdet(PremiumDetails prmdet) {
		this.prmdet = prmdet;
	}
	public List<PremiumBreakup> getPrmbrk() {
		return prmbrk;
	}
	public void setPrmbrk(List<PremiumBreakup> prmbrk) {
		this.prmbrk = prmbrk;
	}
	private List<PremiumBreakup> prmbrk;
	private List<ResponseError> resErr;
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public String getIsPreInspection() {
		return isPreInspection;
	}
	public void setIsPreInspection(String isPreInspection) {
		this.isPreInspection = isPreInspection;
	}
	/*Added For Issue ID 1318 - Starts Here*/
	public YearWiseIDVDetails getYearWiseIDVDtls() {
		return yearWiseIDVDtls;
	}
	public void setYearWiseIDVDtls(YearWiseIDVDetails yearWiseIDVDtls) {
		this.yearWiseIDVDtls = yearWiseIDVDtls;
	}
	/*Added For Issue ID 1318 - Ends Here*/
	
}

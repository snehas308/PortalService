package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PinCodeResponse {
	
	private String strpincodelocality;
	private String strcitycd;
	private String strcityval;
	private String strstatecd;
	private String strstateval;
	private String strdistrictcd;
	private String strdistrictval;
	private String strcountrycd;
	private String strcountryval;
	public String getStrcityval() {
		return strcityval;
	}
	public void setStrcityval(String strcityval) {
		this.strcityval = strcityval;
	}
	public String getStrstateval() {
		return strstateval;
	}
	public void setStrstateval(String strstateval) {
		this.strstateval = strstateval;
	}
	public String getStrcountryval() {
		return strcountryval;
	}
	public void setStrcountryval(String strcountryval) {
		this.strcountryval = strcountryval;
	}
	private List<ResponseError> resErr;
	
	
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public String getStrpincodelocality() {
		return strpincodelocality;
	}
	public void setStrpincodelocality(String strpincodelocality) {
		this.strpincodelocality = strpincodelocality;
	}
	
	
	public String getStrcitycd() {
		return strcitycd;
	}
	public void setStrcitycd(String strcitycd) {
		this.strcitycd = strcitycd;
	}
	
	
	public String getStrstatecd() {
		return strstatecd;
	}
	public void setStrstatecd(String strstatecd) {
		this.strstatecd = strstatecd;
	}
	
	
	public String getStrdistrictcd() {
		return strdistrictcd;
	}
	public void setStrdistrictcd(String strdistrictcd) {
		this.strdistrictcd = strdistrictcd;
	}
	
	
	public String getStrcountrycd() {
		return strcountrycd;
	}
	public void setStrcountrycd(String strcountrycd) {
		this.strcountrycd = strcountrycd;
	}
	public String getStrdistrictval() {
		return strdistrictval;
	}
	public void setStrdistrictval(String strdistrictval) {
		this.strdistrictval = strdistrictval;
	}
	
	
	

}

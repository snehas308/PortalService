package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import java.util.Date;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CalculateHealthRequest {
	
private String plan_type;
private Integer tenure;
private Integer no_individuals;
private Date dob;
private Integer family_size;
private Date dobem ;//Date of bith for eldest Member;
private Integer sum_insured;
private Integer deductible;
private boolean isFamily;


public String getPlan_type() {
	return plan_type;
}
public void setPlan_type(String plan_type) {
	this.plan_type = plan_type;
}
public Integer getTenure() {
	return tenure;
}
public void setTenure(Integer tenure) {
	this.tenure = tenure;
}
public Integer getNo_individuals() {
	return no_individuals;
}
public void setNo_individuals(Integer no_individuals) {
	this.no_individuals = no_individuals;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public Integer getFamily_size() {
	return family_size;
}
public void setFamily_size(Integer family_size) {
	this.family_size = family_size;
}
public Date getDobem() {
	return dobem;
}
public void setDobem(Date dobem) {
	this.dobem = dobem;
}
public Integer getSum_insured() {
	return sum_insured;
}
public void setSum_insured(Integer sum_insured) {
	this.sum_insured = sum_insured;
}
public Integer getDeductible() {
	return deductible;
}
public void setDeductible(Integer deductible) {
	this.deductible = deductible;
}
public boolean isFamily() {
	return isFamily;
}
public void setFamily(boolean isFamily) {
	this.isFamily = isFamily;
}
private Integer num1;
public Integer getNum1() {
	return num1;
}
public void setNum1(Integer num1) {
	this.num1 = num1;
}
public Integer getNum2() {
	return num2;
}
public void setNum2(Integer num2) {
	this.num2 = num2;
}
private Integer num2;

	

}

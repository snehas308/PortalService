package com.majesco.dcf.paproduct.service;



import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;








import com.majesco.dcf.paproduct.entity.QuotationPA;
import com.majesco.dcf.paproduct.entity.QuotationPA1;
import com.majesco.dcf.paproduct.json.IPAProposalDataRequest;
import com.majesco.dcf.paproduct.json.IPAProposalDataResponse;
import com.majesco.dcf.paproduct.json.IPAProposalRequest;
import com.majesco.dcf.paproduct.json.IPAProposalResponse;
import com.majesco.dcf.paproduct.json.SearchIPAQuotRequest;
import com.majesco.dcf.paproduct.json.SearchIPAQuotResponse;
import com.majesco.dcf.paproduct.json.SearchQuoteDetailsRequest;



@Service
@Transactional
public interface IPAService {
	
	public IPAProposalResponse getIPAProposalAG(IPAProposalRequest propPAReq) throws Exception;
	
	public IPAProposalResponse generateIPAProposalAS(IPAProposalRequest propPAReq) throws Exception;
	
	public IPAProposalResponse generateIPAPremiumAS(IPAProposalRequest propPAReq) throws Exception;
	
	public IPAProposalResponse generateIPAProposalSecurePlan(IPAProposalRequest propPAReq) throws Exception;
	
	public IPAProposalResponse getIPAPremiumAG(IPAProposalRequest propPAReq) throws Exception;
	
	public IPAProposalResponse getIPAPremiumSecurePlan(IPAProposalRequest propPAReq) throws Exception;
	
	//public ArrayList<QuotationPA1>getQuotationDetails(SearchQuoteDetailsRequest quoteDetails) throws Exception;

	public QuotationPA getQuotationDetails(QuotationPA quoteDetails) throws Exception;
	public IPAProposalDataResponse getIPAProposalDataAG(IPAProposalDataRequest prodPropDataReq) throws Exception;
	
	public IPAProposalDataResponse getIPAProposalDataAS(IPAProposalDataRequest prodPropDataReq) throws Exception;
	
	public IPAProposalDataResponse getIPAProposalDataSFP(IPAProposalDataRequest prodPropDataReq) throws Exception;
	
	public List<SearchIPAQuotResponse> searchIPAQuotationList(SearchIPAQuotRequest ipaQuotRequest) throws Exception;
	public SearchIPAQuotResponse getIPAQuotation(SearchIPAQuotRequest ipaQuotRequest) throws Exception;
}

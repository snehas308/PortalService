package com.majesco.dcf.covernote.service.impl;

import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.chp.util.CdataWriterInterceptor;
import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;
import com.majesco.dcf.common.tagic.util.CommonHelper;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.covernote.json.AgentCoverNoteBook;
import com.majesco.dcf.covernote.json.CancelMissingCNRequest;
import com.majesco.dcf.covernote.json.CancelMissingCNResponse;
import com.majesco.dcf.covernote.json.GenericCoverNoteRequest;
import com.majesco.dcf.covernote.json.GenericCoverNoteResponse;
import com.majesco.dcf.covernote.json.NextUnusedLeafNoRequest;
import com.majesco.dcf.covernote.json.NextUnusedLeafNoResponse;
import com.majesco.dcf.covernote.json.PhyCancelledRsnForCNLeafRequest;
import com.majesco.dcf.covernote.json.PhyCancelledRsnForCNLeafResponse;
import com.majesco.dcf.covernote.json.SaveOpenCNRequest;
import com.majesco.dcf.covernote.json.SaveOpenCNResponse;
import com.majesco.dcf.covernote.json.TagPaymentCNResponse;
import com.majesco.dcf.covernote.service.GenericCoverNoteService;
import com.majesco.dcf.receipt.util.ReceiptConstants;
import com.majesco.dcf.usermgmt.json.SecurityQuestion;
import com.majesco.dcf.usermgmt.json.SecurityQuestionResponse;
import com.unotechsoft.stub.accountservice.client.AccountService;
import com.unotechsoft.stub.accountservice.client.AccountService_Service;
import com.unotechsoft.stub.accountservice.client.ArrayOfClsPaymentIdGrid;
import com.unotechsoft.stub.accountservice.client.ArrayOfClsPolicyIdGrid;
import com.unotechsoft.stub.accountservice.client.ClsPaymentIdGrid;
import com.unotechsoft.stub.accountservice.client.ClsPolicyIdGrid;
import com.unotechsoft.stub.accountservice.client.LOVServiceResult;
import com.unotechsoft.stub.accountservice.client.PaymentTagingServiceResult;
import com.unotechsoft.stub.accountservice.client.SaveTagPayment2;
import com.unotechsoft.stub.accountservice.client.SaveTagPaymentResponse2;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentTaging;
import com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService;
import com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service;
import com.unotechsoft.stub.genericservice.client.ArrayOfKeyValueOfstringstring;
import com.unotechsoft.stub.genericservice.client.ArrayOfKeyValuePairList;
import com.unotechsoft.stub.genericservice.client.ArrayOfLOVType;
import com.unotechsoft.stub.genericservice.client.CoverNoteEntry;
import com.unotechsoft.stub.genericservice.client.GenericResult;
import com.unotechsoft.stub.genericservice.client.GenericSerive;
import com.unotechsoft.stub.genericservice.client.GenericSerive_Service;
import com.unotechsoft.stub.genericservice.client.KeyValuePairList;
import com.unotechsoft.stub.genericservice.client.LOVTypeRoutingCovernote;

@Service
@Transactional
public class GenericCoverNoteServiceImpl implements GenericCoverNoteService
{
  static final Logger logger = Logger.getLogger(GenericCoverNoteServiceImpl.class);
  
  @Value("${smc.source}")
  private String smc_source;
  
  @Value("${smc.medium}")
  private String smc_medium;
  
  @Value("${smc.campaign}")
  private String smc_campaign;
  
  @Autowired
  DBService dbserv;
  
  @Autowired
  TagicCommunicationService tagicCommunicationService;
  
  private String propValue;
  
  public GenericCoverNoteServiceImpl() {}
  
  private String getWSDLURL(String param)
  {
    try
    {
      propValue = dbserv.getWSDLURL(param, "com.majesco.dcf.common.tagic.entity.InterfaceParam");
      return propValue;
    }
    catch (Exception ae)
    {
      logger.error("Inside MotorServiceImpl :: getWSDLURL() method ::", ae);
    }
    return propValue;
  }
  
  public List<GenericCoverNoteResponse> getSavedCoverNoteDtl(GenericCoverNoteRequest getCoverNoteReq) throws Exception
  {
    String strMethodName = "getCoverNoteDtl";
    LOVTypeRoutingCovernote objLVRoutingCovernote = new LOVTypeRoutingCovernote();
    GenericCoverNoteResponse coverNoteResponse = null;
    List<GenericCoverNoteResponse> lstCoverNoteRespose = null;
    boolean success = false;
    try
    {
      logger.info("Inside " + _strClassName + "::" + strMethodName + "::Entered");
      String serviceUrl = getWSDLURL("GenericService");
      URL wsdlUrl = new URL(serviceUrl);
      GenericSerive_Service genericService = new GenericSerive_Service(wsdlUrl);
      GenericSerive port = genericService.getSOAPOverHTTP();
      ServiceUtility serviceUtil = new ServiceUtility();
      serviceUtil.addClientInterceptor(port);
      
      String _customerSearchForPortalGetObjectData_source = smc_source;
      String _customerSearchForPortalGetObjectData_medium = smc_medium;
      String _customerSearchForPortalGetObjectData_campaingn = smc_campaign;
      String _customerSearchForPortalGetObjectData_strLVTokenID = "";
      if ((getCoverNoteReq != null) && (getCoverNoteReq.getAuthToken() != null)) {
        _customerSearchForPortalGetObjectData_strLVTokenID = getCoverNoteReq.getAuthToken();
      }
      objLVRoutingCovernote.setChassisNo(getCoverNoteReq.getChassisNo());
      objLVRoutingCovernote.setCovernoteIssueDate(getCoverNoteReq.getCovernoteIssueDate());
      objLVRoutingCovernote.setCovernoteIssueTime(getCoverNoteReq.getCovernoteIssueTime());
      objLVRoutingCovernote.setCovernoteNo(getCoverNoteReq.getCoverNoteNo());
      objLVRoutingCovernote.setCustomerID(getCoverNoteReq.getCustomerId());
      objLVRoutingCovernote.setEngineNo(getCoverNoteReq.getEngineNo());
      objLVRoutingCovernote.setFirstName(getCoverNoteReq.getFirstName());
      objLVRoutingCovernote.setLastName(getCoverNoteReq.getLastName());
      objLVRoutingCovernote.setPolicyNo(getCoverNoteReq.getPolicyNo());
      objLVRoutingCovernote.setMiddleName(getCoverNoteReq.getMiddleName());
      objLVRoutingCovernote.setReferenceNo(getCoverNoteReq.getReferenceNo());
      objLVRoutingCovernote.setVehicleRegistrationNo(getCoverNoteReq.getVehicleRegistrationNo());
      objLVRoutingCovernote.setUserId(getCoverNoteReq.getUserID());
      
      GenericResult _genericCoverNoteService_return = port.getLOVRoutingCovernote(_customerSearchForPortalGetObjectData_source, _customerSearchForPortalGetObjectData_medium, _customerSearchForPortalGetObjectData_campaingn, _customerSearchForPortalGetObjectData_strLVTokenID, objLVRoutingCovernote);
      if ((_genericCoverNoteService_return != null) && (_genericCoverNoteService_return.getLOVTypes() != null)) {
        ArrayOfLOVType lstArrayOfLOVTypeResponse = _genericCoverNoteService_return.getLOVTypes();
        List lovTypeRoutingCovernoteList = lstArrayOfLOVTypeResponse.getLOVType();
        lstCoverNoteRespose = new ArrayList();
        
        for (int i = 0; i < lovTypeRoutingCovernoteList.size(); i++) {
          LOVTypeRoutingCovernote LOVTypeRoutingCovernote = new LOVTypeRoutingCovernote();
          coverNoteResponse = new GenericCoverNoteResponse();
          LOVTypeRoutingCovernote = (LOVTypeRoutingCovernote)lovTypeRoutingCovernoteList.get(i);
          coverNoteResponse.setChassisNo(LOVTypeRoutingCovernote.getChassisNo());
          coverNoteResponse.setCovernoteIssueDate(LOVTypeRoutingCovernote.getCovernoteIssueDate());
          coverNoteResponse.setCustomerId(LOVTypeRoutingCovernote.getCustomerID());
          coverNoteResponse.setFirstName(LOVTypeRoutingCovernote.getFirstName());
          coverNoteResponse.setMiddleName(LOVTypeRoutingCovernote.getMiddleName());
          coverNoteResponse.setEngineNo(LOVTypeRoutingCovernote.getEngineNo());
          coverNoteResponse.setPolicyNo(LOVTypeRoutingCovernote.getPolicyNo());
          coverNoteResponse.setCovernoteIssueTime(LOVTypeRoutingCovernote.getCovernoteIssueTime());
          coverNoteResponse.setCoverNoteNo(LOVTypeRoutingCovernote.getCovernoteNo());
          coverNoteResponse.setFirstName(LOVTypeRoutingCovernote.getFirstName());
          coverNoteResponse.setMiddleName(LOVTypeRoutingCovernote.getMiddleName());
          coverNoteResponse.setLastName(LOVTypeRoutingCovernote.getLastName());
          coverNoteResponse.setVehicleRegistrationNo(LOVTypeRoutingCovernote.getVehicleRegistrationNo());
          lstCoverNoteRespose.add(coverNoteResponse);
          success = true;
        }
      }
      

      if (!success) if ((((_genericCoverNoteService_return != null ? 1 : 0) & (_genericCoverNoteService_return.getErrorText() != null ? 1 : 0)) != 0) && (!_genericCoverNoteService_return.getErrorText().equals("")))
        {
          coverNoteResponse = new GenericCoverNoteResponse();
          coverNoteResponse.setErrorText(_genericCoverNoteService_return.getErrorText());
          lstCoverNoteRespose.add(coverNoteResponse);
        }
      logger.info("Inside " + _strClassName + "::" + strMethodName + "::Exit");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    
    return lstCoverNoteRespose;
  }
  
  public GenericCoverNoteResponse saveCoverNoteForCoreProcessing(GenericCoverNoteRequest getCoverNoteReq) throws Exception
  {
    String strMethodName = "saveCoverNoteForCoreProcessing";
    LOVTypeRoutingCovernote objLVRoutingCovernote = new LOVTypeRoutingCovernote();
    GenericCoverNoteResponse coverNoteResponse = null;
    try
    {
      logger.info("Inside " + _strClassName + "::" + strMethodName + "::Entered");
      String serviceUrl = getWSDLURL("GenericService");
      URL wsdlUrl = new URL(serviceUrl);
      GenericSerive_Service genericService = new GenericSerive_Service(wsdlUrl);
      GenericSerive port = genericService.getSOAPOverHTTP();
      ServiceUtility serviceUtil = new ServiceUtility();
      serviceUtil.addClientInterceptor(port);
      
      String _customerSearchForPortalGetObjectData_source = smc_source;
      String _customerSearchForPortalGetObjectData_medium = smc_medium;
      String _customerSearchForPortalGetObjectData_campaingn = smc_campaign;
      String _customerSearchForPortalGetObjectData_strLVTokenID = "";
      if ((getCoverNoteReq != null) && (getCoverNoteReq.getAuthToken() != null)) {
        _customerSearchForPortalGetObjectData_strLVTokenID = getCoverNoteReq.getAuthToken();
      }
      objLVRoutingCovernote.setChassisNo(getCoverNoteReq.getChassisNo());
      objLVRoutingCovernote.setCovernoteIssueDate(getCoverNoteReq.getCovernoteIssueDate());
      objLVRoutingCovernote.setCovernoteIssueTime(getCoverNoteReq.getCovernoteIssueTime());
      objLVRoutingCovernote.setCovernoteNo(getCoverNoteReq.getCoverNoteNo());
      objLVRoutingCovernote.setCustomerID(getCoverNoteReq.getCustomerId());
      objLVRoutingCovernote.setEngineNo(getCoverNoteReq.getEngineNo());
      objLVRoutingCovernote.setFirstName(getCoverNoteReq.getFirstName());
      objLVRoutingCovernote.setLastName(getCoverNoteReq.getLastName());
      objLVRoutingCovernote.setPolicyNo(getCoverNoteReq.getPolicyNo());
      objLVRoutingCovernote.setMiddleName(getCoverNoteReq.getMiddleName());
      objLVRoutingCovernote.setReferenceNo(getCoverNoteReq.getReferenceNo());
      objLVRoutingCovernote.setVehicleRegistrationNo(getCoverNoteReq.getVehicleRegistrationNo());
      objLVRoutingCovernote.setUserId(getCoverNoteReq.getUserID());
      
      GenericResult _genericCoverNoteService_return = port.saveRoutingCovernote(_customerSearchForPortalGetObjectData_source, _customerSearchForPortalGetObjectData_medium, _customerSearchForPortalGetObjectData_campaingn, _customerSearchForPortalGetObjectData_strLVTokenID, objLVRoutingCovernote);
      

      if ((((_genericCoverNoteService_return != null ? 1 : 0) & (_genericCoverNoteService_return.getErrorText() != null ? 1 : 0)) != 0) && (!_genericCoverNoteService_return.getErrorText().equals("")))
      {
        coverNoteResponse = new GenericCoverNoteResponse();
        coverNoteResponse.setErrorText(_genericCoverNoteService_return.getErrorText());
      }
      
      logger.info("Inside " + _strClassName + "::" + strMethodName + "::Exit");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    
    return coverNoteResponse;
  }
  
  public CancelMissingCNResponse cancelMissingCoverNote(CancelMissingCNRequest cancelMissingCNDtl)
    throws Exception
  {
    String strMethodName = "cancelMissingCoverNote";
    CancelMissingCNResponse cancelMissingCNRes = null;
    HashMap<String, String> reasonMap = new HashMap();
    HashMap<String, String> otherReasonMap = new HashMap();
    CoverNoteEntry objcoverNoteEntry = new CoverNoteEntry();
    SecurityQuestionResponse securityQuestionResponse = null;
    ObjectMapper objMap = new ObjectMapper();
    
    logger.info("Inside " + _strClassName + "::" + strMethodName + ":: Request JSON Received From UI : " + objMap.writeValueAsString(cancelMissingCNDtl));
    
    ArrayOfKeyValueOfstringstring objLVSessionParams = new ArrayOfKeyValueOfstringstring();
    try
    {
      logger.info("Inside " + _strClassName + "::" + strMethodName + "::Entered");
      String serviceUrl = getWSDLURL("GenericService");
      logger.info(" service  url for cancelMissingCoverNote " +serviceUrl);
      URL wsdlUrl = new URL(serviceUrl);
      GenericSerive_Service genericService = new GenericSerive_Service(wsdlUrl);
      GenericSerive port = genericService.getSOAPOverHTTP();
      ServiceUtility serviceUtil = new ServiceUtility();
      serviceUtil.addClientInterceptor(port);
      

      List securityQuestionParamList = dbserv.getSystemUserParamCodes(new Integer("2004"), "1");
      
      if (securityQuestionParamList != null)
      {
        securityQuestionResponse = new SecurityQuestionResponse();
        ArrayList<SecurityQuestion> securityQuestionList = new ArrayList();
        Iterator securityQuestionItr = securityQuestionParamList.iterator();
        
        if (securityQuestionItr != null)
        {
          HashMap<String, String> resultMap = new HashMap();
          
          while (securityQuestionItr.hasNext())
          {
            resultMap = (HashMap)securityQuestionItr.next();
            SecurityQuestion securityQuestion = new SecurityQuestion();
            if (resultMap != null)
            {
              reasonMap.put(resultMap.get("strparamcd"), resultMap.get("strcddesc"));
            }
          }
        }
      }
      


      List otherSecurityQuestionParamList = dbserv.getCovernoteOtherReasons(new Integer("2004"), cancelMissingCNDtl.getObjCoverNote().getCanceledReason());
      
      if (otherSecurityQuestionParamList != null) {
        securityQuestionResponse = new SecurityQuestionResponse();
        ArrayList<SecurityQuestion> securityQuestionList = new ArrayList();
        Iterator securityQuestionItr1 = otherSecurityQuestionParamList.iterator();
        
        if (securityQuestionItr1 != null) {
          HashMap<String, String> resultMap = new HashMap();
          
          while (securityQuestionItr1.hasNext()) {
            resultMap = (HashMap)securityQuestionItr1.next();
            SecurityQuestion securityQuestion = new SecurityQuestion();
            if (resultMap != null) {
              otherReasonMap.put(resultMap.get("strotherreasoncd"), resultMap.get("strotherreasondesc"));
            }
            
            securityQuestionList.add(securityQuestion);
          }
        }
      }
     

      
      
      logger.info("get the reason "+cancelMissingCNDtl.getObjCoverNote().getCanceledReason());
      
      
      String _source = smc_source;
      String _medium = smc_medium;
      String _campaingn = smc_campaign;
      String _strLVTokenID = "";
      if ((cancelMissingCNDtl != null) && (cancelMissingCNDtl.getAuthToken() != null)) {
        _strLVTokenID = cancelMissingCNDtl.getAuthToken();
        
      }
      if ((cancelMissingCNDtl != null) && (cancelMissingCNDtl.getObjCoverNote() != null)) {
        if ((cancelMissingCNDtl.getObjCoverNote().getCanceledReason() != null) && (cancelMissingCNDtl.getObjCoverNote().getCanceledReason().equals("2"))) {
         // cancelMissingCNDtl.getObjCoverNote().setCanceledReason(cancelMissingCNDtl.getObjCoverNote().getCanceledReason());
          cancelMissingCNDtl.getObjCoverNote().setUpdatedStatus("Missing");
          cancelMissingCNDtl.setCoverNoteFlag("LOST");
        }
        else if ((cancelMissingCNDtl.getObjCoverNote().getCanceledReason() != null) && (cancelMissingCNDtl.getObjCoverNote().getCanceledReason().equals("1"))) {
          //cancelMissingCNDtl.getObjCoverNote().setCanceledReason(cancelMissingCNDtl.getObjCoverNote().getCanceledReason());
          cancelMissingCNDtl.getObjCoverNote().setUpdatedStatus("Physically Cancelled");
          cancelMissingCNDtl.setCoverNoteFlag("CANCELLED");
        }
        else if ((cancelMissingCNDtl.getObjCoverNote().getCanceledReason() != null) && (cancelMissingCNDtl.getObjCoverNote().getCanceledReason().equals("3"))) {
          cancelMissingCNDtl.getObjCoverNote().setUpdatedStatus("Physically Cancelled");
          cancelMissingCNDtl.setCoverNoteFlag("Discrepancy");
        }
        else if ((cancelMissingCNDtl.getObjCoverNote().getCanceledReason() != null) && (cancelMissingCNDtl.getObjCoverNote().getCanceledReason().equals("4"))) {
          //cancelMissingCNDtl.getObjCoverNote().setCanceledReason(cancelMissingCNDtl.getObjCoverNote().getCanceledReason());
          cancelMissingCNDtl.getObjCoverNote().setUpdatedStatus("Used Book Sent To TAGIC");
          cancelMissingCNDtl.setCoverNoteFlag("CANCELLED");
        }
        else if ((cancelMissingCNDtl.getObjCoverNote().getCanceledReason() != null) && (cancelMissingCNDtl.getObjCoverNote().getCanceledReason().equals("5"))) {
           logger.info("cancel not sent to tagic  get the cancel reason "+cancelMissingCNDtl.getObjCoverNote().getCanceledReason());
           
           
         // cancelMissingCNDtl.getObjCoverNote().setCanceledReason("Unauthorized Overwriting");
          cancelMissingCNDtl.getObjCoverNote().setUpdatedStatus("CANCELLED COVERNOTE SENT TO TAGIC");
          cancelMissingCNDtl.setCoverNoteFlag("CANCELLED COVERNOTE SENT TO TAGIC");
         objcoverNoteEntry.setCancelledRsn("Unauthorized Overwriting");
          
        }
        else {
          cancelMissingCNDtl.getObjCoverNote().setUpdatedStatus("Other");
          cancelMissingCNDtl.setCoverNoteFlag((String)otherReasonMap.get(cancelMissingCNDtl.getObjCoverNote().getOtherReason()));
        }
        
        objcoverNoteEntry.setUserID(cancelMissingCNDtl.getUserID());
        objcoverNoteEntry.setIPAddress(cancelMissingCNDtl.getIpAddress());
        objcoverNoteEntry.setUpdatedStatus(cancelMissingCNDtl.getObjCoverNote().getUpdatedStatus());
        if ((cancelMissingCNDtl.getObjCoverNote().getCanceledReason() != null) && (cancelMissingCNDtl.getObjCoverNote().getCanceledReason().equals("4"))) {
          objcoverNoteEntry.setStartLeafNo(cancelMissingCNDtl.getObjCoverNote().getBookNumber());
          objcoverNoteEntry.setCancelledRsn("");
        }
        else {
          objcoverNoteEntry.setStartLeafNo(cancelMissingCNDtl.getObjCoverNote().getLeafNumber());
          objcoverNoteEntry.setCancelledRsn((String)otherReasonMap.get(cancelMissingCNDtl.getObjCoverNote().getCanceledReason()));
        }
      }
      String str=otherReasonMap.get(cancelMissingCNDtl.getObjCoverNote().getCanceledReason());
      
      for (Map.Entry<String,String> entry : otherReasonMap.entrySet()) {
          System.out.println("Key = " + entry.getKey() +
                           ", Value = " + entry.getValue());
      }
      
      logger.info("cancel not sent to tagic  get the cancel reason>>>>>>>>>> "+str);
      logger.info("Inside cancelMissingCoverNote   request and response "  );
      
      Client client=ClientProxy.getClient(port);
		PrintWriter writer = new PrintWriter(System.out);
		
		client.getOutInterceptors().add(new CdataWriterInterceptor());
		
		client.getInInterceptors().add(new LoggingInInterceptor(writer));
		
		client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
      
      CoverNoteEntry _return = port.updateCoverNoteLeafStatus(_source, _medium, _campaingn, _strLVTokenID, objcoverNoteEntry, cancelMissingCNDtl.getCoverNoteFlag(), objLVSessionParams);
      
      cancelMissingCNRes = new CancelMissingCNResponse();
      if ((((_return != null ? 1 : 0) & (_return.getErrorText() != null ? 1 : 0)) != 0) && (!_return.getErrorText().equals(""))) {
        cancelMissingCNRes.setErrorText(_return.getErrorText());
      }
      else
      {
        cancelMissingCNRes.setErrorText("Cover Note Cancelled Successfuly");
      }
      
      logger.info("Inside " + _strClassName + "::" + strMethodName + ":: Response JSON To UI : " + objMap.writeValueAsString(cancelMissingCNRes));
      
      logger.info("Inside " + _strClassName + "::" + strMethodName + "::Exit");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    
    return cancelMissingCNRes;
  }
  
  private static String _strClassName = "GenericCoverNoteServiceImpl";
  
  public SaveOpenCNResponse saveOpenCoverNoteAccService(SaveOpenCNRequest saveOpenCNReq) throws Exception
  {
    String wsdlUrl = null;
    SaveOpenCNResponse response = new SaveOpenCNResponse();
    String policyNo = null;
    String serviceURL = "";
    List<String> lstSubReceiptNo = new ArrayList();
    List<String> lstReceiptNo = new ArrayList();
    CommonHelper helper = new CommonHelper();
    try {
      logger.info("Inside TagicCommonServiceImpl :: saveOpenCoverNoteAccService() method :: Entered ::");
      
      wsdlUrl = getWSDLURL("GetDocumentForPortalService");
      URL serviceUrl = new URL(wsdlUrl);
      
      QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/GetDocumentForPortalService/", "GetDocumentForPortalService");
      GetDocumentForPortalService_Service ss = new GetDocumentForPortalService_Service(serviceUrl, SERVICE_NAME);
      GetDocumentForPortalService port = ss.getSOAPOverHTTP();
      
      ServiceUtility util = new ServiceUtility();
      util.addClientInterceptor(port);
      
      String _source = smc_source;
      String _medium = smc_medium;
      String _campaign = smc_campaign;
      String _authToken = saveOpenCNReq.getAuthToken();
      String _productCode = "";
      String _proposalNo = "";
      String _proposalDt = "";
      String _workflowId = "";
      String _engineNo = "";
      String _chassisNo = "";
      String _registrationNo1 = "";
      String _registrationNo2 = "";
      String _registrationNo3 = "";
      String _registrationNo4 = "";
      String _registrationNoNotReq = "";
      String _regNoAsPerOldLogic = "";
      String _riskStartDt = "";
      String _riskEndDt = "";
      String _modeOfOperation = "";
      String _userId = "";
      String _userRole = "";
      
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getProductCode() != null))
        _productCode = saveOpenCNReq.getProductCode();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getProposalNo() != null))
        _proposalNo = saveOpenCNReq.getProposalNo();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getProposalDate() != null))
        _proposalDt = saveOpenCNReq.getProposalDate();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getWorkflowid() != null))
        _workflowId = saveOpenCNReq.getWorkflowid();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getEngineNo() != null))
        _engineNo = saveOpenCNReq.getEngineNo();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getChassisNo() != null))
        _chassisNo = saveOpenCNReq.getChassisNo();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getVehiclRegNo1() != null))
        _registrationNo1 = saveOpenCNReq.getVehiclRegNo1();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getVehiclRegNo2() != null))
        _registrationNo2 = saveOpenCNReq.getVehiclRegNo2();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getVehiclRegNo3() != null))
        _registrationNo3 = saveOpenCNReq.getVehiclRegNo3();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getVehiclRegNo4() != null))
        _registrationNo4 = saveOpenCNReq.getVehiclRegNo4();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getVehiclRegNoNotReq() != null))
        _registrationNoNotReq = saveOpenCNReq.getVehiclRegNoNotReq();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getVehiclRegNoAsPerOldLogic() != null))
        _regNoAsPerOldLogic = saveOpenCNReq.getVehiclRegNoAsPerOldLogic();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getRiskStartDate() != null))
        _riskStartDt = saveOpenCNReq.getRiskStartDate();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getRiskEndDate() != null))
        _riskEndDt = saveOpenCNReq.getRiskEndDate();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getOperationMode() != null))
        _modeOfOperation = saveOpenCNReq.getOperationMode();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getUserID() != null))
        _userId = saveOpenCNReq.getUserID();
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getUserRole() != null)) {
        _userRole = saveOpenCNReq.getUserRole();
      } else {
        _userRole = "ADMIN";
      }
      
      String _result = port.saveOpenCoverNote(_source, _medium, _campaign, _authToken, _productCode, _proposalNo, _proposalDt, _workflowId, _engineNo, _chassisNo, _registrationNo1, _registrationNo2, _registrationNo3, _registrationNo4, _registrationNoNotReq, _regNoAsPerOldLogic, _riskStartDt, _riskEndDt, _modeOfOperation, _userId, _userRole);
      
      response.setStatus(_result);
      
      serviceURL = dbserv.getWSDLURL("AccountService", "com.majesco.dcf.common.tagic.entity.InterfaceParam");
      AccountService_Service accService = new AccountService_Service(new URL(serviceURL));
      UserDataPaymentTaging paymentTag = new UserDataPaymentTaging();
      paymentTag.setPayerId(saveOpenCNReq.getCustID());
      paymentTag.setProposalId(saveOpenCNReq.getProposalNo());
      paymentTag.setWorkflowName("RECEIPTINGAFTERUW");
      
      lstReceiptNo.add(saveOpenCNReq.getReceiptNumber());
      
      SaveTagPaymentResponse2 savePaymentResponse = getDetailsForCheckAutoPayment(paymentTag, accService, saveOpenCNReq, lstSubReceiptNo);
      if ((savePaymentResponse != null) && (savePaymentResponse.getSaveTagPaymentResult() != null) && (savePaymentResponse.getSaveTagPaymentResult().getErrorCode() != null) && (savePaymentResponse.getSaveTagPaymentResult().getErrorCode().equalsIgnoreCase("NA")))
      {
        policyNo = getPolicyNo(saveOpenCNReq);
        if ((policyNo != null) && (!policyNo.equals(""))) {
          response.setPolicyNo(policyNo);
          response.setReceiptNo(lstReceiptNo);
          response.setSubReceiptNo(lstSubReceiptNo);
          response.setTransactionId(saveOpenCNReq.getProposalNo());
          
          helper.sendCommunicationCNPolicy(saveOpenCNReq, response, tagicCommunicationService);
        }
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    return response;
  }
  

  public AgentCoverNoteBook getBookListFromAgentID(UserObject agentDtl)
    throws Exception
  {
    String strMethodName = "getBookListFromAgentID";
    List<String> coverNoteBookList = new ArrayList();
    AgentCoverNoteBook coverNoteResponse = new AgentCoverNoteBook();
    String coverNoteBookNo = null;
    String errorText = null;
    try {
      logger.info("Inside " + _strClassName + "::" + strMethodName + "::Execution started..");
      String serviceUrl = getWSDLURL("GenericService");
      URL wsdlUrl = new URL(serviceUrl);
      GenericSerive_Service genericService = new GenericSerive_Service(wsdlUrl);
      GenericSerive port = genericService.getSOAPOverHTTP();
      ServiceUtility serviceUtil = new ServiceUtility();
      serviceUtil.addClientInterceptor(port);
      
      String _source = smc_source;
      String _medium = smc_medium;
      String _campaingn = smc_campaign;
      String _strLVTokenID = "";
      if ((agentDtl != null) && (agentDtl.getAuthToken() != null))
        _strLVTokenID = agentDtl.getAuthToken();
      String _agentId = "";
      if ((agentDtl != null) && (agentDtl.getUserID() != null)) {
        _agentId = agentDtl.getUserID();
      }
      GenericResult _genericCoverNoteService_return = port.getCNBookListByAgentID(_source, _medium, _campaingn, _strLVTokenID, _agentId);
      if ((_genericCoverNoteService_return != null) && (_genericCoverNoteService_return.getKeyValuePairList() != null))
      {




        ArrayOfKeyValuePairList arrayOfKeyValuePairList = _genericCoverNoteService_return.getKeyValuePairList();
        
        if ((arrayOfKeyValuePairList != null) && (arrayOfKeyValuePairList.getKeyValuePairList() != null) && (arrayOfKeyValuePairList.getKeyValuePairList().size() > 0)) {
          for (KeyValuePairList keyValPair : arrayOfKeyValuePairList.getKeyValuePairList()) {
            coverNoteBookNo = keyValPair.getID();
            coverNoteBookList.add(coverNoteBookNo);
          }
        }
      }
      
      if ((((_genericCoverNoteService_return != null ? 1 : 0) & (_genericCoverNoteService_return.getErrorText() != null ? 1 : 0)) != 0) && (!_genericCoverNoteService_return.getErrorText().equals("")))
      {
        errorText = _genericCoverNoteService_return.getErrorText();
      }
      
      coverNoteResponse.setCoverNoteBookList(coverNoteBookList);
      coverNoteResponse.setErrorText(errorText);
      
      logger.info("Inside " + _strClassName + "::" + strMethodName + "::Exit");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    
    return coverNoteResponse;
  }
  
  public NextUnusedLeafNoResponse getNextUnusedLeafNoFromBookNo(NextUnusedLeafNoRequest bookNoDtl) throws Exception
  {
    String strMethodName = "getNextUnusedLeafNoFromBookNo";
    NextUnusedLeafNoResponse coverNoteResponse = new NextUnusedLeafNoResponse();
    try {
      logger.info("Inside " + _strClassName + "::" + strMethodName + "::Execution started..");
      String serviceUrl = getWSDLURL("GenericService");
      URL wsdlUrl = new URL(serviceUrl);
      GenericSerive_Service genericService = new GenericSerive_Service(wsdlUrl);
      GenericSerive port = genericService.getSOAPOverHTTP();
      ServiceUtility serviceUtil = new ServiceUtility();
      serviceUtil.addClientInterceptor(port);
      
      String _source = smc_source;
      String _medium = smc_medium;
      String _campaingn = smc_campaign;
      String _strLVTokenID = "";
      if ((bookNoDtl != null) && (bookNoDtl.getAuthToken() != null))
        _strLVTokenID = bookNoDtl.getAuthToken();
      String _bookNo = "";
      if ((bookNoDtl != null) && (bookNoDtl.getBookNumber() != null))
      {
        _bookNo = bookNoDtl.getBookNumber();
      }
      GenericResult _result = port.getNextUnusedLeafNoByCNBook(_source, _medium, _campaingn, _strLVTokenID, _bookNo);
      if (_result != null) {
        coverNoteResponse.setLeafNo(_result.getID());
        coverNoteResponse.setLeafName(_result.getName());
        coverNoteResponse.setErrorText(_result.getErrorText());
      }
      
      logger.info("Inside " + _strClassName + "::" + strMethodName + "::Exit");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    
    return coverNoteResponse;
  }
  
  private TagPaymentCNResponse tagPayment(UserDataPaymentTaging payTag, SaveOpenCNRequest saveOpenCNReq) throws Exception {
    TagPaymentCNResponse response = new TagPaymentCNResponse();
    String serviceURL = "";
    try {
      serviceURL = dbserv.getWSDLURL("AccountService", "com.majesco.dcf.common.tagic.entity.InterfaceParam");
      AccountService_Service accService = new AccountService_Service(new URL(serviceURL));
      
      String _source = smc_source;
      String _medium = smc_medium;
      String _campaingn = smc_campaign;
      String _strLVTokenID = "";
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getAuthToken() != null)) {
        _strLVTokenID = saveOpenCNReq.getAuthToken();
      }
      AccountService accServClient = accService.getSOAPOverHTTP();
      Client client = ClientProxy.getClient(accServClient);
      PrintWriter writer = new PrintWriter(System.out);
      
      PaymentTagingServiceResult _result = accServClient.tagPayment(_source, _medium, _campaingn, _strLVTokenID, payTag);
      response.setErrorCode(_result.getErrorCode());
      response.setErrorMsg(_result.getErrorMsg());
      response.setProductCode(_result.getProposalproductcode());
      response.setShortPremium(_result.getShortPremium());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return response;
  }
  
  private SaveTagPaymentResponse2 savePayment(UserDataPaymentTaging payTag, SaveOpenCNRequest saveOpenCNReq) throws Exception {
    SaveTagPaymentResponse2 response = new SaveTagPaymentResponse2();
    String serviceURL = "";
    try {
      serviceURL = dbserv.getWSDLURL("AccountService", "com.majesco.dcf.common.tagic.entity.InterfaceParam");
      AccountService_Service accService = new AccountService_Service(new URL(serviceURL));
      
      String _source = smc_source;
      String _medium = smc_medium;
      String _campaingn = smc_campaign;
      String _strLVTokenID = "";
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getAuthToken() != null)) {
        _strLVTokenID = saveOpenCNReq.getAuthToken();
      }
      AccountService accServClient = accService.getSOAPOverHTTP();
      Client client = ClientProxy.getClient(accServClient);
      PrintWriter writer = new PrintWriter(System.out);
      
      SaveTagPayment2 saveTagPayment = new SaveTagPayment2();
      saveTagPayment.setStrLVTokenID(_strLVTokenID);
      saveTagPayment.setSource(_source);
      saveTagPayment.setMedium(_medium);
      saveTagPayment.setCampaign(_campaingn);
      saveTagPayment.setObjUserDataPaymentTaging(payTag);
      response = accServClient.saveTagPayment(saveTagPayment);

    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return response;
  }
  
  private String getPolicyNo(SaveOpenCNRequest saveOpenCNReq) throws Exception {
    String policyNo = "";
    String serviceURL = "";
    try {
      serviceURL = dbserv.getWSDLURL("AccountService", "com.majesco.dcf.common.tagic.entity.InterfaceParam");
      AccountService_Service accService = new AccountService_Service(new URL(serviceURL));
      
      String _source = smc_source;
      String _medium = smc_medium;
      String _campaign = smc_campaign;
      String _strLVTokenID = "";
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getAuthToken() != null)) {
        _strLVTokenID = saveOpenCNReq.getAuthToken();
      }
      AccountService accServClient = accService.getSOAPOverHTTP();
      Client client = ClientProxy.getClient(accServClient);
      PrintWriter writer = new PrintWriter(System.out);
      
      policyNo = accServClient.getPolicyNumber(_source, _medium, _campaign, _strLVTokenID, saveOpenCNReq.getProposalNo());
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    return policyNo;
  }
  
  private SaveTagPaymentResponse2 getDetailsForCheckAutoPayment(UserDataPaymentTaging paymentTag, AccountService_Service accService, SaveOpenCNRequest saveOpenCNReq, List<String> lstSubReceiptNo)
  {
    SaveTagPaymentResponse2 serviceResponse = null;
    String serviceURL = "";
    try
    {
      String _source = smc_source;
      String _medium = smc_medium;
      String _campaign = smc_campaign;
      String _strLVTokenID = "";
      if ((saveOpenCNReq != null) && (saveOpenCNReq.getAuthToken() != null)) {
        _strLVTokenID = saveOpenCNReq.getAuthToken();
      }
      AccountService accServClient = accService.getSOAPOverHTTP();
      Client client = ClientProxy.getClient(accServClient);
      PrintWriter writer = new PrintWriter(System.out);
      

      LOVServiceResult lovResponse = accServClient.getDetailsForCheckAutoPayment(_source, _medium, _campaign, _strLVTokenID, paymentTag);
      
      if ((lovResponse != null) && (lovResponse.getClsPaymentIdLOV() != null) && (lovResponse.getClsPaymentIdLOV().getClsPaymentIdGrid() != null)) {
        for (ClsPaymentIdGrid advObj : lovResponse.getClsPaymentIdLOV().getClsPaymentIdGrid())
        {
          UserDataPaymentTaging payTag = new UserDataPaymentTaging();
          ClsPaymentIdGrid paymentIdGrid = new ClsPaymentIdGrid();
          ArrayOfClsPaymentIdGrid arrPaymentIdGrid = new ArrayOfClsPaymentIdGrid();
          ArrayOfClsPolicyIdGrid proposalGrid = new ArrayOfClsPolicyIdGrid();
          ClsPolicyIdGrid policyGrid = new ClsPolicyIdGrid();
          
          payTag.setBusinessType(ReceiptConstants.ACCOUNTSERVICE_BUSSTYPECD);
          payTag.setCallSLEnv("AP");
          payTag.setCheckAutopayment(Integer.valueOf(1));
          payTag.setModeOfEntry("5");
          

          payTag.setUserId(saveOpenCNReq.getUserID());
          payTag.setPayerId(saveOpenCNReq.getCustID());
          payTag.setPayerType("1");
          payTag.setTransactionId(saveOpenCNReq.getReceiptNumber());
          payTag.setTransactionTime(advObj.getPaymentReceivedDate());
          

          payTag.setAutoAcceptanceApplicable(Integer.valueOf(0));
          payTag.setBankChargeAmt(new Long(0L));
          payTag.setDealerId("0");
          payTag.setDealerName("");
          payTag.setFinancierID("0");
          payTag.setGenPolicy(Integer.valueOf(0));
          payTag.setInstrumentAmount(new Long(0L));
          payTag.setInstrumentId("");
          payTag.setIntermediaryId("0");
          payTag.setIs64VbAllowed(Boolean.valueOf(false));
          payTag.setIsAutoPaymentChecked(Boolean.valueOf(false));
          payTag.setIsAutoPropChecked(Boolean.valueOf(false));
          payTag.setIsCreditPolicy(Boolean.valueOf(false));
          payTag.setIsShortFallNonAllowedFlg(Boolean.valueOf(false));
          payTag.setIsShortPremAllowedFlg(Boolean.valueOf(false));
          payTag.setMaxPremium(new Long(0L));
          payTag.setMonthlyExtension(Integer.valueOf(0));
          payTag.setOtherBankApplicability("0");
          payTag.setProposalUnPaidAmount(new Long(0L));
          payTag.setShortPremium("0");
          payTag.setTagSequence(Integer.valueOf(0));
          payTag.setTotalInstrumentBalanceAmount(new Long(0L));
          payTag.setWorkflowName("");
          payTag.setProposalAmount(new Long(0L));
          
          policyGrid.setBankCharge("0");
          policyGrid.setIsChecked(Boolean.valueOf(true));
          policyGrid.setProposalNo(saveOpenCNReq.getProposalNo());
          policyGrid.setProposalDate(advObj.getPaymentReceivedDate());
          proposalGrid.getClsPolicyIdGrid().add(policyGrid);
          payTag.setClsProposalDetailsGrd(proposalGrid);
          
          paymentIdGrid.setPaymenID(advObj.getPaymenID());
          paymentIdGrid.setIsChecked(Boolean.valueOf(true));
          paymentIdGrid.setRowNum("1");
          arrPaymentIdGrid.getClsPaymentIdGrid().add(paymentIdGrid);
          payTag.setClsPaymentDetailsGrd(arrPaymentIdGrid);
          lstSubReceiptNo.add(advObj.getPaymenID());
          TagPaymentCNResponse tagPaymentResponse = tagPayment(payTag, saveOpenCNReq);
          if ((tagPaymentResponse != null) && (tagPaymentResponse.getErrorCode() != null) && (tagPaymentResponse.getErrorCode().equals("-1")))
          {
            serviceResponse = savePayment(payTag, saveOpenCNReq);
          }
        }
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    return serviceResponse;
  }
  

	@Override
	public List<PhyCancelledRsnForCNLeafResponse> phyCancelledRsnForCNLeaf(PhyCancelledRsnForCNLeafRequest phyCancelledRsnForCNLeafRequest)
			throws Exception {
		 String strMethodName="phyCancelledRsnForCNLeaf";
		 String leafNo = "";
		 logger.info("Inside_Parvind_Method");
		 PhyCancelledRsnForCNLeafResponse phyCancelledRsnForCNLeafResponse = null;
		 List<PhyCancelledRsnForCNLeafResponse> PhyCancelledRsnForCNLeafResponseList = null;
		 boolean success = false;
		 try{
			 
			
		String serviceUrl=getWSDLURL(CommonConstants.GENERIC_COVERNOTE_SERVICE);
		URL wsdlUrl=new URL(serviceUrl);
		com.unotechsoft.stub.wsdl.genericserive.GenericSerive_Service genericService=new com.unotechsoft.stub.wsdl.genericserive.GenericSerive_Service(wsdlUrl);
		com.unotechsoft.stub.wsdl.genericserive.GenericSerive port=genericService.getSOAPOverHTTP();
		ServiceUtility serviceUtil=new ServiceUtility();
		serviceUtil.addClientInterceptor(port);
		String _source = smc_source;
      String _medium = smc_medium;
      String _campaingn = smc_campaign;
      String _strLVTokenID = "";
      if(phyCancelledRsnForCNLeafRequest!=null && phyCancelledRsnForCNLeafRequest.getAuthToken()!=null)
      	_strLVTokenID=phyCancelledRsnForCNLeafRequest.getAuthToken();
      String _leafNo = "";
      if(phyCancelledRsnForCNLeafRequest!=null && phyCancelledRsnForCNLeafRequest.getLeafNumber()!=null)
	    _leafNo = phyCancelledRsnForCNLeafRequest.getLeafNumber();
      logger.info("Inside_Parvind_Method_1");
      org.datacontract.schemas._2004._07.genericmasterbl.GenericResult _result  = port.getPhyCancelledRsnForCNLeaf(_source, _medium, _campaingn, _strLVTokenID, _leafNo);
      org.datacontract.schemas._2004._07.genericmasterbl.ArrayOfLOVType ArrayOfLOVTypeResponse = _result.getLOVTypes(); 
     List<org.datacontract.schemas._2004._07.genericmasterbl.LOVType> lovTypeRoutingCovernoteList = ArrayOfLOVTypeResponse.getLOVType();
     PhyCancelledRsnForCNLeafResponseList = new ArrayList<PhyCancelledRsnForCNLeafResponse>();
     logger.info("Inside_Parvind_Method_2");
     for(org.datacontract.schemas._2004._07.genericmasterbl.LOVType lovType:lovTypeRoutingCovernoteList){  
  	   phyCancelledRsnForCNLeafResponse = new PhyCancelledRsnForCNLeafResponse();
  	   phyCancelledRsnForCNLeafResponse.setId(lovType.getID());
  	   phyCancelledRsnForCNLeafResponse.setReason(lovType.getName());
  	   //phyCancelledRsnForCNLeafResponse.setErrorText(lovType.getErrorText());
  	  
  	   
  	   PhyCancelledRsnForCNLeafResponseList.add(phyCancelledRsnForCNLeafResponse);
  	   
  		success = true;
  	    }  
     
  /*  if (!success && _result!= null & _result.getErrorText()!=null 
	        		&&!_result.getErrorText().equals("")){
  	  
				phyCancelledRsnForCNLeafResponse = new PhyCancelledRsnForCNLeafResponse();
				phyCancelledRsnForCNLeafResponse.setErrorText(_result.getErrorText());
				PhyCancelledRsnForCNLeafResponseList.add(phyCancelledRsnForCNLeafResponse);
	      
			}*/
    logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
    
    
		  }
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		  logger.info("ParvindList::"+PhyCancelledRsnForCNLeafResponseList);
		return PhyCancelledRsnForCNLeafResponseList;
	}
	
	
}
 
 

package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class RenewalSearchResponse extends ResultObject {

	private ArrayList<RenewalSearchData> renewalSearchDataList ;
	public ArrayList<RenewalSearchData> getRenewalSearchDataList() {
		return renewalSearchDataList;
	}

	public void setRenewalSearchDataList(
			ArrayList<RenewalSearchData> renewalSearchDataList) {
		this.renewalSearchDataList = renewalSearchDataList;
	}	
}

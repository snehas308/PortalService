package com.majesco.dcf.common.tagic.json;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.dozer.Mapping;

import java.util.Date;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CalculateHomeRequest {

	private String strplantype;
	private Integer sumInsured;
	private Integer tenure;
	private Double fireRate;
	private Double earthquakerate;
	private Double terorismRate;
	private Integer building;
	private Integer content;
	
	
	public String getStrplantype() {
		return strplantype;
	}
	public void setStrplantype(String strplantype) {
		this.strplantype = strplantype;
	}
	public Integer getSumInsured() {
		return sumInsured;
	}
	public void setSumInsured(Integer sumInsured) {
		this.sumInsured = sumInsured;
	}
	public Integer getTenure() {
		return tenure;
	}
	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}
	public Double getFireRate() {
		return fireRate;
	}
	public void setFireRate(Double fireRate) {
		this.fireRate = fireRate;
	}
	public Double getEarthquakerate() {
		return earthquakerate;
	}
	public void setEarthquakerate(Double earthquakerate) {
		this.earthquakerate = earthquakerate;
	}
	public Double getTerorismRate() {
		return terorismRate;
	}
	public void setTerorismRate(Double terorismRate) {
		this.terorismRate = terorismRate;
	}
	public Integer getBuilding() {
		return building;
	}
	public void setBuilding(Integer building) {
		this.building = building;
	}
	public Integer getContent() {
		return content;
	}
	public void setContent(Integer content) {
		this.content = content;
	}

	
	
}


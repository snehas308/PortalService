package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class AccountPaymentRecieptResponse {
	
	private List<ResponseError> resErr;
	private String transNo;
	private String transDate;
	private String polNo;
	private String totPremPaid;
	
	
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	
	
	public String getTransNo() {
		return transNo;
	}
	public void setTransNo(String transNo) {
		this.transNo = transNo;
	}
	
	
	public String getTransDate() {
		return transDate;
	}
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	
	
	public String getPolNo() {
		return polNo;
	}
	public void setPolNo(String polNo) {
		this.polNo = polNo;
	}
	
	
	public String getTotPremPaid() {
		return totPremPaid;
	}
	public void setTotPremPaid(String totPremPaid) {
		this.totPremPaid = totPremPaid;
	}

	
	
}

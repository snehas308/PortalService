package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PrevInsurerRequest {
	private String strcompanycd="";

	public String getStrcompanycd() {
		return strcompanycd;
	}

	public void setStrcompanycd(String strcompanycd) {
		this.strcompanycd = strcompanycd;
	}
	
}

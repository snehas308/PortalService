package com.majesco.dcf.common.tagic.json;
import javax.net.ssl.*; 
import java.io.*; 
import java.net.URL; 
import java.security.*; 
import java.security.cert.CertificateException; 
import java.security.cert.X509Certificate; 

public class Ticket
{ 
static { 
	System.out.println("Vishal");
disableSslVerification(); 
} 

private static void disableSslVerification() { 
try 
{ 
// Create a trust manager that does not validate certificate chains 
TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() { 
public java.security.cert.X509Certificate[] getAcceptedIssuers() { 
return null; 
} 
public void checkClientTrusted(X509Certificate[] certs, String authType) { 
} 
public void checkServerTrusted(X509Certificate[] certs, String authType) { 
} 
} 
}; 

// Install the all-trusting trust manager 
SSLContext sc = SSLContext.getInstance("SSL"); 
sc.init(null, trustAllCerts, new java.security.SecureRandom()); 
HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory()); 

// Create all-trusting host name verifier 
HostnameVerifier allHostsValid = new HostnameVerifier() { 
public boolean verify(String hostname, SSLSession session) { 
return true; 
} 
}; 

// Install the all-trusting host verifier 
HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid); 
} catch (NoSuchAlgorithmException e) { 
e.printStackTrace(); 
} catch (KeyManagementException e) { 
e.printStackTrace(); 
} 
} 

public String createConnection(HttpsURLConnection connection, String reqBody) throws Exception {		
	if(reqBody!=null) {	
		OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream());
		wr.write(reqBody);
		wr.flush(); // Get the response from the QPS BufferedReader
	}		
	BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	StringBuilder builder = new StringBuilder();
	String inputLine;
	while ((inputLine = in.readLine()) != null) {
		builder.append(inputLine);
	}
	in.close();
	String result = builder.toString();
	return result;
}

public String getQlikTicket(String userID, String userDir) 
{ 
String qlikTicketNo = ""; 
System.out.println("Qlik userID :- "+userID);

String xrfkey = "7rBHABt65vFflaZ7"; //Xrfkey to prevent cross-site issues 
String host = "10.33.194.123"; //Enter the Qlik Sense Server hostname here 
String vproxy = "sess"; //Enter the prefix for the virtual proxy configured in Qlik Sense Steps Step 1 
try 
{ 

/************** BEGIN Certificate Acquisition **************/ 
String certFolder = "/home/showbhik.majesco/AGENTPORTAL/qlik/"; //This is a folder reference to the location of the jks files used for securing ReST communication 
String proxyCert = certFolder + "clientcert.jks"; //Reference to the client jks file which includes the client certificate with private key 
String proxyCertPass="pass@123"; //This is the password to access the Java Key Store information 
String rootCert = certFolder + "root.jks"; //Reference to the root certificate for the client cert. Required in this example because Qlik Sense certs are used. 
String rootCertPass = "pass@123"; //This is the password to access the Java Key Store information 
/************** END Certificate Acquisition **************/ 


/************** BEGIN Certificate configuration for use in connection **************/ 
KeyStore ks = KeyStore.getInstance("JKS"); 
ks.load(new FileInputStream(new File(proxyCert)), proxyCertPass.toCharArray()); 
KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()); 
kmf.init(ks, proxyCertPass.toCharArray()); 
SSLContext context = SSLContext.getInstance("SSL"); 
KeyStore ksTrust = KeyStore.getInstance("JKS"); 
ksTrust.load(new FileInputStream(rootCert), rootCertPass.toCharArray()); 
TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()); 
tmf.init(ksTrust); 
context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null); 
SSLSocketFactory sslSocketFactory = context.getSocketFactory(); 
/************** END Certificate configuration for use in connection **************/ 


/************** BEGIN HTTPS Connection **************/ 
System.out.println("Browsing to: " + "https://" + host + ":4243/qps/" + vproxy + "/ticket?xrfkey=" + xrfkey); 
URL url = new URL("https://" + host + ":4243/qps/" + vproxy + "/ticket?xrfkey=" + xrfkey); 
HttpsURLConnection connection = (HttpsURLConnection ) url.openConnection(); 
connection.setSSLSocketFactory(sslSocketFactory); 
connection.setRequestProperty("X-Qlik-Xrfkey", xrfkey); connection.setDoOutput(true); 
connection.setDoInput(true); 
connection.setRequestProperty("Content-Type","application/json"); 
connection.setRequestProperty("Accept", "application/json"); 
connection.setRequestMethod("POST"); 
/************** BEGIN JSON Message to Qlik Sense Proxy API **************/ 


String body = "{ 'UserId':'" + userID + "','UserDirectory':'" + userDir +"',"; 
body+= "'Attributes': []"; body+= "}"; System.out.println("Payload: " + body); 
/************** END JSON Message to Qlik Sense Proxy API **************/ 


OutputStreamWriter wr= new OutputStreamWriter(connection.getOutputStream()); 
wr.write(body); 
wr.flush(); //Get the response from the QPS BufferedReader 
BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream())); 
StringBuilder builder = new StringBuilder(); 
String inputLine; 
while ((inputLine = in.readLine()) != null) 
{ 
builder.append(inputLine); 
} 
in.close(); 
String result = builder.toString(); 
System.out.println("The response from the server is: " + result); 
if(result!=null && result.contains("Ticket\":")) { 
qlikTicketNo = result.replaceAll("\\r\\n","").replaceAll("\"","").split("Ticket:")[1].split(",")[0].replaceAll("\\r\\n",""); 
} 
/************** END HTTPS Connection **************/ 
/************** Start Test Report call **************
URL reportUrl = new URL("https://10.33.194.123/sess/extensions/External_QAP/External_QAP.html?qlikTicket=" + qlikTicketNo);
connection = (HttpsURLConnection) reportUrl.openConnection();
connection.setRequestProperty("Content-Type", "text/html");
connection.setDoOutput(true);
connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36");
connection.setRequestMethod("GET");
connection.connect();
result = createConnection(connection, null);
System.out.println("Response Code : " + connection.getResponseCode());
System.out.println("Result : " + result);

/************** End Test Report call **************/
} catch (Exception e) {
	e.printStackTrace();
}
return qlikTicketNo; 
} 



/*public static void main(String[] args) 
{ 
	System.out.println("TicketId:"); 
Ticket ticket = new Ticket(); 
String qlikTicket = ticket.getQlikTicket(args[0],args[1]); 
System.out.println("TicketId:"+qlikTicket); 
} */
}

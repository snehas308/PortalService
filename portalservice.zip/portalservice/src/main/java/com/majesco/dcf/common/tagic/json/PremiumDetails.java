package com.majesco.dcf.common.tagic.json;

public class PremiumDetails {

	private String netPremium;
	private String totalPremium;
	private String sumInsured;
	private String serviceTax;
	private String discount;
	private String premiumPayable;
	private String premRate;
	private String addonPremiumPayable;
	private String basisOfRating;
	private String campaign;
	private String basisOfRatingGC;
	
	public String getAddonPremiumPayable() {
		return addonPremiumPayable;
	}
	public void setAddonPremiumPayable(String addonPremiumPayable) {
		this.addonPremiumPayable = addonPremiumPayable;
	}
	public String getPremRate() {
		return premRate;
	}
	public void setPremRate(String premRate) {
		this.premRate = premRate;
	}
	public String getNetPremium() {
		return netPremium;
	}
	public void setNetPremium(String netPremium) {
		this.netPremium = netPremium;
	}
	public String getTotalPremium() {
		return totalPremium;
	}
	public void setTotalPremium(String totalPremium) {
		this.totalPremium = totalPremium;
	}
	public String getSumInsured() {
		return sumInsured;
	}
	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}
	public String getServiceTax() {
		return serviceTax;
	}
	public void setServiceTax(String serviceTax) {
		this.serviceTax = serviceTax;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	public String getPremiumPayable() {
		return premiumPayable;
	}
	public void setPremiumPayable(String premiumPayable) {
		this.premiumPayable = premiumPayable;
	}
	public String getBasisOfRating() {
		return basisOfRating;
	}
	public void setBasisOfRating(String basisOfRating) {
		this.basisOfRating = basisOfRating;
	}
	public String getCampaign() {
		return campaign;
	}
	public void setCampaign(String campaign) {
		this.campaign = campaign;
	}
	public String getBasisOfRatingGC() {
		return basisOfRatingGC;
	}
	public void setBasisOfRatingGC(String basisOfRatingGC) {
		this.basisOfRatingGC = basisOfRatingGC;
	}
	
	
}

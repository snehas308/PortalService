package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.codec.binary.Base64;

@Entity
//@Table(name = "dcf_accmst_bank_branch_relation",schema="dcf_master")			// Commented for oracle migration
@Table(name = "dcf_accmst_bank_brnch_relation")									// Added for oracle migration
public class Account_BankBranch_Master implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="dcf_accmst_bank_branch_relation_seq")
	@SequenceGenerator(
			name="dcf_accmst_bank_branch_relation_seq",
			sequenceName="dcf_accmst_bank_branch_relation_seq",
			allocationSize=1
	)
	@Column(name = "srno")
	private long srno;
	
	@Column(name = "num_financier_cd")
	private int num_financier_cd;
		
	@Column(name = "num_financier_branch_cd" )
	private int num_financier_branch_cd;
			
	@Column(name = "num_office_cd")
	private int num_office_cd;
	
	@Column(name = "txt_transaction_type_cd")
	private String txt_transaction_type_cd;
		
	@Column(name = "txt_ledger_account_cd")
	private String txt_ledger_account_cd;
	
	@Column(name = "txt_bank_account_no_cheque")	
	private String txt_bank_account_no_cheque;
	
	@Column(name = "txt_bank_account_no_cash")
	private String txt_bank_account_no_cash;
	
	@Column(name = "txt_default_flag")
	private String txt_default_flag;
	
	@Column(name = "num_insert_trans_id")
	private int num_insert_trans_id;
	
	@Column(name = "num_modify_trans_id")
	private int num_modify_trans_id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "dat_insert_date")
	private Date dat_insert_date;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "dat_modify_date")
	private Date dat_modify_date;
	
	
	@Column(name = "num_collection_account_cd")
	private int num_collection_account_cd;
	

	@Column(name = "num_commission_account_cd")
	private int num_commission_account_cd;
	
	@Column(name = "num_otherpmnt_account_cd")
	private int num_otherpmnt_account_cd;
	
	@Column(name = "num_claim_account_cd")
	private int num_claim_account_cd;
	
	@Column(name = "txt_cheque_gen_req")
	private String txt_cheque_gen_req;
	

	@Column(name = "txt_yn_chq_no_manual")
	private String txt_yn_chq_no_manual;
	

	@Column(name = "txt_payment_mode")
	private String txt_payment_mode;


	public int getNum_financier_cd() {
		return num_financier_cd;
	}


	public void setNum_financier_cd(int num_financier_cd) {
		this.num_financier_cd = num_financier_cd;
	}


	public int getNum_financier_branch_cd() {
		return num_financier_branch_cd;
	}


	public void setNum_financier_branch_cd(int num_financier_branch_cd) {
		this.num_financier_branch_cd = num_financier_branch_cd;
	}


	public int getNum_office_cd() {
		return num_office_cd;
	}


	public void setNum_office_cd(int num_office_cd) {
		this.num_office_cd = num_office_cd;
	}


	public String getTxt_transaction_type_cd() {
		return txt_transaction_type_cd;
	}


	public void setTxt_transaction_type_cd(String txt_transaction_type_cd) {
		this.txt_transaction_type_cd = txt_transaction_type_cd;
	}


	public String getTxt_ledger_account_cd() {
		return txt_ledger_account_cd;
	}


	public void setTxt_ledger_account_cd(String txt_ledger_account_cd) {
		this.txt_ledger_account_cd = txt_ledger_account_cd;
	}


	public String getTxt_bank_account_no_cheque() {
		return txt_bank_account_no_cheque;
	}


	public void setTxt_bank_account_no_cheque(String txt_bank_account_no_cheque) {
		this.txt_bank_account_no_cheque = txt_bank_account_no_cheque;
	}


	public String getTxt_bank_account_no_cash() {
		return txt_bank_account_no_cash;
	}


	public void setTxt_bank_account_no_cash(String txt_bank_account_no_cash) {
		this.txt_bank_account_no_cash = txt_bank_account_no_cash;
	}


	public String getTxt_default_flag() {
		return txt_default_flag;
	}


	public void setTxt_default_flag(String txt_default_flag) {
		this.txt_default_flag = txt_default_flag;
	}


	public int getNum_insert_trans_id() {
		return num_insert_trans_id;
	}


	public void setNum_insert_trans_id(int num_insert_trans_id) {
		this.num_insert_trans_id = num_insert_trans_id;
	}


	public int getNum_modify_trans_id() {
		return num_modify_trans_id;
	}


	public void setNum_modify_trans_id(int num_modify_trans_id) {
		this.num_modify_trans_id = num_modify_trans_id;
	}


	public Date getDat_insert_date() {
		return dat_insert_date;
	}


	public void setDat_insert_date(Date dat_insert_date) {
		this.dat_insert_date = dat_insert_date;
	}


	public Date getDat_modify_date() {
		return dat_modify_date;
	}


	public void setDat_modify_date(Date dat_modify_date) {
		this.dat_modify_date = dat_modify_date;
	}


	public int getNum_collection_account_cd() {
		return num_collection_account_cd;
	}


	public void setNum_collection_account_cd(int num_collection_account_cd) {
		this.num_collection_account_cd = num_collection_account_cd;
	}


	public int getNum_commission_account_cd() {
		return num_commission_account_cd;
	}


	public void setNum_commission_account_cd(int num_commission_account_cd) {
		this.num_commission_account_cd = num_commission_account_cd;
	}


	public int getNum_otherpmnt_account_cd() {
		return num_otherpmnt_account_cd;
	}


	public void setNum_otherpmnt_account_cd(int num_otherpmnt_account_cd) {
		this.num_otherpmnt_account_cd = num_otherpmnt_account_cd;
	}


	public int getNum_claim_account_cd() {
		return num_claim_account_cd;
	}


	public void setNum_claim_account_cd(int num_claim_account_cd) {
		this.num_claim_account_cd = num_claim_account_cd;
	}


	public String getTxt_cheque_gen_req() {
		return txt_cheque_gen_req;
	}


	public void setTxt_cheque_gen_req(String txt_cheque_gen_req) {
		this.txt_cheque_gen_req = txt_cheque_gen_req;
	}


	public String getTxt_yn_chq_no_manual() {
		return txt_yn_chq_no_manual;
	}


	public void setTxt_yn_chq_no_manual(String txt_yn_chq_no_manual) {
		this.txt_yn_chq_no_manual = txt_yn_chq_no_manual;
	}


	public String getTxt_payment_mode() {
		return txt_payment_mode;
	}


	public void setTxt_payment_mode(String txt_payment_mode) {
		this.txt_payment_mode = txt_payment_mode;
	}
	
	
}

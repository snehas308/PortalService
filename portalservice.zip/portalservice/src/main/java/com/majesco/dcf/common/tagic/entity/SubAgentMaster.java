package com.majesco.dcf.common.tagic.entity;


import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_ch_int_subagent",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_ch_int_subagent")							// Added for Oracle Migration
public class SubAgentMaster implements Serializable{
	private Integer nsubagentseq;
	private String strintermediarycd ="";
	private String strsubagentcd ="";
	private String strsubagentname ="";
	private String dtstart ="";
	private Integer nmobileno;
	private String dtend ="";
	private Integer nisactive;
	private String dtcreated ="";
	private String strcreatedby ="";
	private String dtupdated ="";
	private String strupdatedby ="";
	
	@Id
	@Column(name = "nsubagentseq")
	public Integer getNsubagentseq() {
		return nsubagentseq;
	}
	public void setNsubagentseq(Integer nsubagentseq) {
		this.nsubagentseq = nsubagentseq;
	}
	
	@Column(name = "strintermediarycd")
	public String getStrintermediarycd() {
		return strintermediarycd;
	}
	public void setStrintermediarycd(String strintermediarycd) {
		this.strintermediarycd = strintermediarycd;
	}
	
	@Column(name = "strsubagentcd")
	public String getStrsubagentcd() {
		return strsubagentcd;
	}
	public void setStrsubagentcd(String strsubagentcd) {
		this.strsubagentcd = strsubagentcd;
	}
	
	@Column(name = "strsubagentname")
	public String getStrsubagentname() {
		return strsubagentname;
	}
	public void setStrsubagentname(String strsubagentname) {
		this.strsubagentname = strsubagentname;
	}
	
	@Column(name = "dtstart")
	public String getDtstart() {
		return dtstart;
	}
	public void setDtstart(String dtstart) {
		this.dtstart = dtstart;
	}
	
	@Column(name = "nmobileno")
	public Integer getNmobileno() {
		return nmobileno;
	}
	public void setNmobileno(Integer nmobileno) {
		this.nmobileno = nmobileno;
	}
	
	@Column(name = "dtend")
	public String getDtend() {
		return dtend;
	}
	public void setDtend(String dtend) {
		this.dtend = dtend;
	}
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
}

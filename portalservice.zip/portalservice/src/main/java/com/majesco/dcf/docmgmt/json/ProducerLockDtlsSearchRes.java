package com.majesco.dcf.docmgmt.json;

import java.util.Date;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.ResultObject;

/**
 * 
 * @author vishal662335
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ProducerLockDtlsSearchRes extends ResponseError {		
	private String producerCd;
	private String lob;
	private String noOfDays;
	private String docUploadType;
	private Date startDate;
	private Date endDate;
	private String isActive;
	public String getProducerCd() {
		return producerCd;
	}
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(String noOfDays) {
		this.noOfDays = noOfDays;
	}
	public String getDocUploadType() {
		return docUploadType;
	}
	public void setDocUploadType(String docUploadType) {
		this.docUploadType = docUploadType;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

		
}

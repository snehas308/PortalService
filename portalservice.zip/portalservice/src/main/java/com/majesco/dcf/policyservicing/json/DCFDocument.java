package com.majesco.dcf.policyservicing.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DCFDocument {

	private String docStream;
	private String name;
	private String mimetype;
	
	public String getDocStream() {
		return docStream;
	}
	public void setDocStream(String docStream) {
		this.docStream = docStream;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMimetype() {
		return mimetype;
	}
	public void setMimetype(String mimetype) {
		this.mimetype = mimetype;
	}
	
}

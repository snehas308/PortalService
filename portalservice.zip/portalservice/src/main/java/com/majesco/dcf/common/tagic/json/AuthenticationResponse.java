package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class AuthenticationResponse {
	
	private String resultRes;
	private String resultCode;
	private List<ResponseError> resErr;

	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	
	
	public String getResultRes() {
		return resultRes;
	}
	public void setResultRes(String resultRes) {
		this.resultRes = resultRes;
	}
	
	
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	
	
	

}

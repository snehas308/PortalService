package com.majesco.dcf.common.tagic.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.majesco.dcf.common.tagic.json.AuthenticationRequest;
import com.majesco.dcf.common.tagic.json.AuthenticationResponse;
import com.majesco.dcf.common.tagic.json.CreateCustomerRequest;
import com.majesco.dcf.common.tagic.json.CreateCustomerResponse;
import com.majesco.dcf.common.tagic.json.CustomerDetailRequest;
import com.majesco.dcf.common.tagic.json.CustomerDetailResponse;
import com.majesco.dcf.common.tagic.json.CustomerSearchLiteRequest;
import com.majesco.dcf.common.tagic.json.CustomerSearchLiteResponse;
import com.majesco.dcf.common.tagic.json.CustomerSearchRequest;
import com.majesco.dcf.common.tagic.json.CustomerSearchResponse;
import com.majesco.dcf.common.tagic.json.UpdateCustomerRequest;
import com.majesco.dcf.common.tagic.json.UpdateCustomerResponse;
import com.majesco.dcf.common.tagic.service.AuthenticationService;
import com.majesco.dcf.common.tagic.service.CustomerService;
import com.majesco.dcf.common.tagic.service.GenericTypeService;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.reports.json.ChequeBounceReportResponse;

@Controller
@RequestMapping(value="/customerservice")
public class CustomerServiceController {
	
	final static Logger logger=Logger.getLogger(CustomerServiceController.class);
	
	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	AuthenticationService authService;
	
	@Autowired
	GenericTypeService service;
	
	private Gson gson=new Gson();
	
	//String strClassName="CustomerServiceController";
	//private static String _strClassName="CustomerServiceController";	
	@RequestMapping(value="/searchlist/", method = RequestMethod.POST)
	@ResponseBody	
	public CustomerDetailResponse getCustomerListDetails(@RequestBody CustomerDetailRequest custReq,HttpServletRequest httpServletRequest) throws Exception
	{	
		String strMethod="getCustomerListDetails";
		logger.info("Inside "+service.getClass()+" :: "+strMethod+" method :: Execution Started");
		CustomerDetailResponse result=null;
		AuthenticationRequest authReq=new AuthenticationRequest();
		authReq.setSource(smc_source);
		authReq.setMedium(smc_medium);
		authReq.setCampain(smc_campaign);
		authReq.setUserID(custReq.getUserID());
		authReq.setPassword(custReq.getPassword());
		AuthenticationResponse authResponse=null;
		try{
			
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				custReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
				//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+custReq.getAuthToken());
				//End:Vishal<VAPT comments>| code added to set GC token into user object	
			}else{
				authResponse=authService.getAuthenticationToken(authReq);
				if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
				custReq.setAuthToken(authResponse.getResultRes());		
			}		
		//result = customerService.getCustomerListDetails(custReq);
		//Start:25/02/2017:Customer search changes from portal
		result=customerService.getCustomerListDetailsFromPortal(custReq);
		//End:25/02/2017:Customer search changes from portal
		logger.info("Inside "+service.getClass()+" :: "+strMethod+" method :: Execution Completed Successfully");
		
		}catch(Exception ex){
			logger.error("Inside CustomerServiceController :: getCustomerListDetails() method ::",ex);
			ex.printStackTrace();
			logger.error(service.getClass()+"::"+strMethod+"::", ex);
			result=new CustomerDetailResponse();
			result.setResultCode("0");
			if(authResponse!=null)
			result.setResErr(authResponse.getResErr());
			return result;
		}
		
	return result;
	}
	
	@RequestMapping(value="/searchCustomer/", method = RequestMethod.POST)
	@ResponseBody	
	public CustomerDetailResponse getCustomerDetails(@RequestBody CustomerDetailRequest custReq,HttpServletRequest httpServletRequest) throws Exception
	{	
		String strMethod="getCustomerDetails";
		logger.info("Inside "+service.getClass()+" :: "+strMethod+" method :: Execution Started");
		CustomerDetailResponse result=null;
		AuthenticationRequest authReq=new AuthenticationRequest();
		authReq.setSource(smc_source);
		authReq.setMedium(smc_medium);
		authReq.setCampain(smc_campaign);
		authReq.setUserID(custReq.getUserID());
		authReq.setPassword(custReq.getPassword());
		AuthenticationResponse authResponse=null;
		try{
			
			if(httpServletRequest.getHeader("gc_token")!=null && !httpServletRequest.getHeader("gc_token").equalsIgnoreCase(CommonConstants.BLANK_STRING)){
				//Start:Vishal<VAPT comments>| code added to set GC token into user object 
				custReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
				//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+custReq.getAuthToken());
				//End:Vishal<VAPT comments>| code added to set GC token into user object	
			}else{
				authResponse=authService.getAuthenticationToken(authReq);
				if(authResponse!=null && !authResponse.getResultRes().equalsIgnoreCase(""))
				custReq.setAuthToken(authResponse.getResultRes());		
			}
			
		
		result = customerService.getCustomerDetails(custReq);
		
		logger.info("Inside "+service.getClass()+" :: "+strMethod+" method :: Execution Completed Successfully");
		
		}catch(Exception ex){
			//logger.info("Inside CustomerServiceController :: getCustomerDetails() method ::",ex);
			logger.error(service.getClass()+"::"+strMethod+"::", ex);
			ex.printStackTrace();
			result=new CustomerDetailResponse();
			result.setResultCode("0");
			if(authResponse!=null)
			result.setResErr(authResponse.getResErr());
			return result;
		}
		
	return result;
	}
	
	
	@RequestMapping(value="/CreateCustomerSer/", method = RequestMethod.POST)
	@ResponseBody
	public CreateCustomerResponse createCustomer(@RequestBody CreateCustomerRequest CreateReq, HttpServletRequest httpServletRequest) throws Exception
	{			
		logger.info("Inside CreateCustomerController :: createCustomer method :: Execution Started");
		CreateCustomerResponse result = null;
		try{
			if(CreateReq!=null){
				CreateReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
			}
			//Start:RahulT<1213>| code added to set GC token into user object 
			CreateReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+CreateReq.getAuthToken());
			//End:RahulT<1213>| code added to set GC token into user object
			result = customerService.createCustomer(CreateReq);
			logger.info("Inside CreateCustomerController :: createCustomer method :: Execution Completed Successfully");
		}
		
		catch(Exception ex){
			ex.printStackTrace();
		}
		
					
		return result;
	}
	
	@RequestMapping(value="/SearchMinCustomerDet/", method = RequestMethod.POST)
	@ResponseBody
	public CustomerSearchLiteResponse getCustomerDetails(@RequestBody CustomerSearchLiteRequest CustReq,HttpServletRequest httpServletRequest) throws Exception
	{	
		logger.info("Inside CreateCustomerController :: getCustomerDetails method :: Execution Started");	 								
		
		CustomerSearchLiteResponse result = customerService.getCustomerDetails(CustReq);
		
		logger.info("Inside CreateCustomerController :: getCustomerDetails method :: Execution Completed Successfully");
					
		return result;
	}
	
	/*@RequestMapping(value="/UpdateCustomerDet/", method = RequestMethod.POST)
	@ResponseBody
	public UpdateCustomerResponse updateCustomer(@RequestBody UpdateCustomerRequest CustReq,HttpServletRequest httpServletRequest) throws Exception
	{	
		logger.info("Inside CreateCustomerController :: updateCustomer method :: Execution Started");
		
		UpdateCustomerResponse result = customerService.updateCustomer(CustReq);
		
		logger.info("Inside CreateCustomerController :: updateCustomer method :: Execution Completed Successfully");
		
	return result;
	}*/

	@RequestMapping(value="/searchCustomerService/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String>  searchCustomer(@RequestBody String requestJson,HttpServletRequest httpServletRequest) throws Exception{
		
		CustomerSearchResponse customerSearchResponse=null;
		CustomerSearchRequest customerSearchRequest=null;
		String result=null;				
		HttpHeaders responseHeaders =  new HttpHeaders();
		ResponseEntity responseEntity=null;
		String strMethodName="searchCustomer";
		try{
			customerSearchRequest=gson.fromJson(requestJson, CustomerSearchRequest.class);
			logger.info("Inside "+service.getClass()+"::"+strMethodName+"::Entered");
			//customerSearchResponse=customerService.searchCustomer(customerSearchRequest);
			//Start:25/02/2017:Added for customer search from portal
			customerSearchResponse=customerService.searchCustomerFromPortal(customerSearchRequest);
			//End:25/02/2017:Added for customer search from portal
			
			if(customerSearchResponse!=null && customerSearchResponse.getCustomerSearchDetailsList()!=null &&  customerSearchResponse.getCustomerSearchDetailsList().size()>0){
				result=gson.toJson(customerSearchResponse);
				responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.OK);
			}
			else{
				result="No Data Found";
				responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);	
			}
			
			logger.info("Inside "+service.getClass()+"::"+strMethodName+"::Exit");
		}catch(Exception ex){
			logger.error("Inside "+service.getClass()+"::"+strMethodName+"::Exception::", ex);
			customerSearchResponse=new CustomerSearchResponse(); 
			customerSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			result=gson.toJson(customerSearchResponse);
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
		return responseEntity;
	}
	
	// <1840> : Vishal : 19-Aug-2017 : Start
	
	@RequestMapping(value="/editCustomerSer/", method = RequestMethod.POST)
	@ResponseBody
	public CreateCustomerResponse editCustomer(@RequestBody CreateCustomerRequest CreateReq, HttpServletRequest httpServletRequest) throws Exception
	{			
		logger.info("Inside CustomerController :: editCustomer method :: Execution Started");
		CreateCustomerResponse result = null;
		try{
			if(CreateReq!=null){
				CreateReq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
			}
			//Start:RahulT<1213>| code added to set GC token into user object 
			CreateReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+CreateReq.getAuthToken());
			//End:RahulT<1213>| code added to set GC token into user object
			result = customerService.editCustomer(CreateReq);
			logger.info("Inside CustomerController :: editCustomer method :: Execution Completed Successfully");
		}
		
		catch(Exception ex){
			ex.printStackTrace();
		}
		
					
		return result;
	}
	// <1840> : Vishal : 19-Aug-2017 : End
	
	
	
	
	
}

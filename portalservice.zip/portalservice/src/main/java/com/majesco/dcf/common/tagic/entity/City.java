package com.majesco.dcf.common.tagic.entity;


import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_district_city_m",schema="dcf_master")			// Commented for Oracle Migration
@Table(name = "dcf_district_city_m")								// Added for Oracle Migration
public class City implements Serializable{
	
	private String strcitycd;
	private String strcityname;
	private String ndistrictcityflag;
	private String strstatecd;
	private Integer npincode;
	private String streqzone;
	private String strrsmdzone;
	private String strstfizone;
	private Integer nparentid;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	
	
	@Id
	@Column(name = "strcitycd")
	public String getStrcitycd() {
		return strcitycd;
	}
	public void setStrcitycd(String strcitycd) {
		this.strcitycd = strcitycd;
	}
	
	
	@Column(name = "strcityname")
	public String getStrcityname() {
		return strcityname;
	}
	public void setStrcityname(String strcityname) {
		this.strcityname = strcityname;
	}
	
	
	@Id
	@Column(name = "ndistrictcityflag")
	public String getNdistrictcityflag() {
		return ndistrictcityflag;
	}
	public void setNdistrictcityflag(String ndistrictcityflag) {
		this.ndistrictcityflag = ndistrictcityflag;
	}
	
	
	@Column(name = "strstatecd")
	public String getStrstatecd() {
		return strstatecd;
	}
	public void setStrstatecd(String strstatecd) {
		this.strstatecd = strstatecd;
	}
	
	
	@Column(name = "npincode")
	public Integer getNpincode() {
		return npincode;
	}
	public void setNpincode(Integer npincode) {
		this.npincode = npincode;
	}
	
	
	@Column(name = "streqzone")
	public String getStreqzone() {
		return streqzone;
	}
	public void setStreqzone(String streqzone) {
		this.streqzone = streqzone;
	}
	
	
	@Column(name = "strrsmdzone")
	public String getStrrsmdzone() {
		return strrsmdzone;
	}
	public void setStrrsmdzone(String strrsmdzone) {
		this.strrsmdzone = strrsmdzone;
	}
	
	
	@Column(name = "strstfizone")
	public String getStrstfizone() {
		return strstfizone;
	}
	public void setStrstfizone(String strstfizone) {
		this.strstfizone = strstfizone;
	}
	
	
	@Column(name = "nparentid")
	public Integer getNparentid() {
		return nparentid;
	}
	public void setNparentid(Integer nparentid) {
		this.nparentid = nparentid;
	}
	
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	
	
}

package com.majesco.dcf.claims.serviceImpl;

import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.claims.json.ClaimServiceValidateSaveRequest;
import com.majesco.dcf.claims.json.ClaimServiceValidateSaveResponse;
import com.majesco.dcf.claims.json.CoverageDetails;
import com.majesco.dcf.claims.json.CoverageSearchRequest;
import com.majesco.dcf.claims.json.CoverageSearchResponse;
import com.majesco.dcf.claims.json.PolicyDetailsSearchRequest;
import com.majesco.dcf.claims.json.PolicyDetailsSearchResponse;
import com.majesco.dcf.claims.json.PolicySearchCoverNoteRequest;
import com.majesco.dcf.claims.json.PolicySearchCoverNoteResponse;
import com.majesco.dcf.claims.service.ClaimService;
import com.majesco.dcf.common.chp.util.CdataWriterInterceptor;
import com.majesco.dcf.common.chp.util.JAXBXMLHandler;
import com.majesco.dcf.common.tagic.json.AuthenticationResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.service.AuthenticationService;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.motor.serviceImpl.MotorServiceImpl;
import com.unotechsoft.stub.claimsservice.motor.client.ArrayOfKeyValueOfstringstring;
import com.unotechsoft.stub.claimsservice.motor.client.ArrayOfKeyValueOfstringstring.KeyValueOfstringstring;
import com.unotechsoft.stub.claimsservice.motor.client.CUD_Registration;
import com.unotechsoft.stub.claimsservice.motor.client.ClaimServiceResult;
import com.unotechsoft.stub.claimsservice.motor.client.ClaimUserData;
import com.unotechsoft.stub.claimsservice.motor.client.DriverDetails;
import com.unotechsoft.stub.claimsservice.motor.client.GDtCoverageDetails;
import com.unotechsoft.stub.claimsservice.motor.client.MotorClaimsService;
import com.unotechsoft.stub.claimsservice.motor.client.MotorClaimsService_Service;

@Service
@Transactional
public class ClaimServiceImpl implements ClaimService{
	
final static Logger logger = Logger.getLogger(ClaimServiceImpl.class);

	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/
	
	@Autowired
	AuthenticationService authServ;
	
	@Autowired
	DBService dbserv;
	
	public String propValue="";
	
	
	public String getWSDLURL(String param)
	{
		String propVal="";
		try
		{
			propVal = dbserv.getWSDLURL(param,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			return propVal;
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorServiceImpl :: getWSDLURL() method ::",ae);
		}
		return propVal;
	}

	@Override
	public PolicySearchCoverNoteResponse getClaimServiceGetLOV(PolicySearchCoverNoteRequest cvrNoteClaimReq) throws Exception 
	{
		long transId = System.nanoTime();
		logger.info("TransactionID : "+transId+" :: Inside ClaimServiceImpl :: getClaimServiceGetLOV() method :: Execution Started");
		propValue = "";
		String jaxbXML = "";
		PolicySearchCoverNoteResponse cvrNoteClaimRes = new PolicySearchCoverNoteResponse();
		
		if(propValue.equalsIgnoreCase(""))
			propValue = this.getWSDLURL(CommonConstants.MOTOR_SERVICE_PRIVATECAR);
		
		try
		{
			URL url = new URL(propValue);
			
			MotorClaimsService_Service stub = new MotorClaimsService_Service(url);
			ClaimServiceResult p2Dto = new ClaimServiceResult();
			ClaimUserData claimUserData=new ClaimUserData();
			if(cvrNoteClaimReq!=null)
			{
				if(cvrNoteClaimReq.getCoverNoteNumber()!=null && !cvrNoteClaimReq.getCoverNoteNumber().equalsIgnoreCase(""))
				{
					claimUserData.setCovernoteNumber(cvrNoteClaimReq.getCoverNoteNumber());
				}
			}
			
			p2Dto.setClaimData(claimUserData);
			jaxbXML=JAXBXMLHandler.marshal(p2Dto);
			
			//Getting Authentication Token Starts Here
            String propFileName = "resource.properties";
            String userID="";
            String password="";
            String responseFrom = "";
            Properties prop = new Properties();
            InputStream inputStream = MotorServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
            prop.load(inputStream);
            userID=cvrNoteClaimReq.getUserID();
            password=cvrNoteClaimReq.getPassword();
            responseFrom=prop.getProperty("ResponseFrom");
            AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
            //Getting Authentication Token Stops Here
            
            MotorClaimsService port = stub.getSOAPOverHTTP();
            Client client=ClientProxy.getClient(port);
            PrintWriter writer = new PrintWriter(System.out);
            
            client.getOutInterceptors().add(new CdataWriterInterceptor());
            client.getInInterceptors().add(new LoggingInInterceptor(writer));
            client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
            
            logger.info("Requesting For Motor Claim getClaimServiceGetLOV()");
            ClaimServiceResult claimServiceResult = port.claimSearchGetLOV(smc_source, smc_medium, smc_campaign,authRes.getResultRes(),p2Dto);
            logger.info("Response Recieved For Motor Claim getClaimServiceGetLOV()");
			
            if(claimServiceResult!=null)
            {
            	if(claimServiceResult.getClaimData()!=null)
            	{
            		if(claimServiceResult.getClaimData().getPolicyNumber()!=null)
            		{
		            	cvrNoteClaimRes.setResultCode("1");
						List<ResponseError> errorList=new ArrayList<ResponseError>();
						ResponseError errorRes=new ResponseError();
						errorRes.setErrorCode("ERR");
						errorRes.setErrorMMessag("NOERR");
						errorList.add(errorRes);
						cvrNoteClaimRes.setResErr(errorList);
						cvrNoteClaimRes.setPolicyNumber(claimServiceResult.getClaimData().getPolicyNumber());
						
						return cvrNoteClaimRes;
            		}
            	}
            }
			
		}
		catch(Exception ex)
		{
			logger.info("Inside ClaimServiceImpl :: getClaimServiceGetLOV() method ::",ex);
			cvrNoteClaimRes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR");
			errorRes.setErrorMMessag("Exception Occurred..."+" :: TransactionID : "+transId);
			errorList.add(errorRes);
			cvrNoteClaimRes.setResErr(errorList);
		}
		
		logger.info("TransactionID : "+transId+" :: Inside ClaimServiceImpl :: getClaimServiceGetLOV() method :: Execution Completed");
		return cvrNoteClaimRes;
	}

	@SuppressWarnings("unused")
	@Override
	public PolicyDetailsSearchResponse getClaimServiceFetchGeneralDetails(PolicyDetailsSearchRequest polDetSearchReq) throws Exception 
	{
		long transId = System.nanoTime();
		logger.info("TransactionID : "+transId+" :: Inside ClaimServiceImpl :: getClaimServiceFetchGeneralDetails() method :: Execution Started");
		propValue = "";
		PolicyDetailsSearchResponse polDetSearchRes = new PolicyDetailsSearchResponse();
		
		String tempNumber = null;
		String polNum = null;
		if(propValue.equalsIgnoreCase(""))
			propValue = this.getWSDLURL(CommonConstants.MOTOR_SERVICE_PRIVATECAR);
		
		try
		{
			if(polDetSearchReq!=null)
			{
				if(polDetSearchReq.getPolicyNumber()!=null && !polDetSearchReq.getPolicyNumber().equalsIgnoreCase(""))
				{
					
					tempNumber = polDetSearchReq.getPolicyNumber().substring(0, 1);
					
					if(tempNumber!=null && tempNumber.equalsIgnoreCase("G"))
					{
						PolicySearchCoverNoteRequest cvrNoteClaimReq = new PolicySearchCoverNoteRequest();
						
						cvrNoteClaimReq.setCoverNoteNumber(polDetSearchReq.getPolicyNumber());
						
						logger.info("Requesting For Motor Claim getClaimServiceGetLOV()");
						PolicySearchCoverNoteResponse cvrNoteClaimRes = this.getClaimServiceGetLOV(cvrNoteClaimReq);
						logger.info("Response Recieved For Motor Claim getClaimServiceGetLOV()");
						
						if(cvrNoteClaimRes!=null)
						{
							if(cvrNoteClaimRes.getPolicyNumber()!=null)
							{
								polDetSearchReq.setPolicyNumber(cvrNoteClaimRes.getPolicyNumber());
							}
							else
							{
								polDetSearchRes.setResultCode("0");
								List<ResponseError> errorList=new ArrayList<ResponseError>();
								ResponseError errorRes=new ResponseError();
								errorRes.setErrorCode("ERR");
								errorRes.setErrorMMessag("Policy Number Not Found From CoverNote Service....!!"+cvrNoteClaimReq.getCoverNoteNumber()+" :: TransactionID : "+transId);
								errorList.add(errorRes);
								polDetSearchRes.setResErr(errorList);
								
								return polDetSearchRes;
							}
						}
						else
						{
							polDetSearchRes.setResultCode("0");
							List<ResponseError> errorList=new ArrayList<ResponseError>();
							ResponseError errorRes=new ResponseError();
							errorRes.setErrorCode("ERR");
							errorRes.setErrorMMessag("Policy Number Not Found From CoverNote Service....!!"+cvrNoteClaimReq.getCoverNoteNumber()+" :: TransactionID : "+transId);
							errorList.add(errorRes);
							polDetSearchRes.setResErr(errorList);
							
							return polDetSearchRes;
						}
					}
				}
			}
			else
			{
				polDetSearchRes.setResultCode("0");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError errorRes=new ResponseError();
				errorRes.setErrorCode("ERR");
				errorRes.setErrorMMessag("Issue With Request Recieved....!!"+" :: TransactionID : "+transId);
				errorList.add(errorRes);
				polDetSearchRes.setResErr(errorList);
				
				return polDetSearchRes;
			}
			
			URL url = new URL(propValue);
			MotorClaimsService_Service stub = new MotorClaimsService_Service(url);	
			ClaimServiceResult p2Dto = new ClaimServiceResult();
			ClaimUserData claimUserData = new ClaimUserData();
			
			if(polDetSearchReq!=null)
			{
				if(polDetSearchReq.getPolicyNumber()!=null && polDetSearchReq.getDateOfLoss()!=null)
				{
					claimUserData.setPolicyNumber(polDetSearchReq.getPolicyNumber());
					claimUserData.setLossDate(polDetSearchReq.getDateOfLoss());
					
					p2Dto.setClaimData(claimUserData);
					
					//Getting Authentication Token Starts Here
		            String propFileName = "resource.properties";
		            String userID="";
		            String password="";
		            String responseFrom = "";
		            Properties prop = new Properties();
		            InputStream inputStream = MotorServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
		            prop.load(inputStream);
		            userID=polDetSearchReq.getUserID();
		            password=polDetSearchReq.getPassword();
		            responseFrom=prop.getProperty("ResponseFrom");
		            AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
		            //Getting Authentication Token Stops Here
		            
		            MotorClaimsService port = stub.getSOAPOverHTTP();
		            Client client=ClientProxy.getClient(port);
		            PrintWriter writer = new PrintWriter(System.out);
		            
		            client.getOutInterceptors().add(new CdataWriterInterceptor());
		            client.getInInterceptors().add(new LoggingInInterceptor(writer));
		            client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
		            
		            /*...........................................Calling Cover Details Service Starts Here..........................................*/
		            CoverageSearchRequest coverSearchReq = new CoverageSearchRequest();
		            coverSearchReq.setPolicyNumber(polDetSearchReq.getPolicyNumber());
		            coverSearchReq.setDateOfLoss(polDetSearchReq.getDateOfLoss());
		            
		            CoverageSearchResponse coverSearchRes = this.getClaimServiceGetLOV(coverSearchReq);
		            if(coverSearchRes!=null)
		            {
		            	if(coverSearchRes.getLstCoverDtld()!=null)
		            	{
		            		polDetSearchRes.setLstCoverDtld(coverSearchRes.getLstCoverDtld());
		            	}
		            }
		            /*...........................................Calling Cover Details Service Ends Here..........................................*/
		            
		            
		            logger.info("Requesting For Motor Claim claimSearchGetGeneralDetails()");
		            ClaimServiceResult claimServiceResult = port.claimSearchGetGeneralDetails("","","",authRes.getResultRes(),p2Dto);
		            logger.info("Response Recieved For Motor Claim claimSearchGetGeneralDetails()");
		            
		            if(claimServiceResult!=null)
		            {
		            	if(claimServiceResult.getClaimData()!=null)
		            	{
			            	if(claimServiceResult.getClaimData().getProdcode()!=null)
			            		polDetSearchRes.setProductCode(claimServiceResult.getClaimData().getProdcode());
			            	if(claimServiceResult.getClaimData().getProdName()!=null)
			            		polDetSearchRes.setProductName(claimServiceResult.getClaimData().getProdName());
			            	if(claimServiceResult.getClaimData().getInsuredName()!=null)
			            		polDetSearchRes.setInsuredName(claimServiceResult.getClaimData().getInsuredName());
			            	if(claimServiceResult.getClaimData().getInsuredDetails()!=null)
			            	{
			            		if(claimServiceResult.getClaimData().getInsuredDetails().getInsuredEmailID()!=null)
			            			polDetSearchRes.setCustEmailID(claimServiceResult.getClaimData().getInsuredDetails().getInsuredEmailID());
			            	}
			            	else
			            	{
			            		polDetSearchRes.setResultCode("0");
								List<ResponseError> errorList=new ArrayList<ResponseError>();
								ResponseError errorRes=new ResponseError();
								errorRes.setErrorCode("ERR");
								errorRes.setErrorMMessag("Issue With Response Recieved....!!"+" :: TransactionID : "+transId);
								errorList.add(errorRes);
								polDetSearchRes.setResErr(errorList);
								
								return polDetSearchRes;
			            	}
			            	if(claimServiceResult.getClaimData().getProducercd()!=null)
			            		polDetSearchRes.setProducerCode(claimServiceResult.getClaimData().getProducercd());
			            	
			            	
			            	
			            	logger.info("TransactionID : "+transId+" :: Returning Successfull Response For ClaimServiceFetchGeneralDetails()");
			            	polDetSearchRes.setResultCode("1");
							List<ResponseError> errorList=new ArrayList<ResponseError>();
							ResponseError errorRes=new ResponseError();
							errorRes.setErrorCode("ERR");
							errorRes.setErrorMMessag("NOERR");
							errorList.add(errorRes);
							polDetSearchRes.setResErr(errorList);
			            	return polDetSearchRes;
		            	}
		            	else
		            	{
		            		polDetSearchRes.setResultCode("0");
							List<ResponseError> errorList=new ArrayList<ResponseError>();
							ResponseError errorRes=new ResponseError();
							errorRes.setErrorCode("ERR");
							errorRes.setErrorMMessag("Issue With Response Recieved....!!"+" :: TransactionID : "+transId);
							errorList.add(errorRes);
							polDetSearchRes.setResErr(errorList);
							
							return polDetSearchRes;
		            	}
		            }
		            else
		            {
		            	polDetSearchRes.setResultCode("0");
						List<ResponseError> errorList=new ArrayList<ResponseError>();
						ResponseError errorRes=new ResponseError();
						errorRes.setErrorCode("ERR");
						errorRes.setErrorMMessag("Issue With Response Recieved....!!"+" :: TransactionID : "+transId);
						errorList.add(errorRes);
						polDetSearchRes.setResErr(errorList);
						
						return polDetSearchRes;
		            }
					
				}
				else
				{
					polDetSearchRes.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError errorRes=new ResponseError();
					errorRes.setErrorCode("ERR");
					errorRes.setErrorMMessag("Issue With Request Recieved....!!"+" :: TransactionID : "+transId);
					errorList.add(errorRes);
					polDetSearchRes.setResErr(errorList);
					
					return polDetSearchRes;
				}
			}
			else
			{
				polDetSearchRes.setResultCode("0");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError errorRes=new ResponseError();
				errorRes.setErrorCode("ERR");
				errorRes.setErrorMMessag("Issue With Request Recieved....!!"+" :: TransactionID : "+transId);
				errorList.add(errorRes);
				polDetSearchRes.setResErr(errorList);
				
				return polDetSearchRes;
			}
			
			
			
		}
		catch(Exception ex)
		{
			polDetSearchRes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR");
			errorRes.setErrorMMessag("TransactionID : "+transId+" :: Inside ClaimServiceImpl :: getClaimServiceFetchGeneralDetails() method :: Exception Occurred...."+" :: TransactionID : "+transId);
			errorList.add(errorRes);
			polDetSearchRes.setResErr(errorList);
		}
		
		
		
		
		logger.info("TransactionID : "+transId+" :: Inside ClaimServiceImpl :: getClaimServiceFetchGeneralDetails() method :: Execution Completed");
		return polDetSearchRes;
	}

	@Override
	public CoverageSearchResponse getClaimServiceGetLOV(CoverageSearchRequest cvrgSearchReq) throws Exception 
	{
		long transId = System.nanoTime();
		logger.info("TransactionID : "+transId+" :: Inside ClaimServiceImpl :: getClaimServiceGetLOV() method :: Execution Started");
		propValue = "";
		CoverageSearchResponse cvrgSearchRes = new CoverageSearchResponse();
		
		if(propValue.equalsIgnoreCase(""))
			propValue = this.getWSDLURL(CommonConstants.MOTOR_SERVICE_PRIVATECAR);
		
		try
		{
			URL url = new URL(propValue);
			MotorClaimsService_Service stub = new MotorClaimsService_Service(url);	
			ClaimServiceResult p2Dto = new ClaimServiceResult();
			ClaimUserData claimUserData = new ClaimUserData();
			
			if(cvrgSearchReq!=null)
			{
				if(cvrgSearchReq.getPolicyNumber()!=null && cvrgSearchReq.getDateOfLoss()!=null && !cvrgSearchReq.getPolicyNumber().equalsIgnoreCase("") && !cvrgSearchReq.getDateOfLoss().equalsIgnoreCase(""))
				{
					
					claimUserData.setPolicyNumber(cvrgSearchReq.getPolicyNumber());
					claimUserData.setLossDate(cvrgSearchReq.getDateOfLoss());
					p2Dto.setClaimData(claimUserData);
					
					//Getting Authentication Token Starts Here
		            String propFileName = "resource.properties";
		            String userID="";
		            String password="";
		            String responseFrom = "";
		            Properties prop = new Properties();
		            InputStream inputStream = MotorServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
		            prop.load(inputStream);
		            userID=cvrgSearchReq.getUserID();
		            password=cvrgSearchReq.getPassword();
		            responseFrom=prop.getProperty("ResponseFrom");
		            AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
		            //Getting Authentication Token Stops Here
		            
		            MotorClaimsService port = stub.getSOAPOverHTTP();
		            Client client=ClientProxy.getClient(port);
		            PrintWriter writer = new PrintWriter(System.out);
		            
		            client.getOutInterceptors().add(new CdataWriterInterceptor());
		            client.getInInterceptors().add(new LoggingInInterceptor(writer));
		            client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
		            
		            logger.info("Requesting For Motor Claim getClaimServiceGetLOV()");
		            ClaimServiceResult claimServiceResult = port.claimSearchGetLOV(smc_source, smc_medium, smc_campaign,authRes.getResultRes(),p2Dto);
		            logger.info("Response Recieved For Motor Claim getClaimServiceGetLOV()");
		            
		            if(claimServiceResult!=null)
		            {
		            	if(claimServiceResult.getClaimData()!=null)
		            	{
		            		if(claimServiceResult.getClaimData().getGDtCoverageDetailsList()!=null)
		            		{
		            			if(claimServiceResult.getClaimData().getGDtCoverageDetailsList().getGDtCoverageDetails()!=null)
		            			{
		            				List<GDtCoverageDetails> cvrList = claimServiceResult.getClaimData().getGDtCoverageDetailsList().getGDtCoverageDetails();

	            					List<CoverageDetails> lstCoverDtls = new ArrayList<CoverageDetails>();
	            					
		            				for(int i=0;i<cvrList.size();i++)
		            				{
		            					List<GDtCoverageDetails> coverList = (List<GDtCoverageDetails>) claimServiceResult.getClaimData().getGDtCoverageDetailsList().getGDtCoverageDetails().get(i);
		            					CoverageDetails coverDtls = new CoverageDetails();
		            					
		            					if(coverList.get(i).getCoverGroup()!=null)
		            						coverDtls.setCoverageCode(coverList.get(i).getCoverGroup());
		            					else
		            						coverDtls.setCoverageCode("");
		            					
		            					if(coverList.get(i).getCoverDesc()!=null)
		            						coverDtls.setCoverageName(coverList.get(i).getCoverDesc());
		            					else
		            						coverDtls.setCoverageName("");
		            					
		            					if(coverList.get(i).getRowIndex()!=null)
		            						coverDtls.setCoverGroupIndex(""+coverList.get(i).getRowIndex());
		            					else
		            						coverDtls.setCoverGroupIndex("");
		            					
		            					
		            					lstCoverDtls.add(coverDtls);
		            				}
            						
            						cvrgSearchRes.setResultCode("1");
									List<ResponseError> errorList=new ArrayList<ResponseError>();
									ResponseError errorRes=new ResponseError();
									errorRes.setErrorCode("ERR");
									errorRes.setErrorMMessag("NOERR");
									errorList.add(errorRes);
									cvrgSearchRes.setResErr(errorList);
									
									cvrgSearchRes.setLstCoverDtld(lstCoverDtls);
									return cvrgSearchRes;
		            			}
		            		}
		            	}
		            }
				}
			}
		}
		catch(Exception e)
		{
			cvrgSearchRes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR");
			errorRes.setErrorMMessag("TransactionID : "+transId+" :: Inside ClaimServiceImpl :: getClaimServiceGetLOV() : Exception Occurred...."+" :: TransactionID : "+transId);
			errorList.add(errorRes);
			cvrgSearchRes.setResErr(errorList);
		}
		
		logger.info("TransactionID : "+transId+" :: Inside ClaimServiceImpl :: getClaimServiceGetLOV() method :: Execution Completed");
		return cvrgSearchRes;
	}

	@Override
	public ClaimServiceValidateSaveResponse getClaimServiceValidateSave(
			ClaimServiceValidateSaveRequest claimServValidateSaveReq)
			throws Exception {
		
		long transId = System.nanoTime();
		logger.info("TransactionID : "+transId+" :: Inside ClaimServiceImpl :: getClaimServiceValidateSave() method :: Execution Started");
		propValue = "";
		ClaimServiceValidateSaveResponse claimServValidateSaveRes = new ClaimServiceValidateSaveResponse();
		String strSessionID = "";
		String strTransactionID = "";
		String strTransactionDateTime = "";
		String currentDate="";
		String currentTime="";
		
		/*Current date & time Logic*/
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		strTransactionDateTime = dateFormat.format(date);
		/*Current date & time Logic*/
		
		if(propValue.equalsIgnoreCase(""))
			propValue = this.getWSDLURL(CommonConstants.MOTOR_CLAIM_SERVICE);
		
		try
		{
			URL url = new URL(propValue);
			MotorClaimsService_Service stub = new MotorClaimsService_Service(url);
			CUD_Registration p2Dto = new CUD_Registration();
			
			ArrayOfKeyValueOfstringstring dicLVWFParams = new ArrayOfKeyValueOfstringstring();
			
			KeyValueOfstringstring keyValuePair1 = new KeyValueOfstringstring();
			keyValuePair1.setKey("LINK_ID");
			keyValuePair1.setValue("0");
			
			KeyValueOfstringstring keyValuePair2 = new KeyValueOfstringstring();
			keyValuePair2.setKey("DMS_KEY");
			keyValuePair2.setValue("Y");
			
			KeyValueOfstringstring keyValuePair3 = new KeyValueOfstringstring();
			keyValuePair3.setKey("WORKFLOW_NAME");
			keyValuePair3.setValue("MotorProcessFlowODClaim");
			
			
			dicLVWFParams.getKeyValueOfstringstring().add(keyValuePair1);
			dicLVWFParams.getKeyValueOfstringstring().add(keyValuePair2);
			dicLVWFParams.getKeyValueOfstringstring().add(keyValuePair3);
			
			
			if(claimServValidateSaveReq!=null)
			{
					
				
					//Getting Authentication Token Starts Here
		            String propFileName = "resource.properties";
		            String userID="";
		            String password="";
		            String responseFrom = "";
		            Properties prop = new Properties();
		            InputStream inputStream = MotorServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
		            prop.load(inputStream);
		            userID=claimServValidateSaveReq.getUserID();
		            password=claimServValidateSaveReq.getPassword();
		            responseFrom=prop.getProperty("ResponseFrom");
		            AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
		            //Getting Authentication Token Stops Here
		            
		            p2Dto.setPolicyNumber(claimServValidateSaveReq.getPolicyNoCoverNoteNo()==null?"":claimServValidateSaveReq.getPolicyNoCoverNoteNo());
		            p2Dto.setLossDate(claimServValidateSaveReq.getLossDate()==null?"":claimServValidateSaveReq.getLossDate());
		            p2Dto.setDamage(claimServValidateSaveReq.getGeneralDescOfDamage()==null?"":claimServValidateSaveReq.getGeneralDescOfDamage());
		            p2Dto.setCLMInsuredName(claimServValidateSaveReq.getInsuredName()==null?"":claimServValidateSaveReq.getInsuredName());
		            p2Dto.setLOBCode(claimServValidateSaveReq.getLobCode()==null?"":claimServValidateSaveReq.getLobCode());
		            p2Dto.setLOBName(claimServValidateSaveReq.getLobName()==null?"":claimServValidateSaveReq.getLobName());
		            p2Dto.setProductCode(claimServValidateSaveReq.getProdCode()==null?"":claimServValidateSaveReq.getProdCode());
		            p2Dto.setProductName(claimServValidateSaveReq.getProdName()==null?"":claimServValidateSaveReq.getProdName());
		            p2Dto.setLossLocationPINCode(claimServValidateSaveReq.getLossLocationPincode()==null?"":claimServValidateSaveReq.getLossLocationPincode());
		            
		            DriverDetails driverDet = new DriverDetails();
		            driverDet.setDriver_Name(claimServValidateSaveReq.getDriverName()==null?"":claimServValidateSaveReq.getDriverName());
		            driverDet.setDriver_LicenseNo(claimServValidateSaveReq.getDriverLicenceNumber()==null?"":claimServValidateSaveReq.getDriverLicenceNumber());
		            p2Dto.setDriverDetails(driverDet);
		            
		            p2Dto.setLossDescriptionCode("999");
		            p2Dto.setLossDescriptionName("Other...");
		            p2Dto.setOtherLossDesc(claimServValidateSaveReq.getOtherLossDesc()==null?"":claimServValidateSaveReq.getOtherLossDesc());
		            
		            p2Dto.setServicingOfficeCode("0900"); //Setting Temporarily Hardcoded.... Need To Fetch It From DB
		            p2Dto.setServicingOfficeName("CORP OFFICE"); //Setting Temporarily Hardcoded.... Need To Fetch It From DB
		            p2Dto.setLocationLandmark(claimServValidateSaveReq.getLocationLandmark()==null?"":claimServValidateSaveReq.getLocationLandmark());
		            
		            DateFormat dateFormat1 = new SimpleDateFormat("dd/MM/yyyy");
		    		Date date1 = new Date();
		    		currentDate = dateFormat1.format(date1);
		            
		            p2Dto.setIntimationDate(currentDate==null?"":currentDate);
		            
		            DateFormat dateFormat2 = new SimpleDateFormat("HH:mm");
		    		Date date2 = new Date();
		    		currentTime = dateFormat2.format(date2);
		    		
		            p2Dto.setIntimationTime(currentTime==null?"":currentTime);
		            
		            p2Dto.setNOLCode(claimServValidateSaveReq.getNolCode()==null?"":claimServValidateSaveReq.getNolCode());
		            p2Dto.setNOLName(claimServValidateSaveReq.getNolName()==null?"":claimServValidateSaveReq.getNolName());
		            
		            p2Dto.setCauseOfLossCode("0380");
		            p2Dto.setAnatCode("380");
		            p2Dto.setInjuryCode("380");
		            p2Dto.setLossTime(claimServValidateSaveReq.getLossTime()==null?"":claimServValidateSaveReq.getLossTime());
		            
		            p2Dto.setExaminerCode("ServiceID-90900"); //Setting Temporarily Hardcoded.... Need To Reference It From DB
		            p2Dto.setExaminerName("Service ID for CORP OFFICE"); //Setting Temporarily Hardcoded.... Need To Reference It From DB
		            
		            MotorClaimsService port = stub.getSOAPOverHTTP();
		            Client client=ClientProxy.getClient(port);
		            PrintWriter writer = new PrintWriter(System.out);
		            
		            client.getOutInterceptors().add(new CdataWriterInterceptor());
		            client.getInInterceptors().add(new LoggingInInterceptor(writer));
		            client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
		            
		            logger.info("Requesting For Motor Claim getClaimServiceValidateSave()");
		            CUD_Registration claimServiceResult = port.claimServiceValidateSave(smc_source, smc_medium, smc_campaign, authRes.getResultRes(), p2Dto, userID, authRes.getResultRes(), strSessionID, strTransactionID, strTransactionDateTime, dicLVWFParams);
		            logger.info("Response Recieved For Motor Claim getClaimServiceValidateSave()");
		            
		            if(claimServiceResult!=null)
		            {
		            	claimServValidateSaveRes.setResultCode("1");
		            	List<ResponseError> errorList=new ArrayList<ResponseError>();
		    			ResponseError errorRes=new ResponseError();
		    			errorRes.setErrorCode("ERR");
		    			errorRes.setErrorMMessag("NOERR");
		    			errorList.add(errorRes);
		    			claimServValidateSaveRes.setResErr(errorList);
		    			
		            	claimServValidateSaveRes.setClaimNumber(claimServiceResult.getClaim_Number()==null?"":claimServiceResult.getClaim_Number());
		            	claimServValidateSaveRes.setLstclaimServValidateSaveReq(claimServValidateSaveReq);
		            }
		            else
		            {
		            	claimServValidateSaveRes.setResultCode("0");
		    			List<ResponseError> errorList=new ArrayList<ResponseError>();
		    			ResponseError errorRes=new ResponseError();
		    			errorRes.setErrorCode("ERR");
		    			errorRes.setErrorMMessag("TransactionID : "+transId+"Not Able To Fetch Data....!!"+" :: TransactionID : "+transId);
		    			errorList.add(errorRes);
		    			claimServValidateSaveRes.setResErr(errorList);
		            }
		            
		            
			}
		}
		catch(Exception e)
		{
			claimServValidateSaveRes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERR");
			errorRes.setErrorMMessag("TransactionID : "+transId+" :: Inside ClaimServiceImpl :: getClaimServiceValidateSave() : Exception Occurred...."+" :: TransactionID : "+transId);
			errorList.add(errorRes);
			claimServValidateSaveRes.setResErr(errorList);
		}
		
		logger.info("TransactionID : "+transId+" :: Inside ClaimServiceImpl :: getClaimServiceValidateSave() method :: Execution Completed");
		return claimServValidateSaveRes;
		
		
		
		
		
	}

}

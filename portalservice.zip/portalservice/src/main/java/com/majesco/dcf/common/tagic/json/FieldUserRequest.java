package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class FieldUserRequest {
	
	private String nofficecd;
	private String strintermediarycd;
	public String getNofficecd() {
		return nofficecd;
	}
	public void setNofficecd(String nofficecd) {
		this.nofficecd = nofficecd;
	}
	public String getStrintermediarycd() {
		return strintermediarycd;
	}
	public void setStrintermediarycd(String strintermediarycd) {
		this.strintermediarycd = strintermediarycd;
	}

}

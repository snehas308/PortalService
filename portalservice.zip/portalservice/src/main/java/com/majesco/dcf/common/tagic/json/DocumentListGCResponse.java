package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocumentListGCResponse {

	private String documentName;
	private String documentcode;
	private String documentSeries;
	private String isDocumentRequired;
	private String isDocumentWaived;
	private String isDocumentReceived;
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentcode() {
		return documentcode;
	}
	public void setDocumentcode(String documentcode) {
		this.documentcode = documentcode;
	}
	public String getDocumentSeries() {
		return documentSeries;
	}
	public void setDocumentSeries(String documentSeries) {
		this.documentSeries = documentSeries;
	}
	public String getIsDocumentRequired() {
		return isDocumentRequired;
	}
	public void setIsDocumentRequired(String isDocumentRequired) {
		this.isDocumentRequired = isDocumentRequired;
	}
	public String getIsDocumentWaived() {
		return isDocumentWaived;
	}
	public void setIsDocumentWaived(String isDocumentWaived) {
		this.isDocumentWaived = isDocumentWaived;
	}
	public String getIsDocumentReceived() {
		return isDocumentReceived;
	}
	public void setIsDocumentReceived(String isDocumentReceived) {
		this.isDocumentReceived = isDocumentReceived;
	}
		
}

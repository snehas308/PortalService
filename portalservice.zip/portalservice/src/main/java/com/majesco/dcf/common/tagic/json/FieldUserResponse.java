package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class FieldUserResponse {
	
	private List<BigDecimal> nfieldusercd;
	private List<String> struserid;
	private List<String> strfieldusername;
		
	public List<BigDecimal> getNfieldusercd() {
		return nfieldusercd;
	}
	public void setNfieldusercd(List<BigDecimal> nfieldusercd) {
		this.nfieldusercd = nfieldusercd;
	}
	public List<String> getStruserid() {
		return struserid;
	}
	public void setStruserid(List<String> struserid) {
		this.struserid = struserid;
	}
	public List<String> getStrfieldusername() {
		return strfieldusername;
	}
	public void setStrfieldusername(List<String> strfieldusername) {
		this.strfieldusername = strfieldusername;
	}
	private List<ResponseError> resErr;	
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	

}

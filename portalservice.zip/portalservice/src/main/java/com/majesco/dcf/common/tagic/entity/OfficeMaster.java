package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_ch_office_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_ch_office_m")							// Added for Oracle Migration
public class OfficeMaster implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private BigDecimal nofficecd;
	private BigDecimal nparentofficecd;
	private BigDecimal ntransctionid;
	private BigDecimal nisactive;	
	private String strofficedesc;
	private String strofficecd;
	private String strparentofficecd;
	private String strofficetype;
	private String dtstart;
	private String dtend;
	private String strcontactperson;
	private String stremailid;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	private String office;
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Id
	@Column(name = "nofficecd")
	public BigDecimal getNofficecd() {
		return nofficecd;
	}

	public void setNofficecd(BigDecimal nofficecd) {
		this.nofficecd = nofficecd;
	}
	
	@Column(name = "nparentofficecd")
	public BigDecimal getNparentofficecd() {
		return nparentofficecd;
	}
	
	public void setNparentofficecd(BigDecimal nparentofficecd) {
		this.nparentofficecd = nparentofficecd;
	}
	
	@Column(name = "ntransctionid")
	public BigDecimal getNtransctionid() {
		return ntransctionid;
	}

	public void setNtransctionid(BigDecimal ntransctionid) {
		this.ntransctionid = ntransctionid;
	}
	
	@Column(name = "nisactive")
	public BigDecimal getNisactive() {
		return nisactive;
	}

	public void setNisactive(BigDecimal nisactive) {
		this.nisactive = nisactive;
	}
	
	@Column(name = "strofficedesc")
	public String getStrofficedesc() {
		return strofficedesc;
	}

	public void setStrofficedesc(String strofficedesc) {
		this.strofficedesc = strofficedesc;
	}
	
	@Column(name = "strofficecd")
	public String getStrofficecd() {
		return strofficecd;
	}

	public void setStrofficecd(String strofficecd) {
		this.strofficecd = strofficecd;
	}
	
	@Column(name = "strparentofficecd")
	public String getStrparentofficecd() {
		return strparentofficecd;
	}

	public void setStrparentofficecd(String strparentofficecd) {
		this.strparentofficecd = strparentofficecd;
	}
	
	@Column(name = "strofficetype")
	public String getStrofficetype() {
		return strofficetype;
	}

	public void setStrofficetype(String strofficetype) {
		this.strofficetype = strofficetype;
	}

	@Column(name = "dtstart")
	public String getDtstart() {
		return dtstart;
	}

	public void setDtstart(String dtstart) {
		this.dtstart = dtstart;
	}

	@Column(name = "dtend")
	public String getDtend() {
		return dtend;
	}

	public void setDtend(String dtend) {
		this.dtend = dtend;
	}

	@Column(name = "strcontactperson")
	public String getStrcontactperson() {
		return strcontactperson;
	}

	public void setStrcontactperson(String strcontactperson) {
		this.strcontactperson = strcontactperson;
	}

	@Column(name = "stremailid")
	public String getStremailid() {
		return stremailid;
	}

	public void setStremailid(String stremailid) {
		this.stremailid = stremailid;
	}

	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}

	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}

	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}

	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}

	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}

	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}

	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}

	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}

	@Column(name = "office")
	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}
}

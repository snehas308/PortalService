package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.codec.binary.Base64;

@Entity
@Table(name = "dcf_message_outgoing_m")
public class OutBoundMaster implements Serializable {
	@Id
	@Column(name = "seqid")
	private String seqid;
	
	@Column(name = "createby")
	private String createby;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "dtcreated" )
	private Date dtcreated;
			
	@Column(name = "strjsonobj")
	private String strjsonobj;
	
	@Column(name = "strlobservice")
	private String strlobservice;
		
	@Column(name = "strlobtype")
	private String strlobtype;
	
	@Column(name = "strsoapenvelope")	
	private String strsoapenvelope;
	
	@Column(name = "strproducercode")
	private String strproducercode;
	
	@Column(name = "stripaddress")
	private String stripaddress;
	
	@Column(name = "strproductcode")
	private String strproductcode;
	
	@Column(name = "strtransactionevent")
	private String strtransactionevent;

	@Column(name = "strrefno")
	private String strrefno;
	
	
	
	public String getStrrefno() {
		return strrefno;
	}

	public void setStrrefno(String strrefno) {
		this.strrefno = strrefno;
	}

	public String getStrproducercode() {
		return strproducercode;
	}

	public void setStrproducercode(String strproducercode) {
		this.strproducercode = strproducercode;
	}

	public String getStripaddress() {
		return stripaddress;
	}

	public void setStripaddress(String stripaddress) {
		this.stripaddress = stripaddress;
	}

	public String getStrproductcode() {
		return strproductcode;
	}

	public void setStrproductcode(String strproductcode) {
		this.strproductcode = strproductcode;
	}

	public String getStrtransactionevent() {
		return strtransactionevent;
	}

	public void setStrtransactionevent(String strtransactionevent) {
		this.strtransactionevent = strtransactionevent;
	}

	public String getSeqid() {
		return seqid;
	}

	public void setSeqid(String seqid) {
		this.seqid = seqid;
	}

	
	public String getCreateby() {
		return createby;
	}

	public void setCreateby(String createby) {
		this.createby = createby;
	}
	
	public Date getDtcreated() {
		return dtcreated;
	}

	public void setDtcreated(Date dtcreated) {
		this.dtcreated = dtcreated;
	}

	
	public String getStrjsonobj() {
		return strjsonobj;
	}

	

	public void setStrjsonobj(String strjsonobj) {
		if(strjsonobj != null)
			this.strjsonobj = new String(Base64.encodeBase64(strjsonobj.getBytes()));
		else
			this.strjsonobj = strjsonobj;
	}

	
	public String getStrlobservice() {
		return strlobservice;
	}

	public void setStrlobservice(String strlobservice) {
		this.strlobservice = strlobservice;
	}

	
	public String getStrlobtype() {
		return strlobtype;
	}

	public void setStrlobtype(String strlobtype) {
		this.strlobtype = strlobtype;
	}

	
	public String getStrsoapenvelope() {
		return strsoapenvelope;
	}

	public void setStrsoapenvelope(String strsoapenvelope) {
		if(strsoapenvelope != null)
			this.strsoapenvelope = new String(Base64.encodeBase64(strsoapenvelope.getBytes()));
		else
			this.strsoapenvelope = strsoapenvelope;
	}

}

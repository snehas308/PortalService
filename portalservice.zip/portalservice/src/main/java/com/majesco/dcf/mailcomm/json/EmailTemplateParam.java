package com.majesco.dcf.mailcomm.json;

import java.util.HashMap;

public class EmailTemplateParam {

	private String eventID;
	private HashMap<String, String> parameterMap;
	public String getEventID() {
		return eventID;
	}
	public void setEventID(String eventID) {
		this.eventID = eventID;
	}
	public HashMap<String, String> getParameterMap() {
		return parameterMap;
	}
	public void setParameterMap(HashMap<String, String> parameterMap) {
		this.parameterMap = parameterMap;
	}
	
	
}

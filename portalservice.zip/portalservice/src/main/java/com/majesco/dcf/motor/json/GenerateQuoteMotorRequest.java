package com.majesco.dcf.motor.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.CustomerDetails;
import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.common.tagic.util.ServiceUtility;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class GenerateQuoteMotorRequest extends UserObject {

	
	private String strprodcd;
	private String strcustID;
	private String strcustName;
	private String printFlag;
	private RiskDetails lstRiskdet;
	private CustomerDetails lstcustDet;
	private VehicleRegDetails lstvecReg;
	private VehicleAdditionalDetails lsdaddDet;
	private DiscountDeatils lstdiscdet;
	private AddOnCoverDetails lstAddonCover;
	private ChannelDetails lstChanlDet;
	private CoverNoteDetails lstCvrNtDet;
	private DriverDetails lstDrivrDet;
	private DocumentChecklistDetails lstDocChkDet;
	private PreInspectionResultDetails lstPreInspResDet;
	private PrevExistingPolDetails prvExisPolDet;
	private NomineeDetails lstNomDet;
	
	
	//Additional Fields
	private String policyNumber;
	private String proposalNumber;
	private String quotationNumber;
	private String isRenew;
	ServiceUtility serviceUtility = new ServiceUtility();
	/**
	 * Mapping for Rate field
	 */
	private String discountRate;
	//private String authenticationToken;
	
	public String getDiscountRate() {
		return discountRate;
	}
	public void setDiscountRate(String discountRate) {
		this.discountRate = discountRate;
	}
	public String getStrprodcd() {
		return strprodcd;
	}
	public void setStrprodcd(String strprodcd) {
		strprodcd = serviceUtility.blankToNullCheck(strprodcd);
		this.strprodcd = strprodcd;
	}
	public String getStrcustID() {
		return strcustID;
	}
	public void setStrcustID(String strcustID) {
		strcustID = serviceUtility.blankToNullCheck(strcustID);
		this.strcustID = strcustID;
	}
	public String getStrcustName() {
		return strcustName;
	}
	public void setStrcustName(String strcustName) {
		strcustName = serviceUtility.blankToNullCheck(strcustName);
		this.strcustName = strcustName;
	}
	public RiskDetails getLstRiskdet() {
		return lstRiskdet;
	}
	public void setLstRiskdet(RiskDetails lstRiskdet) {
		this.lstRiskdet = lstRiskdet;
	}
	public CustomerDetails getLstcustDet() {
		return lstcustDet;
	}
	public void setLstcustDet(CustomerDetails lstcustDet) {
		this.lstcustDet = lstcustDet;
	}
	public VehicleRegDetails getLstvecReg() {
		return lstvecReg;
	}
	public void setLstvecReg(VehicleRegDetails lstvecReg) {
		this.lstvecReg = lstvecReg;
	}
	public VehicleAdditionalDetails getLsdaddDet() {
		return lsdaddDet;
	}
	public void setLsdaddDet(VehicleAdditionalDetails lsdaddDet) {
		this.lsdaddDet = lsdaddDet;
	}
	public DiscountDeatils getLstdiscdet() {
		return lstdiscdet;
	}
	public void setLstdiscdet(DiscountDeatils lstdiscdet) {
		this.lstdiscdet = lstdiscdet;
	}
	public AddOnCoverDetails getLstAddonCover() {
		return lstAddonCover;
	}
	public void setLstAddonCover(AddOnCoverDetails lstAddonCover) {
		this.lstAddonCover = lstAddonCover;
	}
	public ChannelDetails getLstChanlDet() {
		return lstChanlDet;
	}
	public void setLstChanlDet(ChannelDetails lstChanlDet) {
		this.lstChanlDet = lstChanlDet;
	}
	public String getPrintFlag() {
		return printFlag;
	}
	public void setPrintFlag(String printFlag) {
		printFlag = serviceUtility.blankToNullCheck(printFlag);
		this.printFlag = printFlag;
	}
	public CoverNoteDetails getLstCvrNtDet() {
		return lstCvrNtDet;
	}
	public void setLstCvrNtDet(CoverNoteDetails lstCvrNtDet) {
		this.lstCvrNtDet = lstCvrNtDet;
	}
	public DriverDetails getLstDrivrDet() {
		return lstDrivrDet;
	}
	public void setLstDrivrDet(DriverDetails lstDrivrDet) {
		this.lstDrivrDet = lstDrivrDet;
	}
	public DocumentChecklistDetails getLstDocChkDet() {
		return lstDocChkDet;
	}
	public void setLstDocChkDet(DocumentChecklistDetails lstDocChkDet) {
		this.lstDocChkDet = lstDocChkDet;
	}
	public PreInspectionResultDetails getLstPreInspResDet() {
		return lstPreInspResDet;
	}
	public void setLstPreInspResDet(PreInspectionResultDetails lstPreInspResDet) {
		this.lstPreInspResDet = lstPreInspResDet;
	}
	public NomineeDetails getLstNomDet() {
		return lstNomDet;
	}
	public void setLstNomDet(NomineeDetails lstNomDet) {
		this.lstNomDet = lstNomDet;
	}
	public String getProposalNumber() {
		return proposalNumber;
	}
	public void setProposalNumber(String proposalNumber) {
		proposalNumber = serviceUtility.blankToNullCheck(proposalNumber);
		this.proposalNumber = proposalNumber;
	}
	public String getQuotationNumber() {
		return quotationNumber;
	}
	public void setQuotationNumber(String quotationNumber) {
		quotationNumber = serviceUtility.blankToNullCheck(quotationNumber);
		this.quotationNumber = quotationNumber;
	}
	public String getIsRenew() {
		return isRenew;
	}
	public void setIsRenew(String isRenew) {
		isRenew = serviceUtility.blankToNullCheck(isRenew);
		this.isRenew = isRenew;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		policyNumber = serviceUtility.blankToNullCheck(policyNumber);
		this.policyNumber = policyNumber;
	}
	public PrevExistingPolDetails getPrvExisPolDet() {
		return prvExisPolDet;
	}
	public void setPrvExisPolDet(PrevExistingPolDetails prvExisPolDet) {
		this.prvExisPolDet = prvExisPolDet;
	}
	
//	public String getAuthenticationToken() {
//		return authenticationToken;
//	}
//	public void setAuthenticationToken(String authenticationToken) {
//		this.authenticationToken = authenticationToken;
//	}
	
	
	
}

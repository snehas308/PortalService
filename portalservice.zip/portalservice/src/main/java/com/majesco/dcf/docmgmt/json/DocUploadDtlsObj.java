package com.majesco.dcf.docmgmt.json;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author yogesh570158
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocUploadDtlsObj {

	private long ndocid;
	//private Integer activeStatus;
	private String proposalNo;
	private String policyNo;
	private String docmodMapId;
	private String docIndex;
	private String docName;	
	private String docPath;
	private String fileExt;
	private String fileName;
	private String fileSize;
	private String fileType;
	private String functionId;
	private String isHardCopy;
	private String isMandatory ;
	private String module;
	private String remarks;
	private String uploadBy;
	//private Date uploadDate;
	private String version;
	private String createdBy;
	
	private List<MultipartFile> files;
	
	private Date dtCreated;
	private String updatedBy;
	private Date dtUpdated;
	//private String docModMapId;
	
	private String strdocstatus;
	
	//Start:-@Yogesh|05/01/2018|Added code for defectId-1305
	private String strOmniDocStatus;
	private Date dtOmniDoc;
	private String strIsRenew;
	//End:-@Yogesh|05/01/2018|Added code for defectId-1305
	
	private String strSource;
	
	
	
	public String getStrSource() {
		return strSource;
	}
	public void setStrSource(String strSource) {
		this.strSource = strSource;
	}
	
	public String getStrdocstatus() {
		return strdocstatus;
	}
	public void setStrdocstatus(String strdocstatus) {
		this.strdocstatus = strdocstatus;
	}
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getDocmodMapId() {
		return docmodMapId;
	}
	public void setDocmodMapId(String docmodMapId) {
		this.docmodMapId = docmodMapId;
	}
	public String getDocIndex() {
		return docIndex;
	}
	public void setDocIndex(String docIndex) {
		this.docIndex = docIndex;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getDocPath() {
		return docPath;
	}
	public void setDocPath(String docPath) {
		this.docPath = docPath;
	}
	public String getFileExt() {
		return fileExt;
	}
	public void setFileExt(String fileExt) {
		this.fileExt = fileExt;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getFunctionId() {
		return functionId;
	}
	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}
	
	
	public String isHardCopy() {
		return isHardCopy;
	}
	public void setHardCopy(String isHardCopy) {
		this.isHardCopy = isHardCopy;
	}
	
	
	public String isMandatory() {
		return isMandatory;
	}
	public void setMandatory(String isMandatory) {
		this.isMandatory = isMandatory;
	}
	
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getUploadBy() {
		return uploadBy;
	}
	public void setUploadBy(String uploadBy) {
		this.uploadBy = uploadBy;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public List<MultipartFile> getFiles() {
		return files;
	}
	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}
	public long getNdocid() {
		return ndocid;
	}
	public void setNdocid(long ndocid) {
		this.ndocid = ndocid;
	}
	public Date getDtCreated() {
		return dtCreated;
	}
	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getDtUpdated() {
		return dtUpdated;
	}
	public void setDtUpdated(Date dtUpdated) {
		this.dtUpdated = dtUpdated;
	}
	//Start:-@Yogesh|05/01/2018|Added code for defectId-1305
	public String getStrOmniDocStatus() {
		return strOmniDocStatus;
	}
	public void setStrOmniDocStatus(String strOmniDocStatus) {
		this.strOmniDocStatus = strOmniDocStatus;
	}
	public Date getDtOmniDoc() {
		return dtOmniDoc;
	}
	public void setDtOmniDoc(Date dtOmniDoc) {
		this.dtOmniDoc = dtOmniDoc;
	}
	public String getStrIsRenew() {
		return strIsRenew;
	}
	public void setStrIsRenew(String strIsRenew) {
		this.strIsRenew = strIsRenew;
	}
	//End:-@Yogesh|05/01/2018|Added code for defectId-1305
	
	
	
//	public String getDocModMapId() {
//		return docModMapId;
//	}
//	public void setDocModMapId(String docModMapId) {
//		this.docModMapId = docModMapId;
//	}
	
	
}

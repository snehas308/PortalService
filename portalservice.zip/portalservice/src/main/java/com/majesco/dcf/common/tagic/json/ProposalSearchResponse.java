package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ProposalSearchResponse extends ResultObject {

	private ArrayList<ProposalSearchResultDet> proposalSearchResultDetList=new ArrayList<ProposalSearchResultDet>();

	public ArrayList<ProposalSearchResultDet> getProposalSearchResultDetList() {
		return proposalSearchResultDetList;
	}

	public void setProposalSearchResultDetList(
			ArrayList<ProposalSearchResultDet> proposalSearchResultDetList) {
		this.proposalSearchResultDetList = proposalSearchResultDetList;
	}
	
}

package com.majesco.dcf.claims.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CoverageSearchRequest extends UserObject
{
	private String policyNumber;
	private String coverNoteNumber;
	private String dateOfLoss;
	private String intermediatoryCode;
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getCoverNoteNumber() {
		return coverNoteNumber;
	}
	public void setCoverNoteNumber(String coverNoteNumber) {
		this.coverNoteNumber = coverNoteNumber;
	}
	public String getDateOfLoss() {
		return dateOfLoss;
	}
	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}
	public String getIntermediatoryCode() {
		return intermediatoryCode;
	}
	public void setIntermediatoryCode(String intermediatoryCode) {
		this.intermediatoryCode = intermediatoryCode;
	}
	
	
}

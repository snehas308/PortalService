package com.majesco.dcf.docmgmt.json;

import java.util.List;
import java.util.Date;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

/**
 * @author yogesh570158
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ProducerLockDtlsSearchReq extends UserObject{
	
	private String producerCd;
	private String lob;

	
	public String getProducerCd() {
		return producerCd;
	}
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	
}

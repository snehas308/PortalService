package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ProposalStatus extends ResultObject{

	private String proposalStatus;
	private String proposalStatusDesc;
	public String getProposalStatus() {
		return proposalStatus;
	}
	public void setProposalStatus(String proposalStatus) {
		this.proposalStatus = proposalStatus;
	}
	public String getProposalStatusDesc() {
		return proposalStatusDesc;
	}
	public void setProposalStatusDesc(String proposalStatusDesc) {
		this.proposalStatusDesc = proposalStatusDesc;
	}
}

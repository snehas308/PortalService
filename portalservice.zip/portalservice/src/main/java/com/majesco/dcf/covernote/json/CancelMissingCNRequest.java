package com.majesco.dcf.covernote.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CancelMissingCNRequest extends UserObject{

	private MissingCoverNoteDtl objCoverNote;
	private String ipAddress;
	private String coverNoteFlag;
	
	public MissingCoverNoteDtl getObjCoverNote() {
		return objCoverNote;
	}
	public void setObjCoverNote(MissingCoverNoteDtl objCoverNote) {
		this.objCoverNote = objCoverNote;
	}
	public String getCoverNoteFlag() {
		return coverNoteFlag;
	}
	public void setCoverNoteFlag(String coverNoteFlag) {
		this.coverNoteFlag = coverNoteFlag;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
}

package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.dozer.Mapping;

import java.util.Date;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class VehicleVariantRequest {

	private String strmanufacturercd;
	private String strprodcd;
	private String strmodelnumber;

	
	public String getStrmodelnumber() {
		return strmodelnumber;
	}
	public void setStrmodelnumber(String strmodelnumber) {
		this.strmodelnumber = strmodelnumber;
	}
	public String getStrmanufacturercd() {
		return strmanufacturercd;
	}
	public void setStrmanufacturercd(String strmanufacturercd) {
		this.strmanufacturercd = strmanufacturercd;
	}
	public String getStrprodcd() {
		return strprodcd;
	}
	public void setStrprodcd(String strprodcd) {
		this.strprodcd = strprodcd;
	}
	
	
}

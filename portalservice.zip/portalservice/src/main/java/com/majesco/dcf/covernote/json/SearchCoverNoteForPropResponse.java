package com.majesco.dcf.covernote.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class SearchCoverNoteForPropResponse {
	
	private String coverNoteNo;
	private String coverNoteStatus;
	private String covernoteProducerCode;
	private String producerName;
	
	public String getCoverNoteNo() {
		return coverNoteNo;
	}
	public void setCoverNoteNo(String coverNoteNo) {
		this.coverNoteNo = coverNoteNo;
	}
	public String getCoverNoteStatus() {
		return coverNoteStatus;
	}
	public void setCoverNoteStatus(String coverNoteStatus) {
		this.coverNoteStatus = coverNoteStatus;
	}
	public String getCovernoteProducerCode() {
		return covernoteProducerCode;
	}
	public void setCovernoteProducerCode(String covernoteProducerCode) {
		this.covernoteProducerCode = covernoteProducerCode;
	}
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}

}

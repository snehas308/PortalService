package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class IntermediaryOfficeCodeServiceResponse {
	
	private String intermediaryCode;
	private String intermediaryName;
	private String intermediaryOfficeCode;
	public String getIntermediaryCode() {
		return intermediaryCode;
	}
	public void setIntermediaryCode(String intermediaryCode) {
		this.intermediaryCode = intermediaryCode;
	}
	public String getIntermediaryName() {
		return intermediaryName;
	}
	public void setIntermediaryName(String intermediaryName) {
		this.intermediaryName = intermediaryName;
	}
	public String getIntermediaryOfficeCode() {
		return intermediaryOfficeCode;
	}
	public void setIntermediaryOfficeCode(String intermediaryOfficeCode) {
		this.intermediaryOfficeCode = intermediaryOfficeCode;
	}
	
	

}

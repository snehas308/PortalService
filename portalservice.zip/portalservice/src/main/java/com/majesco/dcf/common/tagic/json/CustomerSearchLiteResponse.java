package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CustomerSearchLiteResponse {

	private String producercode;
	private List<CustomerDetails> lstCustDet;
	private List<ResponseError> lstResErr;
	public String getProducercode() {
		return producercode;
	}
	public void setProducercode(String producercode) {
		this.producercode = producercode;
	}
	public List<CustomerDetails> getLstCustDet() {
		return lstCustDet;
	}
	public void setLstCustDet(List<CustomerDetails> lstCustDet) {
		this.lstCustDet = lstCustDet;
	}
	public List<ResponseError> getLstResErr() {
		return lstResErr;
	}
	public void setLstResErr(List<ResponseError> lstResErr) {
		this.lstResErr = lstResErr;
	}
	
	
	
	
}

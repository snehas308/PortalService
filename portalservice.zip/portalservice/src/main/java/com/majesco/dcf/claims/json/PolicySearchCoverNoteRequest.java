package com.majesco.dcf.claims.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PolicySearchCoverNoteRequest extends UserObject
{
	private String coverNoteNumber;
	private String intermediatoryCode;

	public String getCoverNoteNumber() {
		return coverNoteNumber;
	}

	public void setCoverNoteNumber(String coverNoteNumber) {
		this.coverNoteNumber = coverNoteNumber;
	}

	public String getIntermediatoryCode() {
		return intermediatoryCode;
	}

	public void setIntermediatoryCode(String intermediatoryCode) {
		this.intermediatoryCode = intermediatoryCode;
	}
	
	

}

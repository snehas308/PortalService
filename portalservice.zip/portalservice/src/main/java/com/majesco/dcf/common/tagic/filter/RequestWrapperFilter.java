package com.majesco.dcf.common.tagic.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

public class RequestWrapperFilter implements Filter {
	final static Logger logger=Logger.getLogger(RequestWrapperFilter.class.getName());
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		
	//	MultiReadHttpServletRequest requestWrapper=new MultiReadHttpServletRequest(request);
		HttpServletRequest httpRequest=(HttpServletRequest) request;
		//System.out.println("Content type from header ::"+httpRequest.getHeader("Content-Type"));
		String excludePath=((HttpServletRequest) request).getRequestURI();
		//Start:<YogeshM>:<20/12/2017>:<SIT>:<DefectID-0001305>:<Filter skipped for exclude multipart content-type>
		String excludeContentType=httpRequest.getHeader("Content-Type");
		if(excludePath!=null && (excludePath.contains("CommonService/printPolicy") || excludePath.contains("CommonService/printProposal") || excludePath.contains("CommonService/printWorksheet") || excludePath.contains("CommonService/printPolicySPL") || excludePath.contains("CommonService/printProposalSPL") || excludePath.contains("payment")) || (excludeContentType!=null && excludeContentType.contains("multipart/form-data"))){
			logger.info("Filter skipped for ::"+excludePath);
			logger.info("Filter skipped for excludeContentType ::"+excludeContentType);
		//End:<YogeshM>:<20/12/2017>:<SIT>:<DefectID-0001305>:<Filter skipped for exclude multipart content-type>	
			chain.doFilter((HttpServletRequest) request,response);
		}else{
		MultiReadHttpServletRequest requestWrapper=new MultiReadHttpServletRequest((HttpServletRequest)request);
		//HttpServletRequest httpRequest=(HttpServletRequest)request;
		logger.info("Request wrapped ::");
		 // Pass request back down the filter 
		 chain.doFilter(requestWrapper,response);
		}
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

}

package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CustomerDetailResponse {

	private List<CustomerDetails> custDetails;
	public List<CustomerDetails> getCustDetails() {
		return custDetails;
	}
	public void setCustDetails(List<CustomerDetails> custDetails) {
		this.custDetails = custDetails;
	}
	private List<ResponseError> resErr;
	private String resultCode;
	
	
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	
}

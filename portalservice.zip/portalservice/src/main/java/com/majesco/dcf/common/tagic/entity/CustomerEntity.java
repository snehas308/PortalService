package com.majesco.dcf.common.tagic.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "dcf_client_m")
public class CustomerEntity {

	@Id
	@Column(name="strcustomerid")
	private String strcustomerid;
	
	@Column(name="strcustomertype")
	private String strcustomertype;
	
	@Column(name="strtitle")
	private String strtitle;
	
	@Column(name="strfirstname")
	private String strfirstname;
	
	@Column(name="strmiddlename")
	private String strmiddlename;
	
	@Column(name="strlastname")
	private String strlastname;
	
	@Column(name="strdob")
	private String strdob;
	
	@Column(name="strgender")
	private String strgender;
	
	@Column(name="stridtype")
	private String stridtype;
	
	@Column(name="stridnumber")
	private String stridnumber;
	
	@Column(name="stremail")
	private String stremail;
	
	@Column(name="strmobile")
	private String strmobile;
	
	@Column(name="strpincode")
	private String strpincode;
	
	@Column(name="strstatecode")
	private String strstatecode;
	
	@Column(name="strcitycode")
	private String strcitycode;
	
	@Column(name="stripaddress")
	private String stripaddress;
	
	@Column(name="strproducercode")
	private String strproducercode;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtcreated", insertable=false)
	private Date dtcreated;
	
	@Column(name= "strcreatedby")
	private String strcreatedby;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtupdated", insertable=false)
	private Date dtupdated;
	
	@Column(name= "strupdatedby")
	private String strupdatedby;
	
	@Column(name= "straadharno")
	private String straadharno;

	@Column(name= "strgstnumber")
	private String strgstnumber;

	public String getStrcustomerid() {
		return strcustomerid;
	}

	public void setStrcustomerid(String strcustomerid) {
		this.strcustomerid = strcustomerid;
	}

	public String getStrcustomertype() {
		return strcustomertype;
	}

	public void setStrcustomertype(String strcustomertype) {
		this.strcustomertype = strcustomertype;
	}

	public String getStrtitle() {
		return strtitle;
	}

	public void setStrtitle(String strtitle) {
		this.strtitle = strtitle;
	}

	public String getStrfirstname() {
		return strfirstname;
	}

	public void setStrfirstname(String strfirstname) {
		this.strfirstname = strfirstname;
	}

	public String getStrmiddlename() {
		return strmiddlename;
	}

	public void setStrmiddlename(String strmiddlename) {
		this.strmiddlename = strmiddlename;
	}

	public String getStrlastname() {
		return strlastname;
	}

	public void setStrlastname(String strlastname) {
		this.strlastname = strlastname;
	}

	public String getStrdob() {
		return strdob;
	}

	public void setStrdob(String strdob) {
		this.strdob = strdob;
	}

	public String getStrgender() {
		return strgender;
	}

	public void setStrgender(String strgender) {
		this.strgender = strgender;
	}

	public String getStridtype() {
		return stridtype;
	}

	public void setStridtype(String stridtype) {
		this.stridtype = stridtype;
	}

	public String getStridnumber() {
		return stridnumber;
	}

	public void setStridnumber(String stridnumber) {
		this.stridnumber = stridnumber;
	}

	public String getStremail() {
		return stremail;
	}

	public void setStremail(String stremail) {
		this.stremail = stremail;
	}

	public String getStrmobile() {
		return strmobile;
	}

	public void setStrmobile(String strmobile) {
		this.strmobile = strmobile;
	}

	public String getStrpincode() {
		return strpincode;
	}

	public void setStrpincode(String strpincode) {
		this.strpincode = strpincode;
	}

	public String getStrstatecode() {
		return strstatecode;
	}

	public void setStrstatecode(String strstatecode) {
		this.strstatecode = strstatecode;
	}

	public String getStrcitycode() {
		return strcitycode;
	}

	public void setStrcitycode(String strcitycode) {
		this.strcitycode = strcitycode;
	}

	public String getStripaddress() {
		return stripaddress;
	}

	public void setStripaddress(String stripaddress) {
		this.stripaddress = stripaddress;
	}

	public String getStrproducercode() {
		return strproducercode;
	}

	public void setStrproducercode(String strproducercode) {
		this.strproducercode = strproducercode;
	}

	public Date getDtcreated() {
		return dtcreated;
	}

	public void setDtcreated(Date dtcreated) {
		this.dtcreated = dtcreated;
	}

	public String getStrcreatedby() {
		return strcreatedby;
	}

	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}

	public Date getDtupdated() {
		return dtupdated;
	}

	public void setDtupdated(Date dtupdated) {
		this.dtupdated = dtupdated;
	}

	public String getStrupdatedby() {
		return strupdatedby;
	}

	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}

	public String getStraadharno() {
		return straadharno;
	}

	public void setStraadharno(String straadharno) {
		this.straadharno = straadharno;
	}
	
	public String getStrgstnumber() {
		return strgstnumber;
	}

	public void setStrgstnumber(String strgstnumber) {
		this.strgstnumber = strgstnumber;
	}	
	
}

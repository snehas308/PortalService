package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class AddOnResponse {
	
	private String strplanname="";
	  private String strchoice="";
	  private String ndepreciationreimbursement;
	  private String strnoofclaims="";
	  private String nenginesecure;
	  private String strenginesecureoption="";
	  private String ntyresecure;
	  private String strtyresecureoption="";
	  private String nrepairofglassrubberplasticparts;
	  private String nkeyreplacement;
	  private String strkeyreplacementsi="";
	  private String nconsumableexpenses;
	  private String nlossofpersonalbelongings;
	  private String strlossofpersonalbelongingssi="";
	  private String nroadsideassistance;
	  private String stremergtrnsprtandhotelexpensidv="";
	  private String strratioofaoaaoy="";
	  private String stremergencytransportsiaoa="";
	  private String stremergencytransportsiaoy="";
	  private String ndailyallowance;
	  private String straccidentallowancedays="";
	  private String strtheftallowancedays="";
	  private String strfranchisedays="";
	  private String nreturntoinvoice;
	  private String straddonpremium="";
	  private String dtcreated="";
	  private String strcreatedby="";
	  private String dtupdated="";
	  private String strupdatedby="";
	
	  
	public String getStrplanname() {
		return strplanname;
	}
	public void setStrplanname(String strplanname) {
		this.strplanname = strplanname;
	}
	public String getStrchoice() {
		return strchoice;
	}
	public void setStrchoice(String strchoice) {
		this.strchoice = strchoice;
	}
	public String getNdepreciationreimbursement() {
		return ndepreciationreimbursement;
	}
	public void setNdepreciationreimbursement(String ndepreciationreimbursement) {
		this.ndepreciationreimbursement = ndepreciationreimbursement;
	}
	public String getStrnoofclaims() {
		return strnoofclaims;
	}
	public void setStrnoofclaims(String strnoofclaims) {
		this.strnoofclaims = strnoofclaims;
	}
	public String getNenginesecure() {
		return nenginesecure;
	}
	public void setNenginesecure(String nenginesecure) {
		this.nenginesecure = nenginesecure;
	}
	public String getStrenginesecureoption() {
		return strenginesecureoption;
	}
	public void setStrenginesecureoption(String strenginesecureoption) {
		this.strenginesecureoption = strenginesecureoption;
	}
	public String getNtyresecure() {
		return ntyresecure;
	}
	public void setNtyresecure(String ntyresecure) {
		this.ntyresecure = ntyresecure;
	}
	public String getStrtyresecureoption() {
		return strtyresecureoption;
	}
	public void setStrtyresecureoption(String strtyresecureoption) {
		this.strtyresecureoption = strtyresecureoption;
	}
	public String getNrepairofglassrubberplasticparts() {
		return nrepairofglassrubberplasticparts;
	}
	public void setNrepairofglassrubberplasticparts(String nrepairofglassrubberplasticparts) {
		this.nrepairofglassrubberplasticparts = nrepairofglassrubberplasticparts;
	}
	public String getNkeyreplacement() {
		return nkeyreplacement;
	}
	public void setNkeyreplacement(String nkeyreplacement) {
		this.nkeyreplacement = nkeyreplacement;
	}
	public String getStrkeyreplacementsi() {
		return strkeyreplacementsi;
	}
	public void setStrkeyreplacementsi(String strkeyreplacementsi) {
		this.strkeyreplacementsi = strkeyreplacementsi;
	}
	public String getNconsumableexpenses() {
		return nconsumableexpenses;
	}
	public void setNconsumableexpenses(String nconsumableexpenses) {
		this.nconsumableexpenses = nconsumableexpenses;
	}
	public String getNlossofpersonalbelongings() {
		return nlossofpersonalbelongings;
	}
	public void setNlossofpersonalbelongings(String nlossofpersonalbelongings) {
		this.nlossofpersonalbelongings = nlossofpersonalbelongings;
	}
	public String getStrlossofpersonalbelongingssi() {
		return strlossofpersonalbelongingssi;
	}
	public void setStrlossofpersonalbelongingssi(String strlossofpersonalbelongingssi) {
		this.strlossofpersonalbelongingssi = strlossofpersonalbelongingssi;
	}
	public String getNroadsideassistance() {
		return nroadsideassistance;
	}
	public void setNroadsideassistance(String nroadsideassistance) {
		this.nroadsideassistance = nroadsideassistance;
	}
	public String getStremergtrnsprtandhotelexpensidv() {
		return stremergtrnsprtandhotelexpensidv;
	}
	public void setStremergtrnsprtandhotelexpensidv(String stremergtrnsprtandhotelexpensidv) {
		this.stremergtrnsprtandhotelexpensidv = stremergtrnsprtandhotelexpensidv;
	}
	public String getStrratioofaoaaoy() {
		return strratioofaoaaoy;
	}
	public void setStrratioofaoaaoy(String strratioofaoaaoy) {
		this.strratioofaoaaoy = strratioofaoaaoy;
	}
	public String getStremergencytransportsiaoa() {
		return stremergencytransportsiaoa;
	}
	public void setStremergencytransportsiaoa(String stremergencytransportsiaoa) {
		this.stremergencytransportsiaoa = stremergencytransportsiaoa;
	}
	public String getStremergencytransportsiaoy() {
		return stremergencytransportsiaoy;
	}
	public void setStremergencytransportsiaoy(String stremergencytransportsiaoy) {
		this.stremergencytransportsiaoy = stremergencytransportsiaoy;
	}
	public String getNdailyallowance() {
		return ndailyallowance;
	}
	public void setNdailyallowance(String ndailyallowance) {
		this.ndailyallowance = ndailyallowance;
	}
	public String getStraccidentallowancedays() {
		return straccidentallowancedays;
	}
	public void setStraccidentallowancedays(String straccidentallowancedays) {
		this.straccidentallowancedays = straccidentallowancedays;
	}
	public String getStrtheftallowancedays() {
		return strtheftallowancedays;
	}
	public void setStrtheftallowancedays(String strtheftallowancedays) {
		this.strtheftallowancedays = strtheftallowancedays;
	}
	public String getStrfranchisedays() {
		return strfranchisedays;
	}
	public void setStrfranchisedays(String strfranchisedays) {
		this.strfranchisedays = strfranchisedays;
	}
	public String getNreturntoinvoice() {
		return nreturntoinvoice;
	}
	public void setNreturntoinvoice(String nreturntoinvoice) {
		this.nreturntoinvoice = nreturntoinvoice;
	}
	public String getStraddonpremium() {
		return straddonpremium;
	}
	public void setStraddonpremium(String straddonpremium) {
		this.straddonpremium = straddonpremium;
	}
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}

}

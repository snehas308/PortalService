package com.majesco.dcf.common.tagic.json;

public class RenewalCalCountData {

	private String policyDate;
	private String pendingCount;
	private String convertedCount;
	public String getPolicyDate() {
		return policyDate;
	}
	public void setPolicyDate(String policyDate) {
		this.policyDate = policyDate;
	}
	public String getPendingCount() {
		return pendingCount;
	}
	public void setPendingCount(String pendingCount) {
		this.pendingCount = pendingCount;
	}
	public String getConvertedCount() {
		return convertedCount;
	}
	public void setConvertedCount(String convertedCount) {
		this.convertedCount = convertedCount;
	}

}

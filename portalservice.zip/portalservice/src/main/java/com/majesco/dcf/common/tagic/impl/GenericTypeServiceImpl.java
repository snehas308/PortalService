package com.majesco.dcf.common.tagic.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.tagic.service.GenericTypeService;

@Service
@Transactional
public class GenericTypeServiceImpl implements GenericTypeService{
	
	final static Logger logger = Logger.getLogger(GenericTypeServiceImpl.class);

	@Override
	public <T> T getObject(Class<T> clazz) throws Exception{
			  
			    return clazz.newInstance();
	}

}//end of class
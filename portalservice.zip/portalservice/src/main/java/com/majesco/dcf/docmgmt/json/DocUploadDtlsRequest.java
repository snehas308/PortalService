package com.majesco.dcf.docmgmt.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author yogesh570158
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocUploadDtlsRequest {

	private List<DocUploadDtlsObj>  docUploadDtlsObj;
	private String isRenew;	

	public List<DocUploadDtlsObj> getDocUploadDtlsObj() {
		return docUploadDtlsObj;
	}
	public void setDocUploadDtlsObj(List<DocUploadDtlsObj> docUploadDtlsObj) {
		this.docUploadDtlsObj = docUploadDtlsObj;
	}
	public String getIsRenew() {
		return isRenew;
	}
	public void setIsRenew(String isRenew) {
		this.isRenew = isRenew;
	}
	
}

package com.majesco.dcf.common.tagic.service;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



//import com.majesco.dcf.common.tagic.controller.GenerateCacheController;


import com.googlecode.ehcache.annotations.Cacheable;
import com.majesco.dcf.common.tagic.entity.Model;
import com.majesco.dcf.common.tagic.entity.Motor;
import com.majesco.dcf.common.tagic.json.ModelResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.VehicleVariantRequest;
import com.majesco.dcf.common.tagic.json.VehicleVariantResponse;
import com.majesco.dcf.common.tagic.service.DBService;

@Service
public class VehicleVariantService {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(VehicleVariantService.class);
	
	@SuppressWarnings("null")
	@Cacheable(cacheName="variantInfoEhcache")
	public VehicleVariantResponse FetchVariantInfo(VehicleVariantRequest quickReq) throws Exception
	{
		VehicleVariantResponse variantres = new VehicleVariantResponse();
		try
		{
		
		logger.info("In VehicleVariantService.FetchVariantInfo Method Begin()...");

		List<ResponseError> reserrList = new ArrayList<ResponseError>();
		String strmodelcd="";
		String strvariant="";
		String strfuel="";
		String strfueldesc="";
		String strbodytypecd="";
		String strbodytypedesc="";
		BigDecimal nvehicleclasscd;
		BigDecimal ncubiccapacity;
		BigDecimal nseatingcapacity;
		BigDecimal ncarryingcapacity;
		String strvehicletype="";
		String strsegmenttype="";
		BigDecimal strgvw;
		
		List<String> lststrmodelcd= new ArrayList<String>();
		List<String> lststrvariant= new ArrayList<String>();
		List<String> lststrfuel= new ArrayList<String>();
		List<String> lststrfueldesc= new ArrayList<String>();
		List<String> lststrbodytypecd= new ArrayList<String>();
		List<String> lststrbodytypedesc= new ArrayList<String>();
		List<BigDecimal> lstnvehicleclasscd= new ArrayList<BigDecimal>();
		List<BigDecimal> lstncubiccapacity= new ArrayList<BigDecimal>();
		List<BigDecimal> lstnseatingcapacity= new ArrayList<BigDecimal>();
		List<BigDecimal> lstncarryingcapacity= new ArrayList<BigDecimal>();
		List<String> lststrvehicletype= new ArrayList<String>();
		List<String> lststrsegmenttype= new ArrayList<String>();
		List<BigDecimal> lststrgvw= new ArrayList<BigDecimal>();
		
		ResponseError res = new ResponseError();
		res.setErrorCode("101");
		res.setErrorMMessag("Sorry Authentication Issue....");
		reserrList.add(res);
		
		@SuppressWarnings("unchecked")
		List<Model> oComMotorList =  (List<Model>) dbserv.getVarInfo("com.majesco.dcf.common.tagic.entity.Model", quickReq);
        for(Model motorList:oComMotorList){
        	strmodelcd=nullCheckString(motorList.getStrmodelcd());
        	strvariant=nullCheckString(motorList.getStrvariant());
        	strfuel=nullCheckString(motorList.getStrfuel());
        	strfueldesc = nullCheckString(motorList.getStrfueldesc());
        	strbodytypecd = nullCheckString(motorList.getStrbodytypecd());
        	strbodytypedesc = nullCheckString(motorList.getStrbodytypedesc());
        	nvehicleclasscd = motorList.getNvehicleclasscd();
    		ncubiccapacity = motorList.getNcubiccapacity();
    		nseatingcapacity = motorList.getNseatingcapacity();
        	ncarryingcapacity = motorList.getNcarryingcapacity();
    		strvehicletype = nullCheckString(motorList.getStrvehicletype()); 
    		strsegmenttype = nullCheckString(motorList.getStrsegmenttype());
    		strgvw = motorList.getNgrossvehicleweight();
    		
    		lststrmodelcd.add(strmodelcd);
			lststrvariant.add(strvariant);
			lststrfuel.add(strfuel);
			lststrfueldesc.add(strfueldesc);
			lststrbodytypecd.add(strbodytypecd);
			lststrbodytypedesc.add(strbodytypedesc);
			lstnvehicleclasscd.add(nvehicleclasscd);
			lststrvehicletype.add(strvehicletype);
			lststrsegmenttype.add(strsegmenttype);
			lstncubiccapacity.add(ncubiccapacity);
			lstnseatingcapacity.add(nseatingcapacity);
			lstncarryingcapacity.add(ncarryingcapacity);
			lststrgvw.add(strgvw);
        }
        variantres.setStrmodelcd(lststrmodelcd);
        variantres.setStrvariant(lststrvariant);
        variantres.setStrfuel(lststrfuel);
        variantres.setStrfueldesc(lststrfueldesc);
        variantres.setStrbodytypecd(lststrbodytypecd);
        variantres.setStrbodytypedesc(lststrbodytypedesc);
        variantres.setNvehicleclasscd(lstnvehicleclasscd);
        variantres.setStrvehicletype(lststrvehicletype);
        variantres.setNcubiccapacity(lstncubiccapacity);
        variantres.setNseatingcapacity(lstnseatingcapacity);
        variantres.setNcarryingcapacity(lstncarryingcapacity);
        variantres.setStrsegmenttype(lststrsegmenttype);
        variantres.setStrgvw(lststrgvw);
        variantres.setResErr(reserrList);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In VehicleVariantService.FetchVariantInfo Method End()...");
		logger.info("In VehicleVariantService.FetchVariantInfo Method :: Response Of variantres : "+variantres);
		
		return variantres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(Object obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }

}

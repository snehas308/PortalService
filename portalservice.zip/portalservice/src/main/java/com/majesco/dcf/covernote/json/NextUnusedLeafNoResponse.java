package com.majesco.dcf.covernote.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class NextUnusedLeafNoResponse {

	private String errorText;
	private String leafNo;
	private String leafName;
	
	public String getErrorText() {
		return errorText;
	}
	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}
	public String getLeafNo() {
		return leafNo;
	}
	public void setLeafNo(String leafNo) {
		this.leafNo = leafNo;
	}
	public String getLeafName() {
		return leafName;
	}
	public void setLeafName(String leafName) {
		this.leafName = leafName;
	}
	
}

package com.majesco.dcf.motor.json;

import java.util.List;

import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.docmgmt.json.DocUploadDtlsObj;

public class DocumentChecklistDetails {
	
	private String serialNo;
	private String docDescrpn;
	private String applcble;
	private String submttd;
	private String notSubmttd;
	private String fileSelectn;
	private String updtDt;
	ServiceUtility serviceUtility = new ServiceUtility();
	private List<DocUploadDtlsObj> lstDocUploadDtls;
	 
	public DocumentChecklistDetails() {}
	
	
	public List<DocUploadDtlsObj> getLstDocUploadDtls() {
		return lstDocUploadDtls;
	}


	public void setLstDocUploadDtls(List<DocUploadDtlsObj> lstDocUploadDtls) {
		this.lstDocUploadDtls = lstDocUploadDtls;
	}


	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		serialNo = serviceUtility.blankToNullCheck(serialNo);
		this.serialNo = serialNo;
	}
	public String getDocDescrpn() {
		return docDescrpn;
	}
	public void setDocDescrpn(String docDescrpn) {
		docDescrpn = serviceUtility.blankToNullCheck(docDescrpn);
		this.docDescrpn = docDescrpn;
	}
	public String getApplcble() {
		return applcble;
	}
	public void setApplcble(String applcble) {
		applcble = serviceUtility.blankToNullCheck(applcble);
		this.applcble = applcble;
	}
	public String getSubmttd() {
		return submttd;
	}
	public void setSubmttd(String submttd) {
		submttd = serviceUtility.blankToNullCheck(submttd);
		this.submttd = submttd;
	}
	public String getNotSubmttd() {
		return notSubmttd;
	}
	public void setNotSubmttd(String notSubmttd) {
		notSubmttd = serviceUtility.blankToNullCheck(notSubmttd);
		this.notSubmttd = notSubmttd;
	}
	public String getFileSelectn() {
		return fileSelectn;
	}
	public void setFileSelectn(String fileSelectn) {
		fileSelectn = serviceUtility.blankToNullCheck(fileSelectn);
		this.fileSelectn = fileSelectn;
	}
	public String getUpdtDt() {
		return updtDt;
	}
	public void setUpdtDt(String updtDt) {
		updtDt = serviceUtility.blankToNullCheck(updtDt);
		this.updtDt = updtDt;
	}
	
	

}

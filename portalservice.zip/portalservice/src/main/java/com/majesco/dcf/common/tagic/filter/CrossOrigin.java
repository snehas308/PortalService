package com.majesco.dcf.common.tagic.filter;
import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value; //@Yogesh:-17/03/2018|VAPT:for CSRF validation

/**
 * 
 * Standard Filter. Allows cross origin restful access. 
 */
public class CrossOrigin implements Filter {

	final static Logger logger = Logger.getLogger(CrossOrigin.class);
	
	@Value("${accesscntrlorigin}") //@Yogesh:-17/03/2018|VAPT:for CSRF validation
	private String accessCntrlOrigin; //@Yogesh:-17/03/2018|VAPT:for CSRF validation
	
	@Override
	public void destroy() {
	
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		
		if(logger.isDebugEnabled()){
			logger.debug("In CrossOrigin.doFilter Method");
		}
		
		HttpServletResponse r = (HttpServletResponse) response;
	    //String origin = ((HttpServletRequest) request).getHeader("origin");
	   // r.addHeader("Access-Control-Allow-Origin", "*"); //@Yogesh:-17/03/2018|VAPT:for CSRF validation
	    r.addHeader("Access-Control-Allow-Origin", "*"); //@Yogesh:-17/03/2018|VAPT:for CSRF validation

	    r.addHeader("Access-Control-Allow-Headers",
	            "Accept,Accept-Encoding,Accept-Language,Cache-Control,"
	            + "Connection,Content-Length,Content-Type," +
	            "Cookie,Host,Pragma,Referer,RemoteQueueID,User-Agent,refresh_token,X-Forwarded-For,gc_token,Checksum"	            
	    		);
	    r.addHeader("Access-Control-Allow-Credentials", "true");
	    r.addHeader("Access-Control-Allow-Methods", "GET, POST, PUT");
	    r.addHeader( "X-FRAME-OPTIONS", "DENY" );
	    //Added for Keycloak token management.
	    r.addHeader("Access-Control-Expose-Headers", "refresh_token,gc_token");
	    //Start:1726:PROD:Added to set character encoding to UTF-8. By default servlet is ISO-8859-1
	    request.setCharacterEncoding("UTF-8");
	  //End:1726:PROD:Added to set character encoding to UTF-8. By default servlet is ISO-8859-1
	    chain.doFilter(request, response);
	    
	    if(logger.isDebugEnabled()){
			logger.debug("Out CrossOrigin.doFilter Method");
		}
	} 

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	
	} 

}

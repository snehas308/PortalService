package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_vehicle_idv_m",schema="dcf_master")
@Table(name = "dcf_vehicle_idv_m")
public class VehicleIdv implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4206211346639598162L;
	/**
	 * 
	 */
	
	private BigDecimal nvhidvseq;
	  public static long getSerialversionuid() {
		return serialVersionUID;
	}
	private String strrtolocationcd="";
	  private BigDecimal nvehicleclasscd;
	  private String strmanufacturercd="";
	  private String strmodelcd="";
	  private BigDecimal npgid;
	  private BigDecimal nvehicleage;
	  private BigDecimal nvehiclemodelstatus;
	  private String dtstart="";
	  private String dtend ="";
	  private BigDecimal nidv;
	  private BigDecimal nvehiclesellingprice;
	  private BigDecimal nvehiclechassisprice;
	  private BigDecimal nlocationexshowroomprice;
	  private String dtcreated="";
	  private String strcreatedby="";
	  private String dtupdated="";
	  private String strupdatedby="";
	  
	@Id
	@Column(name = "nvhidvseq")  
	public BigDecimal getNvhidvseq() {
		return nvhidvseq;
	}
	public void setNvhidvseq(BigDecimal nvhidvseq) {
		this.nvhidvseq = nvhidvseq;
	}
	
	@Column(name = "strrtolocationcd") 
	public String getStrrtolocationcd() {
		return strrtolocationcd;
	}
	public void setStrrtolocationcd(String strrtolocationcd) {
		this.strrtolocationcd = strrtolocationcd;
	}
	
	@Column(name = "nvehicleclasscd") 
	public BigDecimal getNvehicleclasscd() {
		return nvehicleclasscd;
	}
	public void setNvehicleclasscd(BigDecimal nvehicleclasscd) {
		this.nvehicleclasscd = nvehicleclasscd;
	}
	
	@Column(name = "strmanufacturercd") 
	public String getStrmanufacturercd() {
		return strmanufacturercd;
	}
	public void setStrmanufacturercd(String strmanufacturercd) {
		this.strmanufacturercd = strmanufacturercd;
	}
	
	@Column(name = "strmodelcd") 
	public String getStrmodelcd() {
		return strmodelcd;
	}
	public void setStrmodelcd(String strmodelcd) {
		this.strmodelcd = strmodelcd;
	}
	
	@Column(name = "npgid") 
	public BigDecimal getNpgid() {
		return npgid;
	}
	public void setNpgid(BigDecimal npgid) {
		this.npgid = npgid;
	}
	
	@Column(name = "nvehicleage") 
	public BigDecimal getNvehicleage() {
		return nvehicleage;
	}
	public void setNvehicleage(BigDecimal nvehicleage) {
		this.nvehicleage = nvehicleage;
	}
	
	@Column(name = "nvehiclemodelstatus") 
	public BigDecimal getNvehiclemodelstatus() {
		return nvehiclemodelstatus;
	}
	public void setNvehiclemodelstatus(BigDecimal nvehiclemodelstatus) {
		this.nvehiclemodelstatus = nvehiclemodelstatus;
	}
	
	@Column(name = "dtstart") 
	public String getDtstart() {
		return dtstart;
	}
	public void setDtstart(String dtstart) {
		this.dtstart = dtstart;
	}
	
	@Column(name = "dtend") 
	public String getDtend() {
		return dtend;
	}
	public void setDtend(String dtend) {
		this.dtend = dtend;
	}
	
	@Column(name = "nidv") 
	public BigDecimal getNidv() {
		return nidv;
	}
	public void setNidv(BigDecimal nidv) {
		this.nidv = nidv;
	}
	
	@Column(name = "nvehiclesellingprice") 
	public BigDecimal getNvehiclesellingprice() {
		return nvehiclesellingprice;
	}
	public void setNvehiclesellingprice(BigDecimal nvehiclesellingprice) {
		this.nvehiclesellingprice = nvehiclesellingprice;
	}
	
	@Column(name = "nvehiclechassisprice") 
	public BigDecimal getNvehiclechassisprice() {
		return nvehiclechassisprice;
	}
	public void setNvehiclechassisprice(BigDecimal nvehiclechassisprice) {
		this.nvehiclechassisprice = nvehiclechassisprice;
	}
	
	@Column(name = "nlocationexshowroomprice") 
	public BigDecimal getNlocationexshowroomprice() {
		return nlocationexshowroomprice;
	}
	public void setNlocationexshowroomprice(BigDecimal nlocationexshowroomprice) {
		this.nlocationexshowroomprice = nlocationexshowroomprice;
	}
	
	@Column(name = "dtcreated") 
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby") 
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated") 
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby") 
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	//@Column(name = "strbodytypedesc")
}

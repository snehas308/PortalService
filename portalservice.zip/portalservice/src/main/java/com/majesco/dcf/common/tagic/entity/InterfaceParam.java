package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dcf_interface_m")
public class InterfaceParam implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1480681584439282697L;
	
	private long seqid;
	private String strinterfaceid;
	private String strwsdlurl;
	private String strurl;
	private String dtcreated;
	private String createdby;
	private String dtupdated;
	private String updatedby;
	
	
	@Id
	@Column(name = "seqid")
	public long getSeqid() {
		return seqid;
	}
	public void setSeqid(long seqid) {
		this.seqid = seqid;
	}
	
	
	@Column(name = "strinterfaceid")
	public String getStrinterfaceid() {
		return strinterfaceid;
	}
	public void setStrinterfaceid(String strinterfaceid) {
		this.strinterfaceid = strinterfaceid;
	}
	
	
	@Column(name = "strwsdlurl")
	public String getStrwsdlurl() {
		return strwsdlurl;
	}
	public void setStrwsdlurl(String strwsdlurl) {
		this.strwsdlurl = strwsdlurl;
	}
	
	
	@Column(name = "strurl")
	public String getStrurl() {
		return strurl;
	}
	public void setStrurl(String strurl) {
		this.strurl = strurl;
	}
	
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	
	@Column(name = "createdby")
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	
	@Column(name = "updatedby")
	public String getUpdatedby() {
		return updatedby;
	}
	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}
	

}

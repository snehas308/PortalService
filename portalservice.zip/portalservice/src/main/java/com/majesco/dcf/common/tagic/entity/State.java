package com.majesco.dcf.common.tagic.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
//@Table(name = "dcf_state_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_state_m")							// Added for Oracle Migration
public class State {

	private String strstatecd;
	private String strstatename;
	private String strcountrycd;
	private Integer ncrestaid;
	private String strdisplaystatecd;
	private String strregioncd;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	
	
	@Id
	@Column(name = "strstatecd")
	public String getStrstatecd() {
		return strstatecd;
	}
	public void setStrstatecd(String strstatecd) {
		this.strstatecd = strstatecd;
	}
	
	
	@Column(name = "strstatename")
	public String getStrstatename() {
		return strstatename;
	}
	public void setStrstatename(String strstatename) {
		this.strstatename = strstatename;
	}
	
	
	@Column(name = "strcountrycd")
	public String getStrcountrycd() {
		return strcountrycd;
	}
	public void setStrcountrycd(String strcountrycd) {
		this.strcountrycd = strcountrycd;
	}
	
	
	@Column(name = "ncrestaid")
	public Integer getNcrestaid() {
		return ncrestaid;
	}
	public void setNcrestaid(Integer ncrestaid) {
		this.ncrestaid = ncrestaid;
	}
	
	
	@Column(name = "strdisplaystatecd")
	public String getStrdisplaystatecd() {
		return strdisplaystatecd;
	}
	public void setStrdisplaystatecd(String strdisplaystatecd) {
		this.strdisplaystatecd = strdisplaystatecd;
	}
	
	
	@Column(name = "strregioncd")
	public String getStrregioncd() {
		return strregioncd;
	}
	public void setStrregioncd(String strregioncd) {
		this.strregioncd = strregioncd;
	}
	
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}	
}

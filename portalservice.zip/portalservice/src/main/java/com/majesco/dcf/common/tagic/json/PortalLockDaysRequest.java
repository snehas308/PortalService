package com.majesco.dcf.common.tagic.json;

import java.util.HashMap;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PortalLockDaysRequest extends UserObject{
	
	private HashMap<String, String> minPayDatesMap;
	private String officeCode;

	public String getOfficeCode() {
		return officeCode;
	}

	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}

	public HashMap<String, String> getMinPayDatesMap() {
		return minPayDatesMap;
	}

	public void setMinPayDatesMap(HashMap<String, String> minPayDatesMap) {
		this.minPayDatesMap = minPayDatesMap;
	}
	
}

package com.majesco.dcf.common.tagic.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.json.PreInspectionDetailsRequest;
import com.majesco.dcf.common.tagic.json.PreInspectionDetailsResponse;
import com.majesco.dcf.usermgmt.json.SecurityQuestion;

@Service
public class PreInspectionAgencyDetailsService {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(PreInspectionAgencyDetailsService.class);
	
	@SuppressWarnings({ "null", "unchecked" })
	public ArrayList<PreInspectionDetailsResponse> fetchPreInspectionAgencyDetails(PreInspectionDetailsRequest modelreq) throws Exception
	{
		
		ArrayList<PreInspectionDetailsResponse> lstmodelres = new ArrayList<PreInspectionDetailsResponse>();
		int i = 0;
		try
		{
		
			logger.info("In PreInspectionAgencyDetailsService.fetchPreInspectionAgencyDetails() Method Begin()...");
			
			ObjectMapper objMap = new ObjectMapper();
			//ArrayList<Object[]> resultList = new ArrayList<Object[]>();
			
			List resultList =  dbserv.getPreInspectionAgencyDetails(Integer.parseInt(modelreq.getOfficeCode()));
			
			logger.info("In PreInspectionAgencyDetailsService.fetchPreInspectionAgencyDetails() :: resultMap : "+objMap.writeValueAsString(resultList));
			
			if (resultList!=null && !resultList.isEmpty()){
				Iterator iterator = resultList.iterator();
				if(iterator!=null){
					HashMap<String, String> resultMap =new HashMap<String, String>();
					while (iterator.hasNext()){
						
						resultMap=(HashMap)iterator.next();
						PreInspectionDetailsResponse modelres = new PreInspectionDetailsResponse();
						if(resultMap!=null){
							modelres.setStremailid((String) nullCheckString(resultMap.get("stremail_id")));
							modelres.setStrfirstescalationemailid((String) nullCheckString(resultMap.get("strfirstescalationemail_id")));
							modelres.setStrfirstescalationmobno((String) nullCheckString(resultMap.get("strfirstescalationmob_no")));
							modelres.setStrinspectionagencycd((String) nullCheckString(resultMap.get("strinspectionagency_cd")));
							modelres.setStrinspectionagencyname((String) nullCheckString(resultMap.get("strinspectionagency_name")));
							modelres.setStrlandlineno((String) nullCheckString(resultMap.get("strlandline_no")));
							modelres.setStrmobileno((String) nullCheckString(resultMap.get("strmobile_no")));
							modelres.setStrsecondescalationemailid((String) nullCheckString(resultMap.get("strsecondescalationemail_id")));
							modelres.setStrsecondescalationmobno((String) nullCheckString(resultMap.get("strsecondescalationmob_no")));
						}
						
						lstmodelres.add(modelres);
					}
						
				}
			}
			
			/*for(Object[] resultObj : resultMap){
				
				logger.info("In PreInspectionAgencyDetailsService.fetchPreInspectionAgencyDetails() :: $$$$$$$ i : "+i);
				modelres.setStremailid((String) nullCheckString(resultObj[2]));
				modelres.setStrfirstescalationemailid((String) nullCheckString(resultObj[5]));
				modelres.setStrfirstescalationmobno((String) nullCheckString(resultObj[6]));
				modelres.setStrinspectionagencycd((String) nullCheckString(resultObj[0]));
				modelres.setStrinspectionagencyname((String) nullCheckString(resultObj[1]));
				modelres.setStrlandlineno((String) nullCheckString(resultObj[4]));
				modelres.setStrmobileno((String) nullCheckString(resultObj[3]));
				modelres.setStrsecondescalationemailid((String) nullCheckString(resultObj[7]));
				modelres.setStrsecondescalationmobno((String) nullCheckString(resultObj[8]));
				
				logger.info("In PreInspectionAgencyDetailsService.fetchPreInspectionAgencyDetails() :: modelres : "+objMap.writeValueAsString(modelres));
				
				lstmodelres.add(modelres);
			}*/
			
			logger.info("In PreInspectionAgencyDetailsService.fetchPreInspectionAgencyDetails() :: Response JSON : "+objMap.writeValueAsString(lstmodelres));
			
			//return lstmodelres;
		}
		catch(Exception e)
		{
			logger.error("Exception StackTrace: ", e);
			e.printStackTrace();
			logger.info("Exception occured: " + e.toString());
		}
		logger.info("In PreInspectionAgencyDetailsService.fetchPreInspectionAgencyDetails() Method End()...");
		
		return lstmodelres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(Object obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }


}

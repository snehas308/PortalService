package com.majesco.dcf.common.tagic.json;

public class BankDetails {

	
private String 	nameasinBankAccount;
private String 	bankName;
private String 	branchName;
private String 	accountNumber;
/*private String 	MICRCode;
private String 	IFSCCode;*/
private String 	micrcode;
private String 	ifsccode;

public String getNameasinBankAccount() {
	return nameasinBankAccount;
}
public void setNameasinBankAccount(String nameasinBankAccount) {
	this.nameasinBankAccount = nameasinBankAccount;
}
public String getBankName() {
	return bankName;
}
public void setBankName(String bankName) {
	this.bankName = bankName;
}
public String getBranchName() {
	return branchName;
}
public void setBranchName(String branchName) {
	this.branchName = branchName;
}
public String getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}
/*public String getMICRCode() {
	return MICRCode;
}
public void setMICRCode(String mICRCode) {
	MICRCode = mICRCode;
}
public String getIFSCCode() {
	return IFSCCode;
}
public void setIFSCCode(String iFSCCode) {
	IFSCCode = iFSCCode;
}*/

public String getIfsccode() {
	return ifsccode;
}
public String getMicrcode() {
	return micrcode;
}
public void setMicrcode(String micrcode) {
	this.micrcode = micrcode;
}
public void setIfsccode(String ifsccode) {
	this.ifsccode = ifsccode;
}

	
}

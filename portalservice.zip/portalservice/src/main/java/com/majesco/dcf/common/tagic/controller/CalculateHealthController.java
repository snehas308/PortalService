package com.majesco.dcf.common.tagic.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.majesco.dcf.common.tagic.json.CalculateHealthRequest;
import com.majesco.dcf.common.tagic.json.CalculateHealthResponse;
import com.majesco.dcf.common.tagic.service.CalculateHealthService;
import com.majesco.dcf.common.tagic.service.DBService;


@Controller
@RequestMapping(value="/QuickQuote")
public class CalculateHealthController {
	
	@Autowired
	CalculateHealthService quickQuote;
	
	final static Logger logger = Logger.getLogger(CalculateHealthController.class);
	
	@RequestMapping(value="/fetchMovementData1/", method = RequestMethod.POST)
	@ResponseBody	
	public CalculateHealthResponse fetchQuote(@RequestBody CalculateHealthRequest movBase,HttpServletRequest httpServletRequest) throws Exception
	{	
			 								
		logger.info("Inside CalculateHealthController :: fetchQuote method :: Execution Started");
		
		CalculateHealthResponse result = quickQuote.getQuote(movBase);
		
		logger.info("Inside CalculateHealthController :: fetchQuote method :: Execution Completed Successfully");
					
		return result;
	}
	

}

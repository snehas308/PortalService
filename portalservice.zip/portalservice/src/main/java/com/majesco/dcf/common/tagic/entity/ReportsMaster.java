package com.majesco.dcf.common.tagic.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_reports_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_reports_m")								// Added for Oracle Migration
public class ReportsMaster {
	private Integer nrepid;
	private String strrepname;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	
	private Integer nisactive;

	@Id
	@Column(name = "nrepid")
	public Integer getNrepid() {
		return nrepid;
	}
	public void setNrepid(Integer nrepid) {
		this.nrepid = nrepid;
	}
	
	@Column(name = "strrepname")
	public String getStrrepname() {
		return strrepname;
	}
	public void setStrrepname(String strrepname) {
		this.strrepname = strrepname;
	}
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}

	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
}

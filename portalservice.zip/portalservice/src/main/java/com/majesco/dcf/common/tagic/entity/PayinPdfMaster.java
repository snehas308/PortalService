package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "dcf_payinslip_pdf_mst")
public class PayinPdfMaster implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3352254201930567934L;

	@Id	
	@Column(name = "depositslipno")
	private String depositslipno;
	
	@Column(name = "payinpdf")
	@Type(type="text")
	private String payinpdf;
		
	@Column(name = "dtcreated" )
	private Date dtcreated;
			
	@Column(name = "createdby")
	private String createdby;

	public String getDepositslipno() {
		return depositslipno;
	}

	public void setDepositslipno(String depositslipno) {
		this.depositslipno = depositslipno;
	}

	public String getPayinpdf() {
		return payinpdf;
	}

	public void setPayinpdf(String payinpdf) {
		this.payinpdf = payinpdf;
	}

	public Date getDtcreated() {
		return dtcreated;
	}

	public void setDtcreated(Date dtcreated) {
		this.dtcreated = dtcreated;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
		
	
}

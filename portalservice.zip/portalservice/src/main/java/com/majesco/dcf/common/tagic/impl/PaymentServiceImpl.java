package com.majesco.dcf.common.tagic.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer; // 3299
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.billdesk.pgidsk.PGIUtil;
import com.google.gson.Gson;
import com.majesco.dcf.common.tagic.entity.OnlineAccountService;
import com.majesco.dcf.common.tagic.entity.PaymentDetails;
import com.majesco.dcf.common.tagic.entity.PmtFlowFlags;
import com.majesco.dcf.common.tagic.entity.SelfPaymentEntiry;
import com.majesco.dcf.common.tagic.json.CPIPaymentResponse;
import com.majesco.dcf.common.tagic.json.CommunicationRequest;
import com.majesco.dcf.common.tagic.json.EmailAttachment;
import com.majesco.dcf.common.tagic.json.ProposalStatus;
import com.majesco.dcf.common.tagic.json.ProposalStatusReq;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.PaymentService;
import com.majesco.dcf.common.tagic.service.TagicCommonService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationLiteService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;
import com.majesco.dcf.common.tagic.util.CommonHelper;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.covernote.json.CNFlagProposalResponse;
import com.majesco.dcf.covernote.json.CheckCNFlagForProposal;
import com.majesco.dcf.covernote.service.WcfGCIntegrationService;
import com.majesco.dcf.pg.billdesk.service.BilldeskService;
import com.majesco.dcf.pg.entity.PGTransaction;
import com.majesco.dcf.pg.upi.entity.UpiTransactionDtl; //1266
import com.majesco.dcf.pg.upi.json.UpiTransactionRequest; //1266
import com.majesco.dcf.pg.util.PGConstants;
import com.majesco.dcf.receipt.handler.ReceiptSelfPayLinkHandler;
import com.majesco.dcf.receipt.handler.ReceiptSelfPayLinkHandlerForLiteService;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyResponse;
import com.majesco.dcf.receipt.json.ReceiptPaymentDetails;
import com.majesco.dcf.receipt.service.ReceiptService;
import com.majesco.dcf.receipt.util.ReceiptConstants;

@Service
@Transactional
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	BilldeskService billdeskService;
	
	@Autowired
	DBService dbService;
	
	@Autowired
	ReceiptService receiptService;
	
	@Autowired
	TagicCommunicationService tagicCommunicationService;
	
	@Autowired
	WcfGCIntegrationService wcfGCIntegrationService;
	
	@Autowired
	TagicCommonService comServ; //1845
	
	final static Logger logger = Logger.getLogger(PaymentServiceImpl.class);
	
//Start: <Production 1571, 1665>| code changes done for online payment option for producer
	@Value("${billdesk_Key}")
	private String billdesk_Key;
	//End: <Production 1571, 1665>| code changes done for online payment option for producer
	@Override
	public Map<String, String> verifyBilldeskTrans(String msg) throws Exception {
		
		Map<String, String> mapVal = new HashMap<String, String>();
		try{
			mapVal = billdeskService.validateBillDeskTrans(msg);
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return mapVal;
	}
	
	// This method gets invoked from billdesk on OL transaction Type
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, String> billdeskResponse(String msg) throws Exception {
		
		Map<String, String> mapVal = new HashMap<String, String>();
		Map<String, String> responseVal = new HashMap<String, String>();
		ReceiptCumPolicyRequest accountServReq =null;
		ReceiptCumPolicyResponse receiptResponse=null;
		ReceiptPaymentDetails paymentDtl = new ReceiptPaymentDetails();
		List<ReceiptPaymentDetails> lstPaymentDtl = new ArrayList<ReceiptPaymentDetails>();
		Gson gson = new Gson();
		String accountServiceJSON = null;
		HashMap<String,String> resultVal = new HashMap<String,String>();
		HashMap<String,String> resultAccService = new HashMap<String,String>();
		ObjectMapper objMapper = new ObjectMapper();
		CommonHelper helper = new CommonHelper();
		double sentAmtToBilldesk = 0;
		PGTransaction transaction = new PGTransaction();
		
		try{
			logger.debug("Inside PaymentServiceImpl.billdeskResponse method.. ");
			
			
			/*//Start| RahulT <VAPT comment>| code added to validate billdesk transaction at portal level
			//mapVal = billdeskService.validateBillDeskTrans(msg);
			String val[] = msg.split("\\|");
			String orderID = val[1];
			String transRefNo = val[2];
			String bankRefNo = val[3];
			String txnAmount = val[4];
			String txnDate = val[13];
			String Status = val[14];
			String errorDesc = val[24];
			String checksumRes = val[25];
				
			String tranStatus = PGConstants.STATUS_FAILURE;
			String withoutCheckSumURL = msg.substring(0,msg.lastIndexOf(PGConstants.PIPE_SEPARATOR));

			String chksumCalc = PGIUtil.doDigest(withoutCheckSumURL, billdesk_Key);		//<Production 1571, 1665>
*/				
			
			//Start:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
			
			String orderID = null;
			String transRefNo = null;
			String bankRefNo = null;
			String txnAmount = null;
			String txnDate = null;
			String Status = null;
			String errorDesc = null;
			String checksumRes = null;
			String tranStatus = null;
			String chksumCalc = null;
			
			int pgFlagVal = 0;	
			String pgFlag = dbService.getConfigParamVal(CommonConstants.PG_REDIRECT_FLAG);
			pgFlagVal = Integer.parseInt(pgFlag);
			if (pgFlagVal == 1) {
				logger.info("Inside PaymentServiceImpl::: selfPayResponse::: message String received from CPI-->"+msg);
				String strCPIResp = decrypt(msg);
				logger.info("Inside PaymentServiceImpl::: selfPayResponse::: message String decrypt from CPI response-->"+strCPIResp);
				
				msg = strCPIResp;
				CPIPaymentResponse cpiRespObj = new CPIPaymentResponse();
				cpiRespObj = gson.fromJson(strCPIResp, CPIPaymentResponse.class);
				logger.info("Inside PaymentServiceImpl::: selfPayResponse::: CPIPaymentResponse-->"+objMapper.writeValueAsString(cpiRespObj));
				
				orderID = cpiRespObj.getConsumerAppId();
				transRefNo = cpiRespObj.getPgiTransactionid();
				bankRefNo = cpiRespObj.getBankId();
				txnAmount = cpiRespObj.getPremiumAmount();
				//txnDate = cpiRespObj.get;
				Status = cpiRespObj.getResponseCode();
				errorDesc = cpiRespObj.getResponseDescription();
				//checksumRes = val[25];
				tranStatus = PGConstants.STATUS_FAILURE;
				
			} else {
				
				String withoutCheckSumURL = msg.substring(0,msg.lastIndexOf(PGConstants.PIPE_SEPARATOR));
				
				logger.info("withoutCheckSumURL--> "+withoutCheckSumURL);
				
				String val[] = msg.split("\\|");
				orderID = val[1];
				transRefNo = val[2];
				bankRefNo = val[3];
				txnAmount = val[4];
				txnDate = val[13];
				Status = val[14];
				errorDesc = val[24];
				checksumRes = val[25];
					
				tranStatus = PGConstants.STATUS_FAILURE;
				//String withoutCheckSumURL = msg.substring(0,msg.lastIndexOf(PGConstants.PIPE_SEPARATOR));
				chksumCalc = PGIUtil.doDigest(withoutCheckSumURL, billdesk_Key);
				
				logger.info("chksumCalc--> "+chksumCalc+", checksumRes-->"+checksumRes);
				
			}
			//End:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
			DateFormat formatter = new SimpleDateFormat(PGConstants.DATEFORMAT_BILLDESK); 
			Date dtUpdated = (Date) formatter.parse(txnDate);
			sentAmtToBilldesk = dbService.getBilldeskTransData(orderID);
			double receivedAmtFromBilldesk = Double.valueOf(txnAmount).doubleValue();
			
			logger.info("receivedAmtFromBilldesk--> "+receivedAmtFromBilldesk+", sentAmtToBilldesk-->"+sentAmtToBilldesk);
			
			if(receivedAmtFromBilldesk == sentAmtToBilldesk && chksumCalc.equals(checksumRes)){
				logger.info("billdesk received & sent amount values are same! ");
				if (PGConstants.PG_RES_SUCCESS.equals(Status)) {
					transaction.setTxnStatus(PGConstants.STATUS_SUCCESS);
					tranStatus = PGConstants.STATUS_SUCCESS;
				} 
				//Start:<YogeshM>:<16/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration:- To Handle CPI response>
				else if (PGConstants.CPI_RES_SUCCESS.equals(Status)) 
				{
					transaction.setTxnStatus(PGConstants.STATUS_SUCCESS);
					tranStatus = PGConstants.STATUS_SUCCESS;
				}
				//End:<YogeshM>:<16/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration:- To Handle CPI response>
				else {
					transaction.setTxnStatus(PGConstants.STATUS_FAILURE);
				}
				transaction.setScreenRefNo(orderID);
				transaction.setPgTxnRefNo(transRefNo);
				transaction.setPgBankRefNo(bankRefNo);
				transaction.setPgAuthStatus(Status);
				transaction.setPgErrorDesc(errorDesc);
				transaction.setPgMsg(msg);
				transaction.setUpdatedBy(PGConstants.PG_RESPONSE);
				transaction.setUpdatedDt(dtUpdated);
				transaction.setTxnStatus(tranStatus);
				dbService.updateBilldeskTxn(transaction);
				logger.info("updated billdesk transaction table successfully..");
			}
			/*String Status = (String)mapVal.get("Status");
			String orderID = (String)mapVal.get("screenRefNo");
			String transRefNo = (String)mapVal.get("TxnReferenceNo");
			String bankRefNo = (String)mapVal.get("BankReferenceNo");
			String txnDate = (String)mapVal.get("TxnDate");
			String txnAmount = (String)mapVal.get("TxnAmount");
			String errorDesc = (String)mapVal.get("errorDesc");*/
			
			//End| RahulT <VAPT comment>| code added
			
			Object obj_OrderID = orderID;
			
			logger.debug("Inside PaymentServiceImpl.billdeskResponse method:: OrderID--> "+orderID);
			
			//if(Status!=null && Status.equalsIgnoreCase(CommonConstants.BILLDESK_SUCCESS)){
				resultVal = (HashMap<String,String>)dbService.getOLTransaction("com.majesco.dcf.pg.entity.PGTransaction","screenRefNo",orderID);
				
				String strPropNbr = (String) resultVal.get("txnmodeval")==null?"":resultVal.get("txnmodeval");
				String strTransCat = (String) resultVal.get("txnmode")==null?"":resultVal.get("txnmode");
				
				logger.debug("Inside PaymentServiceImpl.billdeskResponse method:: Proposal Number--> "+strPropNbr);
				
				
				resultAccService = (HashMap<String,String>)dbService.getBilldeskStgDtl("com.majesco.dcf.common.tagic.entity.OnlineAccountService","strOrderID",strPropNbr);
				
				logger.debug("Inside PaymentServiceImpl.billdeskResponse method:: HashMap Object --> "+objMapper.writeValueAsString(resultAccService));
				
				String strJsonObj = (String) resultAccService.get("func_get_online_acc_service_dtl")==null?"":resultAccService.get("func_get_online_acc_service_dtl");
				accountServReq = gson.fromJson(strJsonObj, ReceiptCumPolicyRequest.class);
				
				logger.debug("Inside PaymentServiceImpl.billdeskResponse method:: Json Object--> "+objMapper.writeValueAsString(accountServReq));
				double dTotalAmtPartPayment=0;
				String strTotalAmtPartPayment="";
				
				if (accountServReq!=null && accountServReq.getPaymentDetails()!=null ){
					for(int i=0;i<accountServReq.getPaymentDetails().size();i++){
						ReceiptPaymentDetails paymentDtls = new ReceiptPaymentDetails();
						paymentDtls = accountServReq.getPaymentDetails().get(i);	
						if (paymentDtls.getPaymentAmount()!=null && !paymentDtls.getPaymentAmount().equals("")){
							dTotalAmtPartPayment = dTotalAmtPartPayment + Double.valueOf(paymentDtls.getPaymentAmount()).doubleValue();								
						}
					}
					strTotalAmtPartPayment = new String(""+Math.round(dTotalAmtPartPayment));
				}
				
				for(int i=0;i<accountServReq.getPaymentDetails().size();i++)
				{
				
					logger.debug("Inside PaymentServiceImpl.billdeskResponse method..Before invoking account service, formed JSON Object--> "+ objMapper.writeValueAsString(accountServReq));
					
					if(accountServReq.getPaymentDetails().get(i)!=null && accountServReq.getPaymentDetails().get(i).getPaymentType()!=null
							&& accountServReq.getPaymentDetails().get(i).getPaymentType().equalsIgnoreCase("OL")){
						accountServReq.getPaymentDetails().get(i).setInstrumentNo(transRefNo);
					}
				}
				
				//Start:11/03/2017:Changes done for proposal with cover note handling
				if (accountServReq.getProposalDetails() != null
						&& accountServReq.getProposalDetails().getProposalNo() != null) {
					CheckCNFlagForProposal checkCNFlagForProposal = new CheckCNFlagForProposal();
					checkCNFlagForProposal.setProposalNo(accountServReq
							.getProposalDetails().getProposalNo());
					CNFlagProposalResponse cnFlagProposalResponse = wcfGCIntegrationService
							.isCoverNoteProposal(checkCNFlagForProposal);
					if (cnFlagProposalResponse != null && cnFlagProposalResponse.getCnFlag()!=null && cnFlagProposalResponse.getCnFlag().equalsIgnoreCase(CommonConstants.SUCCESS_STATUS)) {
						accountServReq
								.setIsCoverNoteProposal(cnFlagProposalResponse
										.getCnFlag());
					}else{
						accountServReq.setIsCoverNoteProposal(CommonConstants.FAILURE_STATUS);
					}
				}//End:11/03/2017:Changes done for proposal with cover note handling
				//Start: <Production 1571, 1665>| code changes done for online payment option for producer
				if (Status!=null && Status.equals(CommonConstants.BILLDESK_SUCCESS)){
				//if (Status!=null){
				receiptResponse = receiptService.createReceiptPolicy(accountServReq, true);
				
				logger.debug("Inside PaymentServiceImpl.billdeskResponse method..After invoking account service "+ objMapper.writeValueAsString(receiptResponse));
				}
				//End: <Production 1571, 1665>| code changes done for online payment option for producer
				
				// Added to invoke EMAIl & SMS on policy generation
				
				//Start: 27122016| Added to retrieve Email & mobile no of proposal owner
				String emailID = accountServReq.getProposalDetails().getEmailId();
				String mobileNo = accountServReq.getProposalDetails().getMobileNo();
				
				
		           if(accountServReq.getProposalDetails().getEmailId()!=null && !accountServReq.getProposalDetails().getEmailId().equals("")
		        		   && accountServReq.getIsCoverNoteProposal().equalsIgnoreCase(CommonConstants.FAILURE_STATUS) && receiptResponse!=null 
		        		   && receiptResponse.getPolicyNo()!=null && (accountServReq.getStrnewrenewflag()==null || !accountServReq.getStrnewrenewflag().equalsIgnoreCase("R"))){//Code Changes For <1526> | VishaJ | 04-Aug-2017   
		        	   try{
							CommunicationRequest commRequest = new CommunicationRequest();
							EmailAttachment attachment = new EmailAttachment(); 
							commRequest.setAlertType(CommonConstants.SEND_EMAIL);
							commRequest.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS);
							commRequest.setReceipient(accountServReq.getProposalDetails().getEmailId());
							commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequest.setParam2(receiptResponse.getPolicyNo());
							commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequest.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"":accountServReq.getProposalDetails().getPlanName());
							//Start: RahulT| commented based on Jaydeep's mail dated Wed 4/26/2017 4:07 PM
							//commRequest.setParam5(strTotalAmtPartPayment);
							commRequest.setParam5(accountServReq.getProposalDetails().getProposalAmount());
							//End: RahulT| commented based on Jaydeep's mail dated Wed 4/26/2017 4:07 PM
							commRequest.setParam6(accountServReq.getProducerName()); // producer name	<Production 1571, 1665>
							commRequest.setParam7(accountServReq.getProducerCode()); // producer code	<Production 1571, 1665>

							commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());
							commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
							commRequest.setParam10(orderID);
							commRequest.setParam11(transRefNo);	
							
							commRequest.setParam12(accountServReq.getProposalDetails().getCustomerName());
							commRequest.setParam13(txnAmount);
							commRequest.setParam14(receiptResponse.getPolicyNo());

							commRequest.setParam15(accountServReq.getProducerName());	//<Production 1571, 1665>

							commRequest.setParam16(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile());
							
							attachment.setCustomerID(accountServReq.getProposalDetails().getCustomerId()==null?"":accountServReq.getProposalDetails().getCustomerId());
							attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
							attachment.setProductCode(accountServReq.getProposalDetails().getProductCode()==null?"":accountServReq.getProposalDetails().getProductCode());
							attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate()==null?"":accountServReq.getProposalDetails().getProposalDate());
							attachment.setPolicyNumber(receiptResponse.getPolicyNo());
							attachment.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
							commRequest.setEmailAttachment(attachment);
							commRequest.setUserID(accountServReq.getUserID());
							commRequest.setPassword(accountServReq.getPassword());
							commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
							commRequest.setProducerEmail(accountServReq.getProducerEmail());
							tagicCommunicationService.sendCommunication(commRequest);
							logger.info("In IPAServiceImpl :: billdeskResponse method ::: Mail sent successfully to "+accountServReq.getProposalDetails().getEmailId());
						}
						catch(Exception e){
							e.printStackTrace();
						}
					
					if (accountServReq.getProposalDetails().getMobileNo()!=null && !accountServReq.getProposalDetails().getMobileNo().equals("")){
						try{
							//Start: changes done to set values for sms in fresh instance
							CommunicationRequest commRequestSMS = new CommunicationRequest();
							//End: changes done to set values for sms in fresh instance
							logger.info("In IPAServiceImpl :: billdeskResponse method ::: sending SMS to  "+ accountServReq.getProposalDetails().getMobileNo());
							commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS);
							commRequestSMS.setReceipient(accountServReq.getProposalDetails().getMobileNo());
							commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequestSMS.setParam2(txnAmount);
							commRequestSMS.setParam3(receiptResponse.getPolicyNo());
							commRequestSMS.setParam4(accountServReq.getProposalDetails().getEmailId());
							commRequestSMS.setParam5(accountServReq.getProducerName());		//<Production 1571, 1665>

							commRequestSMS.setParam6(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile());
							commRequestSMS.setUserID(accountServReq.getUserID());
							commRequestSMS.setPassword(accountServReq.getPassword());
							tagicCommunicationService.sendCommunication(commRequestSMS);
							logger.info("In IPAServiceImpl :: billdeskResponse method ::: SMS sent successfully to "+accountServReq.getProposalDetails().getMobileNo());
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					// Sending email & SMS to producer
					if (accountServReq.getProducerEmail()!=null && !accountServReq.getProducerEmail().equals("")){
						try{
							CommunicationRequest commRequestProducer = new CommunicationRequest();
							EmailAttachment attachmentProducer = new EmailAttachment();
							commRequestProducer.setAlertType(CommonConstants.SEND_EMAIL);
							commRequestProducer.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS_PRODUCER);
							commRequestProducer.setReceipient(accountServReq.getProducerEmail());	//Email
							commRequestProducer.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequestProducer.setParam2(receiptResponse.getPolicyNo());
							commRequestProducer.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequestProducer.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"":accountServReq.getProposalDetails().getPlanName());
							commRequestProducer.setParam5(accountServReq.getProposalDetails().getProposalAmount());
							commRequestProducer.setParam6(accountServReq.getProducerName());
							commRequestProducer.setParam7(accountServReq.getProducerCode());
							commRequestProducer.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
							commRequestProducer.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
							commRequestProducer.setParam10(orderID); 
							commRequestProducer.setParam11(transRefNo);	
							
							commRequestProducer.setParam12(accountServReq.getProducerName()== null?"":accountServReq.getProducerName());
							commRequestProducer.setParam13(receiptResponse.getPolicyNo());
							commRequestProducer.setParam14(accountServReq.getProposalDetails().getCustomerName());
							commRequestProducer.setParam15(accountServReq.getProposalDetails().getProposalAmount());
							commRequestProducer.setParam16(accountServReq.getProposalDetails().getProposalNo());	//<Production 1571, 1665>
							
							attachmentProducer.setPolicyNumber(receiptResponse.getPolicyNo());
							attachmentProducer.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
							attachmentProducer.setProductCode(accountServReq.getProposalDetails().getProductCode());
							attachmentProducer.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
							attachmentProducer.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
							commRequestProducer.setEmailAttachment(attachmentProducer);
							commRequestProducer.setUserID(accountServReq.getUserID());
							commRequestProducer.setPassword(accountServReq.getPassword());
							commRequestProducer.setProductCode(accountServReq.getProposalDetails().getProductCode());
							commRequestProducer.setProducerEmail(accountServReq.getProducerEmail());
							//tagicCommunicationService.sendCommunication(commRequestProducer);		//1703: RahulT
							logger.info("In IPAServiceImpl :: billdeskResponse method ::: Mail sent successfully to "+accountServReq.getProducerEmail());
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					if (accountServReq.getProducerMobile()!=null && !accountServReq.getProducerMobile().equals("")){
						try{
							//Start: changes done to set values for sms in fresh instance
							CommunicationRequest commRequestSMSProducer = new CommunicationRequest();
							//End: changes done to set values for sms in fresh instance
							logger.info("In IPAServiceImpl :: billdeskResponse method ::: sending SMS to  "+ accountServReq.getProducerMobile());
							commRequestSMSProducer.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMSProducer.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS_PRODUCER);
							commRequestSMSProducer.setReceipient(accountServReq.getProducerMobile());
							commRequestSMSProducer.setParam1(accountServReq.getProducerName()== null?"":accountServReq.getProducerName());
							commRequestSMSProducer.setParam2(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequestSMSProducer.setParam3(accountServReq.getProposalDetails().getCustomerName());
							commRequestSMSProducer.setParam4(accountServReq.getProposalDetails().getProposalNo()==null?"-": accountServReq.getProposalDetails().getProposalNo());
							commRequestSMSProducer.setParam5(receiptResponse.getPolicyNo());
							commRequestSMSProducer.setParam6(accountServReq.getProducerEmail()==null ?"":accountServReq.getProducerEmail()); 
							//tagicCommunicationService.sendCommunication(commRequestSMSProducer);		//1703: RahulT
							logger.info("In IPAServiceImpl :: billdeskResponse method ::: SMS sent successfully to "+accountServReq.getProducerMobile());
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
		        	   
		           }

		        //End: 27122016| Added to retrieve Email & mobile no of proposal owner
		           
		        //Start: Addded to trigger mail & sms for Renewal case
		           else if(accountServReq.getProposalDetails().getEmailId()!=null && !accountServReq.getProposalDetails().getEmailId().equals("")
		        		   && accountServReq.getIsCoverNoteProposal().equalsIgnoreCase(CommonConstants.FAILURE_STATUS) && receiptResponse!=null 
		        		   && receiptResponse.getPolicyNo()!=null && (accountServReq.getStrnewrenewflag()!=null && accountServReq.getStrnewrenewflag().equalsIgnoreCase("R"))){//Code Changes For <1526> | VishaJ | 04-Aug-2017
		        	   
		        	// code for sending communication for renewal cases.
							helper.sendCommunicationRenewalPolicy(accountServReq,receiptResponse, accountServReq.getProposalDetails().getProposalAmount(),tagicCommunicationService);
		        	   
		           }
		           
		        // Start| RahulT 15/03/2017| code added to send mail for cover note cases
	            	else if (accountServReq.getIsCoverNoteProposal()!=null && accountServReq.getIsCoverNoteProposal().equalsIgnoreCase(CommonConstants.SUCCESS_STATUS)
	            			&& receiptResponse!=null && receiptResponse.getPolicyNo()!=null && !receiptResponse.getPolicyNo().equals("")){
						
						if (emailID!=null && !emailID.equals("")){
						try{
							CommunicationRequest commRequest = new CommunicationRequest();
							EmailAttachment attachment = new EmailAttachment();
							commRequest.setAlertType(CommonConstants.SEND_EMAIL);
							commRequest.setEventType(CommonConstants.EVENT_OFFLINE_COVERNOTE_PAYMENT_SUCCESS);
							commRequest.setReceipient(emailID);	//Email
							commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequest.setParam2(accountServReq.getCoverNoteNumber());	// cover note number
							commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequest.setParam4(txnAmount);
							commRequest.setParam5(accountServReq.getProposalDetails().getCustomerName());
							commRequest.setParam6(accountServReq.getProposalDetails().getProposalAmount());
							commRequest.setParam7(accountServReq.getCoverNoteNumber());	// cover note number
							commRequest.setParam8(accountServReq.getProducerName());
							commRequest.setParam9(accountServReq.getProducerMobile()==null ?"-":accountServReq.getProducerMobile()); 
							
							attachment.setPolicyNumber(receiptResponse.getPolicyNo());
							attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
							attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
							attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
							attachment.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
							commRequest.setEmailAttachment(attachment);
							commRequest.setUserID(accountServReq.getUserID());
							commRequest.setPassword(accountServReq.getPassword());
							commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
							commRequest.setProducerEmail(accountServReq.getProducerEmail());
							tagicCommunicationService.sendCommunication(commRequest);
							logger.info("In ReceiptServiceImpl  ::: Mail sent successfully to "+emailID);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					if (mobileNo!=null && !mobileNo.equals("")){
						try{
							//Start: changes done to set values for sms in fresh instance
							CommunicationRequest commRequestSMS = new CommunicationRequest();
							//End: changes done to set values for sms in fresh instance
							logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
							commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMS.setEventType(CommonConstants.EVENT_OFFLINE_COVERNOTE_PAYMENT_SUCCESS);
							commRequestSMS.setReceipient(mobileNo);
							commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequestSMS.setParam2(strTotalAmtPartPayment);
							commRequestSMS.setParam3(accountServReq.getCoverNoteNumber());	// cover note number
							commRequestSMS.setParam4(accountServReq.getProducerName()==null?"-":accountServReq.getProducerName());
							commRequestSMS.setParam5(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile());
							tagicCommunicationService.sendCommunication(commRequestSMS);
							logger.info("In ReceiptServiceImpl method ::: SMS sent successfully to "+mobileNo);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
	            }
	            	//End| RahulT 15/03/2017| code added to send mail for cover note cases
		           
	            	else {
	    				if (emailID!= null && !emailID.equals("")){
	    					try{
	    						CommunicationRequest commRequest = new CommunicationRequest();
	    						EmailAttachment attachment = new EmailAttachment();
	    						commRequest.setAlertType(CommonConstants.SEND_EMAIL);
	    						commRequest.setEventType(CommonConstants.EVENT_PAYMENT_FAILED);
	    						commRequest.setReceipient(emailID);	//Email
	    						commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
	    						commRequest.setParam2(accountServReq.getProposalDetails().getProposalNo());
	    						commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
	    						commRequest.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"":accountServReq.getProposalDetails().getPlanName());
	    						commRequest.setParam5(accountServReq.getProposalDetails().getProposalAmount());
	    						commRequest.setParam6(accountServReq.getProducerName());
	    						commRequest.setParam7(accountServReq.getProducerCode());
	    						commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
	    						commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
	    						commRequest.setParam10(orderID); // Salutation followed by name & last name
	    						commRequest.setParam11(transRefNo);	// product code
	    						
	    						commRequest.setParam12(accountServReq.getProposalDetails().getCustomerName());	
	    						commRequest.setParam13(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
	    						commRequest.setParam14(accountServReq.getProducerName());
	    						commRequest.setParam15(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
	    						commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());	
	    						/*attachment.setPolicyNumber(receiptResponse.getPolicyNo());
	    						attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
	    						attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
	    						attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
	    						commRequest.setEmailAttachment(attachment);*/
	    						commRequest.setProducerEmail(accountServReq.getProducerEmail());
	    						tagicCommunicationService.sendCommunication(commRequest);
	    						logger.info("In PaymentServiceImpl.selfPayResponse method ::: Mail sent successfully to "+emailID);
	    					}
	    					catch(Exception e){
	    						e.printStackTrace();
	    					}
	    				}
	    				if (mobileNo!=null && !mobileNo.equals("")){
	    					try{
	    						//Start: changes done to set values for sms in fresh instance
	    						CommunicationRequest commRequestSMS = new CommunicationRequest();
	    						//End: changes done to set values for sms in fresh instance
	    						logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
	    						commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
	    						commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_FAILED);
	    						commRequestSMS.setReceipient(mobileNo);
	    						commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
	    						commRequestSMS.setParam2(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
	    						commRequestSMS.setParam3(orderID);
	    						commRequestSMS.setParam4(accountServReq.getProposalDetails().getProposalNo());
	    						commRequestSMS.setParam5(accountServReq.getProducerName());
	    						commRequestSMS.setParam6(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
	    						tagicCommunicationService.sendCommunication(commRequestSMS);
	    						logger.info("In PaymentServiceImpl.selfPayResponse method ::: SMS sent successfully to "+mobileNo);
	    					}
	    					catch(Exception e){
	    						e.printStackTrace();
	    					}
	    				}
	    				
	    				// sending mail & SMS to producer 
	    				if (accountServReq.getProducerEmail()!= null && !accountServReq.getProducerEmail().equals("")){
	    					try{
	    						CommunicationRequest commRequest = new CommunicationRequest();
	    						commRequest.setAlertType(CommonConstants.SEND_EMAIL);
	    						commRequest.setEventType(CommonConstants.EVENT_PAYMENT_FAILED_PRODUCER);
	    						commRequest.setReceipient(accountServReq.getProducerEmail());	//Email
	    						commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
	    						commRequest.setParam2(accountServReq.getProposalDetails().getProposalNo());
	    						commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
	    						commRequest.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"NA":accountServReq.getProposalDetails().getPlanName());
	    						commRequest.setParam5(accountServReq.getProposalDetails().getProposalAmount());
	    						commRequest.setParam6(accountServReq.getProducerName());
	    						commRequest.setParam7(accountServReq.getProducerCode());
	    						commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
	    						commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
	    						commRequest.setParam10(orderID); // Salutation followed by name & last name
	    						commRequest.setParam11(transRefNo);	// product code
	    						
	    						commRequest.setParam12(accountServReq.getProducerName()==null?"":accountServReq.getProducerName());	
	    						commRequest.setParam13(accountServReq.getProposalDetails().getCustomerName()== null ?"":accountServReq.getProposalDetails().getCustomerName());
	    						commRequest.setParam14(mobileNo);		
	    						commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
	    						commRequest.setProducerEmail(accountServReq.getProducerEmail());
	    						//tagicCommunicationService.sendCommunication(commRequest);		//1703: RahulT
	    						logger.info("In PaymentServiceImpl.selfPayResponse method ::: Mail sent successfully to producer on "+accountServReq.getProducerEmail());
	    					}
	    					catch(Exception e){
	    						e.printStackTrace();
	    					}
	    				}
	    				if (accountServReq.getProducerMobile()!=null && !accountServReq.getProducerMobile().equals("")){
	    					try{
	    						//Start: changes done to set values for sms in fresh instance
	    						CommunicationRequest commRequestSMS = new CommunicationRequest();
	    						//End: changes done to set values for sms in fresh instance
	    						logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ accountServReq.getProducerMobile());
	    						commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
	    						commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_FAILED_PRODUCER);
	    						commRequestSMS.setReceipient(accountServReq.getProducerMobile());
	    						commRequestSMS.setParam1(accountServReq.getProducerName()==null?"":accountServReq.getProducerName());
	    						commRequestSMS.setParam2(accountServReq.getProposalDetails().getCustomerName()== null ?"":accountServReq.getProposalDetails().getCustomerName());
	    						commRequestSMS.setParam3(accountServReq.getProposalDetails().getProposalNo());
	    						commRequestSMS.setParam4(orderID);
	    						commRequestSMS.setParam5(accountServReq.getProducerMobile());
	    						//tagicCommunicationService.sendCommunication(commRequestSMS);		//1703: RahulT
	    						logger.info("In PaymentServiceImpl.selfPayResponse method ::: SMS sent successfully to producer on "+accountServReq.getProducerMobile());
	    					}
	    					catch(Exception e){
	    						e.printStackTrace();
	    					}
	    				}

	            	}		//End of billdesk success loop	<Production 1571, 1665>

				accountServiceJSON = gson.toJson(receiptResponse);
				
				logger.debug("Inside PaymentServiceImpl.billdeskResponse method..Before converting object to string  "+ accountServReq);
				
				responseVal.put("jsonObj", accountServiceJSON);
				responseVal.put("status", Status);

			//}		<Production 1571, 1665>
	            
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return responseVal;
	}

	@Override
	public String billdeskPaymentRequest(String orderID, String transAmt,
			String userId, String txnMode, String propNumber,
			String productCode, String producerCode, String transType, String isRenew) //<YogeshM>:<18/04/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration - added isRenew flag>
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		String strMsg = null;
		OnlineAccountService onlineEntity = null;
		int pgFlagVal = 0;	//<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
		
		try {
			//onlineEntity = this.getBilldeskData(propNumber);
			//dbService.saveOrUpdate(onlineEntity);
			//Start : 3299 : Code added for Handling of / issue of URL
			if (propNumber!=null && !propNumber.equals(CommonConstants.BLANK_STRING)){
				logger.debug("PaymentSeviceImpl Main String: "+propNumber);
				StringTokenizer stringTokenizer  = new StringTokenizer(propNumber,"|");	
				List<String> alParam = new ArrayList<String>();
				String strproposalNo = "";
				String strCustomerName = "";
			 	while(stringTokenizer.hasMoreTokens()){
			 		alParam.add(stringTokenizer.nextToken()) ;
				}
			 	
			 	logger.debug("List items - "+alParam);
			 	if (alParam!=null && !alParam.isEmpty()){
			 		int listSize = alParam.size();			 		
			 		strproposalNo = alParam.get(0);
			 		
			 		if(listSize>1)
			 			strCustomerName = alParam.get(1);
			 	}
			 		
			 	logger.debug("PaymentSeviceImpl Proposal Number: "+strproposalNo+" Of customer name Before- "+strCustomerName);
			 	strCustomerName = strCustomerName.replace("$", "/");
			 	logger.debug("PaymentSeviceImpl Proposal Number: "+strproposalNo+" Of customer name After- "+strCustomerName);
			 	propNumber = strproposalNo + "|" + strCustomerName;
			 	logger.debug("PaymentSeviceImpl Main String After: "+propNumber);
			}			 
			//End : 3299 : Code added for Handling of / issue of URL
			//strMsg = billdeskService.generateBillDeskPayURL(orderID, transAmt,userId,
			//		txnMode, propNumber, productCode,producerCode,transType);			//Commented for DefectID-3332 CPI
			
			
			//Start:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
			String pgFlag = dbService.getConfigParamVal(CommonConstants.PG_REDIRECT_FLAG);
			pgFlagVal = Integer.parseInt(pgFlag);
			
			if (pgFlagVal == 1) {
				strMsg = billdeskService.generateCPIPayURL(orderID, transAmt,userId, txnMode, propNumber, productCode,producerCode,transType,isRenew); //<YogeshM>:<18/04/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration - added isRenew flag>
			} else {
				strMsg = billdeskService.generateBillDeskPayURL(orderID, transAmt,userId, txnMode, propNumber, productCode,producerCode,transType);
			}
			logger.debug("PaymentSeviceImpl.billdeskPaymentRequest() :: strMsg: "+strMsg);
			//End:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
			
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strMsg;
	}

	@Override
	public String generateOrderID() throws Exception {
		
		String orderID = null; // SUCCESS/FAILURE
		try {
			//String currentDateInString = new SimpleDateFormat(CommonConstants.UNIQUE_SEQUENCE).format(new java.util.Date());
			//Start:-<YogeshM><06/12/2017><Defect-HotFixed><to get unique sequence of CHP in spl link>
			Long OrderSeq = dbService.getNextOrderSeq();	//To get nextSeq from DB
			String strOrderIdSeq = String.format("%09d", OrderSeq);	
			
			String currentDateInString = new SimpleDateFormat(CommonConstants.UNIQUE_SEQUENCE_PG).format(new java.util.Date());
			//orderID = CommonConstants.BILLDESK_PREFIX+currentDateInString;
			orderID = CommonConstants.BILLDESK_PREFIX+currentDateInString+OrderSeq.toString(); //CHP+currentDate-timestamp+OrderSeq
			//End:-<YogeshM><06/12/2017><Defect-HotFixed><to get unique sequence of CHP in spl link>
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return orderID;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map <String,String> getSelfPayURLDetails(String transactionID) throws Exception {
		
		Map requestSelfPayMap = new HashMap();
		Map <String,String> resultMap = new HashMap<String,String>();
		ObjectMapper objMapper = new ObjectMapper();
		HashMap<String,String>  resultAccService = new HashMap<String,String> ();
		Gson gson = new Gson();
		ReceiptCumPolicyRequest accountServReq = new ReceiptCumPolicyRequest(); 
		//Start: RahulT|1853
		ProposalStatusReq proposalStatRequest = new ProposalStatusReq();
		ProposalStatus proposalStatRes = new ProposalStatus(); 
		//End: RahulT|1853
		
		try{
			requestSelfPayMap = (HashMap<String,String>)dbService.getPayLinkDtl("com.majesco.dcf.common.tagic.entity.SelfPaymentEntiry", "transId", transactionID);
			logger.debug("Inside PaymentServiceImpl.getSelfPayURLDetails method:: HashMap Object --> "+objMapper.writeValueAsString(requestSelfPayMap));
					
			Date endDate = (Date) requestSelfPayMap.get("endtime");
			
				
			//resultAccService = (HashMap<String,String>)dbService.getBilldeskStgDtl("com.majesco.dcf.common.tagic.entity.OnlineAccountService","strOrderID",(String)requestSelfPayMap.get("proppolnbr"));
			resultAccService = (HashMap<String,String>)dbService.getBilldeskStgDtl("com.majesco.dcf.common.tagic.entity.OnlineAccountService","strOrderID",transactionID);
			
			logger.debug("Inside PaymentServiceImpl.getSelfPayURLDetails method:: HashMap Object --> "+objMapper.writeValueAsString(resultAccService));
				
			String strJsonObj = (String) resultAccService.get("func_get_online_acc_service_dtl")==null?"":resultAccService.get("func_get_online_acc_service_dtl");
			accountServReq = gson.fromJson(strJsonObj, ReceiptCumPolicyRequest.class);
				
			if (accountServReq!=null && accountServReq.getProposalDetails()!=null){
				resultMap.put("custName", accountServReq.getProposalDetails().getCustomerName());
				resultMap.put("productName", accountServReq.getProposalDetails().getProductLine());
				resultMap.put("planName", accountServReq.getProposalDetails().getPlanName());
				
				//Start:  <issue id 1911> | condition added to check vehRegNo
				
				if(accountServReq.getProposalDetails().getVehRegNo()!=null && !accountServReq.getProposalDetails().getVehRegNo().equals(CommonConstants.BLANK_STRING)){
					
					resultMap.put("vehRegNo", accountServReq.getProposalDetails().getVehRegNo());
				
				}else{
					
					resultMap.put("vehRegNo", CommonConstants.NOT_APPLICABLE_VAL);
				}
				
				resultMap.put("lobNo", accountServReq.getStrLOB());
			 
				logger.info("In getSelfPayURLDetails() :: vehRegNo :"+accountServReq.getProposalDetails().getVehRegNo()+"::and lobNo::"+accountServReq.getStrLOB());
				//End:  <issue id 1911> | condition added to check vehRegNo
			}
				
			resultMap.put("customerID", (String)requestSelfPayMap.get("customerid"));
			resultMap.put("proposalNo", (String)requestSelfPayMap.get("proppolnbr"));
			resultMap.put("transAmt", (String)requestSelfPayMap.get("transamount"));
			resultMap.put("productCd", (String)requestSelfPayMap.get("productcd"));
			resultMap.put("agentCode", (String)requestSelfPayMap.get("createdby"));
			resultMap.put("agentName", (String)requestSelfPayMap.get("producercd"));
			resultMap.put("agentName", (String)requestSelfPayMap.get("isrenew")); //<YogeshM>:<18/04/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration - added isRenew flag>
				

			/*
             * Start:RahulT <2350> | code commented to populate agent code instead of producer code
             * if (accountServReq!=null){
                             resultMap.put("agentCode", (String)accountServReq.getProducerCode());
             }*/

			if (requestSelfPayMap.get("paylinkused")!=null && requestSelfPayMap.get("paylinkused").equals("1")){
				resultMap.put("isError", "1");
				resultMap.put("messageDisplay", "Dear "+accountServReq.getProposalDetails().getCustomerName()+", You can not make payment for same transaction again.");
				return resultMap;
			}
			
			//resultMap.put("isError", "2"); // key changed by akshay for 3525 
			//resultMap.put("messageDisplay","Payment Link is valid till "+endDate);

			// Start : Code added for renewal 48 Hours validation 
			if(requestSelfPayMap.get("isrenew")!=null && requestSelfPayMap.get("isrenew").equals("R")){
				try{
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String createdDate =(String) requestSelfPayMap.get("dtcreated");
					logger.info("In getSelfPayURLDetails() :: createdDate String "+createdDate);
					Date dtCreated = format.parse(createdDate);
					logger.info("In getSelfPayURLDetails() :: dtCreated"+dtCreated);
					// Start :- <3330> : Change the renewal link validity back  to 24 hrs..
					//Start : <3343> : changes for checking prevPolicyDate eligibility
					/*dtCreated.setHours(00);
					dtCreated.setMinutes(00);
					dtCreated.setSeconds(00);*/
					dtCreated = getZeroTimeDate(dtCreated);
					logger.info("In getSelfPayURLDetails() :: dtCreated after setting time 00"+dtCreated);
					int renDayLimit =Integer.parseInt(dbService.getConfigParamVal(CommonConstants.RENEWAL_EXP_DAY_LIMIT));
					logger.info("In getSelfPayURLDetails() :: renDayLimit"+renDayLimit);
					Date addedDate = calculateDays(dtCreated, renDayLimit);
					logger.info("In getSelfPayURLDetails() :: "+renDayLimit+" days addedDate"+addedDate);
					// End :- <3330> : Change the renewal link validity back  to 24 hrs.					
					Date currentDate = new Date();
					logger.info("In getSelfPayURLDetails() :: Current Date"+currentDate);
					/*currentDate.setHours(00);
					currentDate.setMinutes(00);
					currentDate.setSeconds(00);*/
					currentDate = getZeroTimeDate(currentDate);
					logger.info("In getSelfPayURLDetails() :: Current Date after time 0"+currentDate);
					// End :- <3330> : Change the renewal link validity back  to 24 hrs. : 25-Jan-2018
					int res=addedDate.compareTo(currentDate);
					
					logger.info("In getSelfPayURLDetails() :: Result Of Comparison"+res);

					logger.info("In getSelfPayURLDetails() :: PrevPolEndDate"+accountServReq.getPrevPolEndDate());
					SimpleDateFormat format1 = new SimpleDateFormat("dd/MM/yyyy");
					Date expDate = format1.parse(accountServReq.getPrevPolEndDate());
					logger.info("In getSelfPayURLDetails() :: expDate"+expDate);
					/*expDate.setHours(00);
					expDate.setMinutes(00);
					expDate.setSeconds(00);*/
					expDate = getZeroTimeDate(expDate);
					int res1=expDate.compareTo(currentDate);
					logger.info("In getSelfPayURLDetails() :: Result Of Expiry Date Comparison"+res1);
					if(res < 0 || res1 < 0){
					//End : <3343> : changes for checking prevPolicyDate eligibility
						resultMap.put("isError", "1");
						resultMap.put("messageDisplay", "Sorry! Your payment link has expired. Please contact your agent for more details!");
					}	
				}catch(Exception e){
					logger.error("In getSelfPayURLDetails() :: Exception occured while Renewal Expiry Checnking",e);
					if(requestSelfPayMap.get("paylinkused")!=null && requestSelfPayMap.get("paylinkused").equals("2")){
						resultMap.put("isError", "1");
						resultMap.put("messageDisplay", "Sorry! Your payment link has expired. Please contact your agent for more details!");
					}
				}
							
				
			}else{			
				if(requestSelfPayMap.get("paylinkused")!=null && requestSelfPayMap.get("paylinkused").equals("2")){
					resultMap.put("isError", "1");
					resultMap.put("messageDisplay", "Sorry! Your payment link has expired. Please contact your agent for more details!");
				}
			}
			// End : Code added for renewal 48 Hours validation
			//Start: RahulT <Production1853> | code added to check proposal status before allowing online payment option
			proposalStatRequest.setProposalNo((String)requestSelfPayMap.get("proppolnbr"));
			proposalStatRequest.setProductCode((String)requestSelfPayMap.get("producercd"));
			proposalStatRes = comServ.getProposalStatus(proposalStatRequest);
			if(proposalStatRes!=null && proposalStatRes.getProposalStatus()!=null && !(proposalStatRes.getProposalStatus().equals("RCCN")||
					proposalStatRes.getProposalStatus().equals("NCCA")|| proposalStatRes.getProposalStatus().equals("RA")||proposalStatRes.getProposalStatus().equals("NA")
							|| proposalStatRes.getProposalStatus().equals("RCCA")|| proposalStatRes.getProposalStatus().equals("NCCN")|| proposalStatRes.getProposalStatus().equals("NPQC1")
							|| proposalStatRes.getProposalStatus().equals("NPQC2")|| proposalStatRes.getProposalStatus().equals("RPVI")
							|| proposalStatRes.getProposalStatus().equals("RPQC2")|| proposalStatRes.getProposalStatus().equals("NOPCN"))) {
				
				resultMap.put("isError", "1");
				resultMap.put("messageDisplay", "Sorry! Your Proposal status is not valid . Please contact your agent for more details!");
			}
			//End: RahulT <Production1853> | code added to check proposal status before allowing online payment option
						
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return resultMap;
		
	}

	// This method gets invoked from billdesk on SPL transaction Type
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, String> selfPayResponse(String msg) throws Exception {
		
		ReceiptCumPolicyRequest accountServReq =null;
		ReceiptCumPolicyResponse receiptResponse=null;
		Gson gson = new Gson();
		HashMap<String,String> resultAccService = new HashMap<String,String>();
		ObjectMapper objMapper = new ObjectMapper();
		String emailID= null;
		//String payAmount= "";
		String mobileNo = null;
		double sentAmtToBilldesk = 0;
		PGTransaction transaction = new PGTransaction();
		HashMap<String,String> mapVal = new HashMap<String, String>();
		double dTotalAmtPartPayment = 0;
		String strTotalAmtPartPayment = "";
		PaymentDetails payDtlsTrans = null;
		String splPaymentAmt = "";
		String instrumentDt = "";
		String instrumentNo = "";
		String paymentType = null;
		ArrayList lstPaymentTransDtls = new ArrayList();
		try{
			
			//Start| RahulT <VAPT comment>| code added to validate billdesk transaction at portal level
			logger.info("Inside PaymentServiceImpl::: selfPayResponse::: message String received from billdesk-->"+msg);
			//Start:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
			
			String orderID = null;
			String TransRefNbr = null;
			String bankRefNo = null;
			String txnAmount = null;
			String txnDate = null;
			String Status = null;
			String errorDesc = null;
			String checksumRes = null;
			String tranStatus = null;
			Date dtUpdated = null;
			String cpiTxId=null;
			int pgFlagVal = 0;	
			String pgFlag = dbService.getConfigParamVal(CommonConstants.PG_REDIRECT_FLAG);
			logger.debug("Inside PaymentServiceImpl.pgFlag>>>>>>> "+ pgFlag);
			pgFlagVal = Integer.parseInt(pgFlag);
			if (pgFlagVal == 1) {
				logger.info("Inside PaymentServiceImpl::: selfPayResponse::: message String received from CPI-->"+msg);
				String strCPIResp = decrypt(msg);
				logger.info("Inside PaymentServiceImpl::: selfPayResponse::: message String decrypt from CPI response-->"+strCPIResp);
				
				CPIPaymentResponse cpiRespObj = new CPIPaymentResponse();
				cpiRespObj = gson.fromJson(strCPIResp, CPIPaymentResponse.class);
				logger.info("Inside PaymentServiceImpl::: selfPayResponse::: CPIPaymentResponse-->"+objMapper.writeValueAsString(cpiRespObj));
				
				orderID = cpiRespObj.getConsumerAppTransId();
				TransRefNbr = cpiRespObj.getGatewayTxnid();
				cpiTxId=cpiRespObj.getPgiTransactionid();
				
				
				bankRefNo = cpiRespObj.getBankId();
				txnAmount = cpiRespObj.getPremiumAmount();
				//txnDate = cpiRespObj.get;
				Status = cpiRespObj.getResponseCode();
				errorDesc = cpiRespObj.getResponseDescription();
				//checksumRes = val[25];
				tranStatus = cpiRespObj.getTransactionStatus();
				
				DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY HH:mm:ss.SSS");
				Date date = new Date();
				txnDate =  dateFormat.format(date); //"14-04-2018 13:23:38";
				
//				DateFormat formatter = new SimpleDateFormat(PGConstants.DATEFORMAT_BILLDESK); 
//				dtUpdated = (Date) formatter.parse(txnDate);
				
			} else {
				
				String withoutCheckSumURL = msg.substring(0,msg.lastIndexOf(PGConstants.PIPE_SEPARATOR));
				
				logger.info("withoutCheckSumURL--> "+withoutCheckSumURL);
				
				String val[] = msg.split("\\|");
				orderID = val[1];
				TransRefNbr = val[2];
				bankRefNo = val[3];
				txnAmount = val[4];
				txnDate = val[13];
				Status = val[14];
				errorDesc = val[24];
				checksumRes = val[25];
					
				tranStatus = PGConstants.STATUS_FAILURE;
				//String withoutCheckSumURL = msg.substring(0,msg.lastIndexOf(PGConstants.PIPE_SEPARATOR));
				String chksumCalc = PGIUtil.doDigest(withoutCheckSumURL, billdesk_Key);
				
				logger.info("chksumCalc--> "+chksumCalc+", checksumRes-->"+checksumRes);
				
//				DateFormat formatter = new SimpleDateFormat(PGConstants.DATEFORMAT_BILLDESK); 
//				dtUpdated = (Date) formatter.parse(txnDate);
				
			}
			//End:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
			
			
			DateFormat formatter = new SimpleDateFormat(PGConstants.DATEFORMAT_BILLDESK); 
			//logger.info("dtUpdated--> " + txnDate);
			dtUpdated = (Date) formatter.parse(txnDate);
			sentAmtToBilldesk = dbService.getBilldeskTransData(orderID);
			double receivedAmtFromBilldesk = Double.valueOf(txnAmount).doubleValue();
			
			logger.info("receivedAmtFromBilldesk--> "+receivedAmtFromBilldesk+", sentAmtToBilldesk-->"+sentAmtToBilldesk);
			
			if(receivedAmtFromBilldesk == sentAmtToBilldesk){
				logger.info("billdesk received & sent amount values are same! ");
				if (PGConstants.PG_RES_SUCCESS.equals(Status)||"0".equals(Status)) {
					transaction.setTxnStatus(PGConstants.STATUS_SUCCESS);
					tranStatus = PGConstants.STATUS_SUCCESS;
				} else {
					tranStatus=tranStatus!=null? tranStatus:PGConstants.STATUS_FAILURE;
				}
				transaction.setScreenRefNo(orderID);
				transaction.setPgTxnRefNo(TransRefNbr);
				transaction.setPgBankRefNo(bankRefNo);
				transaction.setPgAuthStatus(Status);
				transaction.setPgErrorDesc(errorDesc);
				transaction.setPgMsg(msg);
				transaction.setUpdatedBy(PGConstants.PG_RESPONSE);
				transaction.setUpdatedDt(dtUpdated);
				transaction.setTxnStatus(tranStatus);
				transaction.setPgId(Integer.parseInt(cpiTxId==null?"0":cpiTxId));
				dbService.updateBilldeskTxn(transaction);
				logger.info("updated billdesk transaction table successfully..");
			}

			mapVal.put(PGConstants.SCREEN_REF_NO, orderID);
			mapVal.put(PGConstants.TRANS_REF_NO, TransRefNbr);
			mapVal.put(PGConstants.BANK_REF_NO, bankRefNo);
			mapVal.put(PGConstants.AUTH_STATUS, Status);
			mapVal.put(PGConstants.TRANS_DATE, txnDate);
			mapVal.put(PGConstants.ERROR_DESC, errorDesc);
			mapVal.put(PGConstants.TRANS_AMT, txnAmount);
			mapVal.put(CommonConstants.IS_ERROR_STRING, "0");  // 1825 : Vishal J : Code for sending 0 by default. Mentioning No GC Error. 
			
			/*String Status = (String)mapVal.get("Status");
			String orderID = (String)mapVal.get("screenRefNo");
			String TransRefNbr = (String)mapVal.get("TxnReferenceNo");
			String payAmount = (String)mapVal.get("TxnAmount");*/
			
			//End| RahulT <VAPT comment>| code added
			
			
			logger.debug("Inside PaymentServiceImpl.Status>>>>>>> "+ Status);
			logger.debug("Inside PaymentServiceImpl.selfPayResponse method:: OrderID--> "+orderID);		
			/*HashMap<String,String> resultVal = (HashMap<String,String>)dbService.getOLTransaction("com.majesco.dcf.pg.entity.PGTransaction","screenRefNo",orderID);
			
			String strPropNbr = (String) resultVal.get("txnmodeval")==null?"":resultVal.get("txnmodeval");*/
			resultAccService = (HashMap<String,String>)dbService.getBilldeskStgDtl("com.majesco.dcf.common.tagic.entity.OnlineAccountService","strOrderID",orderID);
			
			logger.debug("Inside PaymentServiceImpl.selfPayResponse method:: HashMap Object --> "+objMapper.writeValueAsString(resultAccService));
			
			String strJsonObj = (String) resultAccService.get("func_get_online_acc_service_dtl")==null?"":resultAccService.get("func_get_online_acc_service_dtl");
			accountServReq = gson.fromJson(strJsonObj, ReceiptCumPolicyRequest.class);
			
			if (accountServReq!=null && accountServReq.getProposalDetails()!=null ){
				logger.debug("Inside PaymentServiceImpl.selfPayResponse method..Before invoking account service "+ objMapper.writeValueAsString(accountServReq));
				mapVal.put("customerID", accountServReq.getProposalDetails().getCustomerId());
				mapVal.put("proposalDate", accountServReq.getProposalDetails().getProposalDate());
				mapVal.put("productCode", accountServReq.getProposalDetails().getProductCode());
				mapVal.put("proposalNo", accountServReq.getProposalDetails().getProposalNo());
				mapVal.put("producerCode", accountServReq.getProducerCode());
				mapVal.put("userId", accountServReq.getUserID());
				
				//setting unique transaction ID received from billdesk
				for (ReceiptPaymentDetails paymentDtl: accountServReq.getPaymentDetails()){
					if (paymentDtl.getPaymentType()!=null && paymentDtl.getPaymentType().contains("SPL")){ 
						paymentDtl.setInstrumentNo(TransRefNbr);
						if (Status!=null && Status.equals(CommonConstants.BILLDESK_SUCCESS)||Status.equals("0")){
						//if (Status!=null){
								// setting flag for Payment link used
								SelfPaymentEntiry selfPayEntity = new SelfPaymentEntiry();
								selfPayEntity.setTransId(orderID);
								selfPayEntity.setPayLinkUsed("1");
								dbService.markPayLinkUsed(orderID);
								
								ReceiptSelfPayLinkHandler handler = new ReceiptSelfPayLinkHandler();
								receiptResponse = handler.callReceiptCumPolicyProcess(accountServReq, dbService);
								logger.debug("Inside PaymentServiceImpl.selfPayResponse method..After invoking account service "+ objMapper.writeValueAsString(receiptResponse));
								
								if(receiptResponse!=null && receiptResponse.getPolicyNo()!=null){
									mapVal.put("policyNo", receiptResponse.getPolicyNo());
									if (receiptResponse.getReceiptDtls() != null)
										mapVal.put("receiptNo", receiptResponse.getReceiptDtls().getReceiptNo());
								}
						//}
						}
						emailID = paymentDtl.getEmailID();
						mobileNo = paymentDtl.getMobileNo();
						if (paymentDtl.getPaymentAmount()!=null && !paymentDtl.getPaymentAmount().equals("")){
							dTotalAmtPartPayment = dTotalAmtPartPayment + Double.valueOf(paymentDtl.getPaymentAmount()).doubleValue();								
						}
						
						instrumentDt = paymentDtl.getInstrumentDate();
						splPaymentAmt = paymentDtl.getPaymentAmount();
						instrumentNo = paymentDtl.getInstrumentNo();
						paymentType = paymentDtl.getPaymentType();
					}
										
				}
				
				strTotalAmtPartPayment = new String(""+Math.round(dTotalAmtPartPayment));
				
				//Start: RahulT<Production> 26/04/2017| data persisted into payment details table for the policy created through SPL payment mode
				SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
				payDtlsTrans = new PaymentDetails();
				payDtlsTrans.setStrpaymentmode(paymentType);
				payDtlsTrans.setStrpaymentamount(splPaymentAmt);
				//Start:03/05/2017:Modified to handle null / blank instrument date coming in request.
				if(instrumentDt==null || instrumentDt.equalsIgnoreCase(CommonConstants.BLANK_STRING))
					instrumentDt=sdf.format(new Date());
				//End:03/05/2017:Modified to handle null / blank instrument date coming in request.
				payDtlsTrans.setStrpaymentinstrumentdt(sdf.parse(instrumentDt));
				payDtlsTrans.setStrinstrumentno(instrumentNo);
				payDtlsTrans.setStripaddress(accountServReq.getSystemIPAddress());
				
				if(accountServReq.getProposalDetails()!=null)
				{
					payDtlsTrans.setStrproposalno(accountServReq.getProposalDetails().getProposalNo());
					payDtlsTrans.setStrcustid(accountServReq.getProposalDetails().getCustomerId());
					payDtlsTrans.setStrbalanceamt(accountServReq.getProposalDetails().getBalanceAmount());
					payDtlsTrans.setStrworkflowid(accountServReq.getProposalDetails().getProposalSystemId());
					
					if(accountServReq.getProposalDetails().getPolicyEffDt()!=null && !accountServReq.getProposalDetails().getPolicyEffDt().equals(""))
						payDtlsTrans.setStrpolicystartdt(sdf.parse(accountServReq.getProposalDetails().getPolicyEffDt()));
					else
						payDtlsTrans.setStrpolicystartdt(null);
					
					if(accountServReq.getProposalDetails().getPolicyEndDt()!=null && !accountServReq.getProposalDetails().getPolicyEndDt().equals(""))
						payDtlsTrans.setStrpolicyenddt(sdf.parse(accountServReq.getProposalDetails().getPolicyEndDt()));
					else
						payDtlsTrans.setStrpolicyenddt(null);
					
					payDtlsTrans.setStrproductcd(accountServReq.getProposalDetails().getProductCode());
					payDtlsTrans.setStrproducercd(accountServReq.getProducerCode());
					payDtlsTrans.setStrcreatedby(accountServReq.getProducerName());
					payDtlsTrans.setDtcreated(new Date());
					payDtlsTrans.setStrbusinessLocation(accountServReq.getProposalDetails().getBusinessLocation());
					payDtlsTrans.setStrdepositofficecode(accountServReq.getProposalDetails().getDepositOfficeCode());
					payDtlsTrans.setStrbusslocname(accountServReq.getProposalDetails().getBussLocName());
					payDtlsTrans.setStrnewrenewflag(accountServReq.getStrnewrenewflag()); // internal issues to save renewal flag in PaymentDetails. : Vishal J | 11-08-2017
				}
				
				//End: RahulT<Production> 26/04/2017| data persisted into payment details table for the policy created through SPL payment mode
				
				
				if (receiptResponse!=null && receiptResponse.getPolicyNo()!=null && Status!=null && Status.equals(CommonConstants.BILLDESK_SUCCESS)||Status.equals("0")){
				//if (receiptResponse!=null && receiptResponse.getPolicyNo()!=null && Status!=null){
					if (receiptResponse!=null && receiptResponse.getPolicyNo()!=null && Status!=null 
							 && accountServReq.getIsCoverNoteProposal().equalsIgnoreCase(CommonConstants.FAILURE_STATUS)){
						if (emailID!=null && !emailID.equals("")){
						try{
							CommunicationRequest commRequest = new CommunicationRequest();
							EmailAttachment attachment = new EmailAttachment();
							commRequest.setAlertType(CommonConstants.SEND_EMAIL);
							commRequest.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS);
							commRequest.setReceipient(emailID);	//Email
							commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequest.setParam2(receiptResponse.getPolicyNo());
							commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequest.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"NA":accountServReq.getProposalDetails().getPlanName());
							commRequest.setParam5(strTotalAmtPartPayment);
							commRequest.setParam6(accountServReq.getProducerName());
							commRequest.setParam7(accountServReq.getProducerCode());
							commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
							commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
							commRequest.setParam10(orderID); 
							commRequest.setParam11(TransRefNbr);	
							commRequest.setParam12(accountServReq.getProposalDetails().getCustomerName());
							//commRequest.setParam13(accountServReq.getProposalDetails().getProposalAmount());
							commRequest.setParam13(strTotalAmtPartPayment); //Start:15/04/2017:Changes done to set only the part payment amount as suggested by TAGIC
							commRequest.setParam14(receiptResponse.getPolicyNo());
							commRequest.setParam15(accountServReq.getProducerName());
							commRequest.setParam16(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
							
							attachment.setPolicyNumber(receiptResponse.getPolicyNo());
							attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
							attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
							attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
							attachment.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
							commRequest.setEmailAttachment(attachment);
							commRequest.setUserID(accountServReq.getUserID());
							commRequest.setPassword(accountServReq.getPassword());
							commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
							commRequest.setProducerEmail(accountServReq.getProducerEmail());
							tagicCommunicationService.sendCommunication(commRequest);
							logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: Mail sent successfully to "+emailID);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					if (mobileNo!=null && !mobileNo.equals("")){
						try{
							//Start: changes done to set values for sms in fresh instance
							CommunicationRequest commRequestSMS = new CommunicationRequest();
							//End: changes done to set values for sms in fresh instance
							logger.info("In IPAServiceImpl :: selfPayResponse method ::: sending SMS to  "+ mobileNo);
							commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS);
							commRequestSMS.setReceipient(mobileNo);
							commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequestSMS.setParam2(strTotalAmtPartPayment);
							commRequestSMS.setParam3(receiptResponse.getPolicyNo());
							commRequestSMS.setParam4(emailID);
							commRequestSMS.setParam5(accountServReq.getProducerName());
							commRequestSMS.setParam6(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
							tagicCommunicationService.sendCommunication(commRequestSMS);
							logger.info("In IPAServiceImpl :: selfPayResponse method ::: SMS sent successfully to "+mobileNo);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					// Sending email & SMS to producer
					if (accountServReq.getProducerEmail()!=null && !accountServReq.getProducerEmail().equals("")){
						try{
							CommunicationRequest commRequestProducer = new CommunicationRequest();
							EmailAttachment attachmentProducer = new EmailAttachment();
							commRequestProducer.setAlertType(CommonConstants.SEND_EMAIL);
							commRequestProducer.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS_PRODUCER);
							commRequestProducer.setReceipient(accountServReq.getProducerEmail());	//Email
							commRequestProducer.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequestProducer.setParam2(receiptResponse.getPolicyNo());
							commRequestProducer.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequestProducer.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"NA":accountServReq.getProposalDetails().getPlanName());
							commRequestProducer.setParam5(strTotalAmtPartPayment);
							commRequestProducer.setParam6(accountServReq.getProducerName());
							commRequestProducer.setParam7(accountServReq.getProducerCode());
							commRequestProducer.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
							commRequestProducer.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
							commRequestProducer.setParam10(orderID); 
							commRequestProducer.setParam11(TransRefNbr);	
							
							commRequestProducer.setParam12(accountServReq.getProducerName()== null?"":accountServReq.getProducerName());
							commRequestProducer.setParam13(receiptResponse.getPolicyNo());
							commRequestProducer.setParam14(accountServReq.getProposalDetails().getCustomerName());
							commRequestProducer.setParam15(accountServReq.getProposalDetails().getProposalAmount());
							commRequestProducer.setParam16(accountServReq.getProposalDetails().getProposalNo());
							
							attachmentProducer.setPolicyNumber(receiptResponse.getPolicyNo());
							attachmentProducer.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
							attachmentProducer.setProductCode(accountServReq.getProposalDetails().getProductCode());
							attachmentProducer.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
							attachmentProducer.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
							commRequestProducer.setEmailAttachment(attachmentProducer);
							commRequestProducer.setUserID(accountServReq.getUserID());
							commRequestProducer.setPassword(accountServReq.getPassword());
							commRequestProducer.setProductCode(accountServReq.getProposalDetails().getProductCode());
							commRequestProducer.setProducerEmail(accountServReq.getProducerEmail());
							//tagicCommunicationService.sendCommunication(commRequestProducer);		//1703: RahulT
							logger.info("In IPAServiceImpl :: selfPayResponse method ::: Mail sent successfully to "+accountServReq.getProducerEmail());
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					if (accountServReq.getProducerMobile()!=null && !accountServReq.getProducerMobile().equals("")){
						try{
							//Start: changes done to set values for sms in fresh instance
							CommunicationRequest commRequestSMSProducer = new CommunicationRequest();
							//End: changes done to set values for sms in fresh instance
							logger.info("In IPAServiceImpl :: selfPayResponse method ::: sending SMS to  "+ accountServReq.getProducerMobile());
							commRequestSMSProducer.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMSProducer.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS_PRODUCER);
							commRequestSMSProducer.setReceipient(accountServReq.getProducerMobile());
							commRequestSMSProducer.setParam1(accountServReq.getProducerName()== null?"":accountServReq.getProducerName());
							commRequestSMSProducer.setParam2(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequestSMSProducer.setParam3(accountServReq.getProposalDetails().getCustomerName());
							commRequestSMSProducer.setParam4(accountServReq.getProposalDetails().getProposalNo()==null?"-": accountServReq.getProposalDetails().getProposalNo());
							commRequestSMSProducer.setParam5(receiptResponse.getPolicyNo());
							commRequestSMSProducer.setParam6(accountServReq.getProducerEmail()==null ?"":accountServReq.getProducerEmail()); 
							//tagicCommunicationService.sendCommunication(commRequestSMSProducer);		//1703: RahulT
							logger.info("In IPAServiceImpl :: selfPayResponse method ::: SMS sent successfully to "+accountServReq.getProducerMobile());
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
				}
				
				 // Start| RahulT 15/03/2017| code added to send mail for cover note cases
	            	else if (accountServReq.getIsCoverNoteProposal()!=null && accountServReq.getIsCoverNoteProposal().equalsIgnoreCase(CommonConstants.SUCCESS_STATUS)
	            			&& receiptResponse!=null && receiptResponse.getPolicyNo()!=null && !receiptResponse.getPolicyNo().equals("")){
						
						if (emailID!=null && !emailID.equals("")){
						try{
							CommunicationRequest commRequest = new CommunicationRequest();
							EmailAttachment attachment = new EmailAttachment();
							commRequest.setAlertType(CommonConstants.SEND_EMAIL);
							commRequest.setEventType(CommonConstants.EVENT_OFFLINE_COVERNOTE_PAYMENT_SUCCESS);
							commRequest.setReceipient(emailID);	//Email
							commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequest.setParam2("-");	// cover note number
							commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequest.setParam4(strTotalAmtPartPayment);
							commRequest.setParam5(accountServReq.getProposalDetails().getCustomerName());
							commRequest.setParam6(strTotalAmtPartPayment);
							commRequest.setParam7("-");	// cover note number
							commRequest.setParam8(accountServReq.getProducerName());
							commRequest.setParam9(accountServReq.getProducerMobile()==null ?"-":accountServReq.getProducerMobile()); 
							
							attachment.setPolicyNumber(receiptResponse.getPolicyNo());
							attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
							attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
							attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
							attachment.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
							commRequest.setEmailAttachment(attachment);
							commRequest.setUserID(accountServReq.getUserID());
							commRequest.setPassword(accountServReq.getPassword());
							commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
							commRequest.setProducerEmail(accountServReq.getProducerEmail());
							tagicCommunicationService.sendCommunication(commRequest);
							logger.info("In ReceiptServiceImpl  ::: Mail sent successfully to "+emailID);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					if (mobileNo!=null && !mobileNo.equals("")){
						try{
							//Start: changes done to set values for sms in fresh instance
							CommunicationRequest commRequestSMS = new CommunicationRequest();
							//End: changes done to set values for sms in fresh instance
							logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
							commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMS.setEventType(CommonConstants.EVENT_OFFLINE_COVERNOTE_PAYMENT_SUCCESS);
							commRequestSMS.setReceipient(mobileNo);
							commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequestSMS.setParam2(strTotalAmtPartPayment);
							commRequestSMS.setParam3("-");	// cover note number
							commRequestSMS.setParam4(accountServReq.getProducerName()==null?"-":accountServReq.getProducerName());
							commRequestSMS.setParam5(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile());
							tagicCommunicationService.sendCommunication(commRequestSMS);
							logger.info("In ReceiptServiceImpl method ::: SMS sent successfully to "+mobileNo);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
	            }
					
					
					// fetch sequence ID from payment detail table so that saveOrUpdate method will update existing record
					// And will insert new record for paymentType 'SPL_single'
					if (paymentType!=null && paymentType.equalsIgnoreCase("SPL")){
						lstPaymentTransDtls = (ArrayList) dbService.getPaymentDetailsTransaction("com.majesco.dcf.common.tagic.entity.PaymentDetails", payDtlsTrans.getStrproposalno());	
						if(logger.isDebugEnabled())logger.debug("PaymentServiceImpl:: selfPaymentResponse:: value extracted from payment table for SPL part payment transaction--> "+objMapper.writeValueAsString(lstPaymentTransDtls));
						if(lstPaymentTransDtls!=null && lstPaymentTransDtls.size() > 0)
						{
							for(int i=0;i<lstPaymentTransDtls.size(); i++)
							{
								PaymentDetails payDtlsDB = new PaymentDetails();
								payDtlsDB = (PaymentDetails) lstPaymentTransDtls.get(i);
								
								if(payDtlsDB!=null && payDtlsDB.getStrpaymentmode()!=null && !payDtlsDB.getStrpaymentmode().equals("") && !payDtlsDB.getStrpaymentmode().equals("SPL"))
								{
									payDtlsTrans.setLtransId(payDtlsDB.getLtransId());
								}
							}
						}
					}
					payDtlsTrans.setStrpolicyno(receiptResponse.getPolicyNo());
					payDtlsTrans.setStrgcreceiptno(receiptResponse.getReceiptDtls().getReceiptNo());
					payDtlsTrans.setStrgcsubreceiptno(receiptResponse.getReceiptDtls().getSubReceiptId());
					if (paymentType!=null && paymentType.equalsIgnoreCase("SPL")){	// 2027| RahulT| condition modified for SPL+AD
						//dbService.updatePaymentDetailForSPL(payDtlsTrans);
						dbService.saveOrUpdate(payDtlsTrans);
					}
					else{
						dbService.saveOrUpdate(payDtlsTrans);
					}
					
			}
            //End| RahulT 15/03/2017| code added to send mail for cover note cases
				
			else {
				if (emailID!= null && !emailID.equals("")){
					try{
						CommunicationRequest commRequest = new CommunicationRequest();
						EmailAttachment attachment = new EmailAttachment();
						commRequest.setAlertType(CommonConstants.SEND_EMAIL);
						commRequest.setEventType(CommonConstants.EVENT_PAYMENT_FAILED);
						commRequest.setReceipient(emailID);	//Email
						commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
						commRequest.setParam2(accountServReq.getProposalDetails().getProposalNo());
						commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
						commRequest.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"NA":accountServReq.getProposalDetails().getPlanName());
						commRequest.setParam5(strTotalAmtPartPayment);
						commRequest.setParam6(accountServReq.getProducerName());
						commRequest.setParam7(accountServReq.getProducerCode());
						commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
						commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
						commRequest.setParam10(orderID); // Salutation followed by name & last name
						commRequest.setParam11(TransRefNbr);	// product code
						
						commRequest.setParam12(accountServReq.getProposalDetails().getCustomerName());	
						commRequest.setParam13(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
						commRequest.setParam14(accountServReq.getProducerName());
						commRequest.setParam15(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
							
						/*attachment.setPolicyNumber(receiptResponse.getPolicyNo());
						attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
						attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
						attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
						commRequest.setEmailAttachment(attachment);*/
						commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
						commRequest.setProducerEmail(accountServReq.getProducerEmail());
						tagicCommunicationService.sendCommunication(commRequest);
						logger.info("In PaymentServiceImpl.selfPayResponse method ::: Mail sent successfully to "+emailID);
					}
					catch(Exception e){
						e.printStackTrace();
					}
				}
				if (mobileNo!=null && !mobileNo.equals("")){
					try{
						//Start: changes done to set values for sms in fresh instance
						CommunicationRequest commRequestSMS = new CommunicationRequest();
						//End: changes done to set values for sms in fresh instance
						logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
						commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
						commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_FAILED);
						commRequestSMS.setReceipient(mobileNo);
						commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
						commRequestSMS.setParam2(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
						commRequestSMS.setParam3(orderID);
						commRequestSMS.setParam4(accountServReq.getProposalDetails().getProposalNo());
						commRequestSMS.setParam5(accountServReq.getProducerName());
						commRequestSMS.setParam6(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
						tagicCommunicationService.sendCommunication(commRequestSMS);
						logger.info("In PaymentServiceImpl.selfPayResponse method ::: SMS sent successfully to "+mobileNo);
					}
					catch(Exception e){
						e.printStackTrace();
					}
				}
				
				// sending mail & SMS to producer 
				if (accountServReq.getProducerEmail()!= null && !accountServReq.getProducerEmail().equals("")){
					try{
						CommunicationRequest commRequest = new CommunicationRequest();
						commRequest.setAlertType(CommonConstants.SEND_EMAIL);
						commRequest.setEventType(CommonConstants.EVENT_PAYMENT_FAILED_PRODUCER);
						commRequest.setReceipient(accountServReq.getProducerEmail());	//Email
						commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
						commRequest.setParam2(accountServReq.getProposalDetails().getProposalNo());
						commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
						commRequest.setParam4(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
						commRequest.setParam5(strTotalAmtPartPayment);
						commRequest.setParam6(accountServReq.getProducerName());
						commRequest.setParam7(accountServReq.getProducerCode());
						commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
						commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
						commRequest.setParam10(orderID); // Salutation followed by name & last name
						commRequest.setParam11(TransRefNbr);	// product code
						
						commRequest.setParam12(accountServReq.getProducerName()==null?"":accountServReq.getProducerName());	
						commRequest.setParam13(accountServReq.getProposalDetails().getCustomerName()== null ?"":accountServReq.getProposalDetails().getCustomerName());
						commRequest.setParam14(mobileNo);						
						commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
						commRequest.setProducerEmail(accountServReq.getProducerEmail());
						//tagicCommunicationService.sendCommunication(commRequest);		//1703: RahulT
						logger.info("In PaymentServiceImpl.selfPayResponse method ::: Mail sent successfully to producer on "+accountServReq.getProducerEmail());
					}
					catch(Exception e){
						e.printStackTrace();
					}
				}
				if (accountServReq.getProducerMobile()!=null && !accountServReq.getProducerMobile().equals("")){
					try{
						//Start: changes done to set values for sms in fresh instance
						CommunicationRequest commRequestSMS = new CommunicationRequest();
						//End: changes done to set values for sms in fresh instance
						logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ accountServReq.getProducerMobile());
						commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
						commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_FAILED_PRODUCER);
						commRequestSMS.setReceipient(accountServReq.getProducerMobile());
						commRequestSMS.setParam1(accountServReq.getProducerName()==null?"":accountServReq.getProducerName());
						commRequestSMS.setParam2(accountServReq.getProposalDetails().getCustomerName()== null ?"":accountServReq.getProposalDetails().getCustomerName());
						commRequestSMS.setParam3(accountServReq.getProposalDetails().getProposalNo());
						commRequestSMS.setParam4(orderID);
						commRequestSMS.setParam5(mobileNo);
						//tagicCommunicationService.sendCommunication(commRequestSMS);		//1703: RahulT
						logger.info("In PaymentServiceImpl.selfPayResponse method ::: SMS sent successfully to producer on "+accountServReq.getProducerMobile());
					}
					catch(Exception e){
						e.printStackTrace();
					}
				}

				mapVal.put("receiptNo", "-");
				mapVal.put("policyNo", "-");
				mapVal.put("receiptNo", "-");
				mapVal.put("customerID", "-");
				mapVal.put("proposalDate", "-");
				mapVal.put("productCode", "-");
				mapVal.put("proposalNo", "-");
				// capturing GC error message to display on user screen.
				// setting values in selfpayment entity for billdesk transaction canceled
				if (receiptResponse== null){
					SelfPaymentEntiry failedTxnBD = new SelfPaymentEntiry();
					failedTxnBD.setTransId((String)mapVal.get("screenRefNo"));
					failedTxnBD.setErrorCode((String)mapVal.get("Status"));
					failedTxnBD.setErrorMsg((String)mapVal.get("errorDesc"));
					dbService.payLinkFailedTxnGC(failedTxnBD);
					logger.info("In PaymentController.payLinkRes service ::: updated SelfPaymentEntiry entity for error code & error message.");
					// 1825 : Vishal J : To send error message to user in Payment Failure | 10-Aug-2017 | : Start 
					errorDesc = CommonConstants.PAYMENT_FALURE_GENERIC_ERR_MSG;
					mapVal.put(CommonConstants.IS_ERROR_STRING, "1");
					mapVal.put(PGConstants.ERROR_DESC, errorDesc);
					// 1825 : Vishal J : To send error message to user in Payment Failure | 10-Aug-2017 | : End
				}
				if (receiptResponse!=null && receiptResponse.getResultCode()!=null && receiptResponse.getResultCode().equals("0")
						&& receiptResponse.getErrorList()!=null && !receiptResponse.getErrorList().isEmpty()){
					
					logger.info("In PaymentServiceImpl.selfPayResponse method ::: Transaction failed due to error at GC/ESB layer.");
					ResponseError error = receiptResponse.getErrorList().get(0);
					
					// setting flag for Payment link used
					SelfPaymentEntiry failedTxnGC = new SelfPaymentEntiry();
					failedTxnGC.setTransId(orderID);
					failedTxnGC.setErrorCode(error.getErrorCode());
					failedTxnGC.setErrorMsg(error.getErrorMMessag());
					dbService.payLinkFailedTxnGC(failedTxnGC);
					logger.info("In PaymentServiceImpl.selfPayResponse method ::: updated SelfPaymentEntiry entity for error code & error message.");
					// 1825 : Vishal J : To send error message to user in Payment Failure | 10-Aug-2017 | : Start
					errorDesc = CommonConstants.PAYMENT_FALURE_GENERIC_ERR_MSG;
					mapVal.put(CommonConstants.IS_ERROR_STRING, "1");
					mapVal.put(PGConstants.ERROR_DESC, errorDesc);
					// 1825 : Vishal J : To send error message to user in Payment Failure | 10-Aug-2017 | : End
				}
			}
				
			}
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return mapVal;
	}

	@Override
	public HashMap<String, String> processOLPartPayment(ReceiptCumPolicyRequest accountServReq) throws Exception {
		String strMsg =null;
		ObjectMapper objMap = new ObjectMapper();
		String txtPayCategory = null;
		HashMap <String, String> mapValue = new HashMap<String, String>();
		ObjectMapper objMapper = new ObjectMapper();
		logger.debug("Inside PaymentServiceImpl.processOLPartPayment method.. "+objMapper.writeValueAsString(accountServReq));	
		try{
			if (accountServReq!=null && accountServReq.getPaymentDetails()!= null && !accountServReq.getPaymentDetails().isEmpty() 
					&& accountServReq.getProposalDetails()!=null){
				// Persisting data into dcf_online_stg
				OnlineAccountService olEntity = new OnlineAccountService();
				olEntity.setStrOrderID(accountServReq.getProposalDetails().getProposalNo());
				olEntity.setStrRequestMsg(objMap.writeValueAsString(accountServReq));
				logger.info("In PaymentServiceImpl :: processOLPartPayment method ::: Saving Entity for Billdesk --> Self Payment LinkRequest Object::"+olEntity.getStrRequestMsg());
				dbService.saveOrUpdate(olEntity);
				
				for(int i=0; i<accountServReq.getPaymentDetails().size();i++){
					
					ReceiptPaymentDetails payDtls = accountServReq.getPaymentDetails().get(i);
		    		if(payDtls.getPaymentType().equalsIgnoreCase("OL"))
		    		{
		    			strMsg = this.billdeskPaymentRequest(payDtls.getTransactionId(), payDtls.getPaymentAmount(),accountServReq.getUserID(),payDtls.getOnlinePayMode(), 
		    					accountServReq.getProposalDetails().getProposalNo(),accountServReq.getProposalDetails().getProductCode(),accountServReq.getProducerCode(), null, null);
		    			txtPayCategory = payDtls.getOnlinePayMode();
		    		}
					
				}
				mapValue.put("strMsg", strMsg);
				mapValue.put("txtPayCategory", txtPayCategory);
			}
		}
		catch (Exception e){
			e.printStackTrace();
		}
		return mapValue;
	}

//Start: RahulT<1266> | code added for UPI integration
	
@Override
	public boolean validateVPA(UpiTransactionRequest upiTxnReq)
			throws Exception {
		return false;
	}
		@SuppressWarnings("unchecked")
		@Override
		public Map<String, String> finalResponseAPIHSBC(String msg) throws Exception {
			ReceiptCumPolicyRequest accountServReq =null;
			ReceiptCumPolicyResponse receiptResponse=null;
			Gson gson = new Gson();
			HashMap<String,String> resultAccService = new HashMap<String,String>();
			ObjectMapper objMapper = new ObjectMapper();
			String emailID= null;
			String mobileNo = null;
			double sentAmtToHSBCUPI = 0;
			HashMap<String,String> mapVal = new HashMap<String, String>();
			double dTotalAmtPartPayment = 0;
			String strTotalAmtPartPayment = "";
			PaymentDetails payDtlsTrans = null;
			String splPaymentAmt = "";
			String instrumentDt = "";
			String instrumentNo = "";
			String paymentType = null;
			ArrayList lstPaymentTransDtls = new ArrayList();
			
			try{
				
				String val[] = msg.split("\\|");
				String upiTxnID = val[0];
				String orderIDUPI = val[1];
				String txnAmount = val[2];
				String txnDate = val[3];
				String status = val[4];
				String statusDesc = val[5];
				String responseCode = val[6];
				String bankRefNo = val[7];
				String payerVPA = val[8];
				String npciTransId = val[9];
				String referenceId = val[10];
				//String payeeVPA = val[11];	//commented as it is not used & transaction status response does not send PayeeVPA
								
				UpiTransactionDtl objHSBCUPITrans = dbService.getCHPOrderId(orderIDUPI);
								
				String orderID = objHSBCUPITrans.getPortalTransId();
				logger.info("DBService :: getCHPOrderId :: chpOrderId "+orderID);
								
				DateFormat formatter = new SimpleDateFormat(PGConstants.DATEFORMAT_BILLDESK); 
				//Date dtUpdated = (Date) formatter.parse(txnDate);
				//UpiTransactionDtl objHSBCUPITrans = dbService.getUPITransDtl(orderID, upiTxnID);
				//UpiTransactionDtl objHSBCUPITrans = dbService.getUPITransDtl(orderIDUPI, upiTxnID);
				
				if (objHSBCUPITrans!=null && objHSBCUPITrans.getTransAmount()!=null){
					sentAmtToHSBCUPI = Double.valueOf(objHSBCUPITrans.getTransAmount()).doubleValue();
					double receivedAmtFromHSBCUPI = Double.valueOf(txnAmount).doubleValue();
					
					logger.info("receivedAmtFromHSBCUPI--> "+receivedAmtFromHSBCUPI+", sentAmtToHSBCUPI-->"+sentAmtToHSBCUPI);
					
					if(receivedAmtFromHSBCUPI == sentAmtToHSBCUPI){
						logger.info("HSBC UPI received & sent amount values are same! ");
						objHSBCUPITrans.setUpiTransId(orderID);
						//objHSBCUPITrans.setDtUpdated(dtUpdated);
						objHSBCUPITrans.setPortalTransIdUPI(upiTxnID);
						objHSBCUPITrans.setTransStatus(status);
						objHSBCUPITrans.setTransDescription(statusDesc);
						//objHSBCUPITrans.setResponseMsg(msg);
						objHSBCUPITrans.setUpiFinalResCode(responseCode);
						objHSBCUPITrans.setUpdatedBy(PGConstants.HSBC_UPI);
						objHSBCUPITrans.setBankRefNo(bankRefNo);
						objHSBCUPITrans.setIsProcessed("1");
						objHSBCUPITrans.setNpciTransId(npciTransId);
						objHSBCUPITrans.setReferenceId(referenceId);
						dbService.updateUPITxn(objHSBCUPITrans);	//15-Nov| Method name needs to be changed, updated date need to store
						logger.info("updated billdesk transaction table successfully..");
					}
	
					mapVal.put(PGConstants.SCREEN_REF_NO, orderID);
					mapVal.put(PGConstants.TRANS_REF_NO, referenceId);
					mapVal.put(PGConstants.BANK_REF_NO, bankRefNo);
					mapVal.put(PGConstants.AUTH_STATUS, status);
					mapVal.put(PGConstants.TRANS_DATE, txnDate);
					mapVal.put(PGConstants.TRANS_AMT, txnAmount);
					mapVal.put(CommonConstants.IS_ERROR_STRING, "0");  
					
					logger.debug("Inside PaymentServiceImpl.selfPayResponse method:: OrderID--> "+orderID);		
					/*HashMap<String,String> resultVal = (HashMap<String,String>)dbService.getOLTransaction("com.majesco.dcf.pg.entity.PGTransaction","screenRefNo",orderID);
					
					String strPropNbr = (String) resultVal.get("txnmodeval")==null?"":resultVal.get("txnmodeval");*/
					resultAccService = (HashMap<String,String>)dbService.getBilldeskStgDtl("com.majesco.dcf.common.tagic.entity.OnlineAccountService","strOrderID",orderID);
					
					logger.debug("Inside PaymentServiceImpl.selfPayResponse method:: HashMap Object --> "+objMapper.writeValueAsString(resultAccService));
					
					String strJsonObj = (String) resultAccService.get("func_get_online_acc_service_dtl")==null?"":resultAccService.get("func_get_online_acc_service_dtl");
					accountServReq = gson.fromJson(strJsonObj, ReceiptCumPolicyRequest.class);
					
					if (accountServReq!=null && accountServReq.getProposalDetails()!=null ){
						logger.debug("Inside PaymentServiceImpl.selfPayResponse method..Before invoking account service "+ objMapper.writeValueAsString(accountServReq));
						mapVal.put("customerID", accountServReq.getProposalDetails().getCustomerId());
						mapVal.put("proposalDate", accountServReq.getProposalDetails().getProposalDate());
						mapVal.put("productCode", accountServReq.getProposalDetails().getProductCode());
						mapVal.put("proposalNo", accountServReq.getProposalDetails().getProposalNo());
						mapVal.put("producerCode", accountServReq.getProducerCode());
						mapVal.put("userId", accountServReq.getUserID());
						//setting unique transaction ID received from billdesk
						for (ReceiptPaymentDetails paymentDtl: accountServReq.getPaymentDetails()){
							if (paymentDtl.getPaymentType()!=null && paymentDtl.getPaymentType().contains("SPL")){ 
								paymentDtl.setInstrumentNo(referenceId);
								if (status!=null && status.equals(PGConstants.HSBC_UPI_TRANSACTION_SUCCESS)){
								//if (status!=null){
										// setting flag for Payment link used
										SelfPaymentEntiry selfPayEntity = new SelfPaymentEntiry();
										selfPayEntity.setTransId(orderID);
										selfPayEntity.setPayLinkUsed("1");
										dbService.markPayLinkUsed(orderID);
										
										ReceiptSelfPayLinkHandler handler = new ReceiptSelfPayLinkHandler();
										receiptResponse = handler.callReceiptCumPolicyProcess(accountServReq, dbService);
										
										if(receiptResponse!=null && receiptResponse.getPolicyNo()!=null){
											mapVal.put("policyNo", receiptResponse.getPolicyNo());
											if (receiptResponse.getReceiptDtls() != null)
												mapVal.put("receiptNo", receiptResponse.getReceiptDtls().getReceiptNo());
										}
								//}
								}
								emailID = paymentDtl.getEmailID();
								mobileNo = paymentDtl.getMobileNo();
								if (paymentDtl.getPaymentAmount()!=null && !paymentDtl.getPaymentAmount().equals("")){
									dTotalAmtPartPayment = dTotalAmtPartPayment + Double.valueOf(paymentDtl.getPaymentAmount()).doubleValue();								
								}
								
								instrumentDt = paymentDtl.getInstrumentDate();
								splPaymentAmt = paymentDtl.getPaymentAmount();
								instrumentNo = paymentDtl.getInstrumentNo();
								paymentType = paymentDtl.getPaymentType();
							}
												
						}
						
						strTotalAmtPartPayment = new String(""+Math.round(dTotalAmtPartPayment));
						
						//Start: RahulT<Production> 26/04/2017| data persisted into payment details table for the policy created through SPL payment mode
						SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
						payDtlsTrans = new PaymentDetails();
						payDtlsTrans.setStrpaymentmode(paymentType);
						payDtlsTrans.setStrpaymentamount(splPaymentAmt);
						//Start:03/05/2017:Modified to handle null / blank instrument date coming in request.
						if(instrumentDt==null || instrumentDt.equalsIgnoreCase(CommonConstants.BLANK_STRING))
							instrumentDt=sdf.format(new Date());
						//End:03/05/2017:Modified to handle null / blank instrument date coming in request.
						payDtlsTrans.setStrpaymentinstrumentdt(sdf.parse(instrumentDt));
						payDtlsTrans.setStrinstrumentno(instrumentNo);
						payDtlsTrans.setStripaddress(accountServReq.getSystemIPAddress());
						
						if(accountServReq.getProposalDetails()!=null)
						{
							payDtlsTrans.setStrproposalno(accountServReq.getProposalDetails().getProposalNo());
							payDtlsTrans.setStrcustid(accountServReq.getProposalDetails().getCustomerId());
							payDtlsTrans.setStrbalanceamt(accountServReq.getProposalDetails().getBalanceAmount());
							payDtlsTrans.setStrworkflowid(accountServReq.getProposalDetails().getProposalSystemId());
							
							if(accountServReq.getProposalDetails().getPolicyEffDt()!=null && !accountServReq.getProposalDetails().getPolicyEffDt().equals(""))
								payDtlsTrans.setStrpolicystartdt(sdf.parse(accountServReq.getProposalDetails().getPolicyEffDt()));
							else
								payDtlsTrans.setStrpolicystartdt(null);
							
							if(accountServReq.getProposalDetails().getPolicyEndDt()!=null && !accountServReq.getProposalDetails().getPolicyEndDt().equals(""))
								payDtlsTrans.setStrpolicyenddt(sdf.parse(accountServReq.getProposalDetails().getPolicyEndDt()));
							else
								payDtlsTrans.setStrpolicyenddt(null);
							
							payDtlsTrans.setStrproductcd(accountServReq.getProposalDetails().getProductCode());
							payDtlsTrans.setStrproducercd(accountServReq.getProducerCode());
							payDtlsTrans.setStrcreatedby(accountServReq.getProducerName());
							payDtlsTrans.setDtcreated(new Date());
							payDtlsTrans.setStrbusinessLocation(accountServReq.getProposalDetails().getBusinessLocation());
							payDtlsTrans.setStrdepositofficecode(accountServReq.getProposalDetails().getDepositOfficeCode());
							payDtlsTrans.setStrbusslocname(accountServReq.getProposalDetails().getBussLocName());
							payDtlsTrans.setStrnewrenewflag(accountServReq.getStrnewrenewflag()); // internal issues to save renewal flag in PaymentDetails. : Vishal J | 11-08-2017
						}
						
						//End: RahulT<Production> 26/04/2017| data persisted into payment details table for the policy created through SPL payment mode
						
						if (receiptResponse!=null && receiptResponse.getPolicyNo()!=null && status!=null && status.equals(PGConstants.HSBC_UPI_TRANSACTION_SUCCESS)){
						//if (receiptResponse!=null && receiptResponse.getPolicyNo()!=null && status!=null){
							if (receiptResponse!=null && receiptResponse.getPolicyNo()!=null && status!=null 
									 && accountServReq.getIsCoverNoteProposal().equalsIgnoreCase(CommonConstants.FAILURE_STATUS)){
								if (emailID!=null && !emailID.equals("")){
								try{
									CommunicationRequest commRequest = new CommunicationRequest();
									EmailAttachment attachment = new EmailAttachment();
									commRequest.setAlertType(CommonConstants.SEND_EMAIL);
									commRequest.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS);
									commRequest.setReceipient(emailID);	//Email
									commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
									commRequest.setParam2(receiptResponse.getPolicyNo());
									commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
									commRequest.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"NA":accountServReq.getProposalDetails().getPlanName());
									commRequest.setParam5(strTotalAmtPartPayment);
									commRequest.setParam6(accountServReq.getProducerName());
									commRequest.setParam7(accountServReq.getProducerCode());
									commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
									commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
									commRequest.setParam10(orderID); 
									commRequest.setParam11(referenceId);	
									commRequest.setParam12(accountServReq.getProposalDetails().getCustomerName());
									//commRequest.setParam13(accountServReq.getProposalDetails().getProposalAmount());
									commRequest.setParam13(strTotalAmtPartPayment); //Start:15/04/2017:Changes done to set only the part payment amount as suggested by TAGIC
									commRequest.setParam14(receiptResponse.getPolicyNo());
									commRequest.setParam15(accountServReq.getProducerName());
									commRequest.setParam16(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
									
									attachment.setPolicyNumber(receiptResponse.getPolicyNo());
									attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
									attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
									attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
									attachment.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
									commRequest.setEmailAttachment(attachment);
									commRequest.setUserID(accountServReq.getUserID());
									commRequest.setPassword(accountServReq.getPassword());
									commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
									commRequest.setProducerEmail(accountServReq.getProducerEmail());
									tagicCommunicationService.sendCommunication(commRequest);
									logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: Mail sent successfully to "+emailID);
								}
								catch(Exception e){
									e.printStackTrace();
								}
							}
							
							if (mobileNo!=null && !mobileNo.equals("")){
								try{
									//Start: changes done to set values for sms in fresh instance
									CommunicationRequest commRequestSMS = new CommunicationRequest();
									//End: changes done to set values for sms in fresh instance
									logger.info("In IPAServiceImpl :: selfPayResponse method ::: sending SMS to  "+ mobileNo);
									commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
									commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS);
									commRequestSMS.setReceipient(mobileNo);
									commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
									commRequestSMS.setParam2(strTotalAmtPartPayment);
									commRequestSMS.setParam3(receiptResponse.getPolicyNo());
									commRequestSMS.setParam4(emailID);
									commRequestSMS.setParam5(accountServReq.getProducerName());
									commRequestSMS.setParam6(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
									tagicCommunicationService.sendCommunication(commRequestSMS);
									logger.info("In IPAServiceImpl :: selfPayResponse method ::: SMS sent successfully to "+mobileNo);
								}
								catch(Exception e){
									e.printStackTrace();
								}
							}
							
							// Sending email & SMS to producer
							if (accountServReq.getProducerEmail()!=null && !accountServReq.getProducerEmail().equals("")){
								try{
									CommunicationRequest commRequestProducer = new CommunicationRequest();
									EmailAttachment attachmentProducer = new EmailAttachment();
									commRequestProducer.setAlertType(CommonConstants.SEND_EMAIL);
									commRequestProducer.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS_PRODUCER);
									commRequestProducer.setReceipient(accountServReq.getProducerEmail());	//Email
									commRequestProducer.setParam1(accountServReq.getProposalDetails().getCustomerName());
									commRequestProducer.setParam2(receiptResponse.getPolicyNo());
									commRequestProducer.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
									commRequestProducer.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"NA":accountServReq.getProposalDetails().getPlanName());
									commRequestProducer.setParam5(strTotalAmtPartPayment);
									commRequestProducer.setParam6(accountServReq.getProducerName());
									commRequestProducer.setParam7(accountServReq.getProducerCode());
									commRequestProducer.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
									commRequestProducer.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
									commRequestProducer.setParam10(orderID); 
									commRequestProducer.setParam11(referenceId);	
									
									commRequestProducer.setParam12(accountServReq.getProducerName()== null?"":accountServReq.getProducerName());
									commRequestProducer.setParam13(receiptResponse.getPolicyNo());
									commRequestProducer.setParam14(accountServReq.getProposalDetails().getCustomerName());
									commRequestProducer.setParam15(accountServReq.getProposalDetails().getProposalAmount());
									commRequestProducer.setParam16(accountServReq.getProposalDetails().getProposalNo());
									
									attachmentProducer.setPolicyNumber(receiptResponse.getPolicyNo());
									attachmentProducer.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
									attachmentProducer.setProductCode(accountServReq.getProposalDetails().getProductCode());
									attachmentProducer.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
									attachmentProducer.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
									commRequestProducer.setEmailAttachment(attachmentProducer);
									commRequestProducer.setUserID(accountServReq.getUserID());
									commRequestProducer.setPassword(accountServReq.getPassword());
									commRequestProducer.setProductCode(accountServReq.getProposalDetails().getProductCode());
									commRequestProducer.setProducerEmail(accountServReq.getProducerEmail());
									tagicCommunicationService.sendCommunication(commRequestProducer);
									logger.info("In IPAServiceImpl :: selfPayResponse method ::: Mail sent successfully to "+accountServReq.getProducerEmail());
								}
								catch(Exception e){
									e.printStackTrace();
								}
							}
							
							if (accountServReq.getProducerMobile()!=null && !accountServReq.getProducerMobile().equals("")){
								try{
									CommunicationRequest commRequestSMSProducer = new CommunicationRequest();
									logger.info("In IPAServiceImpl :: selfPayResponse method ::: sending SMS to  "+ accountServReq.getProducerMobile());
									commRequestSMSProducer.setAlertType(CommonConstants.SEND_SMS);
									commRequestSMSProducer.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS_PRODUCER);
									commRequestSMSProducer.setReceipient(accountServReq.getProducerMobile());
									commRequestSMSProducer.setParam1(accountServReq.getProducerName()== null?"":accountServReq.getProducerName());
									commRequestSMSProducer.setParam2(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
									commRequestSMSProducer.setParam3(accountServReq.getProposalDetails().getCustomerName());
									commRequestSMSProducer.setParam4(accountServReq.getProposalDetails().getProposalNo()==null?"-": accountServReq.getProposalDetails().getProposalNo());
									commRequestSMSProducer.setParam5(receiptResponse.getPolicyNo());
									commRequestSMSProducer.setParam6(accountServReq.getProducerEmail()==null ?"":accountServReq.getProducerEmail()); 
									tagicCommunicationService.sendCommunication(commRequestSMSProducer);
									logger.info("In IPAServiceImpl :: selfPayResponse method ::: SMS sent successfully to "+accountServReq.getProducerMobile());
								}
								catch(Exception e){
									e.printStackTrace();
								}
							}
						}
						
						 // Start| RahulT 15/03/2017| code added to send mail for cover note cases
			            	else if (accountServReq.getIsCoverNoteProposal()!=null && accountServReq.getIsCoverNoteProposal().equalsIgnoreCase(CommonConstants.SUCCESS_STATUS)
			            			&& receiptResponse!=null && receiptResponse.getPolicyNo()!=null && !receiptResponse.getPolicyNo().equals("")){
								
								if (emailID!=null && !emailID.equals("")){
								try{
									CommunicationRequest commRequest = new CommunicationRequest();
									EmailAttachment attachment = new EmailAttachment();
									commRequest.setAlertType(CommonConstants.SEND_EMAIL);
									commRequest.setEventType(CommonConstants.EVENT_OFFLINE_COVERNOTE_PAYMENT_SUCCESS);
									commRequest.setReceipient(emailID);	//Email
									commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
									commRequest.setParam2("-");	// cover note number
									commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
									commRequest.setParam4(strTotalAmtPartPayment);
									commRequest.setParam5(accountServReq.getProposalDetails().getCustomerName());
									commRequest.setParam6(strTotalAmtPartPayment);
									commRequest.setParam7("-");	// cover note number
									commRequest.setParam8(accountServReq.getProducerName());
									commRequest.setParam9(accountServReq.getProducerMobile()==null ?"-":accountServReq.getProducerMobile()); 
									
									attachment.setPolicyNumber(receiptResponse.getPolicyNo());
									attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
									attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
									attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
									attachment.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
									commRequest.setEmailAttachment(attachment);
									commRequest.setUserID(accountServReq.getUserID());
									commRequest.setPassword(accountServReq.getPassword());
									commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
									commRequest.setProducerEmail(accountServReq.getProducerEmail());
									tagicCommunicationService.sendCommunication(commRequest);
									logger.info("In ReceiptServiceImpl  ::: Mail sent successfully to "+emailID);
								}
								catch(Exception e){
									e.printStackTrace();
								}
							}
							
							if (mobileNo!=null && !mobileNo.equals("")){
								try{
									CommunicationRequest commRequestSMS = new CommunicationRequest();
									logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
									commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
									commRequestSMS.setEventType(CommonConstants.EVENT_OFFLINE_COVERNOTE_PAYMENT_SUCCESS);
									commRequestSMS.setReceipient(mobileNo);
									commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
									commRequestSMS.setParam2(strTotalAmtPartPayment);
									commRequestSMS.setParam3("-");	// cover note number
									commRequestSMS.setParam4(accountServReq.getProducerName()==null?"-":accountServReq.getProducerName());
									commRequestSMS.setParam5(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile());
									tagicCommunicationService.sendCommunication(commRequestSMS);
									logger.info("In ReceiptServiceImpl method ::: SMS sent successfully to "+mobileNo);
								}
								catch(Exception e){
									e.printStackTrace();
								}
							}
			            }
							
							
							// fetch sequence ID from payment detail table so that saveOrUpdate method will update existing record
							// And will insert new record for paymentType 'SPL_single'
							if (paymentType!=null && paymentType.equalsIgnoreCase("SPL")){
								lstPaymentTransDtls = (ArrayList) dbService.getPaymentDetailsTransaction("com.majesco.dcf.common.tagic.entity.PaymentDetails", payDtlsTrans.getStrproposalno());	
								if(logger.isDebugEnabled())logger.debug("PaymentServiceImpl:: selfPaymentResponse:: value extracted from payment table for SPL part payment transaction--> "+objMapper.writeValueAsString(lstPaymentTransDtls));
								if(lstPaymentTransDtls!=null && lstPaymentTransDtls.size() > 0)
								{
									for(int i=0;i<lstPaymentTransDtls.size(); i++)
									{
										PaymentDetails payDtlsDB = new PaymentDetails();
										payDtlsDB = (PaymentDetails) lstPaymentTransDtls.get(i);
										
										if(payDtlsDB!=null && payDtlsDB.getStrpaymentmode()!=null && !payDtlsDB.getStrpaymentmode().equals("") && !payDtlsDB.getStrpaymentmode().equals("SPL"))
										{
											payDtlsTrans.setLtransId(payDtlsDB.getLtransId());
										}
									}
								}
							}
							payDtlsTrans.setStrpolicyno(receiptResponse.getPolicyNo());
							payDtlsTrans.setStrgcreceiptno(receiptResponse.getReceiptDtls().getReceiptNo());
							payDtlsTrans.setStrgcsubreceiptno(receiptResponse.getReceiptDtls().getSubReceiptId());
							if (paymentType!=null && paymentType.equalsIgnoreCase("SPL")){	// 2027| RahulT| condition modified for SPL+AD
								//dbService.updatePaymentDetailForSPL(payDtlsTrans);
								dbService.saveOrUpdate(payDtlsTrans);
							}
							else{
								dbService.saveOrUpdate(payDtlsTrans);
							}
							
						}
	            //End| RahulT 15/03/2017| code added to send mail for cover note cases
					
						else {
							if (emailID!= null && !emailID.equals("")){
								try{
									CommunicationRequest commRequest = new CommunicationRequest();
									EmailAttachment attachment = new EmailAttachment();
									commRequest.setAlertType(CommonConstants.SEND_EMAIL);
									commRequest.setEventType(CommonConstants.EVENT_PAYMENT_FAILED);
									commRequest.setReceipient(emailID);	//Email
									commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
									commRequest.setParam2(accountServReq.getProposalDetails().getProposalNo());
									commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
									commRequest.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"NA":accountServReq.getProposalDetails().getPlanName());
									commRequest.setParam5(strTotalAmtPartPayment);
									commRequest.setParam6(accountServReq.getProducerName());
									commRequest.setParam7(accountServReq.getProducerCode());
									commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
									commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
									commRequest.setParam10(orderID); // Salutation followed by name & last name
									commRequest.setParam11(referenceId);	// product code
									
									commRequest.setParam12(accountServReq.getProposalDetails().getCustomerName());	
									commRequest.setParam13(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
									commRequest.setParam14(accountServReq.getProducerName());
									commRequest.setParam15(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
								
									commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
									commRequest.setProducerEmail(accountServReq.getProducerEmail());
									tagicCommunicationService.sendCommunication(commRequest);
									logger.info("In PaymentServiceImpl.selfPayResponse method ::: Mail sent successfully to "+emailID);
								}
								catch(Exception e){
									e.printStackTrace();
								}
							}
							if (mobileNo!=null && !mobileNo.equals("")){
								try{
									//Start: changes done to set values for sms in fresh instance
									CommunicationRequest commRequestSMS = new CommunicationRequest();
									//End: changes done to set values for sms in fresh instance
									logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
									commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
									commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_FAILED);
									commRequestSMS.setReceipient(mobileNo);
									commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
									commRequestSMS.setParam2(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
									commRequestSMS.setParam3(orderID);
									commRequestSMS.setParam4(accountServReq.getProposalDetails().getProposalNo());
									commRequestSMS.setParam5(accountServReq.getProducerName());
									commRequestSMS.setParam6(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
									tagicCommunicationService.sendCommunication(commRequestSMS);
									logger.info("In PaymentServiceImpl.selfPayResponse method ::: SMS sent successfully to "+mobileNo);
								}
								catch(Exception e){
									e.printStackTrace();
								}
							}
							
							// sending mail & SMS to producer 
							if (accountServReq.getProducerEmail()!= null && !accountServReq.getProducerEmail().equals("")){
								try{
									CommunicationRequest commRequest = new CommunicationRequest();
									commRequest.setAlertType(CommonConstants.SEND_EMAIL);
									commRequest.setEventType(CommonConstants.EVENT_PAYMENT_FAILED_PRODUCER);
									commRequest.setReceipient(accountServReq.getProducerEmail());	//Email
									commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
									commRequest.setParam2(accountServReq.getProposalDetails().getProposalNo());
									commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
									commRequest.setParam4(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
									commRequest.setParam5(strTotalAmtPartPayment);
									commRequest.setParam6(accountServReq.getProducerName());
									commRequest.setParam7(accountServReq.getProducerCode());
									commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
									commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
									commRequest.setParam10(orderID); // Salutation followed by name & last name
									commRequest.setParam11(referenceId);	// product code
									
									commRequest.setParam12(accountServReq.getProducerName()==null?"":accountServReq.getProducerName());	
									commRequest.setParam13(accountServReq.getProposalDetails().getCustomerName()== null ?"":accountServReq.getProposalDetails().getCustomerName());
									commRequest.setParam14(mobileNo);						
									commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
									commRequest.setProducerEmail(accountServReq.getProducerEmail());
									tagicCommunicationService.sendCommunication(commRequest);
									logger.info("In PaymentServiceImpl.selfPayResponse method ::: Mail sent successfully to producer on "+accountServReq.getProducerEmail());
								}
								catch(Exception e){
									e.printStackTrace();
								}
							}
							if (accountServReq.getProducerMobile()!=null && !accountServReq.getProducerMobile().equals("")){
								try{
									//Start: changes done to set values for sms in fresh instance
									CommunicationRequest commRequestSMS = new CommunicationRequest();
									//End: changes done to set values for sms in fresh instance
									logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ accountServReq.getProducerMobile());
									commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
									commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_FAILED_PRODUCER);
									commRequestSMS.setReceipient(accountServReq.getProducerMobile());
									commRequestSMS.setParam1(accountServReq.getProducerName()==null?"":accountServReq.getProducerName());
									commRequestSMS.setParam2(accountServReq.getProposalDetails().getCustomerName()== null ?"":accountServReq.getProposalDetails().getCustomerName());
									commRequestSMS.setParam3(accountServReq.getProposalDetails().getProposalNo());
									commRequestSMS.setParam4(orderID);
									commRequestSMS.setParam5(mobileNo);
									tagicCommunicationService.sendCommunication(commRequestSMS);
									logger.info("In PaymentServiceImpl.selfPayResponse method ::: SMS sent successfully to producer on "+accountServReq.getProducerMobile());
								}
								catch(Exception e){
									e.printStackTrace();
								}
							}
		
							mapVal.put("receiptNo", "-");
							mapVal.put("policyNo", "-");
							mapVal.put("receiptNo", "-");
							mapVal.put("customerID", "-");
							mapVal.put("proposalDate", "-");
							mapVal.put("productCode", "-");
							mapVal.put("proposalNo", "-");
							// capturing GC error message to display on user screen.
							// setting values in selfpayment entity for billdesk transaction canceled
							if (receiptResponse == null){
								SelfPaymentEntiry failedTxnBD = new SelfPaymentEntiry();
								failedTxnBD.setTransId((String)mapVal.get("screenRefNo"));
								failedTxnBD.setErrorCode((String)mapVal.get("Status"));
								failedTxnBD.setErrorMsg((String)mapVal.get("errorDesc"));
								dbService.payLinkFailedTxnGC(failedTxnBD);
								logger.info("In PaymentController.payLinkRes service ::: updated SelfPaymentEntiry entity for error code & error message.");
								mapVal.put(CommonConstants.IS_ERROR_STRING, "1");
								mapVal.put(PGConstants.ERROR_DESC, CommonConstants.PAYMENT_FALURE_GENERIC_ERR_MSG);
								// 1825 : Vishal J : To send error message to user in Payment Failure | 10-Aug-2017 | : End
							}
							if (receiptResponse!=null && receiptResponse.getResultCode()!=null && receiptResponse.getResultCode().equals("0")
									&& receiptResponse.getErrorList()!=null && !receiptResponse.getErrorList().isEmpty()){
								
								logger.info("In PaymentServiceImpl.selfPayResponse method ::: Transaction failed due to error at GC/ESB layer.");
								ResponseError error = receiptResponse.getErrorList().get(0);
								
								// setting flag for Payment link used
								SelfPaymentEntiry failedTxnGC = new SelfPaymentEntiry();
								failedTxnGC.setTransId(orderID);
								failedTxnGC.setErrorCode(error.getErrorCode());
								failedTxnGC.setErrorMsg(error.getErrorMMessag());
								dbService.payLinkFailedTxnGC(failedTxnGC);
								logger.info("In PaymentServiceImpl.selfPayResponse method ::: updated SelfPaymentEntiry entity for error code & error message.");
								mapVal.put(CommonConstants.IS_ERROR_STRING, "1");
								mapVal.put(PGConstants.ERROR_DESC, CommonConstants.PAYMENT_FALURE_GENERIC_ERR_MSG);
								// 1825 : Vishal J : To send error message to user in Payment Failure | 10-Aug-2017 | : End
							}
						}
					}
				}
			}
			catch(Exception ex){
				ex.printStackTrace();
			}
			return mapVal;
		}
		//End: RahulT<1266> | code added for UPI integration
		
		/**
		 * subtract days to date in java
		 * @param date
		 * @param days
		 * @return
		 */
		public static Date calculateDays(Date date, int days) {
			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(date);
			cal.add(Calendar.DATE, days);
					
			return cal.getTime();
		}
		
		public static int getDifferenceDays(Date d1, Date d2) {
		    long diff = d2.getTime() - d1.getTime();
		    return (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		}
		// Start : <3343> Added for setting time to 0 : VishalJ
		private static Date getZeroTimeDate(Date date) {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			date = calendar.getTime();
			return date;
		}
		// End : <3343> Added for setting time to 0 : VishalJ		
		
		
		public String decrypt(String instaResp) throws Exception
			  {
				byte[] utf8 = null;
			    try
			    {
			      String lKey = "#g%t8&(k$^";
			      SecretKeySpec lKeySpec = new SecretKeySpec(lKey.getBytes("UTF8"), "Blowfish");
			      Cipher lCipher = Cipher.getInstance("Blowfish/ECB/PKCS5Padding");
			      lCipher.init(2, lKeySpec);
			      byte[] dec = DatatypeConverter.parseBase64Binary(instaResp);
			      utf8 = lCipher.doFinal(dec);
			      return new String(utf8, "UTF8");
			    }
			    catch (Exception lException)
			    {
			      logger.error("PGI Exception : ", lException);
			     // throw new ApplicationException(ApplicationErrorCodes.BUSINESS_EXCEPTION);
			    }
			    return new String(utf8, "UTF8");
			  }
		
		
		
		
		// Start : Added For Payment lite Services :DineshS
		// This method gets invoked from billdesk on SPL transaction Type
		@SuppressWarnings("unchecked")
		@Override
		public Map<String, String> selfPayLitePaymentService(String msg) throws Exception {
			
			logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: <Method START A1" );
			
			ReceiptCumPolicyRequest accountServReq =null;
			ReceiptCumPolicyResponse receiptResponse=null;
			Gson gson = new Gson();
			HashMap<String,String> resultAccService = new HashMap<String,String>();
			ObjectMapper objMapper = new ObjectMapper();
			String emailID= null;
			//String payAmount= "";
			String mobileNo = null;
			double sentAmtToBilldesk = 0;
			PGTransaction transaction = new PGTransaction();
			HashMap<String,String> mapVal = new HashMap<String, String>();
			TagicCommunicationLiteService tagicCommLite = new TagicCommunicationLiteService(); // 860664
			String customerSMSSuccess = ""; //added for scheduler 860664
			String customerEmailSuccess = ""; // added for scheduler 860664
			double dTotalAmtPartPayment = 0;
			String strTotalAmtPartPayment = "";
			PaymentDetails payDtlsTrans = null;
			String splPaymentAmt = "";
			String instrumentDt = "";
			String instrumentNo = "";
			String paymentType = null;
			ArrayList lstPaymentTransDtls = new ArrayList();
			try{
				

				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: <Method MID A2>");
				//Start| RahulT <VAPT comment>| code added to validate billdesk transaction at portal level
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: message String received from billdesk-->"+msg);
				//Start:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
				if(msg == null){
					logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: message String received from billdesk is Empty");
				}
				
				
				msg = "HrpdZPthOJM1sZXjwM9wC4FGX3IJezFXMnkuO4dedr6hNJGkmYX14vHcXKWlgb9FIla8H0SeDp57acR5nIiwdDzQHkyXEJkaIsf1k+ctDyPZ/DVi2DYqoHx9ove/1yuQialV8Zheo9Xto0etzUDGIJfOn1O6CP0GLNnH93hHAs1Ngy/PptXZfJlJy3FnrKoydkwQIsjNA6vXrDyn6DoNkz+SE7MifY81J/OvJiYnz2xIKpaXbAUzoZ8314H09gy/fYzXc418j3ufpwVCEiLC/a4ZwaHWL+if2bst4YRu6hWKPNNcEMafCxapBy593DINPYm9+p5yFcr5qUMt14n78n/M6E9JitR7SQ0lyzs3in6aLgKFCECyII2c3ghPrA+P5wA4ygjOvzb9tSupfj/0wv7BM0sCWfOB8OheJ3b8FND/a1uE8ekRhdWwH8enuVGCWSFj91t3hdb8PymnxD1rt47IqQ08nJFJtajJyXHWX8rgMe6qC/rJlPuyLl/hdmOkEiBp19l+zcBLGHI/8oyLum172/bgCC3NI0h9grm/geEgx54KrULRZNsoP5TqAdQYzr2nckLgra8=";
				
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: <Method MID A3>");
				String orderID = null;
				String TransRefNbr = null;
				String bankRefNo = null;
				String txnAmount = null;
				String txnDate = null;
				String Status = null;
				String errorDesc = null;
				String checksumRes = null;
				String tranStatus = null;
				Date dtUpdated = null;
				String strCPIResp=null;
				
				int pgFlagVal = 0;	
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: BEFORE CALLING METHOD dbService.getConfigParamVal <Method MID A4>");
				String pgFlag = dbService.getConfigParamVal(CommonConstants.PG_REDIRECT_FLAG);
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: AFTER CALLING METHOD dbService.getConfigParamVal <Method MID A5>");
				pgFlagVal = Integer.parseInt(pgFlag);
				if (pgFlagVal == 1) {
					logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: message String received from CPI-->"+msg);
					if(msg != null && !msg.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
					 strCPIResp = decrypt(msg);
					}
					logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: message String decrypt from CPI response-->"+strCPIResp);
					

						CPIPaymentResponse cpiRespObj = new CPIPaymentResponse();
					cpiRespObj = gson.fromJson(strCPIResp, CPIPaymentResponse.class);
					
					logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: CPIPaymentResponse-->"+objMapper.writeValueAsString(cpiRespObj));
					
					orderID = cpiRespObj.getConsumerAppTransId();
					TransRefNbr = cpiRespObj.getPgiTransactionid();
					bankRefNo = cpiRespObj.getBankId();
					txnAmount = cpiRespObj.getPremiumAmount();
					//txnDate = cpiRespObj.get;
					Status = cpiRespObj.getResponseCode();
					errorDesc = cpiRespObj.getResponseDescription();
					//checksumRes = val[25];
					tranStatus = PGConstants.STATUS_FAILURE;
					
					DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY HH:mm:ss.SSS");
					Date date = new Date();
					txnDate =  dateFormat.format(date); //"14-04-2018 13:23:38";
					
//					DateFormat formatter = new SimpleDateFormat(PGConstants.DATEFORMAT_BILLDESK); 
//					dtUpdated = (Date) formatter.parse(txnDate);
					
				} else {
					
					String withoutCheckSumURL = msg.substring(0,msg.lastIndexOf(PGConstants.PIPE_SEPARATOR));
					
					logger.info("withoutCheckSumURL--> "+withoutCheckSumURL);
					
					String val[] = msg.split("\\|");
					orderID = val[1];
					TransRefNbr = val[2];
					bankRefNo = val[3];
					txnAmount = val[4];
					txnDate = val[13];
					Status = val[14];
					errorDesc = val[24];
					checksumRes = val[25];
						
					tranStatus = PGConstants.STATUS_FAILURE;
					//String withoutCheckSumURL = msg.substring(0,msg.lastIndexOf(PGConstants.PIPE_SEPARATOR));
					String chksumCalc = PGIUtil.doDigest(withoutCheckSumURL, billdesk_Key);
					
					logger.info("chksumCalc--> "+chksumCalc+", checksumRes-->"+checksumRes);
					
//					DateFormat formatter = new SimpleDateFormat(PGConstants.DATEFORMAT_BILLDESK); 
//					dtUpdated = (Date) formatter.parse(txnDate);
					
				}
				//End:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
				
				
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: <Method MID A6>");
				DateFormat formatter = new SimpleDateFormat(PGConstants.DATEFORMAT_BILLDESK); 
				//logger.info("dtUpdated--> " + txnDate);
				dtUpdated = (Date) formatter.parse(txnDate);
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService::: <Method MID A6.1>"+orderID);
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService:::BEFORE Calling Method dbService.getBilldeskTransData <Method MID A6.2>");
				sentAmtToBilldesk = dbService.getBilldeskTransData(orderID);
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService:::AFTER Calling Method dbService.getBilldeskTransData <Method MID A7>");
				double receivedAmtFromBilldesk = Double.valueOf(txnAmount).doubleValue();
				
				logger.info("receivedAmtFromBilldesk--> "+receivedAmtFromBilldesk+", sentAmtToBilldesk-->"+sentAmtToBilldesk);
				
				if(receivedAmtFromBilldesk == sentAmtToBilldesk){
					logger.info("billdesk received & sent amount values are same! ");
					if (PGConstants.PG_RES_SUCCESS.equals(Status)) {
						transaction.setTxnStatus(PGConstants.STATUS_SUCCESS);
						tranStatus = PGConstants.STATUS_SUCCESS;
					} else {
						transaction.setTxnStatus(PGConstants.STATUS_FAILURE);
					}
					transaction.setScreenRefNo(orderID);
					transaction.setPgTxnRefNo(TransRefNbr);
					transaction.setPgBankRefNo(bankRefNo);
					transaction.setPgAuthStatus(Status);
					transaction.setPgErrorDesc(errorDesc);
					transaction.setPgMsg(msg);
					transaction.setUpdatedBy(PGConstants.PG_RESPONSE);
					transaction.setUpdatedDt(dtUpdated);
					transaction.setTxnStatus(tranStatus);
					logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService:::BEFORE Calling Method dbService.updateBilldeskTxn <Method MID A8>");
					dbService.updateBilldeskTxn(transaction);
					logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService:::AFTER Calling Method dbService.updateBilldeskTxn <Method MID A9>");
					logger.info("updated billdesk transaction table successfully..");
				}

				mapVal.put(PGConstants.SCREEN_REF_NO, orderID);
				mapVal.put(PGConstants.TRANS_REF_NO, TransRefNbr);
				mapVal.put(PGConstants.BANK_REF_NO, bankRefNo);
				mapVal.put(PGConstants.AUTH_STATUS, Status);
				mapVal.put(PGConstants.TRANS_DATE, txnDate);
				mapVal.put(PGConstants.ERROR_DESC, errorDesc);
				mapVal.put(PGConstants.TRANS_AMT, txnAmount);
				mapVal.put(CommonConstants.IS_ERROR_STRING, "0");  // 1825 : Vishal J : Code for sending 0 by default. Mentioning No GC Error. 
				
				/*String Status = (String)mapVal.get("Status");
				String orderID = (String)mapVal.get("screenRefNo");
				String TransRefNbr = (String)mapVal.get("TxnReferenceNo");
				String payAmount = (String)mapVal.get("TxnAmount");*/
				
				//End| RahulT <VAPT comment>| code added
				
				
				
				logger.debug("Inside PaymentServiceImpl.selfPayResponse method:: OrderID--> "+orderID);		
				/*HashMap<String,String> resultVal = (HashMap<String,String>)dbService.getOLTransaction("com.majesco.dcf.pg.entity.PGTransaction","screenRefNo",orderID);
				
				String strPropNbr = (String) resultVal.get("txnmodeval")==null?"":resultVal.get("txnmodeval");*/
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService:::BEFORE Calling Method dbService.getBilldeskStgDtl( <Method MID A10>");
				resultAccService = (HashMap<String,String>)dbService.getBilldeskStgDtl("com.majesco.dcf.common.tagic.entity.OnlineAccountService","strOrderID",orderID);
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService:::AFTER Calling Method dbService.getBilldeskStgDtl( <Method MID A11>");
				logger.info("Inside PaymentServiceImpl.selfPayResponse method:: HashMap Object --> "+objMapper.writeValueAsString(resultAccService));
				
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService:::BEFORE Calling Method  resultAccService.get(func_get_online_acc_service_dtl)( <Method MID A12>");
				String strJsonObj = (String) resultAccService.get("func_get_online_acc_service_dtl")==null?"":resultAccService.get("func_get_online_acc_service_dtl");
				accountServReq = gson.fromJson(strJsonObj, ReceiptCumPolicyRequest.class);
				logger.info("Inside PaymentServiceImpl::: selfPayLitePaymentService:::AFTER Calling Method  resultAccService.get(func_get_online_acc_service_dtl)( <Method MID A13>");
				
				
				if (accountServReq!=null && accountServReq.getProposalDetails()!=null ){
					logger.info("Inside PaymentServiceImpl.selfPayResponse method..Before invoking account service "+ objMapper.writeValueAsString(accountServReq));
					mapVal.put("customerID", accountServReq.getProposalDetails().getCustomerId());
					mapVal.put("proposalDate", accountServReq.getProposalDetails().getProposalDate());
					mapVal.put("productCode", accountServReq.getProposalDetails().getProductCode());
					mapVal.put("proposalNo", accountServReq.getProposalDetails().getProposalNo());
					mapVal.put("producerCode", accountServReq.getProducerCode());
					mapVal.put("userId", accountServReq.getUserID());
					
					logger.info("Outside PaymentServiceImpl.selfPayResponse method..Before invoking account service ");
					//setting unique transaction ID received from billdesk
					for (ReceiptPaymentDetails paymentDtl: accountServReq.getPaymentDetails()){
 						logger.info("Inside PaymentServiceImpl.selfPayResponse method..Before invoking account service 1234");
						if (paymentDtl.getPaymentType()!=null && paymentDtl.getPaymentType().contains("SPL")){ 
							logger.info("Inside PaymentServiceImpl.selfPayResponse method..Before invoking account service 1235"+Status);
							paymentDtl.setInstrumentNo(TransRefNbr);
							if ((Status!=null && Status.equals(CommonConstants.BILLDESK_SUCCESS))){
							//if (Status!=null){
								logger.info("Inside PaymentServiceImpl.selfPayResponse method..Before invoking account service 1235");
								logger.info("in PaymentServiceImpl.selfPayResponse method..Before invoking account service A15451");
									// setting flag for Payment link used
									SelfPaymentEntiry selfPayEntity = new SelfPaymentEntiry();
									selfPayEntity.setTransId(orderID);
									selfPayEntity.setPayLinkUsed("1");
									dbService.markPayLinkUsed(orderID);
									
									
									boolean isSPLPart = false;
									String proposalNumber = accountServReq.getProposalDetails().getProposalNo();	//RahulT| User transaction changes
									logger.info("Inside PaymentServiceImpl.selfPayResponse method..Before invoking dbService.getPaymentDetailsTransaction ");
									lstPaymentTransDtls = (ArrayList) dbService.getPaymentDetailsTransaction("com.majesco.dcf.common.tagic.entity.PaymentDetails", proposalNumber);	
									logger.info("Inside PaymentServiceImpl.selfPayResponse method..Before invoking dbService.getPaymentDetailsTransaction");
									logger.info("Start:: :ReceiptOnlineHandler::Calling AccountService-->paymentEntryCumPolicyGen:: lstPaymentTransDtls");
									if(lstPaymentTransDtls!=null && lstPaymentTransDtls.size() > 0)
									{
										for(int i=0;i<lstPaymentTransDtls.size(); i++)
										{
											payDtlsTrans = new PaymentDetails();
											payDtlsTrans = (PaymentDetails) lstPaymentTransDtls.get(i);
											
											
											if(payDtlsTrans!=null && payDtlsTrans.getStrpaymentmode()!=null && !payDtlsTrans.getStrpaymentmode().equals("") && !payDtlsTrans.getStrpaymentmode().equals(CommonConstants.PAYMENT_METHOD_SPL))
											{
												isSPLPart = true;
											}
											
										}
									}
									
									
									if(isSPLPart){
										logger.info("Inside PaymentServiceImpl.selfPayResponse method..After invoking account service IN IS_SPL_PART "+isSPLPart);
										ReceiptSelfPayLinkHandler handler = new ReceiptSelfPayLinkHandler();
										receiptResponse = handler.callReceiptCumPolicyProcess(accountServReq, dbService);
										logger.info("Inside PaymentServiceImpl.selfPayResponse method..After invoking account service "+ objMapper.writeValueAsString(receiptResponse));
										
									}else{
										//START save Payment data in PMTFLOW_Flag table
										if(TransRefNbr != null && !TransRefNbr.equalsIgnoreCase("") && orderID != null && !orderID.equalsIgnoreCase("")){
											PmtFlowFlags flags = new PmtFlowFlags();
											flags.setStrpaymnetno(TransRefNbr);
											flags.setStrscreenrefno(orderID);
											flags.setStrpolicyno(accountServReq.getProposalDetails().getProposalNo());
											dbService.updatePmtFlowFlag(flags);
										}
										
										//END save Payment data in PMTFLOW_Flag table
										
										logger.info("Inside PaymentServiceImpl.selfPayResponse method..After invoking account service IN NON IS_SPL_PART "+isSPLPart);
										ReceiptSelfPayLinkHandlerForLiteService handler = new ReceiptSelfPayLinkHandlerForLiteService();
										receiptResponse = handler.callReceiptCumPolicyProcess(accountServReq, dbService);
										logger.info("Inside PaymentServiceImpl.selfPayResponse method..After invoking account service "+ objMapper.writeValueAsString(receiptResponse));
										

										
									}
									
									
									if(receiptResponse!=null && receiptResponse.getPolicyNo()!=null){
										mapVal.put("policyNo", receiptResponse.getPolicyNo());
										if (receiptResponse.getReceiptDtls() != null)
											mapVal.put("receiptNo", receiptResponse.getReceiptDtls().getReceiptNo());
									}
							//}
							}
							emailID = paymentDtl.getEmailID();
							mobileNo = paymentDtl.getMobileNo();
							if (paymentDtl.getPaymentAmount()!=null && !paymentDtl.getPaymentAmount().equals("")){
								dTotalAmtPartPayment = dTotalAmtPartPayment + Double.valueOf(paymentDtl.getPaymentAmount()).doubleValue();								
							}
							
							instrumentDt = paymentDtl.getInstrumentDate();
							splPaymentAmt = paymentDtl.getPaymentAmount();
							instrumentNo = paymentDtl.getInstrumentNo();
							paymentType = paymentDtl.getPaymentType();
						}
											
					}
					
					strTotalAmtPartPayment = new String(""+Math.round(dTotalAmtPartPayment));
					
					//Start: RahulT<Production> 26/04/2017| data persisted into payment details table for the policy created through SPL payment mode
					SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
					payDtlsTrans = new PaymentDetails();
					payDtlsTrans.setStrpaymentmode(paymentType);
					payDtlsTrans.setStrpaymentamount(splPaymentAmt);
					//Start:03/05/2017:Modified to handle null / blank instrument date coming in request.
					if(instrumentDt==null || instrumentDt.equalsIgnoreCase(CommonConstants.BLANK_STRING))
						instrumentDt=sdf.format(new Date());
					//End:03/05/2017:Modified to handle null / blank instrument date coming in request.
					payDtlsTrans.setStrpaymentinstrumentdt(sdf.parse(instrumentDt));
					payDtlsTrans.setStrinstrumentno(instrumentNo);
					payDtlsTrans.setStripaddress(accountServReq.getSystemIPAddress());
					
					if(accountServReq.getProposalDetails()!=null)
					{
						payDtlsTrans.setStrproposalno(accountServReq.getProposalDetails().getProposalNo());
						payDtlsTrans.setStrcustid(accountServReq.getProposalDetails().getCustomerId());
						payDtlsTrans.setStrbalanceamt(accountServReq.getProposalDetails().getBalanceAmount());
						payDtlsTrans.setStrworkflowid(accountServReq.getProposalDetails().getProposalSystemId());
						
						if(accountServReq.getProposalDetails().getPolicyEffDt()!=null && !accountServReq.getProposalDetails().getPolicyEffDt().equals(""))
							payDtlsTrans.setStrpolicystartdt(sdf.parse(accountServReq.getProposalDetails().getPolicyEffDt()));
						else
							payDtlsTrans.setStrpolicystartdt(null);
						
						if(accountServReq.getProposalDetails().getPolicyEndDt()!=null && !accountServReq.getProposalDetails().getPolicyEndDt().equals(""))
							payDtlsTrans.setStrpolicyenddt(sdf.parse(accountServReq.getProposalDetails().getPolicyEndDt()));
						else
							payDtlsTrans.setStrpolicyenddt(null);
						
						payDtlsTrans.setStrproductcd(accountServReq.getProposalDetails().getProductCode());
						payDtlsTrans.setStrproducercd(accountServReq.getProducerCode());
						payDtlsTrans.setStrcreatedby(accountServReq.getProducerName());
						payDtlsTrans.setDtcreated(new Date());
						payDtlsTrans.setStrbusinessLocation(accountServReq.getProposalDetails().getBusinessLocation());
						payDtlsTrans.setStrdepositofficecode(accountServReq.getProposalDetails().getDepositOfficeCode());
						payDtlsTrans.setStrbusslocname(accountServReq.getProposalDetails().getBussLocName());
						payDtlsTrans.setStrnewrenewflag(accountServReq.getStrnewrenewflag()); // internal issues to save renewal flag in PaymentDetails. : Vishal J | 11-08-2017
					}
					
					//End: RahulT<Production> 26/04/2017| data persisted into payment details table for the policy created through SPL payment mode
					
					if (receiptResponse!=null && receiptResponse.getPolicyNo()!=null && Status!=null && Status.equals(CommonConstants.BILLDESK_SUCCESS)){
					//if (receiptResponse!=null && receiptResponse.getPolicyNo()!=null && Status!=null){
						if (receiptResponse!=null && receiptResponse.getPolicyNo()!=null && Status!=null 
								 && accountServReq.getIsCoverNoteProposal().equalsIgnoreCase(CommonConstants.FAILURE_STATUS)){
							if (emailID!=null && !emailID.equals("")){
							try{
								CommunicationRequest commRequest = new CommunicationRequest();
								EmailAttachment attachment = new EmailAttachment();
								commRequest.setAlertType(CommonConstants.SEND_EMAIL);
								commRequest.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS);
								commRequest.setReceipient(emailID);	//Email
								commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
								commRequest.setParam2(receiptResponse.getPolicyNo());
								commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
								commRequest.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"NA":accountServReq.getProposalDetails().getPlanName());
								commRequest.setParam5(strTotalAmtPartPayment);
								commRequest.setParam6(accountServReq.getProducerName());
								commRequest.setParam7(accountServReq.getProducerCode());
								commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
								commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
								commRequest.setParam10(orderID); 
								commRequest.setParam11(TransRefNbr);	
								commRequest.setParam12(accountServReq.getProposalDetails().getCustomerName());
								//commRequest.setParam13(accountServReq.getProposalDetails().getProposalAmount());
								commRequest.setParam13(strTotalAmtPartPayment); //Start:15/04/2017:Changes done to set only the part payment amount as suggested by TAGIC
								commRequest.setParam14(receiptResponse.getPolicyNo());
								commRequest.setParam15(accountServReq.getProducerName());
								commRequest.setParam16(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
								
								attachment.setPolicyNumber(receiptResponse.getPolicyNo());
								attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
								attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
								attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
								attachment.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
								commRequest.setEmailAttachment(attachment);
								commRequest.setUserID(accountServReq.getUserID());
								commRequest.setPassword(accountServReq.getPassword());
								commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
								commRequest.setProducerEmail(accountServReq.getProducerEmail());
								customerEmailSuccess = tagicCommLite.sendCommunication(commRequest);
								logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: Mail sent successfully to "+emailID);
							}
							catch(Exception e){
								e.printStackTrace();
								
							}
						}
						
						if (mobileNo!=null && !mobileNo.equals("")){
							try{
								//Start: changes done to set values for sms in fresh instance
								CommunicationRequest commRequestSMS = new CommunicationRequest();
								//End: changes done to set values for sms in fresh instance
								logger.info("In IPAServiceImpl :: selfPayResponse method ::: sending SMS to  "+ mobileNo);
								commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
								commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS);
								commRequestSMS.setReceipient(mobileNo);
								commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
								commRequestSMS.setParam2(strTotalAmtPartPayment);
								commRequestSMS.setParam3(receiptResponse.getPolicyNo());
								commRequestSMS.setParam4(emailID);
								commRequestSMS.setParam5(accountServReq.getProducerName());
								commRequestSMS.setParam6(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
								customerSMSSuccess = tagicCommLite.sendCommunication(commRequestSMS);
								logger.info("In IPAServiceImpl :: selfPayResponse method ::: SMS sent successfully to "+mobileNo);
							}
							catch(Exception e){
								e.printStackTrace();
								
							}
						}
						
						// Sending email & SMS to producer
						if (accountServReq.getProducerEmail()!=null && !accountServReq.getProducerEmail().equals("")){
							try{
								CommunicationRequest commRequestProducer = new CommunicationRequest();
								EmailAttachment attachmentProducer = new EmailAttachment();
								commRequestProducer.setAlertType(CommonConstants.SEND_EMAIL);
								commRequestProducer.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS_PRODUCER);
								commRequestProducer.setReceipient(accountServReq.getProducerEmail());	//Email
								commRequestProducer.setParam1(accountServReq.getProposalDetails().getCustomerName());
								commRequestProducer.setParam2(receiptResponse.getPolicyNo());
								commRequestProducer.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
								commRequestProducer.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"NA":accountServReq.getProposalDetails().getPlanName());
								commRequestProducer.setParam5(strTotalAmtPartPayment);
								commRequestProducer.setParam6(accountServReq.getProducerName());
								commRequestProducer.setParam7(accountServReq.getProducerCode());
								commRequestProducer.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
								commRequestProducer.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
								commRequestProducer.setParam10(orderID); 
								commRequestProducer.setParam11(TransRefNbr);	
								
								commRequestProducer.setParam12(accountServReq.getProducerName()== null?"":accountServReq.getProducerName());
								commRequestProducer.setParam13(receiptResponse.getPolicyNo());
								commRequestProducer.setParam14(accountServReq.getProposalDetails().getCustomerName());
								commRequestProducer.setParam15(accountServReq.getProposalDetails().getProposalAmount());
								commRequestProducer.setParam16(accountServReq.getProposalDetails().getProposalNo());
								
								attachmentProducer.setPolicyNumber(receiptResponse.getPolicyNo());
								attachmentProducer.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
								attachmentProducer.setProductCode(accountServReq.getProposalDetails().getProductCode());
								attachmentProducer.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
								attachmentProducer.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
								commRequestProducer.setEmailAttachment(attachmentProducer);
								commRequestProducer.setUserID(accountServReq.getUserID());
								commRequestProducer.setPassword(accountServReq.getPassword());
								commRequestProducer.setProductCode(accountServReq.getProposalDetails().getProductCode());
								commRequestProducer.setProducerEmail(accountServReq.getProducerEmail());
								//tagicCommunicationService.sendCommunication(commRequestProducer);		//1703: RahulT
								logger.info("In IPAServiceImpl :: selfPayResponse method ::: Mail sent successfully to "+accountServReq.getProducerEmail());
							}
							catch(Exception e){
								e.printStackTrace();
							
							}
						}
						
						if (accountServReq.getProducerMobile()!=null && !accountServReq.getProducerMobile().equals("")){
							try{
								//Start: changes done to set values for sms in fresh instance
								CommunicationRequest commRequestSMSProducer = new CommunicationRequest();
								//End: changes done to set values for sms in fresh instance
								logger.info("In IPAServiceImpl :: selfPayResponse method ::: sending SMS to  "+ accountServReq.getProducerMobile());
								commRequestSMSProducer.setAlertType(CommonConstants.SEND_SMS);
								commRequestSMSProducer.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS_PRODUCER);
								commRequestSMSProducer.setReceipient(accountServReq.getProducerMobile());
								commRequestSMSProducer.setParam1(accountServReq.getProducerName()== null?"":accountServReq.getProducerName());
								commRequestSMSProducer.setParam2(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
								commRequestSMSProducer.setParam3(accountServReq.getProposalDetails().getCustomerName());
								commRequestSMSProducer.setParam4(accountServReq.getProposalDetails().getProposalNo()==null?"-": accountServReq.getProposalDetails().getProposalNo());
								commRequestSMSProducer.setParam5(receiptResponse.getPolicyNo());
								commRequestSMSProducer.setParam6(accountServReq.getProducerEmail()==null ?"":accountServReq.getProducerEmail()); 
								//tagicCommunicationService.sendCommunication(commRequestSMSProducer);		//1703: RahulT
								logger.info("In IPAServiceImpl :: selfPayResponse method ::: SMS sent successfully to "+accountServReq.getProducerMobile());
							}
							catch(Exception e){
								e.printStackTrace();
								
							}
						}
					}
					
					 // Start| RahulT 15/03/2017| code added to send mail for cover note cases
		            	else if (accountServReq.getIsCoverNoteProposal()!=null && accountServReq.getIsCoverNoteProposal().equalsIgnoreCase(CommonConstants.SUCCESS_STATUS)
		            			&& receiptResponse!=null && receiptResponse.getPolicyNo()!=null && !receiptResponse.getPolicyNo().equals("")){
							
							if (emailID!=null && !emailID.equals("")){
							try{
								CommunicationRequest commRequest = new CommunicationRequest();
								EmailAttachment attachment = new EmailAttachment();
								commRequest.setAlertType(CommonConstants.SEND_EMAIL);
								commRequest.setEventType(CommonConstants.EVENT_OFFLINE_COVERNOTE_PAYMENT_SUCCESS);
								commRequest.setReceipient(emailID);	//Email
								commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
								commRequest.setParam2("-");	// cover note number
								commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
								commRequest.setParam4(strTotalAmtPartPayment);
								commRequest.setParam5(accountServReq.getProposalDetails().getCustomerName());
								commRequest.setParam6(strTotalAmtPartPayment);
								commRequest.setParam7("-");	// cover note number
								commRequest.setParam8(accountServReq.getProducerName());
								commRequest.setParam9(accountServReq.getProducerMobile()==null ?"-":accountServReq.getProducerMobile()); 
								
								attachment.setPolicyNumber(receiptResponse.getPolicyNo());
								attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
								attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
								attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
								attachment.setReceiptNo(receiptResponse.getReceiptDtls().getReceiptNo());
								commRequest.setEmailAttachment(attachment);
								commRequest.setUserID(accountServReq.getUserID());
								commRequest.setPassword(accountServReq.getPassword());
								commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
								commRequest.setProducerEmail(accountServReq.getProducerEmail());
								tagicCommLite.sendCommunication(commRequest);
								logger.info("In ReceiptServiceImpl  ::: Mail sent successfully to "+emailID);
							}
							catch(Exception e){
								e.printStackTrace();
								
							}
						}
						
						if (mobileNo!=null && !mobileNo.equals("")){
							try{
								//Start: changes done to set values for sms in fresh instance
								CommunicationRequest commRequestSMS = new CommunicationRequest();
								//End: changes done to set values for sms in fresh instance
								logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
								commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
								commRequestSMS.setEventType(CommonConstants.EVENT_OFFLINE_COVERNOTE_PAYMENT_SUCCESS);
								commRequestSMS.setReceipient(mobileNo);
								commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
								commRequestSMS.setParam2(strTotalAmtPartPayment);
								commRequestSMS.setParam3("-");	// cover note number
								commRequestSMS.setParam4(accountServReq.getProducerName()==null?"-":accountServReq.getProducerName());
								commRequestSMS.setParam5(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile());
								tagicCommLite.sendCommunication(commRequestSMS);
								logger.info("In ReceiptServiceImpl method ::: SMS sent successfully to "+mobileNo);
							}
							catch(Exception e){
								e.printStackTrace();
								
							}
						}
		            }
						
						
						// fetch sequence ID from payment detail table so that saveOrUpdate method will update existing record
						// And will insert new record for paymentType 'SPL_single'
						if (paymentType!=null && paymentType.equalsIgnoreCase("SPL")){
							lstPaymentTransDtls = (ArrayList) dbService.getPaymentDetailsTransaction("com.majesco.dcf.common.tagic.entity.PaymentDetails", payDtlsTrans.getStrproposalno());	
							if(logger.isDebugEnabled())logger.debug("PaymentServiceImpl:: selfPaymentResponse:: value extracted from payment table for SPL part payment transaction--> "+objMapper.writeValueAsString(lstPaymentTransDtls));
							if(lstPaymentTransDtls!=null && lstPaymentTransDtls.size() > 0)
							{
								for(int i=0;i<lstPaymentTransDtls.size(); i++)
								{
									PaymentDetails payDtlsDB = new PaymentDetails();
									payDtlsDB = (PaymentDetails) lstPaymentTransDtls.get(i);
									
									if(payDtlsDB!=null && payDtlsDB.getStrpaymentmode()!=null && !payDtlsDB.getStrpaymentmode().equals("") && !payDtlsDB.getStrpaymentmode().equals("SPL"))
									{
										payDtlsTrans.setLtransId(payDtlsDB.getLtransId());
									}
								}
							}
						}
						payDtlsTrans.setStrpolicyno(receiptResponse.getPolicyNo());
						payDtlsTrans.setStrgcreceiptno(receiptResponse.getReceiptDtls().getReceiptNo());
						payDtlsTrans.setStrgcsubreceiptno(receiptResponse.getReceiptDtls().getSubReceiptId());
						if (paymentType!=null && paymentType.equalsIgnoreCase("SPL")){	// 2027| RahulT| condition modified for SPL+AD
							//dbService.updatePaymentDetailForSPL(payDtlsTrans);
							dbService.saveOrUpdate(payDtlsTrans);
						}
						else{
							dbService.saveOrUpdate(payDtlsTrans);
						}
						
				}
	            //End| RahulT 15/03/2017| code added to send mail for cover note cases
					
				else {
					if (emailID!= null && !emailID.equals("")){
						try{
							CommunicationRequest commRequest = new CommunicationRequest();
							EmailAttachment attachment = new EmailAttachment();
							commRequest.setAlertType(CommonConstants.SEND_EMAIL);
							commRequest.setEventType(CommonConstants.EVENT_PAYMENT_FAILED);
							commRequest.setReceipient(emailID);	//Email
							commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequest.setParam2(accountServReq.getProposalDetails().getProposalNo());
							commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequest.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"NA":accountServReq.getProposalDetails().getPlanName());
							commRequest.setParam5(strTotalAmtPartPayment);
							commRequest.setParam6(accountServReq.getProducerName());
							commRequest.setParam7(accountServReq.getProducerCode());
							commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
							commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
							commRequest.setParam10(orderID); // Salutation followed by name & last name
							commRequest.setParam11(TransRefNbr);	// product code
							
							commRequest.setParam12(accountServReq.getProposalDetails().getCustomerName());	
							commRequest.setParam13(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequest.setParam14(accountServReq.getProducerName());
							commRequest.setParam15(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
								
							/*attachment.setPolicyNumber(receiptResponse.getPolicyNo());
							attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
							attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
							attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
							commRequest.setEmailAttachment(attachment);*/
							commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
							commRequest.setProducerEmail(accountServReq.getProducerEmail());
							tagicCommLite.sendCommunication(commRequest);
							logger.info("In PaymentServiceImpl.selfPayResponse method ::: Mail sent successfully to "+emailID);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					if (mobileNo!=null && !mobileNo.equals("")){
						try{
							//Start: changes done to set values for sms in fresh instance
							CommunicationRequest commRequestSMS = new CommunicationRequest();
							//End: changes done to set values for sms in fresh instance
							logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ mobileNo);
							commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_FAILED);
							commRequestSMS.setReceipient(mobileNo);
							commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequestSMS.setParam2(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequestSMS.setParam3(orderID);
							commRequestSMS.setParam4(accountServReq.getProposalDetails().getProposalNo());
							commRequestSMS.setParam5(accountServReq.getProducerName());
							commRequestSMS.setParam6(accountServReq.getProducerMobile()==null ?"1800 - 266 - 7780":accountServReq.getProducerMobile()); 
							tagicCommLite.sendCommunication(commRequestSMS);
							logger.info("In PaymentServiceImpl.selfPayResponse method ::: SMS sent successfully to "+mobileNo);
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					
					// sending mail & SMS to producer 
					if (accountServReq.getProducerEmail()!= null && !accountServReq.getProducerEmail().equals("")){
						try{
							CommunicationRequest commRequest = new CommunicationRequest();
							commRequest.setAlertType(CommonConstants.SEND_EMAIL);
							commRequest.setEventType(CommonConstants.EVENT_PAYMENT_FAILED_PRODUCER);
							commRequest.setReceipient(accountServReq.getProducerEmail());	//Email
							commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
							commRequest.setParam2(accountServReq.getProposalDetails().getProposalNo());
							commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequest.setParam4(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
							commRequest.setParam5(strTotalAmtPartPayment);
							commRequest.setParam6(accountServReq.getProducerName());
							commRequest.setParam7(accountServReq.getProducerCode());
							commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
							commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
							commRequest.setParam10(orderID); // Salutation followed by name & last name
							commRequest.setParam11(TransRefNbr);	// product code
							
							commRequest.setParam12(accountServReq.getProducerName()==null?"":accountServReq.getProducerName());	
							commRequest.setParam13(accountServReq.getProposalDetails().getCustomerName()== null ?"":accountServReq.getProposalDetails().getCustomerName());
							commRequest.setParam14(mobileNo);						
							commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
							commRequest.setProducerEmail(accountServReq.getProducerEmail());
							//tagicCommunicationService.sendCommunication(commRequest);		//1703: RahulT
							logger.info("In PaymentServiceImpl.selfPayResponse method ::: Mail sent successfully to producer on "+accountServReq.getProducerEmail());
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
					if (accountServReq.getProducerMobile()!=null && !accountServReq.getProducerMobile().equals("")){
						try{
							//Start: changes done to set values for sms in fresh instance
							CommunicationRequest commRequestSMS = new CommunicationRequest();
							//End: changes done to set values for sms in fresh instance
							logger.info("In IPAServiceImpl :: getIPAProposalAG method ::: sending SMS to  "+ accountServReq.getProducerMobile());
							commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_FAILED_PRODUCER);
							commRequestSMS.setReceipient(accountServReq.getProducerMobile());
							commRequestSMS.setParam1(accountServReq.getProducerName()==null?"":accountServReq.getProducerName());
							commRequestSMS.setParam2(accountServReq.getProposalDetails().getCustomerName()== null ?"":accountServReq.getProposalDetails().getCustomerName());
							commRequestSMS.setParam3(accountServReq.getProposalDetails().getProposalNo());
							commRequestSMS.setParam4(orderID);
							commRequestSMS.setParam5(mobileNo);
							//tagicCommunicationService.sendCommunication(commRequestSMS);		//1703: RahulT
							logger.info("In PaymentServiceImpl.selfPayResponse method ::: SMS sent successfully to producer on "+accountServReq.getProducerMobile());
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}

					mapVal.put("receiptNo", "-");
					mapVal.put("policyNo", "-");
					mapVal.put("receiptNo", "-");
					mapVal.put("customerID", "-");
					mapVal.put("proposalDate", "-");
					mapVal.put("productCode", "-");
					mapVal.put("proposalNo", "-");
					// capturing GC error message to display on user screen.
					// setting values in selfpayment entity for billdesk transaction canceled
					if (receiptResponse== null){
						SelfPaymentEntiry failedTxnBD = new SelfPaymentEntiry();
						failedTxnBD.setTransId((String)mapVal.get("screenRefNo"));
						failedTxnBD.setErrorCode((String)mapVal.get("Status"));
						failedTxnBD.setErrorMsg((String)mapVal.get("errorDesc"));
						dbService.payLinkFailedTxnGC(failedTxnBD);
						logger.info("In PaymentController.payLinkRes service ::: updated SelfPaymentEntiry entity for error code & error message.");
						// 1825 : Vishal J : To send error message to user in Payment Failure | 10-Aug-2017 | : Start 
						errorDesc = CommonConstants.PAYMENT_FALURE_GENERIC_ERR_MSG;
						mapVal.put(CommonConstants.IS_ERROR_STRING, "1");
						mapVal.put(PGConstants.ERROR_DESC, errorDesc);
						// 1825 : Vishal J : To send error message to user in Payment Failure | 10-Aug-2017 | : End
					}
					if (receiptResponse!=null && receiptResponse.getResultCode()!=null && receiptResponse.getResultCode().equals("0")
							&& receiptResponse.getErrorList()!=null && !receiptResponse.getErrorList().isEmpty()){
						
						logger.info("In PaymentServiceImpl.selfPayResponse method ::: Transaction failed due to error at GC/ESB layer.");
						ResponseError error = receiptResponse.getErrorList().get(0);
						
						// setting flag for Payment link used
						SelfPaymentEntiry failedTxnGC = new SelfPaymentEntiry();
						failedTxnGC.setTransId(orderID);
						failedTxnGC.setErrorCode(error.getErrorCode());
						failedTxnGC.setErrorMsg(error.getErrorMMessag());
						dbService.payLinkFailedTxnGC(failedTxnGC);
						logger.info("In PaymentServiceImpl.selfPayResponse method ::: updated SelfPaymentEntiry entity for error code & error message.");
						// 1825 : Vishal J : To send error message to user in Payment Failure | 10-Aug-2017 | : Start
						errorDesc = CommonConstants.PAYMENT_FALURE_GENERIC_ERR_MSG;
						mapVal.put(CommonConstants.IS_ERROR_STRING, "1");
						mapVal.put(PGConstants.ERROR_DESC, errorDesc);
						// 1825 : Vishal J : To send error message to user in Payment Failure | 10-Aug-2017 | : End
					}
				}
//Start : code for setting final status 
					
					PmtFlowFlags  flags = new PmtFlowFlags();
					flags.setStrproposalno(accountServReq.getProposalDetails().getProposalNo());
					flags.setStrpdfgenflag(CommonConstants.FAILURE_VALUE);
					flags.setStrfinalstatus(CommonConstants.FAILURE_VALUE);
					dbService.updatePmtFlowFlag(flags);
					
					//if both email and sms are null
					if((mobileNo==null || mobileNo.equals("")) && (emailID==null || emailID.equals("")))
					{ 
						//PmtFlowFlags  flags = new PmtFlowFlags();
						flags.setStrproposalno(accountServReq.getProposalDetails().getProposalNo());
					flags.setStrpdfgenflag(CommonConstants.SUCCESS_VALUE);
					flags.setStrfinalstatus(CommonConstants.SUCCESS_VALUE);
					dbService.updatePmtFlowFlag(flags);
					}
					
					//if email is null
					if(emailID==null || "".equals(emailID)){
						if(mobileNo!=null || !"".equals(mobileNo)) {
							if(customerSMSSuccess == CommonConstants.PDF_SUCCESS) {
								//PmtFlowFlags  flags = new PmtFlowFlags();
								flags.setStrproposalno(accountServReq.getProposalDetails().getProposalNo());
								flags.setStrpdfgenflag(CommonConstants.SUCCESS_VALUE);
								flags.setStrfinalstatus(CommonConstants.SUCCESS_VALUE);
								dbService.updatePmtFlowFlag(flags);
							}
						}
					}
					
					//if mobileno is null
					if(mobileNo==null || "".equals(mobileNo)){
						if(emailID!=null || !"".equals(emailID)) {
							if(customerEmailSuccess == CommonConstants.PDF_SUCCESS) {
								//PmtFlowFlags  flags = new PmtFlowFlags();
								flags.setStrproposalno(accountServReq.getProposalDetails().getProposalNo());
								flags.setStrpdfgenflag(CommonConstants.SUCCESS_VALUE);
								flags.setStrfinalstatus(CommonConstants.SUCCESS_VALUE);
								dbService.updatePmtFlowFlag(flags);
				}
						}
					}
				
					//if both are not null
					if((emailID!=null || !"".equals(emailID)) && (mobileNo!=null || !"".equals(mobileNo)) ) {
						if(customerEmailSuccess == CommonConstants.PDF_SUCCESS && customerSMSSuccess == CommonConstants.PDF_SUCCESS) {
							//PmtFlowFlags  flags = new PmtFlowFlags();
							flags.setStrproposalno(accountServReq.getProposalDetails().getProposalNo());
							flags.setStrpdfgenflag(CommonConstants.SUCCESS_VALUE);
							flags.setStrfinalstatus(CommonConstants.SUCCESS_VALUE);
							dbService.updatePmtFlowFlag(flags);
						}
					}
					//End : code for setting final status 	
			}
			}
			catch(Exception ex){
				ex.printStackTrace();
			}
			return mapVal;
		}
		
		
		//End : Added For Pamyment lite Services : DineshS
}

package com.majesco.dcf.docmgmt.json;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

/**
 * @author yogesh570158
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CustDocUploadLinkReq extends UserObject{
	private String proposalNo;
	private String customerId;
	private String customerName;
	private String productLine; /// Line of business - Motor,IPA,Health etc
	private String proposalAmount;				
	private String proposalDate;
	private String productCode;	
	private String emailId;
	private String mobileNo;
	private String policyEffDt;
	private String policyEndDt;
	private String planName;
	private String vehRegNo;
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getProductLine() {
		return productLine;
	}
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}
	public String getProposalAmount() {
		return proposalAmount;
	}
	public void setProposalAmount(String proposalAmount) {
		this.proposalAmount = proposalAmount;
	}
	public String getProposalDate() {
		return proposalDate;
	}
	public void setProposalDate(String proposalDate) {
		this.proposalDate = proposalDate;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPolicyEffDt() {
		return policyEffDt;
	}
	public void setPolicyEffDt(String policyEffDt) {
		this.policyEffDt = policyEffDt;
	}
	public String getPolicyEndDt() {
		return policyEndDt;
	}
	public void setPolicyEndDt(String policyEndDt) {
		this.policyEndDt = policyEndDt;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getVehRegNo() {
		return vehRegNo;
	}
	public void setVehRegNo(String vehRegNo) {
		this.vehRegNo = vehRegNo;
	}			
}

package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;
/**
 * 
 * @author vishal662335
 *
 */

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class QlikTicketResponse extends ResultObject{
	
	private String qlikTicketNo;

	public String getQlikTicketNo() {
		return qlikTicketNo;
	}

	public void setQlikTicketNo(String qlikTicketNo) {
		this.qlikTicketNo = qlikTicketNo;
	}



}

package com.majesco.dcf.common.tagic.service;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class TestService {

	final static Logger logger=Logger.getLogger(TestService.class);
	
	public String sayHello(String strInput){
		System.out.println("Hello from ");
		logger.debug("TestService called, strInput="+strInput);
		return "Hello from TestService !!!!";
	}
	
}

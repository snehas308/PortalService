package com.majesco.dcf.docmgmt.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.springframework.web.multipart.MultipartFile;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class UploadModel extends UserObject {

	//private String extraField;
	private String propNo;
	private String docMapId;
	private String userId;
	private MultipartFile[] files;
	//private MultipartFile uploadfile;
	
	
	public String getPropNo() {
		return propNo;
	}
	public void setPropNo(String propNo) {
		this.propNo = propNo;
	}
	public String getDocMapId() {
		return docMapId;
	}
	public void setDocMapId(String docMapId) {
		this.docMapId = docMapId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public MultipartFile[] getFiles() {
		return files;
	}
	public void setFiles(MultipartFile[] files) {
		this.files = files;
	}
	
}

package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_param_user_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_param_user_m")							// Added for Oracle Migration
public class UserParameterList implements Serializable{
	
	  private Integer iparamtypecd;
	  private String strparamcd;
	  private String strcddesc;
	  private Integer nisactive;
	  private ParameterList parameterList;
	  
	  @Id
		@Column(name = "nparamtypecd")  
	public Integer getIparamtypecd() {
		return iparamtypecd;
	}
	public void setIparamtypecd(Integer iparamtypecd) {
		this.iparamtypecd = iparamtypecd;
	}
	
	
	@Id
	@Column(name = "strparamcd") 
	public String getStrparamcd() {
		return strparamcd;
	}
	public void setStrparamcd(String strparamcd) {
		this.strparamcd = strparamcd;
	}
	
	
	@Column(name = "strcddesc") 
	public String getStrcddesc() {
		return strcddesc;
	}
	public void setStrcddesc(String strcddesc) {
		this.strcddesc = strcddesc;
	}
	
 	@ManyToOne
    @JoinColumn(name="nparamtypecd", nullable=false)
	public ParameterList getParameterList() {
		return parameterList;
	}
	public void setParameterList(ParameterList parameterList) {
		this.parameterList = parameterList;
	}
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	  
	  

}

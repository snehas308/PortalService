package com.majesco.dcf.covernote.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PendingCoverNoteResponse {
	private String coverNoteNo;
	private String custID;
	private String customerName;
	private String make;
	private String model;
	private String modelVariant;
	private String officeCode;
	private String productCode;
	private String proposalAmount;
	private String proposalDate;
	private String proposalNo;
	private String rto;
	private String receiptNumber;
	private String reference_Date;
	private String riskEndDate;
	private String riskStartDate;
	private String workflowid;
	private String errorCode;
	private String errorMsg;
	private String errorText;
	public String getCoverNoteNo() {
		return coverNoteNo;
	}
	public void setCoverNoteNo(String coverNoteNo) {
		this.coverNoteNo = coverNoteNo;
	}
	public String getCustID() {
		return custID;
	}
	public void setCustID(String custID) {
		this.custID = custID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getModelVariant() {
		return modelVariant;
	}
	public void setModelVariant(String modelVariant) {
		this.modelVariant = modelVariant;
	}
	public String getOfficeCode() {
		return officeCode;
	}
	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProposalAmount() {
		return proposalAmount;
	}
	public void setProposalAmount(String proposalAmount) {
		this.proposalAmount = proposalAmount;
	}
	public String getProposalDate() {
		return proposalDate;
	}
	public void setProposalDate(String proposalDate) {
		this.proposalDate = proposalDate;
	}
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getRto() {
		return rto;
	}
	public void setRto(String rto) {
		this.rto = rto;
	}
	public String getReceiptNumber() {
		return receiptNumber;
	}
	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}
	public String getReference_Date() {
		return reference_Date;
	}
	public void setReference_Date(String reference_Date) {
		this.reference_Date = reference_Date;
	}
	public String getRiskEndDate() {
		return riskEndDate;
	}
	public void setRiskEndDate(String riskEndDate) {
		this.riskEndDate = riskEndDate;
	}
	public String getRiskStartDate() {
		return riskStartDate;
	}
	public void setRiskStartDate(String riskStartDate) {
		this.riskStartDate = riskStartDate;
	}
	public String getWorkflowid() {
		return workflowid;
	}
	public void setWorkflowid(String workflowid) {
		this.workflowid = workflowid;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getErrorText() {
		return errorText;
	}
	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}
}

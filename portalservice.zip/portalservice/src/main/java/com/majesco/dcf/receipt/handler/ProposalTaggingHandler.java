package com.majesco.dcf.receipt.handler;

import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;

import com.majesco.dcf.common.chp.util.CdataWriterInterceptor;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.SOAPInfo;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;
import com.majesco.dcf.receipt.util.ReceiptConstants;
import com.majesco.dcf.util.CXFInBoundInterceptor;
import com.majesco.dcf.util.CXFOutInterceptor;
import com.unotechsoft.stub.accountservice.client.AccountService;
import com.unotechsoft.stub.accountservice.client.ArrayOfClsPaymentIdGrid;
import com.unotechsoft.stub.accountservice.client.ArrayOfClsPolicyIdGrid;
import com.unotechsoft.stub.accountservice.client.ArrayOfKeyValueOfstringstring;
import com.unotechsoft.stub.accountservice.client.ArrayOfanyType;
import com.unotechsoft.stub.accountservice.client.ArrayOfstring;
import com.unotechsoft.stub.accountservice.client.ClsPaymentIdGrid;
import com.unotechsoft.stub.accountservice.client.ClsPolicyIdGrid;
import com.unotechsoft.stub.accountservice.client.PaymentEntryServiceResult;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentTaging;

public class ProposalTaggingHandler {
	
	
	final static Logger logger=Logger.getLogger(ProposalTaggingHandler.class);
	public  String serviceURL=ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING;
	private static Properties prop = new Properties();
	static{
		try{
	InputStream inputStream = ReceiptSelfPayLinkHandler.class.getClassLoader().getResourceAsStream("resources.properties");
	prop.load(inputStream);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	
	public PaymentEntryServiceResult proposalTaggingServiceCall(ReceiptCumPolicyRequest receiptReq, DBService dbService, String receiptNo,AccountService accServClient) throws Exception{
		
        System.out.println("START ::ProposalTaggingHandler::proposalTaggingServiceCall:: START");
		logger.info("START ::ProposalTaggingHandler::proposalTaggingServiceCall:: START");
		PaymentEntryServiceResult responseProposalTagging = null;
		ArrayOfstring paymntid = new ArrayOfstring();
		ArrayOfstring propdate = new ArrayOfstring();
		ArrayOfstring propnumber = new ArrayOfstring();
		ArrayOfanyType homebank = new ArrayOfanyType();
		ArrayOfanyType tag = new ArrayOfanyType();
		ArrayOfKeyValueOfstringstring arrOfKeyValueOfstringstringnew  = new ArrayOfKeyValueOfstringstring();
		ObjectMapper objMap = new ObjectMapper();
		UserDataPaymentTaging objUserDataPaymentTaging = null;
		String userId = "";
		if(receiptReq.getUserId() != null  && StringUtils.isNumeric(receiptReq.getUserId())){
		userId = receiptReq.getUserId();
		}else{
			userId =  ReceiptConstants.DEFAULT_USERID_TASKUSER;
		}

		/*if(serviceURL==null || serviceURL.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
			serviceURL=dbService.getWSDLURL(ReceiptConstants.ACCOUNTSERVICE_ID,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			//serviceURL="http://172.17.203.45:9393/AccountService_SOAPOverHTTP?wsdl";
			//serviceURL=wsdlURL;
		}
		AccountService_Service accService=new AccountService_Service(new URL(serviceURL));
		
		AccountService accServClient=accService.getSOAPOverHTTP();*/
		//UserDataPaymentTaging objUserDataPaymentTaging = new UserDataPaymentTaging();
		logger.info("START ::ProposalTaggingHandler::proposalTaggingServiceCall:: START");
		
		try{
		objUserDataPaymentTaging = new UserDataPaymentTaging();
		
		SimpleDateFormat sdf_transTime = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss", Locale.US);
		Date dateFormat_PayTag = new Date();
	
		logger.info(" ::ProposalTaggingHandler::proposalTaggingServiceCall:: B1");
		objUserDataPaymentTaging.setAutoAcceptanceApplicable(0);
		objUserDataPaymentTaging.setBankChargeAmt(new Long(0));
		objUserDataPaymentTaging.setBankChargeArr(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objUserDataPaymentTaging.setBusinessChannelId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objUserDataPaymentTaging.setBusinessType(0); //receiptReq.getBussinessChannelType()-->string
		objUserDataPaymentTaging.setCallSLEnv("AP");
		objUserDataPaymentTaging.setCheckAutoProposal(1);
		objUserDataPaymentTaging.setCheckAutopayment(1);
		objUserDataPaymentTaging.setConcateInstrumentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objUserDataPaymentTaging.setConcateProposalNumbers(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objUserDataPaymentTaging.setCoverNoteNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objUserDataPaymentTaging.setCustomerName(receiptReq.getProposalDetails().getCustomerName()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getCustomerName());
		objUserDataPaymentTaging.setDealerId("0");
		objUserDataPaymentTaging.setDealerName(receiptReq.getDealerName()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getDealerName());
		objUserDataPaymentTaging.setDepartmentCode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objUserDataPaymentTaging.setDraweeBankBranch(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objUserDataPaymentTaging.setDraweeBankName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objUserDataPaymentTaging.setFinancierID("0");
		objUserDataPaymentTaging.setFinancierIDList(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objUserDataPaymentTaging.setFinancierName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objUserDataPaymentTaging.setGUIDWorkFlow("W"+receiptReq.getProposalDetails().getProposalSystemId()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:"W"+receiptReq.getProposalDetails().getProposalSystemId());
		objUserDataPaymentTaging.setGenPolicy(0); 
		objUserDataPaymentTaging.setHouseBankId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objUserDataPaymentTaging.setInstrumentAmount(0l); //NA, hardcoded elsewhere too
		objUserDataPaymentTaging.setInstrumentId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA, hardcoded elsewhere too
		objUserDataPaymentTaging.setInstrumentNo(receiptReq.getPaymentDetails().get(0).getInstrumentNo()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING: receiptReq.getPaymentDetails().get(0).getInstrumentNo()); 
		objUserDataPaymentTaging.setInstrumetDate(receiptReq.getPaymentDetails().get(0).getInstrumentDate()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING: receiptReq.getPaymentDetails().get(0).getInstrumentDate());
		objUserDataPaymentTaging.setIntermediaryId("0"); // NA, hardcoded elsewhere too
		objUserDataPaymentTaging.setIs64VbAllowed(false); //NA, false elsewhere 
		objUserDataPaymentTaging.setIsAutoPaymentChecked(false); //NA, false elsewhere
		objUserDataPaymentTaging.setIsAutoPropChecked(false); //NA, false elsewhere
		objUserDataPaymentTaging.setIsCreditPolicy(false); //NA, false elsewhere
		objUserDataPaymentTaging.setIsShortFallNonAllowedFlg(false); //NA, false elsewhere
		objUserDataPaymentTaging.setIsShortPremAllowedFlg(false); //NA, false elsewhere
		objUserDataPaymentTaging.setMIBLShortfallFlg(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA anywhere
		objUserDataPaymentTaging.setMaxPremium(0l); // NA , 0 elsewhere
		objUserDataPaymentTaging.setModeOfEntry(ReceiptConstants.ACCOUNTSERVICE_BGTAG); //NA, hardcoded elsewhere too
		objUserDataPaymentTaging.setMonthlyExtension(0); // NA, 0 elsewhere
		objUserDataPaymentTaging.setOfficeCode(receiptReq.getProposalDetails().getDepositOfficeCode()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getDepositOfficeCode());
		objUserDataPaymentTaging.setOfficeCodeUnmasked("90200"); // NA anywhere, default value provided in sample request
		objUserDataPaymentTaging.setOtherBankApplicability("0"); // NA , set 0 elsewhere
		objUserDataPaymentTaging.setOtherOffCd(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA anywhere
		objUserDataPaymentTaging.setPayerId(receiptReq.getProposalDetails().getCustomerId()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getCustomerId());
		objUserDataPaymentTaging.setPayerType("1"); // 1 elsewhere, other: 
		objUserDataPaymentTaging.setPaymentIds(paymntid); // NA
		objUserDataPaymentTaging.setPaymentInfo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA
		objUserDataPaymentTaging.setPaymentMode(ReceiptConstants.ACCOUNTSERVICE_PAYMENT_MODE_ONLINE); // available in adv rcpt too
		objUserDataPaymentTaging.setPaymentStatus(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA anywhere
		objUserDataPaymentTaging.setPaymentType(receiptReq.getPaymentDetails().get(0).getPaymentType()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getPaymentDetails().get(0).getPaymentType()); // -1 is set elsewhere
		objUserDataPaymentTaging.setPenaltyAmount(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA 
		objUserDataPaymentTaging.setPolicyNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // blank elsewhere
		objUserDataPaymentTaging.setPolicyStartDate(receiptReq.getProposalDetails().getPolicyEffDt()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getPolicyEffDt());
		objUserDataPaymentTaging.setProposalAmount(null);//receiptReq.getProposalDetails().getProposalAmount()==null?:receiptReq.getProposalDetails().getProposalAmount()
		objUserDataPaymentTaging.setProposalCustomerId(receiptReq.getProposalDetails().getCustomerId()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getCustomerId());
		objUserDataPaymentTaging.setProposalDate(receiptReq.getProposalDetails().getProposalDate()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getProposalDate());
		objUserDataPaymentTaging.setProposalDateD(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA
		objUserDataPaymentTaging.setProposalDates(propdate); // NA
		objUserDataPaymentTaging.setProposalId(receiptReq.getProposalDetails().getProposalNo()==null?"":receiptReq.getProposalDetails().getProposalNo());
		objUserDataPaymentTaging.setProposalNumbers(propnumber); // NA
		objUserDataPaymentTaging.setProposalUnPaidAmount(null); // NA 
		objUserDataPaymentTaging.setReceivedDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA
		objUserDataPaymentTaging.setServiceChannelId(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA
		objUserDataPaymentTaging.setSessionTransactionDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA
		objUserDataPaymentTaging.setSessionTransactionId(receiptReq.getPaymentDetails().get(0).getTransactionId()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getPaymentDetails().get(0).getTransactionId());
		objUserDataPaymentTaging.setShortPremium("0"); // same elsewhere
		objUserDataPaymentTaging.setTagSequence(0); // same elsewhere
		objUserDataPaymentTaging.setTotalInstrumentBalanceAmount(0l); // same elsewhere
		objUserDataPaymentTaging.setTransactionId(receiptReq.getProposalDetails().getProposalSystemId()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getProposalSystemId()); // as per elsewhere
		objUserDataPaymentTaging.setTransactionTime(sdf_transTime.format(dateFormat_PayTag));
		objUserDataPaymentTaging.setTypeOfBusiness(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA
		objUserDataPaymentTaging.setUserId(userId);
		objUserDataPaymentTaging.setWorkflowName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // same elsewhere
		
		ClsPolicyIdGrid objClsPolicyIdGrid = new ClsPolicyIdGrid();
		
		objClsPolicyIdGrid.setBankCharge("0"); // NA, same elsewhere
		objClsPolicyIdGrid.setBusinessChannelID("0"); // NA, same elsewhere
		objClsPolicyIdGrid.setCovernoteNumber(receiptReq.getCoverNoteNumber()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getCoverNoteNumber());
		objClsPolicyIdGrid.setCustomerName(receiptReq.getProposalDetails().getCustomerName()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getCustomerName());
		objClsPolicyIdGrid.setIsChecked(true); // same elsewhere
		objClsPolicyIdGrid.setPolicyNumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // blank elsewhere
		objClsPolicyIdGrid.setPolicyStartDate(receiptReq.getProposalDetails().getPolicyEffDt()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getPolicyEffDt());
		objClsPolicyIdGrid.setPropApplicationNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING); // NA
		objClsPolicyIdGrid.setPropCustId(receiptReq.getProposalDetails().getCustomerId()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getCustomerId());
		objClsPolicyIdGrid.setProposalAmount(receiptReq.getProposalDetails().getProposalAmount()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getProposalAmount());
		objClsPolicyIdGrid.setProposalDate(receiptReq.getProposalDetails().getProposalDate()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getProposalDate());
		objClsPolicyIdGrid.setProposalDateD("0");
		objClsPolicyIdGrid.setProposalNo(receiptReq.getProposalDetails().getProposalNo()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getProposalNo());
		objClsPolicyIdGrid.setRowNum(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPolicyIdGrid.setServiceChannelID(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPolicyIdGrid.setTransactionDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPolicyIdGrid.setUnpaidAmount(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		
		ArrayOfClsPolicyIdGrid arrOfClsPolicyIdGrid = new ArrayOfClsPolicyIdGrid();
		arrOfClsPolicyIdGrid.getClsPolicyIdGrid().add(objClsPolicyIdGrid);
		
		ClsPaymentIdGrid objClsPaymentIdGrid = new ClsPaymentIdGrid();
		
		objClsPaymentIdGrid.setApplicationNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setBalanceAmount(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setCDAccountNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setCollectionOffice(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setDepositBanktype(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setDraweeBankName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setDraweeBranchName(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setHomebank(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setHomebankList(homebank);
		objClsPaymentIdGrid.setIsChecked(true);
		objClsPaymentIdGrid.setModeofEntry(ReceiptConstants.ACCOUNTSERVICE_BGTAG);
		objClsPaymentIdGrid.setPayerID(receiptReq.getProposalDetails().getCustomerId()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getCustomerId());
		objClsPaymentIdGrid.setPayerName(receiptReq.getProposalDetails().getCustomerName()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getCustomerName());
		objClsPaymentIdGrid.setPayerType("1");
		objClsPaymentIdGrid.setPaymenID(receiptNo); // IMPP
		objClsPaymentIdGrid.setPaymentApplicationNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		
		Date payDate2=new Date();
		SimpleDateFormat sdfPay2=new SimpleDateFormat("dd/MM/yyyy", Locale.US);
		
		objClsPaymentIdGrid.setPaymentDate(sdfPay2.format(payDate2));
		objClsPaymentIdGrid.setPaymentMode(ReceiptConstants.ACCOUNTSERVICE_PAYMENT_MODE_ONLINE);
		objClsPaymentIdGrid.setPaymentNo(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setPaymentReceivedDate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setPaymentStatus(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setPolicynumber(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setProducerCd(receiptReq.getProducerCode()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProducerCode());
		objClsPaymentIdGrid.setProposalNumber(receiptReq.getProposalDetails().getProposalNo()==null?ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING:receiptReq.getProposalDetails().getProposalNo());
		objClsPaymentIdGrid.setRelationship(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setRowNum(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setSubreceiptamnt(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setSubreceiptblncamnt(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setSubreceiptcrtndate(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setSubreceiptno(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setSubreceiptoffccode(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		objClsPaymentIdGrid.setTagSequenceList(tag);
		objClsPaymentIdGrid.setTotalAmount(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING);
		ArrayOfClsPaymentIdGrid arrOfClsPaymentIdGrid = new ArrayOfClsPaymentIdGrid();
		arrOfClsPaymentIdGrid.getClsPaymentIdGrid().add(objClsPaymentIdGrid);
		
		objUserDataPaymentTaging.setClsPaymentDetailsGrd(arrOfClsPaymentIdGrid);
		objUserDataPaymentTaging.setClsProposalDetailsGrd(arrOfClsPolicyIdGrid);
		
		SOAPInfo soapInfo = new SOAPInfo();
		soapInfo.setTransactionID(Long.parseLong(receiptReq.getProcessTransId()));
		soapInfo.setLobService("ProposalTaggingcumpolicygenrationResult");
		soapInfo.setLobtype(receiptReq.getStrLOB());
		soapInfo.setCreatedBy(receiptReq.getUserID());
		soapInfo.setProducerCode(receiptReq.getProducerCode());
		soapInfo.setSystemIP(receiptReq.getSystemIP());
		soapInfo.setTransactionEvent(CommonConstants.POLICY_CREATION_EVENT);
		soapInfo.setJsonRequest(objMap.writeValueAsString(receiptReq));
		
		
		
		if(receiptReq.getProposalDetails()!=null)
			soapInfo.setProductCode(receiptReq.getProposalDetails().getProductCode());

		
		Client client=ClientProxy.getClient(accServClient);
		PrintWriter writer = new PrintWriter(System.out);
		
		client.getOutInterceptors().add(new CdataWriterInterceptor());
		client.getInInterceptors().add(new LoggingInInterceptor(writer));
		client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
		
		logger.info("Start::ProposalTaggingHandler::proposalTaggingServiceCall::Calling AccountService-->paymentEntryCumPolicyGenPortal::Entered");
		 responseProposalTagging = accServClient.proposalTaggingcumpolicygenration(prop.getProperty("smc.source"), prop.getProperty("smc.medium"), prop.getProperty("smc.campaign"),ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING, objUserDataPaymentTaging, arrOfKeyValueOfstringstringnew);
		 logger.info("End::ProposalTaggingHandler::proposalTaggingServiceCall::Calling AccountService-->paymentEntryCumPolicyGenPortal::end");
		  if(responseProposalTagging != null && responseProposalTagging.getErrorMsg() != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(responseProposalTagging.getErrorMsg()) 
				  && responseProposalTagging.getErrorMsg() != "-1"){
			  
	        	responseProposalTagging.setErrorMsg(responseProposalTagging.getErrorMsg()+""+CommonConstants.PROPOSAL_TAGGING_CUM_POLICY_GEN);
	        }
		}catch(Exception ex){
			//dbService.isErrorWhileSelfPayTrans(ex.toString(), proposalNumber, receiptReq.getUserId(), null);//Added For Issue ID 2505
			logger.error("Exception:::ProposalTaggingHandler::proposalTaggingServiceCall::Exit", ex);
			//response.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError error=new ResponseError();
			error.setErrorCode("ERR01");
			error.setErrorMMessag("Failed to call service !!");
			errorList.add(error);
			//response.setErrorList(errorList);
		}
		return responseProposalTagging;
	}

}

package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PendingPropListResponse extends ResultObject {

	List<PendingProposalLOVType> lovTypeList;
	private String declinedStatus;
	private String declinedStatusDesc;
	private String transactionType;
	
	

	public String getDeclinedStatusDesc() {
		return declinedStatusDesc;
	}

	public void setDeclinedStatusDesc(String declinedStatusDesc) {
		this.declinedStatusDesc = declinedStatusDesc;
	}

	public String getDeclinedStatus() {
		return declinedStatus;
	}

	public void setDeclinedStatus(String declinedStatus) {
		this.declinedStatus = declinedStatus;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public List<PendingProposalLOVType> getLovTypeList() {
		return lovTypeList;
	}

	public void setLovTypeList(List<PendingProposalLOVType> lovTypeList) {
		this.lovTypeList = lovTypeList;
	}
		
}

package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class RenewalCalCountResponse extends ResultObject {

	private ArrayList<RenewalCalCountData> renewalCalCountDataList;

	public ArrayList<RenewalCalCountData> getRenewalCalCountDataList() {
		return renewalCalCountDataList;
	}

	public void setRenewalCalCountDataList(
			ArrayList<RenewalCalCountData> renewalCalCountDataList) {
		this.renewalCalCountDataList = renewalCalCountDataList;
	}
}

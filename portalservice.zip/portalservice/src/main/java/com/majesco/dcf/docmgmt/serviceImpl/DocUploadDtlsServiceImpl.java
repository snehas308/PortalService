package com.majesco.dcf.docmgmt.serviceImpl;

import com.google.gson.Gson;
import com.majesco.dcf.common.tagic.entity.Product;
import com.majesco.dcf.common.tagic.json.CommunicationRequest;
import com.majesco.dcf.common.tagic.json.PortalLockDetails;
import com.majesco.dcf.common.tagic.json.ProposalStatus;
import com.majesco.dcf.common.tagic.json.ProposalStatusReq;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.TagicCommonService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.docmgmt.entity.CustDocUploadEntity;
import com.majesco.dcf.docmgmt.entity.DocUploadAuditDtlsEntity;
import com.majesco.dcf.docmgmt.entity.DocUploadDtlsEntity;
import com.majesco.dcf.docmgmt.entity.DocUploadOptn;
import com.majesco.dcf.docmgmt.entity.OmniDocUploadDtlsEntity;
import com.majesco.dcf.docmgmt.entity.ProducerLockDetails;
import com.majesco.dcf.docmgmt.json.CustDocUploadLinkReq;
import com.majesco.dcf.docmgmt.json.CustDocUploadLinkRes;
import com.majesco.dcf.docmgmt.json.DocSourceOptionReq;
import com.majesco.dcf.docmgmt.json.DocUploadDtlsObj;
import com.majesco.dcf.docmgmt.json.DocUploadDtlsRequest;
import com.majesco.dcf.docmgmt.json.DocUploadDtlsResponse;
import com.majesco.dcf.docmgmt.json.DocUploadOptionReq;
import com.majesco.dcf.docmgmt.json.DocUploadOptnResponse;
import com.majesco.dcf.docmgmt.json.DocUploadSearchObj;
import com.majesco.dcf.docmgmt.json.DocUploadSearchResponse;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsReq;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsRes;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsSearchReq;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsSearchRes;
import com.majesco.dcf.docmgmt.json.QCDecisionRequest;
import com.majesco.dcf.docmgmt.json.QCDecisionResponse;
import com.majesco.dcf.docmgmt.json.QCInspectionRequest;
import com.majesco.dcf.docmgmt.json.QCInspectionResponse;
import com.majesco.dcf.docmgmt.json.QCInspectionResult;
import com.majesco.dcf.docmgmt.service.DocUploadDtlsService;
import com.majesco.dcf.receipt.handler.ReceiptSelfPayLinkHandler;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.tika.Tika;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@Transactional
public class DocUploadDtlsServiceImpl implements DocUploadDtlsService {
	@Autowired
	DBService dbserv;
	@Autowired
	TagicCommunicationService commService;
	@Autowired
	TagicCommonService comServ;
	@Value("${docUploadPath}")
	private String docUploadPath;
	static final Logger logger = Logger
			.getLogger(DocUploadDtlsServiceImpl.class);
	private static String _strClassName = "DocUploadDtlsServiceImpl";

	private static Properties prop = new Properties();

	static {
		try {
			InputStream inputStream = ReceiptSelfPayLinkHandler.class
					.getClassLoader().getResourceAsStream(
							"resources.properties");
			prop.load(inputStream);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public DocUploadDtlsResponse saveDocUploadDtls(
			DocUploadDtlsRequest docUploadDtlsRequest, String propNo)
			throws Exception {
		logger.info("In DocUploadDtlsServiceImpl.saveDocUploadDtls() Method Begin()...");

		ObjectMapper objMap = new ObjectMapper();

		DocUploadDtlsResponse docUploadDtlsRes = new DocUploadDtlsResponse();
		DocUploadDtlsEntity docUploadDtlsEntity = new DocUploadDtlsEntity();
		List<DocUploadDtlsObj> docUploadDtlsObjLst = new ArrayList();
		DocUploadDtlsObj docUploadDtlsObj = new DocUploadDtlsObj();

		try {
			logger.info("In DocUploadDtlsServiceImpl.saveDocUploadDtls() Method :: "
					+ objMap.writeValueAsString(docUploadDtlsRequest));
			logger.info("In DocUploadDtlsServiceImpl.saveDocUploadDtls() :: About To Call DocUploadDtlsValue()... "
					+ docUploadDtlsRequest.getDocUploadDtlsObj().size());

			boolean _bSaveStatus = false;

			for (int i = 0; i < docUploadDtlsRequest.getDocUploadDtlsObj()
					.size(); i++) {

				docUploadDtlsEntity.setActiveStatus(Integer.valueOf(1));

				docUploadDtlsEntity.setStrProposalNo(propNo == null ? ""
						: propNo);

				if ((docUploadDtlsRequest.getDocUploadDtlsObj() != null)
						&& (((DocUploadDtlsObj) docUploadDtlsRequest
								.getDocUploadDtlsObj().get(i)).getPolicyNo() != null)
						&& (!((DocUploadDtlsObj) docUploadDtlsRequest
								.getDocUploadDtlsObj().get(i)).getPolicyNo()
								.equalsIgnoreCase(""))) {
					docUploadDtlsEntity
							.setStrPolicyNo(((DocUploadDtlsObj) docUploadDtlsRequest
									.getDocUploadDtlsObj().get(i))
									.getPolicyNo() == null ? ""
									: ((DocUploadDtlsObj) docUploadDtlsRequest
											.getDocUploadDtlsObj().get(i))
											.getPolicyNo());
				}

				docUploadDtlsEntity
						.setStrDocmodMapId(((DocUploadDtlsObj) docUploadDtlsRequest
								.getDocUploadDtlsObj().get(i)).getDocmodMapId() == null ? ""
								: ((DocUploadDtlsObj) docUploadDtlsRequest
										.getDocUploadDtlsObj().get(i))
										.getDocmodMapId());
				docUploadDtlsEntity
						.setStrDocIndex(((DocUploadDtlsObj) docUploadDtlsRequest
								.getDocUploadDtlsObj().get(i)).getDocIndex() == null ? ""
								: ((DocUploadDtlsObj) docUploadDtlsRequest
										.getDocUploadDtlsObj().get(i))
										.getDocIndex());
				docUploadDtlsEntity
						.setStrDocName(((DocUploadDtlsObj) docUploadDtlsRequest
								.getDocUploadDtlsObj().get(i)).getDocName() == null ? ""
								: ((DocUploadDtlsObj) docUploadDtlsRequest
										.getDocUploadDtlsObj().get(i))
										.getDocName());
				if ((((DocUploadDtlsObj) docUploadDtlsRequest
						.getDocUploadDtlsObj().get(i)).isMandatory() != null)
						&& (!((DocUploadDtlsObj) docUploadDtlsRequest
								.getDocUploadDtlsObj().get(i)).isMandatory()
								.equalsIgnoreCase(""))) {
					docUploadDtlsEntity
							.setBisMandatory(((DocUploadDtlsObj) docUploadDtlsRequest
									.getDocUploadDtlsObj().get(i))
									.isMandatory().equalsIgnoreCase("true"));
					
				}
				docUploadDtlsEntity.setStrIsRenew(docUploadDtlsRequest
						.getIsRenew() == null ? "" : docUploadDtlsRequest
						.getIsRenew());
				docUploadDtlsEntity.setStrOmniDocStatus("N");
				docUploadDtlsEntity
						.setStrCreatedBy(((DocUploadDtlsObj) docUploadDtlsRequest
								.getDocUploadDtlsObj().get(i)).getCreatedBy() == null ? ""
								: ((DocUploadDtlsObj) docUploadDtlsRequest
										.getDocUploadDtlsObj().get(i))
										.getCreatedBy());
				docUploadDtlsEntity.setDtCreated(new Date());
				/*docUploadDtlsEntity.setStrDocStatus("R");
				docUploadDtlsEntity.setStrUploadBy(((DocUploadDtlsObj) docUploadDtlsRequest
								.getDocUploadDtlsObj().get(i)).getCreatedBy() == null ? ""
								: ((DocUploadDtlsObj) docUploadDtlsRequest
										.getDocUploadDtlsObj().get(i))
										.getCreatedBy());
				docUploadDtlsEntity.setDtUpdated(new Date());*/
				_bSaveStatus = dbserv.saveDocUploadDtls(docUploadDtlsEntity);

				if (_bSaveStatus) {

					List<ResponseError> errorList = new ArrayList();

					docUploadDtlsRes.setResultCode("1");
					ResponseError err = new ResponseError();
					err.setErrorCode("NOERR");
					err.setErrorMMessag("NO ERROR");
					errorList.add(err);
					docUploadDtlsRes.setResponseError(errorList);

				} else {
					List<ResponseError> errorList = new ArrayList();

					docUploadDtlsRes.setResultCode("0");
					ResponseError err = new ResponseError();
					err.setErrorCode("ERR01");
					err.setErrorMMessag("Exception occurred while save DocUploadDtls into DB !!!");
					errorList.add(err);
					docUploadDtlsRes.setResponseError(errorList);
				}
			}
			logger.info("In DocUploadDtlsServiceImpl.saveDocUploadDtls() Method :: "
					+ objMap.writeValueAsString(docUploadDtlsRes));

		} catch (Exception e) {
			logger.error(
					"In DocUploadDtlsServiceImpl.saveDocUploadDtls() Method :: Exception StackTrace : ",
					e);
		}

		return docUploadDtlsRes;
	}

	public String nullCheckString(Object obj) {
		if (obj == null) {
			return "";
		}
		return (String) obj;
	}

	public boolean saveUploadedFiles(DocUploadDtlsObj docUploadDtlsObj)
			throws Exception {
		boolean isSave = true;
		boolean _bUpdateStatus = false;
		boolean _bSaveStatus = false;
		String strMethodName = "saveUploadedFiles";
		ObjectMapper objMap = new ObjectMapper();
		String fileName = null;
		Integer fileVersion = null;
		Path dirPath = null;
		Path filePath = null;
		String fileExtn = null;
		String fileSize = null;
		String contentType = null;

		logger.info("DocUploadDtlsServiceImpl :: " + strMethodName
				+ " Method Execution Begin()...");

		try {
			DocUploadDtlsEntity docUploadDtlsEntity = new DocUploadDtlsEntity();
			DocUploadAuditDtlsEntity docUploadAuditDtlsEntity = new DocUploadAuditDtlsEntity();
			docUploadDtlsEntity = dbserv.getDocUploadDtls(
					"com.majesco.dcf.docmgmt.entity.DocUploadDtlsEntity",
					docUploadDtlsObj);

			if ((docUploadDtlsEntity.getNversion() != null)
					&& (!docUploadDtlsEntity.getNversion().equals(""))) {
				fileVersion = Integer.valueOf(docUploadDtlsEntity.getNversion()
						.intValue() + 1);
			} else {
				fileVersion = Integer.valueOf(1);
			}

			for (MultipartFile file : docUploadDtlsObj.getFiles()) {
				if (!file.isEmpty()) {

					byte[] bytes = file.getBytes();
					fileName = file.getOriginalFilename();
					fileExtn = getFileExtension(fileName);
					fileSize = String.valueOf(file.getSize());
					logger.info("DocUploadDtlsServiceImpl :: " + strMethodName
							+ " Method :: fileExtn ::" + fileExtn
							+ " fileSize ::" + fileSize);

					Long timestamp = Long.valueOf(new Date().getTime());

					dirPath = Paths.get(
							docUploadPath + docUploadDtlsObj.getProposalNo()
									+ "/" + fileVersion, new String[0]);
					if (Files.notExists(dirPath, new LinkOption[0]))
						Files.createDirectories(dirPath, new FileAttribute[0]);
					logger.info("DocUploadDtlsServiceImpl :: dirPath ::"
							+ dirPath);

					filePath = Paths.get(
							dirPath + "/" + docUploadDtlsObj.getProposalNo()
									+ "_" + fileName, new String[0]);
					if (Files.notExists(filePath, new LinkOption[0]))
						Files.createFile(filePath, new FileAttribute[0]);
					Files.write(filePath, bytes, new OpenOption[0]);
					logger.info("DocUploadDtlsServiceImpl :: filePath ::"
							+ filePath);
				}
			}

			docUploadDtlsEntity.setStrDocPath(filePath.toString() == null ? ""
					: filePath.toString());
			docUploadDtlsEntity.setStrFileExt(fileExtn == null ? "" : fileExtn);
			docUploadDtlsEntity
					.setStrFileName(fileName == null ? "" : fileName);
			docUploadDtlsEntity
					.setStrFileSize(fileSize == null ? "" : fileSize);
			docUploadDtlsEntity.setStrFileType(contentType);
			docUploadDtlsEntity.setNversion(fileVersion);
			docUploadDtlsEntity.setUploadDate(new Date());
			docUploadDtlsEntity
					.setStrUploadBy(docUploadDtlsObj.getCreatedBy() == null ? ""
							: docUploadDtlsObj.getCreatedBy());
			docUploadDtlsEntity.setDtUpdated(new Date());
			docUploadDtlsEntity
					.setStrUpdatedBy(docUploadDtlsObj.getCreatedBy() == null ? ""
							: docUploadDtlsObj.getCreatedBy());
			docUploadDtlsEntity.setStrDocStatus("U");

			docUploadAuditDtlsEntity.setActiveStatus(Integer.valueOf(1));

			docUploadAuditDtlsEntity.setStrProposalNo(docUploadDtlsEntity
					.getStrProposalNo() == null ? "" : docUploadDtlsEntity
					.getStrProposalNo());
			docUploadAuditDtlsEntity.setStrPolicyNo(docUploadDtlsEntity
					.getStrPolicyNo() == null ? "" : docUploadDtlsEntity
					.getStrPolicyNo());
			docUploadAuditDtlsEntity.setStrDocmodMapId(docUploadDtlsEntity
					.getStrDocmodMapId() == null ? "" : docUploadDtlsEntity
					.getStrDocmodMapId());
			docUploadAuditDtlsEntity.setStrDocIndex(docUploadDtlsEntity
					.getStrDocIndex() == null ? "" : docUploadDtlsEntity
					.getStrDocIndex());
			docUploadAuditDtlsEntity.setStrDocName(docUploadDtlsEntity
					.getStrDocName() == null ? "" : docUploadDtlsEntity
					.getStrDocName());
			docUploadAuditDtlsEntity.setBisMandatory(docUploadDtlsEntity
					.isBisMandatory());

			docUploadAuditDtlsEntity.setStrCreatedBy(docUploadDtlsEntity
					.getStrCreatedBy() == null ? "" : docUploadDtlsEntity
					.getStrCreatedBy());
			docUploadAuditDtlsEntity.setDtCreated(new Date());
			docUploadAuditDtlsEntity
					.setStrDocPath(filePath.toString() == null ? "" : filePath
							.toString());
			docUploadAuditDtlsEntity.setStrFileExt(fileExtn == null ? ""
					: fileExtn);
			docUploadAuditDtlsEntity.setStrFileName(fileName == null ? ""
					: fileName);
			docUploadAuditDtlsEntity.setStrFileSize(fileSize == null ? ""
					: fileSize);

			docUploadAuditDtlsEntity.setStrFileType(contentType);
			docUploadAuditDtlsEntity.setNversion(fileVersion);
			docUploadAuditDtlsEntity.setUploadDate(new Date());
			docUploadAuditDtlsEntity.setStrUploadBy(docUploadDtlsObj
					.getCreatedBy() == null ? "" : docUploadDtlsObj
					.getCreatedBy());
			docUploadAuditDtlsEntity.setDtUpdated(new Date());
			docUploadAuditDtlsEntity.setStrUpdatedBy(docUploadDtlsObj
					.getCreatedBy() == null ? "" : docUploadDtlsObj
					.getCreatedBy());
			docUploadAuditDtlsEntity.setStrDocStatus("U");
			logger.info("DocUploadDtlsServiceImpl ::docUploadDtlsEntity.getNdocid()>>>>>>>>>" +docUploadDtlsEntity.getNdocid());
			if (docUploadDtlsEntity!=null||docUploadAuditDtlsEntity!=null) {
				_bSaveStatus = dbserv.saveDocUploadDtls(docUploadAuditDtlsEntity);
				logger.info("DocUploadDtlsServiceImpl :: " + strMethodName+ " Method :: dbserv.saveDocUploadDtls _bSaveStatus::"+ _bSaveStatus);
				_bUpdateStatus = dbserv.updateDocUploadDtls(docUploadDtlsEntity);
				logger.info("DocUploadDtlsServiceImpl :: "+ strMethodName+ " Method :: dbserv.updateDocUploadDtls _bUpdateStatus::"	+ _bUpdateStatus);
			}
			
			isSave = _bUpdateStatus;

		} catch (Exception e) {
			isSave = false;
			logger.error(
					"In DocUploadDtlsServiceImpl.saveDocUploadDtls() Method :: Exception StackTrace : ",
					e);
			e.printStackTrace();
		}

		logger.info("DocUploadDtlsServiceImpl :: " + strMethodName
				+ " Method Execution Completed()...");

		return isSave;
	}

	private String getFileExtension(String originalFilename) {
		String fileName = originalFilename;
		if ((fileName.lastIndexOf(".") != -1)
				&& (fileName.lastIndexOf(".") != 0))
			return fileName.substring(fileName.lastIndexOf(".") + 1);
		return "";
	}

	private static String getFileExtension(File file) {
		String fileName = file.getName();
		if ((fileName.lastIndexOf(".") != -1)
				&& (fileName.lastIndexOf(".") != 0))
			return fileName.substring(fileName.lastIndexOf(".") + 1);
		return "";
	}

	public QCInspectionResponse getDataForQCInspection(
			QCInspectionRequest qcInspectionRequest) throws Exception {
		QCInspectionResponse qcInspectionResponse = null;
		String strMethodName = "getDataForQCInspection";
		List lstQCInspectionRes = new ArrayList();
		ObjectMapper objMap = new ObjectMapper();
		DocUploadDtlsEntity docUploadDtlsEntity = null;
		QCInspectionResult qcInspectionResult = null;
		ArrayList<QCInspectionResult> lstQCInspectionResult = new ArrayList();
		try {
			logger.info("Inside " + _strClassName + "::" + strMethodName
					+ "::Entered");
			logger.info("Inside " + _strClassName + "::" + strMethodName
					+ "::Requested JSON String Is :: "
					+ objMap.writeValueAsString(qcInspectionRequest));

			lstQCInspectionRes = dbserv.getDataForQC(qcInspectionRequest);

			if ((lstQCInspectionRes != null) && (lstQCInspectionRes.size() > 0)) {
				qcInspectionResponse = new QCInspectionResponse();
				for (int i = 0; i < lstQCInspectionRes.size(); i++) {
					qcInspectionResult = new QCInspectionResult();
					docUploadDtlsEntity = new DocUploadDtlsEntity();
					docUploadDtlsEntity = (DocUploadDtlsEntity) lstQCInspectionRes
							.get(i);

					qcInspectionResult.setStrdocindex(docUploadDtlsEntity
							.getStrDocIndex() == null ? ""
							: docUploadDtlsEntity.getStrDocIndex());
					qcInspectionResult.setStrdocmodmapid(docUploadDtlsEntity
							.getStrDocmodMapId() == null ? ""
							: docUploadDtlsEntity.getStrDocmodMapId());
					qcInspectionResult.setStrdocname(docUploadDtlsEntity
							.getStrDocName() == null ? "" : docUploadDtlsEntity
							.getStrDocName());
					qcInspectionResult.setStrfileext(docUploadDtlsEntity
							.getStrFileExt() == null ? "" : docUploadDtlsEntity
							.getStrFileExt());
					qcInspectionResult.setStrfilename(docUploadDtlsEntity
							.getStrFileName() == null ? ""
							: docUploadDtlsEntity.getStrFileName());
					qcInspectionResult.setStrfilesize(docUploadDtlsEntity
							.getStrFileSize() == null ? ""
							: docUploadDtlsEntity.getStrFileSize());
					qcInspectionResult.setStrfiletype(docUploadDtlsEntity
							.getStrFileType() == null ? ""
							: docUploadDtlsEntity.getStrFileType());
					qcInspectionResult.setStrproposalnumber(docUploadDtlsEntity
							.getStrProposalNo() == null ? ""
							: docUploadDtlsEntity.getStrProposalNo());
					qcInspectionResult.setStrpolicynumber(docUploadDtlsEntity
							.getStrPolicyNo() == null ? ""
							: docUploadDtlsEntity.getStrPolicyNo());
					qcInspectionResult.setSeqid(docUploadDtlsEntity.getNdocid()
							+ "");
					qcInspectionResult.setStrdocstatus(docUploadDtlsEntity
							.getStrDocStatus() == null ? ""
							: docUploadDtlsEntity.getStrDocStatus());
					qcInspectionResult.setStrremarks(docUploadDtlsEntity
							.getStrRemarks() == null ? "" : docUploadDtlsEntity
							.getStrRemarks());

					lstQCInspectionResult.add(qcInspectionResult);
				}
				qcInspectionResponse
						.setLstQCInspectionResult(lstQCInspectionResult);
				qcInspectionResponse.setErrorCode("1");
				qcInspectionResponse.setErrorMMessag("NOERR");
			} else {
				qcInspectionResponse = new QCInspectionResponse();
				qcInspectionResponse
						.setLstQCInspectionResult(lstQCInspectionResult);
				qcInspectionResponse.setErrorCode("0");
				qcInspectionResponse.setErrorMMessag("No Data Found");
			}

			logger.info("Inside " + _strClassName + "::" + strMethodName
					+ "::Exit");
		} catch (Exception ex) {
			logger.error("Inside " + _strClassName + "::" + strMethodName
					+ "::Exception::", ex);
			qcInspectionResponse = new QCInspectionResponse();
			qcInspectionResponse.setErrorCode("0");
			qcInspectionResponse
					.setErrorMMessag("System Is Experiencing Issue, Please Try After Some Time.");
		}

		logger.info("Inside " + _strClassName + "::" + strMethodName
				+ ":: Response Sent to UI Is :"
				+ objMap.writeValueAsString(qcInspectionResponse));

		return qcInspectionResponse;
	}

	public DocUploadSearchResponse getUploadDocSearch(
			DocUploadSearchObj docSearchDtls) throws Exception {
		logger.info("In DocUploadDtlsServiceImpl.getUploadDocSearch() Method Begin()...");

		ObjectMapper objMap = new ObjectMapper();

		DocUploadSearchResponse docUploadSearchDtlsRes = new DocUploadSearchResponse();

		List<DocUploadDtlsObj> docUploadDtlsObjLst = new ArrayList();
		List<DocUploadDtlsEntity> docUploadDtlsEntities = null;

		try {
			logger.info("In DocUploadDtlsServiceImpl.getUploadDocSearch() Method :: "
					+ objMap.writeValueAsString(docSearchDtls));
			logger.info("In DocUploadDtlsServiceImpl.getUploadDocSearch() :: About To Call dbserv.getUploadDocSearch()... ");

			docUploadDtlsEntities = dbserv.getUploadDocSearch(docSearchDtls);

			for (int i = 0; i < docUploadDtlsEntities.size(); i++) {
				DocUploadDtlsObj docUploadDtlsObj = new DocUploadDtlsObj();
				DocUploadDtlsEntity docUploadDtlsEntity = (DocUploadDtlsEntity) docUploadDtlsEntities
						.get(i);
				if (docUploadDtlsEntity != null) {
					docUploadDtlsObj.setProposalNo(docUploadDtlsEntity
							.getStrProposalNo());
					docUploadDtlsObj.setPolicyNo(docUploadDtlsEntity
							.getStrPolicyNo() == null ? ""
							: docUploadDtlsEntity.getStrPolicyNo());
					docUploadDtlsObj.setDocmodMapId(docUploadDtlsEntity
							.getStrDocmodMapId() == null ? ""
							: docUploadDtlsEntity.getStrDocmodMapId());
					docUploadDtlsObj.setDocIndex(docUploadDtlsEntity
							.getStrDocIndex() == null ? ""
							: docUploadDtlsEntity.getStrDocIndex());
					docUploadDtlsObj.setMandatory(docUploadDtlsEntity
							.isBisMandatory() + "");
					docUploadDtlsObj.setCreatedBy(docUploadDtlsEntity
							.getStrCreatedBy() == null ? ""
							: docUploadDtlsEntity.getStrCreatedBy());
					docUploadDtlsObj.setDocName(docUploadDtlsEntity
							.getStrDocName() == null ? "" : docUploadDtlsEntity
							.getStrDocName());
					docUploadDtlsObj.setNdocid(docUploadDtlsEntity.getNdocid());
					docUploadDtlsObj.setStrSource(docUploadDtlsEntity
							.getStrsource());
					docUploadDtlsObjLst.add(docUploadDtlsObj);
				}
			}

			docUploadSearchDtlsRes.setDocUploadDtlsObj(docUploadDtlsObjLst);

			logger.info("In DocUploadDtlsServiceImpl.getUploadDocSearch() Method :: "
					+ objMap.writeValueAsString(docUploadSearchDtlsRes));

		} catch (Exception e) {
			logger.error(
					"In DocUploadDtlsServiceImpl.getUploadDocSearch() Method :: Exception StackTrace : ",
					e);
		}

		return docUploadSearchDtlsRes;
	}

	public DocUploadOptnResponse saveDocUploadOptn(
			DocUploadOptionReq docUploadOptnReq) throws Exception {
		logger.info("In DocUploadDtlsServiceImpl.saveDocUploadOptn() Method Begin()...");
		DocUploadOptnResponse docUploadOptnResponse = null;
		try {
			docUploadOptnResponse = new DocUploadOptnResponse();
			DocUploadOptn docUploadOptn = new DocUploadOptn();
			docUploadOptn.setStrproposalno(docUploadOptnReq.getProposalNo());
			docUploadOptn.setStrpolicyno(docUploadOptnReq.getPolicyNo());
			docUploadOptn.setStroption(docUploadOptnReq.getOption());
			docUploadOptn.setDtCreated(new Date());

			docUploadOptn.setStrCreatedBy(docUploadOptnReq.getUserID());
			docUploadOptn.setStrUpdatedBy(docUploadOptnReq.getUserID());
			boolean isSave = dbserv.saveDocUploadOptn(docUploadOptn);
			docUploadOptnResponse.setSuccessFlag(Boolean.valueOf(isSave));
		} catch (Exception e) {
			logger.error(
					"In DocUploadDtlsServiceImpl.saveDocUploadOptn() Method :: Exception StackTrace : ",
					e);
		}
		return docUploadOptnResponse;
	}

	public QCDecisionResponse updateDataForQCInspection(
			QCDecisionRequest qcDecisionRequest) throws Exception {
		QCDecisionResponse qcDecisionResponse = null;
		String strMethodName = "updateDataForQCInspection";
		ObjectMapper objMap = new ObjectMapper();
		DocUploadDtlsEntity docUploadDtlsEntity = null;
		QCInspectionResult qcInspectionResult = null;
		ArrayList<QCInspectionResult> lstQCInspectionResult = new ArrayList();
		HashMap<String, Boolean> mapIsSuccessful = new HashMap();
		boolean _bUpdateStatus = false;
		try {
			logger.info("Inside " + _strClassName + " :: " + strMethodName
					+ " ::Entered");
			logger.info("Inside " + _strClassName + " :: " + strMethodName
					+ " ::Requested JSON String Is :: "
					+ objMap.writeValueAsString(qcDecisionRequest));

			if ((qcDecisionRequest != null)
					&& (qcDecisionRequest.getLstQCInspectionResult() != null)
					&& (qcDecisionRequest.getLstQCInspectionResult().size() > 0)) {
				lstQCInspectionResult = qcDecisionRequest
						.getLstQCInspectionResult();
			}
			if ((lstQCInspectionResult != null)
					&& (lstQCInspectionResult.size() > 0)) {
				qcDecisionResponse = new QCDecisionResponse();

				for (int i = 0; i < lstQCInspectionResult.size(); i++) {
					qcInspectionResult = (QCInspectionResult) lstQCInspectionResult
							.get(i);
					docUploadDtlsEntity = new DocUploadDtlsEntity();
					docUploadDtlsEntity = dbserv
							.getDocUploadDtlsBySeqID(
									"com.majesco.dcf.docmgmt.entity.DocUploadDtlsEntity",
									qcInspectionResult.getSeqid());

					docUploadDtlsEntity.setUploadDate(new Date());
					docUploadDtlsEntity.setStrUpdatedBy(qcDecisionRequest
							.getUserID());
					docUploadDtlsEntity.setStrDocStatus(qcInspectionResult
							.getStrdocstatus());
					docUploadDtlsEntity.setStrRemarks(qcInspectionResult
							.getStrremarks());
					_bUpdateStatus = dbserv
							.updateDocUploadDtls(docUploadDtlsEntity);
					if ((qcInspectionResult.getStrdocstatus() != null)
							&& (qcInspectionResult.getStrdocstatus()
									.equalsIgnoreCase("A"))) {
						OmniDocUploadDtlsEntity omniDocUploadDtlsEntity = null;
						omniDocUploadDtlsEntity = transformDocToOmni(docUploadDtlsEntity);
						dbserv.saveDocUploadDtls(omniDocUploadDtlsEntity);
					}
					mapIsSuccessful.put(qcInspectionResult.getSeqid(),
							Boolean.valueOf(_bUpdateStatus));
					logger.info("DocUploadDtlsServiceImpl :: "
							+ strMethodName
							+ " Method :: dbserv.updateDataForQCInspection _bUpdateStatus::"
							+ _bUpdateStatus);
				}

				qcDecisionResponse.setMapIsSuccessful(mapIsSuccessful);
				qcDecisionResponse.setErrorCode("1");
				qcDecisionResponse.setErrorMMessag("NOERR");
			} else {
				qcDecisionResponse.setMapIsSuccessful(null);
				qcDecisionResponse.setErrorCode("0");
				qcDecisionResponse
						.setErrorMMessag("System Is Experiencing Issue, Please Try After Some Time.");
			}

			logger.info("Inside " + _strClassName + " :: " + strMethodName
					+ " :: Exit");
		} catch (Exception ex) {
			logger.error("Inside " + _strClassName + "::" + strMethodName
					+ "::Exception::", ex);
			qcDecisionResponse = new QCDecisionResponse();
			qcDecisionResponse.setErrorCode("0");
			qcDecisionResponse
					.setErrorMMessag("System Is Experiencing Issue, Please Try After Some Time.");
		}

		logger.info("Inside " + _strClassName + "::" + strMethodName
				+ ":: Response Sent to UI Is :"
				+ objMap.writeValueAsString(qcDecisionResponse));

		return qcDecisionResponse;
	}

	public byte[] getRequestedDocument(QCInspectionRequest qcInspectionRequest,
			HttpServletResponse httpServletResponse) throws Exception {
		String strMethodName = "getRequestedDocument";
		ObjectMapper objMap = new ObjectMapper();
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		File file = null;
		String strFilePath = null;
		DocUploadDtlsEntity docUploadDtlsEntity = null;
		String strFilename = null;
		byte[] buff = null;
		String contentType = "Undetermined";
		Tika tika = new Tika();
		try {
			logger.info("Inside " + _strClassName + " :: " + strMethodName
					+ " ::Entered");
			logger.info("Inside " + _strClassName + " :: " + strMethodName
					+ " ::Requested JSON String Is :: "
					+ objMap.writeValueAsString(qcInspectionRequest));

			if ((qcInspectionRequest != null)
					&& (qcInspectionRequest.getSeqID() != null)
					&& (!qcInspectionRequest.getSeqID().equals(""))) {
				docUploadDtlsEntity = dbserv.getDocUploadDtlsBySeqID(
						"com.majesco.dcf.docmgmt.entity.DocUploadDtlsEntity",
						qcInspectionRequest.getSeqID());

				if (docUploadDtlsEntity != null) {
					strFilename = docUploadDtlsEntity.getStrFileName();
					strFilePath = docUploadDtlsEntity.getStrDocPath();

					file = new File(strFilePath);

					if ((strFilename != null) && (!strFilename.equals(""))
							&& (file.exists())) {
						bis = new BufferedInputStream(new FileInputStream(file));
						httpServletResponse.setContentLength((int) file
								.length());

						ServletOutputStream outs = httpServletResponse
								.getOutputStream();

						contentType = tika.detect(file);
						logger.info("Inside " + _strClassName + " :: "
								+ strMethodName
								+ " :: Content Type Value Is :: " + contentType);
						httpServletResponse.setContentType(contentType);
						httpServletResponse.setHeader("Content-Disposition",
								"attachment;filename=\"" + strFilename + "\"");

						bos = new BufferedOutputStream(outs);
						buff = new byte['Ѐ'];
						int bytesRead;
						while (-1 != (bytesRead = bis
								.read(buff, 0, buff.length))) {
							bos.write(buff, 0, bytesRead);
						}
					}
				}
			}

			logger.info("Inside " + _strClassName + " :: " + strMethodName
					+ " :: Exit");
		} catch (Exception ex) {
			logger.error("Inside " + _strClassName + " :: " + strMethodName
					+ " :: Exception::", ex);
		} finally {
			if (bis != null) {
				bis.close();
			}
			if (bos != null) {
				bos.flush();
				bos.close();
			}
		}
		return buff;
	}

	public boolean saveUploadedMultiFiles(
			DocUploadDtlsRequest docUploadDtlsRequest) throws Exception {
		boolean isSave = true;
		boolean _bUpdateStatus = false;
		boolean _bSaveStatus = false;
		String strMethodName = "saveUploadedMultiFiles";
		ObjectMapper objMap = new ObjectMapper();
		String fileName = null;
		Integer fileVersion = null;
		Path dirPath = null;
		Path filePath = null;
		String fileExtn = null;
		String fileSize = null;
		String contentType = null;

		logger.info("DocUploadDtlsServiceImpl :: " + strMethodName
				+ " Method Execution Begin()...");

		try {
			DocUploadDtlsEntity docUploadDtlsEntity = new DocUploadDtlsEntity();
			DocUploadAuditDtlsEntity docUploadAuditDtlsEntity = new DocUploadAuditDtlsEntity();

			if (docUploadDtlsRequest.getDocUploadDtlsObj() != null) {
				for (int i = 0; i < docUploadDtlsRequest.getDocUploadDtlsObj()
						.size(); i++) {
					docUploadDtlsEntity = new DocUploadDtlsEntity();
					docUploadAuditDtlsEntity = new DocUploadAuditDtlsEntity();

					docUploadDtlsEntity = dbserv
							.getDocUploadDtls(
									"com.majesco.dcf.docmgmt.entity.DocUploadDtlsEntity",
									(DocUploadDtlsObj) docUploadDtlsRequest
											.getDocUploadDtlsObj().get(i));

					if ((docUploadDtlsEntity.getNversion() != null)
							&& (!docUploadDtlsEntity.getNversion().equals(""))) {
						fileVersion = Integer.valueOf(docUploadDtlsEntity
								.getNversion().intValue() + 1);
					} else {
						fileVersion = Integer.valueOf(1);
					}

					for (MultipartFile file : ((DocUploadDtlsObj) docUploadDtlsRequest
							.getDocUploadDtlsObj().get(i)).getFiles()) {
						if (!file.isEmpty()) {

							byte[] bytes = file.getBytes();
							fileName = file.getOriginalFilename();
							fileExtn = getFileExtension(fileName);
							fileSize = String.valueOf(file.getSize());
							logger.info("DocUploadDtlsServiceImpl :: "
									+ strMethodName + " Method :: fileExtn ::"
									+ fileExtn + " fileSize ::" + fileSize);

							Long timestamp = Long.valueOf(new Date().getTime());

							dirPath = Paths
									.get(docUploadPath
											+ ((DocUploadDtlsObj) docUploadDtlsRequest
													.getDocUploadDtlsObj().get(
															i)).getProposalNo()
											+ "/" + fileVersion, new String[0]);
							if (Files.notExists(dirPath, new LinkOption[0]))
								Files.createDirectories(dirPath,
										new FileAttribute[0]);
							logger.info("DocUploadDtlsServiceImpl :: dirPath ::"
									+ dirPath);

							filePath = Paths
									.get(dirPath
											+ "/"
											+ ((DocUploadDtlsObj) docUploadDtlsRequest
													.getDocUploadDtlsObj().get(
															i)).getProposalNo()
											+ "_" + fileName, new String[0]);
							if (Files.notExists(filePath, new LinkOption[0]))
								Files.createFile(filePath, new FileAttribute[0]);
							Files.write(filePath, bytes, new OpenOption[0]);
							logger.info("DocUploadDtlsServiceImpl :: filePath ::"
									+ filePath);
						}
					}

					docUploadDtlsEntity
							.setStrDocPath(filePath.toString() == null ? ""
									: filePath.toString());
					docUploadDtlsEntity.setStrFileExt(fileExtn == null ? ""
							: fileExtn);
					docUploadDtlsEntity.setStrFileName(fileName == null ? ""
							: fileName);
					docUploadDtlsEntity.setStrFileSize(fileSize == null ? ""
							: fileSize);
					docUploadDtlsEntity.setStrFileType(contentType);
					docUploadDtlsEntity.setNversion(fileVersion);
					docUploadDtlsEntity.setUploadDate(new Date());
					docUploadDtlsEntity
							.setStrUploadBy(((DocUploadDtlsObj) docUploadDtlsRequest
									.getDocUploadDtlsObj().get(i))
									.getCreatedBy() == null ? ""
									: ((DocUploadDtlsObj) docUploadDtlsRequest
											.getDocUploadDtlsObj().get(i))
											.getCreatedBy());
					docUploadDtlsEntity.setDtUpdated(new Date());
					docUploadDtlsEntity
							.setStrUpdatedBy(((DocUploadDtlsObj) docUploadDtlsRequest
									.getDocUploadDtlsObj().get(i))
									.getCreatedBy() == null ? ""
									: ((DocUploadDtlsObj) docUploadDtlsRequest
											.getDocUploadDtlsObj().get(i))
											.getCreatedBy());
					docUploadDtlsEntity.setStrDocStatus("U");

					docUploadAuditDtlsEntity
							.setActiveStatus(Integer.valueOf(1));

					docUploadAuditDtlsEntity
							.setStrProposalNo(docUploadDtlsEntity
									.getStrProposalNo() == null ? ""
									: docUploadDtlsEntity.getStrProposalNo());
					docUploadAuditDtlsEntity.setStrPolicyNo(docUploadDtlsEntity
							.getStrPolicyNo() == null ? ""
							: docUploadDtlsEntity.getStrPolicyNo());
					docUploadAuditDtlsEntity
							.setStrDocmodMapId(docUploadDtlsEntity
									.getStrDocmodMapId() == null ? ""
									: docUploadDtlsEntity.getStrDocmodMapId());
					docUploadAuditDtlsEntity.setStrDocIndex(docUploadDtlsEntity
							.getStrDocIndex() == null ? ""
							: docUploadDtlsEntity.getStrDocIndex());
					docUploadAuditDtlsEntity.setStrDocName(docUploadDtlsEntity
							.getStrDocName() == null ? "" : docUploadDtlsEntity
							.getStrDocName());
					docUploadAuditDtlsEntity
							.setBisMandatory(docUploadDtlsEntity
									.isBisMandatory());

					docUploadAuditDtlsEntity
							.setStrCreatedBy(docUploadDtlsEntity
									.getStrCreatedBy() == null ? ""
									: docUploadDtlsEntity.getStrCreatedBy());
					docUploadAuditDtlsEntity.setDtCreated(new Date());
					docUploadAuditDtlsEntity
							.setStrDocPath(filePath.toString() == null ? ""
									: filePath.toString());
					docUploadAuditDtlsEntity
							.setStrFileExt(fileExtn == null ? "" : fileExtn);
					docUploadAuditDtlsEntity
							.setStrFileName(fileName == null ? "" : fileName);
					docUploadAuditDtlsEntity
							.setStrFileSize(fileSize == null ? "" : fileSize);
					docUploadDtlsEntity.setStrFileType(contentType);
					docUploadAuditDtlsEntity.setNversion(fileVersion);
					docUploadAuditDtlsEntity.setUploadDate(new Date());
					docUploadAuditDtlsEntity
							.setStrUploadBy(((DocUploadDtlsObj) docUploadDtlsRequest
									.getDocUploadDtlsObj().get(i))
									.getCreatedBy() == null ? ""
									: ((DocUploadDtlsObj) docUploadDtlsRequest
											.getDocUploadDtlsObj().get(i))
											.getCreatedBy());
					docUploadAuditDtlsEntity.setDtUpdated(new Date());
					docUploadAuditDtlsEntity
							.setStrUpdatedBy(((DocUploadDtlsObj) docUploadDtlsRequest
									.getDocUploadDtlsObj().get(i))
									.getCreatedBy() == null ? ""
									: ((DocUploadDtlsObj) docUploadDtlsRequest
											.getDocUploadDtlsObj().get(i))
											.getCreatedBy());
					docUploadAuditDtlsEntity.setStrDocStatus("U");

					if ((docUploadDtlsEntity != null)
							|| (docUploadAuditDtlsEntity != null)) {
						_bSaveStatus = dbserv
								.saveDocUploadDtls(docUploadAuditDtlsEntity);
						logger.info("DocUploadDtlsServiceImpl :: "
								+ strMethodName
								+ " Method :: dbserv.saveDocUploadDtls _bSaveStatus::"
								+ _bSaveStatus);
						_bUpdateStatus = dbserv
								.updateDocUploadDtls(docUploadDtlsEntity);
						logger.info("DocUploadDtlsServiceImpl :: "
								+ strMethodName
								+ " Method :: dbserv.updateDocUploadDtls _bUpdateStatus::"
								+ _bUpdateStatus);
					}
					isSave = _bUpdateStatus;
				}

			}

		} catch (Exception e) {
			isSave = false;
			logger.error("DocUploadDtlsServiceImpl :: " + strMethodName
					+ " :: Exception StackTrace : ", e);
			e.printStackTrace();
		}
		logger.info("DocUploadDtlsServiceImpl :: " + strMethodName
				+ " Method Execution Completed()...");
		return isSave;
	}

	public CustDocUploadLinkRes sendCustDocUploadLink(
			CustDocUploadLinkReq custDocUploadLinkReq) throws Exception {
		CustDocUploadLinkRes response = new CustDocUploadLinkRes();
		ObjectMapper objMap = new ObjectMapper();
		String customerName = null;
		String custLinkUrl = null;
		String strEmail = null;
		String strMobile = null;
		CustDocUploadEntity entity = new CustDocUploadEntity();
		String orderID = null;
		try {
			logger.info("Input::DocUploadDtlsServiceImpl::sendCustDocUploadLink::"
					+ objMap.writeValueAsString(custDocUploadLinkReq));
			String userId = custDocUploadLinkReq.getUserID();

			String link_used = "0";
			String uploadURL = prop.getProperty("CUST_DOC_UPLOAD_URL");
			logger.info("uploadURL----------------------------------->>>>>>>>>>>>>>>>>>>>>" + uploadURL);
			strEmail = custDocUploadLinkReq.getEmailId();

			String currentDateInString = new SimpleDateFormat(
					CommonConstants.UNIQUE_SEQUENCE_PG).format(new Date());
			Random rand = new Random();
			int randomNo = rand.nextInt(1000);
			orderID = CommonConstants.CUST_DOC_PREFIX + currentDateInString
					+ randomNo;
			logger.info("orderID----------------------------------->>>>>>>>>>>>>>>>>>>>>" + orderID);

			custLinkUrl = uploadURL + orderID;
			logger.info("custLinkUrl----------------------------------->>>>>>>>>>>>>>>>>>>>>" + custLinkUrl);
			customerName = custDocUploadLinkReq.getCustomerName();
			entity.setCustlinkURL(custLinkUrl);
			entity.setTransId(orderID);
			entity.setCustomerId(custDocUploadLinkReq.getCustomerId());
			entity.setPropPolNbr(custDocUploadLinkReq.getProposalNo());
			entity.setEmail(custDocUploadLinkReq.getEmailId());
			entity.setMobile(custDocUploadLinkReq.getMobileNo());
			entity.setProposalAmount(Double.parseDouble(custDocUploadLinkReq
					.getProposalAmount()));
			entity.setProductCd(custDocUploadLinkReq.getProductCode());
			entity.setProducerCd(custDocUploadLinkReq.getProducerCode());
			entity.setStatus("1");
			entity.setDtCreated(new Date());
			entity.setCreatedby(custDocUploadLinkReq.getUserID());
			entity.setCustLinkUsed("0");
			entity.setProducerName(custDocUploadLinkReq.getProducerName());
			entity.setCustomerName(customerName);
			entity.setVegRegNo(custDocUploadLinkReq.getVehRegNo());
			entity.setPlanName(custDocUploadLinkReq.getPlanName());
			dbserv.saveOrUpdate(entity);

			if (logger.isDebugEnabled()) {
				logger.debug("In DocUploadDtlsServiceImpl :sendCustDocUploadLink: EMAIL ID $$$$$$$$$$$$$$$$$$ ::: "
						+ custDocUploadLinkReq.getEmailId());
			}
			CommunicationRequest commRequest = new CommunicationRequest();
			commRequest.setAlertType("EMAIL");
			commRequest.setEventType("CUST_DOC_UPLOAD_LINK");
			commRequest.setReceipient(custDocUploadLinkReq.getEmailId());
			commRequest.setParam1(customerName);
			commRequest.setParam2(custDocUploadLinkReq.getProposalNo());
			commRequest
					.setParam3(custDocUploadLinkReq.getProductLine() == null ? "NA"
							: custDocUploadLinkReq.getProductLine());
			commRequest
					.setParam4(custDocUploadLinkReq.getPlanName() == null ? "NA"
							: custDocUploadLinkReq.getPlanName());
			commRequest.setParam5(custDocUploadLinkReq.getProposalAmount());
			commRequest.setParam6(custDocUploadLinkReq.getProducerName());
			commRequest.setParam7(custDocUploadLinkReq.getProducerCode());
			commRequest
					.setParam8(custDocUploadLinkReq.getPolicyEffDt() == null ? ""
							: custDocUploadLinkReq.getPolicyEffDt());
			commRequest
					.setParam9(custDocUploadLinkReq.getPolicyEndDt() == null ? ""
							: custDocUploadLinkReq.getPolicyEndDt());
			commRequest.setParam10(customerName);
			commRequest.setParam11(custLinkUrl.trim());
			
			commRequest
					.setParam12(custDocUploadLinkReq.getProductLine() == null ? "NA"
							: custDocUploadLinkReq.getProductLine());
			commRequest.setParam13(custDocUploadLinkReq.getProducerName());
			commRequest
					.setParam14(custDocUploadLinkReq.getProducerMobile() == null ? "1800 - 266 - 7780"
							: custDocUploadLinkReq.getProducerMobile());
			//commRequest.setParam15(custLinkUrl.trim());
			commRequest.setProductCode(custDocUploadLinkReq.getProductCode());
			commRequest.setProducerEmail(custDocUploadLinkReq
					.getProducerEmail());
			commRequest.setUserID(custDocUploadLinkReq.getUserID());
			commRequest.setPassword(custDocUploadLinkReq.getPassword());
			if (logger.isDebugEnabled())
				logger.debug("In DocUploadDtlsServiceImpl :EmailRequestObj :- $$$$$$$$$$$$$$$$$$ ::: "
						+ objMap.writeValueAsString(commRequest));
			commService.sendCommunication(commRequest);

			CommunicationRequest commRequestSMS = new CommunicationRequest();

			commRequestSMS.setAlertType("SMS");
			commRequestSMS.setEventType("CUST_DOC_UPLOAD_LINK");
			commRequestSMS.setReceipient(custDocUploadLinkReq.getMobileNo());
			commRequestSMS.setParam1(customerName);
			commRequestSMS.setParam2(custLinkUrl);
			commRequestSMS
					.setParam3(custDocUploadLinkReq.getProductLine() == null ? "NA"
							: custDocUploadLinkReq.getProductLine());
			commRequestSMS.setParam4(custDocUploadLinkReq.getProposalNo());
			commRequestSMS.setParam5(custDocUploadLinkReq.getProposalAmount());
			commRequestSMS.setParam6(custDocUploadLinkReq.getProducerName());
			commRequestSMS
					.setParam7(custDocUploadLinkReq.getProducerMobile() == null ? "1800 - 266 - 7780"
							: custDocUploadLinkReq.getProducerMobile());
			commRequest.setUserID(custDocUploadLinkReq.getUserID());
			commRequest.setPassword(custDocUploadLinkReq.getPassword());
			commService.sendCommunication(commRequestSMS);
			response.setErrorCode("0");
			response.setSuccessFlag(Boolean.valueOf(true));
		} catch (Exception ex) {
			logger.error(
					"Exception ::DocUploadDtlsServiceImpl::sendCustDocUploadLink::Exit",
					ex);
			response.setErrorCode("1");
			List<ResponseError> errorList = new ArrayList();
			ResponseError error = new ResponseError();
			error.setErrorCode("ERR01");
			error.setErrorMMessag("Failed to call service !!."
					+ ex.getMessage() + ".Transaction ID " + orderID);
			errorList.add(error);
			response.setErrorMMessag("Failed to call service !!."
					+ ex.getMessage() + ".Transaction ID " + orderID);
			ex.printStackTrace();
		}
		return null;
	}

	public PortalLockDetails portalLockForDocument(UserObject userObjectReq)
			throws Exception {
		String strMethodName = "portalLockForDocument";

		logger.info("In " + _strClassName + " :: " + strMethodName + " method");

		int dateDiffProducer = 0;
		int producerLimit = 0;
		int qcUserLimit = 0;
		int producerCount = 0;
		int qcUserCount = 0;
		ObjectMapper objMap2 = new ObjectMapper();
		PortalLockDetails portalLockDtl = new PortalLockDetails();
		String DOCUPLDUSERLIMIT = null;
		String DOCUPLDQCUSERLIMIT = null;
		List<DocUploadOptn> lstDocUploadOptn = new ArrayList();
		List<DocUploadDtlsEntity> lstDocUploadDtlsEntity = new ArrayList();
		DocUploadOptn docUploadOptn = null;
		Date dtObtained = null;
		Date dtCurrent = new Date();
		DocUploadDtlsEntity docUploadDtlsEntity = new DocUploadDtlsEntity();
		String tempMsg = null;

		if (logger.isDebugEnabled()) {
			logger.debug("Inside " + _strClassName + " :: " + strMethodName
					+ " :: Request Received From UI JSON : "
					+ objMap2.writeValueAsString(userObjectReq));
		}

		try {
			DOCUPLDUSERLIMIT = dbserv.getConfigParamVal("DOCUPLDUSERLIMIT");
			DOCUPLDQCUSERLIMIT = dbserv.getConfigParamVal("DOCUPLDQCUSERLIMIT");

			if ((DOCUPLDUSERLIMIT != null) && (DOCUPLDQCUSERLIMIT != null)) {
				producerLimit = Integer.parseInt(DOCUPLDUSERLIMIT);
				qcUserLimit = Integer.parseInt(DOCUPLDQCUSERLIMIT);

				dtObtained = dbserv.checkProducerDocumentLock(
						"com.majesco.dcf.docmgmt.entity.DocUploadOptn",
						userObjectReq.getProducerCode());
				dtObtained = getZeroTimeDate(dtObtained);
				if (logger.isDebugEnabled())
					logger.debug("Inside " + _strClassName + " :: "
							+ strMethodName + " :Producer Lock: DtObtained"
							+ dtObtained);
				if (dtObtained != null) {
					dateDiffProducer = 0;
					dtCurrent = getZeroTimeDate(dtCurrent);
					dateDiffProducer = getDifferenceDays(dtCurrent, dtObtained);
					if (logger.isDebugEnabled())
						logger.debug("Inside " + _strClassName + " :: "
								+ strMethodName + " dateDiffProducer "
								+ dateDiffProducer);
					if (dateDiffProducer >= producerLimit) {
						producerCount++;
					}
					if (logger.isDebugEnabled()) {
						logger.debug("Inside " + _strClassName + " :: "
								+ strMethodName + " producerCount "
								+ producerCount);
					}
				}
				dtObtained = null;

				dtObtained = dbserv.checkQCProducerDocumentLock(
						"com.majesco.dcf.docmgmt.entity.DocUploadDtlsEntity",
						userObjectReq.getProducerCode());
				if (logger.isDebugEnabled())
					logger.debug("Inside " + _strClassName + " :: "
							+ strMethodName + " :QC User Lock: DtObtained"
							+ dtObtained);
				if (dtObtained != null) {
					dateDiffProducer = 0;
					dateDiffProducer = getDifferenceDays(dtCurrent, dtObtained);
					if (logger.isDebugEnabled())
						logger.debug("Inside " + _strClassName + " :: "
								+ strMethodName + " QCdateDiffProducer "
								+ dateDiffProducer);
					if (dateDiffProducer >= qcUserLimit) {
						qcUserCount++;
					}
					if (logger.isDebugEnabled()) {
						logger.debug("Inside " + _strClassName + " :: "
								+ strMethodName + " producerCount "
								+ qcUserCount);
					}
				}
			}
			if ((producerCount > 0) && (qcUserCount > 0)) {
				portalLockDtl.setPortalLock(true);
				portalLockDtl
						.setMessage("Please Upload Your Pending Documents to enable Proceed to Pay, Which Were In UPLOAD LATER Status And Which Were Rejected By QC Team.");
			} else if (producerCount > 0) {
				portalLockDtl.setPortalLock(true);
				portalLockDtl
						.setMessage("Please Upload Your Pending Documents to enable Proceed to Pay, Which Were Opted By You As UPLOAD LATER.");
			} else if (qcUserCount > 0) {
				portalLockDtl.setPortalLock(true);
				portalLockDtl
						.setMessage("Please Upload Documents Again to enable Proceed to Pay, Which Were Rejected By QC Team.");
			} else {
				portalLockDtl.setPortalLock(false);
				portalLockDtl.setMessage("NOERR");
			}

			logger.info("Out " + _strClassName + " :: " + strMethodName
					+ " method");

		} catch (Exception e) {
			logger.error("Inside Exception " + _strClassName + " :: "
					+ strMethodName + " method :- " + e);
			e.printStackTrace();
		}
		ObjectMapper obj = new ObjectMapper();
		logger.info("Inside Exception " + _strClassName + " :: "
				+ strMethodName + " :: Response To Send UI JSON : "
				+ obj.writeValueAsString(portalLockDtl));
		return portalLockDtl;
	}

	public static Date calculateDays(Date date, int days) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		cal.add(5, -days);

		return cal.getTime();
	}

	public static int getDifferenceDays(Date d1, Date d2) {
		long diff = d1.getTime() - d2.getTime();
		return (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	}

	public Map<String, String> getUploadDocDetails(String transactionID)
			throws Exception {
		Map reqDocUploadMap = new HashMap();
		Map<String, String> resultMap = new HashMap();
		ObjectMapper objMapper = new ObjectMapper();
		HashMap<String, String> resultAccService = new HashMap();
		Gson gson = new Gson();
		ReceiptCumPolicyRequest accountServReq = new ReceiptCumPolicyRequest();

		ProposalStatusReq proposalStatRequest = new ProposalStatusReq();
		ProposalStatus proposalStatRes = new ProposalStatus();
		String proposalNo = null;

		try {
			reqDocUploadMap = dbserv.getCustDocUploasLinkDtl(
					"com.majesco.dcf.docmgmt.entity.CustDocUploadEntity",
					"transId", transactionID);
			logger.debug("Inside DocUploadDtlsServiceImpl.getUploadDocDetails method:: HashMap Object --> "
					+ objMapper.writeValueAsString(reqDocUploadMap));

			Date endDate = (Date) reqDocUploadMap.get("endtime");
			proposalNo = (String) reqDocUploadMap.get("proppolnbr");

			logger.debug("Inside DocUploadDtlsServiceImpl.getUploadDocDetails method:: Proposal No --> "
					+ proposalNo);
			DocUploadSearchObj docSearchDtls = new DocUploadSearchObj();
			docSearchDtls.setProposalNo(proposalNo);
			DocUploadSearchResponse searchResponse = getUploadDocSearch(docSearchDtls);

			logger.debug("Inside DocUploadDtlsServiceImpl.getUploadDocDetails method:: HashMap Object --> "
					+ objMapper.writeValueAsString(searchResponse));

			resultMap.put("documentChecklist",
					objMapper.writeValueAsString(searchResponse));
			resultMap.put("custName",
					(String) reqDocUploadMap.get("customername"));

			resultMap.put("planName", (String) reqDocUploadMap.get("planname"));
			logger.debug("Plan Name :- "
					+ (String) reqDocUploadMap.get("planname"));
			String strval = "";
			List<Product> oComProductList = (List<Product>) dbserv.getProduct("com.majesco.dcf.common.tagic.entity.Product", "strprodcd",(String)reqDocUploadMap.get("productcd"));
			if (oComProductList.size() > 0) {
				for (Product productList : oComProductList) {
					strval = productList.getStrprodname() != null ? productList
							.getStrprodname().toString() : "";
				}
			}

			resultMap.put("productName", strval);

			if (((String) reqDocUploadMap.get("vehregno") != null)
					&& (!((String) reqDocUploadMap.get("vehregno")).equals(""))) {
				resultMap.put("vehRegNo",
						(String) reqDocUploadMap.get("vehregno"));
			} else {
				resultMap.put("vehRegNo", "NA");
			}
			resultMap.put("lobNo", (String) reqDocUploadMap.get("lob"));

			resultMap.put("customerID",
					(String) reqDocUploadMap.get("customerid"));
			resultMap.put("proposalNo",
					(String) reqDocUploadMap.get("proppolnbr"));
			resultMap.put("transAmt", reqDocUploadMap.get("transamount")
					.toString());
			resultMap.put("productCd",
					(String) reqDocUploadMap.get("productcd"));
			resultMap.put("agentCode",
					(String) reqDocUploadMap.get("producercd"));
			resultMap.put("agentName",
					(String) reqDocUploadMap.get("producername"));

			if ((reqDocUploadMap.get("custlinkused") != null)
					&& (reqDocUploadMap.get("custlinkused").equals("1"))) {
				resultMap.put("isError", "1");
				resultMap.put("messageDisplay", "Dear "
						+ (String) reqDocUploadMap.get("customername")
						+ ", You can not upload documents again.");
				return resultMap;
			}

			if ((reqDocUploadMap.get("custlinkused") != null)
					&& (reqDocUploadMap.get("custlinkused").equals("2"))) {
				resultMap.put("isError", "1");
				resultMap
						.put("messageDisplay",
								"Sorry! Your Document Upload Link has expired. Please contact your agent for more details!");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultMap;
	}

	public ProducerLockDtlsRes saveProducerLockDtls(
			ProducerLockDtlsReq producerLockDtlsReq) throws Exception {
		logger.info("In DocUploadDtlsServiceImpl. saveProducerLockDtls() Method Begin()...");
		ProducerLockDtlsRes producerLockDtlsRes = null;
		try {
			producerLockDtlsRes = new ProducerLockDtlsRes();
			ProducerLockDetails lockDetails = new ProducerLockDetails();
			lockDetails.setStrproducercd(producerLockDtlsReq.getProducerCd());
			lockDetails.setStrlob(producerLockDtlsReq.getLob());
			lockDetails.setNoofdays(Integer.parseInt(producerLockDtlsReq
					.getNoOfDays()));
			lockDetails.setStartdt(producerLockDtlsReq.getStartDate());
			lockDetails.setEnddt(producerLockDtlsReq.getEndDate());
			lockDetails.setStrisactive(producerLockDtlsReq.getIsActive());
			lockDetails.setDtCreated(new Date());
			lockDetails.setDtUpdated(new Date());
			lockDetails.setStrCreatedBy(producerLockDtlsReq.getUserID());
			lockDetails.setStrUpdatedBy(producerLockDtlsReq.getUserID());
			boolean isSave = dbserv.saveProducerLockDtls(lockDetails);
			producerLockDtlsRes.setSuccessFlag(Boolean.valueOf(isSave));
		} catch (Exception e) {
			logger.error(
					"In DocUploadDtlsServiceImpl.saveDocUploadOptn() Method :: Exception StackTrace : ",
					e);
		}
		return producerLockDtlsRes;
	}

	public ProducerLockDtlsSearchRes searchProdLockDtls(
			ProducerLockDtlsSearchReq producerLockDtlsSearchReq)
			throws Exception {
		logger.info("In DocUploadDtlsServiceImpl. searchProdLockDtls() Method Begin()...");
		ProducerLockDtlsSearchRes producerLockDtlsSearchRes = null;
		try {
			producerLockDtlsSearchRes = new ProducerLockDtlsSearchRes();
			ProducerLockDetails lockDetails = null;
			lockDetails = dbserv
					.seachProducerLockDtls(producerLockDtlsSearchReq);
			producerLockDtlsSearchRes.setProducerCd(producerLockDtlsSearchReq
					.getProducerCd());
			producerLockDtlsSearchRes.setLob(lockDetails.getStrlob());
			producerLockDtlsSearchRes.setNoOfDays(lockDetails.getNoofdays()
					+ "");
			producerLockDtlsSearchRes.setDocUploadType(lockDetails
					.getStrdocuploadtype());
			producerLockDtlsSearchRes.setStartDate(lockDetails.getStartdt());
			producerLockDtlsSearchRes.setEndDate(lockDetails.getEnddt());
			producerLockDtlsSearchRes.setIsActive(lockDetails.getStrisactive());

		} catch (Exception e) {
			logger.error(
					"In DocUploadDtlsServiceImpl.saveDocUploadOptn() Method :: Exception StackTrace : ",
					e);
		}
		return producerLockDtlsSearchRes;
	}

	public DocUploadSearchResponse getUploadRejDocSearch(
			DocUploadSearchObj docSearchDtls) throws Exception {
		logger.info("In DocUploadDtlsServiceImpl.getUploadRejDocSearch() Method Begin()...");

		ObjectMapper objMap = new ObjectMapper();

		DocUploadSearchResponse docUploadSearchDtlsRes = new DocUploadSearchResponse();

		List<DocUploadDtlsObj> docUploadDtlsObjLst = new ArrayList();
		List<DocUploadDtlsEntity> docUploadDtlsEntities = null;

		try {
			logger.info("In DocUploadDtlsServiceImpl.getUploadRejDocSearch() Method :: "
					+ objMap.writeValueAsString(docSearchDtls));
			logger.info("In DocUploadDtlsServiceImpl.getUploadRejDocSearch() :: About To Call dbserv.getUploadDocSearch()... ");

			docUploadDtlsEntities = dbserv
					.getUploadDocSearchByStatus(docSearchDtls);

			for (int i = 0; i < docUploadDtlsEntities.size(); i++) {
				DocUploadDtlsObj docUploadDtlsObj = new DocUploadDtlsObj();
				DocUploadDtlsEntity docUploadDtlsEntity = (DocUploadDtlsEntity) docUploadDtlsEntities
						.get(i);
				if (docUploadDtlsEntity != null) {
					docUploadDtlsObj.setProposalNo(docUploadDtlsEntity
							.getStrProposalNo());
					docUploadDtlsObj.setPolicyNo(docUploadDtlsEntity
							.getStrPolicyNo() == null ? ""
							: docUploadDtlsEntity.getStrPolicyNo());
					docUploadDtlsObj.setDocmodMapId(docUploadDtlsEntity
							.getStrDocmodMapId() == null ? ""
							: docUploadDtlsEntity.getStrDocmodMapId());
					docUploadDtlsObj.setDocIndex(docUploadDtlsEntity
							.getStrDocIndex() == null ? ""
							: docUploadDtlsEntity.getStrDocIndex());
					docUploadDtlsObj.setMandatory(docUploadDtlsEntity
							.isBisMandatory() + "");
					docUploadDtlsObj.setCreatedBy(docUploadDtlsEntity
							.getStrCreatedBy() == null ? ""
							: docUploadDtlsEntity.getStrCreatedBy());
					docUploadDtlsObj.setDocName(docUploadDtlsEntity
							.getStrDocName() == null ? "" : docUploadDtlsEntity
							.getStrDocName());
					docUploadDtlsObj.setNdocid(docUploadDtlsEntity.getNdocid());
					docUploadDtlsObj.setRemarks(docUploadDtlsEntity
							.getStrRemarks() == null ? "" : docUploadDtlsEntity
							.getStrRemarks());
					docUploadDtlsObj.setStrdocstatus(docUploadDtlsEntity
							.getStrDocStatus() == null ? ""
							: docUploadDtlsEntity.getStrDocStatus());
					docUploadDtlsObjLst.add(docUploadDtlsObj);
				}
			}

			docUploadSearchDtlsRes.setDocUploadDtlsObj(docUploadDtlsObjLst);

			logger.info("In DocUploadDtlsServiceImpl.getUploadRejDocSearch() Method :: "
					+ objMap.writeValueAsString(docUploadSearchDtlsRes));

		} catch (Exception e) {
			logger.error(
					"In DocUploadDtlsServiceImpl.getUploadRejDocSearch() Method :: Exception StackTrace : ",
					e);
		}

		return docUploadSearchDtlsRes;
	}

	public DocUploadOptnResponse saveSourceOptn(
			DocSourceOptionReq docUploadOptnReq) throws Exception {
		logger.info("In DocUploadDtlsServiceImpl.saveDocUploadOptn() Method Begin()...");
		DocUploadOptnResponse docUploadOptnResponse = null;
		try {
			docUploadOptnResponse = new DocUploadOptnResponse();
			DocUploadDtlsEntity docUploadOptn = new DocUploadDtlsEntity();
			docUploadOptn.setStrProposalNo(docUploadOptnReq.getProposalNo());
			docUploadOptn.setStrsource(docUploadOptnReq.getSource());
			boolean isSave = dbserv.updateDocSOurceOptn(docUploadOptn);
			docUploadOptnResponse.setSuccessFlag(Boolean.valueOf(isSave));
		} catch (Exception e) {
			logger.error(
					"In DocUploadDtlsServiceImpl.saveSourceOptn() Method :: Exception StackTrace : ",
					e);
		}
		return docUploadOptnResponse;
	}

	public OmniDocUploadDtlsEntity transformDocToOmni(
			DocUploadDtlsEntity docUploadAuditDtlsEntity) {
		OmniDocUploadDtlsEntity entity = new OmniDocUploadDtlsEntity();

		entity.setActiveStatus(docUploadAuditDtlsEntity.getActiveStatus());

		entity.setStrProposalNo(docUploadAuditDtlsEntity.getStrProposalNo());
		entity.setStrPolicyNo(docUploadAuditDtlsEntity.getStrPolicyNo());
		entity.setStrDocmodMapId(docUploadAuditDtlsEntity.getStrDocmodMapId());
		entity.setStrDocIndex(docUploadAuditDtlsEntity.getStrDocIndex());
		entity.setStrDocName(docUploadAuditDtlsEntity.getStrDocName());
		entity.setBisMandatory(docUploadAuditDtlsEntity.isBisMandatory());
		entity.setStrCreatedBy(docUploadAuditDtlsEntity.getStrCreatedBy());
		entity.setDtCreated(docUploadAuditDtlsEntity.getDtCreated());
		entity.setStrDocPath(docUploadAuditDtlsEntity.getStrDocPath());
		entity.setStrFileExt(docUploadAuditDtlsEntity.getStrFileExt());
		entity.setStrFileName(docUploadAuditDtlsEntity.getStrFileName());
		entity.setStrFileSize(docUploadAuditDtlsEntity.getStrFileSize());
		entity.setStrFileType(docUploadAuditDtlsEntity.getStrFileType());
		entity.setNversion(docUploadAuditDtlsEntity.getNversion());
		entity.setUploadDate(docUploadAuditDtlsEntity.getUploadDate());
		entity.setStrUploadBy(docUploadAuditDtlsEntity.getStrUploadBy());
		entity.setDtUpdated(docUploadAuditDtlsEntity.getDtUpdated());
		entity.setStrUpdatedBy(docUploadAuditDtlsEntity.getStrUpdatedBy());
		entity.setStrDocStatus(docUploadAuditDtlsEntity.getStrDocStatus());

		return entity;
	}

	private static Date getZeroTimeDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(11, 0);
		calendar.set(12, 0);
		calendar.set(13, 0);
		calendar.set(14, 0);
		date = calendar.getTime();
		return date;
	}

	public DocUploadDtlsServiceImpl() {
	}
}

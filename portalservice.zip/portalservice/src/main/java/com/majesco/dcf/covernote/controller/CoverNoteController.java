package com.majesco.dcf.covernote.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.covernote.json.AgentCoverNoteBook;
import com.majesco.dcf.covernote.json.CNFlagProposalResponse;
import com.majesco.dcf.covernote.json.CancelMissingCNRequest;
import com.majesco.dcf.covernote.json.CancelMissingCNResponse;
import com.majesco.dcf.covernote.json.CheckCNFlagForProposal;
import com.majesco.dcf.covernote.json.GenericCoverNoteRequest;
import com.majesco.dcf.covernote.json.GenericCoverNoteResponse;
import com.majesco.dcf.covernote.json.GetPolicyNoRequest;
import com.majesco.dcf.covernote.json.NextUnusedLeafNoRequest;
import com.majesco.dcf.covernote.json.NextUnusedLeafNoResponse;
import com.majesco.dcf.covernote.json.PendingCoverNoteRequest;
import com.majesco.dcf.covernote.json.PendingCoverNoteResponse;
import com.majesco.dcf.covernote.json.PhyCancelledRsnForCNLeafRequest;
import com.majesco.dcf.covernote.json.PhyCancelledRsnForCNLeafResponse;
import com.majesco.dcf.covernote.json.SaveOpenCNRequest;
import com.majesco.dcf.covernote.json.SaveOpenCNResponse;
import com.majesco.dcf.covernote.json.SearchCoverNoteForPropRequest;
import com.majesco.dcf.covernote.json.SearchCoverNoteForPropResponse;
import com.majesco.dcf.covernote.json.TagPaymentCNRequest;
import com.majesco.dcf.covernote.json.TagPaymentCNResponse;
import com.majesco.dcf.covernote.service.GenericCoverNoteService;
import com.majesco.dcf.covernote.service.WcfGCIntegrationService;

@Controller
@RequestMapping(value="/coverNote")

public class CoverNoteController {
	
	@Autowired
	GenericCoverNoteService genericCoverNote;

	@Autowired
	WcfGCIntegrationService wcfGCIntegration;
	
	final static Logger logger=Logger.getLogger(CoverNoteController.class);
	
	// This service gets called on click of search icon on search routed cover note screen 
	@RequestMapping(value="/getSavedCoverNoteDtl/", method = RequestMethod.POST)
	@ResponseBody
	public List<GenericCoverNoteResponse> getSavedCoverNoteDtl (@RequestBody GenericCoverNoteRequest coverNoteReq,HttpServletRequest httpServletRequest){
		List<GenericCoverNoteResponse> response = null;
		ObjectMapper objM = new ObjectMapper();
		
		try{
			
			logger.info("CoverNote CONTROLLER :: getCoverNoteDtl :: Recieved Request JSON Object :: "+objM.writeValueAsString(coverNoteReq));
			response = genericCoverNote.getSavedCoverNoteDtl(coverNoteReq);
			logger.info("Inside CoverNoteController :: getCoverNoteDtl method :: Exit:: Response JSON Object :: "+objM.writeValueAsString(response));
		}
		catch(Exception e){
			logger.error("Inside CoverNoteController :: getCoverNoteDtl method :: Error ", e);
		}
		return response;
	}
	
	// This service gets called on click of save button on core note for core processing screen 
	@RequestMapping(value="/saveCoverNoteDtl/", method = RequestMethod.POST)
	@ResponseBody
	public GenericCoverNoteResponse saveCoverNoteForCoreProcessing (@RequestBody GenericCoverNoteRequest coverNoteReq ,HttpServletRequest httpServletRequest){
		GenericCoverNoteResponse response = null;
		ObjectMapper objM = new ObjectMapper();
		try{
			
			logger.info("Inside CoverNote :: saveCoverNoteDtl() :: Execution Started");
			logger.info("CoverNote CONTROLLER :: saveCoverNoteDtl :: Recieved Request JSON Object :: "+objM.writeValueAsString(coverNoteReq));
			response = genericCoverNote.saveCoverNoteForCoreProcessing(coverNoteReq);
			logger.info("Inside CoverNote :: saveCoverNoteDtl() :: Exit:: Response JSON Object :: "+objM.writeValueAsString(response));
		}
		catch(Exception e){
			logger.error("Inside CoverNoteController :: saveCoverNoteDtl method :: Error ", e);
		}
		return response;
	}
	
	// This service gets called on click of save button on cancel/missing cover note screen
	@RequestMapping(value="/cancelMissingCoverNote/", method = RequestMethod.POST)
	@ResponseBody
	public CancelMissingCNResponse cancelMissingCoverNote (@RequestBody CancelMissingCNRequest cancelMissingCNDtl, HttpServletRequest httpServletRequest){
		CancelMissingCNResponse response = null;
		ObjectMapper objM = new ObjectMapper();
		try{
			String ipAddress = null;
			ipAddress = ServiceUtility.getClientIpAddr(httpServletRequest);
			cancelMissingCNDtl.setIpAddress(ipAddress);
			logger.info("CoverNote CONTROLLER :: updateCoverNoteDtl :: IP Address Of Client :: "+cancelMissingCNDtl.getIpAddress());
			logger.info("CoverNote CONTROLLER :: updateCoverNoteDtl :: Recieved Request JSON Object :: "+objM.writeValueAsString(cancelMissingCNDtl));
			response = genericCoverNote.cancelMissingCoverNote(cancelMissingCNDtl);
			logger.info("Inside CoverNote :: updateCoverNoteDtl() ::Exit:: Response JSON Object :: "+objM.writeValueAsString(response));
		}
		catch(Exception e){
			logger.error("Inside CoverNoteController :: updateCoverNoteDtl() :: Error ", e);
		}
		return response;
	}
	// This service gets called on after selecting field user from field user drop-down on cover note for core processing screen & during motor proposal creation
	@RequestMapping(value="/searchUniqueCoverNote/", method = RequestMethod.POST)
	@ResponseBody
	public SearchCoverNoteForPropResponse searchUniqueCoverNote (@RequestBody SearchCoverNoteForPropRequest coverNoteReq,HttpServletRequest httpServletRequest){
		SearchCoverNoteForPropResponse response = null;
		ObjectMapper objM = new ObjectMapper();
		
		try{
			
			logger.info("CoverNote CONTROLLER :: searchUniqueCoverNote :: Request JSON Object :: "+objM.writeValueAsString(coverNoteReq));
			response = wcfGCIntegration.searchUniqueCoverNote(coverNoteReq);
			logger.info("Inside CoverNote :: searchCoverNoteMotorProp() :: Exit:: Response JSON Object :: "+objM.writeValueAsString(response));
		}
		catch(Exception e){
			logger.error("Inside CoverNoteController :: searchUniqueCoverNote() :: Error ", e);
		}
		return response;
	}
	
	// This service gets called on click of search icon on update open cover note screen
	@RequestMapping(value="/getOpenCoverNoteList/", method = RequestMethod.POST)
	@ResponseBody
	public List<PendingCoverNoteResponse> getOpenCoverNoteList (@RequestBody PendingCoverNoteRequest openCoverNoteReq,HttpServletRequest httpServletRequest){
		PendingCoverNoteResponse response = null;
		List<PendingCoverNoteResponse> responseLst = new ArrayList<PendingCoverNoteResponse>();
		ObjectMapper objM = new ObjectMapper();
		
		try{
			
			logger.info("Inside CoverNote :: getOpenCoverNoteList() :: Execution Started");
			logger.info("CoverNote CONTROLLER :: getOpenCoverNoteList :: Request JSON Object :: "+objM.writeValueAsString(openCoverNoteReq));
			responseLst = wcfGCIntegration.getOpenCoverNoteList(openCoverNoteReq);
			logger.info("Inside CoverNote :: getOpenCoverNoteList() :: Exit:: Response JSON Object :: "+objM.writeValueAsString(response));
		}
		catch(Exception e){
			logger.error("Inside CoverNoteController :: getOpenCoverNoteList() :: Error ", e);
		}
		return responseLst;
	}
	
	// This service gets called on click of submit button after filling reg no, chassis no details on modify cover note screen
	@RequestMapping(value="/saveOpenCoverNoteAccService/", method = RequestMethod.POST)
	@ResponseBody
	public SaveOpenCNResponse saveOpenCoverNoteAccService (@RequestBody SaveOpenCNRequest saveOpenCNReq, HttpServletRequest httpServletRequest){
		SaveOpenCNResponse response = null;
		ObjectMapper objM = new ObjectMapper();
		
		try{
			logger.info("CoverNote CONTROLLER :: searchCoverNoteMotorProp :: Request JSON Object :: "+objM.writeValueAsString(saveOpenCNReq));
			response = genericCoverNote.saveOpenCoverNoteAccService(saveOpenCNReq);
			logger.info("Inside CoverNote :: searchCoverNoteMotorProp() :: Exit:: Response JSON Object :: "+objM.writeValueAsString(response));
		}
		catch(Exception e){
			logger.error("Inside CoverNoteController :: getCoverNoteDtl() :: Error ", e);
		}
		return response;
	}
	
	// This method gets called on the fly while loading cancel/missing cover note screen
	@RequestMapping(value="/getBookListFromAgentID/", method = RequestMethod.POST)
	@ResponseBody
	public AgentCoverNoteBook getBookListFromAgentID (@RequestBody UserObject agentDtl, HttpServletRequest httpServletRequest){
		AgentCoverNoteBook response = null;
		ObjectMapper objM = new ObjectMapper();
		
		try{
			
			logger.info("CoverNote CONTROLLER :: getBookListFromAgentID :: Request JSON Object :: "+objM.writeValueAsString(agentDtl));
			response = genericCoverNote.getBookListFromAgentID(agentDtl);
			logger.info("Inside CoverNote :: getBookListFromAgentID() :: Exit:: Response JSON Object :: "+objM.writeValueAsString(response));
		}
		catch(Exception e){
			logger.error("Inside CoverNoteController :: getCoverNoteDtl() :: Error ", e);
		}
		return response;
	}
	
	// This method gets called on click of book number from CN book number drop down on cancel/missing cover note screen
		@RequestMapping(value="/getNextUnusedLeafNoFromBookNo/", method = RequestMethod.POST)
		@ResponseBody
		public NextUnusedLeafNoResponse getNextUnusedLeafNoFromBookNo (@RequestBody NextUnusedLeafNoRequest bookNoDtl, HttpServletRequest httpServletRequest){
			NextUnusedLeafNoResponse response = null;
			ObjectMapper objM = new ObjectMapper();
			
			try{
				
				logger.info("CoverNote CONTROLLER :: getNextUnusedLeafNoFromBookNo :: Request JSON Object :: "+objM.writeValueAsString(bookNoDtl));
				response = genericCoverNote.getNextUnusedLeafNoFromBookNo(bookNoDtl);
				logger.info("Inside CoverNote :: getNextUnusedLeafNoFromBookNo() :: Exit:: Response JSON Object :: "+objM.writeValueAsString(response));
			}
			catch(Exception e){
				logger.error("Inside CoverNoteController :: getCoverNoteDtl() :: Error ", e);
			}
			return response;
		}
		
		// this service gets called after generating motor proposal to check cover note flag
		@RequestMapping(value="/isCoverNoteProposal/", method = RequestMethod.POST)
		@ResponseBody
		public CNFlagProposalResponse isCoverNoteProposal(@RequestBody CheckCNFlagForProposal cnFlagForProposal, HttpServletRequest httpServletRequest) throws Exception
		{
			logger.info("Inside CoverNoteController :: isCoverNoteProposal method :: Execution Started");
			
			CNFlagProposalResponse cnFlagObject = 	wcfGCIntegration.isCoverNoteProposal(cnFlagForProposal);
			
			logger.info("Inside CoverNoteController :: isCoverNoteProposal method :: Execution Completed Successfully");
				
			return cnFlagObject;
		}
		
		// this service gets called after generating motor proposal to check cover note flag
		@RequestMapping(value="/makePaymentForCoverNote/", method = RequestMethod.POST)
		@ResponseBody
		public CNFlagProposalResponse makePaymentForCoverNote(@RequestBody CheckCNFlagForProposal cnFlagForProposal, HttpServletRequest httpServletRequest) throws Exception
		{
			logger.info("Inside CoverNoteController :: makePaymentForCoverNote method :: Execution Started");
			
			CNFlagProposalResponse cnFlagObject = 	wcfGCIntegration.isCoverNoteProposal(cnFlagForProposal);
					
			logger.info("Inside CoverNoteController :: makePaymentForCoverNote method :: Execution Completed Successfully");
					
			return cnFlagObject;
		}
		
		// this service used to tag payment for cover note proposal
		/*@RequestMapping(value="/tagPayment/", method = RequestMethod.POST)
		@ResponseBody
		public TagPaymentCNResponse tagPayment(@RequestBody TagPaymentCNRequest tagPaymentRequest, HttpServletRequest httpServletRequest) throws Exception
		{
			logger.info("Inside CoverNoteController :: tagPayment method :: Execution Started");
					
			TagPaymentCNResponse response = genericCoverNote.tagPayment(tagPaymentRequest);
							
			logger.info("Inside CoverNoteController :: tagPayment method :: Execution Completed Successfully");
							
			return response;
		}*/
		
		// this service used to tag payment for cover note proposal
		/*@RequestMapping(value="/getPolicyNo/", method = RequestMethod.POST)
		@ResponseBody
		public String getPolicyNo(@RequestBody GetPolicyNoRequest policyRequest, HttpServletRequest httpServletRequest) throws Exception
		{
			logger.info("Inside CoverNoteController :: getPolicyNo method :: Execution Started");
							
			String policyNo = genericCoverNote.getPolicyNo(policyRequest);
									
			logger.info("Inside CoverNoteController :: getPolicyNo method :: Execution Completed Successfully");
									
			return policyNo;
		}*/
		@RequestMapping(value="/cancelledRsnForCNLeaf/", method = RequestMethod.POST)
		@ResponseBody
		public List<PhyCancelledRsnForCNLeafResponse> getPhyCancelledRsnForCNLeaf (@RequestBody PhyCancelledRsnForCNLeafRequest phyCancelledRsnForCNLeafRequest, HttpServletRequest httpServletRequest){
			
			List<PhyCancelledRsnForCNLeafResponse> responseLst = new ArrayList<PhyCancelledRsnForCNLeafResponse>();
			ObjectMapper objM = new ObjectMapper();
			try{
				//String ipAddress = null;
				//ipAddress = ServiceUtility.getClientIpAddr(httpServletRequest);
				//phyCancelledRsnForCNLeafRequest.setIpAddress(ipAddress);
				//logger.info("CoverNote CONTROLLER :: updateCoverNoteDtl :: IP Address Of Client :: "+cancelMissingCNDtl.getIpAddress());
				logger.info("CoverNote PhyCancelledRsnForCNLeaf CONTROLLER :: PhyCancelledRsnForCNLeaf :: Recieved Request JSON Object :: "+objM.writeValueAsString(phyCancelledRsnForCNLeafRequest));
				responseLst =genericCoverNote.phyCancelledRsnForCNLeaf(phyCancelledRsnForCNLeafRequest);
				logger.info("Inside CoverNote :: updateCoverNoteDtl() ::Exit:: Response JSON Object :: "+objM.writeValueAsString(responseLst));
			}
			catch(Exception e){
				logger.error("Inside CoverNoteController :: updateCoverNoteDtl() :: Error ", e);
			}
			return responseLst;
		}
}

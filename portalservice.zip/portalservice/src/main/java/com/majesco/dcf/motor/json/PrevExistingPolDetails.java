package com.majesco.dcf.motor.json;

import com.majesco.dcf.common.tagic.json.AddressDetails;
import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class PrevExistingPolDetails {

private String 	prevPolEndDate;
private String 	prevPolStartDate;
private String 	vehicleCity;
private String 	financerName;
private String 	agreementType;
private String 	loanAcctNumber;
private String 	existingPolicyType;
private String 	existingInsCompany;
private String 	existingPolNumber;
private String 	branchCode;
private String 	claimRecieve;
private String 	ncbExstPol;
private String 	ncbApplcble;
private AddressDetails adddetails;
ServiceUtility serviceUtility = new ServiceUtility();


public String getPrevPolEndDate() {
	return prevPolEndDate;
}
public void setPrevPolEndDate(String prevPolEndDate) {
	prevPolEndDate = serviceUtility.blankToNullCheck(prevPolEndDate);
	this.prevPolEndDate = prevPolEndDate;
}
public String getVehicleCity() {
	return vehicleCity;
}
public void setVehicleCity(String vehicleCity) {
	vehicleCity = serviceUtility.blankToNullCheck(vehicleCity);
	this.vehicleCity = vehicleCity;
}
public String getFinancerName() {
	return financerName;
}
public void setFinancerName(String financerName) {
	financerName = serviceUtility.blankToNullCheck(financerName);
	this.financerName = financerName;
}
public String getAgreementType() {
	return agreementType;
}
public void setAgreementType(String agreementType) {
	agreementType = serviceUtility.blankToNullCheck(agreementType);
	this.agreementType = agreementType;
}
public String getLoanAcctNumber() {
	return loanAcctNumber;
}
public void setLoanAcctNumber(String loanAcctNumber) {
	loanAcctNumber = serviceUtility.blankToNullCheck(loanAcctNumber);
	this.loanAcctNumber = loanAcctNumber;
}
public String getExistingPolicyType() {
	return existingPolicyType;
}
public void setExistingPolicyType(String existingPolicyType) {
	existingPolicyType = serviceUtility.blankToNullCheck(existingPolicyType);
	this.existingPolicyType = existingPolicyType;
}
public String getExistingInsCompany() {
	return existingInsCompany;
}
public void setExistingInsCompany(String existingInsCompany) {
	existingInsCompany = serviceUtility.blankToNullCheck(existingInsCompany);
	this.existingInsCompany = existingInsCompany;
}
public String getExistingPolNumber() {
	return existingPolNumber;
}
public void setExistingPolNumber(String existingPolNumber) {
	existingPolNumber = serviceUtility.blankToNullCheck(existingPolNumber);
	this.existingPolNumber = existingPolNumber;
}
public String getBranchCode() {
	return branchCode;
}
public void setBranchCode(String branchCode) {
	branchCode = serviceUtility.blankToNullCheck(branchCode);
	this.branchCode = branchCode;
}
public AddressDetails getAdddetails() {
	return adddetails;
}
public void setAdddetails(AddressDetails adddetails) {
	this.adddetails = adddetails;
}
public String getPrevPolStartDate() {
	return prevPolStartDate;
}
public void setPrevPolStartDate(String prevPolStartDate) {
	prevPolStartDate = serviceUtility.blankToNullCheck(prevPolStartDate);
	this.prevPolStartDate = prevPolStartDate;
}
public String getClaimRecieve() {
	return claimRecieve;
}
public void setClaimRecieve(String claimRecieve) {
	claimRecieve = serviceUtility.blankToNullCheck(claimRecieve);
	this.claimRecieve = claimRecieve;
}
public String getNcbExstPol() {
	return ncbExstPol;
}
public void setNcbExstPol(String ncbExstPol) {
	ncbExstPol = serviceUtility.blankToNullCheck(ncbExstPol);
	this.ncbExstPol = ncbExstPol;
}
public String getNcbApplcble() {
	return ncbApplcble;
}
public void setNcbApplcble(String ncbApplcble) {
	ncbApplcble = serviceUtility.blankToNullCheck(ncbApplcble);
	this.ncbApplcble = ncbApplcble;
}




	
}

package com.majesco.dcf.common.tagic.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "dcf_online_stg")
public class OnlineAccountService {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="dcf_online_stg_seq")
	@SequenceGenerator(name="dcf_online_stg_seq",sequenceName="dcf_online_stg_seq",allocationSize=1,initialValue=1)
	@Column(name="ntxnno", nullable=false)
	private Integer ntxnNo;
	
	@Column(name = "strorderid")
	private String strOrderID;
	
	@Type(type="org.hibernate.type.StringClobType")
	@Column(name = "strrequestmsg")
	private String strRequestMsg;

	public Integer getNtxnNo() {
		return ntxnNo;
	}

	public void setNtxnNo(Integer ntxnNo) {
		this.ntxnNo = ntxnNo;
	}

	public String getStrOrderID() {
		return strOrderID;
	}

	public void setStrOrderID(String strOrderID) {
		this.strOrderID = strOrderID;
	}

	public String getStrRequestMsg() {
		return strRequestMsg;
	}

	public void setStrRequestMsg(String strRequestMsg) {
		this.strRequestMsg = strRequestMsg;
	}

}

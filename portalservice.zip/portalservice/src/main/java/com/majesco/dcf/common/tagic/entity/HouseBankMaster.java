package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.codec.binary.Base64;

@Entity
@Table(name = "dcf_housebank_acc_m")
public class HouseBankMaster implements Serializable {
	@Id
	@Column(name = "house_bank_cd")
	private int house_bank_cd;
	
	@Column(name = "house_bank_name")
	private String house_bank_name;
		
	@Column(name = "house_bank_acc_no" )
	private int house_bank_acc_no;

	public int getHouse_bank_cd() {
		return house_bank_cd;
	}

	public void setHouse_bank_cd(int house_bank_cd) {
		this.house_bank_cd = house_bank_cd;
	}

	public String getHouse_bank_name() {
		return house_bank_name;
	}

	public void setHouse_bank_name(String house_bank_name) {
		this.house_bank_name = house_bank_name;
	}

	public int getHouse_bank_acc_no() {
		return house_bank_acc_no;
	}

	public void setHouse_bank_acc_no(int house_bank_acc_no) {
		this.house_bank_acc_no = house_bank_acc_no;
	}
	
	
	
}

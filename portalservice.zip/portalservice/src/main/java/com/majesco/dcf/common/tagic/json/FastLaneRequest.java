package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author ketan570156
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class FastLaneRequest extends UserObject{
	
	private String registrationNumber;
	private String chasisNumber;
	private String engineNumber;
	private String stateCd;
	private String fncrMakerDesc;
	private String fncrDate;
	private String fncrVhClass;
	private String fncrName;
	private String moduleCode;

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getChasisNumber() {
		return chasisNumber;
	}

	public void setChasisNumber(String chasisNumber) {
		this.chasisNumber = chasisNumber;
	}

	public String getEngineNumber() {
		return engineNumber;
	}

	public void setEngineNumber(String engineNumber) {
		this.engineNumber = engineNumber;
	}

	public String getStateCd() {
		return stateCd;
	}

	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}

	public String getFncrMakerDesc() {
		return fncrMakerDesc;
	}

	public void setFncrMakerDesc(String fncrMakerDesc) {
		this.fncrMakerDesc = fncrMakerDesc;
	}

	public String getFncrDate() {
		return fncrDate;
	}

	public void setFncrDate(String fncrDate) {
		this.fncrDate = fncrDate;
	}

	public String getFncrVhClass() {
		return fncrVhClass;
	}

	public void setFncrVhClass(String fncrVhClass) {
		this.fncrVhClass = fncrVhClass;
	}

	public String getFncrName() {
		return fncrName;
	}

	public void setFncrName(String fncrName) {
		this.fncrName = fncrName;
	}

	public String getModuleCode() {
		return moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}
	

}

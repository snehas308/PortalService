package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_vh_addon_feature_m",schema="dcf_master")			// Commented for Oracle Migration
@Table(name = "dcf_vh_addon_feature_m")									// Added for Oracle Migration				
public class VehicleAddOn implements Serializable{
	
	
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String strplancode="";
	private String strplanname="";
	private String strchoice="";
	private BigDecimal ndepreciationreimbursement;
	private String strnoofclaims="";
	private BigDecimal nenginesecure;
	private String strenginesecureoption="";
	private BigDecimal ntyresecure;
	private String strtyresecureoption="";
	private BigDecimal nrepairofglassrubberplasticparts;
	private BigDecimal nkeyreplacement;
	private String strkeyreplacementsi="";
	private BigDecimal nconsumableexpenses;
	private BigDecimal nlossofpersonalbelongings;
	private String strlossofpersonalbelongingssi="";
	private BigDecimal nroadsideassistance;
	private String stremergtrnsprtandhotelexpensidv="";
	private String strratioofaoaaoy="";
	private String stremergencytransportsiaoa="";
	private String stremergencytransportsiaoy="";
	private BigDecimal ndailyallowance;
	private String straccidentallowancedays="";
	private String strtheftallowancedays="";
	private String strfranchisedays="";
	private BigDecimal nreturntoinvoice;
	private String straddonpremium="";
	private String dtcreated="";
	private String strcreatedby="";
	private String dtupdated="";
	private String strupdatedby="";
 
  	@Id
  	@Column(name="strplancode")
	public String getStrplancode() {
		return strplancode;
	}
	public void setStrplancode(String strplancode) {
		this.strplancode = strplancode;
	}
	
	@Column(name="strplanname")
	public String getStrplanname() {
		return strplanname;
	}
	public void setStrplanname(String strplanname) {
		this.strplanname = strplanname;
	}
	
	@Column(name="strchoice")
	public String getStrchoice() {
		return strchoice;
	}
	public void setStrchoice(String strchoice) {
		this.strchoice = strchoice;
	}
	
	@Column(name="ndepreciationreimbursement")
	public BigDecimal getNdepreciationreimbursement() {
		return ndepreciationreimbursement;
	}
	public void setNdepreciationreimbursement(BigDecimal ndepreciationreimbursement) {
		this.ndepreciationreimbursement = ndepreciationreimbursement;
	}
	
	@Column(name="strnoofclaims")
	public String getStrnoofclaims() {
		return strnoofclaims;
	}
	public void setStrnoofclaims(String strnoofclaims) {
		this.strnoofclaims = strnoofclaims;
	}
	
	@Column(name="nenginesecure")
	public BigDecimal getNenginesecure() {
		return nenginesecure;
	}
	public void setNenginesecure(BigDecimal nenginesecure) {
		this.nenginesecure = nenginesecure;
	}
	
	@Column(name="strenginesecureoption")
	public String getStrenginesecureoption() {
		return strenginesecureoption;
	}
	public void setStrenginesecureoption(String strenginesecureoption) {
		this.strenginesecureoption = strenginesecureoption;
	}
	
	@Column(name="ntyresecure")
	public BigDecimal getNtyresecure() {
		return ntyresecure;
	}
	public void setNtyresecure(BigDecimal ntyresecure) {
		this.ntyresecure = ntyresecure;
	}
	
	@Column(name="strtyresecureoption")
	public String getStrtyresecureoption() {
		return strtyresecureoption;
	}
	public void setStrtyresecureoption(String strtyresecureoption) {
		this.strtyresecureoption = strtyresecureoption;
	}
	
	//@Column(name="nrepairofglassrubberplasticparts")			// commented for oracle migration
	@Column(name="nrepairofglassrubberplastcpart")				// Added for oracle migration
	public BigDecimal getNrepairofglassrubberplasticparts() {
		return nrepairofglassrubberplasticparts;
	}
	public void setNrepairofglassrubberplasticparts(
			BigDecimal nrepairofglassrubberplasticparts) {
		this.nrepairofglassrubberplasticparts = nrepairofglassrubberplasticparts;
	}
	
	@Column(name="nkeyreplacement")
	public BigDecimal getNkeyreplacement() {
		return nkeyreplacement;
	}
	public void setNkeyreplacement(BigDecimal nkeyreplacement) {
		this.nkeyreplacement = nkeyreplacement;
	}
	
	@Column(name="strkeyreplacementsi")
	public String getStrkeyreplacementsi() {
		return strkeyreplacementsi;
	}
	public void setStrkeyreplacementsi(String strkeyreplacementsi) {
		this.strkeyreplacementsi = strkeyreplacementsi;
	}
	
	@Column(name="nconsumableexpenses")
	public BigDecimal getNconsumableexpenses() {
		return nconsumableexpenses;
	}
	public void setNconsumableexpenses(BigDecimal nconsumableexpenses) {
		this.nconsumableexpenses = nconsumableexpenses;
	}
	
	@Column(name="nlossofpersonalbelongings")
	public BigDecimal getNlossofpersonalbelongings() {
		return nlossofpersonalbelongings;
	}
	public void setNlossofpersonalbelongings(BigDecimal nlossofpersonalbelongings) {
		this.nlossofpersonalbelongings = nlossofpersonalbelongings;
	}
	
	@Column(name="strlossofpersonalbelongingssi")
	public String getStrlossofpersonalbelongingssi() {
		return strlossofpersonalbelongingssi;
	}
	public void setStrlossofpersonalbelongingssi(
			String strlossofpersonalbelongingssi) {
		this.strlossofpersonalbelongingssi = strlossofpersonalbelongingssi;
	}
	
	@Column(name="nroadsideassistance")
	public BigDecimal getNroadsideassistance() {
		return nroadsideassistance;
	}
	public void setNroadsideassistance(BigDecimal nroadsideassistance) {
		this.nroadsideassistance = nroadsideassistance;
	}
	
	//@Column(name="stremergtrnsprtandhotelexpensidv")				// commented for oracle migration
	@Column(name="stremergtrnsprtandhotelexpsidv")					// Added for oracle migration
	public String getStremergtrnsprtandhotelexpensidv() {
		return stremergtrnsprtandhotelexpensidv;
	}
	public void setStremergtrnsprtandhotelexpensidv(
			String stremergtrnsprtandhotelexpensidv) {
		this.stremergtrnsprtandhotelexpensidv = stremergtrnsprtandhotelexpensidv;
	}
	
	@Column(name="strratioofaoaaoy")
	public String getStrratioofaoaaoy() {
		return strratioofaoaaoy;
	}
	public void setStrratioofaoaaoy(String strratioofaoaaoy) {
		this.strratioofaoaaoy = strratioofaoaaoy;
	}
	
	@Column(name="stremergencytransportsiaoa")
	public String getStremergencytransportsiaoa() {
		return stremergencytransportsiaoa;
	}
	public void setStremergencytransportsiaoa(String stremergencytransportsiaoa) {
		this.stremergencytransportsiaoa = stremergencytransportsiaoa;
	}
	
	@Column(name="stremergencytransportsiaoy")
	public String getStremergencytransportsiaoy() {
		return stremergencytransportsiaoy;
	}
	public void setStremergencytransportsiaoy(String stremergencytransportsiaoy) {
		this.stremergencytransportsiaoy = stremergencytransportsiaoy;
	}
	
	@Column(name="ndailyallowance")
	public BigDecimal getNdailyallowance() {
		return ndailyallowance;
	}
	public void setNdailyallowance(BigDecimal ndailyallowance) {
		this.ndailyallowance = ndailyallowance;
	}
	
	@Column(name="straccidentallowancedays")
	public String getStraccidentallowancedays() {
		return straccidentallowancedays;
	}
	public void setStraccidentallowancedays(String straccidentallowancedays) {
		this.straccidentallowancedays = straccidentallowancedays;
	}
	
	@Column(name="strtheftallowancedays")
	public String getStrtheftallowancedays() {
		return strtheftallowancedays;
	}
	public void setStrtheftallowancedays(String strtheftallowancedays) {
		this.strtheftallowancedays = strtheftallowancedays;
	}
	
	@Column(name="strfranchisedays")
	public String getStrfranchisedays() {
		return strfranchisedays;
	}
	public void setStrfranchisedays(String strfranchisedays) {
		this.strfranchisedays = strfranchisedays;
	}
	
	@Column(name="nreturntoinvoice")
	public BigDecimal getNreturntoinvoice() {
		return nreturntoinvoice;
	}
	public void setNreturntoinvoice(BigDecimal nreturntoinvoice) {
		this.nreturntoinvoice = nreturntoinvoice;
	}
	
	@Column(name="straddonpremium")
	public String getStraddonpremium() {
		return straddonpremium;
	}
	public void setStraddonpremium(String straddonpremium) {
		this.straddonpremium = straddonpremium;
	}
	
	@Column(name="dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name="strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name="dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name="strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}

package com.majesco.dcf.common.tagic.errorhandler;

public class TestErrorHandler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ErrorHandlerUtility errorHandlerUtility = new ErrorHandlerUtility();
		
		for (int i = 0; i < 2; i++) {
			
		String str=null;
		try {
			str = errorHandlerUtility.getErrorCodeByPropName("ERRORA001");
			//System.out.println("propName: " + str);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
	}

}

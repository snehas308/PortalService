package com.majesco.dcf.covernote.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CheckCNFlagForProposal extends UserObject{
	private String proposalNo;

	public String getProposalNo() {
		return proposalNo;
	}

	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}

	
}

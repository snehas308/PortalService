package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CovernoteOtherReasonResponse extends ResultObject {
	
	ArrayList<CoverNoteReasons> securityQuestionList;

	public ArrayList<CoverNoteReasons> getSecurityQuestionList() {
		return securityQuestionList;
	}

	public void setSecurityQuestionList(
			ArrayList<CoverNoteReasons> securityQuestionList) {
		this.securityQuestionList = securityQuestionList;
	}

}

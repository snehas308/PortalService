package com.majesco.dcf.common.tagic.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.ehcache.annotations.Cacheable;
import com.majesco.dcf.common.tagic.entity.Model;
import com.majesco.dcf.common.tagic.entity.Motor;
import com.majesco.dcf.common.tagic.json.ModelRequest;
import com.majesco.dcf.common.tagic.json.ModelResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;


@Service
public class ModelService {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(ModelService.class);
	
	
	@SuppressWarnings("null")
	@Cacheable(cacheName="modelInfoEhcache")
	public ModelResponse getModelInfo(ModelRequest modelreq) throws Exception
	{
		ModelResponse modelres = new ModelResponse();
		try
		{
		
		logger.info("In ModelService.getModelInfo() Method Begin()...");
		
		String strmodelcd = "";
		String strmodelnumber = "";

		List<String> lststrmodelcd = new ArrayList<String>();
		List<String> lststrmodelnumber = new ArrayList<String>();
		
		List<ResponseError> reserrList = new ArrayList<ResponseError>();
		
		
		ResponseError res = new ResponseError();
		res.setErrorCode("101");
		res.setErrorMMessag("Sorry Authentication Issue....");
		reserrList.add(res);
		
		
		
		@SuppressWarnings("unchecked")
		List<Model> ModelList =  (List<Model>) dbserv.getModelInfo("com.majesco.dcf.common.tagic.entity.Model", modelreq);
        for(Model modelLst:ModelList){
        
        	strmodelcd=nullCheckString(modelLst.getStrmodelcd());
        	strmodelnumber=nullCheckString(modelLst.getStrmodelnumber());
        	lststrmodelcd.add(strmodelcd);
        	lststrmodelnumber.add(strmodelnumber);
        }
        
        modelres.setStrmodelcd(lststrmodelcd);
        modelres.setStrmodelnumber(lststrmodelnumber);
        
        /*pincdres.setStrcitycd(strcitycd);       
        strcityval = dbserv.getCityNameByCode("com.majesco.dcf.common.tagic.entity.City", strcitycd, "C");
        pincdres.setStrcityval(strcityval);
       
        pincdres.setStrdistrictcd(strdistrictcd);       
        strdistrictval = dbserv.getDistrictNameByCode("com.majesco.dcf.common.tagic.entity.City", strdistrictcd, "D");
        pincdres.setStrdistrictval(strdistrictval);
        
        pincdres.setStrstatecd(strstatecd);
        strstateval = dbserv.getStateNameByCode("com.majesco.dcf.common.tagic.entity.State", strstatecd);
        pincdres.setStrstateval(strstateval);
        
        pincdres.setStrcountrycd(strcountrycd);
        strcountryval = dbserv.getCountryNameByCode("com.majesco.dcf.common.tagic.entity.Country", strcountrycd);
        pincdres.setStrcountryval(strcountryval);*/
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In ModelService.getModelInfo() Method End()...");
		ObjectMapper objMap=new ObjectMapper();
		//System.out.println(objMap.writeValueAsString(modelres));
		logger.info("In ModelService.getModelInfo() Method ::: "+modelres);
		
		return modelres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }
}

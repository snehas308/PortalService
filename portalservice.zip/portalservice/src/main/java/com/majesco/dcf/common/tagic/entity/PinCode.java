package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_pincode_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_pincode_m")								// Added for Oracle Migration
public class PinCode{
	
	private Integer npincodeseq;
	private String strcountrycd;
	private String strstatecd;
	private String strdistrictcd;
	private String strcitycd;
	private Integer npincode;
	private String strpincodelocality;
	private String nisrural;
	private String dtstart;
	private String dtend;
	private Integer nisactive;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	
	@Id
	@Column(name = "npincodeseq")
	public Integer getNpincodeseq() {
		return npincodeseq;
	}
	public void setNpincodeseq(Integer npincodeseq) {
		this.npincodeseq = npincodeseq;
	}
	
	@Column(name = "strcountrycd")
	public String getStrcountrycd() {
		return strcountrycd;
	}
	public void setStrcountrycd(String strcountrycd) {
		this.strcountrycd = strcountrycd;
	}
	
	@Column(name = "strstatecd")
	public String getStrstatecd() {
		return strstatecd;
	}
	public void setStrstatecd(String strstatecd) {
		this.strstatecd = strstatecd;
	}
	
	@Column(name = "strdistrictcd")
	public String getStrdistrictcd() {
		return strdistrictcd;
	}
	public void setStrdistrictcd(String strdistrictcd) {
		this.strdistrictcd = strdistrictcd;
	}
	
	@Column(name = "strcitycd")
	public String getStrcitycd() {
		return strcitycd;
	}
	public void setStrcitycd(String strcitycd) {
		this.strcitycd = strcitycd;
	}
	
	@Column(name = "npincode")
	public Integer getNpincode() {
		return npincode;
	}
	public void setNpincode(Integer npincode) {
		this.npincode = npincode;
	}
	
	@Column(name = "strpincodelocality")
	public String getStrpincodelocality() {
		return strpincodelocality;
	}
	public void setStrpincodelocality(String strpincodelocality) {
		this.strpincodelocality = strpincodelocality;
	}
	
	@Column(name = "nisrural")
	public String getNisrural() {
		return nisrural;
	}
	public void setNisrural(String nisrural) {
		this.nisrural = nisrural;
	}
	
	@Column(name = "dtstart")
	public String getDtstart() {
		return dtstart;
	}
	public void setDtstart(String dtstart) {
		this.dtstart = dtstart;
	}
	
	@Column(name = "dtend")
	public String getDtend() {
		return dtend;
	}
	public void setDtend(String dtend) {
		this.dtend = dtend;
	}
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	


}

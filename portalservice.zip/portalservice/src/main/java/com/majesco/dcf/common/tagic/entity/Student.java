package com.majesco.dcf.common.tagic.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SecondaryTables;
import javax.persistence.Table;

@Entity
@Table(name = "student")
@SecondaryTables({
    @SecondaryTable(name="name", pkJoinColumns={@PrimaryKeyJoinColumn(name = "studentid")}),
    @SecondaryTable(name="address", pkJoinColumns={@PrimaryKeyJoinColumn(name = "studentid")})
})
public class Student {

	@Id
	@Column(name="studentid")
	private String id;
	
	@Column(name="firstname", table="name")
	private String firstname;
	
	@Column(name="lastname", table="name")
	private String lastname;
	
	@Column(name="city", table="address")
	private String city ;
	
	@Column(name="state", table="address")
	private String state ;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	
}

package com.majesco.dcf.receipt.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.covernote.json.CNFlagProposalResponse;
import com.majesco.dcf.covernote.json.CheckCNFlagForProposal;
import com.majesco.dcf.covernote.service.WcfGCIntegrationService;
import com.majesco.dcf.receipt.json.AdvanceReceiptDepositDtls;
import com.majesco.dcf.receipt.json.AdvanceReceiptDepositDtlsRequest;
import com.majesco.dcf.receipt.json.AdvanceReceiptDepositDtlsResponse;
import com.majesco.dcf.receipt.json.ChequeDishonourRequest;
import com.majesco.dcf.receipt.json.ChequeDishonourResponse;
import com.majesco.dcf.receipt.json.DeleteReceiptRequest;
import com.majesco.dcf.receipt.json.DeleteReceiptResponse;
import com.majesco.dcf.receipt.json.FetchPaySlipReportRequest;
import com.majesco.dcf.receipt.json.FetchPaySlipReportResponse;
import com.majesco.dcf.receipt.json.FetchPayinSlipReportRequest;
import com.majesco.dcf.receipt.json.FetchPayinSlipReportResponse;
import com.majesco.dcf.receipt.json.FetchReceiptAlterationRequest;
import com.majesco.dcf.receipt.json.FetchReceiptAlterationResponse;
import com.majesco.dcf.receipt.json.GeneratePayingSlipRequest;
import com.majesco.dcf.receipt.json.GeneratePayingSlipResponse;
import com.majesco.dcf.receipt.json.PaymentEntryEODRequest;
import com.majesco.dcf.receipt.json.PaymentEntryEODResponse;
import com.majesco.dcf.receipt.json.PrintRecieptRequest;
import com.majesco.dcf.receipt.json.PrintRecieptResponse;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyResponse;
import com.majesco.dcf.receipt.json.ReceiptDetailsRequest;
import com.majesco.dcf.receipt.json.ReceiptDetailsResponse;
import com.majesco.dcf.receipt.json.SavePayinPdfRequest;
import com.majesco.dcf.receipt.json.SavePayinPdfResponse;
import com.majesco.dcf.receipt.json.SaveReceiptAlterationRequest;
import com.majesco.dcf.receipt.json.SaveReceiptAlterationResponse;
import com.majesco.dcf.receipt.json.getPolicyDetailsEODRequest;
import com.majesco.dcf.receipt.json.getPolicyDetailsEODResponse;
import com.majesco.dcf.receipt.service.ReceiptService;
import com.majesco.dcf.common.chp.util.AesUtil;



@Controller
@RequestMapping(value="/accountservice")
public class ReceiptController {
	@Autowired
	ReceiptService receiptService;
	
	@Autowired
	WcfGCIntegrationService wcfGCIntegrationService;
	
	//Start: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
	@Value("${aes.passphrase}")
	private String passphrase;
		
	@Value("${aes.iterationCount}")
	private String iterationCount;
		
	@Value("${aes.keySize}")
	private String keySize;
		
	@Value("${passwordEncryptionApplied}")
	private String isAesEncryption;
		
	@Value("${aes.salt}")
	private String aesSalt;
		
	@Value("${aes.iv}")
	private String aesIv;	
	//End: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
	
	final static Logger logger=Logger.getLogger(ReceiptController.class);
	private Gson gson=new Gson();	
	@RequestMapping(value="/receiptPolicy/", method = RequestMethod.POST)
	@ResponseBody
	public ReceiptCumPolicyResponse createReceiptCumPolicy(@RequestBody ReceiptCumPolicyRequest accountServReq,HttpServletRequest httpServletRequest) throws Exception{
		ReceiptCumPolicyResponse receiptResponse=null;
		long transId=System.nanoTime();
		try{
			accountServReq.setProcessTransId(String.valueOf(transId));
			
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			accountServReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			logger.info("Auth token received from Request Header..--> "+accountServReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			
			/*Code To Set System IP Starts Here*/
			String ipAddress = null;
			ipAddress = ServiceUtility.getClientIpAddr(httpServletRequest);
			accountServReq.setSystemIPAddress(ipAddress);
			accountServReq.setSystemIP(ipAddress);
			/*Code To Set System IP Ends Here*/
			
		logger.info("Start::"+transId+"::Inside ReceiptController :: createReceiptCumPolicy method :: Entered");
		//Start:11/03/2017:Changes done for proposal with cover note handling
			if (accountServReq.getProposalDetails() != null
					&& accountServReq.getProposalDetails().getProposalNo() != null) {
				CheckCNFlagForProposal checkCNFlagForProposal = new CheckCNFlagForProposal();
				checkCNFlagForProposal.setProposalNo(accountServReq
						.getProposalDetails().getProposalNo());
				CNFlagProposalResponse cnFlagProposalResponse = wcfGCIntegrationService
						.isCoverNoteProposal(checkCNFlagForProposal);
				if (cnFlagProposalResponse != null && cnFlagProposalResponse.getCnFlag()!=null && cnFlagProposalResponse.getCnFlag().equalsIgnoreCase(CommonConstants.SUCCESS_STATUS)) {
					accountServReq
							.setIsCoverNoteProposal(cnFlagProposalResponse
									.getCnFlag());
				}else{
					accountServReq.setIsCoverNoteProposal(CommonConstants.FAILURE_STATUS);
				}
			}//End:11/03/2017:Changes done for proposal with cover note handling
		receiptResponse=receiptService.createReceiptPolicy(accountServReq,false);
		
		logger.info("End::"+transId+"::Inside ReceiptController :: createReceiptCumPolicy method :: Exit");
		}catch(Exception ex){
			logger.error("Inside ReceiptController :: createReceiptCumPolicy method :: Exception::", ex);
			if(receiptResponse==null){
				receiptResponse=new ReceiptCumPolicyResponse();
				receiptResponse.setResultCode("0");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError error=new ResponseError();
				error.setErrorCode("ERR01");
				error.setErrorMMessag(ex.getMessage()+":: Transaction Id::"+transId);
				errorList.add(error);
				receiptResponse.setErrorList(errorList);
			}
		}
		return receiptResponse;
	}

	
	@RequestMapping(value="/fetchReceiptDetailsForCash/", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ReceiptDetailsResponse> fetchReceiptDetailsForCash(@RequestBody ReceiptDetailsRequest receiptDetailsReq ,HttpServletRequest httpServletRequest) throws Exception{
		logger.info("In ReceiptController :: fetchReceiptDetailsForCash method");
		ArrayList<ReceiptDetailsResponse> receiptDetailsResp=null;
		
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		receiptDetailsReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+receiptDetailsReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		
		receiptDetailsResp=receiptService.fetchReceiptDetailsForCash(receiptDetailsReq);
		
		logger.info("Out ReceiptController :: fetchReceiptDetailsForCash method");
		return receiptDetailsResp;
	}
	
	@RequestMapping(value="/fetchReceiptDetailsForChequeDD/", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ReceiptDetailsResponse> fetchReceiptDetailsForChequeDD(@RequestBody ReceiptDetailsRequest receiptDetailsReq,HttpServletRequest httpServletRequest) throws Exception{
		logger.info("In ReceiptController :: fetchReceiptDetailsForChequeDD method");
		ArrayList<ReceiptDetailsResponse> receiptDetailsResp=null;
		
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		receiptDetailsReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+receiptDetailsReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
				
		receiptDetailsResp=receiptService.fetchReceiptDetailsForChequeDD(receiptDetailsReq);
		
		logger.info("Out ReceiptController :: fetchReceiptDetailsForChequeDD method");
		return receiptDetailsResp;
	}
	
	@RequestMapping(value="/generatePayingSlip/", method = RequestMethod.POST)
	@ResponseBody
	public GeneratePayingSlipResponse generatePayingSlip(@RequestBody GeneratePayingSlipRequest receiptDetailsResp,HttpServletRequest httpServletRequest) throws Exception{
		logger.info("In ReceiptController :: generatePayingSlip method$$");
		//Portal lock related changes
		receiptDetailsResp.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from generatePayingSlip service Request Header--> "+receiptDetailsResp.getAuthToken());
		
		GeneratePayingSlipResponse generateSlipResp=new GeneratePayingSlipResponse(); 
		
		generateSlipResp=receiptService.generatePayingSlip(receiptDetailsResp);
		generateSlipResp.setReceiptDetailsResp(receiptDetailsResp);
		
		logger.info("Out ReceiptController :: generatePayingSlip method");
		return generateSlipResp;
	}
	
	@RequestMapping(value="/fetchPayinSlipReport/", method = RequestMethod.POST)
	@ResponseBody
	//public ArrayList<FetchPaySlipReportResponse> fetchPaySlipReport(@RequestBody FetchPaySlipReportRequest fetchPaySlipReportReq ,HttpServletRequest httpServletRequest) throws Exception{ //Commented For 413 Status Issue
	public ResponseEntity<String> fetchPaySlipReport(@RequestBody FetchPaySlipReportRequest fetchPaySlipReportReq ,HttpServletRequest httpServletRequest) throws Exception{ //Added For 413 Status Issue
		logger.info("In ReceiptController :: FetchPaySlipReportRequest method");
		ArrayList<FetchPaySlipReportResponse> fetPaySlipPayResp=null; 
		HttpHeaders responseHeaders =  new HttpHeaders(); //Added for 413 status issue
		ResponseEntity responseEntity = null; //Added for 413 status issue
		String result=null; //Added for 413 status issue
		
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		fetchPaySlipReportReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+fetchPaySlipReportReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		
		fetPaySlipPayResp=receiptService.fetchPaySlipReport(fetchPaySlipReportReq);
		
		/*Added For 413 Status Issue Starts Here*/
		if(fetPaySlipPayResp!=null && fetPaySlipPayResp.get(0)!=null && fetPaySlipPayResp.get(0).getErrorCode()!=null && fetPaySlipPayResp.size()>0 && !fetPaySlipPayResp.get(0).getErrorCode().equalsIgnoreCase("0")){
			result=gson.toJson(fetPaySlipPayResp);
			logger.info("VJ  1:- "+result+"HttpStatus.OK :- "+HttpStatus.OK +" ## "+fetPaySlipPayResp.size());
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.OK);
		}
		else{
			result="No Data Found";
			logger.info("VJ  2:- "+result+"HttpStatus.NO_CONTENT :- "+HttpStatus.NO_CONTENT+" ## "+fetPaySlipPayResp.size());
			responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);	
		}
		/*Added For 413 Status Issue Ends Here*/
		
		logger.info("Out ReceiptController :: FetchPaySlipReportRequest method");
		//return fetPaySlipPayResp; //Commented For 413 Status Issue
		return responseEntity; //Added For 413 Status Issue
	}
	
	@RequestMapping(value="/printPayinSlipReport/", method = RequestMethod.POST)
	@ResponseBody
	public FetchPayinSlipReportResponse fetchPayinSlipReport(@RequestBody FetchPayinSlipReportRequest fetchPayinSlipReportReq ,HttpServletRequest httpServletRequest) throws Exception{
		logger.info("In ReceiptController :: fetchPayinSlipReport method");
		FetchPayinSlipReportResponse fetPayinSlipPayResp=null; 
		
		//Start:RahulT<VAPT comments>| code added to set GC token into user object 
		fetchPayinSlipReportReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		logger.info("Auth token received from Request Header..--> "+fetchPayinSlipReportReq.getAuthToken());
		//End:RahulT<VAPT comments>| code added to set GC token into user object
		
		fetPayinSlipPayResp=receiptService.fetchPayinSlipReport(fetchPayinSlipReportReq);
		
		logger.info("Out ReceiptController :: fetchPayinSlipReport method");
		return fetPayinSlipPayResp;
	}
	
	@RequestMapping(value="/fetchReceiptAlteration/", method = RequestMethod.POST)
	@ResponseBody
	public FetchReceiptAlterationResponse fetchReceiptAlteration(@RequestBody FetchReceiptAlterationRequest fetchReceiptAlterationReq ,HttpServletRequest httpServletRequest) throws Exception{
		logger.info("In ReceiptController :: fetchReceiptAlteration method");
		FetchReceiptAlterationResponse fetchReceiptAlterationResp=null; 
		
		//fetchReceiptAlterationResp=receiptService.fetchReceiptAlteration(fetchReceiptAlterationReq);
		
		logger.info("Out ReceiptController :: fetchReceiptAlteration method");
		return fetchReceiptAlterationResp;
	}
	
	@RequestMapping(value="/saveReceiptAlteration/", method = RequestMethod.POST)
	@ResponseBody
	public SaveReceiptAlterationResponse saveReceiptAlteration(@RequestBody SaveReceiptAlterationRequest saveReceiptAlterationReq ,HttpServletRequest httpServletRequest) throws Exception{
		logger.info("In ReceiptController :: fetchPayinSlipReport method");
		SaveReceiptAlterationResponse saveReceiptAlterationResp=null; 
		
		//saveReceiptAlterationResp=receiptService.saveReciptAlteration(saveReceiptAlterationReq);
		
		logger.info("Out ReceiptController :: fetchPayinSlipReport method");
		return saveReceiptAlterationResp;
	}
	
	@RequestMapping(value="/fetchAdvReceipt/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> fetchAdvReceipt(@RequestBody String requestJson/*@RequestBody AdvanceReceiptDepositDtlsRequest advReceiptDepReq*/,HttpServletRequest httpServletRequest) throws Exception{
		long transId=System.nanoTime();
		logger.info("In ReceiptController :: fetchAdvReceipt method Start");
		
		AdvanceReceiptDepositDtlsResponse advReceiptRes=null;
		AdvanceReceiptDepositDtlsRequest advReceiptDepReq=null;
		String result=null;		
		HttpHeaders responseHeaders =  new HttpHeaders();
		ResponseEntity responseEntity=null;		
		
		try{
			advReceiptDepReq=gson.fromJson(requestJson, AdvanceReceiptDepositDtlsRequest.class);
			
			List<AdvanceReceiptDepositDtls> advReceiptList=null;
			if(advReceiptDepReq!=null && advReceiptDepReq.getAdvReceiptDtls()!=null){
				//Start:RahulT<VAPT comments>| code added to set GC token into user object 
				//advReceiptDepReq.getAdvReceiptDtls().setAuthToken(httpServletRequest.getHeader("gc_token"));   // Commented to remove dependency from Internal Object : 08/06/2017
				advReceiptDepReq.setAuthToken(httpServletRequest.getHeader("gc_token"));   // Sending authToken into main request     
				logger.info("Auth token received from Request Header..--> "+advReceiptDepReq.getAuthToken());
				//End:RahulT<VAPT comments>| code added to set GC token into user object
				
				advReceiptList=receiptService.fetchAdvReceiptList(advReceiptDepReq);  //Sending Main Request to impl Method : 08/06/2017 : Vishal 
				
				if(advReceiptList!=null && advReceiptList.size()>0){
					
					advReceiptRes=new AdvanceReceiptDepositDtlsResponse();
					advReceiptRes.setAdvReceiptList(advReceiptList);
					
					result=gson.toJson(advReceiptRes);
					responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.OK);
				}
				else{
					advReceiptRes=new AdvanceReceiptDepositDtlsResponse();
					advReceiptRes.setResultCode("99");
					result="No Data Found";
					responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);	
				}																
			}
		}
			catch(Exception ex){
				logger.error("Inside ReceiptController :: createReceiptCumPolicy method :: Exception::", ex);
				if(advReceiptRes==null){
					advReceiptRes=new AdvanceReceiptDepositDtlsResponse();
					advReceiptRes.setResultCode("0");
					List<ResponseError> errorList=new ArrayList<ResponseError>();
					ResponseError error=new ResponseError();
					error.setErrorCode("ERR01");
					error.setErrorMMessag(ex.getMessage()+":: Transaction Id::"+transId);
					errorList.add(error);
					advReceiptRes.setResponseError(errorList);
					result=gson.toJson(advReceiptRes);
					responseEntity = new ResponseEntity(result,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);					
				}
		}
		logger.info("In ReceiptController :: fetchAdvReceipt method End");
		//return advReceiptRes;
		return responseEntity;
	}
	
	@RequestMapping(value="/deleteOrDeallocateRpt/", method = RequestMethod.POST)
	@ResponseBody
	public DeleteReceiptResponse deleteOrDeallocateReceipt(@RequestBody DeleteReceiptRequest advReceiptDepReq,HttpServletRequest httpServletRequest) throws Exception{
		
		ObjectMapper objMapper = new ObjectMapper();
		long transId=System.nanoTime();
		
		logger.info("In ReceiptController :: deleteOrDeallocateReceipt method ::: Input Data from UI--> "+objMapper.writeValueAsString(advReceiptDepReq));
		DeleteReceiptResponse response = null;
		try{
			//Start:RahulT<VAPT comments>| code added to set GC token into user object 
			advReceiptDepReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
			logger.info("Auth token received from Request Header..--> "+advReceiptDepReq.getAuthToken());
			//End:RahulT<VAPT comments>| code added to set GC token into user object
			response=receiptService.deleteOrDeallocateReceipt(advReceiptDepReq);
		}
		catch(Exception ex){
			ex.printStackTrace();
			if(response==null){
				response=new DeleteReceiptResponse();
				response.setErrorCode("0");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError error=new ResponseError();
				error.setErrorCode("ERR01");
				error.setErrorMMessag(ex.getMessage()+":: Transaction Id::"+transId);
				errorList.add(error);
				response.setResponseError(errorList);
			}
		}
		return response;
	}
	
	@RequestMapping(value="/printReceipt/", method = RequestMethod.POST)
	@ResponseBody
	public PrintRecieptResponse printPolicyReceipt(@RequestBody PrintRecieptRequest objPrintReceipt, HttpServletRequest httpServletRequest) throws Exception{
		
		ObjectMapper objMapper = new ObjectMapper();
		long transId = System.nanoTime();
		
		logger.info("In ReceiptController :: deleteOrDeallocateReceipt method ::: Input Data from UI--> "+objMapper.writeValueAsString(objPrintReceipt));
		PrintRecieptResponse response = null;
		
		try{
			//Start: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
			if (objPrintReceipt.getPassword()!=null && !objPrintReceipt.getPassword().equals(""))
			{
				if (isAesEncryption!=null && isAesEncryption.equals(CommonConstants.YES_FLAG_VAL2)){
			        String strIV = new String(Base64.decodeBase64(aesIv));
			        String strSalt = new String(Base64.decodeBase64(aesSalt));
			        String phrasePass = new String(Base64.decodeBase64(passphrase));
					String ciphertext = objPrintReceipt.getPassword();
			        AesUtil aesUtil = new AesUtil(Integer.parseInt(keySize),Integer.parseInt(iterationCount));
			        //if(logger.isDebugEnabled())logger.debug("iv value ..--> "+strIV+", salt value--> "+strSalt+", ciphertext--> "+ciphertext);
			        String decodePass = aesUtil.decrypt(strSalt, strIV, phrasePass, ciphertext);
			        logger.info("Pasword has been decoded successfully--> "+decodePass);
			        objPrintReceipt.setPassword(decodePass);
				}
			}
			//End: RahulT <VAPT comments>| added to decrypt AES encrypted password - Issue ID 1323
			response=receiptService.printReceipt(objPrintReceipt);
		}
		catch(Exception ex){
			ex.printStackTrace();
			if(response==null){
				response=new PrintRecieptResponse();
				response.setResultCode("0");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError error=new ResponseError();
				error.setErrorCode("ERR01");
				error.setErrorMMessag(ex.getMessage()+":: Transaction Id::"+transId);
				errorList.add(error);
				response.setResponseError(errorList);
			}
		}
		return response;
	}
	
	//Added for Online transaction
	/*@RequestMapping(value="/receiptPolicyOL/", method = RequestMethod.POST)
	public String getBilldeskURL(Locale locale, Model model,@RequestBody ReceiptCumPolicyRequest accountServReq, HttpServletRequest httpServletRequest) throws Exception{
		
		Map<String, String> mapVal = new HashMap<String, String>();
		logger.info("In ReceiptController :: getBilldeskURL method ::: Entered ");
			
			try {
				
				mapVal = receiptService.getBilldeskPage(accountServReq);
				
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("In ReceiptController :: getBilldeskURL method :::", e);
			}
			
			model.addAttribute("msg", mapVal.get("msg"));
			model.addAttribute("txtPayCategory", mapVal.get("txtPayCategory"));
			return CommonConstants.BILLDESK_PAY_REQ;
	}*/
	
	@RequestMapping(value="/getPolicyDetailsEOD/", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<getPolicyDetailsEODResponse> getPolicyDetailsEOD(@RequestBody getPolicyDetailsEODRequest policyDetailsEODRequest,HttpServletRequest httpServletRequest) throws Exception{
		
		ObjectMapper objMapper = new ObjectMapper();
		long transId=System.nanoTime();
		
		logger.info("In ReceiptController :: getPolicyDetailsEOD method ::: Input Data from UI--> "+objMapper.writeValueAsString(policyDetailsEODRequest));
		ArrayList<getPolicyDetailsEODResponse> lstResponse = null;
		getPolicyDetailsEODResponse response = null;
		try{
			lstResponse=receiptService.getPolicyDetailsEOD(policyDetailsEODRequest);
		}
		catch(Exception ex){
			ex.printStackTrace();
			if(lstResponse==null){
				lstResponse=new ArrayList<getPolicyDetailsEODResponse>();
				response = new getPolicyDetailsEODResponse();
				response.setErrorCode("0");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError error=new ResponseError();
				error.setErrorCode("ERR01");
				error.setErrorMMessag(ex.getMessage()+":: Transaction Id::"+transId);
				errorList.add(error);
				response.setResponseError(errorList);
				lstResponse.add(response);
			}
		}
		return lstResponse;
	}
	
	@RequestMapping(value="/getPaymentEntryForEODPortal/", method = RequestMethod.POST)
	@ResponseBody
	public PaymentEntryEODResponse getPaymentEntryForEODPortal(@RequestBody PaymentEntryEODRequest accountServReq,HttpServletRequest httpServletRequest) throws Exception{
		PaymentEntryEODResponse receiptResponse=null;
		long transId=System.nanoTime();
		try{
			accountServReq.setProcessTransId(String.valueOf(transId));
			
		logger.info("Start::"+transId+"::Inside ReceiptController :: getPaymentEntryForEODPortal method :: Entered");
		
		receiptResponse=receiptService.getPaymentEntryForEODPortal(accountServReq);
		
		logger.info("End::"+transId+"::Inside ReceiptController :: getPaymentEntryForEODPortal method :: Exit");
		}catch(Exception ex){
			logger.error("Inside ReceiptController :: getPaymentEntryForEODPortal method :: Exception::", ex);
			if(receiptResponse==null){
				receiptResponse=new PaymentEntryEODResponse();
				receiptResponse.setResultCode("0");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError error=new ResponseError();
				error.setErrorCode("ERR01");
				error.setErrorMMessag(ex.getMessage()+":: Transaction Id::"+transId);
				errorList.add(error);
				receiptResponse.setErrorList(errorList);
			}
		}
		return receiptResponse;
	}
	
	//Start: RahulT <Production # 1169>| code added to fetch cheque dishonour detail on cheque bounce hyperlink
	@RequestMapping(value="/getChequeDishonourDtl/", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> getChequeDishonourDtl(@RequestBody ChequeDishonourRequest chequeDishonourReq, HttpServletRequest httpServletRequest) throws Exception{
		List<ChequeDishonourResponse> lstDishonourResponse=null;
		String result ="";
		Gson gson = new Gson();
		HttpHeaders responseHeaders =  new HttpHeaders();
		try{
			
		logger.info("Start::Inside ReceiptController :: getChequeDishonourDtl method :: Entered");
		chequeDishonourReq.setAuthToken(httpServletRequest.getHeader("gc_token"));
		//if(logger.isDebugEnabled())logger.debug("Auth token received from Request Header..--> "+chequeDishonourReq.getAuthToken());
		lstDishonourResponse = receiptService.getChequeDishonourDtl(chequeDishonourReq);
		if (lstDishonourResponse!=null && !lstDishonourResponse.isEmpty()){
			result = gson.toJson(lstDishonourResponse);
			logger.info("End: Inside ReceiptController :: getChequeDishonourDtl method :: Exit WITH SOME CONTENT");
			return new ResponseEntity(result,responseHeaders,HttpStatus.OK);
		}
		else{
			logger.info("End: Inside ReceiptController :: getChequeDishonourDtl method :: Exit WITH NO_CONTENT");
			return new ResponseEntity(result,responseHeaders,HttpStatus.NO_CONTENT);
		}
		
		
		}catch(Exception ex){
			logger.error("Inside ReceiptController :: getChequeDishonourDtl method :: Exception::", ex);
			
		}
		return new ResponseEntity(result,responseHeaders,HttpStatus.OK);
	}
	//End: RahulT <Production # 1169>| code added to fetch cheque dishonour detail on cheque bounce hyperlink
	
//Start: RahulT <VAPT Point 2: Production 1345> | added new service for printReceipt to bifurgate call from portal and SPL's Jsp page
	@RequestMapping(value="/printReceiptSPL/", method = RequestMethod.POST)
	@ResponseBody
	public PrintRecieptResponse printPolicyReceiptSPL(@RequestBody PrintRecieptRequest objPrintReceipt, HttpServletRequest httpServletRequest) throws Exception{
		
		ObjectMapper objMapper = new ObjectMapper();
		long transId = System.nanoTime();
		
		logger.info("In ReceiptController :: deleteOrDeallocateReceipt method ::: Input Data from UI--> "+objMapper.writeValueAsString(objPrintReceipt));
		PrintRecieptResponse response = null;
		
		try{
			response=receiptService.printReceipt(objPrintReceipt);
		}
		catch(Exception ex){
			ex.printStackTrace();
			if(response==null){
				response=new PrintRecieptResponse();
				response.setResultCode("0");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError error=new ResponseError();
				error.setErrorCode("ERR01");
				error.setErrorMMessag(ex.getMessage()+":: Transaction Id::"+transId);
				errorList.add(error);
				response.setResponseError(errorList);
			}
		}
		return response;
	}
	//End: RahulT <VAPT Point 2: Production 1345> | added new service for printReceipt to bifurgate call from portal and SPL's Jsp page
	
	// 2717 : VishalJ : new method to store PDF of Payin slip.:Start 
	@RequestMapping(value="/savePayinPdf/", method = RequestMethod.POST)
	@ResponseBody
	public SavePayinPdfResponse savePayinPdf(@RequestBody SavePayinPdfRequest savePayinPdfrequest ,HttpServletRequest httpServletRequest) throws Exception{
		logger.info("In ReceiptController :: fetchPayinSlipReport method");
		SavePayinPdfResponse savePayinPdfResponse=null; 
		
		savePayinPdfResponse=receiptService.savePayinPdf(savePayinPdfrequest);
		
		logger.info("Out ReceiptController :: fetchPayinSlipReport method");
		return savePayinPdfResponse;
	}
	// 2717 : VishalJ : new method to store PDF of Payin slip. :End 
	
	
	
}

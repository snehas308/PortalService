package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include= JsonSerialize.Inclusion.NON_EMPTY)
public class PolicySearchRequest extends UserObject{
private String lvTokenId;
private String policyNo;
private String lob;
private String productCode;
private String vehRegdNo;
private String quotationNo;
private String proposalNo;
private String manualCoverNoteNo;
private String receiptNo;
private String instrumentNo;
private String authorizationNo;
private String partnerAppNo;
private String mobileNo;
//private String producerCode;
private String userId;
public String getLvTokenId() {
	return lvTokenId;
}
public void setLvTokenId(String lvTokenId) {
	this.lvTokenId = lvTokenId;
}
public String getPolicyNo() {
	return policyNo;
}
public void setPolicyNo(String policyNo) {
	this.policyNo = policyNo;
}
public String getLob() {
	return lob;
}
public void setLob(String lob) {
	this.lob = lob;
}
public String getProductCode() {
	return productCode;
}
public void setProductCode(String productCode) {
	this.productCode = productCode;
}
public String getVehRegdNo() {
	return vehRegdNo;
}
public void setVehRegdNo(String vehRegdNo) {
	this.vehRegdNo = vehRegdNo;
}
public String getQuotationNo() {
	return quotationNo;
}
public void setQuotationNo(String quotationNo) {
	this.quotationNo = quotationNo;
}
public String getProposalNo() {
	return proposalNo;
}
public void setProposalNo(String proposalNo) {
	this.proposalNo = proposalNo;
}
public String getManualCoverNoteNo() {
	return manualCoverNoteNo;
}
public void setManualCoverNoteNo(String manualCoverNoteNo) {
	this.manualCoverNoteNo = manualCoverNoteNo;
}
public String getReceiptNo() {
	return receiptNo;
}
public void setReceiptNo(String receiptNo) {
	this.receiptNo = receiptNo;
}
public String getInstrumentNo() {
	return instrumentNo;
}
public void setInstrumentNo(String instrumentNo) {
	this.instrumentNo = instrumentNo;
}
public String getAuthorizationNo() {
	return authorizationNo;
}
public void setAuthorizationNo(String authorizationNo) {
	this.authorizationNo = authorizationNo;
}
public String getPartnerAppNo() {
	return partnerAppNo;
}
public void setPartnerAppNo(String partnerAppNo) {
	this.partnerAppNo = partnerAppNo;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
/*public String getProducerCode() {
	return producerCode;
}
public void setProducerCode(String producerCode) {
	this.producerCode = producerCode;
}*/
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}



}

package com.majesco.dcf.motor.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.motor.json.InspectionRequest;
import com.majesco.dcf.motor.json.InspectionResponse;

@Service
@Transactional
public interface InspectionCoverNoteService {

	public InspectionResponse triggerPreInspection(InspectionRequest inspectionRequest) throws Exception;
	
	public InspectionResponse triggerCoverNote(InspectionRequest inspectionRequest) throws Exception;
}

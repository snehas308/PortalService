package com.majesco.dcf.motor.json;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CalculatorMotorResponse {

	private String resultCode;
	List<ResponseError> resErr ;
	List<PremiumDetails> premiumDetails ;
	private List<PremiumBreakup> prmbrk;
	private PremiumDetails prmdet;
	private String rulesWarning; //Added For Issue ID 1615

	private YearWiseIDVDetails yearWiseIDVDtls; //Added For Issue ID 1318
	
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public List<PremiumDetails> getPremiumDetails() {
		return premiumDetails;
	}
	public void setPremiumDetails(List<PremiumDetails> premiumDetails) {
		this.premiumDetails = premiumDetails;
	}
	public List<PremiumBreakup> getPrmbrk() {
		return prmbrk;
	}
	public void setPrmbrk(List<PremiumBreakup> prmbrk) {
		this.prmbrk = prmbrk;
	}
	public PremiumDetails getPrmdet() {
		return prmdet;
	}
	public void setPrmdet(PremiumDetails prmdet) {
		this.prmdet = prmdet;
	}
	/*Added For Issue ID 1318 - Starts Here*/
	public YearWiseIDVDetails getYearWiseIDVDtls() {
		return yearWiseIDVDtls;
	}
	public void setYearWiseIDVDtls(YearWiseIDVDetails yearWiseIDVDtls) {
		this.yearWiseIDVDtls = yearWiseIDVDtls;
	}
	/*Added For Issue ID 1318 - Starts Here*/
	/*Added For Issue ID 1615 - Starts Here*/
	public String getRulesWarning() {
		return rulesWarning;
	}
	public void setRulesWarning(String rulesWarning) {
		this.rulesWarning = rulesWarning;
	}
	/*Added For Issue ID 1615 - Ends Here*/
	
}

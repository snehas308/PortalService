package com.majesco.dcf.common.tagic.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
//@Table(name = "dcf_acc_financier_branch",schema="dcf_master")			// Commented for Oracle Migration
@Table(name = "dcf_acc_financier_branch")								// Added for oracle migration
public class AccFinancierBranch {
	private Integer nfinanciercd;
	private Integer nfinbranchseq;
	private String strfinancierbranchcd;
	private String strbranchname;
	private Integer nischqgenreq;
	private Integer nischqnomanual;
	private String strmicrcd;
	private String strifsccd;
	private Integer nisactive;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	//private AccFinancierMaster accFinMast;
	
	@Column(name = "nfinanciercd")
	public Integer getNfinanciercd() {
		return nfinanciercd;
	}
	public void setNfinanciercd(Integer nfinanciercd) {
		this.nfinanciercd = nfinanciercd;
	}
	
	@Id
	@Column(name = "nfinbranchseq")
	public Integer getNfinbranchseq() {
		return nfinbranchseq;
	}
	public void setNfinbranchseq(Integer nfinbranchseq) {
		this.nfinbranchseq = nfinbranchseq;
	}
	
	@Column(name = "strfinancierbranchcd")
	public String getStrfinancierbranchcd() {
		return strfinancierbranchcd;
	}
	public void setStrfinancierbranchcd(String strfinancierbranchcd) {
		this.strfinancierbranchcd = strfinancierbranchcd;
	}
	
	@Column(name = "strbranchname")
	public String getStrbranchname() {
		return strbranchname;
	}
	public void setStrbranchname(String strbranchname) {
		this.strbranchname = strbranchname;
	}
	
	@Column(name = "nischqgenreq")
	public Integer getNischqgenreq() {
		return nischqgenreq;
	}
	public void setNischqgenreq(Integer nischqgenreq) {
		this.nischqgenreq = nischqgenreq;
	}
	
	@Column(name = "nischqnomanual")
	public Integer getNischqnomanual() {
		return nischqnomanual;
	}
	public void setNischqnomanual(Integer nischqnomanual) {
		this.nischqnomanual = nischqnomanual;
	}
	
	@Column(name = "strmicrcd")
	public String getStrmicrcd() {
		return strmicrcd;
	}
	public void setStrmicrcd(String strmicrcd) {
		this.strmicrcd = strmicrcd;
	}
	
	@Column(name = "strifsccd")
	public String getStrifsccd() {
		return strifsccd;
	}
	public void setStrifsccd(String strifsccd) {
		this.strifsccd = strifsccd;
	}
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	/*@OneToOne
    @JoinColumn(name="nfinanciercd", nullable=false)
	public AccFinancierMaster getAccFinMast() {
		return accFinMast;
	}
	public void setAccFinMast(AccFinancierMaster accFinMast) {
		this.accFinMast = accFinMast;
	}*/
}

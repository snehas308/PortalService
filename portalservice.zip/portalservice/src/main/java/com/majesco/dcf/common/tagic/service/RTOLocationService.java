package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.ehcache.annotations.Cacheable;
import com.majesco.dcf.common.tagic.entity.RTOLocation;
import com.majesco.dcf.common.tagic.json.RTOLocationRequest;
import com.majesco.dcf.common.tagic.json.RTOLocationResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;


@Service
public class RTOLocationService {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(RTOLocationService.class);
	
	@SuppressWarnings("null")
	@Cacheable(cacheName="rtoLocationInfoEhcache")
	public RTOLocationResponse fetchRTOLocation(RTOLocationRequest modelreq) throws Exception
	{
		RTOLocationResponse modelres = new RTOLocationResponse();
		try
		{
		
		logger.info("In ModelService.getRTOLocation() Method Begin()...");
		
		String strrtolocationcd="";
		String strrtolocationdesc="";
		
		List<ResponseError> reserrList = new ArrayList<ResponseError>();
		
		
		ResponseError res = new ResponseError();
		res.setErrorCode("101");
		res.setErrorMMessag("Sorry Authentication Issue....");
		reserrList.add(res);
		
		@SuppressWarnings("unchecked")
		//List<Integer> idvList =  (List<Integer>) dbserv.getVehicleIdv("com.majesco.dcf.common.tagic.entity.VehicleIdv", modelreq);
		List<RTOLocation> idvList =  (List<RTOLocation>) dbserv.fetchRTOLocation("com.majesco.dcf.common.tagic.entity.RTOLocation", modelreq);
        for(RTOLocation idv:idvList){
        
        	strrtolocationcd = idv.getStrrtolocationcd();
        	strrtolocationdesc = idv.getStrrtolocationdesc();
        }
        
        modelres.setStrrtolocationcd(strrtolocationcd);
        modelres.setStrrtolocationdesc(strrtolocationdesc);
        
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In ModelService.getModelInfo() Method End()...");
		ObjectMapper objMap=new ObjectMapper();
		//System.out.println(objMap.writeValueAsString(modelres));
		logger.info("In ModelService.getModelInfo() Method ::: "+modelres);
		
		return modelres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }
}

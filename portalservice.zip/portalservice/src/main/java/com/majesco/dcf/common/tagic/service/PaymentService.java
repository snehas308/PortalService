package com.majesco.dcf.common.tagic.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.pg.upi.json.UpiTransactionRequest; //1266
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;

@Service
@Transactional
public interface PaymentService {
	
	//public String billdeskPaymentRequest(PaymentRequest paymentRequest) throws Exception;
	//Start:<YogeshM>:<18/04/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration - added isRenew flag>
	public String billdeskPaymentRequest(String orderID, String transAmt, String userId,String txnMode, String txnModeVal, String productCode, String producerCode, String transType, String isRenew) 
			throws ClassNotFoundException,InstantiationException, IllegalAccessException; //End:<YogeshM>:<18/04/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration - added isRenew flag>
	public Map<String, String> verifyBilldeskTrans(String msg) throws Exception;
	public String generateOrderID() throws Exception;
	public Map <String,String> getSelfPayURLDetails(String transactionID) throws Exception;
	public Map<String, String> billdeskResponse(String msg) throws Exception;
	public Map<String, String> selfPayResponse(String msg) throws Exception;
	public HashMap<String, String> processOLPartPayment (ReceiptCumPolicyRequest accountServReq) throws Exception;
//Start: RahulT<1266> | code added for UPI integration
	public Map<String, String> finalResponseAPIHSBC(String msg) throws Exception;
	public boolean validateVPA (UpiTransactionRequest upiTxnReq) throws Exception;
	//End: RahulT<1266>| code added for separate service for UPI transaction
	
	// Start : Dinesh | lite service for payment.
	public Map<String, String> selfPayLitePaymentService(String msg) throws Exception; 
	// End : Dinesh | lite service for payment.
}

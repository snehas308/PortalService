package com.majesco.dcf.covernote.json;

public class MissingCoverNoteDtl {
	private String canceledReason;
	private String leafNumber;
	private String bookNumber;
	private String updatedStatus;
	private String otherReason;
	public String getCanceledReason() {
		return canceledReason;
	}
	public void setCanceledReason(String canceledReason) {
		this.canceledReason = canceledReason;
	}
	public String getLeafNumber() {
		return leafNumber;
	}
	public void setLeafNumber(String leafNumber) {
		this.leafNumber = leafNumber;
	}
	public String getUpdatedStatus() {
		return updatedStatus;
	}
	public void setUpdatedStatus(String updatedStatus) {
		this.updatedStatus = updatedStatus;
	}
	public String getOtherReason() {
		return otherReason;
	}
	public void setOtherReason(String otherReason) {
		this.otherReason = otherReason;
	}
	public String getBookNumber() {
		return bookNumber;
	}
	public void setBookNumber(String bookNumber) {
		this.bookNumber = bookNumber;
	}
	
	
}

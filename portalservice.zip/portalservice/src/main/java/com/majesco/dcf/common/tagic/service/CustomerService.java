package com.majesco.dcf.common.tagic.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.tagic.json.CreateCustomerRequest;
import com.majesco.dcf.common.tagic.json.CreateCustomerResponse;
import com.majesco.dcf.common.tagic.json.CustomerDetailRequest;
import com.majesco.dcf.common.tagic.json.CustomerDetailResponse;
import com.majesco.dcf.common.tagic.json.CustomerSearchLiteRequest;
import com.majesco.dcf.common.tagic.json.CustomerSearchLiteResponse;
import com.majesco.dcf.common.tagic.json.CustomerSearchRequest;
import com.majesco.dcf.common.tagic.json.CustomerSearchResponse;
import com.majesco.dcf.common.tagic.json.UpdateCustomerRequest;
import com.majesco.dcf.common.tagic.json.UpdateCustomerResponse;

@Service
@Transactional
public interface CustomerService {
	
	public CustomerDetailResponse getCustomerDetails(CustomerDetailRequest custoReq) throws Exception;
	public CustomerDetailResponse getCustomerListDetails(CustomerDetailRequest custoReq) throws Exception;
	public CreateCustomerResponse createCustomer(CreateCustomerRequest objCreateCust) throws Exception;
	public CustomerSearchLiteResponse getCustomerDetails(CustomerSearchLiteRequest custreq) throws Exception;
	public UpdateCustomerResponse updateCustomer(UpdateCustomerRequest updtreq) throws Exception;
	public CustomerSearchLiteResponse getLightCustomerDetails(CustomerSearchLiteRequest custreq) throws Exception;
	
	public CustomerSearchResponse searchCustomer(CustomerSearchRequest customerSearchRequest) throws Exception;
	
	public CustomerDetailResponse getCustomerListDetailsFromPortal(CustomerDetailRequest custoReq) throws Exception;
	
	public CustomerSearchResponse searchCustomerFromPortal(CustomerSearchRequest customerSearchRequest) throws Exception;
	
	public CreateCustomerResponse editCustomer(CreateCustomerRequest createReq)throws Exception; //<1840> : Vishal : Method to edit customer detail.

}

package com.majesco.dcf.motor.json;

public class SummarySection {

private String desclabelkey;
private String premiumAmt;
public String getDesclabelkey() {
	return desclabelkey;
}
public void setDesclabelkey(String desclabelkey) {
	this.desclabelkey = desclabelkey;
}
public String getPremiumAmt() {
	return premiumAmt;
}
public void setPremiumAmt(String premiumAmt) {
	this.premiumAmt = premiumAmt;
}

}

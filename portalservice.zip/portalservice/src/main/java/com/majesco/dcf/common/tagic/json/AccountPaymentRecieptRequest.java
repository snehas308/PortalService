package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class AccountPaymentRecieptRequest {
	
	private String custName;
	private Integer amtPayable;
	private Integer propNum;
	private String polIncptnDt;
	private String prodName;
	private PaymentDetails lstPaymentDet;
	//private String authenticationToken;
	
	
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	
	public Integer getAmtPayable() {
		return amtPayable;
	}
	public void setAmtPayable(Integer amtPayable) {
		this.amtPayable = amtPayable;
	}
	
	
	public Integer getPropNum() {
		return propNum;
	}
	public void setPropNum(Integer propNum) {
		this.propNum = propNum;
	}
	
	
	public String getPolIncptnDt() {
		return polIncptnDt;
	}
	public void setPolIncptnDt(String polIncptnDt) {
		this.polIncptnDt = polIncptnDt;
	}
	
	
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	
	
	public PaymentDetails getLstPaymentDet() {
		return lstPaymentDet;
	}
	public void setLstPaymentDet(PaymentDetails lstPaymentDet) {
		this.lstPaymentDet = lstPaymentDet;
	}
	
	
//	public String getAuthenticationToken() {
//		return authenticationToken;
//	}
//	public void setAuthenticationToken(String authenticationToken) {
//		this.authenticationToken = authenticationToken;
//	}
//	
	
	
}

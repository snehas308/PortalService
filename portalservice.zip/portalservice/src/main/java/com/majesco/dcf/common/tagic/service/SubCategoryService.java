package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.ehcache.annotations.Cacheable;
import com.majesco.dcf.common.tagic.entity.SubCategory;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.SubCategoryRequest;
import com.majesco.dcf.common.tagic.json.SubCategoryResponse;

@Service
public class SubCategoryService {
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(SubCategoryService.class);
	
	@SuppressWarnings({ "null", "unchecked" })
	@Cacheable(cacheName="subCategoryInfoEhcache")
	public SubCategoryResponse getSubCategory(SubCategoryRequest docreq) throws Exception
	{
		SubCategoryResponse docres = new SubCategoryResponse();
		ArrayList docArr = new ArrayList();
		try
		{
		
			logger.info("In SubCategoryService.getSubCategory() Method Begin()...");
			
			List<String> strservreqsubcatcd = new ArrayList<String>(); 
			List<String> strcddesc = new ArrayList<String>();
			List<String> strtype = new ArrayList<String>();
			List<String> strsubtype = new ArrayList<String>();
			List<String> strgrp = new ArrayList<String>(); 
			List<String> strsubgrp = new ArrayList<String>();
			
			
			List<ResponseError> reserrList = new ArrayList<ResponseError>();
			
			
			ResponseError res = new ResponseError();
			res.setErrorCode("101");
			res.setErrorMMessag("Sorry Authentication Issue....");
			reserrList.add(res);
			
	
			docArr = (ArrayList<Object>) dbserv.getSubCategory("com.majesco.dcf.common.tagic.entity.SubCategory", docreq);
			for(int i=0; i< docArr.size(); i++)
			{
		        SubCategory ent = new SubCategory();
		        ent = (SubCategory) docArr.get(i);
		        strservreqsubcatcd.add(ent.getStrservreqsubcatcd());
		        strcddesc.add(ent.getStrcddesc());
		        strtype.add(ent.getStrtype());
		        strsubtype.add(ent.getStrsubtype());
		        strgrp.add(ent.getStrgrp());
		        strsubgrp.add(ent.getStrsubgrp());
	        }
			docres.setStrcddesc(strcddesc);
			docres.setStrgrp(strgrp);
			docres.setStrservreqsubcatcd(strservreqsubcatcd);
			docres.setStrsubgrp(strsubgrp);
			docres.setStrsubtype(strsubtype);
			docres.setStrtype(strtype);
		}
		catch(Exception e)
		{
			//System.out.println(e.toString());
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In SubCategoryService.getSubCategory() Method End()...");
//		ObjectMapper objMap=new ObjectMapper();
//		System.out.println(objMap.writeValueAsString(docres));
		logger.info("In SubCategoryService.getSubCategory() Method :: Response Of variantres : "+docres);
		
		return docres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }


}

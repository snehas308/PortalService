package com.majesco.dcf.constant;

public class TwoWheelVehConstants {
	
	private TwoWheelVehConstants(){}
	

	
/*	public static final String CALCULATOR_VEHICLE_TYPE_VALUE_PV = "1";
	public static final String RTO_SIGN_CHECK = "-";
	public static final String MAPPING_XML_FILE_NAME = "MotorMapping.xml";
	public static final String RESOURCE_PROPERTIES_FILE_NAME = "resource.properties";
	public static final String RESULTMAP_KEY_NAME_INTERMEDIARY_NAME = "intermediary_name";
	public static final String CALCULATOR_MAPPING_NAME = "MotorCalcPriVeh";
*/	
	//Constants Added by Vishal
	public static final String BLANK_STRING = "";
	public static final String MAPPING_XML_FILE_NAME = "MotorMapping.xml";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES = "ElectricalAccessiories";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GRPCD = "GRP289";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA = "GroupData";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_MAKE_NAME = "Make";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_MAKE_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_MAKE_TYPE = "String";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_MODEL_NAME = "Model";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_MODEL_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_MODEL_TYPE = "String";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_YEAR_NAME = "Year";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_YEAR_TYPE = "String";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_IDV_NAME = "IDV";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_IDV_TYPE = "Double";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_TYPEOFACCESSORIES_NAME = "TypeofAccessories";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_TYPEOFACCESSORIES_VALUE = "Other";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_TYPEOFACCESSORIES_TYPE = "String";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_DESCRIPTION_NAME = "Description";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_DESCRIPTION_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_DESCRIPTION_TYPE = "String";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_SERIALNO_NAME = "SerialNo";
	public static final String OTHERDETAILSGRID_ELECTRICAL_ACCESSIORIES_GROUPDATA_SERIALNO_TYPE = "String";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES = "NonElectricalAccessiories";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GRPCD = "GRP288";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA = "GroupData";	
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_MAKE_NAME = "Make";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_MAKE_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_MAKE_TYPE = "String";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_MODEL_NAME = "Model";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_MODEL_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_MODEL_TYPE = "String";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_YEAR_NAME = "Year";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_YEAR_TYPE = "String";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_IDV_NAME = "IDV";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_IDV_TYPE = "Double";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_TYPEOFACCESSORIES_NAME = "TypeofAccessories";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_TYPEOFACCESSORIES_VALUE = "Other";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_TYPEOFACCESSORIES_TYPE = "String";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_DESCRIPTION_NAME = "Description";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_DESCRIPTION_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_DESCRIPTION_TYPE = "String";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_SERIALNO_NAME = "SerialNo";
	public static final String OTHERDETAILSGRID_NONELECTRICAL_ACCESSIORIES_GROUPDATA_SERIALNO_TYPE = "String";	
	public static final String OTHERDETAILSGRID_REMARK = "Remark";
	public static final String OTHERDETAILSGRID_REMARK_GRPCD = "GRP290";
	public static final String OTHERDETAILSGRID_REMARK_GROUPDATA = "GroupData";
	public static final String OTHERDETAILSGRID_REMARK_TYPEOFREMARKS_NAME = "TypeofRemarks";
	public static final String OTHERDETAILSGRID_REMARK_TYPEOFREMARKS_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_REMARK_TYPEOFREMARKS_TYPE = "String";
	public static final String OTHERDETAILSGRID_REMARK_REFERENCENUMBER_NAME = "ReferenceNumber";
	public static final String OTHERDETAILSGRID_REMARK_REFERENCENUMBER_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_REMARK_REFERENCENUMBER_TYPE = "String";
	public static final String OTHERDETAILSGRID_REMARK_RECOMMENDATIONREMARKS_NAME = "RecommendationRemarks";
	public static final String OTHERDETAILSGRID_REMARK_RECOMMENDATIONREMARKS_TYPE = "String";
	public static final String OTHERDETAILSGRID_REMARK_WIPCATEGORY_NAME = "WipCategory";
	public static final String OTHERDETAILSGRID_REMARK_WIPCATEGORY_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_REMARK_WIPCATEGORY_TYPE = "String";
	public static final String OTHERDETAILSGRID_REMARK_NAMEOFUNDRWRTR_NAME = "NameofUnderwriter";
	public static final String OTHERDETAILSGRID_REMARK_NAMEOFUNDRWRTR_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_REMARK_NAMEOFUNDRWRTR_TYPE = "String";
	public static final String OTHERDETAILSGRID_REMARK_USERID_NAME = "UserId";
	public static final String OTHERDETAILSGRID_REMARK_USERID_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_REMARK_USERID_TYPE = "String";
	public static final String OTHERDETAILSGRID_REMARK_DATEOFREMARK_NAME = "DateOfRemark";
	public static final String OTHERDETAILSGRID_REMARK_DATEOFREMARK_TYPE = "String";
	public static final String OTHERDETAILSGRID_REMARK_STATUSOFWIP_NAME = "StatusofWip";
	public static final String OTHERDETAILSGRID_REMARK_STATUSOFWIP_VALUE = "N/A";
	public static final String OTHERDETAILSGRID_REMARK_STATUSOFWIP_TYPE = "String";
	public static final String MODEL_ENTITY_NAME = "com.majesco.dcf.common.tagic.entity.Model";	
	public static final String MODELVARIANTSEATCUBMAP_PARENTMODELCODE_KEY = "parentModelCode";
	public static final String MODELVARIANTSEATCUBMAP_MODELCODE_KEY = "modelCode";
	public static final String MODELVARIANTSEATCUBMAP_VEHICLETYPE_KEY = "VehicleType";
	public static final String STRING_ONE = "1";
	public static final String STRING_TWO = "2";
	public static final String STRING_THREE = "3";
	public static final String RTOLOCATION_ENTITY_NAME = "com.majesco.dcf.common.tagic.entity.RTOLocation";
	public static final String RTOGROUPMAP_LOCATIONDESC_KEY = "locationDesc";
	public static final String RTOGROUPMAP_REGISTRATIONZONE_KEY = "registrationZone";
	public static final String RTOGROUPMAP_LOCATIONCODE_KEY = "locationCode";
	public static final String RTOGROUPMAP_STATECODE_KEY = "stateCode";
	public static final String MOTOR_ENTITY_NAME = "com.majesco.dcf.common.tagic.entity.Motor";
	public static final boolean FALSE_BOOLEAN = false;
	public static final boolean TRUE_BOOLEAN = true;
	public static final String BASISOFRATING_TWOWHEEL = "Tariff";
	public static final String EMERGENCY_MEDICAL_EXP_SI = "200000";
	public static final String METHODOFCALCULATIONUSER = "GCWINPR05";
	public static final String BUSINESS_CHANNEL_TYPE = "RETAINER";
	public static final String BUSINESS_SOURCE_MANDATORY = "INTERMEDIARY";
	public static final String NCB_TWENTY = "20";
	public static final String NCB_TWENTY_FIVE = "25";
	public static final String NCB_THIRTY_FIVE = "35";
	public static final String NCB_FORTY_FIVE = "45";
	public static final String NCB_FIFTY = "50";
	public static final String NCB_SIXTY_FIVE = "65";
	public static final String TERTIARY_MO_CODE_A = "A_PORTAL";
	public static final String NO_STRING = "No";
	public static final String YES_STRING = "Yes";
	public static final String ZERO_STRING = "0";
	public static final String MAINDRIVER_STRING_TWOWHEEL = "Self - owner driver";
	public static final String ANY_OTHER_STRING_TWOWHEEL = "Any Other";
	public static final String VEHICLEPURCHASEAS_TW_BRAND_NEW = "Brand new";
	public static final String VEHICLEPURCHASEAS_TW_USED = "Used";
	public static final String BUSINESSSOURCEMANDATARY_PRIVATE = "INTERMEDIARY";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_NAME = "OwnerDriverNomineeDetails";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_VALUE = "GRP292";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE = "GroupData";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_NOMINEE_NAME = "Nominee";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_NOMINEE_VALUE = "N";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_NOMINEE_TYPE = "String";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_AGE_NAME = "Age";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_AGE_VALUE = "30";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_AGE_TYPE = "Double";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_RELATIONSHIP_NAME = "Relationship";
	public static final String PROP_RISK_RELATIONSHIP_BROTHER = "Brother";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_RELATIONSHIP_TYPE = "String";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_NAMEOFAPPOINTEE_NAME = "Nameoftheappointee";	
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_RELATIONSHIPTONOMINEE_NAME = "Relationshiptothenominee";
	public static final String PROP_RISK_RELATIONSHIP_FATHER = "Father";
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_NAMEOFAPPOINTEE_TYPE = "String";	
	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_RELATIONSHIPTONOMINEE_TYPE = "String";
	public static final String TW_BUSINESS_TYPE_MANDATARY_NEW = "New Business";
	public static final String TW_BUSINESS_TYPE_MANDATARY_ROLLOVER = "Roll Over";
	public static final String TW_PREVIOUS_POLICYDETAILS_POLICY_NO = "TEST/100000000";
	public static final String PROP_VEHICLE_USE_MANDATORY="Driving Tuitions";
	public static final String MINUS_ONE_STRING = "-1";	
	public static final String MODEOFOPERATION_NEW = "NEWPOLICY";
	public static final String USER_ROLE = "ADMIN";
	public static final String GETQUICKQUOTE_ONQUOTE = "getQuickQuoteOnQuote";
	public static final String LOB_TYPE_MOTOR = "31";
	public static final String LOB_STRING_MOTOR = "MOTOR";
	public static final String TRANSACTION_EVENT_TW_GET_PREMIUM_QUOTE = "GetPremium / Motor-TW Quote";
	public static final String RESPONSE_FROM_TATA = "TataAIG";
	public static final String RESPONSE_FROM_MAJESCOQC = "MajescoQC";
	public static final String FILENAME_TwoWheel = "/twowheeler_response.xml";
	public static final String ORA_ERROR_STRING = "ORA-";
	public static final String ERR_STRING = "ERR";
	public static final String NOERR_STRING = "NOERR";
	public static final String NO_ERROR_STRING = "NO ERROR";
	public static final String PREMIUMBRK_OWNDAMAGE_STRING = "OWNDAMAGE";
	public static final String PREMIUMBRK_LIABILITY_STRING = "LIABILITY";
	public static final String TOTAL_OWNDAMAGE_PREMIUM_STRING = "A: TOTAL OWN DAMAGE PREMIUM";
	public static final String TOTAL_ADDON_PREMIUM_STRING = "C: TOTAL ADD ON PREMIUM";
	public static final String BASIC_STRING = "Basic";
	public static final String TOTAL_LIABILITY_PREMIUM_STRING = "B: TOTAL LIABILITY PREMIUM";
	public static final String PREMIUMBRK_TOTAL_PREMIUM_STRING = "TOTALPREMIUM";
	public static final String COMPREHENSIVE_PREMIUM_STRING = "COMPREHENSIVE PREMIUM";
	public static final String NET_PREMIUM_STRING = "NET PREMIUM";
	public static final String SERVICE_TAX_STRING = "SERVICE TAX / GST";
	public static final String SPACE_TOTAL_PREMIUM_STRING = "TOTAL PREMIUM";
	public static final String ERR_CODE_ZERO = "ERR00";
	public static final String ERR_CODE_ONE = "ERR01";
	public static final String ERR_CODE_TWO = "ERR02";
	public static final String FALSE_STRING = "false";
	public static final String TRUE_STRING = "true";
	public static final String ONE_STRING = "1";
	public static final String TWO_STRING = "2";
	public static final String THREE_STRING = "3";
	public static final String FOUR_STRING = "4";
	public static final String PROP_GENERAL_PROPOSAL_INFO_OPT_CALCULATION_YEARLY = "Yearly";
	public static final String PROP_GENERAL_PROPOSAL_INFO_OPT_CALCULATION_SHORT_PERIOD = "Short Period";
	public static final String REG_NUMBER_SECTION1_VAL1 = "DL";
	
	public static final String REG_NUMBER_SECTION2_VAL1="4C";
	public static final String REG_NUMBER_SECTION2_VAL2="6C";
	public static final String CONSTANTMAP_SEGMENTTYPE_KEY = "segmenttype";	
	public static final String CONSTANTMAP_VEHICLECLASS_KEY = "vehicleclass";
	public static final String TO_HOUR_MANDATARY = "23:59";
	public static final String CREATE_QUOTE_STRING = "createQuote";
	public static final String TRANSACTION_EVENT_TW_CREATE_QUOTE = "SaveQuote / Motor-TW Quote";
	public static final String PLUS_SIGN = "+";
	public static final String MINUS_SIGN = "-";
	public static final String TRANS_TYPE_SAVE_QUOTE = "Save Quote";
	public static final String READ_TIME_OUT_STRING = "Read Time Out Issue... !!!";
	public static final String CALL_SERVICE_ISSUE_STRING = "System Failed to call service !!!";
	public static final String DOZER_MAPPING_ISSUE_STRING = "System Failed Due To Dozer Mapping Issue !!!";
	//end
	/*
	public static final String REG_NUMBER_THREE_STRING = "AZ";  // Not in TW
	public static final String REG_NUMBER_FOUR_STRING = "6256"; // Not In TW

	
	

	public static final String ZONE_STRING_APPEND = "Zone-";
	
	public static final String RTOGROUPMAP_REGISTRATIONZONE1_KEY = "registrationZone1";
	
	public static final String CUSTOMER_TYPE_INDIVIDUAL = "I";
	public static final String CUSTOMER_TYPE_ORGNIZATION = "O";
	public static final String PACKAGE_COMPREH_STRING = "PackageComprehensive";
	
	
	public static final String VEHICLESUBCLASS_ENTITY_NAME = "com.majesco.dcf.common.tagic.entity.VehicleSubClass";
	public static final String SUBCLASSMAP_VEHICLECLASSCODE_KEY = "vehicleclasscode";
	public static final String SUBCLASSMAP_VEHICLESUBCLASSCODE_KEY = "vehiclesubclasscode";
	public static final String SUBCLASSMAP_SUBCLASSDESC_KEY = "subclassdesc";
	public static final String SUBCLASSMAP_SUBCLASSCATG_KEY = "subclasscatg";
	
	
	public static final String ONE_STRING = "1";
	public static final String TWO_STRING = "2";
	public static final String THREE_STRING = "3";
	public static final String FOUR_STRING = "4";
	public static final String PLUS_SIGN = "+";
	public static final String MINUS_SIGN = "-";
	public static final String MAX_NO_OF_DAYS = "30";

	
	
	public static final String DRIVER_AGE = "35";
	public static final String DRIVER_EXPERIENCE = "10";
	public static final String DRIVER_MARRITAL_STATUS = "MARRIED";
	public static final String DRIVER_DRIVING_LICENCE = "true";
	public static final String DRIVER_NAME_OF_NOMINEE = "ABCD";
	public static final String DRIVER_AGE_COVERAGE_DETAILS = "20";
	public static final String DRIVER_RELATIONSHIP = "As attached";
	public static final String NATUREOFGOODSCARRIED_PRIVATE = "Non hazardous";
	public static final String GOODS_CARRYING_PRIVATE = "Goods Carrying Vehicle";
	public static final String NO_OF_CLAIMS_PRIVATE = "2";
	
	
	public static final String VEHICLEPURCHASEAS_PRIVATE_ROLLOVER = "";
	public static final String METHOD_OF_CALCULATION = "0025961000";
	public static final String VEHICLETYPECODE_FIFTY_TWO = "52";
	public static final String VEHICLETYPECODE_FIFTY_FOUR = "54";
	public static final String MANUFACTURER_MONTH_PRIVATE = "1";
	
	
	public static final String JAMMUKASHMIR_STRING1 = "JK";
	public static final String JAMMUKASHMIR_STRING2 = "JAMMU & KASHMIR";
	public static final String JAMMUKASHMIR_STRING3 = "JAMMU AND KASHMIR";
	public static final String SERVICETAX_EXEMPTION_CATEGORY_SEZ = "SEZ";
	public static final String SERVICETAX_EXEMPTION_CATEGORY_EXEMPTION = "No Exemption";
	
	public static final String TERTIARY_MO_CODE_Q = "Q_PORTAL";
	
	public static final String PREVIOUS_POLICYDETAILS_CLAIM_AMOUNT = "1";

	
	
	
	
	
	

	public static final String OWNERDRIVER_NOMINEE_DETAILS_TYPE_RELATIONSHIP_VALUE = "As attached";
	
	
	
	public static final String TRAILER_DETAILS_NAME = "Trailer Details";
	public static final String TRAILER_DETAILS_VALUE = "GRP314";
	public static final String TRAILER_DETAILS_TYPE = "GroupData";
	public static final String TRAILER_DETAILS_MAKE_NAME = "Make";
	public static final String TRAILER_DETAILS_MAKE_TYPE = "String";
	public static final String TRAILER_DETAILS_MODEL_NAME = "Model";
	public static final String TRAILER_DETAILS_MODEL_TYPE = "String";
	public static final String TRAILER_DETAILS_CHASISNO_NAME = "Chassis No";
	public static final String TRAILER_DETAILS_CHASISNO_TYPE = "String";
	public static final String TRAILER_DETAILS_REGISTRATIONNO_NAME = "Registration No";
	public static final String TRAILER_DETAILS_REGISTRATIONNO_TYPE = "String";
	public static final String TRAILER_DETAILS_YEAROFMANUFACTURE_NAME = "Year Of Manufacture";
	public static final String TRAILER_DETAILS_YEAROFMANUFACTURE_TYPE = "Double";
	public static final String TRAILER_DETAILS_SI_NAME = "SI";
	public static final String TRAILER_DETAILS_SI_TYPE = "Double";
	
	
	public static final String PREVIOUS_POLICY_ID = "A";
	public static final String PREVIOUS_POLICY_PINCODE = "400052";
	public static final String PREVIOUS_POLICY_CITY_NAME = "MUMBAI";
	public static final String PREVIOUS_POLICY_POLICYNO = "9999999999";
	public static final String PREVIOUS_POLICY_STATE_NAME = "MAHARASHTRA";
	public static final String BASIS_OF_RATING = "Campaign";
	public static final String USER_ID_STRING = "UserID";
	public static final String PASSWORD_STRING = "Password";
	public static final String PROPFILENAME_RESOURCE = "resource.properties";
	public static final String PROPERTYNAME_RESPONSEFROM = "ResponseFrom";
	
	public static final String MODEOFOPERATION_RENEW = "RENEWPOLICY";
	
	public static final String GETQUICKQUOTE = "getQuickQuote";
	
	public static final String SAVE_PROPOSAL_STRING = "saveProposal";
	

	
	public static final String TRANSACTION_EVENT_TW_CALCULATOR = "GetPremium / Motor-Calculator";
	
	public static final String TRANSACTION_EVENT_TW_SAVE_PROPOSAL = "SaveProposal / Motor-TW Proposal";
	
	
	
	
	


	
	
	
	
	
	

	
	public static final String PRIVATE_PRODUCT_CODE = "3124";
	public static final String NS2_STRING = "ns2:";
	public static final String PRODUCTLINE_PRIVATE = "Commercial Vehicle";
	public static final String DECLINEDSTATUS_NPDP = "NPDP";
	public static final String DECLINEDSTATUS_NMTD = "NMTD";
	public static final String DECLINEDSTATUS_NR = "NR";
	public static final String DECLINEDSTATUS_DECLINED = "DECLINED";
	public static final String SAVE_PROPOSAL_STRING2= "Save Proposal";
	public static final String DEFAULT_PRODUCERMOBILE = "1800 - 266 - 7780";
	public static final String PRODUCTNAME_TWOWHEELER = "Two Wheeler";

	public static final String RENEWAL_PROPOSAL_TYPE = "Renewal";
	public static final String RENEWAL_BUSINESS_TYPE = "Renewal Business";
	public static final String TRANSACTION_ID_STRING = ".Transaction Id=";
	public static final String URL_ISSUE_STRING = "System Failed Due To URL Issue !!!";
	
	
	
	
	
	
	
*/	
	

}

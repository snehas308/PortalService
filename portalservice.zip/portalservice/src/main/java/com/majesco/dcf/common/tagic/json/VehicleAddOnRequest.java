package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class VehicleAddOnRequest {
	
	private String strplancode="";

	public String getStrplancode() {
		return strplancode;
	}

	public void setStrplancode(String strplancode) {
		this.strplancode = strplancode;
	}
	
}

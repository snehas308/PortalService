package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocListRequest {
	
	private String strprodcd;
	private String strservreqcatcd;
	private String strservreqsubcatcd;
	
	public String getStrprodcd() {
		return strprodcd;
	}
	public void setStrprodcd(String strprodcd) {
		this.strprodcd = strprodcd;
	}
	public String getStrservreqcatcd() {
		return strservreqcatcd;
	}
	public void setStrservreqcatcd(String strservreqcatcd) {
		this.strservreqcatcd = strservreqcatcd;
	}
	public String getStrservreqsubcatcd() {
		return strservreqsubcatcd;
	}
	public void setStrservreqsubcatcd(String strservreqsubcatcd) {
		this.strservreqsubcatcd = strservreqsubcatcd;
	}
	
	
}

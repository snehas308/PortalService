package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ProdSupportContactServiceRequest {
	
	private ArrayList<String> paramCode;

	public ArrayList<String> getParamCode() {
		return paramCode;
	}

	public void setParamCode(ArrayList<String> paramCode) {
		this.paramCode = paramCode;
	}
	
	

}

package com.majesco.dcf.motor.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class GenerateMoratoriumResponse {

	private String resultCode;
	private String errmessage;
	private String straction;
	
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getErrmessage() {
		return errmessage;
	}
	public void setErrmessage(String errmessage) {
		this.errmessage = errmessage;
	}
	public String getStraction() {
		return straction;
	}
	public void setStraction(String straction) {
		this.straction = straction;
	}
	
}

package com.majesco.dcf.paproduct.util;

public interface IPAProductConstants {

	public static String IPA_NOMINEE_GRID_NAME="Nominee Details Grid";
	public static String IPA_NOMINEE_GRID_VALUE="GRP258";
	public static String IPA_NOMINEE_TYPE="GroupData";
	public static String IPA_NOMINEE_InsuredPerson="InsuredPerson";
	public static String IPA_NOMINEE_Nominee="Nominee";
	public static String IPA_NOMINEE_DateofBirth="DateofBirth";
	public static String IPA_NOMINEE_Age="Age";
	public static String IPA_NOMINEE_GenderofNominee="GenderofNominee";
	public static String IPA_NOMINEE_RelationshipofNomineewithInsuredPerson="RelationshipofNomineewithInsuredPerson";
	public static String IPA_NOMINEE_WhethertheNomineeisaminor="WhethertheNomineeisaminor";
	public static String IPA_NOMINEE_NomineeGuardianName="NomineeGuardianName";
	public static String IPA_NOMINEE_RelationshipofNomineeGuardianwithNominee="RelationshipofNomineeGuardianwithNominee";
	public static String IPA_NOMINEE_NomineeContribution="NomineeContribution(%)";
	public static String IPA_NOMINEE_FieldType_String="String";
	public static String IPA_NOMINEE_FieldType_Double="Double";
	public static String IPA_ACCIDENTGUARD_SERVICE_WSDL="AccidentGuardService";
	public static String IPA_ACCIDENTSHIELD_SERVICE_WSDL="AccidentShieldService";
	public static String IPA_SECUREPLAN_SERVICE_WSDL="SecureFuturePlanService";
	public static String ONYX_SERVICE_WSDL="OnysxService";
	
	public static final String OCCUPATION_CLASS_PARAM="1004";
	public static final String RELATIONSHIP_CODE_AG="1057";
	public static final Integer NOMINEE_MINOR_AGE=18;
	public static final String NOMINEE_RELATIONSHIP_PARAM="1073";
	
}

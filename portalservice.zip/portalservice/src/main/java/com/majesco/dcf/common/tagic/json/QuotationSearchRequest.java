package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class QuotationSearchRequest extends UserObject {

	private String lineOfBussiness;
	private String productCode;
	private String quoteNo;
	private String regNo1;
	private String regNo2;
	private String regNo3;
	private String regNo4;
	private String customerId;
	private String dateOfBirth;
	private String mobileNo;
	private String dateFrom;
	private String dateTo;
	private String vehicleRegNo;
	private String flag;
	
	public String getLineOfBussiness() {
		return lineOfBussiness;
	}
	public void setLineOfBussiness(String lineOfBussiness) {
		this.lineOfBussiness = lineOfBussiness;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getQuoteNo() {
		return quoteNo;
	}
	public void setQuoteNo(String quoteNo) {
		this.quoteNo = quoteNo;
	}
	public String getRegNo1() {
		return regNo1;
	}
	public void setRegNo1(String regNo1) {
		this.regNo1 = regNo1;
	}
	public String getRegNo2() {
		return regNo2;
	}
	public void setRegNo2(String regNo2) {
		this.regNo2 = regNo2;
	}
	public String getRegNo3() {
		return regNo3;
	}
	public void setRegNo3(String regNo3) {
		this.regNo3 = regNo3;
	}
	public String getRegNo4() {
		return regNo4;
	}
	public void setRegNo4(String regNo4) {
		this.regNo4 = regNo4;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}
	public String getDateTo() {
		return dateTo;
	}
	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}
	public String getVehicleRegNo() {
		return vehicleRegNo;
	}
	public void setVehicleRegNo(String vehicleRegNo) {
		this.vehicleRegNo = vehicleRegNo;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	
	
	
}

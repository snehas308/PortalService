package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_vehicle_model_variant_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_vehicle_model_variant_m")							// Added for Oracle Migration
public class Motor implements Serializable{
	
	private String strmodelcd;
	private String strmodelnumber;
	private String strmanufacturercd;
	private String strbodytypecd;
	private String strbodytypedesc;
	private String strfuel;
	private String strfueldesc;
	private String strsegmenttype;
	private BigDecimal nvehicleclasscd;
	private BigDecimal nnoofwheels;
	private BigDecimal ncubiccapacity;
	private BigDecimal ngrossvehicleweight;
	private BigDecimal nseatingcapacity;
	private BigDecimal ncarryingcapacity;
	private BigDecimal nvehiclemodelstatus;
	private String strvariant;
	private String strvehicletype;
	private BigDecimal nexshowroomprice;
	private BigDecimal nvariation;
	private String strvehiclerefno;
	private String strexcessgroupcd;
	private BigDecimal nparenmodelcd;
	private BigDecimal nlevel;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	private String strairbag;
	private String strabs;
	private String strautotran;
	private String strthefttarget;
	private BigDecimal nisactive;
	private BigDecimal nparentofficecd;
	private BigDecimal ntransctionid;
	private String strcontactperson;
	private String stremailid;
	private String strofficecd;
	private String strofficedesc;
	private String strofficetype;
	private String strparentofficecd;

	@Column(name = "strfueldesc")
	public String getStrfueldesc() {
		return strfueldesc;
	}
	public void setStrfueldesc(String strfueldesc) {
		this.strfueldesc = strfueldesc;
	}
	@Id
	@Column(name = "strmodelcd")
	public String getStrmodelcd() {
		return strmodelcd;
	}
	public void setStrmodelcd(String strmodelcd) {
		this.strmodelcd = strmodelcd;
	}
	
	@Column(name = "strmodelnumber")
	public String getStrmodelnumber() {
		return strmodelnumber;
	}
	public void setStrmodelnumber(String strmodelnumber) {
		this.strmodelnumber = strmodelnumber;
	}
	
	
	@Column(name = "strmanufacturercd")
	public String getStrmanufacturercd() {
		return strmanufacturercd;
	}
	public void setStrmanufacturercd(String strmanufacturercd) {
		this.strmanufacturercd = strmanufacturercd;
	}
	
	
	@Column(name = "strbodytypecd")
	public String getStrbodytypecd() {
		return strbodytypecd;
	}
	public void setStrbodytypecd(String strbodytypecd) {
		this.strbodytypecd = strbodytypecd;
	}
	
	
	@Column(name = "strfuel")
	public String getStrfuel() {
		return strfuel;
	}
	public void setStrfuel(String strfuel) {
		this.strfuel = strfuel;
	}
	
	
	@Column(name = "strsegmenttype")
	public String getStrsegmenttype() {
		return strsegmenttype;
	}
	public void setStrsegmenttype(String strsegmenttype) {
		this.strsegmenttype = strsegmenttype;
	}
	
	public BigDecimal getNvehicleclasscd() {
		return nvehicleclasscd;
	}
	public void setNvehicleclasscd(BigDecimal nvehicleclasscd) {
		this.nvehicleclasscd = nvehicleclasscd;
	}
	@Column(name = "nnoofwheels")
	public BigDecimal getNnoofwheels() {
		return nnoofwheels;
	}
	public void setNnoofwheels(BigDecimal nnoofwheels) {
		this.nnoofwheels = nnoofwheels;
	}
	
	
	@Column(name = "ncubiccapacity")
	public BigDecimal getNcubiccapacity() {
		return ncubiccapacity;
	}
	public void setNcubiccapacity(BigDecimal ncubiccapacity) {
		this.ncubiccapacity = ncubiccapacity;
	}
	
	
	@Column(name = "ngrossvehicleweight")
	public BigDecimal getNgrossvehicleweight() {
		return ngrossvehicleweight;
	}
	public void setNgrossvehicleweight(BigDecimal ngrossvehicleweight) {
		this.ngrossvehicleweight = ngrossvehicleweight;
	}
	
	
	@Column(name = "nseatingcapacity")
	public BigDecimal getNseatingcapacity() {
		return nseatingcapacity;
	}
	public void setNseatingcapacity(BigDecimal nseatingcapacity) {
		this.nseatingcapacity = nseatingcapacity;
	}
	
	
	@Column(name = "ncarryingcapacity")
	public BigDecimal getNcarryingcapacity() {
		return ncarryingcapacity;
	}
	public void setNcarryingcapacity(BigDecimal ncarryingcapacity) {
		this.ncarryingcapacity = ncarryingcapacity;
	}
	
	
	@Column(name = "nvehiclemodelstatus")
	public BigDecimal getNvehiclemodelstatus() {
		return nvehiclemodelstatus;
	}
	public void setNvehiclemodelstatus(BigDecimal nvehiclemodelstatus) {
		this.nvehiclemodelstatus = nvehiclemodelstatus;
	}
	
	
	@Id
	@Column(name = "strvariant")
	public String getStrvariant() {
		return strvariant;
	}
	public void setStrvariant(String strvariant) {
		this.strvariant = strvariant;
	}
	
	
	@Column(name = "strvehicletype")
	public String getStrvehicletype() {
		return strvehicletype;
	}
	public void setStrvehicletype(String strvehicletype) {
		this.strvehicletype = strvehicletype;
	}
	
	
	@Column(name = "nexshowroomprice")
	public BigDecimal getNexshowroomprice() {
		return nexshowroomprice;
	}
	public void setNexshowroomprice(BigDecimal nexshowroomprice) {
		this.nexshowroomprice = nexshowroomprice;
	}
	
	
	@Column(name = "nvariation")
	public BigDecimal getNvariation() {
		return nvariation;
	}
	public void setNvariation(BigDecimal nvariation) {
		this.nvariation = nvariation;
	}
	
	
	@Column(name = "strvehiclerefno")
	public String getStrvehiclerefno() {
		return strvehiclerefno;
	}
	public void setStrvehiclerefno(String strvehiclerefno) {
		this.strvehiclerefno = strvehiclerefno;
	}
	
	
	@Column(name = "strexcessgroupcd")
	public String getStrexcessgroupcd() {
		return strexcessgroupcd;
	}
	public void setStrexcessgroupcd(String strexcessgroupcd) {
		this.strexcessgroupcd = strexcessgroupcd;
	}
	
	
	@Column(name = "nparenmodelcd")
	public BigDecimal getNparenmodelcd() {
		return nparenmodelcd;
	}
	public void setNparenmodelcd(BigDecimal nparenmodelcd) {
		this.nparenmodelcd = nparenmodelcd;
	}
	
	
	@Column(name = "nlevel")
	public BigDecimal getNlevel() {
		return nlevel;
	}
	public void setNlevel(BigDecimal nlevel) {
		this.nlevel = nlevel;
	}
	
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	
	@Column(name = "strairbag")
	public String getStrairbag() {
		return strairbag;
	}
	public void setStrairbag(String strairbag) {
		this.strairbag = strairbag;
	}
	
	
	@Column(name = "strabs")
	public String getStrabs() {
		return strabs;
	}
	public void setStrabs(String strabs) {
		this.strabs = strabs;
	}
	
	
	@Column(name = "strautotran")
	public String getStrautotran() {
		return strautotran;
	}
	public void setStrautotran(String strautotran) {
		this.strautotran = strautotran;
	}
	
	
	@Column(name = "strthefttarget")
	public String getStrthefttarget() {
		return strthefttarget;
	}
	public void setStrthefttarget(String strthefttarget) {
		this.strthefttarget = strthefttarget;
	}
	
	@Column(name = "strbodytypedesc")
	public String getStrbodytypedesc() {
		return strbodytypedesc;
	}
	public void setStrbodytypedesc(String strbodytypedesc) {
		this.strbodytypedesc = strbodytypedesc;
	}
	
	@Column(name = "nisactive")
	public BigDecimal getNisactive() {
		return nisactive;
	}
	public void setNisactive(BigDecimal nisactive) {
		this.nisactive = nisactive;
	}
	
	@Column(name = "nparentofficecd")
	public BigDecimal getNparentofficecd() {
		return nparentofficecd;
	}
	public void setNparentofficecd(BigDecimal nparentofficecd) {
		this.nparentofficecd = nparentofficecd;
	}
	
	@Column(name = "ntransctionid")
	public BigDecimal getNtransctionid() {
		return ntransctionid;
	}
	public void setNtransctionid(BigDecimal ntransctionid) {
		this.ntransctionid = ntransctionid;
	}
	
	@Column(name = "strcontactperson")
	public String getStrcontactperson() {
		return strcontactperson;
	}
	public void setStrcontactperson(String strcontactperson) {
		this.strcontactperson = strcontactperson;
	}
	
	@Column(name = "stremailid")
	public String getStremailid() {
		return stremailid;
	}
	public void setStremailid(String stremailid) {
		this.stremailid = stremailid;
	}
	
	@Column(name = "strofficecd")
	public String getStrofficecd() {
		return strofficecd;
	}
	public void setStrofficecd(String strofficecd) {
		this.strofficecd = strofficecd;
	}
	
	@Column(name = "strofficedesc")
	public String getStrofficedesc() {
		return strofficedesc;
	}
	public void setStrofficedesc(String strofficedesc) {
		this.strofficedesc = strofficedesc;
	}
	
	
	@Column(name = "strofficetype")
	public String getStrofficetype() {
		return strofficetype;
	}
	public void setStrofficetype(String strofficetype) {
		this.strofficetype = strofficetype;
	}
	
	@Column(name = "strparentofficecd")
	public String getStrparentofficecd() {
		return strparentofficecd;
	}
	public void setStrparentofficecd(String strparentofficecd) {
		this.strparentofficecd = strparentofficecd;
	}

	
}

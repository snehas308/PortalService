package com.majesco.dcf.policyservicing.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DCFIncidentCreationResult {
	
	private List<DocumentListResult> lstDocResult;

	public List<DocumentListResult> getLstDocResult() {
		return lstDocResult;
	}

	public void setLstDocResult(List<DocumentListResult> lstDocResult) {
		this.lstDocResult = lstDocResult;
	}
}

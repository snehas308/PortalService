package com.majesco.dcf.common.tagic.filter;

import java.io.BufferedReader;
import java.security.MessageDigest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.majesco.dcf.constant.CommonConstants;

public class ValidatePayloadFilter extends HandlerInterceptorAdapter {

	private String _strClassName="ValidatePayloadFilter";
	final static Logger logger = LogManager.getLogger(ValidatePayloadFilter.class.getName());
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
 Object handler) throws Exception {

		String strMethodName = "preHandle";
		boolean payloadVerification = true;
		String strComputedCheckSum = null;
		BufferedReader bufferedReader = request.getReader();
		if (request.getHeader("Checksum") != null
				&& !request.getHeader("Checksum").equalsIgnoreCase(
						CommonConstants.BLANK_STRING)) {
			if (bufferedReader != null) {
				String jsonPayload = bufferedReader.readLine();
				//Start: 1324,1335,1352| RahulT| Commented CRC32 hashing approax due to instability  & used SH256 hashing algorithm instead
				/*if (jsonPayload != null) {
					CRC32 crc32 = new CRC32();
					crc32.update(jsonPayload.getBytes());
					hashValue = crc32.getValue();
				}*/
				if (jsonPayload != null) {
				MessageDigest md=MessageDigest.getInstance("SHA-256");
	              md.update(jsonPayload.getBytes());
	              byte [] byteData=md.digest();
	              StringBuffer hexString = new StringBuffer();
	              for (int i=0;i<byteData.length;i++) {
	                     String hex=Integer.toHexString(0xff & byteData[i]);
	                     if(hex.length()==1) hexString.append('0');
	                     hexString.append(hex);
				}
	              strComputedCheckSum = hexString.toString();
				}
				//End: 1324,1335,1352| RahulT| Commented CRC32 hashing approax due to instability & used SH256 hashing algorithm instead 
	              
				if (logger.isDebugEnabled())
					logger.debug(strMethodName + "::JSON PAYLOAD::"
							+ jsonPayload);

				logger.info(strMethodName + "::JSON HASH VALUE::" + strComputedCheckSum);

			}

			 String strChecksum=new String(Base64.decodeBase64(request.getHeader("Checksum")));
			logger.info(strMethodName + "::Received Checksum VALUE::" + strChecksum);
			if (strChecksum != null && !strChecksum.equalsIgnoreCase(CommonConstants.BLANK_STRING)) {
				if (!strChecksum.equalsIgnoreCase(strComputedCheckSum)) {
					payloadVerification = false;
					response.resetBuffer();
					response.setStatus(HttpStatus.BAD_REQUEST.value());
					response.setHeader("Content-Type", "application/json");
					JSONObject message = new JSONObject();
					message.put("errorMessage", "Invalid Message !!!");
					response.getOutputStream().print(message.toJSONString());
					response.flushBuffer();
				}
			}
		}

		bufferedReader.close();
		return payloadVerification;
	}
}

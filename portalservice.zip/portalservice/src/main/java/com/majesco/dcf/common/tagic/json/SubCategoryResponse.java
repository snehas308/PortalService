package com.majesco.dcf.common.tagic.json;

import java.util.List;

public class SubCategoryResponse {
	private List<String> strservreqsubcatcd; 
	private List<String> strcddesc;
	private List<String> strtype; 
	private List<String> strsubtype;
	private List<String> strgrp; 
	private List<String> strsubgrp;
		
	public List<String> getStrservreqsubcatcd() {
		return strservreqsubcatcd;
	}

	public void setStrservreqsubcatcd(List<String> strservreqsubcatcd) {
		this.strservreqsubcatcd = strservreqsubcatcd;
	}

	public List<String> getStrcddesc() {
		return strcddesc;
	}

	public void setStrcddesc(List<String> strcddesc) {
		this.strcddesc = strcddesc;
	}

	public List<String> getStrtype() {
		return strtype;
	}

	public void setStrtype(List<String> strtype) {
		this.strtype = strtype;
	}

	public List<String> getStrsubtype() {
		return strsubtype;
	}

	public void setStrsubtype(List<String> strsubtype) {
		this.strsubtype = strsubtype;
	}

	public List<String> getStrgrp() {
		return strgrp;
	}

	public void setStrgrp(List<String> strgrp) {
		this.strgrp = strgrp;
	}

	public List<String> getStrsubgrp() {
		return strsubgrp;
	}

	public void setStrsubgrp(List<String> strsubgrp) {
		this.strsubgrp = strsubgrp;
	}

	private List<ResponseError> resErr;
	public List<ResponseError> getResErr() {
		return resErr;
	}

	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	
	
}

/*
 * Object For Storing Data for RenewalSearchResponse
 */
package com.majesco.dcf.common.tagic.json;

public class RenewalSearchData {

	private String addOn;
	private String customerCode;
	private String customerName;
	private String dob;
	private String lob;
	private String mobileNo;
	private String policyInsDate;
	private String policyNo;
	private String productName;
	private String renewalStatus;
	private String totalPremium;
	private String vehRegNo;
	private String lobCode;
	private String productCode;
	// 3520 : 14-Mar-2018 : 0003520: Producer code field should be Non Mandatory in Renewal Search of MIBL login. : Start 
	private String producerCode;
	
	// 3520 : VishalJ : 19-Mar-2018 : Start 
	
	private String make;
	private String model;
	private String ren_status_cd;
	private String txt_customer_name;
	
	public String getTxt_customer_name() {
		return txt_customer_name;
	}
	public void setTxt_customer_name(String txt_customer_name) {
		this.txt_customer_name = txt_customer_name;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getRen_status_cd() {
		return ren_status_cd;
	}
	public void setRen_status_cd(String ren_status_cd) {
		this.ren_status_cd = ren_status_cd;
	}
	
	
	//3520 : VishalJ : 19-Mar-2018 : End
	public String getProducerCode() {
		return producerCode;
	}
	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}
	// 3520 : 14-Mar-2018 : 0003520: Producer code field should be Non Mandatory in Renewal Search of MIBL login. : End 
	public String getLobCode() {
		return lobCode;
	}
	public void setLobCode(String lobCode) {
		this.lobCode = lobCode;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getAddOn() {
		return addOn;
	}
	public void setAddOn(String addOn) {
		this.addOn = addOn;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPolicyInsDate() {
		return policyInsDate;
	}
	public void setPolicyInsDate(String policyInsDate) {
		this.policyInsDate = policyInsDate;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getRenewalStatus() {
		return renewalStatus;
	}
	public void setRenewalStatus(String renewalStatus) {
		this.renewalStatus = renewalStatus;
	}
	public String getTotalPremium() {
		return totalPremium;
	}
	public void setTotalPremium(String totalPremium) {
		this.totalPremium = totalPremium;
	}
	public String getVehRegNo() {
		return vehRegNo;
	}
	public void setVehRegNo(String vehRegNo) {
		this.vehRegNo = vehRegNo;
	}
	
	
	
}

package com.majesco.dcf.motor.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.CustomerDetails;
import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ProductProposalDataTWResponse {

	private String productCode;
	private String newPolStartDate;
	private String strcustID;
	private String strcustName;
	private String printFlag;
	private String isHardCopyReq;
	private CustomerDetails lstcustDet;
	private RiskDetails lstRiskdet;
	private VehicleRegDetails lstvecReg;
	private VehicleAdditionalDetails lsdaddDet;
	private DiscountDeatils lstdiscdet;
	private AddOnCoverDetails lstAddonCover;
	private PrevExistingPolDetails prvExisPolDet;
	private DriverDetails lstDrivrDet;
	private InsuredDetails lstInsuDet;
	private NomineeDetails lstNomDet;
	private ChannelDetails lstChanlDet;
	private CoverNoteDetails lstCvrNtDet;
	private DocumentChecklistDetails lstDocChkDet;
	private PreInspectionResultDetails lstPreInspResDet;
	//private String authenticationToken;
	
	private String resultCode;
	private String proposalNumber;
	private String proposalStatus;
	private List<ResponseError> resErr;
	private List<PremiumBreakup> prmbrk;
	private PremiumDetails premDet;
	private String proposalSystemId; // WFSystemId from create proposal
										// response.WFSystemID
	private String businessLocation; // From proposal response;
										// PropGeneralProposalInformation_OfficeCode
	private String depositOfficeCode; // From proposal response
										// PropGeneralProposalInformation_OfficeCode
	private String bussLocName; // From proposal
								// response.PropGeneralProposalInformation_OfficeName
	private String proposalDate;
	private String isPreInspection;
	private String proposalStatusDesc;
	
	private String posPanNo;
	private String posAdhaarNo;		
	private String isPUP;
	
	private String productName;
	private String quotationNumber;
	private String policyNumber;
	
	private String propInfoPolicyNumberChar;
	private String propInfoPolicyNo;
	private String propInfoNumCovernoteNo;
	private String campaignCode;
	private String generalApplicationNumber; //Added For Defect ID 1424
	
	
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPosPanNo() {
		return posPanNo;
	}
	public void setPosPanNo(String posPanNo) {
		this.posPanNo = posPanNo;
	}
	public String getPosAdhaarNo() {
		return posAdhaarNo;
	}
	public void setPosAdhaarNo(String posAdhaarNo) {
		this.posAdhaarNo = posAdhaarNo;
	}
	public String getIsPUP() {
		return isPUP;
	}
	public void setIsPUP(String isPUP) {
		this.isPUP = isPUP;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getNewPolStartDate() {
		return newPolStartDate;
	}
	public void setNewPolStartDate(String newPolStartDate) {
		this.newPolStartDate = newPolStartDate;
	}
	public String getStrcustID() {
		return strcustID;
	}
	public void setStrcustID(String strcustID) {
		this.strcustID = strcustID;
	}
	public String getStrcustName() {
		return strcustName;
	}
	public void setStrcustName(String strcustName) {
		this.strcustName = strcustName;
	}
	public String getPrintFlag() {
		return printFlag;
	}
	public void setPrintFlag(String printFlag) {
		this.printFlag = printFlag;
	}
	public String getIsHardCopyReq() {
		return isHardCopyReq;
	}
	public void setIsHardCopyReq(String isHardCopyReq) {
		this.isHardCopyReq = isHardCopyReq;
	}
	public CustomerDetails getLstcustDet() {
		return lstcustDet;
	}
	public void setLstcustDet(CustomerDetails lstcustDet) {
		this.lstcustDet = lstcustDet;
	}
	public RiskDetails getLstRiskdet() {
		return lstRiskdet;
	}
	public void setLstRiskdet(RiskDetails lstRiskdet) {
		this.lstRiskdet = lstRiskdet;
	}
	public VehicleRegDetails getLstvecReg() {
		return lstvecReg;
	}
	public void setLstvecReg(VehicleRegDetails lstvecReg) {
		this.lstvecReg = lstvecReg;
	}
	public VehicleAdditionalDetails getLsdaddDet() {
		return lsdaddDet;
	}
	public void setLsdaddDet(VehicleAdditionalDetails lsdaddDet) {
		this.lsdaddDet = lsdaddDet;
	}
	public DiscountDeatils getLstdiscdet() {
		return lstdiscdet;
	}
	public void setLstdiscdet(DiscountDeatils lstdiscdet) {
		this.lstdiscdet = lstdiscdet;
	}
	public AddOnCoverDetails getLstAddonCover() {
		return lstAddonCover;
	}
	public void setLstAddonCover(AddOnCoverDetails lstAddonCover) {
		this.lstAddonCover = lstAddonCover;
	}
	public PrevExistingPolDetails getPrvExisPolDet() {
		return prvExisPolDet;
	}
	public void setPrvExisPolDet(PrevExistingPolDetails prvExisPolDet) {
		this.prvExisPolDet = prvExisPolDet;
	}
	public DriverDetails getLstDrivrDet() {
		return lstDrivrDet;
	}
	public void setLstDrivrDet(DriverDetails lstDrivrDet) {
		this.lstDrivrDet = lstDrivrDet;
	}
	public InsuredDetails getLstInsuDet() {
		return lstInsuDet;
	}
	public void setLstInsuDet(InsuredDetails lstInsuDet) {
		this.lstInsuDet = lstInsuDet;
	}
	public NomineeDetails getLstNomDet() {
		return lstNomDet;
	}
	public void setLstNomDet(NomineeDetails lstNomDet) {
		this.lstNomDet = lstNomDet;
	}
	public ChannelDetails getLstChanlDet() {
		return lstChanlDet;
	}
	public void setLstChanlDet(ChannelDetails lstChanlDet) {
		this.lstChanlDet = lstChanlDet;
	}
	public CoverNoteDetails getLstCvrNtDet() {
		return lstCvrNtDet;
	}
	public void setLstCvrNtDet(CoverNoteDetails lstCvrNtDet) {
		this.lstCvrNtDet = lstCvrNtDet;
	}
	public DocumentChecklistDetails getLstDocChkDet() {
		return lstDocChkDet;
	}
	public void setLstDocChkDet(DocumentChecklistDetails lstDocChkDet) {
		this.lstDocChkDet = lstDocChkDet;
	}
	public PreInspectionResultDetails getLstPreInspResDet() {
		return lstPreInspResDet;
	}
	public void setLstPreInspResDet(PreInspectionResultDetails lstPreInspResDet) {
		this.lstPreInspResDet = lstPreInspResDet;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getProposalNumber() {
		return proposalNumber;
	}
	public void setProposalNumber(String proposalNumber) {
		this.proposalNumber = proposalNumber;
	}
	public String getProposalStatus() {
		return proposalStatus;
	}
	public void setProposalStatus(String proposalStatus) {
		this.proposalStatus = proposalStatus;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public List<PremiumBreakup> getPrmbrk() {
		return prmbrk;
	}
	public void setPrmbrk(List<PremiumBreakup> prmbrk) {
		this.prmbrk = prmbrk;
	}
	public PremiumDetails getPremDet() {
		return premDet;
	}
	public void setPremDet(PremiumDetails premDet) {
		this.premDet = premDet;
	}
	public String getProposalSystemId() {
		return proposalSystemId;
	}
	public void setProposalSystemId(String proposalSystemId) {
		this.proposalSystemId = proposalSystemId;
	}
	public String getBusinessLocation() {
		return businessLocation;
	}
	public void setBusinessLocation(String businessLocation) {
		this.businessLocation = businessLocation;
	}
	public String getDepositOfficeCode() {
		return depositOfficeCode;
	}
	public void setDepositOfficeCode(String depositOfficeCode) {
		this.depositOfficeCode = depositOfficeCode;
	}
	public String getBussLocName() {
		return bussLocName;
	}
	public void setBussLocName(String bussLocName) {
		this.bussLocName = bussLocName;
	}
	public String getProposalDate() {
		return proposalDate;
	}
	public void setProposalDate(String proposalDate) {
		this.proposalDate = proposalDate;
	}
	public String getIsPreInspection() {
		return isPreInspection;
	}
	public String getQuotationNumber() {
		return quotationNumber;
	}
	public void setQuotationNumber(String quotationNumber) {
		this.quotationNumber = quotationNumber;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public void setIsPreInspection(String isPreInspection) {
		this.isPreInspection = isPreInspection;
	}
	public String getProposalStatusDesc() {
		return proposalStatusDesc;
	}
	public void setProposalStatusDesc(String proposalStatusDesc) {
		this.proposalStatusDesc = proposalStatusDesc;
	}
	public String getPropInfoPolicyNumberChar() {
		return propInfoPolicyNumberChar;
	}
	public void setPropInfoPolicyNumberChar(String propInfoPolicyNumberChar) {
		this.propInfoPolicyNumberChar = propInfoPolicyNumberChar;
	}
	public String getPropInfoPolicyNo() {
		return propInfoPolicyNo;
	}
	public void setPropInfoPolicyNo(String propInfoPolicyNo) {
		this.propInfoPolicyNo = propInfoPolicyNo;
	}
	public String getPropInfoNumCovernoteNo() {
		return propInfoNumCovernoteNo;
	}
	public void setPropInfoNumCovernoteNo(String propInfoNumCovernoteNo) {
		this.propInfoNumCovernoteNo = propInfoNumCovernoteNo;
	}
	/*Added For Defect ID 1424 - Starts Here*/
	public String getGeneralApplicationNumber() {
		return generalApplicationNumber;
	}
	public void setGeneralApplicationNumber(String generalApplicationNumber) {
		this.generalApplicationNumber = generalApplicationNumber;
	}
	/*Added For Defect ID 1424 - Ends Here*/
	
}

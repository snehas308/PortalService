package com.majesco.dcf.common.tagic.json;

public class CustomerSearchDetails {

	private String customerCode;
	private String customerName;
	private String dateOfBirth;
	private String mobileNo;
	private String cityName;
	private String pinCode;
	private String createDate;
	private String noOfPolicy;
	private String noOfProposal;
	private String noOfQuote;
	private String intermediaryCode;
	
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getNoOfPolicy() {
		return noOfPolicy;
	}
	public void setNoOfPolicy(String noOfPolicy) {
		this.noOfPolicy = noOfPolicy;
	}
	public String getNoOfProposal() {
		return noOfProposal;
	}
	public void setNoOfProposal(String noOfProposal) {
		this.noOfProposal = noOfProposal;
	}
	public String getNoOfQuote() {
		return noOfQuote;
	}
	public void setNoOfQuote(String noOfQuote) {
		this.noOfQuote = noOfQuote;
	}
	public String getIntermediaryCode() {
		return intermediaryCode;
	}
	public void setIntermediaryCode(String intermediaryCode) {
		this.intermediaryCode = intermediaryCode;
	}
	
	
	
}

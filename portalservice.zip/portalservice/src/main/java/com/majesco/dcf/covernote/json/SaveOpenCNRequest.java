package com.majesco.dcf.covernote.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class SaveOpenCNRequest extends UserObject{
	
	private String coverNoteNo;
	private String custID;
	private String customerName;
	private String make;
	private String model;
	private String modelVariant;
	private String officeCode;
	private String productCode;
	private String proposalAmount;
	private String proposalDate;
	private String proposalNo;
	private String rto;
	private String receiptNumber;
	private String reference_Date;
	private String riskEndDate;
	private String riskStartDate;
	private String workflowid;
	private String engineNo;
	private String chassisNo;
	private String vehiclRegNo1;
	private String vehiclRegNo2;
	private String vehiclRegNo3;
	private String vehiclRegNo4;
	private String vehiclRegNoNotReq;
	private String vehiclRegNoAsPerOldLogic;
	private String operationMode;
	private String subReceiptNumber;
	private String productDesc;
	private String customerEmail;
	private String customerMobile;
	
	public String getCoverNoteNo() {
		return coverNoteNo;
	}
	public void setCoverNoteNo(String coverNoteNo) {
		this.coverNoteNo = coverNoteNo;
	}
	public String getCustID() {
		return custID;
	}
	public void setCustID(String custID) {
		this.custID = custID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getModelVariant() {
		return modelVariant;
	}
	public void setModelVariant(String modelVariant) {
		this.modelVariant = modelVariant;
	}
	public String getOfficeCode() {
		return officeCode;
	}
	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProposalAmount() {
		return proposalAmount;
	}
	public void setProposalAmount(String proposalAmount) {
		this.proposalAmount = proposalAmount;
	}
	public String getProposalDate() {
		return proposalDate;
	}
	public void setProposalDate(String proposalDate) {
		this.proposalDate = proposalDate;
	}
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getRto() {
		return rto;
	}
	public void setRto(String rto) {
		this.rto = rto;
	}
	public String getReceiptNumber() {
		return receiptNumber;
	}
	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}
	public String getReference_Date() {
		return reference_Date;
	}
	public void setReference_Date(String reference_Date) {
		this.reference_Date = reference_Date;
	}
	public String getRiskEndDate() {
		return riskEndDate;
	}
	public void setRiskEndDate(String riskEndDate) {
		this.riskEndDate = riskEndDate;
	}
	public String getRiskStartDate() {
		return riskStartDate;
	}
	public void setRiskStartDate(String riskStartDate) {
		this.riskStartDate = riskStartDate;
	}
	public String getWorkflowid() {
		return workflowid;
	}
	public void setWorkflowid(String workflowid) {
		this.workflowid = workflowid;
	}
	public String getEngineNo() {
		return engineNo;
	}
	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}
	public String getChassisNo() {
		return chassisNo;
	}
	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}
	public String getVehiclRegNo1() {
		return vehiclRegNo1;
	}
	public void setVehiclRegNo1(String vehiclRegNo1) {
		this.vehiclRegNo1 = vehiclRegNo1;
	}
	public String getVehiclRegNo2() {
		return vehiclRegNo2;
	}
	public void setVehiclRegNo2(String vehiclRegNo2) {
		this.vehiclRegNo2 = vehiclRegNo2;
	}
	public String getVehiclRegNo3() {
		return vehiclRegNo3;
	}
	public void setVehiclRegNo3(String vehiclRegNo3) {
		this.vehiclRegNo3 = vehiclRegNo3;
	}
	public String getVehiclRegNo4() {
		return vehiclRegNo4;
	}
	public void setVehiclRegNo4(String vehiclRegNo4) {
		this.vehiclRegNo4 = vehiclRegNo4;
	}
	public String getVehiclRegNoNotReq() {
		return vehiclRegNoNotReq;
	}
	public void setVehiclRegNoNotReq(String vehiclRegNoNotReq) {
		this.vehiclRegNoNotReq = vehiclRegNoNotReq;
	}
	public String getVehiclRegNoAsPerOldLogic() {
		return vehiclRegNoAsPerOldLogic;
	}
	public void setVehiclRegNoAsPerOldLogic(String vehiclRegNoAsPerOldLogic) {
		this.vehiclRegNoAsPerOldLogic = vehiclRegNoAsPerOldLogic;
	}
	public String getOperationMode() {
		return operationMode;
	}
	public void setOperationMode(String operationMode) {
		this.operationMode = operationMode;
	}
	public String getSubReceiptNumber() {
		return subReceiptNumber;
	}
	public void setSubReceiptNumber(String subReceiptNumber) {
		this.subReceiptNumber = subReceiptNumber;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerMobile() {
		return customerMobile;
	}
	public void setCustomerMobile(String customerMobile) {
		this.customerMobile = customerMobile;
	}	

}

package com.majesco.dcf.common.tagic.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.majesco.dcf.common.tagic.json.AuthenticationRequest;
import com.majesco.dcf.common.tagic.json.AuthenticationResponse;
import com.majesco.dcf.common.tagic.service.AuthenticationService;
import com.majesco.dcf.paproduct.json.IPAProposalRequest;
import com.majesco.dcf.paproduct.json.IPAProposalResponse;


@Controller
@RequestMapping(value="/AuthenticateService")
public class AuthenticateController {
	
	@Autowired
	AuthenticationService authServ;
	
	
	final static Logger logger=Logger.getLogger(AuthenticateController.class);
	
	@RequestMapping(value="/getAuthenticationToken/", method = RequestMethod.POST)
	@ResponseBody
	public AuthenticationResponse getAuthenticationToken(@RequestBody AuthenticationRequest authReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside MotorController :: calculatepremiumMotor method :: Execution Started");
		
		AuthenticationResponse authRes = authServ.getAuthenticationToken(authReq);
		
		logger.info("Inside MotorController :: calculatepremiumMotor method :: Execution Completed Successfully");
		
		return authRes;
	}
	

}

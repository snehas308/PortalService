package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class VehicleVariantResponse {
	private List<String> strmodelcd;
	private List<String> strvariant;
	private List<String> strfuel;
	private List<String> strfueldesc;
	private List<String> strbodytypecd;
	private List<String> strbodytypedesc;
	private List<BigDecimal> nvehicleclasscd;
	private List<BigDecimal> ncubiccapacity;
	private List<BigDecimal> nseatingcapacity;
	private List<BigDecimal> ncarryingcapacity;
	private List<String> strvehicletype;
	private List<String> strsegmenttype;
	private List<BigDecimal> strgvw;
	
	private List<ResponseError> resErr;
	
	public List<String> getStrmodelcd() {
		return strmodelcd;
	}
	public void setStrmodelcd(List<String> lststrmodelcd) {
		this.strmodelcd = lststrmodelcd;
	}
	public List<String> getStrvariant() {
		return strvariant;
	}
	public void setStrvariant(List<String> strvariant) {
		this.strvariant = strvariant;
	}
	public List<String> getStrfuel() {
		return strfuel;
	}
	public void setStrfuel(List<String> strfuel) {
		this.strfuel = strfuel;
	}
	public List<String> getStrfueldesc() {
		return strfueldesc;
	}
	public void setStrfueldesc(List<String> strfueldesc) {
		this.strfueldesc = strfueldesc;
	}
	public List<String> getStrbodytypecd() {
		return strbodytypecd;
	}
	public void setStrbodytypecd(List<String> strbodytypecd) {
		this.strbodytypecd = strbodytypecd;
	}
	public List<String> getStrbodytypedesc() {
		return strbodytypedesc;
	}
	public void setStrbodytypedesc(List<String> strbodytypedesc) {
		this.strbodytypedesc = strbodytypedesc;
	}
	public List<BigDecimal> getNvehicleclasscd() {
		return nvehicleclasscd;
	}
	public void setNvehicleclasscd(List<BigDecimal> nvehicleclasscd) {
		this.nvehicleclasscd = nvehicleclasscd;
	}
	public List<BigDecimal> getNcubiccapacity() {
		return ncubiccapacity;
	}
	public void setNcubiccapacity(List<BigDecimal> ncubiccapacity) {
		this.ncubiccapacity = ncubiccapacity;
	}
	public List<BigDecimal> getNseatingcapacity() {
		return nseatingcapacity;
	}
	public void setNseatingcapacity(List<BigDecimal> nseatingcapacity) {
		this.nseatingcapacity = nseatingcapacity;
	}
	public List<BigDecimal> getNcarryingcapacity() {
		return ncarryingcapacity;
	}
	public void setNcarryingcapacity(List<BigDecimal> ncarryingcapacity) {
		this.ncarryingcapacity = ncarryingcapacity;
	}
	public List<String> getStrvehicletype() {
		return strvehicletype;
	}
	public void setStrvehicletype(List<String> strvehicletype) {
		this.strvehicletype = strvehicletype;
	}
	public List<String> getStrsegmenttype() {
		return strsegmenttype;
	}
	public void setStrsegmenttype(List<String> strsegmenttype) {
		this.strsegmenttype = strsegmenttype;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public List<BigDecimal> getStrgvw() {
		return strgvw;
	}
	public void setStrgvw(List<BigDecimal> strgvw) {
		this.strgvw = strgvw;
	}

	
	

}

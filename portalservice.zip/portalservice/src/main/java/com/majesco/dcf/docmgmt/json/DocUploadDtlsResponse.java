package com.majesco.dcf.docmgmt.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResultObject;

/**
 * @author yogesh570158
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocUploadDtlsResponse extends ResultObject {
	
	
	
}

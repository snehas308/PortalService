package com.majesco.dcf.paproduct.json;

import java.util.Date;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.CustomerDetails;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class SearchIPAQuotResponse {
	private String quotionNo;
	private String productCd;
	private String customerId;
	private String firstName;
	private String lastName;
	private String mobileNo;
	private String intermediaryCd;
	private String quotationDate;
	private String plan;
	private String creationDate;
	private PAQuickQuotPrmRequest quoteRequestData;
	private PAQuickQuotPrmResponse quoteResponseData;
	private CustomerDetails custDetails;
	
	public String getQuotionNo() {
		return quotionNo;
	}
	public void setQuotionNo(String quotionNo) {
		this.quotionNo = quotionNo;
	}
	public String getProductCd() {
		return productCd;
	}
	public void setProductCd(String productCd) {
		this.productCd = productCd;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getIntermediaryCd() {
		return intermediaryCd;
	}
	public void setIntermediaryCd(String intermediaryCd) {
		this.intermediaryCd = intermediaryCd;
	}
	public String getQuotationDate() {
		return quotationDate;
	}
	public void setQuotationDate(String quotationDate) {
		this.quotationDate = quotationDate;
	}
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public PAQuickQuotPrmRequest getQuoteRequestData() {
		return quoteRequestData;
	}
	public void setQuoteRequestData(PAQuickQuotPrmRequest quoteRequestData) {
		this.quoteRequestData = quoteRequestData;
	}
	public PAQuickQuotPrmResponse getQuoteResponseData() {
		return quoteResponseData;
	}
	public void setQuoteResponseData(PAQuickQuotPrmResponse quoteResponseData) {
		this.quoteResponseData = quoteResponseData;
	}
	public CustomerDetails getCustDetails() {
		return custDetails;
	}
	public void setCustDetails(CustomerDetails custDetails) {
		this.custDetails = custDetails;
	}
	
}

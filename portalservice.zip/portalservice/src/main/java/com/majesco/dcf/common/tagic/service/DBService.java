package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.engine.spi.SessionFactoryImplementor; // ADDED FOR ORACLE MIGRATION
import org.hibernate.service.jdbc.connections.spi.ConnectionProvider; // ADDED FOR ORACLE MIGRATION
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.tagic.entity.AdvanceReceiptDtl;
import com.majesco.dcf.common.tagic.entity.BranchMaster;
import com.majesco.dcf.common.tagic.entity.City;
import com.majesco.dcf.common.tagic.entity.ClaimDocMaster;
import com.majesco.dcf.common.tagic.entity.Company;
import com.majesco.dcf.common.tagic.entity.CompanyMaster;
import com.majesco.dcf.common.tagic.entity.Country;
import com.majesco.dcf.common.tagic.entity.CoverDetailsMaster;
import com.majesco.dcf.common.tagic.entity.CustomerEntity;
import com.majesco.dcf.common.tagic.entity.DealerMaster;
import com.majesco.dcf.common.tagic.entity.DocumentMaster;
import com.majesco.dcf.common.tagic.entity.ExternalMapList;
import com.majesco.dcf.common.tagic.entity.FieldUser;
import com.majesco.dcf.common.tagic.entity.FinancierMaster;
import com.majesco.dcf.common.tagic.entity.GarageCityMaster;
import com.majesco.dcf.common.tagic.entity.GarageRadius;
import com.majesco.dcf.common.tagic.entity.InBoundMaster;
import com.majesco.dcf.common.tagic.entity.InterfaceParam;
import com.majesco.dcf.common.tagic.entity.InternalUser;
import com.majesco.dcf.common.tagic.entity.Manufact;
import com.majesco.dcf.common.tagic.entity.Masters;
import com.majesco.dcf.common.tagic.entity.Model;
import com.majesco.dcf.common.tagic.entity.MotorQuoteEntity;
import com.majesco.dcf.common.tagic.entity.OfficeMaster;
import com.majesco.dcf.common.tagic.entity.OnlineAccountService;
import com.majesco.dcf.common.tagic.entity.OutBoundMaster;
import com.majesco.dcf.common.tagic.entity.ParameterDetailList;
import com.majesco.dcf.common.tagic.entity.ParameterList;
import com.majesco.dcf.common.tagic.entity.PayinPdfMaster;
import com.majesco.dcf.common.tagic.entity.PaymentDetails;
import com.majesco.dcf.common.tagic.entity.PmtFlowFlags;
import com.majesco.dcf.common.tagic.entity.RTOLocation;
import com.majesco.dcf.common.tagic.entity.RenPolicyMaster;
import com.majesco.dcf.common.tagic.entity.ReportsMaster;
import com.majesco.dcf.common.tagic.entity.SecurityQuestion;
import com.majesco.dcf.common.tagic.entity.SelfPaymentEntiry;
import com.majesco.dcf.common.tagic.entity.SpMaster;
import com.majesco.dcf.common.tagic.entity.State;
import com.majesco.dcf.common.tagic.entity.Student;
import com.majesco.dcf.common.tagic.entity.SubAgentMaster;
import com.majesco.dcf.common.tagic.entity.SubCategory;
import com.majesco.dcf.common.tagic.entity.UserTransaction;
import com.majesco.dcf.common.tagic.entity.VehicleAddOn;
import com.majesco.dcf.common.tagic.entity.VehicleIdv;
import com.majesco.dcf.common.tagic.entity.VehicleSubClass;
//import com.majesco.dcf.common.tagic.json.AccFinancierVO_old;
//import com.majesco.dcf.common.tagic.json.PrevInsurerRequest;
import com.majesco.dcf.common.tagic.json.AccFinancierBranchRequest;
import com.majesco.dcf.common.tagic.json.AddOnRequest;
import com.majesco.dcf.common.tagic.json.CustomerSearchRequest;
import com.majesco.dcf.common.tagic.json.DealerMasterRequest;
import com.majesco.dcf.common.tagic.json.DocListRequest;
import com.majesco.dcf.common.tagic.json.DocumentMasterRequest;
import com.majesco.dcf.common.tagic.json.DocumentVO;
import com.majesco.dcf.common.tagic.json.FieldUserRequest;
import com.majesco.dcf.common.tagic.json.GarageRadiusRequest;
import com.majesco.dcf.common.tagic.json.IDVRelaxationRequest;
import com.majesco.dcf.common.tagic.json.ModelRequest;
import com.majesco.dcf.common.tagic.json.PinCodeRequest;
import com.majesco.dcf.common.tagic.json.PrevInsurerRequest;
import com.majesco.dcf.common.tagic.json.RTOLocationRequest;
import com.majesco.dcf.common.tagic.json.RenewalSearchRequest;
import com.majesco.dcf.common.tagic.json.SubCategoryRequest;
import com.majesco.dcf.common.tagic.json.VehicleAddOnRequest;
import com.majesco.dcf.common.tagic.json.VehicleIdvRequest;
import com.majesco.dcf.common.tagic.json.VehicleVariantRequest;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.docmgmt.entity.DocUploadDtlsEntity;
import com.majesco.dcf.docmgmt.entity.DocUploadOptn;
import com.majesco.dcf.docmgmt.entity.ProducerLockDetails;
import com.majesco.dcf.docmgmt.json.DocUploadDtlsObj;
import com.majesco.dcf.docmgmt.json.DocUploadSearchObj;
import com.majesco.dcf.docmgmt.json.ProducerLockDtlsSearchReq;
import com.majesco.dcf.docmgmt.json.QCInspectionRequest;
import com.majesco.dcf.paproduct.entity.QuotationPA;
import com.majesco.dcf.paproduct.entity.QuotationPA1;
import com.majesco.dcf.paproduct.json.CalculatorPARequest;
import com.majesco.dcf.paproduct.json.SearchIPAQuotRequest;
import com.majesco.dcf.pg.entity.PGTransaction;
import com.majesco.dcf.pg.upi.entity.UpiTransactionDtl; //1266
import com.majesco.dcf.usermgmt.entity.RoleEntity;
import com.majesco.dcf.usermgmt.json.FetchRolePrivilegeList;
import com.majesco.dcf.usermgmt.json.FetchRolePrivilegeRequest;
import com.majesco.dcf.usermgmt.json.FetchUserRoleList;
import com.majesco.dcf.usermgmt.json.FetchUserRoleRequest;
import com.majesco.dcf.usermgmt.json.PrivilegeDetails;
import com.majesco.dcf.usermgmt.json.RoleDetails;
import com.majesco.dcf.usermgmt.json.RolePrivList;
import com.majesco.dcf.usermgmt.json.UserCredentials;
import com.majesco.dcf.usermgmt.json.UserRoleList;

/**
 *
 * This service has methods for database operations. Uses Hibernate 4.2.8
 */
@Service
@Transactional
public class DBService {

	@Autowired
	private HibernateTransactionManager transactionManager;

	@Autowired
	GenericTypeService service;

	final static Logger logger = Logger.getLogger(DBService.class);

	// @Value("${usrmgt.schema}") // Commented for oracle migration
	// private String usrmgtSchema; // Commented for oracle migration

	public void print(String args) {
		logger.info("Inside DBService :: print method :: Execution Started");
		Session session = null;
		Transaction transaction = null;

		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// System.out.println("Got connection ......");

			// String sql = "select a.name from company where name=:name";
			// SQLQuery query = session.createSQLQuery(sql);

			List<Company> query = session.createQuery("from Company").list();
			// System.out.println("Got connection ..122....");
			/*
			 * for (Iterator iterator = query.iterator(); iterator.hasNext();) {
			 * Company comp1 = (Company)iterator.next();
			 * 
			 * //System.out.print("First Name: " + comp1.getName());
			 * //System.out.print("  Last Name: " + comp1.getAddress()); }
			 */

			logger.info("Inside DBService :: print method :: Execution Completed Successfully");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
			logger.error(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		// System.out.println("Got Success....");
		// query.setParameter("name", args);

	}

	// **
	/*
	 * * This method is used to insert a record into database
	 * 
	 * @param insertObj
	 *//*
		 * public void put(Object insertObj){ if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.Put Method"); } Session session =
		 * transactionManager.getSessionFactory().getCurrentSession();
		 * Transaction transaction = session.getTransaction();
		 * if(!transaction.isActive()){ session.beginTransaction(); } try {
		 * session.save(insertObj); transaction.commit(); } catch (Exception e)
		 * {
		 * 
		 * transaction.rollback(); // TODO Auto-generated catch block
		 * if(logger.isDebugEnabled()){
		 * logger.debug("DBService.Put Catch block"); } e.printStackTrace();
		 * }finally{
		 * 
		 * }
		 * 
		 * if(logger.isDebugEnabled()){
		 * logger.debug("Out DBService.Put Method"); } }
		 *//**
	 * This method is used to get generate next value of provided
	 * sequence
	 * 
	 * @param sequence
	 * @return Long
	 */
	/*
	 * public Long getNextKey(String sequence) { Session session =
	 * transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if(!transaction.isActive()){
	 * session.beginTransaction(); } Query query = session.createSQLQuery(
	 * "select nextval('"+sequence+"')" ); Long key = ((BigInteger)
	 * query.uniqueResult()).longValue(); return key; }
	 * 
	 * 
	 * public String getBPMTaskID (String activityId){
	 * 
	 * List lstResult = null; String taskId = null;
	 * 
	 * try { if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.getBPMTaskID Method"); }
	 * 
	 * if(activityId == null) { return null; }
	 * 
	 * Session session =
	 * transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if (!transaction.isActive()) {
	 * session.beginTransaction(); }
	 * 
	 * String sql =
	 * "select id_ from act_ru_task where proc_inst_id_='"+activityId+"'";
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.getBPMTaskID Method sql-- "+ sql); }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * 
	 * lstResult = query.list();
	 * 
	 * if(lstResult != null && lstResult.size() > 0){ taskId = (String)
	 * lstResult.get(0); }
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService.getBPMTaskID Method Task ID -"+ taskId); }
	 * 
	 * } catch (Exception e) {
	 * logger.error("::::::Error in getBPMTaskID ::::::", e);
	 * e.printStackTrace(); }
	 * 
	 * return taskId;
	 * 
	 * }
	 *//**
	 * This method is used to fetch a record from database
	 * 
	 * @param className
	 * @param paramName
	 * @param paramValue
	 * @return Object
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	/**/
	@SuppressWarnings("rawtypes")
	public Object get(String className, String paramName, Object paramValue)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		Object returnObject = new Object();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.get Method"); }
			 */

			logger.info("Inside DBService :: get(String, String, Object) method :: Execution Started, paramaname--> "
					+ paramName + " ParamValue -->" + paramValue.toString());

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq(paramName, paramValue));
			List retList = criteria.list();

			logger.info("Inside DBService :: List " + retList.toString());

			if (!retList.isEmpty()) {
				logger.info("Inside DBService :: List is non empty "
						+ retList.get(0));
				returnObject = retList.get(0);
			}

			logger.info("Inside DBService :: get(String, String, Object) method :: Execution Completed Successfully, return object --> "
					+ returnObject);

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.get Method"); }
			 */
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
			logger.error(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return returnObject;
	}

	/*
	*//**
	 * This method is used to fetch a record from database
	 * 
	 * @param className
	 * @param paramName
	 * @param paramValue
	 * @return Object
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	/**/
	@SuppressWarnings("rawtypes")
	public Object get(String className, List<String> paramName,
			List<Object> paramValue) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		Object returnObject = new Object();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.get Method"); }
			 */

			logger.info("Inside DBService :: get(String, List<String>, List<Object>) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			for (int index = 0; index < paramName.size(); index++) {
				criteria.add(Restrictions.eq(paramName.get(index),
						paramValue.get(index)));
			}
			List retList = criteria.list();

			if (!retList.isEmpty()) {
				returnObject = retList.get(0);
			}

			logger.info("Inside DBService :: get(String, List<String>, List<Object>) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.get Method"); }
			 */
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
			logger.error(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return returnObject;
	}

	/*

	*//**
	 * This method is used to fetch a record from database
	 * 
	 * @param className
	 * @param paramName
	 * @param paramValue
	 * @return Object
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	/**/
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getList(String className,
			List<String> paramName, List<Object> paramValue)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List retList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getList Method"); }
			 */

			logger.info("Inside DBService :: getList(String, List<String>, List<Object>) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			for (int index = 0; index < paramName.size(); index++) {
				criteria.add(Restrictions.eq(paramName.get(index),
						paramValue.get(index)));
			}
			retList = criteria.list();

			logger.info("Inside DBService :: getList(String, List<String>, List<Object>) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getList Method"); }
			 */
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
			logger.error(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return retList;
	}

	/*
	*//**
	 * This method is used to fetch a record from database
	 * 
	 * @param className
	 * @param paramName
	 * @param paramValue
	 * @return Object
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	/**/
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getListUsingIn(String className,
			String paramName, List<Object> paramValue)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List retList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getList Method"); }
			 */

			logger.info("Inside DBService :: getListUsingIn(String, String, List<Object>) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.in(paramName, paramValue.toArray()));
			retList = criteria.list();

			logger.info("Inside DBService :: getListUsingIn(String, String, List<Object>) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getList Method"); }
			 */
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
			logger.error(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return retList;
	}

	/*
	 * //** This method is used to fetch a record from database
	 * 
	 * @param className
	 * 
	 * @param paramName
	 * 
	 * @param paramValue
	 * 
	 * @return Object
	 * 
	 * @throws ClassNotFoundException
	 * 
	 * @throws InstantiationException
	 * 
	 * @throws IllegalAccessException
	 *//**/
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List<? extends
	 * Object> getList(String className, String paramName,Object paramValue)
	 * throws ClassNotFoundException, InstantiationException,
	 * IllegalAccessException{ if(logger.isDebugEnabled()){
	 * logger.debug("In DBService.getList Method"); } Class classInstance =
	 * Class.forName(className); Session session =
	 * transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if(!transaction.isActive()){
	 * session.beginTransaction(); } Criteria criteria =
	 * session.createCriteria(classInstance
	 * ).setProjection(Projections.countDistinct(paramName).setDistinct());
	 * criteria.add(Restrictions.eq(paramName,
	 * paramValue)).setResultTransformer(
	 * CriteriaSpecification.DISTINCT_ROOT_ENTITY);
	 * 
	 * 
	 * 
	 * List retList = (List) criteria.uniqueResult();
	 * 
	 * // List<ParameterDetailList> query =
	 * session.createQuery("from Company").list();
	 * 
	 * if (retList.size()>0) {
	 * 
	 * for (Iterator iterator = retList.iterator(); iterator.hasNext();) {
	 * ParameterDetailList comp1 = (ParameterDetailList)iterator.next();
	 * 
	 * 
	 * }
	 * 
	 * } if(logger.isDebugEnabled()){
	 * logger.debug("Out DBService.getList Method"); } return retList; }
	 */

	/*
	 * //** This method is used to fetch a List of records from database
	 * 
	 * @param className
	 * 
	 * @return List
	 * 
	 * @throws ClassNotFoundException
	 * 
	 * @throws InstantiationException
	 * 
	 * @throws IllegalAccessException
	 *//**/
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> get(String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {

		List<ParameterList> retList = new ArrayList<ParameterList>();
		Session session = null;
		Transaction transaction = null;

		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.get Method"); }
			 */

			logger.info("Inside DBService :: get(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			/*
			 * Criteria criteria = session.createCriteria(classInstance); List
			 * retList = criteria.list();
			 */

			retList = session.createQuery("from ParameterList").list();

			/*
			 * for (Iterator iterator = retList.iterator(); iterator.hasNext();)
			 * { ParameterList comp1 = (ParameterList)iterator.next();
			 * 
			 * 
			 * }
			 */

			List<Student> retList1 = session.createQuery("from Student").list();

			/*
			 * for (Iterator iterator = retList1.iterator();
			 * iterator.hasNext();) { Student comp2 = (Student)iterator.next();
			 * 
			 * 
			 * //System.out.print("  ID: " + comp2.getId());
			 * //System.out.print("  First Name: " + comp2.getFirstname());
			 * //System.out.print("  Last Name: " + comp2.getLastname());
			 * //System.out.print("  State: " + comp2.getState());
			 * //System.out.print("City: " + comp2.getCity()); }
			 */

			logger.info("Inside DBService :: get(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.get Method"); }
			 */
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
			logger.error(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return retList;
	}

	/** GET Branch **/

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getBranch(String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<BranchMaster> retList = new ArrayList<BranchMaster>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getBranch Method"); }
			 */

			logger.info("Inside DBService :: getBranch(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			retList = session.createQuery("from BranchMaster ").list();

			List<Masters> mstList = session.createQuery("from Masters").list();

			/*
			 * for (Iterator iterator = retList.iterator(); iterator.hasNext();)
			 * { BranchMaster comp1 = (BranchMaster)iterator.next();
			 * 
			 * 
			 * }
			 */

			/*
			 * for (Iterator iterator = retList.iterator(); iterator.hasNext();)
			 * { BranchMaster comp1 = (BranchMaster)iterator.next();
			 * 
			 * 
			 * }
			 */

			logger.info("Inside DBService :: getBranch(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getBranch Method"); }
			 */
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
			logger.error(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return retList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getSchema(String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<Masters> mstList = new ArrayList<Masters>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getBranch Method"); }
			 */

			logger.info("Inside DBService :: getSchema(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			/*
			 * Criteria criteria = session.createCriteria(classInstance); List
			 * retList = criteria.list();
			 */

			// List<BranchMaster> retList =
			// session.createQuery("from BranchMaster").list();

			mstList = session.createQuery("from Masters").list();

			/*
			 * for (Iterator iterator = mstList.iterator(); iterator.hasNext();)
			 * { Masters comp1 = (Masters)iterator.next();
			 * 
			 * //System.out.println("test............"+comp1.getId()); }
			 */

			logger.info("Inside DBService :: getSchema(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getBranch Method"); }
			 */
			transaction.commit();
			return mstList;
		} catch (Exception e) {
			transaction.rollback();
			logger.info(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
			logger.error(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return mstList;
	}

	/*
	 * //** This method is used to update a record in database
	 * 
	 * @param insertObj
	 *//*
		 * public void update(Object insertObj){ if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.update Method"); } Session session =
		 * transactionManager.getSessionFactory().getCurrentSession();
		 * Transaction transaction = session.getTransaction();
		 * if(!transaction.isActive()){ session.beginTransaction(); }
		 * 
		 * try { session.update(insertObj); transaction.commit(); } catch
		 * (Exception e) { transaction.rollback(); // TODO Auto-generated catch
		 * block if(logger.isDebugEnabled()){
		 * logger.debug("DBService.update Catch block"); } e.printStackTrace();
		 * } if(logger.isDebugEnabled()){
		 * logger.debug("Out DBService.update Method"); } }
		 *//**
	 * This method is save a record in database
	 * 
	 * @param insertObj
	 */
	/**/
	public void save(Object insertObj) {
		Session session = null;
		Transaction transaction = null;

		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.save Method"); }
		 */

		logger.info("Inside DBService :: save method :: Execution Started");

		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			session.save(insertObj);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			// TODO Auto-generated catch block
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("DBService.save Catch block"); }
			 */
			e.printStackTrace();
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		logger.info("Inside DBService :: save method :: Execution Completed Successfully");

		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("Out DBService.save Method"); }
		 */
	}

	/*
	 * //** /* * This method is used to save or update a record in database
	 * 
	 * @param insertObj
	 *//*
	 *
	 */
	public void saveOrUpdate(Object insertObj) {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.saveOrUpdate Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: saveOrUpdate method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			session.saveOrUpdate(insertObj);
			transaction.commit();
		} catch (Exception e) {
			logger.error("In DBService :: saveOrUpdate error ::", e);
			transaction.rollback();
			// TODO Auto-generated catch block
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("DBService.saveOrUpdate catch block"); }
			 */
			e.printStackTrace();
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }

		logger.info("Inside DBService :: saveOrUpdate method :: Execution Completed Successfully");

		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("Out DBService.saveOrUpdate Method"); }
		 */
	}

	/*
	 * //** /* This method is used to save or update List of records in database
	 * 
	 * @param insertObj
	 *//* */
	public void saveOrUpdateList(List<? extends Object> insertObjList) {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.saveOrUpdate Method"); }
		 */
		Session session = null;
		Transaction transaction = null;

		logger.info("Inside DBService :: saveOrUpdateList method :: Execution Started");

		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			for (Object insertObj : insertObjList)
				session.saveOrUpdate(insertObj);

			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			// TODO Auto-generated catch block
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("DBService.saveOrUpdateList catch block"); }
			 */
			e.printStackTrace();
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }

		logger.info("Inside DBService :: saveOrUpdateList method :: Execution Completed Successfully");

		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("Out DBService.saveOrUpdate Method"); }
		 */
	}

	/*
	 * //** This method is used to check existence of a record in database
	 * 
	 * @param className
	 * 
	 * @param paramName
	 * 
	 * @param paramValue
	 * 
	 * @return Object
	 * 
	 * @throws ClassNotFoundException
	 * 
	 * @throws InstantiationException
	 * 
	 * @throws IllegalAccessException
	 *//**/
	@SuppressWarnings("rawtypes")
	public List fetchRecord(String className, String paramName,
			Object paramValue) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.fetchRecord Method"); }
		 */

		logger.info("Inside DBService :: fetchRecord method :: Execution Started");

		List retList = null;
		Session session = null;
		Transaction transaction = null;
		Integer objCount = null;
		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq(paramName, paramValue));

			retList = criteria.list();

			if (!retList.isEmpty()) {
				objCount = retList.size();
			} else {
				objCount = new Integer(0);
			}

			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.error("::::::Error in fetchRecord ::::::", e);
			e.printStackTrace();
			logger.error("::::::Returning zero empty list from fetchRecord ::::::");
			retList = new ArrayList();
		}
		// session.close();

		logger.info("Inside DBService :: fetchRecord method :: Execution Completed Successfully");

		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("Out DBService.fetchRecord Method"); }
		 */
		return retList;
	}

	/*
	 * //** This method is used to fetch application details in database
	 * 
	 * @param className
	 * 
	 * @param paramName
	 * 
	 * @param paramValue
	 * 
	 * @return Object
	 * 
	 * @throws ClassNotFoundException
	 * 
	 * @throws InstantiationException
	 * 
	 * @throws IllegalAccessException
	 */
	@SuppressWarnings("rawtypes")
	public List fetchApplication(String className1, String className2,
			String paramName, Object paramValue) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List retList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.checkExistence Method"); }
			 */

			logger.info("Inside DBService :: fetchApplication method :: Execution Started");

			Class classInstance = Class.forName(className1);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq(paramName, paramValue));
			retList = criteria.list();

			Integer objCount = null;
			if (!retList.isEmpty()) {
				objCount = retList.size();
			} else {
				objCount = new Integer(0);
			}
			transaction.commit();
			// session.close();

			logger.info("Inside DBService :: fetchApplication method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.checkExistence Method"); }
			 */
		} catch (Exception e) {
			transaction.rollback();
			logger.info(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
			logger.error(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return retList;
	}

	/*
	 * //**
	 * 
	 * @param className
	 * 
	 * @param paramValueMap
	 * 
	 * @return
	 * 
	 * @throws ClassNotFoundException
	 * 
	 * @throws InstantiationException
	 * 
	 * @throws IllegalAccessException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getListWithMultiParam(String className,
			Map<String, Object> paramValueMap) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.getList Method"); }
		 */

		logger.info("Inside DBService :: getListWithMultiParam method :: Execution Started");

		List retList = null;
		Session session = null;
		Transaction transaction = null;

		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);

			for (Map.Entry<String, Object> mapEntry : paramValueMap.entrySet()) {
				criteria.add(Restrictions.eq(mapEntry.getKey(),
						mapEntry.getValue()));
			}

			retList = criteria.list();
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.error("::::::Error in getListWithMultiParam ::::::", e);
			e.printStackTrace();
			logger.error("::::::Returning zero empty list from getListWithMultiParam ::::::");
			retList = new ArrayList();
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		logger.info("Inside DBService :: getListWithMultiParam method :: Execution Completed Successfully");

		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("Out DBService.getList Method"); }
		 */

		return retList;
	}

	/*
	 * //** This method is used to fetch bank List from database.
	 * 
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List fetchBankList() {
		List lstResult = null;
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("In DBService.fetchBankBranchIfsc Method"); }
			 */

			logger.info("Inside DBService :: fetchBankList method :: Execution Started");

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			String sql = "select distinct(bankcode) from dif_bank_branch_m";

			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("In DBService.fetchBankBranchIfsc Method sql-- "+
			 * sql); }
			 */

			SQLQuery query = session.createSQLQuery(sql);

			lstResult = query.list();

			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("Out DBService.getDeviceList Method alBankDevice--"+
			 * lstResult); }
			 */
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.error("::::::Error in alBankDevice ::::::", e);
			e.printStackTrace();
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		logger.info("Inside DBService :: fetchBankList method :: Execution Completed Successfully");

		return lstResult;
	}

	/*
	 * //**
	 * 
	 * @param className
	 * 
	 * @param orderBy
	 * 
	 * @return
	 *//*
		 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
		 * fetchAllRecords(String className, String orderBy) {
		 * 
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.fetchRecord Method"); } List retList =
		 * null; try{ Class classInstance = Class.forName(className); Session
		 * session = transactionManager.getSessionFactory().getCurrentSession();
		 * Transaction transaction = session.getTransaction();
		 * if(!transaction.isActive()){ session.beginTransaction(); } Criteria
		 * criteria = session.createCriteria(classInstance);
		 * criteria.addOrder(Order.desc(orderBy)); retList = criteria.list();
		 * 
		 * session.close(); }catch(Exception e){
		 * logger.error("::::::Error in fetchRecord ::::::", e);
		 * e.printStackTrace();
		 * logger.error("::::::Returning zero empty list from fetchRecord ::::::"
		 * ); retList = new ArrayList(); }
		 * 
		 * if(logger.isDebugEnabled()){
		 * logger.debug("Out DBService.fetchRecord Method"); } return retList;
		 * 
		 * 
		 * 
		 * }
		 * 
		 * public List getAllRecords(String className, String orderbyCol, String
		 * distinctCol ){
		 * 
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.fetchRecord Method"); } List retList =
		 * null; try{ Class classInstance = Class.forName(className); Session
		 * session = transactionManager.getSessionFactory().getCurrentSession();
		 * Transaction transaction = session.getTransaction();
		 * if(!transaction.isActive()){ session.beginTransaction(); } Criteria
		 * criteria = session.createCriteria(classInstance);
		 * 
		 * if(orderbyCol !=null && !"".equals(orderbyCol)){
		 * criteria.addOrder(Order.desc(orderbyCol)); }
		 * 
		 * retList = criteria.list();
		 * 
		 * 
		 * session.close(); }catch(Exception e){
		 * logger.error("::::::Error in fetchRecord ::::::", e);
		 * e.printStackTrace();
		 * logger.error("::::::Returning zero empty list from fetchRecord ::::::"
		 * ); retList = new ArrayList(); }
		 * 
		 * if(logger.isDebugEnabled()){
		 * logger.debug("Out DBService.fetchRecord Method"); } return retList;
		 * 
		 * }
		 *//**
	 * @return
	 */
	/*
	 * public List<String> fetchAgentCode(){
	 * 
	 * List<String> lstResult = null; try { if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.getchAgentCode Method"); } Session session =
	 * transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if (!transaction.isActive()) {
	 * session.beginTransaction(); } String sql =
	 * "select distinct stragentcode from dif_client_m where stragentcode <>''";
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.getchAgentCode Method sql-- "+ sql); }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * 
	 * lstResult = query.list();
	 * 
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService Method getchAgentCode--"+ lstResult); }
	 * session.close();
	 * 
	 * } catch (Exception e) { lstResult = new ArrayList();
	 * logger.error("::::::Error in getchAgentCode ::::::", e);
	 * e.printStackTrace(); }
	 * 
	 * return lstResult;
	 * 
	 * }
	 *//**
	 * @return
	 */
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
	 * fetchAgentDetails() { List lstResult = null; try { if
	 * (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchAgentDetails Method"); } Session session
	 * = transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if (!transaction.isActive()) {
	 * session.beginTransaction(); }
	 * 
	 * String sql = " select * from ";
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchAgentDetails Method sql-- "+ sql); }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * 
	 * lstResult = query.list();
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService Method fetchAgentDetails--"+ lstResult); }
	 * 
	 * } catch (Exception e) {
	 * logger.error("::::::Error in alBankDevice ::::::", e);
	 * e.printStackTrace(); }
	 * 
	 * return lstResult; }
	 *//**
	 * @param strcountrycd
	 * @return
	 */
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
	 * fetchCountryStateList(String strcountrycd) { List<Object[]> lstResult =
	 * null; try { if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchCountryStateList Method -- "
	 * +strcountrycd); } Session session =
	 * transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if (!transaction.isActive()) {
	 * session.beginTransaction(); }
	 * 
	 * String sql =
	 * "select strstatecd, strstatedesc from dif_country_state_m where strcountrycd=:p1"
	 * ;
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchCountryStateList Method sql-- "+ sql); }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * query.setParameter("p1",strcountrycd);
	 * 
	 * lstResult = (List<Object[]>) query.list();
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService.fetchCountryStateList Method --"+ lstResult);
	 * }
	 * 
	 * } catch (Exception e) {
	 * logger.error("::::::Error in fetchCountryStateList ::::::", e);
	 * e.printStackTrace(); }
	 * 
	 * return lstResult; }
	 *//**
	 * @param strcountrycd
	 * @param stateCode
	 * @return
	 */
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
	 * fetchStateDistirctList(String strcountrycd,String stateCode) {
	 * List<Object[]> lstResult = null; try { if (logger.isDebugEnabled()) {
	 * logger
	 * .debug("In DBService.fetchStateDistirctList Method -- "+strcountrycd
	 * +" , "+ stateCode); } Session session =
	 * transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if (!transaction.isActive()) {
	 * session.beginTransaction(); }
	 * 
	 * String sql =
	 * "select strdistcd, strdistdesc from dif_state_district_m where strcountrycd=:p1 and strstatecd=:p2"
	 * ;
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchStateDistirctList Method sql-- "+ sql); }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * query.setParameter("p1",strcountrycd);
	 * query.setParameter("p2",stateCode);
	 * 
	 * lstResult = (List<Object[]>) query.list();
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService.fetchStateDistirctList Method --"+
	 * lstResult); }
	 * 
	 * } catch (Exception e) {
	 * logger.error("::::::Error in fetchStateDistirctList ::::::", e);
	 * e.printStackTrace(); }
	 * 
	 * return lstResult; }
	 *//**
	 * @param strlevel
	 * @return
	 */
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
	 * fetchQualification(String strlevel) { List<Object[]> lstResult = null;
	 * try { if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchStateDistirctList Method -- "+strlevel);
	 * } Session session =
	 * transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if (!transaction.isActive()) {
	 * session.beginTransaction(); }
	 * 
	 * String sql =
	 * "select strqualificationcd, strqualificationdesc from dif_ednlev_qual_m where strednlevelcd=:p1"
	 * ;
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchStateDistirctList Method sql-- "+ sql); }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * query.setParameter("p1",strlevel);
	 * 
	 * lstResult = (List<Object[]>) query.list();
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService.fetchStateDistirctList Method --"+
	 * lstResult); }
	 * 
	 * } catch (Exception e) {
	 * logger.error("::::::Error in fetchStateDistirctList ::::::", e);
	 * e.printStackTrace(); }
	 * 
	 * return lstResult; }
	 *//**
	 * @param period
	 * @param branchMgr
	 * @return
	 */
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
	 * fetchBoardingSummary(String period, String branchMgr) { List lstResult =
	 * null; String sql = null; try { if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchBoardingSummary Method"); } Session
	 * session = transactionManager.getSessionFactory().getCurrentSession();
	 * Transaction transaction = session.getTransaction(); if
	 * (!transaction.isActive()) { session.beginTransaction(); }
	 * if(branchMgr!=null){ sql =
	 * "select strstatus, count(strstatus) from dif_client_m " +
	 * "where branchmgr_name = '"+branchMgr+"' " +
	 * "and strstatusdate between cast(date_trunc('"
	 * +period+"',current_date) as date) " +
	 * "and CURRENT_DATE group by strstatus order by count desc"; }else{
	 * 
	 * sql = "select strstatus, count(strstatus) from dif_client_m " +
	 * "where strstatusdate between cast(date_trunc('"
	 * +period+"',current_date) as date) " +
	 * "and CURRENT_DATE group by strstatus order by count desc"; }
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchBoardingSummary Method sql-- "+ sql); }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * 
	 * lstResult = query.list();
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService.fetchBoardingSummary Method lstResult--"+
	 * lstResult); }
	 * 
	 * } catch (Exception e) { logger.error("::::::Error in lstResult ::::::",
	 * e); e.printStackTrace(); }
	 * 
	 * return lstResult; }
	 *//**
	 * @param branchAgtCd
	 * @param isBranch
	 * @return
	 */
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
	 * fetchProductionKpi(String branchAgtCd, Integer isBranch) { List lstResult
	 * = null; String sql = null; try { if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchProductionKpi Method"); } Session session
	 * = transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if (!transaction.isActive()) {
	 * session.beginTransaction(); }
	 * 
	 * if(isBranch.equals(1)){ sql =
	 * "select sum(kpi_value), kpi_name, Extract(month from kpicalc_date) from dif_production_kpi "
	 * + "where branch_cd = '"+branchAgtCd+"' " + "and is_branch="+isBranch+" "
	 * + "and Extract(year from kpicalc_date)=Extract(year from CURRENT_DATE) "
	 * + "group by kpicalc_date,kpi_name order by kpicalc_date asc"; }else{
	 * 
	 * sql =
	 * "select sum(kpi_value), kpi_name, Extract(month from kpicalc_date) from dif_production_kpi "
	 * + "where agent_cd = '"+branchAgtCd+"' " +
	 * "and Extract(year from kpicalc_date)=Extract(year from CURRENT_DATE) " +
	 * "group by kpicalc_date,kpi_name order by kpicalc_date asc"; }
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchProductionKpi Method sql-- "+ sql); }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * 
	 * lstResult = query.list();
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService.fetchProductionKpi Method lstResult--"+
	 * lstResult); }
	 * 
	 * } catch (Exception e) { logger.error("::::::Error in lstResult ::::::",
	 * e); e.printStackTrace(); }
	 * 
	 * return lstResult; }
	 *//**
	 * @param className
	 * @param paramName1
	 * @param paramName2
	 * @param paramValue
	 * @return
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	/*
	 * @SuppressWarnings("rawtypes") public List fetchHierarchyDesc(String
	 * className, String paramName1, String paramName2, Object paramValue)
	 * throws ClassNotFoundException, InstantiationException,
	 * IllegalAccessException{ if(logger.isDebugEnabled()){
	 * logger.debug("In DBService.fetchHierarchyDesc Method"); } List retList =
	 * null; Class classInstance = Class.forName(className); Session session =
	 * transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if(!transaction.isActive()){
	 * session.beginTransaction(); } Criteria criteria =
	 * session.createCriteria(classInstance); Criterion suvcd =
	 * Restrictions.eq(paramName1, paramValue); Criterion agtCd =
	 * Restrictions.eq(paramName2, paramValue); LogicalExpression orExp =
	 * Restrictions.or(suvcd,agtCd); criteria.add(orExp); try{ retList =
	 * criteria.list(); }catch(Exception e){
	 * logger.error("::::::Error in fetchHierarchyDesc ::::::", e);
	 * e.printStackTrace();
	 * logger.error("::::::Returning zero empty list from fetchHierarchyDesc ::::::"
	 * ); retList = new ArrayList(); } session.close();
	 * if(logger.isDebugEnabled()){
	 * logger.debug("Out DBService.fetchHierarchyDesc Method"); } return
	 * retList; }
	 *//**
	 * @param agentCd
	 * @param fromMon
	 * @param toMon
	 * @param fromYear
	 * @param toYear
	 * @return
	 */
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
	 * fetchCommissionDetails(String agentCd, String fromMon, String toMon,
	 * String fromYear, String toYear) { List lstResult = null; try { if
	 * (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchCommissionDetails Method"); } Session
	 * session = transactionManager.getSessionFactory().getCurrentSession();
	 * Transaction transaction = session.getTransaction(); if
	 * (!transaction.isActive()) { session.beginTransaction(); }
	 * 
	 * 
	 * String sql =
	 * "select sum(commamt), paydate, payMode, paystat, to_char(paydate, 'Mon, YYYY') period from dif_commission_details "
	 * + "where agentcode = '"+agentCd+"' " +
	 * "and Extract(year from paydate) between '"+fromYear+"' and '"+toYear+"' "
	 * +
	 * "and Extract(month from paydate) between '"+fromMon+"' and '"+toMon+"' "
	 * + "group by paydate,payMode,paystat";
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchCommissionDetails Method sql-- "+ sql); }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * 
	 * lstResult = query.list();
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService.fetchCommissionDetails Method lstResult--"+
	 * lstResult); }
	 * 
	 * } catch (Exception e) { logger.error("::::::Error in lstResult ::::::",
	 * e); e.printStackTrace(); }
	 * 
	 * return lstResult; }
	 *//**
	 * @param agentCd
	 * @param fromMon
	 * @param toMon
	 * @param fromYear
	 * @param toYear
	 * @return
	 */
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
	 * fetchIncentiveDetails(String agentCd, String fromMon, String toMon,
	 * String fromYear, String toYear) { List lstResult = null; try { if
	 * (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchIncentiveDetails Method"); } Session
	 * session = transactionManager.getSessionFactory().getCurrentSession();
	 * Transaction transaction = session.getTransaction(); if
	 * (!transaction.isActive()) { session.beginTransaction(); }
	 * 
	 * 
	 * String sql =
	 * "select sum(incentiveamt), paydate, payMode, paystat, to_char(paydate, 'Mon, YYYY') period from dif_incentive_details "
	 * + "where agentcode = '"+agentCd+"' " +
	 * "and Extract(year from paydate) between '"+fromYear+"' and '"+toYear+"' "
	 * +
	 * "and Extract(month from paydate) between '"+fromMon+"' and '"+toMon+"' "
	 * + "group by paydate,payMode,paystat";
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchIncentiveDetails Method sql-- "+ sql); }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * 
	 * lstResult = query.list();
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService.fetchIncentiveDetails Method lstResult--"+
	 * lstResult); }
	 * 
	 * } catch (Exception e) { logger.error("::::::Error in lstResult ::::::",
	 * e); e.printStackTrace(); }
	 * 
	 * return lstResult; }
	 *//**
	 * @param agentCd
	 * @param fromMon
	 * @param toMon
	 * @param fromYear
	 * @param toYear
	 * @return
	 */
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
	 * fetchCommIncentiveDetails(String agentCd, String fromMon, String toMon,
	 * String fromYear, String toYear) { List lstResult = null; try { if
	 * (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchCommIncentiveDetails Method"); } Session
	 * session = transactionManager.getSessionFactory().getCurrentSession();
	 * Transaction transaction = session.getTransaction(); if
	 * (!transaction.isActive()) { session.beginTransaction(); }
	 * 
	 * 
	 * String sql =
	 * "select sum(commamt) comm_amt, commdate, to_char(commdate, 'Mon, YYYY') period, commType, 'C', paytype "
	 * + "  from dif_commission_details where agentcode = '"+agentCd+"' " +
	 * "and Extract(year from paydate) between '"+fromYear+"' and '"+toYear+"' "
	 * +
	 * "and Extract(month from paydate) between '"+fromMon+"' and '"+toMon+"' "
	 * + "group by commType,commdate,paytype " + "union " +
	 * "select sum(incentiveamt),calcdate, to_char(calcdate, 'Mon, YYYY') period, 'Incentive', 'I', paytype "
	 * + "from dif_incentive_details " + "where agentcode = '"+agentCd+"' " +
	 * "and Extract(year from paydate) between '"+fromYear+"' and '"+toYear+"' "
	 * +
	 * "and Extract(month from paydate) between '"+fromMon+"' and '"+toMon+"' "
	 * + "group by calcdate, paytype " + "order by period";
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchCommIncentiveDetails Method sql-- "+
	 * sql); }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * 
	 * lstResult = query.list();
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService.fetchCommIncentiveDetails Method lstResult--"
	 * + lstResult); }
	 * 
	 * } catch (Exception e) { logger.error("::::::Error in lstResult ::::::",
	 * e); e.printStackTrace(); }
	 * 
	 * return lstResult; }
	 *//**
	 * @param className
	 * @param orderBy
	 * @return
	 */
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
	 * getAllRecords(String className, String orderBy) {
	 * 
	 * if(logger.isDebugEnabled()){
	 * logger.debug("In DBService.getAllRecords Method"); } List retList = null;
	 * try{ Class classInstance = Class.forName(className); Session session =
	 * transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if(!transaction.isActive()){
	 * session.beginTransaction(); } Criteria criteria =
	 * session.createCriteria(classInstance);
	 * 
	 * //criteria.add(Restrictions.eq("updatedby", "Null"));
	 * criteria.addOrder(Order.desc(orderBy)); retList = criteria.list();
	 * 
	 * 
	 * session.close(); }catch(Exception e){
	 * logger.error("::::::Error in getAllRecords ::::::", e);
	 * e.printStackTrace();
	 * logger.error("::::::Returning zero empty list from getAllRecords ::::::"
	 * ); retList = new ArrayList(); }
	 * 
	 * if(logger.isDebugEnabled()){
	 * logger.debug("Out DBService.getAllRecords Method"); } return retList; }
	 *//**
	 * @param className
	 * @param paramName
	 * @param paramValue
	 * @param orderBy
	 * @return
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	/*
	 * @SuppressWarnings("rawtypes") public List fetchRecordOrderBy(String
	 * className, String paramName,Object paramValue,String orderBy) throws
	 * ClassNotFoundException, InstantiationException, IllegalAccessException{
	 * if(logger.isDebugEnabled()){
	 * logger.debug("In DBService.fetchRecord Method"); } List retList = null;
	 * Class classInstance = Class.forName(className); Session session =
	 * transactionManager.getSessionFactory().getCurrentSession(); Transaction
	 * transaction = session.getTransaction(); if(!transaction.isActive()){
	 * session.beginTransaction(); } Criteria criteria =
	 * session.createCriteria(classInstance);
	 * criteria.add(Restrictions.eq(paramName, paramValue));
	 * criteria.addOrder(Order.asc(orderBy)); try{ retList = criteria.list();
	 * }catch(Exception e){ logger.error("::::::Error in fetchRecord ::::::",
	 * e); e.printStackTrace();
	 * logger.error("::::::Returning zero empty list from fetchRecord ::::::");
	 * retList = new ArrayList(); } session.close();
	 * if(logger.isDebugEnabled()){
	 * logger.debug("Out DBService.fetchRecord Method"); } return retList; }
	 *//**
	 * @param agentCd
	 * @param fromMon
	 * @param toMon
	 * @param fromYear
	 * @param toYear
	 * @return
	 */
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" }) public List
	 * fetchIncentiveKpiDetails(String agentCd, String fromMon, String toMon,
	 * String fromYear, String toYear) { List lstResult = null; try { if
	 * (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchIncentiveKpiDetails Method"); } Session
	 * session = transactionManager.getSessionFactory().getCurrentSession();
	 * Transaction transaction = session.getTransaction(); if
	 * (!transaction.isActive()) { session.beginTransaction(); }
	 * 
	 * 
	 * String sql =
	 * "select sum(incentiveamt) incentive, incentivetype, incentivename from dif_incentive_details "
	 * + "where agentcode = '"+agentCd+"' " +
	 * "and Extract(year from paydate) between '"+fromYear+"' and '"+toYear+"' "
	 * +
	 * "and Extract(month from paydate) between '"+fromMon+"' and '"+toMon+"' "
	 * + "group by incentivetype, incentivename";
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("In DBService.fetchIncentiveKpiDetails Method sql-- "+ sql);
	 * }
	 * 
	 * SQLQuery query = session.createSQLQuery(sql);
	 * 
	 * lstResult = query.list();
	 * 
	 * if (logger.isDebugEnabled()) {
	 * logger.debug("Out DBService.fetchIncentiveKpiDetails Method lstResult--"+
	 * lstResult); }
	 * 
	 * } catch (Exception e) { logger.error("::::::Error in lstResult ::::::",
	 * e); e.printStackTrace(); }
	 * 
	 * return lstResult; }
	 */

	@SuppressWarnings({ "rawtypes", "unused", "unchecked" })
	public ArrayList getPremiumPA(String classname,
			CalculatorPARequest clacpareq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		logger.info("Inside DBService :: getPremiumPA method :: Execution Started :- ");
		List lstResult = null;
		double dprmamt = 0.0, ab = 0.0;
		int check = 0, premaddon = 0;
		String abc = "";
		StringBuilder buildQuery = new StringBuilder();
		ArrayList arr = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		ObjectMapper obj = new ObjectMapper(); // Added for oracle migration
		try {
			Class classInstance = Class.forName(classname);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			logger.info("Inside getPremiumPA CalculatorPARequest details :: "
					+ obj.writeValueAsString(clacpareq));
			buildQuery.append("select npremium");

			// buildQuery.append(" from dcf_master.dcf_pa_prm where "); //
			// Commented for oracle migration
			buildQuery.append(" from dcf_pa_prm where "); // Added for oracle
															// migration

			if (clacpareq.getProductcd() != null
					&& clacpareq.getProductcd() != "" && check == 0) {
				check = 1;
				buildQuery.append("strprodcd = :productcd ");
			} else if (clacpareq.getProductcd() != null
					&& clacpareq.getProductcd() != "" && check == 1) {
				buildQuery.append("and strprodcd = :productcd ");
			}

			if (clacpareq.getInsuranceFor() != null
					&& clacpareq.getInsuranceFor() != "" && check == 0) {
				check = 1;
				buildQuery.append("strcovertype = :insurancefor ");
			} else if (clacpareq.getInsuranceFor() != null
					&& clacpareq.getInsuranceFor() != "" && check == 1) {
				buildQuery.append("and strcovertype = :insurancefor ");
			}

			if (clacpareq.getPlantype() != null
					&& clacpareq.getPlantype() != "" && check == 0) {
				check = 1;
				buildQuery.append("strplan = :plantype ");
			} else if (clacpareq.getPlantype() != null
					&& clacpareq.getPlantype() != "" && check == 1) {
				buildQuery.append("and strplan = :plantype ");
			}

			if (clacpareq.getSumAssured() != null
					&& clacpareq.getSumAssured() != "" && check == 0) {
				check = 1;
				buildQuery.append("nsa = :sumassured ");
			} else if (clacpareq.getSumAssured() != null
					&& clacpareq.getSumAssured() != "" && check == 1) {
				buildQuery.append("and nsa = :sumassured ");
			}

			if (clacpareq.getTenure() != null && clacpareq.getTenure() != ""
					&& check == 0) {
				check = 1;
				buildQuery.append("ntenure = :tenure ");
			} else if (clacpareq.getTenure() != null
					&& clacpareq.getTenure() != "" && check == 1) {
				buildQuery.append("and ntenure = :tenure ");
			}

			if (clacpareq.getFamilySize() != null
					&& !(clacpareq.getFamilySize().equals("")) && check == 0) {
				check = 1;
				buildQuery.append("strfamilysize = :familysize ");
			} else if (clacpareq.getFamilySize() != null
					&& !(clacpareq.getFamilySize().equals("")) && check == 1) {
				buildQuery.append("and strfamilysize = :familysize ");
			}

			if (clacpareq.getBenperMonth() != null
					&& clacpareq.getBenperMonth() != "" && check == 0) {
				check = 1;
				buildQuery.append("nbenefitpermonth = :benpermonth ");
			} else if (clacpareq.getBenperMonth() != null
					&& clacpareq.getBenperMonth() != "" && check == 1) {
				buildQuery.append("and nbenefitpermonth = :benpermonth ");
			}

			if (clacpareq.getPayPeriod() != null
					&& !(clacpareq.getPayPeriod().equals("")) && check == 0) {
				check = 1;
				buildQuery.append("nnoofmonths = :payperiod ");
			} else if (clacpareq.getPayPeriod() != null
					&& !(clacpareq.getPayPeriod().equals("")) && check == 1) {
				buildQuery.append("and nnoofmonths = :payperiod ");
			}

			logger.info("Inside DBService :: getPremiumPA method :: buildQuery.toString() : "
					+ buildQuery.toString());

			Query query = (Query) session.createSQLQuery(buildQuery.toString())
					.addScalar("npremium", StandardBasicTypes.DOUBLE); // Added
																		// for
																		// oracle
																		// migration
			if (clacpareq.getProductcd() != null
					&& clacpareq.getProductcd() != "") {
				query.setParameter("productcd", clacpareq.getProductcd());
			}
			if (clacpareq.getInsuranceFor() != null
					&& clacpareq.getInsuranceFor() != "") {
				query.setParameter("insurancefor", clacpareq.getInsuranceFor());
			}
			if (clacpareq.getPlantype() != null
					&& clacpareq.getPlantype() != "") {
				query.setParameter("plantype", clacpareq.getPlantype());
			}
			if (clacpareq.getSumAssured() != null
					&& clacpareq.getSumAssured() != "") {
				query.setParameter("sumassured",
						Integer.parseInt(clacpareq.getSumAssured()));
			}
			if (clacpareq.getTenure() != null && clacpareq.getTenure() != "") {
				query.setParameter("tenure",
						Integer.parseInt(clacpareq.getTenure()));
			}
			if (clacpareq.getFamilySize() != null
					&& !(clacpareq.getFamilySize().equals(""))) {
				query.setParameter("familysize", clacpareq.getFamilySize() + "");
			}
			if (clacpareq.getBenperMonth() != null
					&& clacpareq.getBenperMonth() != "") {
				query.setParameter("benpermonth",
						Integer.parseInt(clacpareq.getBenperMonth()));
			}
			if (clacpareq.getPayPeriod() != null
					&& !(clacpareq.getPayPeriod().equals(""))) {
				query.setParameter("payperiod", clacpareq.getPayPeriod());
			}

			List retList = query.list();
			logger.info("Inside DBService :: getPremiumPA method :: Size Of list : "
					+ retList.size());
			// commented to resolve issue when multiple rows returned in filter
			// criteria

			/*
			 * for(Iterator it=retList.iterator();it.hasNext();) { dprmamt =
			 * (double) it.next(); }
			 */

			if (retList != null) {
				Object lst = retList.get(0);

				dprmamt = (double) lst;
			}

			/*
			 * for (int i = 0; i < retList.size(); i++) { CalculatorPARequest cr
			 * = (CalculatorPARequest) retList.get(i);
			 * System.out.println(cr.getNpremium()); }
			 */

			// System.out.println("Hello 3"+criteria.getClass().);
			// if(clacpareq.getProductcd()== "AGRD")
			// {
			// criteria.add(Restrictions.eq("strplan",
			// clacpareq.getPlantype()));
			// criteria.add(Restrictions.eq("nsa", clacpareq.getSumAssured()));
			// String sql =
			// "select npremium from dif_PA_prm  where strprodcd = 'AGRD' and strplan = '1' and nsa = 500000 and strcovertype = '1' ";

			// dprmamt = (Double)
			// session.createQuery("select npremium from PAPremium  where strprodcd = 'AGRD' and strplan = '1' and nsa = 500000 and strcovertype = '1'").uniqueResult();

			// SQLQuery query = session.createSQLQuery(sql);
			// lstResult = query.list();

			// }
			// System.out.println(dprmamt + " " + premaddon);
			arr.add(dprmamt);
			logger.info("Inside getPremiumPA of Object Details ::" + arr); // Added
																			// for
																			// oracle
																			// migration
			logger.info("Inside getPremiumPA of List Object Details ::"
					+ retList); // Added for oracle migration
			transaction.commit();
			return arr;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getPremiumPA method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getPremiumPA method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		logger.info("Inside DBService :: getPremiumPA method :: Execution Completed Successfully");
		return arr;
	}

	/*
	 * this method returns product code and product name
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getProduct(String className,
			String paramName, String arg) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List pdList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getProduct Method"); }
			 */

			logger.info("Inside DBService :: getProduct method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq(paramName, arg)).addOrder(
					Order.desc("strprodcd"));

			pdList = criteria.list();

			/*
			 * for (Iterator iterator = pdList.iterator(); iterator.hasNext();)
			 * { Product pd1 = (Product)iterator.next(); }
			 */

			logger.info("Inside DBService :: getProduct method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getProduct Method"); }
			 */
			transaction.commit();
			return pdList;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getProduct method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getProduct method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return pdList;
	}

	/*
	 * this method returns product code and product name
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getCountry(String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<Country> countryList = new ArrayList<Country>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getCountry Method"); }
			 */

			logger.info("Inside DBService :: getCountry method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			countryList = session.createQuery("from Country").list();

			/*
			 * for (Iterator iterator = countryList.iterator();
			 * iterator.hasNext();) { Country country1 =
			 * (Country)iterator.next();
			 * 
			 * //System.out.println("test............"+country1.getStrcountrycd()
			 * ); }
			 */

			logger.info("Inside DBService :: getCountry method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getCountry Method"); }
			 */
			transaction.commit();
			return countryList;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getCountry method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getCountry method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return countryList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getState(String className, String paramName,
			String countrycd) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List stList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getState Method"); }
			 */

			logger.info("Inside DBService :: getState method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq(paramName, countrycd));

			stList = criteria.list();

			// List<ParameterDetailList> query =
			// session.createQuery("from Company").list();

			if (stList.size() > 0) {

				/*
				 * for (Iterator iterator = stList.iterator();
				 * iterator.hasNext();) { State st1 = (State)iterator.next(); }
				 */

			}

			logger.info("Inside DBService :: getState method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getList Method"); }
			 */
			transaction.commit();
			return stList;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getState method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getState method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return stList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getList(String className, String paramName,
			Object paramValue) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List retList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getList Method"); }
			 */

			logger.info("Inside DBService :: getList(String, String, Object) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.and(
					Restrictions.eq(paramName, paramValue),
					Restrictions.eq("nisactive", 1)));

			retList = criteria.list();

			logger.info("Inside DBService :: getList(String, String, Object) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getList Method"); }
			 */
			transaction.commit();
			return retList;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getState method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getState method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return retList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> get(String className, String paramName,
			String code) throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List retList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.get Method"); }
			 */

			logger.info("Inside DBService :: get(String, String, String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			int paramval = 1;

			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			if (code != null && code.equalsIgnoreCase("sys")) {
				paramval = 1;
			} else if (code != null && code.equalsIgnoreCase("usr")) {
				paramval = 2;
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq(paramName, paramval));
			retList = criteria.list();

			// System.out.println("result list:--"+retList.toString());
			logger.info("Inside DBService :: get(String, String, String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.get Method"); }
			 */
			transaction.commit();
			return retList;
		} catch (Exception e) {

			// logger.info("Inside DBService :: get(String, String, String) method :: Exception Occurred..."+e);
			logger.error(
					"Inside DBService :: get(String, String, String) method :: Exception Occurred...",
					e);
			e.printStackTrace();
			transaction.rollback();
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return retList;
	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getCity(String className, String stateParam,
			String stid, String mapParam, String type, String parentParam,
			String parentID) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List ctList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getCity Method"); }
			 */

			logger.info("Inside DBService :: getCity(String, String, String, String, String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			if (type != null && type.equalsIgnoreCase("D"))
				criteria.add(Restrictions.and(
						Restrictions.eq(stateParam, stid),
						Restrictions.eq(mapParam, type)));
			else if (type != null && type.equalsIgnoreCase("C"))
				criteria.add(Restrictions.and(
						Restrictions.eq(stateParam, stid), Restrictions.eq(
								mapParam, type), Restrictions.eq(parentParam,
								Integer.parseInt(parentID))));
			ctList = criteria.list();

			/*
			 * for (Iterator iterator = ctList.iterator(); iterator.hasNext();)
			 * { City city = (City)iterator.next();
			 * 
			 * //System.out.println("test............"+city.getStrcitycd()); }
			 */

			logger.info("Inside DBService :: getCity(String, String, String, String, String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getCountry Method"); }
			 */
			transaction.commit();
			return ctList;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getCity method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getCity method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return ctList;
	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getManufact(String className, String arg)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<Manufact> manufactList = new ArrayList<Manufact>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getManufact Method"); }
			 */

			logger.info("Inside DBService :: getManufact(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// manufactList =
			// session.createQuery("FROM Manufact m WHERE m.strvehiclecatcd = '"+arg+"' ORDER BY m.strmanufacturername ASC").list();
			// //Commented For VAPT on 6th April 2017 - Ketan
			Query manufactQuery = session
					.createQuery("FROM Manufact m WHERE m.strvehiclecatcd = :argument ORDER BY m.strmanufacturername ASC"); // Added
																															// For
																															// VAPT
																															// on
																															// 6th
																															// April
																															// 2017
																															// -
																															// Ketan
			manufactQuery.setParameter("argument", arg); // Added For VAPT on
															// 6th April 2017 -
															// Ketan

			manufactList = manufactQuery.list(); // Added For VAPT on 6th April
													// 2017 - Ketan

			/*
			 * for (Iterator iterator = manufactList.iterator();
			 * iterator.hasNext();) { Manufact manuf =
			 * (Manufact)iterator.next();
			 * 
			 * //System.out.println("test............"+city.getStrcitycd()); }
			 */

			logger.info("Inside DBService :: getManufact(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getCountry Method"); }
			 */
			transaction.commit();
			return manufactList;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: get(String, String, String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: get(String, String, String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return manufactList;
	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getModelInfo(String className,
			ModelRequest modelreq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List<Model> lstResult = new ArrayList<Model>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getModelInfo Method"); }
			 */

			logger.info("Inside DBService :: getModelInfo method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			String strmanufacturercd = "";
			String strprodcd = "";

			strmanufacturercd = modelreq.getStrmanufacturercd();
			strprodcd = modelreq.getStrprodcd();

			/*
			 * String sql =
			 * "select distinct strmodelnumber from dcf_master.dcf_vehicle_model_variant_m where 1= 1 and strmanufacturercd = '"
			 * +strmanufacturercd+"' and nvehiclemodelstatus = 1 and (CASE '"+
			 * strprodcd+
			 * "' when '3121' then strsegmenttype in ('Compact', 'High End', 'Mid Size', 'Mini', 'MPV SUV') when '3122' then strsegmenttype in ('Moped', 'MOTOR CYCLE', 'Scooter') when '3124' then strsegmenttype in ('Commercial Vehicle')END) and strvariant  not in ( '-','--') order by 1"
			 * ;
			 */
			// String sql =
			// "select distinct strmodelnumber, strmodelcd from dcf_master.dcf_vehicle_model_variant_m where 1= 1 and strmanufacturercd = '"+strmanufacturercd+"' and nlevel = 0 and nvehiclemodelstatus = 1 and strvariant  not in ( '-','--') order by 1";
			// //Commented For VAPT On 6th April 2017 - Ketan

			// START : ADDED FOR ORACLE MIGRATION

			/*
			 * Query modelInfoQuery = session.createSQLQuery(
			 * "select distinct strmodelnumber, strmodelcd from dcf_vehicle_model_variant_m where strmanufacturercd = :manufactcd and nlevel = :level and nvehiclemodelstatus = :vehiclemodelstatus and (strvariant  not in ( '-','--') or strvariant is null) order by 1"
			 * );
			 */

			Query modelInfoQuery = session
					.createSQLQuery(
							"select distinct strmodelnumber, strmodelcd from dcf_vehicle_model_variant_m where strmanufacturercd = :manufactcd and nlevel = :level and nvehiclemodelstatus = :vehiclemodelstatus and (strvariant  not in ( '-','--') or strvariant is null) order by 1")
					.addScalar("strmodelnumber", StandardBasicTypes.STRING)
					.addScalar("strmodelcd", StandardBasicTypes.STRING);

			// for
			// END : ADDED FOR ORACLE MIGRATION // oracle
			modelInfoQuery.setParameter("manufactcd", strmanufacturercd); // Added
																			// For
																			// VAPT
																			// On
																			// 6th
																			// April
																			// 2017
																			// -
																			// Ketan
			modelInfoQuery.setParameter("level", 0); // Added For VAPT On 6th
														// April 2017 - Ketan
			modelInfoQuery.setParameter("vehiclemodelstatus", 1); // Added For
																	// VAPT On
																	// 6th April
																	// 2017 -
																	// Ketan

			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("In DBService.getchAgentCode Method sql-- "+
			 * modelInfoQuery); }
			 */

			// SQLQuery query = session.createSQLQuery(sql); //Commented For
			// VAPT On 6th April 2017 - Ketan

			// lstResult =(List<Model>)
			// query.setResultTransformer(Transformers.aliasToBean(Model.class)).list();
			// //Commented For VAPT On 6th April 2017 - Ketan
			lstResult = (List<Model>) modelInfoQuery.setResultTransformer(
					Transformers.aliasToBean(Model.class)).list(); // Added For
																	// VAPT On
																	// 6th April
																	// 2017 -
																	// Ketan

			logger.info("Inside DBService :: getModelInfo method :: Execution Completed Successfully");
			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("DBService :: getModelInfo--"+ lstResult); }
			 */
			transaction.commit();
		} catch (Exception e) {
			logger.error(
					"Inside DBService :: getModelInfo method :: Exception Occurred...",
					e);
			transaction.rollback();
			// logger.info("Inside DBService :: getModelInfo method :: Exception Occurred..."+e);

		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return lstResult;
	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getVarInfo(String className,
			VehicleVariantRequest varreq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List<Model> lstResult = new ArrayList<Model>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getVarInfo Method"); }
			 */

			logger.info("Inside DBService :: getVarInfo(String, String, String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			String strmanufacturercd = "";
			String strprodcd = "";
			String strmodelnumber = "";

			strmanufacturercd = varreq.getStrmanufacturercd();
			strprodcd = varreq.getStrprodcd();
			strmodelnumber = varreq.getStrmodelnumber();
			/*
			 * Criteria criteria = session.createCriteria(classInstance);
			 * criteria.add(Restrictions.eq(paramName,paramValue));
			 */
			// List vrList = criteria.list();
			// String sql =
			// "select v.strmodelcd,v.strvariant,v.strfuel,fuel.strcddesc as strfueldesc,v.strbodytypecd,bodytype.strcddesc as strbodytypedesc,v.nvehicleclasscd,v.ncubiccapacity,v.nseatingcapacity,v.ncarryingcapacity,v.strvehicletype,v.strsegmenttype, v.ngrossvehicleweight from dcf_master.dcf_vehicle_model_variant_m v ,dcf_master.dcf_param_system_m fuel ,dcf_master.dcf_param_system_m bodytype where v.strfuel = fuel.strparamcd and fuel.nparamtypecd = 1025 and v.strbodytypecd = bodytype.strparamcd and bodytype.nparamtypecd = 1046 and v.strmanufacturercd = '"+strmanufacturercd+"' and v.nvehiclemodelstatus = 1 and (CASE '"+strprodcd+"' when '3121' then v.strsegmenttype in ('Compact', 'High End', 'Mid Size', 'Mini', 'MPV SUV') when '3122' then v.strsegmenttype in ('Moped', 'MOTOR CYCLE', 'Scooter') when '3124' then v.strsegmenttype in ('Commercial Vehicle') END) and v.strvariant  not in ( '-','--') and v.strmodelnumber = '"+strmodelnumber+"' order by 1";
			/*
			 * String sql =
			 * "select v.strmodelcd,v.strvariant,v.strfuel,fuel.strcddesc as strfueldesc,v.strbodytypecd,bodytype.strcddesc as strbodytypedesc,v.nvehicleclasscd,v.ncubiccapacity,v.nseatingcapacity,v.ncarryingcapacity,v.strvehicletype,v.strsegmenttype, v.ngrossvehicleweight from dcf_master.dcf_vehicle_model_variant_m v ,dcf_master.dcf_param_system_m fuel ,dcf_master.dcf_param_system_m bodytype where v.strfuel = fuel.strparamcd and fuel.nparamtypecd = 1025 and v.strbodytypecd = bodytype.strparamcd and bodytype.nparamtypecd = 1046 and v.strmanufacturercd = '"
			 * +strmanufacturercd+"' and v.nvehiclemodelstatus = 1 and (CASE '"+
			 * strprodcd+
			 * "' when '3121' then v.strsegmenttype in ('Compact', 'High End', 'Mid Size', 'Mini', 'MPV SUV') when '3122' then v.strsegmenttype in ('Moped', 'MOTOR CYCLE', 'Scooter') when '3124' then v.strsegmenttype in ('Commercial Vehicle') END) and v.strvariant  not in ( '-','--') and v.strmodelnumber = '"
			 * +strmodelnumber+"' and v.nlevel=1 order by 1";
			 */
			// String sql =
			// "select v.strmodelcd,v.strvariant,v.strfuel,fuel.strcddesc as strfueldesc,v.strbodytypecd,bodytype.strcddesc as strbodytypedesc,v.nvehicleclasscd,v.ncubiccapacity,v.nseatingcapacity,v.ncarryingcapacity,v.strvehicletype,v.strsegmenttype, v.ngrossvehicleweight from dcf_master.dcf_vehicle_model_variant_m v ,dcf_master.dcf_param_system_m fuel ,dcf_master.dcf_param_system_m bodytype where v.strfuel = fuel.strparamcd and fuel.nparamtypecd = 1025 and v.strbodytypecd = bodytype.strparamcd and bodytype.nparamtypecd = 1046 and v.strmanufacturercd = '"+strmanufacturercd+"' and v.nvehiclemodelstatus = 1 and v.strvariant  not in ( '-','--') and v.strmodelnumber = '"+strmodelnumber+"' and v.nlevel=1 order by 1";
			// //Commented For VAPT On 6th April 2017 - Ketan
			// START : ADDED FOR ORACLE MIGRATION

			// Query variantQuery =
			// session.createSQLQuery("select v.strmodelcd,v.strvariant,v.strfuel,fuel.strcddesc as strfueldesc,v.strbodytypecd,bodytype.strcddesc as strbodytypedesc,v.nvehicleclasscd,v.ncubiccapacity,v.nseatingcapacity,v.ncarryingcapacity,v.strvehicletype,v.strsegmenttype, v.ngrossvehicleweight from dcf_master.dcf_vehicle_model_variant_m v ,dcf_master.dcf_param_system_m fuel ,dcf_master.dcf_param_system_m bodytype where v.strfuel = fuel.strparamcd and fuel.nparamtypecd = :nparamtypecd1 and v.strbodytypecd = bodytype.strparamcd and bodytype.nparamtypecd = :nparamtypecd2 and v.strmanufacturercd = :manufactcd and v.nvehiclemodelstatus = :vehiclemodelstatus and v.strvariant  not in ( '-','--') and v.strmodelnumber = :modelnum and v.nlevel=:level order by 1");
			// //Added For VAPT On 6th April 2017 - Ketan // Commented for
			// oracle migration

			Query variantQuery = session
					.createSQLQuery(
							"select v.strmodelcd,v.strvariant,v.strfuel,fuel.strcddesc as strfueldesc,v.strbodytypecd,bodytype.strcddesc as "
									+ "strbodytypedesc,v.nvehicleclasscd,v.ncubiccapacity,v.nseatingcapacity,v.ncarryingcapacity,v.strvehicletype,v.strsegmenttype, "
									+ "v.ngrossvehicleweight from dcf_vehicle_model_variant_m v ,dcf_param_system_m fuel ,dcf_param_system_m bodytype where "
									+ "v.strfuel = fuel.strparamcd and fuel.nparamtypecd = :nparamtypecd1 and v.strbodytypecd = bodytype.strparamcd and "
									+ "bodytype.nparamtypecd = :nparamtypecd2 and v.strmanufacturercd = :manufactcd and v.nvehiclemodelstatus = :vehiclemodelstatus "
									+ "and v.strmodelnumber = :modelnum and v.nlevel=:level order by 1")

					.addScalar("strmodelcd", StandardBasicTypes.STRING)
					.addScalar("strvariant", StandardBasicTypes.STRING)
					.addScalar("strfuel", StandardBasicTypes.STRING)
					.addScalar("strbodytypecd", StandardBasicTypes.STRING)
					.addScalar("nvehicleclasscd",
							StandardBasicTypes.BIG_DECIMAL)
					.addScalar("ncubiccapacity", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("nseatingcapacity",
							StandardBasicTypes.BIG_DECIMAL)
					.addScalar("ncarryingcapacity",
							StandardBasicTypes.BIG_DECIMAL)
					.addScalar("strvehicletype", StandardBasicTypes.STRING)
					.addScalar("strsegmenttype", StandardBasicTypes.STRING)
					.addScalar("ngrossvehicleweight",
							StandardBasicTypes.BIG_DECIMAL)
					.addScalar("strfueldesc", StandardBasicTypes.STRING)
					.addScalar("strbodytypedesc", StandardBasicTypes.STRING);

			// END : ADDED FOR ORACLE MIGRATION
			variantQuery.setParameter("manufactcd", strmanufacturercd); // Added
																		// For
																		// VAPT
																		// On
																		// 6th
																		// April
																		// 2017
																		// -
																		// Ketan
			variantQuery.setParameter("modelnum", strmodelnumber); // Added For
																	// VAPT On
																	// 6th April
																	// 2017 -
																	// Ketan
			variantQuery.setParameter("nparamtypecd1", 1025); // Added For VAPT
																// On 6th April
																// 2017 - Ketan
			variantQuery.setParameter("nparamtypecd2", 1046); // Added For VAPT
																// On 6th April
																// 2017 - Ketan
			variantQuery.setParameter("vehiclemodelstatus", 1); // Added For
																// VAPT On 6th
																// April 2017 -
																// Ketan
			variantQuery.setParameter("level", 1); // Added For VAPT On 6th
													// April 2017

			// SQLQuery query = session.createSQLQuery(sql);
			// lstResult =(List<Model>)
			// query.setResultTransformer(Transformers.aliasToBean(Model.class)).list();
			// //Commented For VAPT On 6th April 2017 - Ketan
			lstResult = (List<Model>) variantQuery.setResultTransformer(
					Transformers.aliasToBean(Model.class)).list(); // Added For
																	// VAPT On
																	// 6th April
																	// 2017 -
																	// Ketan

			logger.info("Inside DBService :: getVarInfo(String, String, String) method :: Execution Completed Successfully");
			transaction.commit();
			return lstResult;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getVarInfo(String, String, String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getVarInfo(String, String, String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return lstResult;
	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getVehicleClass(String className,
			String paramName, String paramValue) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List vehclList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getVehicleClass Method"); }
			 */

			logger.info("Inside DBService :: getVehicleClass(String, String, String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq(paramName, paramValue));

			vehclList = criteria.list();

			logger.info("Inside DBService :: getVehicleClass(String, String, String) method :: Execution Completed Successfully");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getVehicleClass(String, String, String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getVehicleClass(String, String, String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return vehclList;
	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getVehicleSubClass(String className,
			String paramName, String paramValue) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List vehsbclList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getVehicleSubClass Method"); }
			 */

			logger.info("Inside DBService :: getVehicleSubClass(String, String, String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq(paramName, paramValue));

			vehsbclList = criteria.list();

			logger.info("Inside DBService :: getVehicleSubClass(String, String, String) method :: Execution Completed Successfully");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getVehicleSubClass(String, String, String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getVehicleSubClass(String, String, String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return vehsbclList;
	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getRTOLocation(String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<RTOLocation> rtoList = new ArrayList<RTOLocation>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getRTOLocation Method"); }
			 */

			logger.info("Inside DBService :: getRTOLocation(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// rtoList = session.createQuery("from RTOLocation").list();
			// //Commented As Per Issue Raised On 08/05/2017 12:54PM
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("strstatus",
					CommonConstants.RECORD_STATUS_ACTIVE)); // Added As Per
															// Issue Raised On
															// 08/05/2017
															// 12:54PM

			rtoList = criteria.list(); // Added As Per Issue Raised On
										// 08/05/2017 12:54PM

			/*
			 * for (Iterator iterator = rtoList.iterator(); iterator.hasNext();)
			 * { RTOLocation rtof = (RTOLocation)iterator.next();
			 * 
			 * //System.out.println("test............"+city.getStrcitycd()); }
			 */

			logger.info("Inside DBService :: getRTOLocation(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getRTOLocation Method"); }
			 */
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getRTOLocation(String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getRTOLocation(String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return rtoList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getPinCodeInfo(String className,
			PinCodeRequest pincdreq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {

		Session session = null;
		Transaction transaction = null;
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.getPinCodeInfo Method"); }
		 */
		List retList = null;
		List lstResult = null;
		int pincd = 0;
		logger.info("Inside DBService :: getPinCodeInfo(String, PinCodeRequest) method :: Execution Started");
		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);

			pincd = Integer.parseInt(pincdreq.getNpincode().toString());

			if (pincd != 999999) {
				criteria.add(Restrictions.eq("npincode", pincd));
				retList = criteria.list();
			} else {
				criteria.add(Restrictions.eq("npincode", 0));
				retList = criteria.list();
			}

			logger.info("Inside DBService :: getPinCodeInfo(String, PinCodeRequest) method :: Execution Completed Successfully");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getPinCodeInfo(String, PinCodeRequest) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getPinCodeInfo(String, PinCodeRequest) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return retList;
	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getCountryNameByCode(String className, String paramName)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		Session session = null;
		Transaction transaction = null;
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.getCountryByCode Method"); }
		 */
		String countryName = "";
		Country md1 = null;
		List countryList = new ArrayList();
		logger.info("Inside DBService :: getCountryByCode(String, String) method :: Execution Started");
		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("strcountrycd", paramName));

			countryList = criteria.list();

			for (Iterator iterator = countryList.iterator(); iterator.hasNext();) {
				md1 = (Country) iterator.next();

			}
			if (countryList.size() > 0) {
				countryName = md1.getStrcountryname();
			}
			logger.info("Inside DBService :: getCountryByCode(String, String) method :: Execution Completed Successfully");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getCountryByCode(String, String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getCountryByCode(String, String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return countryName;
	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getStateNameByCode(String className, String paramName)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		Session session = null;
		Transaction transaction = null;
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.getStateNameByCode Method"); }
		 */
		String stateName = "";
		State md1 = null;
		List stateList = new ArrayList();
		logger.info("Inside DBService :: getStateNameByCode(String, String) method :: Execution Started");

		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("strstatecd", paramName));

			stateList = criteria.list();

			for (Iterator iterator = stateList.iterator(); iterator.hasNext();) {
				md1 = (State) iterator.next();

			}
			if (stateList.size() > 0) {
				stateName = md1.getStrstatename();
			}
			logger.info("Inside DBService :: getStateNameByCode(String, String) method :: Execution Completed Successfully");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getStateNameByCode(String, String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getStateNameByCode(String, String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return stateName;
	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getCityNameByCode(String className, String paramName,
			String type) throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		Session session = null;
		Transaction transaction = null;
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.getCityNameByCode Method"); }
		 */
		String cityName = "";
		City md1 = null;
		List cityList = new ArrayList();
		logger.info("Inside DBService :: getCityNameByCode(String, String) method :: Execution Started");

		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.and(
					Restrictions.eq("strcitycd", paramName),
					Restrictions.eq("ndistrictcityflag", type)));

			cityList = criteria.list();

			for (Iterator iterator = cityList.iterator(); iterator.hasNext();) {
				md1 = (City) iterator.next();

			}

			if (cityList.size() > 0) {
				cityName = md1.getStrcityname();
			}
			logger.info("Inside DBService :: getCityNameByCode(String, String) method :: Execution Completed Successfully");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getCityNameByCode(String, String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getCityNameByCode(String, String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return cityName;
	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getDistrictNameByCode(String className, String paramName,
			String type) throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		Session session = null;
		Transaction transaction = null;
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.getDistrictNameByCode Method"); }
		 */
		String distName = "";
		City md2 = null;
		List distList = new ArrayList();
		logger.info("Inside DBService :: getDistrictNameByCode(String, String) method :: Execution Started");

		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.and(
					Restrictions.eq("strcitycd", paramName),
					Restrictions.eq("ndistrictcityflag", type)));

			distList = criteria.list();

			for (Iterator iterator = distList.iterator(); iterator.hasNext();) {
				md2 = (City) iterator.next();

			}

			if (distList.size() > 0) {
				distName = md2.getStrcityname();
			}

			logger.info("Inside DBService :: getDistrictNameByCode(String, String) method :: Execution Completed Successfully");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getDistrictNameByCode(String, String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getDistrictNameByCode(String, String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return distName;

	}

	/*
	 * This Method Returns Parameters From dcf_interface_m table depending on
	 * strinterfaceid
	 */
	public String getWSDLURL(String interfaceid, String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		String wsdlUrl = "";
		List retList = null;
		InterfaceParam infcParam = new InterfaceParam();
		Session session = null;
		Transaction transaction = null;
		// Session session = null;
		// Transaction transaction = null;
		try {
			// System.out.println("interfaceid :: "+interfaceid);
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("strinterfaceid", interfaceid));

			retList = criteria.list();

			for (Iterator iterator = retList.iterator(); iterator.hasNext();) {
				infcParam = (InterfaceParam) iterator.next();
			}

			if (retList.size() > 0) {
				if (infcParam.getStrwsdlurl() != null) {
					wsdlUrl = infcParam.getStrwsdlurl().toString();
				}
			}
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error("Inside DBService :: getWSDLURL() method :: ", ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return wsdlUrl;

	}

	/*
	 * This Method Returns Parameters From dcf_interface_m table depending on
	 * strinterfaceid
	 */
	public String getExternalMapCode(String mapTypeDesc, String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		String mapCode = "";
		List retList = null;
		ParameterList mapParam = new ParameterList();
		Session session = null;
		Transaction transaction = null;
		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("strtypedesc", mapTypeDesc));

			retList = criteria.list();

			for (Iterator iterator = retList.iterator(); iterator.hasNext();) {
				mapParam = (ParameterList) iterator.next();
			}

			if (retList.size() > 0) {
				if (mapParam.getIparamtypecd() != null) {
					mapCode = mapParam.getIparamtypecd().toString();
				}
			}
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error("Inside DBService :: getExternalMapCode() method :: ",
					ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return mapCode;

	}

	/*
	 * This Method Returns Parameters From dcf_interface_m table depending on
	 * strinterfaceid
	 */
	public HashMap getExternalMapMasterList(String mapCode, String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		int mapCd = 0;
		List retList = null;
		HashMap masterMap = new HashMap();
		ParameterDetailList mapParam = new ParameterDetailList();
		Session session = null;
		Transaction transaction = null;
		try {
			mapCd = Integer.parseInt(mapCode);
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("iparamtypecd", mapCd));

			retList = criteria.list();

			for (Iterator iterator = retList.iterator(); iterator.hasNext();) {
				mapParam = (ParameterDetailList) iterator.next();
				if (mapParam.getStrparamcd() != null
						&& mapParam.getStrcddesc() != null) {
					masterMap.put(mapParam.getStrparamcd(),
							mapParam.getStrcddesc());
				}
			}
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getExternalMapMasterList() method :: ",
					ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return masterMap;

	}

	/*
	 * This Method Returns Parameters From dcf_interface_m table depending on
	 * strinterfaceid
	 */
	public HashMap getExternalMapDataList(String masterMapCode, String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List retList = null;
		HashMap dataMap = new HashMap();
		ExternalMapList mapParam = new ExternalMapList();
		Session session = null;
		Transaction transaction = null;
		try {

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("strdatacatg", masterMapCode));

			retList = criteria.list();

			for (Iterator iterator = retList.iterator(); iterator.hasNext();) {
				mapParam = (ExternalMapList) iterator.next();
				if (mapParam.getStrdcfparamcd() != null
						&& mapParam.getStrextcd() != null) {
					dataMap.put(mapParam.getStrdcfparamcd(),
							mapParam.getStrextcd());
				}
			}
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getExternalMapDataList() method :: ",
					ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return dataMap;

	}

	/*
	 * This Method Returns Parameters From dcf_interface_m table depending on
	 * strinterfaceid
	 */
	public HashMap getRiskDetails(String prodCD, String variant, String model,
			String manufacturer, String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		double dprmamt = 0.0, ab = 0.0;

		StringBuilder buildQuery = new StringBuilder();
		String airbag = null;
		String abs = null;
		String autotran = null;
		String thefttarget = null;
		String segmenttype = null;
		String bodytype = null;
		String vehicleclass = null;
		String vehicletype = null;
		ArrayList arr = new ArrayList();
		HashMap<String, String> constantMap = new HashMap<String, String>();
		Session session = null;
		Transaction transaction = null;
		try {

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			/*
			 * Criteria criteria = session.createCriteria(classInstance);
			 * criteria.add(Restrictions.eq("strvariant", variantCode));
			 * 
			 * retList = criteria.list();
			 */
			logger.info("Entered :: getRiskDetails() method :: Product Code : "
					+ prodCD);
			if (prodCD != null
					&& !prodCD.equalsIgnoreCase("")
					&& (prodCD.equalsIgnoreCase("3121") || prodCD
							.equalsIgnoreCase("3122"))) {
				buildQuery.append("select ");
				buildQuery.append("var.strvariant, ");
				buildQuery.append("var.strairbag, ");
				buildQuery.append("var.strabs, ");
				buildQuery.append("var.strautotran, ");
				buildQuery.append("var.strthefttarget, ");
				buildQuery.append("var.strsegmenttype, ");
				buildQuery.append("var.strbodytypecd, ");
				buildQuery.append("clas.strvehicleclasscd, ");
				buildQuery.append("var.strvehicletype ");
				buildQuery.append("from ");
				// buildQuery.append("dcf_master.dcf_vehicle_class_m clas "); //
				// Commented for oracle migration
				buildQuery.append("dcf_vehicle_class_m clas "); // Added for
																// oracle
																// migration
				// buildQuery.append(",dcf_master.dcf_vehicle_manuf_m manu ");
				// // Commented for oracle migration
				buildQuery.append(",dcf_vehicle_manuf_m manu "); // Added for
																	// oracle
																	// migration
				// buildQuery.append(",dcf_master.dcf_vehicle_model_variant_m var ");
				// // Commented for oracle migration
				buildQuery.append(",dcf_vehicle_model_variant_m var "); // Added
																		// for
																		// oracle
																		// migration
				buildQuery
						.append("where clas.strvehiclecatcd = manu.strvehiclecatcd ");
				buildQuery
						.append("and manu.strmanufacturercd = var.strmanufacturercd ");
				buildQuery.append("and manu.strvehiclecatcd = :prodcode ");
				buildQuery.append("and var.strvariant = :variant ");
				buildQuery.append("and var.strmodelnumber  = :model ");
				buildQuery.append("and manu.strmanufacturercd = :manufact ");
				buildQuery
						.append("and strsegmenttype <> :segmenttype order by 1,2 ");
			} else if (prodCD != null && !prodCD.equalsIgnoreCase("")
					&& prodCD.equalsIgnoreCase("3124")) {
				buildQuery.append("select ");
				buildQuery.append("var.strvariant, ");
				buildQuery.append("var.strairbag, ");
				buildQuery.append("var.strabs, ");
				buildQuery.append("var.strautotran, ");
				buildQuery.append("var.strthefttarget, ");
				buildQuery.append("var.strsegmenttype, ");
				buildQuery.append("var.strbodytypecd, ");
				buildQuery.append("clas.strvehicleclasscd, ");
				buildQuery.append("var.strvehicletype ");
				buildQuery.append("from ");
				// buildQuery.append("dcf_master.dcf_vehicle_class_m clas "); //
				// Commented for oracle migration
				buildQuery.append("dcf_vehicle_class_m clas "); // Added for
																// oracle
																// migration
				// buildQuery.append(",dcf_master.dcf_vehicle_subclass_m subc ");
				// // Commented for oracle migration
				buildQuery.append(",dcf_vehicle_subclass_m subc "); // Added for
																	// oracle
																	// migration
				// buildQuery.append(",dcf_master.dcf_vehicle_manuf_m manu ");
				// // Commented for oracle migration
				buildQuery.append(",dcf_vehicle_manuf_m manu "); // Added for
																	// oracle
																	// migration
				// buildQuery.append(",dcf_master.dcf_vehicle_model_variant_m var ");
				// // Commented for oracle migration
				buildQuery.append(",dcf_vehicle_model_variant_m var "); // Added
																		// for
																		// oracle
																		// migration
				buildQuery
						.append("where clas.strvehiclecatcd = manu.strvehiclecatcd ");
				buildQuery
						.append("and manu.strmanufacturercd = var.strmanufacturercd ");
				buildQuery
						.append("and clas.strvehicleclasscd =  subc.strvehicleclasscd ");
				buildQuery.append("and manu.strvehiclecatcd = :prodcode ");
				buildQuery.append("and var.strsegmenttype = :segmenttype ");
				buildQuery.append("and manu.strmanufacturercd = :manufact ");
				buildQuery.append("and var.strmodelnumber  = :model ");
				// buildQuery.append("and var.strmodelcd  = '"+propGenReq.getLstvecReg().getStrModel()+"' ");
				buildQuery.append("and var.strvariant = :variant ");
				buildQuery
						.append("and clas.strvehicleclasscd = :vehicleclasscd ");
				// buildQuery.append("and clas.strvehicleclasscd = CASE WHEN manu.strvehiclecatcd::character = '3122' THEN '37' WHEN manu.strvehiclecatcd::character = '3121' THEN '45' ELSE '45' END ");
				buildQuery
						.append("and subc.strvehiclesubclasscd = :vehiclesubclasscd ");
				buildQuery.append("order by 1,2,3,4,5 ");
			}

			// SQLQuery query = session.createSQLQuery(buildQuery.toString());
			// START : ADDED FOR ORACLE MIGRATION
			Query query = session.createSQLQuery(buildQuery.toString())

			.addScalar("strvariant", StandardBasicTypes.STRING)
					.addScalar("strairbag", StandardBasicTypes.STRING)
					.addScalar("strabs", StandardBasicTypes.STRING)
					.addScalar("strautotran", StandardBasicTypes.STRING)
					.addScalar("strthefttarget", StandardBasicTypes.STRING)
					.addScalar("strsegmenttype", StandardBasicTypes.STRING)
					.addScalar("strbodytypecd", StandardBasicTypes.STRING)
					.addScalar("strvehicleclasscd", StandardBasicTypes.STRING)
					.addScalar("strvehicletype", StandardBasicTypes.STRING);

			// END : ADDED FOR ORACLE MIGRATION
			if (prodCD != null
					&& !prodCD.equalsIgnoreCase("")
					&& (prodCD.equalsIgnoreCase("3121") || prodCD
							.equalsIgnoreCase("3122"))) {
				query.setParameter("prodcode", prodCD);
				query.setParameter("manufact", manufacturer);
				query.setParameter("model", model);
				query.setParameter("variant", variant);
				query.setParameter("segmenttype", "Commercial Vehicle");
			} else if (prodCD != null && !prodCD.equalsIgnoreCase("")
					&& prodCD.equalsIgnoreCase("3124")) {
				query.setParameter("prodcode", prodCD);
				query.setParameter("manufact", manufacturer);
				query.setParameter("model", model);
				query.setParameter("variant", variant);
				query.setParameter("segmenttype", "Commercial Vehicle");
				query.setParameter("vehicleclasscd", "50");
				query.setParameter("vehiclesubclasscd", "59");
			}

			logger.info("Inside DBService :: getRiskDetails() method :: Query : "
					+ query);
			if (query != null) {
				if (query.list().size() > 0) {
					List<Object[]> retList = (List<Object[]>) query.list();
					logger.info("Inside DBService :: getRiskDetails() method :: Size Of list : "
							+ retList.size());
					for (Object[] lst : retList) {
						variant = nullCheckString(lst[0]);
						airbag = lst[1] == null ? "N" : lst[1].toString();
						abs = lst[2] == null ? "N" : lst[2].toString();
						autotran = lst[3] == null ? "N" : lst[3].toString();
						thefttarget = lst[4] == null ? "N" : lst[4].toString();
						segmenttype = lst[5] == null ? "N" : lst[5].toString();
						bodytype = nullCheckString(lst[6]);
						vehicleclass = nullCheckString(lst[7]);
						vehicletype = nullCheckString(lst[8]);
					}
				} else {
					variant = "";
					airbag = "N";
					abs = "N";
					autotran = "N";
					thefttarget = "N";
					segmenttype = "";
					bodytype = "";
					vehicleclass = "";
					vehicletype = "";
				}
			} else {
				variant = "";
				airbag = "N";
				abs = "N";
				autotran = "N";
				thefttarget = "N";
				segmenttype = "";
				bodytype = "";
				vehicleclass = "";
				vehicletype = "";
			}

			constantMap.put("variant", variant);
			constantMap.put("airbag", airbag);
			constantMap.put("abs", abs);
			constantMap.put("autotran", autotran);
			constantMap.put("thefttarget", thefttarget);
			constantMap.put("segmenttype", segmenttype);
			constantMap.put("bodytype", bodytype);
			constantMap.put("vehicleclass", vehicleclass);
			constantMap.put("vehicletype", vehicletype);
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error("Inside DBService :: getRiskDetails() method :: ", ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return constantMap;

	}

	@SuppressWarnings({ "rawtypes", "unused", "unchecked" })
	public ArrayList getDocumentResponse(String classname,
			DocumentMasterRequest docMastReq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		logger.info("Inside DBService :: getDocumentResponse() method :: Execution Started");

		List lstResult = null;
		double dprmamt = 0.0, ab = 0.0;
		int check = 0, premaddon = 0;
		String abc = "";
		StringBuilder buildQuery = new StringBuilder();
		ArrayList arr = new ArrayList();
		DocumentVO docVO = null;
		int i = 0;
		String desc = "";
		Integer isReq = 0;
		Session session = null;
		Transaction transaction = null;
		try {
			Class classInstance = Class.forName(classname);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// buildQuery.append("select a.strdcodesc,b.nisrequired from dcf_master.dcf_document_m a,			dcf_master.dcf_document_map b where a.strdoccd = b.strdoccd ");
			// // Commented for oracle migration

			buildQuery
					.append("select a.strdcodesc,b.nisrequired from dcf_document_m a, dcf_document_map b where a.strdoccd = b.strdoccd "); // Added
																																			// for
																																			// oracle
																																			// migration

			if (docMastReq.getStrprodcd() != null
					&& !docMastReq.getStrprodcd().equals("")) {
				buildQuery.append("and strprodcd = :prodcd ");
			}

			if (docMastReq.getStrmodeofoperation() != null
					&& !docMastReq.getStrmodeofoperation().equals("")) {
				buildQuery.append("and strmodeofoperation = :modeofoperation ");
			}

			if (docMastReq.getStrendorsementtypecd() != null
					&& !docMastReq.getStrendorsementtypecd().equals("")) {
				buildQuery
						.append("and strendorsementtypecd = :endorsementtypecd ");
			}

			if (docMastReq.getStrcondition1() != null
					&& !docMastReq.getStrcondition1().equals("")) {
				buildQuery.append("and strcondition1 = :condition1 ");
			}

			if (docMastReq.getStrcondition2() != null
					&& !docMastReq.getStrcondition2().equals("")) {
				buildQuery.append("and strcondition2 = :condition2 ");
			}

			if (docMastReq.getStrcondition3() != null
					&& !docMastReq.getStrcondition3().equals("")) {
				buildQuery.append("and strcondition3 = :condition3 ");
			}

			if (docMastReq.getStrcondition4() != null
					&& !docMastReq.getStrcondition4().equals("")) {
				buildQuery.append("and strcondition4 = :condition4 ");
			}

			logger.info("Inside DBService :: getDocumentResponse() method :: buildQuery.toString() : "
					+ buildQuery.toString());

			// SQLQuery query = session.createSQLQuery(buildQuery.toString());
			// START : ADDED FOR ORACLE MIGRATION
			Query query = session.createSQLQuery(buildQuery.toString())
					.addScalar("strdcodesc", StandardBasicTypes.STRING)
					.addScalar("nisrequired", StandardBasicTypes.BIG_DECIMAL);
			// END : ADDED FOR ORACLE MIGRATION
			if (docMastReq.getStrprodcd() != null
					&& !docMastReq.getStrprodcd().equals("")) {
				query.setParameter("prodcd", docMastReq.getStrprodcd());
			}
			if (docMastReq.getStrmodeofoperation() != null
					&& !docMastReq.getStrmodeofoperation().equals("")) {
				query.setParameter("modeofoperation",
						docMastReq.getStrmodeofoperation());
			}
			if (docMastReq.getStrendorsementtypecd() != null
					&& !docMastReq.getStrendorsementtypecd().equals("")) {
				query.setParameter("endorsementtypecd",
						docMastReq.getStrendorsementtypecd());
			}
			if (docMastReq.getStrcondition1() != null
					&& !docMastReq.getStrcondition1().equals("")) {
				query.setParameter("condition1", docMastReq.getStrcondition1());
			}
			if (docMastReq.getStrcondition2() != null
					&& !docMastReq.getStrcondition2().equals("")) {
				query.setParameter("condition2", docMastReq.getStrcondition2());
			}
			if (docMastReq.getStrcondition3() != null
					&& !docMastReq.getStrcondition3().equals("")) {
				query.setParameter("condition3", docMastReq.getStrcondition3());
			}
			if (docMastReq.getStrcondition4() != null
					&& !docMastReq.getStrcondition4().equals("")) {
				query.setParameter("condition4", docMastReq.getStrcondition4());
			}

			List<DocumentVO> retList = (List<DocumentVO>) query
					.setResultTransformer(
							Transformers.aliasToBean(DocumentVO.class)).list();

			for (int j = 0; j < retList.size(); j++) {
				docVO = new DocumentVO();
				docVO.setStrdcodesc(retList.get(j).getStrdcodesc().toString());
				docVO.setNisrequired((BigDecimal) retList.get(j)
						.getNisrequired());
				arr.add(docVO);
			}

			logger.info("Inside DBService :: getDocumentResponse() method :: Execution Completed Successfully");
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getDocumentResponse() method :: ", ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return arr;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getSecurityQuestion(String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<SecurityQuestion> rtoList = new ArrayList<SecurityQuestion>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getSecurityQuestion Method"); }
			 */

			logger.info("Inside DBService :: getSecurityQuestion(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			rtoList = session.createQuery("from SecurityQuestion").list();

			/*
			 * for (Iterator iterator = rtoList.iterator(); iterator.hasNext();)
			 * { SecurityQuestion rtof = (SecurityQuestion)iterator.next(); }
			 */

			logger.info("Inside DBService :: getSecurityQuestion(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getSecurityQuestion Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getSecurityQuestion() method :: ", ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return rtoList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getSubCategory(String className,
			SubCategoryRequest idvReq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List subCatList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		List listProduct = new ArrayList();
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.getSubCategory Method"); }
		 */

		logger.info("Inside DBService :: getSubCategory(String, String, String) method :: Execution Started");
		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : ADDED FOR ORACLE MIGRATION
			/*
			 * Query query = session .createSQLQuery(
			 * "SELECT * from proc_getsubcategory(:strlobcd,:strprodcd,:strservreqcatcd)"
			 * ) .setParameter("strlobcd", idvReq.getStrlobcd())
			 * .setParameter("strprodcd", idvReq.getStrprodcd())
			 * .setParameter("strservreqcatcd", idvReq.getStrservreqcatcd());
			 */

			Query query = session
					.createSQLQuery(
							"SELECT * from table(proc_getsubcategory(:strlobcd,:strprodcd,:strservreqcatcd))")
					.addScalar("strservreqsubcatcd", StandardBasicTypes.STRING)
					.addScalar("strcddesc", StandardBasicTypes.STRING)
					.addScalar("strtype", StandardBasicTypes.STRING)
					.addScalar("strsubtype", StandardBasicTypes.STRING)
					.addScalar("strgrp", StandardBasicTypes.STRING)
					.addScalar("strsubgrp", StandardBasicTypes.STRING)
					.setParameter("strlobcd", idvReq.getStrlobcd())
					.setParameter("strprodcd", idvReq.getStrprodcd())
					.setParameter("strservreqcatcd",
							idvReq.getStrservreqcatcd());

			// END : ADDED FOR ORACLE MIGRATION

			listProduct = query.setResultTransformer(
					Transformers.aliasToBean(SubCategory.class)).list();
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);

			// listProduct = query.list();
			if (listProduct != null && !listProduct.isEmpty()) {
				// System.out.println("value:***** "+listProduct);
			}

			logger.info("Inside DBService :: getSubCategory(String, String, String) method :: Execution Completed Successfully");

			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getSubCategory(String, String, String) method :: ",
					ae);
		}

		return listProduct;
	}

	/*
	 * This Method Returns Parameters From dcf_interface_m table depending on
	 * strinterfaceid
	 */
	public HashMap getModelVariantSeatCubicInfo(String prodCD, String model,
			String variant, String manufacturer, String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		StringBuilder buildQuery = new StringBuilder();
		String modelCode = null;
		String parentModelCode = null;
		String cubicCapacity = null;
		String SeatingCapacity = null;
		String VehicleType = null; // Added To Make Indigenous, Imported,
									// Obsolete
		ArrayList arr = new ArrayList();
		HashMap<String, String> constantMap = new HashMap<String, String>();
		Session session = null;
		Transaction transaction = null;
		try {

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			buildQuery.append("select ");
			// buildQuery.append("strmodelcd as variantcode, "); // Commented
			// for oracle migration
			buildQuery.append("strmodelcd, "); // Added for oracle migration
			// buildQuery.append("var.nparenmodelcd as modelcode, "); //
			// Commented for oracle migration
			buildQuery.append("var.nparenmodelcd, "); // Added for oracle
														// migration
			// buildQuery.append("var.ncubiccapacity as cubiccapacity, "); //
			// Commented for oracle migration
			buildQuery.append("var.ncubiccapacity, "); // Added for oracle
														// migration
			// buildQuery.append("var.nseatingcapacity as seatingcapacity, ");
			// //Added To Make Indigenous, Imported, Obsolete // Commented for
			// oracle migration
			buildQuery.append("var.nseatingcapacity, "); // Added To Make
															// Indigenous,
															// Imported,
															// Obsolete // Added
															// for oracle
															// migration
			// buildQuery.append("var.strvehicletype as vehicletype "); //Added
			// To Make Indigenous, Imported, Obsolete // Commented for oracle
			// migration
			buildQuery.append("var.strvehicletype "); // Added To Make
														// Indigenous, Imported,
														// Obsolete // Added for
														// oracle migration
			buildQuery.append("from ");
			// buildQuery.append("dcf_master.dcf_vehicle_class_m clas, "); //
			// Commented for oracle migration
			buildQuery.append("dcf_vehicle_class_m clas, "); // Added for oracle
																// migration
			// buildQuery.append("dcf_master.dcf_vehicle_manuf_m manu, "); //
			// Commented for oracle migration
			buildQuery.append("dcf_vehicle_manuf_m manu, "); // Added for oracle
																// migration
			// buildQuery.append("dcf_master.dcf_vehicle_model_variant_m var ");
			// // Commented for oracle migration
			buildQuery.append("dcf_vehicle_model_variant_m var "); // Added for
																	// oracle
																	// migration
			buildQuery
					.append("where clas.strvehiclecatcd = manu.strvehiclecatcd ");
			buildQuery
					.append("and manu.strmanufacturercd = var.strmanufacturercd ");
			buildQuery.append("and manu.strvehiclecatcd = :prodcode ");
			buildQuery.append("and var.strmodelnumber = :model ");
			buildQuery.append("and var.strvariant = :variant ");
			buildQuery.append("and manu.strmanufacturername = :manufact ");

			// SQLQuery query = session.createSQLQuery(buildQuery.toString());
			// START : ADDED FOR ORACLE MIGRATION
			Query query = session
					.createSQLQuery(buildQuery.toString())
					.addScalar("strmodelcd", StandardBasicTypes.STRING)
					.addScalar("nparenmodelcd", StandardBasicTypes.STRING)
					.addScalar("ncubiccapacity", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("nseatingcapacity",
							StandardBasicTypes.BIG_DECIMAL)
					.addScalar("strvehicletype", StandardBasicTypes.STRING);
			// END : ADDED FOR ORACLE MIGRATION
			query.setParameter("prodcode", prodCD);
			query.setParameter("model", model);
			query.setParameter("variant", variant);
			query.setParameter("manufact", manufacturer);

			if (query != null && query.list().size() > 0) {
				List<Object[]> retList = (List<Object[]>) query.list();
				logger.info("Inside DBService :: getModelVariantSeatCubicInfo() method :: Size Of list : "
						+ retList.size());
				for (Object[] lst : retList) {
					modelCode = lst[0] == null ? "" : lst[0].toString();
					parentModelCode = lst[1] == null ? "" : lst[1].toString();
					cubicCapacity = lst[2] == null ? "" : lst[2].toString();
					SeatingCapacity = lst[3] == null ? "" : lst[3].toString();
					VehicleType = lst[4] == null ? "" : lst[4].toString(); // Added
																			// To
																			// Make
																			// Indigenous,
																			// Imported,
																			// Obsolete
				}
			} else {
				modelCode = "";
				parentModelCode = "";
				cubicCapacity = "";
				SeatingCapacity = "";
				VehicleType = ""; // Added To Make Indigenous, Imported,
									// Obsolete
				logger.info("Inside DBService :: getModelVariantSeatCubicInfo() method :: Size Of list : "
						+ query.list().size());
				logger.info("Inside DBService :: getModelVariantSeatCubicInfo() method ::  All Values Are Blank......");
			}

			constantMap.put("modelCode", modelCode);
			constantMap.put("parentModelCode", parentModelCode);
			constantMap.put("cubicCapacity", cubicCapacity);
			constantMap.put("SeatingCapacity", SeatingCapacity);
			constantMap.put("VehicleType", VehicleType); // Added To Make
															// Indigenous,
															// Imported,
															// Obsolete
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getModelVariantSeatCubicInfo() method :: ",
					ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return constantMap;

	}

	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap getRTOGroupCode(String className, String paramValue)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.getRTOGroupCode Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		String locationCode = null;
		String stateCode = null;
		String locationDesc = null;
		String registrationZone = null;// Added For For Zone Change
		String registrationZone1 = null;// Added For For Zone Change
		HashMap<String, String> rtoGroupMap = new HashMap<String, String>();

		logger.info("Inside DBService :: getRTOGroupCode(String) method :: Execution Started");
		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.and(Restrictions.eq("strrtolocationcd",
					paramValue), Restrictions.eq("strstatus",
					CommonConstants.RECORD_STATUS_ACTIVE)));

			List rtoList = criteria.list();

			if (rtoList != null && rtoList.size() > 0) {
				logger.info("Inside DBService :: getRTOGroupCode() method :: Size Of list : "
						+ rtoList.size());
				for (Iterator iterator = rtoList.iterator(); iterator.hasNext();) {
					RTOLocation rtof = (RTOLocation) iterator.next();

					locationCode = rtof.getStrrtolocationcd() == null ? ""
							: rtof.getStrrtolocationcd();
					// stateCode =
					// rtof.getStrstatecd()==null?"":rtof.getStrstatecd().toString();
					// // Commented as sending wrong value
					stateCode = rtof.getStrrtolocgrpcd() == null ? "" : rtof
							.getStrrtolocgrpcd();
					locationDesc = rtof.getStrrtolocationdesc() == null ? ""
							: rtof.getStrrtolocationdesc();
					registrationZone = rtof.getStrregistrationzone() == null ? ""
							: rtof.getStrregistrationzone();// Added For Zone
															// Changes
					registrationZone1 = rtof.getStrregistrationzone1() == null ? ""
							: rtof.getStrregistrationzone1();// Added For Zone
																// Changes
					logger.info("Inside DBService :: getRTOGroupCode() method :: locationCode : "
							+ locationCode);
					logger.info("Inside DBService :: getRTOGroupCode() method :: stateCode : "
							+ stateCode);
					logger.info("Inside DBService :: getRTOGroupCode() method :: locationDesc : "
							+ locationDesc);
					logger.info("Inside DBService :: getRTOGroupCode() method :: registrationZone : "
							+ registrationZone);
					logger.info("Inside DBService :: getRTOGroupCode() method :: registrationZone1 : "
							+ registrationZone1);
				}
			} else {
				locationCode = "";
				stateCode = "";
				locationDesc = "";
				registrationZone = "";// Added For Zone Changes
				registrationZone1 = "";// Added For Zone Changes
				logger.info("Inside DBService :: getRTOGroupCode() method :: Size Of list : "
						+ rtoList.size());
				logger.info("Inside DBService :: getRTOGroupCode() method ::  All Values Are Blank......");
			}

			rtoGroupMap.put("locationCode", locationCode);
			rtoGroupMap.put("stateCode", stateCode);
			rtoGroupMap.put("locationDesc", locationDesc);
			rtoGroupMap.put("registrationZone", registrationZone);// Added For
																	// Zone
																	// Changes
			rtoGroupMap.put("registrationZone1", registrationZone1);// Added For
																	// Zone
																	// Changes

			logger.info("Inside DBService :: getRTOGroupCode(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getRTOGroupCode Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getRTOGroupCode(String) method :: ",
					ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return rtoGroupMap;
	}

	/*-----------------------Added by Nikhil570154 from here-------------------*/
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getVehicleIdv(String className,
			VehicleIdvRequest idvReq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List<VehicleIdv> idvlst = new ArrayList<VehicleIdv>();
		Session session = null;
		Transaction transaction = null;
		List listProduct = new ArrayList();
		ObjectMapper objMap = new ObjectMapper();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getVehicleIdv Method"); }
			 */

			logger.info("Inside DBService :: getVehicleIdv(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			logger.info("Inside DBService :: getVehicleIdv(String) method :: Complete Request JSON For IDV Of The Vehicle : "
					+ objMap.writeValueAsString(idvReq));

			// START : ADDED FOR ORACLE MIGRATION

			Query query = session
					.createSQLQuery(
							"SELECT * from table(proc_getidv(:mfgcode,:modelcode,:vehicleage,:tatabranchcode))")
					.addScalar("nidv", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("nvehiclesellingprice",
							StandardBasicTypes.BIG_DECIMAL)
					.addScalar("nvehiclechassisprice",
							StandardBasicTypes.BIG_DECIMAL)
					.addScalar("nlocationexshowroomprice",
							StandardBasicTypes.BIG_DECIMAL)

					// END : ADDED FOR ORACLE MIGRATION
					.setParameter("mfgcode", idvReq.getStrmanufacturercd())
					.setParameter("modelcode", idvReq.getStrmodelcd())
					.setParameter("vehicleage", idvReq.getNvehicleage())
					.setParameter("tatabranchcode",
							idvReq.getStrofficeproducerid());
			listProduct = query.setResultTransformer(
					Transformers.aliasToBean(VehicleIdv.class)).list();
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);

			// listProduct = query.list();
			if (listProduct != null && !listProduct.isEmpty()) {
				// System.out.println("value:***** "+listProduct.get(0));
			}

			logger.info("Inside DBService :: getVehicleIdv(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getVehicleIdv Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getVehicleIdv(String) method :: ", ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return listProduct;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getAddOnFeatures(String className,
			VehicleAddOnRequest idvReq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List<VehicleAddOn> idvlst = new ArrayList<VehicleAddOn>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getAddOnFeatures Method"); }
			 */

			logger.info("Inside DBService :: getAddOnFeatures(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			String strplancode = "";
			strplancode = idvReq.getStrplancode();

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("strplancode", strplancode));

			idvlst = criteria.list();
			// idvlst =
			// session.createQuery("from VehicleAddOn where strplancode='"+strplancode+"'").list();

			logger.info("Inside DBService :: getAddOnFeatures(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getAddOnFeatures Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			logger.error(
					"Inside DBService :: DBService.getAddOnFeatures method :: ",
					ae);
			transaction.rollback();

		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return idvlst;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getCompanyMaster(String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<CompanyMaster> rtoList = new ArrayList<CompanyMaster>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getCompanyMaster Method"); }
			 */

			logger.info("Inside DBService :: getCompanyMaster(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			rtoList = session.createQuery("from CompanyMaster").list();

			/*
			 * for (Iterator iterator = rtoList.iterator(); iterator.hasNext();)
			 * { CompanyMaster rtof = (CompanyMaster)iterator.next(); }
			 */

			logger.info("Inside DBService :: getCompanyMaster(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getCompanyMaster Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getRTOGroupCode(String) method :: ",
					ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return rtoList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getFinancierMaster(String className,
			String strfin) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List<FinancierMaster> rtoList = new ArrayList<FinancierMaster>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getFinancierMaster Method"); }
			 */

			logger.info("Inside DBService :: getFinancierMaster(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// Criteria criteria = session.createCriteria(classInstance);
			// criteria.add(Restrictions.eq("strfinanciername",strfin));
			//
			// rtoList = criteria.list();
			String query = "from FinancierMaster where strfinanciername LIKE :financiername";
			rtoList = session.createQuery(query)
					.setString("financiername", strfin + "%").list();

			/*
			 * for (Iterator iterator = rtoList.iterator(); iterator.hasNext();)
			 * { FinancierMaster rtof = (FinancierMaster)iterator.next(); }
			 */

			logger.info("Inside DBService :: getFinancierMaster(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getFinancierMaster Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getFinancierMaster(String) method :: ",
					ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return rtoList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> fetchRTOLocation(String className,
			RTOLocationRequest idvReq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List<RTOLocation> idvlst = new ArrayList<RTOLocation>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.fetchRTOLocation Method"); }
			 */

			logger.info("Inside DBService :: fetchRTOLocation(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			String strrtolocationcd = "";
			strrtolocationcd = idvReq.getStrrtolocationcd();
			// START : ADDED FOR ORACLE MIGRATION
			/*
			 * Criteria criteria = session.createCriteria(classInstance);
			 * //criteria
			 * .add(Restrictions.eq("strrtolocationcd",strrtolocationcd));
			 * //commented As Per Issue Raised On 08/05/2017
			 * criteria.add(Restrictions
			 * .and(Restrictions.eq("strrtolocationcd",strrtolocationcd_latest
			 * ),Restrictions.eq("strstatus",
			 * CommonConstants.RECORD_STATUS_ACTIVE))); //Added As Per Issue
			 * Raised On 08/05/2017 12:54PM
			 * 
			 * idvlst = criteria.list();
			 */

			Query query = session
					.createSQLQuery(
							"SELECT * from dcf_vh_rto_location_m where trim(strrtolocationcd) = :rtolocationcd and strstatus = :status")
					.addScalar("strrtolocationcd", StandardBasicTypes.STRING)
					.addScalar("strrtolocationdesc", StandardBasicTypes.STRING)
					.setParameter("rtolocationcd", strrtolocationcd)
					.setParameter("status",
							CommonConstants.RECORD_STATUS_ACTIVE);
			idvlst = query.setResultTransformer(
					Transformers.aliasToBean(RTOLocation.class)).list();

			// END : ADDED FOR ORACLE MIGRATION
			logger.info("Inside DBService :: fetchRTOLocation(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.fetchRTOLocation Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: fetchRTOLocation(String) method :: ",
					ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		if (idvlst.size() > 1) {
			idvlst.get(0);
		}
		return idvlst;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getOfficeMaster(String className,
			String strBranchLocation) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List<OfficeMaster> rtoList = new ArrayList<OfficeMaster>();
		Session session = null;
		Transaction transaction = null;
		List listProduct = new ArrayList();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getOfficeMaster Method"); }
			 */

			logger.info("Inside DBService :: getOfficeMaster(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// rtoList =
			// session.createQuery("select strofficedesc || '('||strofficecd ||')' Office,nofficecd,nparentofficecd,strofficedesc,strofficecd,strparentofficecd from OfficeMaster").list();
			/*
			 * for (Iterator iterator = rtoList.iterator(); iterator.hasNext();)
			 * { OfficeMaster rtof = (OfficeMaster)iterator.next(); }
			 */

			// Query query =
			// session.createSQLQuery("SELECT * from proc_getofficemaster(:_paramkey)").setParameter("_paramkey",
			// strBranchLocation);
			// START : ADDED FOR ORACLE MIGRATION
			/*
			 * Query query = session
			 * .createSQLQuery("SELECT * from proc_getofficemaster()");
			 * query.setResultTransformer(Transformers
			 * .aliasToBean(OfficeMaster.class)); listProduct = query.list();
			 */

			Query query = session
					.createSQLQuery("SELECT * from table(proc_getofficemaster)")
					.addScalar("office", StandardBasicTypes.STRING)
					.addScalar("nofficecd", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("nparentofficecd",
							StandardBasicTypes.BIG_DECIMAL)
					.addScalar("strofficedesc", StandardBasicTypes.STRING)
					.addScalar("strofficecd", StandardBasicTypes.STRING)
					.addScalar("strparentofficecd", StandardBasicTypes.STRING);
			// END : ADDED FOR ORACLE MIGRATION
			query.setResultTransformer(Transformers
					.aliasToBean(OfficeMaster.class));
			listProduct = query.list();

			if (listProduct != null && !listProduct.isEmpty()) {
				// System.out.println("value:***** "+listProduct.get(0));
				// System.out.println("value:XXXXXX "+listProduct.get(0).toString());
			}
			logger.info("Inside DBService :: getOfficeMaster(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getOfficeMaster Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getOfficeMaster(String) method :: ",
					ae);
		}

		return listProduct;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getDealerMasterResponse(String className,
			DealerMasterRequest idvReq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List<DealerMaster> dealerlst = new ArrayList<DealerMaster>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getDealerMasterResponse Method"); }
			 */

			logger.info("Inside DBService :: getDealerMasterResponse(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			BigDecimal nofficecd;
			nofficecd = idvReq.getNofficecd();

			// String sql =
			// "SELECT strintermediarycd,strintermediaryname,strdealercd,strdealername FROM dcf_master.dcf_ch_intermediary_m WHERE nyndealer = 1 AND nofficecd = "+nofficecd;
			// START:Changes done for oracle migration
			// String
			// sql="SELECT strintermediarycd,strintermediaryname,strdealercd,strdealername FROM dcf_master.dcf_ch_intermediary_m WHERE nyndealer = :dealer AND nofficecd =:_nofficecd and strparentintermediarycd=:_producerCode";
			// // Commented for oracle migration
			String sql = "SELECT strintermediarycd,strintermediaryname,strdealercd,strdealername FROM dcf_ch_intermediary_m WHERE "
					+ "nyndealer = :dealer AND nofficecd =:nofficecd and strparentintermediarycd=:producerCode"; // Added
																													// for
																													// oracle
																													// migration

			SQLQuery query = session
					.createSQLQuery(sql)
					.addScalar("strintermediarycd", StandardBasicTypes.STRING)
					.addScalar("strintermediaryname", StandardBasicTypes.STRING)
					.addScalar("strdealercd", StandardBasicTypes.STRING)
					.addScalar("strdealername", StandardBasicTypes.STRING);
			query.setParameter("dealer", 1);
			query.setParameter("nofficecd", nofficecd);
			query.setParameter("producerCode", idvReq.getProducerCode());

			// END:Changes done for oracle migration
			dealerlst = (List<DealerMaster>) query.setResultTransformer(
					Transformers.aliasToBean(DealerMaster.class)).list();

			logger.info("Inside DBService :: getDealerMasterResponse(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getDealerMasterResponse Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getDealerMasterResponse(String) method :: ",
					ae);
		}
		return dealerlst;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getAccFinancierBranch(String className,
			AccFinancierBranchRequest idvReq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		ArrayList arr = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		List listProduct = new ArrayList();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getAccFinancierBranch Method"); }
			 */

			logger.info("Inside DBService :: getAccFinancierBranch(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			String strIFSCCD = "";
			strIFSCCD = idvReq.getStrIFSCCD();
			// START : CHANGES DONE FOR THE ORACLE MIGRATION

			/*
			 * Query query =
			 * session.createSQLQuery("SELECT * from proc_getbranchname(:_iffccode)"
			 * ).setParameter("_iffccode", idvReq.getStrIFSCCD());
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			 * listProduct = query.list();
			 */

			Query query = session
					.createSQLQuery(
							"SELECT * from table(proc_getbranchname(:iffccode))")
					.addScalar("nfinanciercd", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("finbranchname", StandardBasicTypes.STRING)
					.addScalar("strfinanciername", StandardBasicTypes.STRING)
					.addScalar("strbranchname", StandardBasicTypes.STRING)
					.addScalar("strmicrcd", StandardBasicTypes.STRING)

					.setParameter("iffccode", idvReq.getStrIFSCCD());
			listProduct = query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			// END : CHANGES DONE FOR THE ORACLE MIGRATION
			/*
			 * if(listProduct!=null && !listProduct.isEmpty()){
			 * System.out.println("value:***** "+listProduct.get(0));
			 * System.out.
			 * println("value:XXXXXX "+listProduct.get(0).toString()); }
			 */
			// for (Object obj: listProduct){
			//
			// Map row = (Map)obj;
			// arr.add(row.get("proc_getbranchname"));
			// }

			logger.info("Inside DBService :: getAccFinancierBranch(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getAccFinancierBranch Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getAccFinancierBranch(String) method :: ",
					ae);
		}

		return listProduct;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	// public List<? extends Object> getCityVehUsed(String className, String
	// cityName) throws ClassNotFoundException, InstantiationException,
	// IllegalAccessException{
	public ArrayList getCityVehUsed(String className, String cityName)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<City> rtoList = new ArrayList<City>();
		ArrayList<Object[]> retList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getCityVehUsed Method"); }
			 */

			logger.info("Inside DBService :: getCityVehUsed(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// rtoList = session.createQuery("from City").list();

			// ***Start:Old query***
			// Criteria criteria = session.createCriteria(classInstance);
			// criteria.add(Restrictions.eq("ndistrictcityflag","C"));
			// criteria.add(Restrictions.like("strcityname", cityName));
			// rtoList = criteria.list();
			// ***End:Old query***

			// Start:17-12-2016 New query Impl with parameterized method & funct
			// @yogesh
			// START: CHANGES ADDED FOR ORACLE MIGRATION
			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_getcity_veh_used(:_strcityname)")
			 * .setParameter("_strcityname", cityName);
			 * 
			 * retList = (ArrayList) query.list();
			 */

			Query query = session
					.createSQLQuery(
							"SELECT * From table(func_getcity_veh_used(:strcityname))")
					.addScalar("strcitycd", StandardBasicTypes.STRING)
					.addScalar("strcityname", StandardBasicTypes.STRING);

			query.setParameter("strcityname", cityName);
			// END :CHANGES ADDED FOR ORACLE MIGRATION
			retList = (ArrayList) query.list();
			// System.out.println("City List size(): " + rtoList.size());
			// End:17-12-2016 New query Impl with parameterized method & funct
			// @yogesh

			/*
			 * for (Iterator iterator = rtoList.iterator(); iterator.hasNext();)
			 * { City rtof = (City)iterator.next(); }
			 */

			logger.info("Inside DBService :: getCityVehUsed(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getCityVehUsed Method"); }
			 */
			transaction.commit();

		} catch (Exception ae) {
			transaction.rollback();
			logger.error("Inside DBService :: getCityVehUsed() method :: ", ae);
		}

		return retList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getSubAgentMaster(String className,
			String arg, String arg1) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List<SubAgentMaster> rtoList = new ArrayList<SubAgentMaster>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getSubAgentMaster Method"); }
			 */

			logger.info("Inside DBService :: getSubAgentMaster(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// rtoList =
			// session.createQuery("from SubAgentMaster where strintermediarycd = '"+arg+"'").list();

			/*
			 * String query =
			 * "from SubAgentMaster where strintermediarycd ='"+arg
			 * +"' AND strsubagentcd LIKE :strsubagentcd"; rtoList =
			 * session.createQuery(query).setString("strsubagentcd",
			 * arg1+"%").list();
			 */

			String query = "from SubAgentMaster where strintermediarycd = :intermediarycd AND strsubagentcd LIKE :strsubagentcd";
			rtoList = session.createQuery(query)
					.setParameter("intermediarycd", arg)
					.setString("strsubagentcd", arg1 + "%").list();

			/*
			 * for (Iterator iterator = rtoList.iterator(); iterator.hasNext();)
			 * { SubAgentMaster rtof = (SubAgentMaster)iterator.next(); }
			 */
			logger.info("Inside DBService :: getSubAgentMaster(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getSubAgentMaster Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getSecurityQuestion() method :: ", ae);
		}

		return rtoList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getFieldUser(String className,
			FieldUserRequest modelreq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		// List<AccFinancierBranch> idvlst = new
		// ArrayList<AccFinancierBranch>();
		ArrayList arr = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		List listProduct = new ArrayList();
		ObjectMapper objMap = new ObjectMapper();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getFieldUser Method"); }
			 */

			logger.info("Inside DBService :: getFieldUser(String) method :: Execution Started");

			logger.info("Inside DBService :: getFieldUser(String) method :: Received JSON Request"
					+ objMap.writeValueAsString(modelreq));

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			int officeCd = Integer.parseInt(modelreq.getNofficecd());
			logger.info("Inside DBService :: getFieldUser(String) method :: officeCd"
					+ officeCd);

			// START : ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session .createSQLQuery(
			 * "SELECT * from proc_getfieldusermaster(:officecode,:dealercode)")
			 * .setParameter("officecode", officeCd) .setParameter("dealercode",
			 * modelreq.getStrintermediarycd());
			 */

			Query query = session
					.createSQLQuery(
							"SELECT * from table(proc_getfieldusermaster(:officecode,:dealercode))")
					.addScalar("nfieldusercd", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("struserid", StandardBasicTypes.STRING)
					.addScalar("strfieldusername", StandardBasicTypes.STRING)
					.setParameter("officecode", officeCd)
					.setParameter("dealercode", modelreq.getStrintermediarycd());

			// START : ADDED FOR ORACLE MIGRATION
			listProduct = query.setResultTransformer(
					Transformers.aliasToBean(FieldUser.class)).list();
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);

			// listProduct = query.list();
			if (listProduct != null && !listProduct.isEmpty()) {
				// System.out.println("value:***** "+listProduct.get(0));
			}

			logger.info("Inside DBService :: getFieldUser(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getFieldUser Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error("Inside DBService :: getFieldUser(String) method :: ",
					ae);
		}

		return listProduct;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getPrevInsurer(PrevInsurerRequest modelreq)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		// List<AccFinancierBranch> idvlst = new
		// ArrayList<AccFinancierBranch>();
		ArrayList arr = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		List listProduct = new ArrayList();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getPrevInsurer Method"); }
			 */

			logger.info("Inside DBService :: getPrevInsurer(String) method :: Execution Started");

			// Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : CHANGES FOR ORACLE MIGRATION
			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from proc_getprevinsurerdet(:companycode)")
			 * .setParameter("companycode", modelreq.getStrcompanycd());
			 * //listProduct =
			 * query.setResultTransformer(Transformers.aliasToBean
			 * (FieldUser.class)).list(); listProduct =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */
			Query query = (Query) session
					.createSQLQuery(
							"SELECT * from table(proc_getprevinsurerdet(:companycode))")
					.addScalar("strcompanytype", StandardBasicTypes.STRING)
					.addScalar("nofficeid", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("strofficecd", StandardBasicTypes.STRING)
					.addScalar("branch", StandardBasicTypes.STRING)
					.addScalar("straddline1", StandardBasicTypes.STRING)
					.addScalar("straddline2", StandardBasicTypes.STRING)
					.addScalar("straddline3", StandardBasicTypes.STRING)
					.addScalar("strlandmark", StandardBasicTypes.STRING)
					.addScalar("strstatecd", StandardBasicTypes.STRING)
					.addScalar("strstatename", StandardBasicTypes.STRING)
					.addScalar("strcitycd", StandardBasicTypes.STRING)
					.addScalar("strcityname", StandardBasicTypes.STRING)
					.addScalar("npincode", StandardBasicTypes.BIG_DECIMAL)

					// END : CHANGES FOR ORACLE MIGRATION
					.setParameter("companycode", modelreq.getStrcompanycd());
			// listProduct =
			// query.setResultTransformer(Transformers.aliasToBean(FieldUser.class)).list();
			listProduct = query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			// listProduct = query.list();
			if (listProduct != null && !listProduct.isEmpty()) {
				// System.out.println("value: "+listProduct.get(0));
			}

			logger.info("Inside DBService :: getPrevInsurer(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getPrevInsurer Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getPrevInsurer(String) method :: ", ae);
		}

		return listProduct;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getMiscType(String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List vehsbclList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getMiscType Method"); }
			 */

			logger.info("Inside DBService :: getMiscType(String, String, String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("strvehicleclasscd", "51"));

			vehsbclList = criteria.list();

			logger.info("Inside DBService :: getMiscType(String) method :: Execution Completed Successfully");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getMiscType(String, String, String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getMiscType(String, String, String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return vehsbclList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getDocList(String className,
			DocListRequest idvReq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		ArrayList arr = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		List listProduct = new ArrayList();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getDocList Method"); }
			 */

			logger.info("Inside DBService :: getDocList(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION
			Query query = session
					.createSQLQuery(
							"SELECT * from table(proc_getDocList(:strservreqcatcd,:strservreqsubcatcd,:strprodcd))")
					.addScalar("strdcodesc", StandardBasicTypes.STRING)
					.addScalar("strdoccd", StandardBasicTypes.STRING)

					// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
					.setParameter("strservreqcatcd",
							idvReq.getStrservreqcatcd())
					.setParameter("strservreqsubcatcd",
							idvReq.getStrservreqsubcatcd())
					.setParameter("strprodcd", idvReq.getStrprodcd());
			listProduct = query.setResultTransformer(
					Transformers.aliasToBean(DocumentMaster.class)).list();
			if (listProduct != null && !listProduct.isEmpty()) {
				// System.out.println("value:***** "+listProduct.get(0));
				// System.out.println("value:XXXXXX "+listProduct.get(0).toString());
			}
			/*
			 * for (Object obj: listProduct){
			 * 
			 * Map row = (Map)obj; arr.add(row.get("proc_getbranchname")); }
			 */

			logger.info("Inside DBService :: getDocList(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getDocList Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error("Inside DBService :: getDocList(String) method :: ",
					ae);
		}

		return listProduct;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getGarageCityMaster(String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<GarageCityMaster> rtoList = new ArrayList<GarageCityMaster>();
		Session session = null;
		Transaction transaction = null;
		List listProduct = new ArrayList();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getGarageCityMaster Method"); }
			 */

			logger.info("Inside DBService :: getGarageCityMaster(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// rtoList =
			// session.createQuery("select strofficedesc || '('||strofficecd ||')' Office,nofficecd,nparentofficecd,strofficedesc,strofficecd,strparentofficecd from OfficeMaster").list();
			/*
			 * for (Iterator iterator = rtoList.iterator(); iterator.hasNext();)
			 * { OfficeMaster rtof = (OfficeMaster)iterator.next(); }
			 */
			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION
			Query query = session
					.createSQLQuery(
							"SELECT * from  table(proc_getgaragecitymaster())")
					.addScalar("strsettlingoffice", StandardBasicTypes.STRING)
					.addScalar("nserviceofficecd", StandardBasicTypes.INTEGER)
					.addScalar("ncitycd", StandardBasicTypes.INTEGER);

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			query.setResultTransformer(Transformers
					.aliasToBean(GarageCityMaster.class));
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);

			rtoList = query.list();

			if (listProduct != null && !listProduct.isEmpty()) {
				// System.out.println("value:***** "+listProduct.get(0));
				// System.out.println("value:XXXXXX "+listProduct.get(0).toString());
			}
			logger.info("Inside DBService :: getGarageCityMaster(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getGarageCityMaster Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getGarageCityMaster(String) method :: ",
					ae);
		}

		return rtoList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getLongLat(String className,
			GarageRadiusRequest idvReq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		ArrayList arr = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		List listProduct = new ArrayList();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getLongLat Method"); }
			 */

			logger.info("Inside DBService :: getLongLat(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START:Changes done for oracle migration
			Query query = session
					.createSQLQuery(
							"SELECT * from table(proc_getlonglat(:prodcode,:mfgcode,:citycode))")
					.addScalar("address", StandardBasicTypes.STRING)
					.addScalar("nlongitude", StandardBasicTypes.STRING)
					.addScalar("nlatitude", StandardBasicTypes.STRING)

					// END:Changes done for oracle migration
					.setParameter("prodcode", idvReq.getStrprodcd())
					.setParameter("mfgcode", idvReq.getStrmanufacturercd())
					.setParameter("citycode", idvReq.getStrcitycd());
			listProduct = query.setResultTransformer(
					Transformers.aliasToBean(GarageRadius.class)).list();
			if (listProduct != null && !listProduct.isEmpty()) {
				// System.out.println("value:***** "+listProduct.get(0));
				// System.out.println("value:XXXXXX "+listProduct.get(0).toString());
			}
			/*
			 * for (Object obj: listProduct){
			 * 
			 * Map row = (Map)obj; arr.add(row.get("proc_getbranchname")); }
			 */

			logger.info("Inside DBService :: getLongLat(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getLongLat Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error("Inside DBService :: getLongLat(String) method :: ",
					ae);
		}

		return listProduct;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getClaimDocs(String className, String arg)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List listProduct = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getSubAgentMaster Method"); }
			 */

			logger.info("Inside DBService :: getSubAgentMaster(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// rtoList =
			// session.createQuery("from SubAgentMaster where strintermediarycd = '"+arg+"'").list();

			// START : ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from proc_getclaimdoc(:ipacovertype)")
			 * .setParameter("ipacovertype", arg); listProduct =
			 * query.setResultTransformer(
			 * Transformers.aliasToBean(ClaimDocMaster.class)).list();
			 */

			Query query = session
					.createSQLQuery(
							"SELECT * from table(proc_getclaimdoc(:ipacovertype))")
					.addScalar("strdcodesc", StandardBasicTypes.STRING)
					.addScalar("strdoccd", StandardBasicTypes.STRING)
					// END : ADDED FOR ORACLE MIGRATION
					.setParameter("ipacovertype", arg);
			listProduct = query.setResultTransformer(
					Transformers.aliasToBean(ClaimDocMaster.class)).list();

			/*
			 * for (Iterator iterator = listProduct.iterator();
			 * iterator.hasNext();) { SubAgentMaster rtof =
			 * (SubAgentMaster)iterator.next(); }
			 */

			logger.info("Inside DBService :: getSubAgentMaster(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getSubAgentMaster Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getSecurityQuestion() method :: ", ae);
		}

		return listProduct;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getEmail(String arg, Integer arg1)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List listProduct = new ArrayList();
		List arr = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		Connection conn = null; // Added for oracle migration
		CallableStatement csmt = null; // Added for oracle migration
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getEmail(String,string) Method"); }
			 */

			logger.info("Inside DBService :: getEmail(String,string) method :: Execution Started");

			// Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// rtoList =
			// session.createQuery("from SubAgentMaster where strintermediarycd = '"+arg+"'").list();

			// START : CHANGES FOR ORACLE MIGRATION
			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from proc_getemail(:dealercode,:flag)")
			 * .setParameter("dealercode", arg) .setParameter("flag", arg1);
			 * listProduct =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */
			conn = getConnForCollableStmt(session);
			csmt = conn.prepareCall("{?=call proc_getemail(?,?) }");
			csmt.registerOutParameter(1, Types.VARCHAR);
			csmt.setString(2, arg);
			csmt.setInt(3, arg1);
			csmt.execute();
			String strExtCode = csmt.getString(1);

			// listProduct =
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();

			/*
			 * for (Object obj : listProduct) {
			 * 
			 * Map row = (Map) obj; arr.add(row.get("proc_getemail")); }
			 */
			arr.add(strExtCode);
			logger.info("Inside proc_getemail : EMAIL ID ::" + strExtCode);

			// END : CHANGES FOR ORACLE MIGRATION
			logger.info("Inside DBService :: getEmail(String,string) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getEmail(String,string) Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getSecurityQuestion() method :: ", ae);
		}

		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION

		// return arr.get(0).toString(); // Commented for oracle migration
		return arr.toString(); // added for oracle migration
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getContactno(String arg)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List listProduct = new ArrayList();
		// List arr = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getContactno(String) Method"); }
			 */

			logger.info("Inside DBService :: getContactno(String) method :: Execution Started");

			// Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// rtoList =
			// session.createQuery("from SubAgentMaster where strintermediarycd = '"+arg+"'").list();

			// START : CHANGES FOR ORACLE MIGRATION

			/*
			 * Query query =
			 * session.createSQLQuery("SELECT * from proc_contactno(:dealercode)"
			 * ) .setParameter("dealercode", arg); listProduct =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			Query query = session
					.createSQLQuery(
							"SELECT * from table(proc_contactno(:dealercode))")
					.addScalar("nisdno", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("nstdno", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("strcontactdtl", StandardBasicTypes.STRING)
					.addScalar("telephone", StandardBasicTypes.STRING)

					// END : CHANGES FOR ORACLE MIGRATION
					.setParameter("dealercode", arg);
			listProduct = query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			/*
			 * for (Object obj: listProduct){
			 * 
			 * Map row = (Map)obj; arr.add(row.get(0)); }
			 */

			logger.info("Inside DBService :: getContactno(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getContactno(String) Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error("Inside DBService :: getContactno(String) method :: ",
					ae);
		}

		return listProduct;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getProducerDet(String arg)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List listProduct = new ArrayList();
		// List arr = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getProducerDet(String) Method"); }
			 */

			logger.info("Inside DBService :: getProducerDet(String) method :: Execution Started");

			// Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// rtoList =
			// session.createQuery("from SubAgentMaster where strintermediarycd = '"+arg+"'").list();

			// START : CHANGES FOR ORACLE MIGRATION
			/*
			 * Query query =
			 * session.createSQLQuery("SELECT * from proc_producerdet(:dealercode)"
			 * ) .setParameter("dealercode", arg); listProduct =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"SELECT * from table(proc_producerdet(:dealercode))")
					.addScalar("strintermediarycd", StandardBasicTypes.STRING)
					.addScalar("strintermediaryname", StandardBasicTypes.STRING)
					.addScalar("stralternatecd", StandardBasicTypes.STRING)
					.addScalar("strissubproducer", StandardBasicTypes.STRING)
					.addScalar("nyndealer", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("strissuingcompanycd", StandardBasicTypes.STRING)
					.addScalar("nofficecd", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("strlicenseno", StandardBasicTypes.STRING)
					.addScalar("strchanneltype", StandardBasicTypes.STRING)
					.addScalar("strchannelname", StandardBasicTypes.STRING)
					.addScalar("strpanno", StandardBasicTypes.STRING)
					.addScalar("strintermediarystatus",
							StandardBasicTypes.STRING)
					.addScalar("nintermediarystatus",
							StandardBasicTypes.BIG_DECIMAL)
					.addScalar("strstatus", StandardBasicTypes.STRING)
					.addScalar("strapprovalstatus", StandardBasicTypes.STRING)
					.addScalar("dtstatusefectivedt", StandardBasicTypes.DATE)
					.addScalar("dtlicenseexpiry", StandardBasicTypes.DATE)
					.addScalar("dtlicenseeff", StandardBasicTypes.DATE)
					.addScalar("txt_telephone", StandardBasicTypes.STRING)
					.addScalar("txt_email", StandardBasicTypes.STRING)
					.addScalar("txt_alt_email_id", StandardBasicTypes.STRING)

					// END : CHANGES FOR ORACLE MIGRATION
					.setParameter("dealercode", arg);
			listProduct = query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			/*
			 * for (Object obj: listProduct){
			 * 
			 * Map row = (Map)obj; arr.add(row.get(0)); }
			 */

			logger.info("Inside DBService :: getProducerDet(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getProducerDet(String) Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getProducerDet(String) method :: ", ae);
		}

		return listProduct;
	}

	// @SuppressWarnings({ "rawtypes", "unchecked" })
	// public List<? extends Object> getReports(String className) throws
	// ClassNotFoundException, InstantiationException, IllegalAccessException{
	// //List<ReportsMaster> rtoList = new ArrayList<ReportsMaster>();
	// List<ReportsMaster> rtoList = new ArrayList<ReportsMaster>();
	// Session session = null;
	// Transaction transaction =null;
	// List listProduct = new ArrayList();
	// try
	// {
	// if(logger.isDebugEnabled()){
	// logger.debug("In DBService.getReports Method");
	// }
	//
	// logger.info("Inside DBService :: getReports(String) method :: Execution Started");
	//
	// Class classInstance = Class.forName(className);
	// session = transactionManager.getSessionFactory().getCurrentSession();
	// transaction = session.getTransaction();
	// if(!transaction.isActive()){
	// session.beginTransaction();
	// }
	//
	// //rtoList =
	// session.createQuery("select strofficedesc || '('||strofficecd ||')' Office,nofficecd,nparentofficecd,strofficedesc,strofficecd,strparentofficecd from OfficeMaster").list();
	// /*
	// for (Iterator iterator = rtoList.iterator(); iterator.hasNext();)
	// {
	// OfficeMaster rtof = (OfficeMaster)iterator.next();
	// }*/
	//
	// // Query query =
	// session.createSQLQuery("SELECT * from dcf_master.func_dcf_reports_m()");
	// //
	// //query.setResultTransformer(Transformers.aliasToBean(GarageCityMaster.class));
	// // query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
	// //
	// //query.setResultTransformer(Transformers.aliasToBean(ReportsMaster.class));
	// //
	// // rtoList = query.list();
	//
	// rtoList = session.createQuery("from ReportsMaster").list();
	//
	// // if(rtoList!=null && !rtoList.isEmpty()){
	// // System.out.println("value:***** "+rtoList.get(0));
	// // System.out.println("value:XXXXXX "+rtoList.get(0).toString());
	// // }
	// logger.info("Inside DBService :: getReports(String) method :: Execution Completed Successfully");
	//
	// if(logger.isDebugEnabled()){
	// logger.debug("Out DBService.getReports Method");
	// }
	// transaction.commit();
	// }
	// catch(Exception ae)
	// {
	// logger.error("Inside DBService :: getGarageCityMaster(String) method :: ",ae);
	// }
	//
	// return rtoList;
	// }

	/*
	 * this method returns product code and product name
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getReports(String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<ReportsMaster> reportList = new ArrayList<ReportsMaster>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getReports Method"); }
			 */

			logger.info("Inside DBService :: getReports method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			reportList = session.createQuery("from ReportsMaster").list();

			for (Iterator iterator = reportList.iterator(); iterator.hasNext();) {
				ReportsMaster reports1 = (ReportsMaster) iterator.next();

				// System.out.println("test............"+country1.getStrcountrycd());
			}

			logger.info("Inside DBService :: getReports method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getReports Method"); }
			 */
			transaction.commit();
			return reportList;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getReports method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getReports method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return reportList;
	}

	/*-----------------------Added by Nikhil570154 till here-------------------*/
	public int nullCheckInt(Object obj) {
		if (obj == null)
			return 0;
		else
			return (int) obj;
	}

	public double nullCheckDouble(Object obj) {
		if (obj == null)
			return 0.0;
		else
			return (double) obj;
	}

	public String nullCheckString(Object obj) {
		if (obj == null)
			return "";
		else
			return (String) obj;
	}

	public String saveQuickQuot(QuotationPA quotationPA) {

		String quotationNo = null;
		Session session = null;
		Transaction transaction = null;
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.saveOrUpdate Method"); }
		 */

		logger.info("Inside DBService :: saveOrUpdate method :: Execution Started");

		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			session.saveOrUpdate(quotationPA);
			quotationNo = quotationPA.getQuoteNumber();
			transaction.commit();
		} catch (Exception e) {
			logger.error("In DBService :: saveOrUpdate error ::", e);
			transaction.rollback();
			// TODO Auto-generated catch block
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("DBService.saveOrUpdate catch block"); }
			 */
			e.printStackTrace();
		}
		return quotationNo;
	}

	// finally{
	// if (session.isOpen()) {
	// session.close();
	// }
	// }

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getExternalMapCode(String className, String paramCode,
			String paramCatg) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {

		String strExtCode = null;
		Session session = null;
		Transaction transaction = null;
		Connection conn = null; // Added for oracle migration
		CallableStatement csmt = null; // Added for oracle migration
		List result = null;
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getExternalMapCode :: paramCode="
					+ paramCode + ",paramCatg=" + paramCatg);
			// START : CHANGES FOR ORACLE MIGRATION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_getextdatamap(:_paramcatg,:_paramcode)")
			 * .setParameter("_paramcatg", paramCatg)
			 * .setParameter("_paramcode", paramCode);
			 * result=query.setResultTransformer
			 * (Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */
			conn = this.getConnForCollableStmt(session);
			csmt = conn.prepareCall("{?=call func_getextdatamap(?,?) }");
			csmt.registerOutParameter(1, Types.VARCHAR);
			csmt.setString(2, paramCatg);
			csmt.setString(3, paramCode);
			csmt.execute();
			strExtCode = csmt.getString(1);

			/*
			 * if (result != null) { HashMap<String, String> resultMap = new
			 * HashMap<String, String>(); resultMap = (HashMap) result.get(0);
			 * if (resultMap.get("func_getextdatamap") != null) { strExtCode =
			 * (String) resultMap.get("func_getextdatamap"); } }
			 */

			// END : CHANGES FOR ORACLE MIGRATION
			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getExternalMapCode ::", ex);
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		return strExtCode;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ArrayList getAdonPremiumPA(String classname,
			CalculatorPARequest clacpareq, ArrayList arr)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		logger.info("Inside DBService :: getPremiumPA method :: Execution Started");

		int check = 0;
		double premaddon = 0;
		StringBuilder buildQuery = new StringBuilder();
		Session session = null;
		Transaction transaction = null;
		try {
			Class classInstance = Class.forName(classname);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			buildQuery.append("select npremium_addon");

			// buildQuery.append(" from dcf_master.dcf_pa_prm where "); //
			// Commented for oracle migration
			buildQuery.append(" from dcf_pa_prm where "); // Added for oracle
															// migration

			if (clacpareq.getProductcd() != null
					&& clacpareq.getProductcd() != "" && check == 0) {
				check = 1;
				buildQuery.append("strprodcd = :productcd ");
			} else if (clacpareq.getProductcd() != null
					&& clacpareq.getProductcd() != "" && check == 1) {
				buildQuery.append("and strprodcd = :productcd ");
			}

			if (clacpareq.getInsuranceFor() != null
					&& clacpareq.getInsuranceFor() != "" && check == 0) {
				check = 1;
				buildQuery.append("strcovertype = :insurancefor ");
			} else if (clacpareq.getInsuranceFor() != null
					&& clacpareq.getInsuranceFor() != "" && check == 1) {
				buildQuery.append("and strcovertype = :insurancefor ");
			}

			if (clacpareq.getPlantype() != null
					&& clacpareq.getPlantype() != "" && check == 0) {
				check = 1;
				buildQuery.append("strplan = :plantype ");
			} else if (clacpareq.getPlantype() != null
					&& clacpareq.getPlantype() != "" && check == 1) {
				buildQuery.append("and strplan = :plantype ");
			}

			if (clacpareq.getSumAssured() != null
					&& clacpareq.getSumAssured() != "" && check == 0) {
				check = 1;
				buildQuery.append("nsa = :sumassured ");
			} else if (clacpareq.getSumAssured() != null
					&& clacpareq.getSumAssured() != "" && check == 1) {
				buildQuery.append("and nsa = :sumassured ");
			}

			if (clacpareq.getTenure() != null && clacpareq.getTenure() != ""
					&& check == 0) {
				check = 1;
				buildQuery.append("ntenure = :tenure ");
			} else if (clacpareq.getTenure() != null
					&& clacpareq.getTenure() != "" && check == 1) {
				buildQuery.append("and ntenure = :tenure ");
			}

			if (clacpareq.getFamilySize() != null
					&& !(clacpareq.getFamilySize().equals("")) && check == 0) {
				check = 1;
				buildQuery.append("strfamilysize = :familysize ");
			} else if (clacpareq.getFamilySize() != null
					&& !(clacpareq.getFamilySize().equals("")) && check == 1) {
				buildQuery.append("and strfamilysize = :familysize ");
			}

			if (clacpareq.getBenperMonth() != null
					&& clacpareq.getBenperMonth() != "" && check == 0) {
				check = 1;
				buildQuery.append("nbenefitpermonth = :benpermonth ");
			} else if (clacpareq.getBenperMonth() != null
					&& clacpareq.getBenperMonth() != "" && check == 1) {
				buildQuery.append("and nbenefitpermonth = :benpermonth ");
			}

			if (clacpareq.getPayPeriod() != null
					&& !(clacpareq.getPayPeriod().equals("")) && check == 0) {
				check = 1;
				buildQuery.append("nnoofmonths = :payperiod ");
			} else if (clacpareq.getPayPeriod() != null
					&& !(clacpareq.getPayPeriod().equals("")) && check == 1) {
				buildQuery.append("and nnoofmonths = :payperiod ");
			}

			logger.info("Inside DBService :: getPremiumPA method :: buildQuery.toString() : "
					+ buildQuery.toString());

			Query query = session.createSQLQuery(buildQuery.toString())
					.addScalar("npremium_addon", StandardBasicTypes.DOUBLE); // Added
																				// for
																				// oracle
																				// migration
			if (clacpareq.getProductcd() != null
					&& clacpareq.getProductcd() != "") {
				query.setParameter("productcd", clacpareq.getProductcd());
			}
			if (clacpareq.getInsuranceFor() != null
					&& clacpareq.getInsuranceFor() != "") {
				query.setParameter("insurancefor", clacpareq.getInsuranceFor());
			}
			if (clacpareq.getPlantype() != null
					&& clacpareq.getPlantype() != "") {
				query.setParameter("plantype", clacpareq.getPlantype());
			}
			// START:10/10/2017:code changes for defect 2244 done by SAILESH
			if (clacpareq.getSumAssured() != null
					&& clacpareq.getSumAssured() != "") {
				query.setParameter("sumassured",
						Integer.parseInt(clacpareq.getSumAssured()));
			}
			// END
			if (clacpareq.getTenure() != null && clacpareq.getTenure() != "") {
				query.setParameter("tenure", clacpareq.getTenure());
			}
			if (clacpareq.getFamilySize() != null
					&& !(clacpareq.getFamilySize().equals(""))) {
				query.setParameter("familysize", clacpareq.getFamilySize());
			}
			if (clacpareq.getBenperMonth() != null
					&& clacpareq.getBenperMonth() != "") {
				query.setParameter("benpermonth", clacpareq.getBenperMonth());
			}
			if (clacpareq.getPayPeriod() != null
					&& !(clacpareq.getPayPeriod().equals(""))) {
				query.setParameter("payperiod", clacpareq.getPayPeriod());
			}

			List retList = query.list();
			logger.info("Inside DBService :: getPremiumPA method :: Size Of list : "
					+ retList.size());

			if (retList != null) {
				Object lst = retList.get(0);

				premaddon = (Double) lst;
			}

			arr.add(premaddon);
			transaction.commit();
			return arr;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getPremiumPA method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getPremiumPA method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		logger.info("Inside DBService :: getPremiumPA method :: Execution Completed Successfully");
		return arr;
	}

	// Start: RahulT Internal| function added to retrieve reverse mapping for
	// external codes

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getReverseExternalMapCode(String className, String paramCode,
			String paramDesc) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {

		String strExtCode = null;
		Session session = null;
		Transaction transaction = null;
		List result = null;
		Connection conn = null; // Added for oracle migration
		CallableStatement csmt = null; // Added for oracle migration
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getReverseExternalMapCode :: paramCode="
					+ paramCode + ",_paramdesc=" + paramDesc);
			// START : CHANGES FOR ORACLE MIGRATION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_getextdata_reversemap(:_paramcatg,:_paramdesc)"
			 * ) .setParameter("_paramcatg", paramCode)
			 * .setParameter("_paramdesc", paramDesc);
			 * result=query.setResultTransformer
			 * (Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			conn = this.getConnForCollableStmt(session);
			csmt = conn
					.prepareCall("{?=call func_getextdata_reversemap(?,?) }");
			csmt.registerOutParameter(1, Types.VARCHAR);
			csmt.setString(2, paramCode);
			csmt.setString(3, paramDesc);
			csmt.execute();
			strExtCode = csmt.getString(1);
			/*
			 * if (result != null) { HashMap<String, String> resultMap = new
			 * HashMap<String, String>(); resultMap = (HashMap) result.get(0);
			 * if (resultMap.get("func_getextdata_reversemap") != null) {
			 * strExtCode = (String) resultMap
			 * .get("func_getextdata_reversemap"); } }
			 */

			// END : CHANGES FOR ORACLE MIGRATION
			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getReverseExternalMapCode ::", ex);
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		logger.info("DBService :: getReverseExternalMapCode :: paramCode="
				+ paramCode + " :: _paramdesc=" + paramDesc + "::strExtCode="
				+ strExtCode);
		return strExtCode;
	}

	// End: RahulT Internal| function added to retrieve reverse mapping for
	// external codes
	/*
	 * this method returns city list or district list
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap getVehUseSubClass(String className, String paramValue)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.getVehUseSubClass Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		String subclassdesc = null;
		String subclasscatg = null;
		String vehicleclasscode = null;
		String vehiclesubclasscode = null;
		HashMap<String, String> subClassMap = new HashMap<String, String>();

		logger.info("Inside DBService :: getVehUseSubClass(String) method :: Execution Started");
		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			// criteria.add(Restrictions.eq("strvehiclesubclassdesc",paramValue));
			criteria.add(Restrictions.eq("strvehiclesubclasscd", paramValue));

			List subList = criteria.list();

			if (subList != null && subList.size() > 0) {
				logger.info("Inside DBService :: getVehUseSubClass() method :: Size Of list : "
						+ subList.size());
				for (Iterator iterator = subList.iterator(); iterator.hasNext();) {
					VehicleSubClass sbcls = (VehicleSubClass) iterator.next();

					subclassdesc = sbcls.getStrvehiclesubclassdesc() == null ? ""
							: sbcls.getStrvehiclesubclassdesc().toString();
					subclasscatg = sbcls.getStrsubclasscategory() == null ? ""
							: sbcls.getStrsubclasscategory().toString();
					vehicleclasscode = sbcls.getStrvehicleclasscd() == null ? ""
							: sbcls.getStrvehicleclasscd().toString();
					vehiclesubclasscode = sbcls.getStrvehiclesubclasscd() == null ? ""
							: sbcls.getStrvehiclesubclasscd().toString();
				}
			} else {
				subclassdesc = "";
				subclasscatg = "";
				vehicleclasscode = "";
				vehiclesubclasscode = "";
				logger.info("Inside DBService :: getVehUseSubClass() method :: Size Of list : "
						+ subList.size());
				logger.info("Inside DBService :: getVehUseSubClass() method ::  All Values Are Blank......");
			}

			subClassMap.put("subclassdesc", subclassdesc);
			subClassMap.put("subclasscatg", subclasscatg);
			subClassMap.put("vehicleclasscode", vehicleclasscode);
			subClassMap.put("vehiclesubclasscode", vehiclesubclasscode);

			logger.info("Inside DBService :: getVehUseSubClass(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getVehUseSubClass Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getVehUseSubClass(String) method :: ",
					ae);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return subClassMap;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getQuotationDtlList(String className,
			List<String> paramName, List<Object> paramValue)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<QuotationPA1> retList = null;
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getList Method"); }
			 */

			logger.info("Inside DBService :: getQuotationDtlList(String, List<String>, List<Object>) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			for (int index = 0; index < paramName.size(); index++) {
				if (paramName.equals(CommonConstants.CREATED_DATE)) {
					criteria.add(Restrictions.gt(paramName.get(index),
							paramValue.get(index)));
				}
				criteria.add(Restrictions.eq(paramName.get(index),
						paramValue.get(index)));
			}
			retList = criteria.list();

			logger.info("Inside DBService :: getQuotationDtlList(String, List<String>, List<Object>) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getQuotationDtlList Method"); }
			 */
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
			logger.error(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
		}
		return retList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getCodeDesc(String className, String paramCode,
			String paramCatg, String paramType) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {

		String strCodeDesc = null;
		Session session = null;
		Transaction transaction = null;
		List result = null;
		Connection conn = null; // ADDED FOR ORACLE MIGRATION
		CallableStatement csmt = null; // ADDED FOR ORACLE MIGRATION
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getCodeDesc :: paramCode=" + paramCode
					+ " ::paramCatg=" + paramCatg + "::paramType=" + paramType);
			Integer iparamCat = new Integer(paramCatg);
			// START : CHANGES FOR ORACLE MIGRATION
			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_getcodedesc(:_paramcatg,:_paramcode,:_paramtype)"
			 * ) .setParameter("_paramcatg", iparamCat)
			 * .setParameter("_paramcode", paramCode)
			 * .setParameter("_paramtype", paramType);
			 * result=query.setResultTransformer
			 * (Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			conn = this.getConnForCollableStmt(session);
			csmt = conn.prepareCall("{?=call func_getcodedesc(?,?,?) }");
			csmt.registerOutParameter(1, Types.VARCHAR);
			csmt.setInt(2, iparamCat);
			csmt.setString(3, paramCode);
			csmt.setString(4, paramType);
			csmt.execute();
			strCodeDesc = csmt.getString(1);

			/*
			 * Query query = (Query) session .createSQLQuery(
			 * "SELECT * from table(func_getcodedesc(:paramcatg,:paramcode,:paramtype))"
			 * ) .setParameter("paramcatg", iparamCat)
			 * .setParameter("paramcode", paramCode) .setParameter("paramtype",
			 * paramType);
			 */
			// result = query.list();

			// List list = (List)
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			/*
			 * if (result != null) { HashMap<String, String> resultMap = new
			 * HashMap<String, String>(); resultMap = (HashMap) result.get(0);
			 * if (resultMap.get("func_getcodedesc") != null) { strCodeDesc =
			 * (String) resultMap.get("func_getcodedesc"); } }
			 */

			// END : CHANGES FOR ORACLE MIGRATION

			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getCodeDesc ::", ex);
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		return strCodeDesc;
	}

	// Start: RahulT Internal| function added to retrieve config parameter value
	public String getConfigParamVal(String paramKey) {
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		List result = null;
		Connection conn = null; // ADDED FOR ORACLE MIGRATION
		CallableStatement csmt = null; // ADDED FOR ORACLE MIGRATION
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getConfigParamVal :: paramKey= "
					+ paramKey);

			// START : CHANGES FOR ORACLE MIGRATION

			/*
			 * Query query = session .createSQLQuery(
			 * "SELECT * from func_getconfig_param_val(:_paramKey)")
			 * .setParameter("_paramKey", paramKey); result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP) .list();
			 */
			conn = this.getConnForCollableStmt(session);
			csmt = conn.prepareCall("{?=call func_getconfig_param_val(?) }");
			csmt.registerOutParameter(1, Types.VARCHAR);
			csmt.setString(2, paramKey);
			csmt.execute();
			strParamVal = csmt.getString(1);

			/*
			 * Query query = (Query) session.createSQLQuery(
			 * "SELECT * from table(func_getconfig_param_val(:paramKey))")
			 * .setParameter("paramKey", paramKey); //result = query.list();
			 * result = (List)
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			/*
			 * if (result != null) { HashMap<String, String> resultMap = new
			 * HashMap<String, String>(); resultMap = (HashMap) result.get(0);
			 * if (resultMap.get("func_getconfig_param_val") != null) {
			 * strParamVal = (String) resultMap
			 * .get("func_getconfig_param_val"); } }
			 */
			// END : CHANGES FOR ORACLE MIGRATION
			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getConfigParamVal ::", ex);
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		logger.info("DBService :: getConfigParamVal :: paramKey=" + paramKey
				+ " :: _paramvalue=" + strParamVal);
		return strParamVal;
	}

	// End: RahulT Internal| function added to retrieve config parameter value

	public HashMap getCityWhereVehPrimarilyUsed(String paramKey) {
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		List result = new ArrayList();
		HashMap<String, String> resultMap = new HashMap<String, String>();
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getCityWhereVehPrimarilyUsed :: paramkey= "
					+ paramKey);
			// START : CODE CHANGES FOR ORACLE MIGRATION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_getcity_primarily_used_val(:_paramkey)"
			 * ).setParameter("_paramkey", paramKey);
			 * //List<PrimarilyUsedVehicle> primResult =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 * result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			Query query = (Query) session
					.createSQLQuery(
					// "SELECT * from table(func_getcity_primarily_used_val(:paramkey))")
					// // COMMENTED FOR ORACLE MIGRATION
							"SELECT * from table(func_getcity_primrily_used_val(:paramkey))")
					// ADDED FOR ORACLE MIGRATION
					.addScalar("city_flag", StandardBasicTypes.STRING)
					.addScalar("citycd", StandardBasicTypes.STRING)
					.addScalar("city_name", StandardBasicTypes.STRING)
					.addScalar("parent_cd", StandardBasicTypes.BIG_DECIMAL)
					.addScalar("dist_flag", StandardBasicTypes.STRING)
					.addScalar("distrcit_cd", StandardBasicTypes.STRING)
					.addScalar("dist_name", StandardBasicTypes.STRING)
					.addScalar("rtodistrictcd", StandardBasicTypes.STRING)
					.addScalar("rtocitycd", StandardBasicTypes.STRING)
					.addScalar("rtolocationcd", StandardBasicTypes.STRING)
					.addScalar("rtoregistrationcd", StandardBasicTypes.STRING)
					.addScalar("rtolocationdesc", StandardBasicTypes.STRING)

					.setParameter("paramkey", paramKey);

			// END : CODE CHANGES FOR ORACLE MIGRATION
			result = query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
					.list();

			if (result != null && result.size() > 0) {

				resultMap = (HashMap) result.get(0);

				// Do Not Delete Commented..... Use below key to retrieve
				// value..............................
				// resultMap.put("city_flag",
				// primarilyUsedVehicle.getCity_flag());
				// resultMap.put("city_name",
				// primarilyUsedVehicle.getCity_name());
				// resultMap.put("citycd", primarilyUsedVehicle.getCitycd());
				// resultMap.put("dist_flag",
				// primarilyUsedVehicle.getDist_flag());
				// resultMap.put("dist_name",
				// primarilyUsedVehicle.getDist_name());
				// resultMap.put("distrcit_cd",
				// primarilyUsedVehicle.getDistrcit_cd());
				// resultMap.put("rtocitycd",
				// primarilyUsedVehicle.getRtocitycd());
				// resultMap.put("rtodistrictcd",
				// primarilyUsedVehicle.getRtodistrictcd());
				// resultMap.put("rtolocationcd",
				// primarilyUsedVehicle.getRtolocationcd());
				// resultMap.put("rtolocationdesc",
				// primarilyUsedVehicle.getRtolocationdesc());
				// resultMap.put("rtoregistrationcd",
				// primarilyUsedVehicle.getRtoregistrationcd());
				// resultMap.put("parent_cd",
				// ""+primarilyUsedVehicle.getParent_cd());
				//
			}

			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getCityWhereVehPrimarilyUsed ::", ex);
		}
		logger.info("DBService :: getCityWhereVehPrimarilyUsed :: result="
				+ result.toString());
		return resultMap;
	}

	// Start: Added to get PGTransaction table

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap getOLTransaction(String className, String paramName,
			String paramValue) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List subCatList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		List result = new ArrayList();
		HashMap<String, String> resultVal = new HashMap<String, String>();

		logger.info("Inside DBService :: getOLTransaction(String, String, String) method :: Execution Started");
		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_get_transaction_dtl(:_paramkey)"
			 * ).setParameter("_paramkey", paramValue); //result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 * result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"SELECT * from table(func_get_transaction_dtl(:paramkey))")
					.addScalar("txnmodeval", StandardBasicTypes.STRING)
					.addScalar("txnmode", StandardBasicTypes.STRING)
					.setParameter("paramkey", paramValue);
			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			result = query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
					.list();

			if (logger.isDebugEnabled()) {
				logger.debug("In DBService.getBilldeskStgDtl Method sql-- "
						+ query);
			}

			if (result != null && result.size() > 0) {
				resultVal = (HashMap) result.get(0);
			}

			logger.info("Inside DBService :: getOLTransaction(String, String, String) method :: Execution Completed Successfully");

			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getOLTransaction(String, String, String) method :: ",
					ae);
		}

		return resultVal;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap getBilldeskStgDtl(String className, String paramName,
			String paramValue) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List subCatList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		Connection conn = null; // Added for oracle migration
		CallableStatement csmt = null; // Added for oracle migration
		List result = new ArrayList();
		HashMap<String, String> resultVal = new HashMap<String, String>();

		logger.info("Inside DBService :: func_get_online_acc_service_dtl(String, String, String) method :: Execution Started");
		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_get_online_acc_service_dtl(:_paramkey)"
			 * ).setParameter("_paramkey", paramValue); //result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 * result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */
			conn = this.getConnForCollableStmt(session);
			csmt = conn.prepareCall("{?=call func_get_ol_acc_service_dtl(?) }");
			csmt.registerOutParameter(1, Types.VARCHAR);
			csmt.setString(2, paramValue);
			csmt.execute();
			resultVal.put("func_get_online_acc_service_dtl", csmt.getString(1));

			if (logger.isDebugEnabled()) {
				logger.debug("In DBService.getBilldeskStgDtl Method sql-- "
						+ csmt);
			}

			/*
			 * if (result != null && result.size() > 0) { resultVal = (HashMap)
			 * result.get(0); }
			 */
			// END : CHANGES FOR ORACLE MIGRATION
			logger.info("Inside DBService :: getBilldeskStgDtl(String, String, String) method :: Execution Completed Successfully");

			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getBilldeskStgDtl(String, String, String) method :: ",
					ae);
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		return resultVal;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap getPayLinkDtl(String className, String paramName,
			String paramValue) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List subCatList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		List result = new ArrayList();
		HashMap resultVal = new HashMap();

		logger.info("Inside DBService :: getPayLinkDtl(String, String, String) method :: Execution Started");
		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_get_paylink_dtl(:_paramkey)"
			 * ).setParameter("_paramkey", paramValue); //result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 * result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"SELECT * from table(func_get_paylink_dtl(:paramkey))")
					.addScalar("customerid", StandardBasicTypes.STRING)
					.addScalar("proppolnbr", StandardBasicTypes.STRING)
					.addScalar("transamount", StandardBasicTypes.STRING)
					.addScalar("endtime", StandardBasicTypes.TIMESTAMP)
					.addScalar("paylinkused", StandardBasicTypes.STRING)
					.addScalar("productcd", StandardBasicTypes.STRING)
					.addScalar("createdby", StandardBasicTypes.STRING)
					.addScalar("producercd", StandardBasicTypes.STRING)
					.addScalar("producername", StandardBasicTypes.STRING)
					.addScalar("isrenew", StandardBasicTypes.STRING)
					.addScalar("dtcreated", StandardBasicTypes.STRING)

					.setParameter("paramkey", paramValue);

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION

			// result = query.list();

			result = (List) query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			if (logger.isDebugEnabled()) {
				logger.debug("In DBService.getPayLinkDtl Method sql-- " + query);
			}

			if (result != null && result.size() > 0) {
				resultVal = (HashMap) result.get(0);
			}

			logger.info("Inside DBService :: getPayLinkDtl(String, String, String) method :: Execution Completed Successfully");

			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getPayLinkDtl(String, String, String) method :: ",
					ae);
		}

		return resultVal;
	}

	// End: RahulT

	// Start: RahulT| added for IPA Quot search

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ArrayList searchIPAQuotationList(SearchIPAQuotRequest ipaQuotRequest)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<QuotationPA> quotationList = new ArrayList<QuotationPA>();
		Session session = null;
		Transaction transaction = null;
		StringBuilder query = new StringBuilder();
		int check = 0;
		ArrayList<Object[]> retList = new ArrayList();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.searchIPAQuotationList Method"); }
			 */

			logger.info("Inside DBService :: searchIPAQuotationList(String) method :: Execution Started");

			// RahulT: added for service tax rate calculations
			String strParamVal = this.getConfigParamVal("QUOT_VALID_ADAYS");
			int quot_valid_days = new Integer(strParamVal);
			// RahulT: added for service tax rate calculations

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			query.append("select strquotnumber,stremail,firstname,lastname,strmobile,strplancode,strproductcode,strcustomerid, COALESCE(to_char(dtcreated, 'yyyy-MM-dd HH:mm:ss'), '') as dtcreated ,strdob");

			query.append(" from dcf_quotation_dtl where ");

			if (ipaQuotRequest.getQuotationNo() != null
					&& ipaQuotRequest.getQuotationNo() != "" && check == 0) {
				check = 1;
				query.append("strquotnumber = :quotationno ");
			} else if (ipaQuotRequest.getQuotationNo() != null
					&& ipaQuotRequest.getQuotationNo() != "" && check == 1) {
				query.append("and strquotnumber = :quotationno ");
			}

			if (ipaQuotRequest.getCustomerCd() != null
					&& ipaQuotRequest.getCustomerCd() != "" && check == 0) {
				check = 1;
				query.append("strcustomerid = :customercd ");
			} else if (ipaQuotRequest.getCustomerCd() != null
					&& ipaQuotRequest.getCustomerCd() != "" && check == 1) {
				query.append("and strcustomerid = :customercd ");
			}

			if (ipaQuotRequest.getMobileNo() != null
					&& ipaQuotRequest.getMobileNo() != "" && check == 0) {
				check = 1;
				query.append("strmobile = :mobileno ");
			} else if (ipaQuotRequest.getMobileNo() != null
					&& ipaQuotRequest.getMobileNo() != "" && check == 1) {
				query.append("and strmobile = :mobileno ");
			}

			if (ipaQuotRequest.getEmailId() != null
					&& ipaQuotRequest.getEmailId() != "" && check == 0) {
				check = 1;
				query.append("stremail = :emailid ");
			} else if (ipaQuotRequest.getEmailId() != null
					&& ipaQuotRequest.getEmailId() != "" && check == 1) {
				query.append("and stremail = :emailid ");
			}

			if (ipaQuotRequest.getProductCode() != null
					&& ipaQuotRequest.getProductCode() != "" && check == 0) {
				check = 1;
				query.append("strproductcode = :productcode ");
			} else if (ipaQuotRequest.getProductCode() != null
					&& ipaQuotRequest.getProductCode() != "" && check == 1) {
				query.append("and strproductcode = :productcode ");
			}
			if (ipaQuotRequest.getDtBirth() != null
					&& ipaQuotRequest.getDtBirth() != "" && check == 0) {
				check = 1;
				query.append("strdob = :dob ");
				// query.append("strdob = '"+ipaQuotRequest.getDtBirth()+"' ");
			} else if (ipaQuotRequest.getDtBirth() != null
					&& ipaQuotRequest.getDtBirth() != "" && check == 1) {
				query.append("and strdob = :dob ");
				// query.append("and strdob = '"+ipaQuotRequest.getDtBirth()+"' ");
			}

			query.append(" and dtcreated > current_date - interval '"
					+ quot_valid_days + "' day "); // code added to fetch
													// quotation of last 30 days

			query.append(" and strproposalnumber is null "); // code added to
																// fetch
																// quotation of
																// last 30 days

			logger.info("Inside DBService :: getPremiumPA method :: buildQuery.toString() : "
					+ query.toString());

			// START : ADDED FOR ORACLE MIGRATION
			SQLQuery sqlQuery = session.createSQLQuery(query.toString())

			.addScalar("strquotnumber", StandardBasicTypes.STRING)
					.addScalar("stremail", StandardBasicTypes.STRING)
					.addScalar("firstname", StandardBasicTypes.STRING)
					.addScalar("lastname", StandardBasicTypes.STRING)
					.addScalar("strmobile", StandardBasicTypes.STRING)
					.addScalar("strplancode", StandardBasicTypes.STRING)
					.addScalar("strproductcode", StandardBasicTypes.STRING)
					.addScalar("strcustomerid", StandardBasicTypes.STRING)
					.addScalar("dtcreated", StandardBasicTypes.TIMESTAMP);

			// END : ADDED FOR ORACLE MIGRATION

			if (ipaQuotRequest.getQuotationNo() != null
					&& ipaQuotRequest.getQuotationNo() != "") {
				sqlQuery.setParameter("quotationno",
						ipaQuotRequest.getQuotationNo());
			}
			if (ipaQuotRequest.getCustomerCd() != null
					&& ipaQuotRequest.getCustomerCd() != "") {
				sqlQuery.setParameter("customercd",
						ipaQuotRequest.getCustomerCd());
			}
			if (ipaQuotRequest.getMobileNo() != null
					&& ipaQuotRequest.getMobileNo() != "") {
				sqlQuery.setParameter("mobileno", ipaQuotRequest.getMobileNo());
			}
			if (ipaQuotRequest.getEmailId() != null
					&& ipaQuotRequest.getEmailId() != "") {
				sqlQuery.setParameter("emailid", ipaQuotRequest.getEmailId());
			}
			if (ipaQuotRequest.getProductCode() != null
					&& ipaQuotRequest.getProductCode() != "") {
				sqlQuery.setParameter("productcode",
						ipaQuotRequest.getProductCode());
			}
			if (ipaQuotRequest.getDtBirth() != null
					&& ipaQuotRequest.getDtBirth() != "") {
				sqlQuery.setParameter("dob", ipaQuotRequest.getDtBirth());
			}

			retList = (ArrayList) sqlQuery.list();

			logger.info("Inside DBService :: getPremiumPA method :: Size Of list : "
					+ retList.size());

			transaction.commit();
			return retList;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: searchIPAQuotationList:: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: searchIPAQuotationList method :: Exception Occurred..."
					+ e);
		}
		return retList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap getIPAQuotation(String quotationNo)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List subCatList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		List result = new ArrayList();
		HashMap resultVal = new HashMap();

		logger.info("Inside DBService :: getIPAQuotation(String, String, String) method :: quotationNo from UI "
				+ quotationNo);
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * Query query =
			 * session.createSQLQuery("SELECT * from get_ipa_quotation(:_paramkey)"
			 * ).setParameter("_paramkey", quotationNo); //result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 * result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"SELECT * from table(get_ipa_quotation(:paramkey))")
					.addScalar("quotenumber", StandardBasicTypes.STRING)
					.addScalar("email", StandardBasicTypes.STRING)
					.addScalar("firstname", StandardBasicTypes.STRING)
					.addScalar("lastname", StandardBasicTypes.STRING)
					.addScalar("plancode", StandardBasicTypes.STRING)
					.addScalar("productcode", StandardBasicTypes.STRING)
					.addScalar("customerid", StandardBasicTypes.STRING)
					.addScalar("createddate", StandardBasicTypes.TIMESTAMP)
					.addScalar("requesttransdata", StandardBasicTypes.STRING)
					.addScalar("responsetransdata", StandardBasicTypes.STRING)

					.setParameter("paramkey", quotationNo);
			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			result = query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
					.list();

			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("In DBService.getIPAQuotation Method sql-- "+
			 * query); }
			 */

			if (result != null && result.size() > 0) {
				resultVal = (HashMap) result.get(0);
			}

			logger.info("Inside DBService :: getIPAQuotation method :: Execution Completed Successfully");

			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error("Inside DBService :: getIPAQuotation method :: ", ae);
		}

		return resultVal;
	}

	// End: RahulT| added for IPA Quot search list

	// Start: RahulT| user transaction changes
	public void updateUserTransForPolicy(String policyNo, String proposalNumber) {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.saveOrUpdate Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: saveOrUpdate method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Query query = session
					.createSQLQuery(" update dcf_user_trans_dtl set strpolnbr = :policyNumber"
							+ " where strpropnumber = :propNumber");
			query.setParameter("policyNumber", policyNo);
			query.setParameter("propNumber", proposalNumber);
			int result = query.executeUpdate();

			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: saveOrUpdate error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
	}

	// End: RahulT| user transaction changes

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getRole(String className)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<RoleEntity> roleEntityList = new ArrayList<RoleEntity>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("In DBService.getRole Method"); }
			 */

			logger.info("Inside DBService :: getRole method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			roleEntityList = session.createQuery("from RoleEntity").list();

			for (Iterator iterator = roleEntityList.iterator(); iterator
					.hasNext();) {
				RoleEntity roleEntity = (RoleEntity) iterator.next();

				// System.out.println("test............"+country1.getStrcountrycd());
			}

			logger.info("Inside DBService :: getReports method :: Execution Completed Successfully");

			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("Out DBService.getReports Method"); }
			 */
			transaction.commit();
			return roleEntityList;
		} catch (Exception e) {
			transaction.rollback();
			logger.error("Inside DBService :: getReports method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getReports method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return roleEntityList;
	}

	public void deleteUserRoleEntity(UserRoleList userRoleList)
			throws Exception {

		/*
		 * if (logger.isDebugEnabled()) {
		 * logger.debug("In DBService :: deleteEntity Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: deleteEntity method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// Query
			// query=session.createSQLQuery("delete from dcfum.dcf_tagic_user_role_map where struserid=:userid").setParameter("userid",
			// userRoleList.getRoleUserId()); // Commented for oracle migration
			Query query = session
					.createSQLQuery(
							"delete from dcf_tagic_user_role_map where struserid=:userid")
					.setParameter("userid", userRoleList.getRoleUserId()); // Added
																			// for
																			// oracle
																			// migration

			int nDeleteRec = query.executeUpdate();
			// session.delete(deleteEntity);
			transaction.commit();
		} catch (Exception e) {
			logger.error("In DBService :: deleteEntity error ::", e);
			transaction.rollback();
			// TODO Auto-generated catch block
			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("DBService :: deleteEntity catch block"); }
			 */

			e.printStackTrace();
		}
	}

	public FetchUserRoleList fetchUserRoleList(
			FetchUserRoleRequest fetchUserRoleReq) throws Exception {

		/*
		 * if (logger.isDebugEnabled()) {
		 * logger.debug("In DBService :: fetchUserRoleList Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		FetchUserRoleList userRoleList = null;
		String key = null;
		String value = null;
		int flag = 0;// 1272 : Added new temp ver
		ArrayList<RoleDetails> selectedRoles = new ArrayList<RoleDetails>();
		ArrayList<RoleDetails> availableRoles = new ArrayList<RoleDetails>();
		logger.info("Inside DBService :: fetchUserRoleList method :: Execution Started");
		String strMethodName = "fetchUserRoleList";
		try {
			userRoleList = new FetchUserRoleList();
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			userRoleList.setRoleUserId(fetchUserRoleReq.getRoleUserId());
			// Query
			// query=session.createSQLQuery("select strroleid from dcfum.dcf_tagic_role_m where strroleid not in (select strroleid from dcfum.dcf_tagic_user_role_map where struserid=:_userid)").setParameter("_userid",
			// fetchUserRoleReq.getRoleUserId());

			// List resultList=query.list();

			// List
			// resultList=query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
			// .list();

			// START : CHANGES ARE ADDED FOR ORACLE MIGRARION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_getuserrole_selected(:_userid)"
			 * ).setParameter("_userid", fetchUserRoleReq.getRoleUserId()); List
			 * list = query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
			 * .list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"SELECT * from table(func_getuserrole_selected(:userid))")
					.addScalar("strroleid", StandardBasicTypes.STRING)
					.addScalar("strroledesc", StandardBasicTypes.STRING)
					.setParameter("userid", fetchUserRoleReq.getRoleUserId());
			List list = (List) query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			// END : CHANGES ARE ADDED FOR ORACLE MIGRARION
			Iterator it = list.iterator();
			while (it.hasNext()) {
				HashMap<String, String> resultMap = (HashMap<String, String>) it
						.next();
				RoleDetails rolDet = new RoleDetails();
				if (resultMap.get("strroleid") != null) {
					value = (String) resultMap.get("strroleid");
					rolDet.setRoleId(value);
				}

				if (resultMap.get("strroledesc") != null) {
					value = (String) resultMap.get("strroledesc");
					rolDet.setRoleDesc(value);
				}

				selectedRoles.add(rolDet);
			}

			userRoleList.setSelectedRoles(selectedRoles);

			Query query1 = null;
			if (fetchUserRoleReq.getUserSubType() != null
					&& !fetchUserRoleReq.getUserSubType().equals(
							CommonConstants.BLANK_STRING)
					&& (fetchUserRoleReq.getUserSubType()
							.equalsIgnoreCase(CommonConstants.USER_SUBTYPE_PRODUCER))
					|| (fetchUserRoleReq.getUserSubType() != null && fetchUserRoleReq
							.getUserSubType().equalsIgnoreCase(
									CommonConstants.USER_SUBTYPE_DEALER))) {
				query1 = session
						.createSQLQuery(
						// START : CHANGES FOR ORACLE MIGRATION
								"SELECT * from table(func_getuserrole_selected(:userid))")
						.addScalar("strroleid", StandardBasicTypes.STRING)
						.addScalar("strroledesc", StandardBasicTypes.STRING)
						.setParameter("userid", fetchUserRoleReq.getUserID());
				// END : CHANGES FOR ORACLE MIGRATION
				logger.info("Inside ::" + service.getClass() + "::"
						+ strMethodName + ":: User Sub Type::"
						+ fetchUserRoleReq.getUserSubType());
			} else if (fetchUserRoleReq.getUserSubType() != null
					&& !fetchUserRoleReq.getUserSubType().equals(
							CommonConstants.BLANK_STRING)
					&& fetchUserRoleReq.getUserSubType().equalsIgnoreCase(
							CommonConstants.USER_SUBTYPE_PORTALADMIN)) {
				// START : CHANGES ARE ADDED FOR ORACLE MIGRATION
				/*
				 * query1 = session.createSQLQuery(
				 * "SELECT * from func_getuserrole_available(:_userid)")
				 * .setParameter("_userid", fetchUserRoleReq.getRoleUserId());
				 */

				query1 = session
						.createSQLQuery(
								"SELECT * from table(func_getuserrole_available(:userid))")
						.addScalar("strroleid", StandardBasicTypes.STRING)
						.addScalar("strroledesc", StandardBasicTypes.STRING)
						.setParameter("userid",
								fetchUserRoleReq.getRoleUserId());
				// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
				logger.info("Inside ::" + service.getClass() + "::"
						+ strMethodName + ":: Admin Sub Type::"
						+ fetchUserRoleReq.getUserSubType());
			} else {
				// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

				/*
				 * query1 = session.createSQLQuery(
				 * "SELECT * from func_getuserrole_available(:_userid)")
				 * .setParameter("_userid", fetchUserRoleReq.getRoleUserId());
				 */

				query1 = (Query) session
						.createSQLQuery(
								"SELECT * from table(func_getuserrole_available(:userid))")
						.addScalar("strroleid", StandardBasicTypes.STRING)
						.addScalar("strroledesc", StandardBasicTypes.STRING)
						.setParameter("userid",
								fetchUserRoleReq.getRoleUserId());

			}
			/*
			 * List list1 =
			 * query1.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
			 * .list();
			 */

			// List list1 = query1.list();
			List list1 = (List) query1.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			Iterator it1 = list1.iterator();
			while (it1.hasNext()) {
				HashMap<String, String> resultMap = (HashMap<String, String>) it1
						.next();
				RoleDetails rolDet = new RoleDetails();
				if (resultMap.get("strroleid") != null) {
					value = (String) resultMap.get("strroleid");
					rolDet.setRoleId(value);
				}

				if (resultMap.get("strroledesc") != null) {
					value = (String) resultMap.get("strroledesc");
					rolDet.setRoleDesc(value);
				}
				// if(logger.isDebugEnabled())
				logger.debug("Inside DBService :: fetchUserRoleList method :: Role ID Found !!!::"
						+ rolDet.getRoleId());
				// 1272 : VishalJ : Code added to restrict adding Selected
				// Privileges into Availaible Priv. : Start
				flag = 0;
				if (userRoleList != null
						&& userRoleList.getSelectedRoles() != null) {
					for (RoleDetails rolDet1 : userRoleList.getSelectedRoles()) {
						if (rolDet1.getRoleId().equals(rolDet.getRoleId()))
							flag = 1;
					}
				}
				if (flag != 1)
					availableRoles.add(rolDet);
				// 1272 : VishalJ : Code added to restrict adding Selected
				// Privileges into Availaible Priv. : End

			}

			FetchUserRoleList fetchUserRoleListCreatedBy = fetchUserRoleListCreatedBy(fetchUserRoleReq);
			if (fetchUserRoleListCreatedBy != null
					&& fetchUserRoleListCreatedBy.getAvailableRoles() != null
					&& fetchUserRoleListCreatedBy.getAvailableRoles().size() > 0) {
				ArrayList<RoleDetails> roleDetList = fetchUserRoleListCreatedBy
						.getAvailableRoles();

				for (RoleDetails roleDet1 : roleDetList) {
					// if(logger.isDebugEnabled())
					logger.debug("Inside DBService :: fetchUserRoleList method :: Role ID Found 123!!!::"
							+ roleDet1.getRoleId());
					if (roleDet1 != null) {
						// 1272 : VishalJ : Code added to restrict adding
						// Selected Privileges into Availaible Priv. : Start
						flag = 0;
						if (userRoleList != null
								&& userRoleList.getSelectedRoles() != null) {
							for (RoleDetails rolDet1 : userRoleList
									.getSelectedRoles()) {
								if (rolDet1.getRoleId().equals(
										roleDet1.getRoleId()))
									flag = 1;
							}
						}
						if (flag != 1)
							availableRoles.add(roleDet1);
						// 1272 : VishalJ : Code added to restrict adding
						// Selected Privileges into Availaible Priv. : End
					}
				}
			}
			logger.info("Inside DBService :: fetchUserRoleList method :: Role List Before::"
					+ availableRoles.size());
			Set<RoleDetails> roleDetSet = new HashSet<RoleDetails>();
			roleDetSet.addAll(availableRoles);

			availableRoles = new ArrayList<RoleDetails>();
			availableRoles.addAll(roleDetSet);
			logger.info("Inside DBService :: fetchUserRoleList method :: Role List after::"
					+ availableRoles.size());
			userRoleList.setAvailableRoles(availableRoles);

			if (!transaction.wasCommitted())
				transaction.commit();
			/*
			 * if (logger.isDebugEnabled()) { logger.debug(
			 * "DBService :: fetchUserRoleList :: After transaction commit !!!"
			 * ); }
			 */
		} catch (Exception e) {
			logger.error("In DBService :: FetchUserRoleList error ::", e);
			transaction.rollback();
			// TODO Auto-generated catch block
			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("DBService :: FetchUserRoleList catch block"); }
			 */

			e.printStackTrace();
		}

		return userRoleList;
	}

	public void deleteRolePrivEntity(RolePrivList rp) throws Exception {

		/*
		 * if (logger.isDebugEnabled()) {
		 * logger.debug("In DBService :: deleteEntity Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: deleteEntity method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// Query
			// query=session.createSQLQuery("delete from dcfum.DCF_ROLE_PRIV_MAP where strroleid=:roleid").setParameter("roleid",
			// rp.getRoleId()); // Commented for oracle migration
			Query query = session.createSQLQuery(
					"delete from DCF_ROLE_PRIV_MAP where strroleid=:roleid")
					.setParameter("roleid", rp.getRoleId()); // Added for oracle
																// migration

			int nDeleteRec = query.executeUpdate();
			// session.delete(deleteEntity);
			transaction.commit();
		} catch (Exception e) {
			logger.error("In DBService :: deleteEntity error ::", e);
			transaction.rollback();
			// TODO Auto-generated catch block
			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("DBService :: deleteEntity catch block"); }
			 */

			e.printStackTrace();
		}
	}

	public FetchRolePrivilegeList fetchRolePrivilegeList(
			FetchRolePrivilegeRequest fetchRolePrivilegeReq) throws Exception {

		Session session = null;
		Transaction transaction = null;
		FetchRolePrivilegeList rolePrivilegeList = null;
		String key = null;
		String value = null;
		ArrayList<PrivilegeDetails> selectedPrivileges = new ArrayList<PrivilegeDetails>();
		ArrayList<PrivilegeDetails> availablePrivileges = new ArrayList<PrivilegeDetails>();
		int flag = 0; // 1272 : VishalJ

		String strMethodName = "fetchRolePrivilegeList";
		try {
			logger.info("Inside DBService :: fetchRolePrivilegeList method :: Execution Started");
			// userRoleList=new FetchUserRoleList();
			rolePrivilegeList = new FetchRolePrivilegeList();
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// userRoleList.setRoleUserId(fetchUserRoleReq.getRoleUserId());
			rolePrivilegeList.setRoleId(fetchRolePrivilegeReq.getRoleId());
			// Query
			// query=session.createSQLQuery("select strroleid from dcfum.dcf_tagic_role_m where strroleid not in (select strroleid from dcfum.dcf_tagic_user_role_map where struserid=:_userid)").setParameter("_userid",
			// fetchUserRoleReq.getRoleUserId());

			// List resultList=query.list();

			// List
			// resultList=query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
			// .list();

			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_getroleprivilege_assigned(:_roleid)"
			 * ).setParameter("_roleid", fetchRolePrivilegeReq.getRoleId());
			 * List list =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP) .list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"SELECT * from table(func_getroleprvlg_assgnd(:roleid))")
					.addScalar("strparamcd", StandardBasicTypes.STRING)
					.addScalar("strcddesc", StandardBasicTypes.STRING)
					.addScalar("strothparamcd", StandardBasicTypes.STRING)
					.setParameter("roleid", fetchRolePrivilegeReq.getRoleId());
			// List list = query.list();
			List list = (List) query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			logger.info("Inside DBService :: fetchRolePrivilegeList method :: SelectedPrivileges Size:-"
					+ list.size());
			if (list != null && list.size() > 0) {
				Iterator it = list.iterator();
				while (it.hasNext()) {
					HashMap<String, String> resultMap = (HashMap<String, String>) it
							.next();
					// RoleDetails rolDet=new RoleDetails();
					PrivilegeDetails privilegeDetails = new PrivilegeDetails();
					if (resultMap.get("strparamcd") != null) {
						// value = (String) resultMap.get("strroleid");
						key = resultMap.get("strparamcd");
						privilegeDetails.setPrivilegeId(key);
						// rolDet.setRoleId(value);
					}

					if (resultMap.get("strcddesc") != null) {
						value = resultMap.get("strcddesc");
						privilegeDetails.setPrivilegeDescription(value);
					}
					// 1272 : VishalJ : Code added for sending ProductCode in
					// response JSON list. : Start
					if (resultMap.get("strothparamcd") != null) {
						value = resultMap.get("strothparamcd");
						privilegeDetails.setFilterId(value);
					}
					// 1272 : VishalJ : Code added for sending ProductCode in
					// response JSON list. : End

					// selectedRoles.add(rolDet);
					selectedPrivileges.add(privilegeDetails);
				}
				rolePrivilegeList.setSelectedPrivileges(selectedPrivileges);
				// userRoleList.setSelectedRoles(selectedRoles);
			}

			// Start:07/03/2017:Commented
			/*
			 * Query query1 = session.createSQLQuery(
			 * "SELECT * from func_getroleprivilege_available(:_roleid)"
			 * ).setParameter("_roleid", fetchRolePrivilegeReq.getRoleId());;
			 * List list1 =
			 * query1.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
			 * .list(); if(list1!=null && list1.size()>0){ Iterator it1 =
			 * list1.iterator(); while(it1.hasNext()){ HashMap<String, String>
			 * resultMap = (HashMap<String, String>)it1.next(); // RoleDetails
			 * rolDet=new RoleDetails(); PrivilegeDetails privilegeDetails = new
			 * PrivilegeDetails(); if (resultMap.get("strparamcd") != null) { //
			 * value = (String) resultMap.get("strroleid"); key=
			 * resultMap.get("strparamcd");
			 * privilegeDetails.setPrivilegeId(key); // rolDet.setRoleId(value);
			 * }
			 * 
			 * 
			 * if(resultMap.get("strcddesc") != null){ value=
			 * resultMap.get("strcddesc");
			 * privilegeDetails.setPrivilegeDescription(value); }
			 * 
			 * // selectedRoles.add(rolDet);
			 * availablePrivileges.add(privilegeDetails); }
			 * rolePrivilegeList.setAvailablePrivileges(availablePrivileges); }
			 */
			// End:07/03/2017:Commented

			Query query1 = null;
			FetchUserRoleRequest fetchUserRoleReq = new FetchUserRoleRequest();
			fetchUserRoleReq.setUserSubType(fetchRolePrivilegeReq
					.getUserSubType());
			fetchUserRoleReq.setUserID(fetchRolePrivilegeReq.getUserID());
			fetchUserRoleReq.setRoleUserId(fetchRolePrivilegeReq.getUserID());
			// if(logger.isDebugEnabled())
			logger.debug("Inside " + service.getClass() + ":: " + strMethodName
					+ " method :: User id::"
					+ fetchRolePrivilegeReq.getUserID());
			FetchUserRoleList fetchUserRoleList = fetchUserRoleList(fetchUserRoleReq);
			if (fetchUserRoleList != null
					&& fetchUserRoleList.getAvailableRoles() != null
					&& fetchUserRoleList.getAvailableRoles().size() > 0) {

				for (RoleDetails roleDetails : fetchUserRoleList
						.getAvailableRoles()) {

					if (roleDetails != null) {
						// if(logger.isDebugEnabled())
						logger.debug("Inside " + service.getClass() + ":: "
								+ strMethodName + " method :: Role id::"
								+ roleDetails.getRoleId());
						session = transactionManager.getSessionFactory()
								.getCurrentSession();
						transaction = session.getTransaction();
						if (!transaction.isActive()) {
							session.beginTransaction();
						}

						// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

						/*
						 * query1 = session.createSQLQuery(
						 * "SELECT * from func_getroleprivilege_assigned(:_roleid)"
						 * ).setParameter("_roleid", roleDetails.getRoleId());;
						 * List list1 =
						 * query1.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP
						 * ) .list();
						 */

						query1 = (Query) session
								.createSQLQuery(
										"SELECT * from table(func_getroleprvlg_assgnd(:roleid))")
								.addScalar("strparamcd",
										StandardBasicTypes.STRING)
								.addScalar("strcddesc",
										StandardBasicTypes.STRING)
								.addScalar("strothparamcd",
										StandardBasicTypes.STRING)
								.setParameter("roleid", roleDetails.getRoleId());
						;
						List list1 = (List) query1.setResultTransformer(
								Criteria.ALIAS_TO_ENTITY_MAP).list();

						// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
						if (list1 != null && list1.size() > 0) {
							Iterator it1 = list1.iterator();
							while (it1.hasNext()) {
								HashMap<String, String> resultMap = (HashMap<String, String>) it1
										.next();
								// RoleDetails rolDet=new RoleDetails();
								PrivilegeDetails privilegeDetails = new PrivilegeDetails();
								if (resultMap.get("strparamcd") != null) {
									// value = (String)
									// resultMap.get("strroleid");
									key = resultMap.get("strparamcd");
									privilegeDetails.setPrivilegeId(key);
									// rolDet.setRoleId(value);
								}

								if (resultMap.get("strcddesc") != null) {
									value = resultMap.get("strcddesc");
									privilegeDetails
											.setPrivilegeDescription(value);
								}
								// 1272 : VishalJ : Code added for sending
								// ProductCode in response JSON list. : Start
								if (resultMap.get("strothparamcd") != null) {
									value = resultMap.get("strothparamcd");
									privilegeDetails.setFilterId(value);
								}
								// 1272 : VishalJ : Code added for sending
								// ProductCode in response JSON list. : End

								// selectedRoles.add(rolDet);
								// 1272 : VishalJ : Code added to restrict
								// adding Selected Privileges into Availaible
								// Priv. : Start
								flag = 0;
								if (rolePrivilegeList != null
										&& rolePrivilegeList
												.getSelectedPrivileges() != null) {
									for (PrivilegeDetails privDet1 : rolePrivilegeList
											.getSelectedPrivileges()) {
										if (privDet1.getPrivilegeId().equals(
												privilegeDetails
														.getPrivilegeId()))
											flag = 1;
									}
								}
								if (flag != 1)
									availablePrivileges.add(privilegeDetails);
								// 1272 : VishalJ : Code added to restrict
								// adding Selected Privileges into Availaible
								// Priv. : End
							}
							// rolePrivilegeList.setAvailablePrivileges(availablePrivileges);
						}

						// if(logger.isDebugEnabled())
						logger.debug("Inside " + service.getClass() + ":: "
								+ strMethodName
								+ " method :: rolePrivilegeList::"
								+ rolePrivilegeList.toString());
					}
				}

				if (fetchRolePrivilegeReq.getUserSubType() != null
						&& (!fetchRolePrivilegeReq.getUserSubType()
								.equalsIgnoreCase(
										CommonConstants.USER_SUBTYPE_PRODUCER) || !fetchRolePrivilegeReq
								.getUserSubType().equalsIgnoreCase(
										CommonConstants.USER_SUBTYPE_DEALER))
						|| fetchRolePrivilegeReq.getUserSubType() == null) {

					List sysPrivList = getSystemUserParamCodes(new Integer(
							CommonConstants.PRIVILEGE_SYS_PARAM_CODE),
							CommonConstants.SYSTEM_PARAM_TYPE);
					if (sysPrivList != null) {

						ArrayList<PrivilegeDetails> privDetList = new ArrayList<PrivilegeDetails>();
						Iterator sysPrivListItr = sysPrivList.iterator();

						if (sysPrivListItr != null) {
							HashMap<String, String> resultMap = new HashMap<String, String>();

							while (sysPrivListItr.hasNext()) {
								resultMap = (HashMap<String, String>) sysPrivListItr
										.next();
								PrivilegeDetails privilegeDetails = new PrivilegeDetails();
								if (resultMap != null) {
									privilegeDetails.setPrivilegeId(resultMap
											.get("strparamcd"));
									privilegeDetails
											.setPrivilegeDescription(resultMap
													.get("strcddesc"));
									// 1272 : Code added for sending ProductCode
									// in response JSON list. : Start

									if (resultMap.get("strothparamcd") != null) {
										privilegeDetails.setFilterId(resultMap
												.get("strothparamcd"));

									}

									// 1272 : Code added for sending ProductCode
									// in response JSON list. : End
								}
								// 1272 : VishalJ : Code added to restrict
								// adding Selected Privileges into Availaible
								// Priv. : Start
								flag = 0;
								if (rolePrivilegeList != null
										&& rolePrivilegeList
												.getSelectedPrivileges() != null) {
									for (PrivilegeDetails privDet1 : rolePrivilegeList
											.getSelectedPrivileges()) {
										if (privDet1.getPrivilegeId().equals(
												privilegeDetails
														.getPrivilegeId()))
											flag = 1;
									}
								}
								if (flag != 1)
									availablePrivileges.add(privilegeDetails);
								// 1272 : VishalJ : Code added to restrict
								// adding Selected Privileges into Availaible
								// Priv. : End

							}
						}
					}

				}

				Set<PrivilegeDetails> privDetSet = new HashSet<PrivilegeDetails>();
				privDetSet.addAll(availablePrivileges);

				availablePrivileges = new ArrayList<PrivilegeDetails>();
				availablePrivileges.addAll(privDetSet);

				/*
				 * // 1272 : VishalJ : Code Added for removing selected
				 * Privillages from available Privileges : Start
				 * ArrayList<PrivilegeDetails> removePrivileges =
				 * rolePrivilegeList.getSelectedPrivileges(); int flag=0;
				 * for(PrivilegeDetails privDet1:availablePrivileges){ flag=0;
				 * for(PrivilegeDetails selDet1:removePrivileges){
				 * if(privDet1.getPrivilegeId
				 * ().equals(selDet1.getPrivilegeId())){ flag=1; } }
				 * 
				 * if(flag==1) availablePrivileges.remove(privDet1); } if
				 * (logger
				 * .isDebugEnabled())logger.debug("In DBService :: "+strMethodName
				 * +
				 * " Selected Roles :- "+rolePrivilegeList.getSelectedPrivileges
				 * ()); if
				 * (logger.isDebugEnabled())logger.debug("In DBService :: "
				 * +strMethodName+" Available Roles :- "+availablePrivileges);
				 * // 1272 : VishalJ : Code Added for removing selected
				 * Privillages from available Privileges : End
				 */

				rolePrivilegeList.setAvailablePrivileges(availablePrivileges);
			}

			if (!transaction.wasCommitted())
				transaction.commit();
		} catch (Exception e) {
			logger.error("In DBService :: " + strMethodName + " error ::", e);
			if (!transaction.wasRolledBack())
				transaction.rollback();
			// TODO Auto-generated catch block
			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("In DBService :: "+strMethodName
			 * +" error :: after transaction rollback"); }
			 */

			e.printStackTrace();
		}

		return rolePrivilegeList;
	}

	public RoleDetails checkRoleId(String strRoleId) throws Exception {
		RoleDetails roleDet = null;
		Session session = null;
		Transaction transaction = null;
		try {
			logger.info("Inside DBService :: checkRoleId method :: Entered");
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : ADDED FOR ORACLE MIGRATION
			// String
			// strSQL="select strroleid, strroledesc from ".concat(usrmgtSchema).concat("dcf_tagic_role_m where strroleid=:roleId");
			String strSQL = "select strroleid, strroledesc from dcf_tagic_role_m where strroleid=:roleId";

			Query query = session.createSQLQuery(strSQL)
					.addScalar("strroleid", StandardBasicTypes.STRING)
					.addScalar("strroledesc", StandardBasicTypes.STRING);

			query.setParameter("roleId", strRoleId);

			List outputList = query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			// END : ADDED FOR ORACLE MIGRATION

			if (outputList != null) {
				Iterator listItr = outputList.iterator();

				HashMap<String, String> resultMap = new HashMap<String, String>();
				roleDet = new RoleDetails();
				while (listItr.hasNext()) {
					resultMap = (HashMap<String, String>) listItr.next();

					if (resultMap.get("strroleid") != null)
						roleDet.setRoleId(resultMap.get("strroleid"));

					if (resultMap.get("strroledesc") != null)
						roleDet.setRoleId(resultMap.get("strroledesc"));
				}
			}
			transaction.commit();
			logger.info("Inside DBService :: checkRoleId method :: Exit");
		} catch (Exception ex) {

			logger.error("DBService :: checkRoleId catch block ::", ex);

			transaction.rollback();
			throw ex;
		}

		return roleDet;

	}

	public List getSystemUserParamCodes(Integer nParamTypeCd,
			String strParamType) throws Exception {

		List paramList = null;

		String strMethodName = "getSystemUserParamCodes";
		Session session = null;
		Transaction transaction = null;
		try {
			logger.info("Inside DBService :: " + strMethodName + " :: Entered");
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * String strSQL=
			 * "select * from func_getusersystem_param(:_nparamtypecd,:_paramtype)"
			 * ; Query query=session.createSQLQuery(strSQL);
			 * query.setParameter("_nparamtypecd", nParamTypeCd);
			 * query.setParameter("_paramtype", strParamType);
			 * paramList=query.setResultTransformer
			 * (Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			String strSQL = "select * from table(func_getusersystem_param(:nparamtypecd,:paramtype))";
			Query query = (Query) session.createSQLQuery(strSQL)
					.addScalar("strparamcd", StandardBasicTypes.STRING)
					.addScalar("strcddesc", StandardBasicTypes.STRING)
					.addScalar("strothparamcd", StandardBasicTypes.STRING);

			query.setParameter("nparamtypecd", nParamTypeCd);
			query.setParameter("paramtype", strParamType);
			// paramList = query.list();
			paramList = (List) query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			transaction.commit();
		} catch (Exception ex) {
			logger.error("DBService :: " + strMethodName + " catch block ::",
					ex);
			transaction.rollback();
			throw ex;
		}
		return paramList;
	}

	/*
	 * 
	 * Function to retrieve Intermediary Code & Name From
	 * dcf_master.dcf_ch_intermediary_m Table Input : Intermediary Code(Producer
	 * Code) Output : Intermediary Code, Intermediary Name, Intermediary
	 * Officecode
	 */
	public HashMap getIntermediaryDetails(String paramKey) {
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		List result = new ArrayList();
		HashMap<String, String> resultMap = new HashMap<String, String>();
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getIntermediaryDetails :: paramkey= "
					+ paramKey);

			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_getintermediary_details(:_paramkey)"
			 * ).setParameter("_paramkey", paramKey);
			 * //List<PrimarilyUsedVehicle> primResult =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 * result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"SELECT * from table(func_getintermediary_details(:paramkey))")
					.addScalar("intermediary_code", StandardBasicTypes.STRING)
					.addScalar("intermediary_name", StandardBasicTypes.STRING)
					.addScalar("intermediary_officecd",
							StandardBasicTypes.INTEGER)
					.addScalar("noffice_cd", StandardBasicTypes.BIG_DECIMAL);
			query.setParameter("paramkey", paramKey);
			// result = query.list();
			result = (List) query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			if (result != null && result.size() > 0) {

				resultMap = (HashMap) result.get(0);

				// Do Not Delete Commented..... Use below key to retrieve
				// value..............................
				// resultMap.put("intermediary_code", intermediary_code);
				// resultMap.put("intermediary_name", intermediary_name);
				// resultMap.put("intermediary_officecd",
				// intermediary_officecd); //Returns Numeric value
			}

			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getIntermediaryDetails ::", ex);
		}
		logger.info("DBService :: getIntermediaryDetails :: result="
				+ result.toString());
		return resultMap;
	}

	/*
	 * 
	 * Function to retrieve Cover Details such as Cover Name, Type & Code From
	 * dcf_coverdetails_mast Table Input : Intermediary Code(Producer Code)
	 * Output : Intermediary Code, Intermediary Name
	 */
	public HashMap getCoverDetailsMast() {
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		List result = new ArrayList();
		List listProduct = new ArrayList();
		HashMap<String, String> resultMap = new HashMap<String, String>();
		ObjectMapper objMap = new ObjectMapper();
		ArrayList docArr = new ArrayList();

		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START:Changes done for oracle migration
			Query query = session
					.createSQLQuery(
							"SELECT * from  table(func_getcoverdetails_mast)")
					.addScalar("strcover_name", StandardBasicTypes.STRING)
					.addScalar("strcover_type", StandardBasicTypes.STRING)
					.addScalar("strcover_code", StandardBasicTypes.STRING);

			// END:Changes done for oracle migration
			query.setResultTransformer(Transformers
					.aliasToBean(CoverDetailsMaster.class));
			result = query.list();

			logger.info("DBService :: getCoverDetailsMast :: result="
					+ objMap.writeValueAsString(result));

			docArr = (ArrayList<Object>) result;
			for (int i = 0; i < docArr.size(); i++) {
				CoverDetailsMaster ent = new CoverDetailsMaster();
				ent = (CoverDetailsMaster) docArr.get(i);

				resultMap.put(ent.getStrcover_name(), ent.getStrcover_code());
			}

			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getCoverDetailsMast ::", ex);
		}
		logger.info("DBService :: getCoverDetailsMast :: result="
				+ result.toString());
		return resultMap;
	}

	// Start: RahulT| Cron job added to run at 00.00 AM every day to mark
	// generated payment link of previous day to inactive
	public void markPayLinkInactive() {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.markPayLinkInactive Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: markPayLinkInactive method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Query query = session
					.createSQLQuery(" update dcf_self_pay_trans set paylinkused = :inactive, dtupdated = :dttime "
							+ " where paylinkused = :active and isrenew = :isrenew");
			query.setParameter("inactive", "2");
			query.setParameter("dttime", new Date());
			query.setParameter("active", "0");
			query.setParameter("isrenew", "N");
			logger.info("Inside DBService :: query :: " + query);
			int result = query.executeUpdate();
			logger.info("Inside DBService :: No of rows updated :: " + result);
			// Start: RahulT <SIT 2027> | code added to mark all AD SPL receipt
			// as inactive
			// 04102017| Mantis ID 2027
			Query queryAD = session
					.createSQLQuery(" update dcf_ad_receipt_spl set status = :inactive, dtupdated = :dttime "
							+ " where status = :active and isrenew = :isrenew");
			queryAD.setParameter("inactive", "2");
			queryAD.setParameter("dttime", new Date());
			queryAD.setParameter("active", "0");
			queryAD.setParameter("isrenew", "N");
			logger.info("Inside DBService :: queryAD :: " + queryAD);
			result = queryAD.executeUpdate();
			logger.info("Inside DBService :: No of rows updated :: " + result);

			// Start: <Parvind:<SIT Mantis ID:- 3605> |code added for AD amount
			// not showing on payment page Mantis id- 3605
			Calendar cal1 = (Calendar.getInstance());
			cal1.add(Calendar.DATE, -1);
			java.sql.Date dateminus2 = new java.sql.Date(cal1.getTime()
					.getTime());
			logger.info("Dateminus2 :: " + dateminus2);
			String dateMinus2 = dateminus2.toString();

			Query queryRL = session
					.createSQLQuery(" update dcf_self_pay_trans set paylinkused = :inactive, dtupdated = :dttime "
							+ " where paylinkused = :active and isrenew = :isrenew and dtcreated < :dtcreated");
			queryRL.setParameter("inactive", "2");
			queryRL.setParameter("dttime", new Date());
			queryRL.setParameter("active", "0");
			queryRL.setParameter("isrenew", "R");
			queryRL.setParameter("dtcreated", dateminus2);
			logger.info("Update DBService :: query :: " + queryRL);
			result = queryRL.executeUpdate();
			logger.info("Updating Table update dcf_self_pay_trans  DBService :: No of rows updated :: "
					+ result);

			Query queryRl2 = session
					.createSQLQuery(" update dcf_ad_receipt_spl set status = :inactive, dtupdated = :dttime "
							+ " where status = :active and isrenew = :isrenew and dtcreated < :dtcreated");
			// update dcf_ad_receipt_spl set status = ?, dtupdated = ? where
			// status = ? and isrenew = ? and dtcreated ? <= current_date-2
			queryRl2.setParameter("inactive", "2");
			queryRl2.setParameter("dttime", new Date());
			queryRl2.setParameter("active", "0");
			queryRl2.setParameter("isrenew", "R");
			queryRl2.setParameter("dtcreated", dateminus2);
			// queryRl2.setParameter("dtrange", to_date('dateminus2',                                                                               
			// 'YYYY//DD/MM'));
			logger.info("Update DBService :: queryRl2 :: " + queryRl2);
			result = queryRl2.executeUpdate();
			logger.info("Updating Table update dcf_ad_receipt_spl :: No of rows updated :: "
					+ result);

			// End: <Parvind:<SIT Mantis ID:- 3605> |code added for AD amount
			// not showing on payment page Mantis id- 3605
			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: markPayLinkInactive error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
	}

	// End: RahulT| Cron job added to run at 00.00 every day to mark generated
	// payment link of previous day to inactive

	public void markPayLinkUsed(String orderID) {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.markPayLinkUsed Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: markPayLinkUsed method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Query query = session
					.createSQLQuery(" update dcf_self_pay_trans set paylinkused = :used, dtupdated = :dttime"
							+ " where strtransid = :orderID");
			query.setParameter("used", "1");
			query.setParameter("dttime", new Date());
			query.setParameter("orderID", orderID);
			int result = query.executeUpdate();

			// Start: RahulT <SIT 2027> | code added to mark all AD SPL receipt
			// as inactive
			// 04102017| Mantis ID 2027
			Query queryAD = session
					.createSQLQuery(" update dcf_ad_receipt_spl set status = :used, dtupdated = :dttime "
							+ " where transid = :orderID ");
			queryAD.setParameter("used", "1");
			queryAD.setParameter("dttime", new Date());
			queryAD.setParameter("orderID", orderID);
			queryAD.executeUpdate();
			// End: RahulT <SIT 2027> | code added to mark all AD SPL receipt as
			// inactive

			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: markPayLinkUsed error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
	}

	// Start: RahulT| user transaction changes
	public int updateUserTransForProposal(String proposalNumber,
			String quoteNumber) {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.updateUserTransForProposal Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		int result = 0;
		logger.info("Inside DBService :: updateUserTransForProposal method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Query query = session
					.createSQLQuery(" update dcf_user_trans_dtl set strpropnumber = :propNumber"
							+ " where strquotnumber = :quoteNumber");
			query.setParameter("propNumber", proposalNumber);
			query.setParameter("quoteNumber", quoteNumber);
			result = query.executeUpdate();

			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: updateUserTransForProposal error ::",
					e);
			transaction.rollback();
			e.printStackTrace();
		}
		return result;
	}

	// End: RahulT| user transaction changes

	// Start: RahulT| added changes to log error message & error code in self
	// payment table
	public void payLinkFailedTxnGC(SelfPaymentEntiry objSelfPayLink) {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.payLinkFailedTxnGC Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: payLinkFailedTxnGC method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Query query = session
					.createSQLQuery(" update dcf_self_pay_trans set errorcode = :errorcode, errormsg = :errormsg, dtupdated = :dttime"
							+ " where strtransid = :orderID");
			query.setParameter("errorcode", objSelfPayLink.getErrorCode());
			query.setParameter("errormsg", objSelfPayLink.getErrorMsg());
			query.setParameter("dttime", new Date());
			query.setParameter("orderID", objSelfPayLink.getTransId());
			int result = query.executeUpdate();

			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: payLinkFailedTxnGC error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
	}

	// End: RahulT| added changes to log error message & error code in self
	// payment table

	// Start: RahulT| added to retrieve quotatioon sequence
	public Long getNextQuotSeq() {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.markPayLinkInactive Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		Iterator<BigDecimal> iter = Collections.<BigDecimal> emptyList()
				.iterator();
		Long quotationSeq = null;
		logger.info("Inside DBService :: getNextQuotSeq method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			/*
			 * Query query =
			 * session.createSQLQuery(" SELECT nextval('dcf_quotation_pa_seqid') "
			 * );
			 */// Commented for oracle migration
			Query query = session
					.createSQLQuery(" SELECT dcf_quotation_pa_seqid.nextval from dual"); // Added
																							// for
																							// oracle
																							// migration

			iter = query.list().iterator();
			quotationSeq = iter.next().longValue();

			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: markPayLinkInactive error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
		return quotationSeq;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getAddOnFeaturesDefault(String className,
			AddOnRequest idvReq) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List<VehicleAddOn> idvlst = new ArrayList<VehicleAddOn>();
		Session session = null;
		Transaction transaction = null;
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getAddOnFeaturesDefault Method"); }
			 */

			logger.info("Inside DBService :: getAddOnFeaturesDefault(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			String strplancode = "";
			strplancode = idvReq.getStrplancode();

			String strchoice = "";
			strchoice = idvReq.getStrchoice();

			logger.info("Inside DBService :: getAddOnFeaturesDefault(String) method :: strplancode : "
					+ strplancode);

			Criteria criteria = session.createCriteria(classInstance);
			// criteria.add(Restrictions.eq("strplancode",strplancode).ignoreCase());
			criteria.add(Restrictions.and(
					Restrictions.eq("strplanname", strplancode).ignoreCase(),
					Restrictions.eq("strchoice", strchoice).ignoreCase()));

			idvlst = criteria.list();

			logger.info("Inside DBService :: getAddOnFeaturesDefault(String) method :: idvlst.size() : "
					+ idvlst.size());

			ObjectMapper objMap = new ObjectMapper();

			logger.info("Inside DBService :: getAddOnFeaturesDefault(String) method :: idvlst : "
					+ objMap.writeValueAsString(idvlst));

			logger.info("Inside DBService :: getAddOnFeaturesDefault(String) method :: Execution Completed Successfully");

			if (logger.isDebugEnabled()) {
				logger.debug("Out DBService.getAddOnFeaturesDefault(String) Method");
			}
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getAddOnFeaturesDefault(String) method :: ",
					e);
			e.printStackTrace();
		}
		return idvlst;
	}

	public HashMap getIntermediaryDetailsOffice(String paramKey) {
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		List result = new ArrayList();
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getIntermediaryDetailsOffice :: paramkey= "
					+ paramKey);
			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_getintermediary_details(:_paramkey)"
			 * ).setParameter("_paramkey", paramKey);
			 * //List<PrimarilyUsedVehicle> primResult =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 * result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"SELECT * from table(func_getintermediary_details(?))")
					.addScalar("intermediary_code", StandardBasicTypes.STRING)
					.addScalar("intermediary_name", StandardBasicTypes.STRING)
					.addScalar("intermediary_officecd",
							StandardBasicTypes.BIG_DECIMAL)
					.addScalar("noffice_cd", StandardBasicTypes.BIG_DECIMAL)

					.setParameter(0, paramKey);
			// result = query.list();
			result = (List) query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION

			if (result != null && result.size() > 0) {

				resultMap = (HashMap) result.get(0);

				// Do Not Delete Commented..... Use below key to retrieve
				// value..............................
				// resultMap.put("intermediary_code", intermediary_code);
				// resultMap.put("intermediary_name", intermediary_name);
				// resultMap.put("intermediary_officecd",
				// intermediary_officecd); //Returns Numeric value
			}

			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getIntermediaryDetailsOffice ::", ex);
		}
		logger.info("DBService :: getIntermediaryDetailsOffice :: result="
				+ result.toString());
		return resultMap;
	}

	public List getPreInspectionAgencyDetails(int paramKey) {
		Session session = null;
		Transaction transaction = null;
		List result = null;
		HashMap resultMap = new HashMap();
		ObjectMapper objMap = new ObjectMapper();
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getPreInspectionAgencyDetails :: paramkey= "
					+ paramKey);
			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_getpreinspectionagency_details(:_paramkey)"
			 * ).setParameter("_paramkey", paramKey); result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"SELECT * from table(func_getprespecagency_details(:paramkey))")
					.addScalar("strinspectionagency_cd",
							StandardBasicTypes.STRING)
					.addScalar("strinspectionagency_name",
							StandardBasicTypes.STRING)
					.addScalar("stremail_id", StandardBasicTypes.STRING)
					.addScalar("strmobile_no", StandardBasicTypes.STRING)
					.addScalar("strlandline_no", StandardBasicTypes.STRING)
					.addScalar("strfirstescalationemail_id",
							StandardBasicTypes.STRING)
					.addScalar("strfirstescalationmob_no",
							StandardBasicTypes.STRING)
					.addScalar("strsecondescalationemail_id",
							StandardBasicTypes.STRING)
					.addScalar("strsecondescalationmob_no",
							StandardBasicTypes.STRING)
					.setParameter("paramkey", paramKey);
			result = query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
					.list();

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION

			// for(int i=0;i<result.size();i++)
			// {
			//
			// resultMap=(HashMap)result;

			// Do Not Delete Commented..... Use below key to retrieve
			// value..............................
			// resultMap.put("strinspectionagency_cd", strinspectionagency_cd);
			// resultMap.put("strinspectionagency_name",
			// strinspectionagency_name);
			// resultMap.put("stremail_id", stremail_id);
			// resultMap.put("strmobile_no", strmobile_no);
			// resultMap.put("strlandline_no", strlandline_no);
			// resultMap.put("strfirstescalationemail_id",
			// strfirstescalationemail_id);
			// resultMap.put("strfirstescalationmob_no",
			// strfirstescalationmob_no);
			// resultMap.put("strsecondescalationemail_id",
			// strsecondescalationemail_id);
			// resultMap.put("strsecondescalationmob_no",
			// strsecondescalationmob_no);
			// }
			logger.info("DBService :: getPreInspectionAgencyDetails :: result="
					+ objMap.writeValueAsString(result));
			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("DBService :: getPreInspectionAgencyDetails ::", ex);
		}

		return result;
	}

	// Start: RahulT| quotation detail table changes
	public int updateQuotForProposal(String proposalNumber, String quoteNumber) {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.updateQuotForProposal Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		int result = 0;
		logger.info("Inside DBService :: updateQuotForProposal method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Query query = session
					.createSQLQuery(" update dcf_quotation_dtl set strproposalnumber = :propNumber"
							+ " where strquotnumber = :quoteNumber");
			query.setParameter("propNumber", proposalNumber);
			query.setParameter("quoteNumber", quoteNumber);
			result = query.executeUpdate();

			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: updateQuotForProposal error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
		return result;
	}

	// End: RahulT| user transaction changes

	public HashMap getPropStatusDesc(Integer nParamTypeCd) {
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		List result = new ArrayList();
		ArrayList finalLst = new ArrayList();
		HashMap<String, String> resultMap = new HashMap<String, String>();
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getPropStatusDesc :: paramkey= "
					+ nParamTypeCd);

			// START:Changes done for oracle migration
			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from table(func_get_propstatus_desc(:paramkey))")
			 * .setParameter("paramkey", nParamTypeCd);
			 */
			Query query = session
					.createSQLQuery(
							"SELECT * from table(func_get_propstatus_desc(:paramkey))")
					.addScalar("strparamcd", StandardBasicTypes.STRING)
					.addScalar("strcddesc", StandardBasicTypes.STRING)

					.setParameter("paramkey", nParamTypeCd);

			// END:Changes done for oracle migration
			// result =
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			query.setResultTransformer(Transformers
					.aliasToBean(ParameterDetailList.class));
			result = query.list();

			if (result != null && result.size() > 0) {
				finalLst = (ArrayList<Object>) result;
				for (int i = 0; i < finalLst.size(); i++) {
					ParameterDetailList proposalStatObj = new ParameterDetailList();
					proposalStatObj = (ParameterDetailList) finalLst.get(i);

					resultMap.put(proposalStatObj.getStrparamcd(),
							proposalStatObj.getStrcddesc());
				}
			}

			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getPropStatusDesc ::", ex);
		}
		logger.info("DBService :: getPropStatusDesc :: result="
				+ result.toString());
		return resultMap;
	}

	// Start: RahulT| added to get SPL Expired data

	public ArrayList getSPLExpiredData() {
		List<QuotationPA> quotationList = new ArrayList<QuotationPA>();
		Session session = null;
		Transaction transaction = null;
		StringBuilder query = new StringBuilder();
		int check = 0;
		ArrayList<Object[]> retList = new ArrayList();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getSPLExpiredData Method"); }
			 */

			logger.info("Inside DBService :: getSPLExpiredData(String) method :: Execution Started");

			String strParamVal = this.getConfigParamVal("SPLEXPIRED");
			int SPL_Expired_days = new Integer(strParamVal);
			// int SPL_Expired_days = 15;

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			query.append("select strproppolno,strcustomername,productCd,dtransamt,paylinkused, dtcreated ");

			query.append(" from dcf_self_pay_trans where dtcreated > current_date - interval '"
					+ SPL_Expired_days + "' day ");

			query.append(" and paylinkused = :linkused "); // code added to
															// fetch quotation
															// of expired status

			logger.info("Inside DBService :: getSPLExpiredData method :: buildQuery.toString() : "
					+ query.toString());

			// SQLQuery sqlQuery = session.createSQLQuery(query.toString());
			// START : ADDED FOR ORACLE MIGRATION
			Query sqlQuery = session.createSQLQuery(query.toString())

			.addScalar("strproppolno", StandardBasicTypes.STRING)
					.addScalar("strcustomername", StandardBasicTypes.STRING)
					.addScalar("productCd", StandardBasicTypes.STRING)
					.addScalar("dtransamt", StandardBasicTypes.STRING)
					.addScalar("paylinkused", StandardBasicTypes.STRING)
					.addScalar("dtcreated", StandardBasicTypes.TIMESTAMP);

			// END : ADDED FOR ORACLE MIGRATION
			sqlQuery.setParameter("linkused", "2");

			retList = (ArrayList) sqlQuery.list();

			logger.info("Inside DBService :: getSPLExpiredData method :: Size Of list : "
					+ retList.size());

			transaction.commit();
			return retList;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getSPLExpiredData:: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getSPLExpiredData method :: Exception Occurred..."
					+ e);
		}
		return retList;
	}

	public ArrayList searchIPAQuotDashBoard() {
		List<QuotationPA> quotationList = new ArrayList<QuotationPA>();
		Session session = null;
		Transaction transaction = null;
		StringBuilder query = new StringBuilder();
		int check = 0;
		ArrayList<Object[]> retList = new ArrayList();
		try {

			logger.info("Inside DBService :: searchIPAQuotDashBoard(String) method :: Execution Started");

			String strParamVal = this.getConfigParamVal("QUOT_VALID_ADAYS");
			int quot_valid_days = new Integer(strParamVal);

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			query.append("select strquotnumber,firstname,lastname,strproductcode,dtotalpayable, COALESCE(to_char(dtcreated, 'yyyy-MM-dd HH:mm:ss'), '') as dtcreated ");

			query.append(" from dcf_quotation_dtl where dtcreated > current_date - interval '"
					+ quot_valid_days + "' day "); // code added to fetch
													// quotation of last 30 days

			query.append(" and strproposalnumber is null "); // code added to
																// fetch
																// quotation of
																// last 30 days

			logger.info("Inside DBService :: searchIPAQuotDashBoard method :: buildQuery.toString() : "
					+ query.toString());

			// START : ADDED FOR ORACLE MIGRATION
			SQLQuery sqlQuery = session.createSQLQuery(query.toString())

			.addScalar("strquotnumber", StandardBasicTypes.STRING)
					.addScalar("firstname", StandardBasicTypes.STRING)
					.addScalar("lastname", StandardBasicTypes.STRING)
					.addScalar("strproductcode", StandardBasicTypes.STRING)
					.addScalar("dtotalpayable", StandardBasicTypes.STRING)
					.addScalar("dtcreated", StandardBasicTypes.TIMESTAMP);

			// END : ADDED FOR ORACLE MIGRATION

			retList = (ArrayList) sqlQuery.list();

			logger.info("Inside DBService :: searchIPAQuotDashBoard method :: Size Of list : "
					+ retList.size());

			transaction.commit();
			return retList;
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: searchIPAQuotDashBoard:: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: searchIPAQuotDashBoard method :: Exception Occurred..."
					+ e);
		}
		return retList;
	}

	public List getCovernoteOtherReasons(Integer nParamTypeCd, String strParamCd)
			throws Exception {

		List paramList = null;

		String strMethodName = "getCovernoteOtherReasons";
		Session session = null;
		Transaction transaction = null;
		try {
			logger.info("Inside DBService :: " + strMethodName + " :: Entered");
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * String strSQL=
			 * "select * from func_getcovernote_other_reason(:_nparamtypecd,:_strparamcd)"
			 * ; Query query=session.createSQLQuery(strSQL);
			 * query.setParameter("_nparamtypecd", nParamTypeCd);
			 * query.setParameter("_strparamcd", strParamCd);
			 * paramList=query.setResultTransformer
			 * (Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			String strSQL = "select * from table(func_getcvrnote_otr_reasn(:nparamtypecd,:strparamcd))";
			Query query = (Query) session.createSQLQuery(strSQL)
					.addScalar("strotherreasoncd", StandardBasicTypes.STRING)
					.addScalar("strotherreasondesc", StandardBasicTypes.STRING);

			query.setParameter("nparamtypecd", nParamTypeCd);
			query.setParameter("strparamcd", strParamCd);
			paramList = query
					.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			transaction.commit();
		} catch (Exception ex) {
			logger.error("DBService :: " + strMethodName + " catch block ::",
					ex);
			transaction.rollback();
			throw ex;
		}
		return paramList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap<String, UserTransaction> getCustomerIdUserTrans(
			String className, CustomerSearchRequest customerSearchRequest)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {

		List<UserTransaction> userTransactionList = new ArrayList<UserTransaction>();
		HashMap<String, UserTransaction> clientIdMap = new HashMap<>();
		Session session = null;
		Transaction transaction = null;
		String strMethodName = "getCustomerIdUserTrans";
		try {
			logger.info(service.getClass() + "::" + strMethodName + "::Entered");
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);

			Disjunction disjunction = Restrictions.disjunction();

			if (customerSearchRequest != null
					&& customerSearchRequest.getQuotationNo() != null
					&& !customerSearchRequest.getQuotationNo().equals(
							CommonConstants.BLANK_STRING))
				disjunction
						.add(Restrictions.or(Restrictions.eq("strQuotNumber",
								customerSearchRequest.getQuotationNo())));

			if (customerSearchRequest != null
					&& customerSearchRequest.getProposalNo() != null
					&& !customerSearchRequest.getProposalNo().equals(
							CommonConstants.BLANK_STRING))
				disjunction
						.add(Restrictions.or(Restrictions.eq("strPropNumber",
								customerSearchRequest.getProposalNo())));

			if (customerSearchRequest != null
					&& customerSearchRequest.getPolicyNo() != null
					&& !customerSearchRequest.getPolicyNo().equals(
							CommonConstants.BLANK_STRING))
				disjunction.add(Restrictions.or(Restrictions.eq("strPolNbr",
						customerSearchRequest.getPolicyNo())));
			// START:14/06/2017: Code changes for defect1226
			Conjunction conjunction = Restrictions.conjunction();

			if (customerSearchRequest != null
					&& customerSearchRequest.getVehicleRegistrationNumber1() != null
					&& !customerSearchRequest.getVehicleRegistrationNumber1()
							.equals(CommonConstants.BLANK_STRING))
				conjunction.add(Restrictions.eq("strvehregno1",
						customerSearchRequest.getVehicleRegistrationNumber1()));
			if (customerSearchRequest != null
					&& customerSearchRequest.getVehicleRegistrationNumber2() != null
					&& !customerSearchRequest.getVehicleRegistrationNumber2()
							.equals(CommonConstants.BLANK_STRING))
				conjunction.add(Restrictions.eq("strvehregno2",
						customerSearchRequest.getVehicleRegistrationNumber2()));
			if (customerSearchRequest != null
					&& customerSearchRequest.getVehicleRegistrationNumber3() != null
					&& !customerSearchRequest.getVehicleRegistrationNumber3()
							.equals(CommonConstants.BLANK_STRING))
				conjunction.add(Restrictions.eq("strvehregno3",
						customerSearchRequest.getVehicleRegistrationNumber3()));
			if (customerSearchRequest != null
					&& customerSearchRequest.getVehicleRegistrationNumber4() != null
					&& !customerSearchRequest.getVehicleRegistrationNumber4()
							.equals(CommonConstants.BLANK_STRING))
				conjunction.add(Restrictions.eq("strvehregno4",
						customerSearchRequest.getVehicleRegistrationNumber4()));
			// END:14/06/2017: Code changes for defect 1226

			if ((disjunction.conditions() != null && disjunction.conditions()
					.iterator().hasNext())
					|| (conjunction.conditions() != null && conjunction
							.conditions().iterator().hasNext()))
				criteria.add(
						Restrictions.and(Restrictions.eq("strProducercd",
								customerSearchRequest.getProducerCode())))
						.add(disjunction).add(conjunction);

			// START:03/07/2017: Code changes for defect1226
			/*
			 * if(customerSearchRequest!=null &&
			 * customerSearchRequest.getVehicleRegistrationNumber1()!=null &&
			 * !customerSearchRequest
			 * .getVehicleRegistrationNumber1().equals(CommonConstants
			 * .BLANK_STRING))
			 * criteria.add(Restrictions.and(Restrictions.eq("strvehregno1",
			 * customerSearchRequest.getVehicleRegistrationNumber1())));
			 * if(customerSearchRequest!=null &&
			 * customerSearchRequest.getVehicleRegistrationNumber2()!=null &&
			 * !customerSearchRequest
			 * .getVehicleRegistrationNumber2().equals(CommonConstants
			 * .BLANK_STRING))
			 * criteria.add(Restrictions.and(Restrictions.eq("strvehregno2",
			 * customerSearchRequest.getVehicleRegistrationNumber2())));
			 * if(customerSearchRequest!=null &&
			 * customerSearchRequest.getVehicleRegistrationNumber3()!=null &&
			 * !customerSearchRequest
			 * .getVehicleRegistrationNumber3().equals(CommonConstants
			 * .BLANK_STRING))
			 * criteria.add(Restrictions.and(Restrictions.eq("strvehregno3",
			 * customerSearchRequest.getVehicleRegistrationNumber3())));
			 * if(customerSearchRequest!=null &&
			 * customerSearchRequest.getVehicleRegistrationNumber4()!=null &&
			 * !customerSearchRequest
			 * .getVehicleRegistrationNumber4().equals(CommonConstants
			 * .BLANK_STRING))
			 * criteria.add(Restrictions.and(Restrictions.eq("strvehregno4",
			 * customerSearchRequest.getVehicleRegistrationNumber4())));
			 */
			// End:03/07/2017: Code changes for defect1226

			userTransactionList = criteria.list();

			if (userTransactionList != null && userTransactionList.size() > 0) {

				for (UserTransaction userTransaction : userTransactionList) {

					if (userTransaction != null
							&& userTransaction.getStrCustomerId() != null
							&& !userTransaction.getStrCustomerId()
									.equalsIgnoreCase(
											CommonConstants.BLANK_STRING)) {
						clientIdMap.put(userTransaction.getStrCustomerId(),
								userTransaction);
					}
				}
			}

			// if(logger.isDebugEnabled())
			logger.debug(service.getClass() + "::" + strMethodName
					+ ":: Client ID result::" + clientIdMap);
			if (!transaction.wasCommitted())
				transaction.commit();
		} catch (Exception ex) {
			logger.error("DBService :: " + strMethodName + " catch block ::",
					ex);
			if (!transaction.wasRolledBack())
				transaction.rollback();
		}
		logger.info(service.getClass() + "::" + strMethodName + "::Exit");
		return clientIdMap;
	}

	// private String _strClassName="DBService";

	public List<CustomerEntity> getCustomerSearchDetailsFromPortal(
			String strClassName, CustomerSearchRequest customerDetailRequest)
			throws Exception {

		String strMethodName = "getCustomerSearchDetailsFromPortal";
		Session session = null;
		Transaction transaction = null;
		List<CustomerEntity> customerEntityList = new ArrayList<CustomerEntity>();
		Date dtFrom = null;
		Date dtTo = null;
		try {

			logger.info(service.getClass() + "::" + strMethodName + "::Entered");
			Class classInstance = Class.forName(strClassName);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.and(Restrictions.eq("strproducercode",
					customerDetailRequest.getProducerCode())));

			if (customerDetailRequest != null
					&& customerDetailRequest.getCustomerCode() != null
					&& !customerDetailRequest.getCustomerCode().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("strcustomerid",
						customerDetailRequest.getCustomerCode()).ignoreCase()));

			if (customerDetailRequest != null
					&& customerDetailRequest.getFirstName() != null
					&& !customerDetailRequest.getFirstName().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("strfirstname",
						customerDetailRequest.getFirstName()).ignoreCase()));

			if (customerDetailRequest != null
					&& customerDetailRequest.getLastName() != null
					&& !customerDetailRequest.getLastName().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("strlastname",
						customerDetailRequest.getLastName()).ignoreCase()));

			if (customerDetailRequest != null
					&& customerDetailRequest.getPinCode() != null
					&& !customerDetailRequest.getPinCode().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("strpincode",
						customerDetailRequest.getPinCode())));

			if (customerDetailRequest != null
					&& customerDetailRequest.getDateOfBirth() != null
					&& customerDetailRequest.getDateOfBirth() != null
					&& !customerDetailRequest.getDateOfBirth().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("strdob",
						customerDetailRequest.getDateOfBirth())));

			if (customerDetailRequest != null
					&& customerDetailRequest.getStateCode() != null
					&& customerDetailRequest.getStateCode() != null
					&& !customerDetailRequest.getStateCode().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("strstatecode",
						customerDetailRequest.getStateCode())));

			if (customerDetailRequest != null
					&& customerDetailRequest.getCityCode() != null
					&& !customerDetailRequest.getCityCode().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("strcitycode",
						customerDetailRequest.getCityCode())));

			if (customerDetailRequest != null
					&& customerDetailRequest.getMobileNo() != null
					&& !customerDetailRequest.getMobileNo().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("strmobile",
						customerDetailRequest.getMobileNo())));

			if (customerDetailRequest != null
					&& customerDetailRequest.getCusoType() != null
					&& !customerDetailRequest.getCusoType().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq(
						"strcustomertype", customerDetailRequest.getCusoType())));

			// Start: 1242: Sailesh| code added for defect 1242
			if (customerDetailRequest != null
					&& customerDetailRequest.getCreateDateFrom() != null
					&& !customerDetailRequest.getCreateDateFrom().equals(
							CommonConstants.BLANK_STRING)
					&& customerDetailRequest.getCreateDateTo() != null
					&& !customerDetailRequest.getCreateDateTo().equals(
							CommonConstants.BLANK_STRING)) {
				dtFrom = new SimpleDateFormat("dd/MM/yyyy")
						.parse(customerDetailRequest.getCreateDateFrom());
				dtTo = new SimpleDateFormat("dd/MM/yyyy")
						.parse(customerDetailRequest.getCreateDateTo());
				logger.debug("dtFrom" + dtFrom + "dtTo" + dtTo);
				criteria.add(Restrictions.and(Restrictions.ge("dtcreated",
						dtFrom)));
				criteria.add(Restrictions.and(Restrictions
						.lt("dtcreated", dtTo)));
			}

			else if ((customerDetailRequest != null
					&& customerDetailRequest.getCreateDateFrom() != null && !customerDetailRequest
					.getCreateDateFrom().equals(CommonConstants.BLANK_STRING))
					&& (customerDetailRequest != null
							&& customerDetailRequest.getCreateDateTo() == null || customerDetailRequest
							.getCreateDateTo().equals(
									CommonConstants.BLANK_STRING))) {
				dtFrom = new SimpleDateFormat("dd/MM/yyyy")
						.parse(customerDetailRequest.getCreateDateFrom());
				criteria.add(Restrictions.and(Restrictions.ge("dtcreated",
						dtFrom)));
			} else if ((customerDetailRequest != null
					&& customerDetailRequest.getCreateDateFrom() == null || customerDetailRequest
					.getCreateDateFrom().equals(CommonConstants.BLANK_STRING))
					&& (customerDetailRequest != null
							&& customerDetailRequest.getCreateDateTo() != null && !customerDetailRequest
							.getCreateDateTo().equals(
									CommonConstants.BLANK_STRING))) {
				dtTo = new SimpleDateFormat("dd/MM/yyyy")
						.parse(customerDetailRequest.getCreateDateTo());
				criteria.add(Restrictions.and(Restrictions
						.lt("dtcreated", dtTo)));

			}
			// END
			// Start: 1449: RahulT| code addded to filter customer search based
			// on GST number
			if (customerDetailRequest != null
					&& customerDetailRequest.getStrgstnumber() != null
					&& !customerDetailRequest.getStrgstnumber().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("strgstnumber",
						customerDetailRequest.getStrgstnumber()).ignoreCase()));
			// End: 1449: RahulT| code addded to filter customer search based on
			// GST number

			customerEntityList = criteria.list();

			if (!transaction.wasCommitted())
				transaction.commit();

		} catch (Exception ex) {
			logger.error("DBService :: " + strMethodName + " catch block ::",
					ex);
			if (!transaction.wasRolledBack())
				transaction.rollback();
		}
		logger.info(service.getClass() + "::" + strMethodName + "::Exit");
		return customerEntityList;
	}

	public String getDistrictCityNameByCode(String strClassName,
			String strCode, String strCityDistrictFlag) throws Exception {

		String strMethodName = "getDistrictCityNameByCode";
		String strCityName = null;
		List<City> cityList = new ArrayList<City>();
		Session session = null;
		Transaction transaction = null;
		try {
			logger.info(service.getClass() + "::" + strMethodName + "::Entered");
			Class classInstance = Class.forName(strClassName);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);

			criteria.add(Restrictions.and(Restrictions.eq("strcitycd", strCode)));
			criteria.add(Restrictions.and(Restrictions.eq("ndistrictcityflag",
					strCityDistrictFlag)));
			cityList = criteria.list();

			if (cityList != null && cityList.size() > 0) {

				for (City city : cityList) {
					strCityName = city.getStrcityname();
				}
			}

			if (!transaction.wasCommitted())
				transaction.commit();

		} catch (Exception ex) {
			logger.error("DBService :: " + strMethodName + " catch block ::",
					ex);
			if (!transaction.wasRolledBack())
				transaction.rollback();
		}
		logger.info(service.getClass() + "::" + strMethodName + "::CityName::"
				+ strCityName);
		logger.info(service.getClass() + "::" + strMethodName + "::Exit");
		return strCityName;
	}

	/*
	 * this method returns product code and product name
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getPaymentDetailsTransaction(
			String className, String paramName) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List pdList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		try {

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getPaymentDetailsTransaction Method");
			 * }
			 */

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("strproposalno", paramName));

			pdList = criteria.list();

			// String sql =
			// "select distinct strmodelnumber from dcf_master.dcf_vehicle_model_variant_m where 1= 1 and strmanufacturercd = '"+strmanufacturercd+"' and nvehiclemodelstatus = 1 and strvariant  not in ( '-','--') order by 1";
			/*
			 * String sql =
			 * "select * from dcf_payment_dtls_m where strproposalno = '"
			 * +paramName+"'"; if (logger.isDebugEnabled()) {
			 * logger.debug("In DBService.getchAgentCode Method sql-- "+ sql); }
			 * logger.info(
			 * "Inside DBService :: getPaymentDetailsTransaction method :: QUERY : "
			 * +sql); SQLQuery query = session.createSQLQuery(sql);
			 * 
			 * pdList =(List<PaymentDetails>)
			 * query.setResultTransformer(Transformers
			 * .aliasToBean(PaymentDetails.class)).list();
			 */

			logger.info("Inside DBService :: getPaymentDetailsTransaction method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getPaymentDetailsTransaction Method"
			 * ); }
			 */
			if (transaction != null && !transaction.wasCommitted())
				transaction.commit();
			// return pdList;
		} catch (Exception e) {

			// logger.info("Inside DBService :: getPaymentDetailsTransaction method :: Exception Occurred..."+e);
			logger.error(
					"Inside DBService :: getPaymentDetailsTransaction method :: Exception Occurred...",
					e);
			if (transaction != null && !transaction.wasRolledBack())
				transaction.rollback();
		}
		return pdList;
	}

	public FetchUserRoleList fetchUserRoleListCreatedBy(
			FetchUserRoleRequest fetchUserRoleReq) throws Exception {

		Session session = null;
		Transaction transaction = null;
		FetchUserRoleList userRoleList = null;
		String key = null;
		String value = null;

		ArrayList<RoleDetails> availableRoles = new ArrayList<RoleDetails>();

		String strMethodName = "fetchUserRoleListCreatedBy";

		try {
			logger.info(service.getClass() + "::" + strMethodName + "::Entered");
			userRoleList = new FetchUserRoleList();
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION
			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_getuserrole_createdby(:_userid)"
			 * ).setParameter("_userid", fetchUserRoleReq.getUserID());
			 * 
			 * 
			 * List list =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP) .list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"SELECT * from table(func_getuserrole_crtdby(:userid))")
					.addScalar("strroleid", StandardBasicTypes.STRING)
					.addScalar("strroleid", StandardBasicTypes.STRING)
					.setParameter("userid", fetchUserRoleReq.getUserID());

			// List list = query.list();

			List list = query
					.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			Iterator it = list.iterator();
			while (it.hasNext()) {
				HashMap<String, String> resultMap = (HashMap<String, String>) it
						.next();
				RoleDetails rolDet = new RoleDetails();
				if (resultMap.get("strroleid") != null) {
					value = (String) resultMap.get("strroleid");
					rolDet.setRoleId(value);
				}

				if (resultMap.get("strroledesc") != null) {
					value = (String) resultMap.get("strroledesc");
					rolDet.setRoleDesc(value);
				}

				availableRoles.add(rolDet);
			}
			userRoleList.setAvailableRoles(availableRoles);
			if (!transaction.wasCommitted())
				transaction.commit();
		} catch (Exception ex) {
			logger.error(service.getClass() + "::" + strMethodName
					+ " catch block ::", ex);
			if (!transaction.wasRolledBack())
				transaction.rollback();
		}
		logger.info(service.getClass() + "::" + strMethodName + "::Exit");
		return userRoleList;
	}

	public void resetUserPasswordAction(UserCredentials userCredentials)
			throws Exception {

		Session session = null;
		Transaction transaction = null;
		String strMethodName = "resetUserPasswordAction";
		String userKCId = null;
		try {
			logger.info("Inside " + service.getClass() + ":: " + strMethodName
					+ " :: Entered");
			// String
			// strSQL="select id from ".concat(usrmgtSchema).concat(".user_entity where username=:userId");
			// // Commented for Oracle Migration
			String strSQL = "select id from user_entity where username=:userId"; // Changes
																					// Added
																					// for
																					// oracle
																					// migration
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Query query = session.createSQLQuery(strSQL)
					.addScalar("id", StandardBasicTypes.STRING) // Added for
																// oracle
																// migration
					.setParameter("userId", userCredentials.getUserId());
			List outputList = query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();

			if (outputList != null) {
				Iterator listItr = outputList.iterator();

				HashMap<String, String> resultMap = new HashMap<String, String>();

				while (listItr.hasNext()) {
					resultMap = (HashMap<String, String>) listItr.next();

					if (resultMap.get("id") != null) {
						userKCId = resultMap.get("id");

						String resourcePath = "users/" + userKCId
								+ "/reset-password";
						// String
						// strDeleteSQL="delete from ".concat(usrmgtSchema).concat(".admin_event_entity where resource_path=:resourcePath and operation_type=:act");
						// // Commented for Oracle Migration

						String strDeleteSQL = "delete from admin_event_entity where resource_path=:resourcePath and operation_type=:act"; // Added
																																			// for
																																			// Oracle
																																			// Migration
						// Query
						// query1=session.createSQLQuery(strDeleteSQL).setParameter("resourcePath",
						// resourcePath);
						Query query1 = session.createSQLQuery(strDeleteSQL);
						query1.setParameter("resourcePath", resourcePath);
						query1.setParameter("act", "ACTION");
						int nDeleteRec = query1.executeUpdate();

						// if(logger.isDebugEnabled())
						logger.debug("Inside " + service.getClass() + ":: "
								+ strMethodName
								+ " :: Password Reset Action count ::"
								+ nDeleteRec);
					}

				}
			}

			if (!transaction.wasCommitted())
				transaction.commit();
		} catch (Exception ex) {
			logger.error(service.getClass() + "::" + strMethodName
					+ " catch block ::", ex);
			if (!transaction.wasRolledBack())
				transaction.rollback();
		}

		logger.info("Inside " + service.getClass() + ":: " + strMethodName
				+ " :: Exit");
	}

	/* Temporary Created Function For Time Being */
	public HashMap getAccountNoHouseBankBranch(String payMode) throws Exception {

		String strMethodName = "getAccountNoHouseBankBranch";
		HashMap accNoHouseBankMap = new HashMap();
		Session session = null;
		Transaction transaction = null;
		try {
			logger.info("Inside DBService :: " + strMethodName + " :: Entered");
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// String
			// strSQL="select * from func_getcovernote_other_reason(:_nparamtypecd,:_strparamcd)";
			// Query query=session.createSQLQuery(strSQL);
			// query.setParameter("_nparamtypecd", nParamTypeCd);
			// query.setParameter("_strparamcd", strParamCd);
			// paramList=query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();

			if (payMode != null && payMode.equalsIgnoreCase("S")) {
				accNoHouseBankMap.put("ACCOUNT_NUMBER",
						CommonConstants.CASH_ACCOUNT_NUMBER);
				accNoHouseBankMap.put("HOUSEBANKBRANCH_NUMBER",
						CommonConstants.CASH_HOUSEBANKBRANCH_NUMBER);
			} else if (payMode != null && payMode.equalsIgnoreCase("C")) {
				accNoHouseBankMap.put("ACCOUNT_NUMBER",
						CommonConstants.CHEQUE_ACCOUNT_NUMBER);
				accNoHouseBankMap.put("HOUSEBANKBRANCH_NUMBER",
						CommonConstants.CHEQUE_HOUSEBANKBRANCH_NUMBER);
			} else if (payMode != null && payMode.equalsIgnoreCase("D")) {
				accNoHouseBankMap.put("ACCOUNT_NUMBER",
						CommonConstants.DEMANDDRAFT_ACCOUNT_NUMBER);
				accNoHouseBankMap.put("HOUSEBANKBRANCH_NUMBER",
						CommonConstants.DEMANDDRAFT_HOUSEBANKBRANCH_NUMBER);
			} else if (payMode != null && payMode.equalsIgnoreCase("DA")) {
				accNoHouseBankMap.put("ACCOUNT_NUMBER",
						CommonConstants.ONLINE_ACCOUNT_NUMBER);
				accNoHouseBankMap.put("HOUSEBANKBRANCH_NUMBER",
						CommonConstants.ONLINE_HOUSEBANKBRANCH_NUMBER);
			} else {
				accNoHouseBankMap.put("ACCOUNT_NUMBER", "");
				accNoHouseBankMap.put("HOUSEBANKBRANCH_NUMBER", "");
			}

			transaction.commit();
		} catch (Exception ex) {
			logger.error("DBService :: " + strMethodName + " catch block ::",
					ex);
			transaction.rollback();
			throw ex;
		}
		return accNoHouseBankMap;
	}

	/* Temporary Created Function For Time Being */
	public void saveOutSoapInfo(OutBoundMaster outBoundMasterObj)
			throws Exception {
		Session session = null;
		Transaction transaction = null;
		String strMethodName = "saveOutSoapInfo";
		try {
			logger.info("Inside " + service.getClass() + ":: " + strMethodName
					+ " :: Entered");

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			session.saveOrUpdate(outBoundMasterObj);
			transaction.commit();

		} catch (Exception ex) {
			logger.error(service.getClass() + "::" + strMethodName
					+ " catch block ::", ex);
			if (!transaction.wasRolledBack())
				transaction.rollback();
		}
	}

	public void saveInSoapInfo(InBoundMaster inBoundMasterObj) throws Exception {
		Session session = null;
		Transaction transaction = null;
		String strMethodName = "saveInSoapInfo";
		try {
			logger.info("Inside " + service.getClass() + ":: " + strMethodName
					+ " :: Entered");

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			session.saveOrUpdate(inBoundMasterObj);
			transaction.commit();

		} catch (Exception ex) {
			logger.error(service.getClass() + "::" + strMethodName
					+ " catch block ::", ex);
			if (!transaction.wasRolledBack())
				transaction.rollback();
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getCityCodeByName(String className, String paramName,
			String type) throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		Session session = null;
		Transaction transaction = null;
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.getCityCodeByName Method"); }
		 */
		String cityCode = "";
		City md1 = null;
		List cityList = new ArrayList();
		logger.info("Inside DBService :: getCityCodeByName(String, String) method :: Execution Started");

		try {
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.and(
					Restrictions.eq("strcityname", paramName),
					Restrictions.eq("ndistrictcityflag", type)));

			cityList = criteria.list();

			for (Iterator iterator = cityList.iterator(); iterator.hasNext();) {
				md1 = (City) iterator.next();

			}

			if (cityList.size() > 0) {
				cityCode = md1.getStrcitycd();
			}
			logger.info("Inside DBService :: getCityCodeByName(String, String) method :: Execution Completed Successfully");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getCityCodeByName(String, String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getCityCodeByName(String, String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return cityCode;
	}

	public String getMoratoriumChk(String _strprodcd,
			String _strmanufacturercd, String _strmodelcd, String _nvehiclemy,
			String _strintermediarycd, String _strrtolocgrpcd,
			String _strrfueltype) { // <2086> : Method signature changed for
									// additional checking with fuelType
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		List result = null;
		Connection conn = null; // ADDED FOR ORACLE MIGRATION
		CallableStatement csmt = null; // ADDED FOR ORACLE MIGRATION
		int manufactYear;
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getMoratoriumChk :: " + " _strprodcd"
					+ _strprodcd + " _strmanufacturercd= " + _strmanufacturercd
					+ " _strmodelcd= " + _strmodelcd + " _nvehiclemy= "
					+ _nvehiclemy + " _strintermediarycd= "
					+ _strintermediarycd + " _strrtolocgrpcd= "
					+ _strrtolocgrpcd);

			manufactYear = Integer.parseInt(_nvehiclemy);
			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION
			/*
			 * Query query = session .createSQLQuery(
			 * "SELECT * from proc_getmoratorium_chk(:_strprodcd,:_strmanufacturercd,:_strmodelcd,:_nvehiclemy,:_strintermediarycd,:_strrtolocgrpcd,:_strrfueltype)"
			 * ) .setParameter("_strprodcd", _strprodcd)
			 * .setParameter("_strmanufacturercd", _strmanufacturercd)
			 * .setParameter("_strmodelcd", _strmodelcd)
			 * .setParameter("_nvehiclemy", manufactYear)
			 * .setParameter("_strintermediarycd", _strintermediarycd)
			 * .setParameter("_strrtolocgrpcd", _strrtolocgrpcd)
			 * .setParameter("_strrfueltype", _strrfueltype);// <2086> result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP) .list();
			 */

			/*
			 * Query query = (Query) session .createSQLQuery(
			 * "SELECT * from table(proc_getmoratorium_chk(:strprodcd,:strmanufacturercd,:strmodelcd,:nvehiclemy,:strintermediarycd,:strrtolocgrpcd,:strrfueltype))"
			 * ) .setParameter("strprodcd", _strprodcd)
			 * .setParameter("strmanufacturercd", _strmanufacturercd)
			 * .setParameter("strmodelcd", _strmodelcd)
			 * .setParameter("nvehiclemy", manufactYear)
			 * .setParameter("strintermediarycd", _strintermediarycd)
			 * .setParameter("strrtolocgrpcd", _strrtolocgrpcd)
			 * .setParameter("strrfueltype", _strrfueltype);// <2086> result =
			 * query.list();
			 */

			conn = this.getConnForCollableStmt(session);
			csmt = conn
					.prepareCall("{? = call proc_getmoratorium_chk(?,?,?,?,?,?,?) }");
			csmt.registerOutParameter(1, Types.VARCHAR);
			csmt.setString(2, _strprodcd);
			csmt.setString(3, _strmanufacturercd);
			csmt.setString(4, _strmodelcd);
			csmt.setInt(5, manufactYear);
			csmt.setString(6, _strintermediarycd);
			csmt.setString(7, _strrtolocgrpcd);
			csmt.setString(8, _strrfueltype);
			csmt.execute();
			strParamVal = csmt.getString(1);

			/*
			 * if (result != null) { HashMap<String, String> resultMap = new
			 * HashMap<String, String>(); resultMap = (HashMap) result.get(0);
			 * if (resultMap.get("proc_getmoratorium_chk") != null) {
			 * strParamVal = (String) resultMap .get("proc_getmoratorium_chk");
			 * } }
			 */
			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getMoratoriumChk ::", ex);
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		logger.info("DBService :: getMoratoriumChk :: strParamVal="
				+ strParamVal);

		return strParamVal;
	}

	// Start: RahulT<VAPT comments>| added to update billdesk transaction in
	// transaction table
	public void updateBilldeskTxn(PGTransaction objPgTransaction) {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.validateBilldeskTxn Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: validateBilldeskTxn method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Query query = session
					.createSQLQuery(" update dcf_pg_transaction set strpgtxnrefno = :txnrefno, strpgbankrefno = :bankrefno, strauthstatus = :status, strpgmsg = :pgresponse, strupdatedby =:strupdatedby, dtupdated = :dtupdated, ntxnstatus= :txnstatus ,cpitransid=:cpitransid"
							+ " where strscreenrefno = :orderId");
			query.setParameter("txnrefno", objPgTransaction.getPgTxnRefNo());
			query.setParameter("bankrefno", objPgTransaction.getPgBankRefNo());
			query.setParameter("status", objPgTransaction.getPgAuthStatus());
			query.setParameter("pgresponse", objPgTransaction.getPgMsg());
			query.setParameter("strupdatedby", objPgTransaction.getUpdatedBy());
			query.setParameter("dtupdated", objPgTransaction.getUpdatedDt());
			query.setParameter("txnstatus", objPgTransaction.getTxnStatus());
			query.setParameter("orderId", objPgTransaction.getScreenRefNo());
			query.setParameter("cpitransid", objPgTransaction.getPgId());
			int result = query.executeUpdate();

			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: payLinkFailedTxnGC error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
	}

	// End: RahulT<VAPT comments>| added to update billdesk transaction in
	// transaction table

	public double getBilldeskTransData(String orderId) {
		Session session = null;
		Transaction transaction = null;
		StringBuilder query = new StringBuilder();
		ArrayList<Object[]> retList = new ArrayList();
		double dprmamt = 0.0;
		try {
			logger.info("Inside DBService :: getBilldeskTransData(String) method :: Execution Started");

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			query.append("select ntxnamt from dcf_pg_transaction where strscreenrefno = :orderId");

			logger.info("Inside DBService :: getBilldeskTransData method :: buildQuery.toString() : "
					+ query.toString());

			SQLQuery sqlQuery = session.createSQLQuery(query.toString())
					.addScalar("ntxnamt", StandardBasicTypes.DOUBLE); // Added
																		// for
																		// oracle
																		// migration
			sqlQuery.setParameter("orderId", orderId);
			retList = (ArrayList) sqlQuery.list();
			if (retList != null) {
				Object lst = retList.get(0);
				dprmamt = (double) lst;
			}
			logger.info("Inside DBService :: getBilldeskTransData method :: Size Of list : "
					+ retList.size());

			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getBilldeskTransData:: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getBilldeskTransData method :: Exception Occurred..."
					+ e);
		}
		return dprmamt;
	}

	/*
	 * Service Created for getting workflow ID from Proposal No.
	 */

	public String getWorkFlowIdFromProposalNo(String propNo) {
		Session session = null;
		Transaction transaction = null;
		StringBuilder query = new StringBuilder();
		ArrayList<UserTransaction> retList = new ArrayList<UserTransaction>();
		String workFlowId = "";
		try {
			// if(logger.isDebugEnabled())logger.debug("Inside DBService :: getWorkFlowIdFromProposalNo(String) method :: Execution Started");
			String className = "com.majesco.dcf.common.tagic.entity.UserTransaction";
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();

			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// query.append("select strworkflowid from dcf_user_trans_dtl where strpropnumber = '"+propNo+"'");

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.and(Restrictions.eq("strPropNumber",
					propNo)));

			retList = (ArrayList) criteria.list();
			if (retList != null && retList.size() > 0) {
				UserTransaction lst = retList.get(0);
				workFlowId = (String) lst.getStrWorkflowId();
			}
			// if(logger.isDebugEnabled())logger.debug("Inside DBService :: getWorkFlowIdFromProposalNo method :: Size Of list : "+retList.size()+" ## "+workFlowId);

			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getBilldeskTransData:: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getBilldeskTransData method :: Exception Occurred..."
					+ e);
		}
		return workFlowId;
	}

	// Start: RahulT| Added to get Proposal Number from Motor Quote
	public String getMotorProposalFromQuote(Map<String, String> paramValueMap) {
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		ArrayList<MotorQuoteEntity> retList = new ArrayList<MotorQuoteEntity>();
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getMotorProposalFromQuote :: Entered ");
			String className = "com.majesco.dcf.common.tagic.entity.MotorQuoteEntity";
			Class classInstance = Class.forName(className);
			Criteria criteria = session.createCriteria(classInstance);

			for (Map.Entry<String, String> mapEntry : paramValueMap.entrySet()) {
				criteria.add(Restrictions.eq(mapEntry.getKey(),
						mapEntry.getValue()));
			}

			retList = (ArrayList) criteria.list();
			if (retList != null && retList.size() > 0) {
				MotorQuoteEntity quotDetail = retList.get(0);
				strParamVal = (String) quotDetail.getProposalNo();
			}
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getMotorProposalFromQuote:: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getMotorProposalFromQuote method :: Exception Occurred..."
					+ e);
		}
		return strParamVal;
	}

	// End: RahulT| Added to get Proposal Number from Motor Quote

	// Start: RahulT<production>| added to update payment transaction table
	public void updatePaymentDetailForSPL(PaymentDetails objPaymentDetails) {
		/*
		 * if (logger.isDebugEnabled()) {
		 * logger.debug("In DBService.updatePaymentDetailForSPL Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: updatePaymentDetailForSPL method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// String paymentTypeSPL = "SPL";

			Query query = session
					.createSQLQuery(" update dcf_payment_dtls_m set strpolicyno = :policyno, strgcsubreceiptno = :gcsubreceiptno, strgcreceiptno = :gcreceiptno where strproposalno = :proposalno and strpaymentmode='SPL'");
			query.setParameter("policyno", objPaymentDetails.getStrpolicyno());
			query.setParameter("gcsubreceiptno",
					objPaymentDetails.getStrgcsubreceiptno());
			query.setParameter("gcreceiptno",
					objPaymentDetails.getStrgcreceiptno());
			query.setParameter("proposalno",
					objPaymentDetails.getStrproposalno());
			int result = query.executeUpdate();

			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: updatePaymentDetailForSPL error ::",
					e);
			transaction.rollback();
			e.printStackTrace();
		}
	}

	// End:RahulT<production>| added to update payment transaction table
	// Start: RahulT <Production 1235> | code added to check whether proposal no
	// created through new channel portal
	public boolean isIIPProposal(String propNo) {
		Session session = null;
		Transaction transaction = null;
		StringBuilder query = new StringBuilder();
		ArrayList<UserTransaction> retList = new ArrayList<UserTransaction>();
		boolean isIIPPortalProposal = false;
		try {
			// if(logger.isDebugEnabled())logger.debug("Inside DBService :: isIIPProposal(String) method :: Execution Started");
			String className = "com.majesco.dcf.common.tagic.entity.UserTransaction";
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();

			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// query.append("select strworkflowid from dcf_user_trans_dtl where strpropnumber = '"+propNo+"'");

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.and(Restrictions.eq("strPropNumber",
					propNo)));

			retList = (ArrayList) criteria.list();
			if (retList != null && retList.size() > 0) {
				isIIPPortalProposal = false;
			} else {
				isIIPPortalProposal = true;
			}
			// if(logger.isDebugEnabled())logger.debug("Inside DBService :: isIIPProposal method :: Size Of list : "+retList.size()+" ## "+isIIPPortalProposal);

			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: isIIPProposal:: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: isIIPProposal method :: Exception Occurred..."
					+ e);
		}
		return isIIPPortalProposal;
	}

	// Start : 03-Jul-2017 : Method to fetch Key & Values by EffDate into table
	// : Vishal
	public String getValueByEffDate(String key, Date effDate) {
		String strval = null;
		Session session = null;
		List result = null;
		Transaction transaction = null;
		CallableStatement csmt = null; // ADDED FOR ORACLE MIGRATION
		Connection conn = null; // ADDED FOR ORACLE MIGRATION
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getValueByEffDate :: Entered ");
			String className = "com.majesco.dcf.common.tagic.entity.ValueByDate";

			// START : ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session .createSQLQuery(
			 * "SELECT * from func_getvalue_by_effdate(:_paramkey,:_effdate)");
			 * query.setParameter("_paramkey", key);
			 * query.setParameter("_effdate", effDate); result = query.list();
			 * strval = (String) result.get(0);
			 */

			Date todaysDate = new Date();
			DateFormat df3 = new SimpleDateFormat("dd-MMM-yy");
			String str3 = df3.format(effDate);
			logger.info("Inside getValueByEffDate Date:: " + str3);

			conn = this.getConnForCollableStmt(session);
			csmt = conn
					.prepareCall("{? = call func_getvalue_by_effdate(?,?) }");
			csmt.registerOutParameter(1, Types.VARCHAR);
			csmt.setString(2, key);
			csmt.setString(3, str3);
			csmt.execute();
			logger.info("key::" + key + " and str3::" + str3);
			strval = csmt.getString(1);
			logger.info("csmt.getString(1) ::" + strval);
			// END : ADDED FOR ORACLE MIGRATION
			transaction.commit();
		} catch (Exception e) {
			logger.error("Inside DBService :: getValueByEffDate:: Exception Occurred..."
					+ e);
			transaction.rollback();
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		return strval;
	}

	// End : 03-Jul-2017 : Method to fetch Key & Values by EffDate into table :
	// Vishal
	// START(19-07-2017): Code changes for defect 1240.
	public PaymentDetails getCustomerDetails(String receiptNumber) {
		Session session = null;
		Transaction transaction = null;
		StringBuilder query = new StringBuilder();
		PaymentDetails paydm = new PaymentDetails();
		ArrayList<PaymentDetails> retList = new ArrayList<PaymentDetails>();
		try {
			// if(logger.isDebugEnabled())logger.debug("Inside DBService :: getCustomerDetails(String) method :: Execution Started");
			String className = "com.majesco.dcf.common.tagic.entity.PaymentDetails";
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();

			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.and(Restrictions.eq("strgcreceiptno",
					receiptNumber)));
			retList = (ArrayList) criteria.list();
			if (retList != null && retList.size() > 0) {
				paydm = (PaymentDetails) retList.get(0);
			}

			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getCustomerDetails:: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getCustomerDetails method :: Exception Occurred..."
					+ e);
		}

		return paydm;
	}

	// END:Code changes for defect 1240.

	// Start: RahulT <Production 1814>| code added to deactivate old active SPL
	// links to the newly created proposal
	public void markOldLinkInactive(String strProposalNo, String strUserId) {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.markOldLinkInactive Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: markOldLinkInactive method :: Execution Started -->"
				+ strProposalNo + " UserId--> " + strUserId);
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// Start: Internal code changes
			try {
				Query query = session
						.createSQLQuery(" update dcf_self_pay_trans set paylinkused = :inactive, dtupdated = :dttime, strupdatedby = :updatedBy"
								+ " where strproppolno = :proposalNo and paylinkused = :active");
				query.setParameter("inactive", "2");
				query.setParameter("dttime", new Date());
				query.setParameter("updatedBy", strUserId);
				query.setParameter("proposalNo", strProposalNo);
				query.setParameter("active", "0");
				int result = query.executeUpdate();
			} catch (Exception e) {
				logger.error(
						"In DBService ::error while updating dcf_self_pay_trans table ::",
						e);
				transaction.rollback();
				e.printStackTrace();
			}

			// Start: RahulT <SIT 2027> | code added to mark all AD SPL receipt
			// as inactive
			// 04102017| Mantis ID 2027
			// internal code changes
			try {
				Query queryAD = session
						.createSQLQuery(" update dcf_ad_receipt_spl set status = :inactive, dtupdated = :dttime, updatedby = :updatedBy "
								+ " where proposalno = :proposalNo and status = :active ");
				queryAD.setParameter("inactive", "2");
				queryAD.setParameter("dttime", new Date());
				queryAD.setParameter("updatedBy", strUserId);
				queryAD.setParameter("proposalNo", strProposalNo);
				queryAD.setParameter("active", "0");
				queryAD.executeUpdate();
				// End: RahulT <SIT 2027> | code added to mark all AD SPL
				// receipt as inactive
			}

			catch (Exception e) {
				logger.error(
						"In DBService ::error while updating dcf_ad_receipt_spl table ::",
						e);
				transaction.rollback();
				e.printStackTrace();
			}

			logger.info("Inside DBService :: markOldLinkInactive method :: Execution Completed successfully--> ");
			// End: Internal code changes

			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: markOldLinkInactive error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
	}

	// End: RahulT <Production 1814>| code added to deactivate old active SPL
	// links to the newly created proposal

	// For Issue ID 1899 <Change Request>
	public double getIDVRelaxationValue(
			IDVRelaxationRequest idvRelaxationRequest) {
		double strval = 0;
		Session session = null;
		List result = null;
		Transaction transaction = null;
		Connection conn = null; // ADDED FOR ORACLE MIGRATION
		CallableStatement csmt = null; // ADDED FOR ORACLE MIGRATION
		BigDecimal bigDecimal;
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getIDVRelaxationValue :: Entered ");

			// START : ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session .createSQLQuery(
			 * "SELECT * from func_getidv_relaxation_val(:_strintermediarycd, :_strmanufacturercd, :_strmodelcd, :_strvariantcd, :_nvehicleage)"
			 * ); query.setParameter("_strintermediarycd",
			 * idvRelaxationRequest.getStrintermediarycd());
			 * query.setParameter("_strmanufacturercd",
			 * idvRelaxationRequest.getStrmanufacturercd());
			 * query.setParameter("_strmodelcd",
			 * idvRelaxationRequest.getStrmodelcd());
			 * query.setParameter("_strvariantcd",
			 * idvRelaxationRequest.getStrvariantcd());
			 */

			conn = this.getConnForCollableStmt(session);
			csmt = conn
					.prepareCall("{? = call func_getidv_relaxation_val(?,?,?,?,?) }");
			csmt.registerOutParameter(1, Types.NUMERIC);
			csmt.setString(2, idvRelaxationRequest.getStrintermediarycd());
			csmt.setString(3, idvRelaxationRequest.getStrmanufacturercd());
			csmt.setString(4, idvRelaxationRequest.getStrmodelcd());
			csmt.setString(5, "null");
			csmt.setString(6, idvRelaxationRequest.getStrvariantcd());
			csmt.execute();
			strval = csmt.getDouble(1);

			/*
			 * if (idvRelaxationRequest != null &&
			 * idvRelaxationRequest.getNvehicleage() != null &&
			 * !idvRelaxationRequest.getNvehicleage().equals("")) {
			 * query.setParameter("_nvehicleage",
			 * Integer.parseInt(idvRelaxationRequest.getNvehicleage())); } else
			 * { query.setParameter("_nvehicleage", 0); }
			 * 
			 * result = query.list(); bigDecimal = (BigDecimal) result.get(0);
			 * strval = bigDecimal.doubleValue();
			 */

			// END : ADDED FOR ORACLE MIGRATION
			transaction.commit();
		} catch (Exception e) {
			logger.error("Inside DBService :: getValueByEffDate:: Exception Occurred..."
					+ e);
			transaction.rollback();
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		return strval;
	}

	// Start: RahulT| <Production 2027>| code added to allow part payment for
	// SPL+AD
	public double fetchUnRealizedRcptAmt(String receiptNumber) {
		double unRealizedAmt = 0.0;
		Transaction transaction = null;
		List<AdvanceReceiptDtl> alResult = new ArrayList<>();

		try {
			// if(logger.isDebugEnabled())
			logger.debug("In DBService.fetchUnRealizedRcptAmt Entered..");

			Session session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive())
				session.beginTransaction();

			String className = "com.majesco.dcf.common.tagic.entity.AdvanceReceiptDtl";
			Class classInstance = Class.forName(className);

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.and(
					Restrictions.eq("receiptNumber", receiptNumber),
					Restrictions.eq("status", "0"))); // Status 0 for active
														// Payment link.

			alResult = (List<AdvanceReceiptDtl>) criteria.list();

			for (AdvanceReceiptDtl advanceReceipt : alResult) {
				if (advanceReceipt.getReceiptAmount() != null
						&& !advanceReceipt.getReceiptAmount().equals(
								CommonConstants.BLANK_STRING)) {
					double allocatedAmount = Double.valueOf(advanceReceipt
							.getReceiptAmount());

					unRealizedAmt = unRealizedAmt + allocatedAmount;
				}
			}

			transaction.commit();

		}

		catch (Exception ex) {
			transaction.rollback();
			logger.error(ex.getMessage(), ex);
		}
		return unRealizedAmt;
	}

	// End: RahulT| <Production 2027>| code added to allow part payment for
	// SPL+AD

	// For Issue ID 2018 <Change Request>
	public ArrayList getAnnouncementValue(String _startdt, String _enddt,
			String _starttm, String _endtm) {
		double strval = 0;
		Session session = null;
		List result = null;
		Transaction transaction = null;
		BigDecimal bigDecimal;
		HashMap resultMap = new HashMap();
		ArrayList<Object[]> retList = new ArrayList();
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getAnnouncementValue :: Entered ");

			// START : ADDED FOR ORACLE MIGRATION

			Query query = session
					.createSQLQuery(
							"SELECT * from table(func_getannouncement_val(:startdt, :enddt, :starttm, :endtm))")
					.addScalar("strparamname", StandardBasicTypes.STRING)
					.addScalar("strparamdesc", StandardBasicTypes.STRING);
			query.setParameter("startdt", _startdt);
			query.setParameter("enddt", _enddt);
			query.setParameter("starttm", _starttm);
			query.setParameter("endtm", _endtm);

			// END : ADDED FOR ORACLE MIGRATION

			retList = (ArrayList) query.list();
			/*
			 * if(result!=null && result.size()>0) {
			 * 
			 * resultMap=(HashMap)result.get(0); //
			 * resultMap.put("_strparamname", intermediary_code); //
			 * resultMap.put("_strparamdesc", intermediary_name);
			 * 
			 * }
			 */
			transaction.commit();
		} catch (Exception e) {
			logger.error("Inside DBService :: getAnnouncementValue:: Exception Occurred..."
					+ e);
			transaction.rollback();
		}
		return retList;
	}

	// For Issue ID 2129 <Change Request>
	public ArrayList getCoversConfigDetails(String _strvehiclesubclasscd) {
		double strval = 0;
		Session session = null;
		List result = null;
		Transaction transaction = null;
		BigDecimal bigDecimal;
		HashMap resultMap = new HashMap();
		ArrayList<Object[]> retList = new ArrayList();
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getCoversConfigDetails :: Entered ");

			// START :CHANGES DONE FOR ORACLE MIGRATION

			/*
			 * Query query = session .createSQLQuery(
			 * "SELECT * from func_subcoversconfgdtls(:strvehiclesubclasscd)");
			 * query.setParameter("_strvehiclesubclasscd",
			 * _strvehiclesubclasscd);
			 */

			Query query = session
					.createSQLQuery(
							"SELECT * from table(func_subcoversconfgdtls(:strvehiclesubclasscd))")
					.addScalar("strdrivingtution_tp", StandardBasicTypes.STRING)
					.addScalar("strdrivingtution_od", StandardBasicTypes.STRING);

			query.setParameter("strvehiclesubclasscd", _strvehiclesubclasscd);
			// END :CHANGES DONE FOR ORACLE MIGRATION
			retList = (ArrayList) query.list();
			/*
			 * if(result!=null && result.size()>0) {
			 * 
			 * resultMap=(HashMap)result.get(0); //
			 * resultMap.put("strdrivingtution_tp", intermediary_code); //
			 * resultMap.put("strdrivingtution_od", intermediary_name);
			 * 
			 * }
			 */
			transaction.commit();
		} catch (Exception e) {
			logger.error("Inside DBService :: getCoversConfigDetails:: Exception Occurred..."
					+ e);
			transaction.rollback();
		}
		return retList;
	}

	// Start: RahulT <1266>| code added for HSBC UPI integration
	public UpiTransactionDtl getUPITransDtl(String portalTransId,
			String upiTransId) {

		UpiTransactionDtl upiEntity = new UpiTransactionDtl();
		Transaction transaction = null;
		Session session = null;
		List<UpiTransactionDtl> lstUpiTransDtl = new ArrayList<UpiTransactionDtl>();
		UpiTransactionDtl objUPITransaction = null;

		ArrayList<Object[]> resultData = new ArrayList();

		logger.info("DBService :: getUPITransDtl :: portalTransId "
				+ portalTransId + ", upiTransId:: " + upiTransId);

		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive())
				session.beginTransaction();

			String className = "com.majesco.dcf.pg.upi.entity.UpiTransactionDtl";
			Class classInstance = Class.forName(className);

			// Criteria criteria= session.createCriteria(classInstance);
			/*
			 * lstUpiTransDtl =
			 * (List<UpiTransactionDtl>)criteria.add(Restrictions
			 * .and(Restrictions.eq("portalTransId", portalTransId),
			 * Restrictions.eq("portalTransIdUPI",
			 * upiTransId),Restrictions.ne("isProcessed",
			 * CommonConstants.UPI_POLICY_GENERATION_INITIATED))).list();
			 */

			/*
			 * lstUpiTransDtl =
			 * (List<UpiTransactionDtl>)criteria.add(Restrictions.and(
			 * Restrictions.eq("portalTransIdUPI",
			 * portalTransId),Restrictions.ne("isProcessed",
			 * CommonConstants.UPI_POLICY_GENERATION_INITIATED))).list();
			 */

			SQLQuery upiTransDtlQuery = session
					.createSQLQuery("select portaltransid,transamount,payerva from dcf_upi_trans_dtl where portaltransidupi=:_portalTransId and isprocessed=:_notProcessed");

			upiTransDtlQuery.setParameter("_portalTransId", portalTransId);
			upiTransDtlQuery.setParameter("_notProcessed", "0");

			resultData = (ArrayList) upiTransDtlQuery.list();

			for (Object[] row : resultData) {
				objUPITransaction = new UpiTransactionDtl();
				objUPITransaction
						.setPortalTransId((String) nullCheckString(row[0]));
				objUPITransaction
						.setTransAmount((String) nullCheckString(row[1]));
			}

			/*
			 * lstUpiTransDtl = (List<UpiTransactionDtl>)
			 * upiTransDtlQuery.setResultTransformer
			 * (Transformers.ALIAS_TO_ENTITY_MAP).list(); if
			 * (lstUpiTransDtl!=null && !lstUpiTransDtl.isEmpty()){ //return
			 * lstUpiTransDtl.get(0); objUPITransaction = lstUpiTransDtl.get(0);
			 * }
			 */

			transaction.commit();
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			transaction.rollback();
		}
		return objUPITransaction;
	}

	public UpiTransactionDtl getCHPOrderId(String portalTransIdUPI) {

		UpiTransactionDtl upiEntity = new UpiTransactionDtl();
		Transaction transaction = null;
		Session session = null;
		UpiTransactionDtl objUPITransaction = null;
		String chpOrderId = null;
		List<UpiTransactionDtl> lstUpiTransDtl = new ArrayList<UpiTransactionDtl>();
		ArrayList<Object[]> resultData = new ArrayList();

		logger.info("DBService :: getCHPOrderId :: portalTransIdUPI "
				+ portalTransIdUPI);

		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive())
				session.beginTransaction();

			String className = "com.majesco.dcf.pg.upi.entity.UpiTransactionDtl";
			Class classInstance = Class.forName(className);

			/*
			 * Criteria criteria= session.createCriteria(classInstance);
			 * lstUpiTransDtl =
			 * (List<UpiTransactionDtl>)criteria.add(Restrictions
			 * .and(Restrictions.eq("portalTransIdUPI",
			 * portalTransIdUPI))).list();
			 * logger.info("lstUpiTransDtl object::"+lstUpiTransDtl);
			 * logger.info
			 * ("lstUpiTransDtl object size::"+lstUpiTransDtl.size()); if
			 * (lstUpiTransDtl!=null && !lstUpiTransDtl.isEmpty()){ chpOrderId =
			 * lstUpiTransDtl.get(0).getPortalTransId(); }
			 */
			// START : ADDED FOR ORACLE MIGRATION

			/*
			 * Query query = session .createSQLQuery(
			 * "SELECT * from proc_getupichporderid(:portalTransIdUPI, :notProcessed)"
			 * ); query.setParameter("_portalTransIdUPI", portalTransIdUPI);
			 * query.setParameter("_notProcessed", "0");
			 */

			Query query = session
					.createSQLQuery(
							"SELECT * from table(proc_getupichporderid(:portalTransIdUPI, :notProcessed))")
					.addScalar("portaltransid", StandardBasicTypes.STRING)
					.addScalar("transamount", StandardBasicTypes.STRING);
			query.setParameter("portalTransIdUPI", portalTransIdUPI);
			query.setParameter("notProcessed", "0");

			// END : ADDED FOR ORACLE MIGRATION

			ArrayList<Object[]> retList = (ArrayList) query.list();

			/*
			 * if(retList!=null){ chpOrderId=(String)retList.get(0); }
			 */

			for (Object[] row : retList) {
				objUPITransaction = new UpiTransactionDtl();
				objUPITransaction
						.setPortalTransId((String) nullCheckString(row[0]));
				objUPITransaction
						.setTransAmount((String) nullCheckString(row[1]));
			}

			logger.info("DBService :: getCHPOrderId :: chpOrderId "
					+ chpOrderId);
			transaction.commit();
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			transaction.rollback();
		}
		return objUPITransaction;
	}

	public void updateUPITxn(UpiTransactionDtl objHSBCUPITrans) {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.updateUPITxn Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: updateUPITxn method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Query query = session
					.createSQLQuery(" update dcf_upi_trans_dtl set isprocessed = :isprocessed, upifinalrescode = :upifinalrescode, updatedby = :updatedby, transstatus = :transstatus, npcitransid = :npcitransid, referenceid = :referenceid "
							+ " where portaltransidupi = :portaltransidupi");
			query.setParameter("isprocessed", "1");
			query.setParameter("upifinalrescode",
					objHSBCUPITrans.getUpiResponseCode());
			query.setParameter("updatedby", objHSBCUPITrans.getUpdatedBy());
			query.setParameter("transstatus", objHSBCUPITrans.getTransStatus());
			query.setParameter("npcitransid", objHSBCUPITrans.getNpciTransId());
			query.setParameter("referenceid", objHSBCUPITrans.getReferenceId());
			query.setParameter("portaltransidupi",
					objHSBCUPITrans.getPortalTransIdUPI());

			int result = query.executeUpdate();

			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: updateUPITxn error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
	}

	// End: RahulT <1266>| code added for HSBC UPI integration

	// Start: KetanM <Production 2505>| Re-hit mechanism to be put up for
	// policycumreciept generation service
	public void isErrorWhileSelfPayTrans(String strExcpn, String strProposalNo,
			String strUserId, String hitCount) {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.isErrorWhileSelfPayTrans Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		String count = null;
		Integer intCount = 0;
		logger.info("Inside DBService :: isErrorWhileSelfPayTrans method --> strProposalNo : "
				+ strProposalNo
				+ " --> strUserId : "
				+ strUserId
				+ " : strExcpn.Length() : " + strExcpn.length());
		try {

			count = this.getStrLinkHitCount(strProposalNo);

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			if (hitCount != null && !hitCount.equals("")) {
				intCount = Integer.parseInt(hitCount);
			} else {
				if (count == null) {
					intCount = 1;
				} else {
					intCount = (Integer.parseInt(count) + 1);
				}
			}

			Query query = session
					.createSQLQuery("update dcf_self_pay_trans set strlinkhitcount = :_hitcount, strerrorexception = :_strExcpn, dtupdated = :_dttime, strupdatedby = :_updatedBy where strproppolno = :_proposalNo");
			query.setParameter("_hitcount", intCount);
			query.setParameter("_strExcpn", strExcpn);
			query.setParameter("_dttime", new Date());
			query.setParameter("_updatedBy", strUserId);
			query.setParameter("_proposalNo", strProposalNo);
			int result = query.executeUpdate();

			logger.info("Inside DBService :: isErrorWhileSelfPayTrans method :: Execution Completed successfully--> "
					+ result);

			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: isErrorWhileSelfPayTrans error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
	}

	public String getStrLinkHitCount(String strProposalNo) {
		double strval = 0;
		Session session = null;
		Transaction transaction = null;
		BigDecimal bigDecimal;
		String hitCount = null;
		List result = null;
		String strParamVal = null;
		Connection conn = null; // ADDED FOR ORACLE MIGRATION
		CallableStatement csmt = null; // ADDED FOR ORACLE MIGRATION
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.info("DBService :: getStrLinkHitCount :: Entered ");

			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION
			/*
			 * Query query = session.createSQLQuery(
			 * "SELECT * from func_get_strlinkhitcount(:_strProposalNo)");
			 * query.setParameter("_strProposalNo", strProposalNo);
			 * 
			 * 
			 * result =
			 * query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			 */

			/*
			 * Query query = (Query) session .createSQLQuery(
			 * "SELECT * from table(func_get_strlinkhitcount(:strProposalNo))");
			 * query.setParameter("strProposalNo", strProposalNo);
			 * 
			 * result = query.list();
			 */

			conn = this.getConnForCollableStmt(session);
			csmt = conn.prepareCall("{? = call func_get_strlinkhitcount(?) }");
			csmt.registerOutParameter(1, Types.VARCHAR);
			csmt.setString(2, "strProposalNo");
			csmt.execute();
			strParamVal = csmt.getString(1);

			/*
			 * if (result != null) { HashMap resultMap = new HashMap();
			 * resultMap = (HashMap) result.get(0); if
			 * (resultMap.get("func_get_strlinkhitcount") != null) { strParamVal
			 * = (String) resultMap .get("func_get_strlinkhitcount"); } }
			 */

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			transaction.commit();
		} catch (Exception e) {
			logger.error("Inside DBService :: getStrLinkHitCount :: Exception Occurred..."
					+ e);
			transaction.rollback();
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		return strParamVal;
	}

	public List processRehitMechForExceptionPolicy() throws Exception {

		List paramList = null;

		String strMethodName = "processRehitMechForExceptionPolicy";
		Session session = null;
		Transaction transaction = null;
		try {
			logger.info("Inside DBService :: " + strMethodName + " :: Entered");

			String totalCount = this
					.getConfigParamVal(CommonConstants.PROCESS_REHIT_MECH_CONFIG_KEY);
			Integer totCount = Integer.parseInt(totalCount);

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * Query query=session.createSQLQuery(
			 * "select * from func_rehit_exception_policy_val(:_totalHitCount)"
			 * ); query.setParameter("_totalHitCount", totCount);
			 * 
			 * paramList=query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
			 * .list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"select * from table(func_reht_excpt_polcy_val(:totalHitCount))")
					.addScalar("strorderid", StandardBasicTypes.STRING)
					.addScalar("strrequestmsg", StandardBasicTypes.STRING)
					.addScalar("strpgtxnrefno", StandardBasicTypes.STRING);

			query.setParameter("totalHitCount", totCount);

			paramList = query
					.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			transaction.commit();
		} catch (Exception ex) {
			logger.error("DBService :: " + strMethodName + " catch block ::",
					ex);
			transaction.rollback();
			throw ex;
		}
		return paramList;
	}

	// End: KetanM <Production 2505>| Re-hit mechanism to be put up for
	// policycumreciept generation service

	// Start: KetanM Internal EOD Time Taken Changes
	/*
	 * this method returns whole map of proposal numbers for perticular producer
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap getPaymentDetailsMap(String className, String paramName)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List pdList = new ArrayList();
		Session session = null;
		HashMap<String, String> paymentMap = null;
		Transaction transaction = null;
		try {

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getPaymentDetailsMap Method"); }
			 */

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// START:CHANGES DONE FOR THE ORACLE MIGRATION
			Query query = session
					.createSQLQuery(
							"SELECT * from table(func_getPaymentDetailsMap(:strproducercode))")
					.addScalar("strproposalno", StandardBasicTypes.STRING);

			query.setParameter("strproducercode", paramName);

			// END:CHANGES DONE FOR THE ORACLE MIGRATION
			pdList = (ArrayList) query.list();
			if (pdList != null && pdList.size() > 0) {
				paymentMap = new HashMap<String, String>();
				for (int i = 0; i < pdList.size(); i++) {
					paymentMap.put(pdList.get(i).toString(), null);
				}

			}
			transaction.commit();

			logger.info("Inside DBService :: getPaymentDetailsMap method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getPaymentDetailsMap Method"); }
			 */
			if (transaction != null && !transaction.wasCommitted())
				transaction.commit();
		} catch (Exception e) {
			logger.error(
					"Inside DBService :: getPaymentDetailsMap method :: Exception Occurred...",
					e);
			if (transaction != null && !transaction.wasRolledBack())
				transaction.rollback();
		}
		return paymentMap;
	}

	// End: KetanM Internal EOD Time Taken Changes
	// 1272 : New Method added for saving Roles : Start
	public int saveRole(Object insertObj) {
		Session session = null;
		Transaction transaction = null;

		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.saveRole Method"); }
		 */

		logger.info("Inside DBService :: saveRole method :: Execution Started");

		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			session.save(insertObj);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			transaction.rollback();
			// TODO Auto-generated catch block
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("DBService.saveRole Catch block"); }
			 */
			e.printStackTrace();
			return 0;
		}

	}

	// 1272 : New Method added for saving Roles : End
	// Added For Issue ID 1272
	public InternalUser getInternalUser(String strUserId) {
		Session session = null;
		Transaction transaction = null;

		InternalUser user = null;
		List<InternalUser> retList = null;
		try {
			// if(logger.isDebugEnabled())logger.debug("Inside DBService :: getInternalUser(String) method :: Execution Started :- "+strUserId);
			String className = "com.majesco.dcf.common.tagic.entity.InternalUser";
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();

			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// String sql =
			// "select * from dcfum.dcf_internal_user where userid = '"+strUserId+"'";
			// // Commented for oracle migration
			String sql = "select * from dcf_internal_user where userid = '"
					+ strUserId + "'"; // Added for oracle migration
			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("In DBService.getInternalUser Method sql-- "+ sql);
			 * }
			 */
			logger.info("Inside DBService :: getPaymentDetailsTransaction method :: QUERY : "
					+ sql);
			SQLQuery query = session
					.createSQLQuery(sql)
					// START : ADDED FOR ORACLE MIGRATION
					.addScalar("nisactive", StandardBasicTypes.INTEGER)
					.addScalar("nisadmin", StandardBasicTypes.INTEGER)
					.addScalar("dtcreated", StandardBasicTypes.TIMESTAMP)
					.addScalar("dtupdated", StandardBasicTypes.TIMESTAMP)
					.addScalar("userid", StandardBasicTypes.STRING)
					.addScalar("username", StandardBasicTypes.STRING)
					.addScalar("strcreatedby", StandardBasicTypes.STRING)
					.addScalar("strupdatedby", StandardBasicTypes.STRING);
			// END : ADDED FOR ORACLE MIGRATION

			retList = (List<InternalUser>) query.setResultTransformer(
					Transformers.aliasToBean(InternalUser.class)).list();

			/*
			 * Criteria criteria = session.createCriteria(classInstance);
			 * criteria.add(Restrictions.eq("userId", strUserId));
			 */
			// if(logger.isDebugEnabled())logger.debug("Inside DBService :: getInternalUser(String) method :: Size"+retList.size());
			/* retList = (ArrayList<InternalUser>)criteria.list(); */
			if (retList != null && retList.size() > 0) {
				user = (InternalUser) retList.get(0);
			}
			if (user != null)
				// if(logger.isDebugEnabled())logger.debug("Inside DBService :: getInternalUser method :: Size Of list : "+retList.size()+" ## "+user.getUserid()+" "+user.getUsername());

				transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getInternalUser:: Exception Occurred..."
					+ e.toString());
			logger.error(
					"Inside DBService :: getInternalUser method :: Exception Occurred...",
					e);
		}
		return user;
	}

	// Start: KetanM 2594 - FastLane Changes
	/*
	 * this method returns code for manufacturer or model depending on condition
	 */
	public String getFastLaneMakeModelCode(String _manufactVal,
			String _manufactCd, String _modelVal) {
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		List result = null;
		int manufactYear;
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Query query = session
					.createSQLQuery(
							"SELECT * from func_getfastlanemakemodelcode(:_manufactVal,:_manufactCd,:_modelVal)")
					.setParameter("_manufactVal", _manufactVal)
					.setParameter("_manufactCd", _manufactCd)
					.setParameter("_modelVal", _modelVal);
			result = query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
					.list();

			if (result != null) {
				HashMap<String, String> resultMap = new HashMap<String, String>();
				resultMap = (HashMap) result.get(0);
				if (resultMap.get("func_getfastlanemakemodelcode") != null) {
					strParamVal = (String) resultMap
							.get("func_getfastlanemakemodelcode");
				}
			}
			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getFastLaneMakeModelCode ::", ex);
		}

		return strParamVal;
	}

	// End: KetanM 2594 - FastLane Changes
	// Start:<YogeshM>:<06/12/2017>:<PROD>:<DefectID-NA>:<Added code to get next
	// sequence value for CHP orderID>
	@SuppressWarnings("unchecked")
	public Long getNextOrderSeq() {
		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.getNextOrderSeq Method"); }
		 */
		Session session = null;
		Transaction transaction = null;
		// Iterator<BigInteger> iter =
		// Collections.<BigInteger>emptyList().iterator(); // Commented for
		// oracle migration
		Long orderSeq = null;
		logger.info("Inside DBService :: getNextOrderSeq method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// Start: Changes done for the oracle migration
			/*
			 * Query query = session
			 * .createSQLQuery(" SELECT nextval('chp_orderid_seq') ");
			 * 
			 * iter = query.list().iterator(); orderSeq =
			 * iter.next().longValue();
			 */

			Query query = session
					.createSQLQuery(" SELECT chp_orderid_seq.nextval from dual");

			List iter = query.list();

			iter.get(0);

			orderSeq = Long.parseLong(iter.get(0) + "");

			System.out.println(orderSeq);

			// End: Changes done for the oracle migration
			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: getNextOrderSeq error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
		return orderSeq;
	}

	// End:<YogeshM>:<06/12/2017>:<PROD>:<DefectID-NA>:<Added code to get next
	// sequence value for CHP orderID>
	// Start : Vishal<Mantis 3267> : New method added for renewal serach from
	// Portal : 16-Jan-2017
	public List<RenPolicyMaster> renewalSearchPortal(String strClassName,
			RenewalSearchRequest renewalSearchRequest) {

		String strMethodName = "renewalSearchPortal";
		Session session = null;
		Transaction transaction = null;
		List<RenPolicyMaster> renPolEntityList = new ArrayList<RenPolicyMaster>();
		Date dtFrom = null;
		Date dtTo = null;
		try {

			logger.info(service.getClass() + "::" + strMethodName + "::Entered");
			Class classInstance = Class.forName(strClassName);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			/*
			 * InternalUser internalUser =
			 * getInternalUser(renewalSearchRequest.getUserID());
			 */

			// String sql =
			// "select * from dcfum.dcf_internal_user where userid = '"+renewalSearchRequest.getUserID()+"'";
			// // Commented for oracle migration
			String sql = "select * from dcf_internal_user where userid = '"
					+ renewalSearchRequest.getUserID() + "'"; // Added for
																// oracle
																// migration
			/*
			 * if (logger.isDebugEnabled()) {
			 * logger.debug("In DBService.getInternalUser Method sql-- "+ sql);
			 * }
			 */
			logger.info("Inside DBService :: getPaymentDetailsTransaction method :: QUERY : "
					+ sql);
			SQLQuery query = session
					.createSQLQuery(sql)

					// START : ADDED FOR ORACLE MIGRATION
					.addScalar("nisactive", StandardBasicTypes.INTEGER)
					.addScalar("nisadmin", StandardBasicTypes.INTEGER)
					.addScalar("dtcreated", StandardBasicTypes.TIMESTAMP)
					.addScalar("dtupdated", StandardBasicTypes.TIMESTAMP)
					.addScalar("userid", StandardBasicTypes.STRING)
					.addScalar("username", StandardBasicTypes.STRING)
					.addScalar("strcreatedby", StandardBasicTypes.STRING)
					.addScalar("strupdatedby", StandardBasicTypes.STRING)
			// END : ADDED FOR ORACLE MIGRATION
			;

			List retList = (List<InternalUser>) query.setResultTransformer(
					Transformers.aliasToBean(InternalUser.class)).list();

			if (retList != null && retList.size() > 0) // 3250 : COde change for
														// MIBL Customer Change.
														// : 16-Mar-2018
			{
			} else {
				criteria.add(Restrictions.and(Restrictions.eq("producercd",
						renewalSearchRequest.getProducerCode())));
			}

			if (renewalSearchRequest != null
					&& renewalSearchRequest.getStrCustomerID() != null
					&& !renewalSearchRequest.getStrCustomerID().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("custno",
						renewalSearchRequest.getStrCustomerID()).ignoreCase()));

			if (renewalSearchRequest != null
					&& renewalSearchRequest.getStrLOB() != null
					&& !renewalSearchRequest.getStrLOB().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("strlob",
						renewalSearchRequest.getStrLOB())));

			if (renewalSearchRequest != null
					&& renewalSearchRequest.getStrProductCode() != null
					&& !renewalSearchRequest.getStrProductCode().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("strproductcd",
						renewalSearchRequest.getStrProductCode())));

			if (renewalSearchRequest != null
					&& renewalSearchRequest.getStrPolicyNo() != null
					&& !renewalSearchRequest.getStrPolicyNo().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("policynumber",
						renewalSearchRequest.getStrPolicyNo())));

			if (renewalSearchRequest != null
					&& renewalSearchRequest.getStrDOB() != null
					&& !renewalSearchRequest.getStrDOB().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("dateofbirth",
						renewalSearchRequest.getStrDOB())));

			if (renewalSearchRequest != null
					&& renewalSearchRequest.getStrMobileNo() != null
					&& !renewalSearchRequest.getStrMobileNo().equals(
							CommonConstants.BLANK_STRING))
				criteria.add(Restrictions.and(Restrictions.eq("mobileno",
						renewalSearchRequest.getStrMobileNo())));

			if (renewalSearchRequest != null
					&& renewalSearchRequest.getFromDate() != null
					&& !renewalSearchRequest.getFromDate().equals(
							CommonConstants.BLANK_STRING)
					&& renewalSearchRequest.getToDate() != null
					&& !renewalSearchRequest.getToDate().equals(
							CommonConstants.BLANK_STRING)) {
				dtFrom = new SimpleDateFormat("dd/MM/yyyy")
						.parse(renewalSearchRequest.getFromDate());
				dtTo = new SimpleDateFormat("dd/MM/yyyy")
						.parse(renewalSearchRequest.getToDate());
				logger.debug("dtFrom" + dtFrom + "dtTo" + dtTo);
				criteria.add(Restrictions.and(Restrictions.ge("polstartdt",
						dtFrom)));
				criteria.add(Restrictions.and(Restrictions.le("polstartdt",
						dtTo)));
			}

			logger.debug("critera ==> " + criteria.toString());

			renPolEntityList = criteria.list();

			if (!transaction.wasCommitted())
				transaction.commit();

		} catch (Exception ex) {
			logger.error("DBService :: " + strMethodName + " catch block ::",
					ex);
			if (!transaction.wasRolledBack())
				transaction.rollback();
		}
		logger.info(service.getClass() + "::" + strMethodName + "::Exit");
		return renPolEntityList;
	}

	// End : Vishal<Mantis 3267> : New method added for renewal serach from
	// Portal : 16-Jan-2017
	// Start : <22/01/2018> : <KetanM> : <DefectID-0002717>:<:- To save Producer
	// Locking details to give option to manipulate Document Upload option
	// Producer wise.>
	public ArrayList getHouseBranchNameDetails(String receiptNumber) {
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		List result = new ArrayList();
		List listProduct = new ArrayList();
		HashMap<String, String> resultMap = new HashMap<String, String>();
		ObjectMapper objMap = new ObjectMapper();
		ArrayList docArr = new ArrayList();
		ArrayList<Object[]> retList = new ArrayList();

		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// START : CHANGES DONE FOR ORACLE MIGRATION
			/*
			 * Query query = session
			 * .createSQLQuery("SELECT * from func_gethousebnkpymt_dtls(:paramkey)"
			 * ); query.setParameter("_paramkey", receiptNumber);
			 */
			Query query = session
					.createSQLQuery(
							"SELECT * from table(func_gethousebnkpymt_dtls(:paramkey))")
					.addScalar("strhousebranch_name", StandardBasicTypes.STRING)
					.addScalar("strhousebranch_code", StandardBasicTypes.STRING)
					.addScalar("straccountno", StandardBasicTypes.STRING);

			query.setParameter("paramkey", receiptNumber);

			// END : CHANGES DONE FOR ORACLE MIGRATION

			retList = (ArrayList) query.list();
			/*
			 * if(result!=null && result.size()>0) {
			 * 
			 * resultMap=(HashMap)result.get(0); //
			 * resultMap.put("strhousebranch_name", strhousebranchname); //
			 * resultMap.put("strhousebranch_code", strhousebranchcode);
			 * resultMap.put("_straccountno", straccountno); }
			 */

			logger.info("DBService :: getHouseBranchNameDetails :: result="
					+ objMap.writeValueAsString(retList));
			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getHouseBranchNameDetails ::", ex);
		}

		return retList;
	}

	public List getHouseBranchNameMap(String officeCode,String paymentMode,String searchMode){
		HashMap<String,String> response = new HashMap();
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		List result =new ArrayList();
		List listProduct = new ArrayList();
		HashMap<String, String> resultMap = new HashMap<String, String>();
		ObjectMapper objMap = new ObjectMapper();
		ArrayList docArr = new ArrayList();
		Query query= null;
		ArrayList<Object[]> retList= new ArrayList();
		try {

			session = transactionManager.getSessionFactory().getCurrentSession();
			transaction = session.getTransaction();
			if(!transaction.isActive())
			{
				session.beginTransaction();
			}
			String sqlQuery = "";
			logger.info("DBService :: SearchMpde:: SearchMOde="+ searchMode);
			if(searchMode!=null && searchMode.equalsIgnoreCase("D")){
				
				/*sqlQuery = "select distinct a.num_financier_branch_cd,(c.strfinanciername||'-'||b.strbranchname) bankbranchname from dcf_master.dcf_accmst_bank_branch_relation a ,dcf_master.dcf_acc_financier_branch b, dcf_master.dcf_vh_financier_m c ";
				sqlQuery = sqlQuery + "where a.num_office_cd = :_officecd and a.txt_payment_mode =:_paymentmode and a.num_financier_branch_cd=CAST (b.strfinancierbranchcd AS INTEGER) and a.num_financier_cd =CAST (c.strfinanciercd AS INTEGER) and substr(b.strmicrcd,4,3) in('211','229')";*/
				sqlQuery = "select house_bank_cd,house_bank_name from dcf_housebank_acc_m";							
				logger.info("DBService :: Bank:: sqlQuery="+ sqlQuery);
		
	query = session.createSQLQuery(sqlQuery)
			// START : ADDED FOR ORACLE MIGRATION
			.addScalar("house_bank_cd", StandardBasicTypes.INTEGER)
			.addScalar("house_bank_name", StandardBasicTypes.STRING);
			// END : ADDED FOR ORACLE MIGRATION
				
			}else if(searchMode!=null && searchMode.equalsIgnoreCase("B")){
	// sqlQuery = "select distinct a.num_financier_branch_cd,(c.strfinanciername||'-'||b.strbranchname) bankbranchname from dcf_master.dcf_accmst_bank_branch_relation a ,dcf_master.dcf_acc_financier_branch b, dcf_master.dcf_vh_financier_m c ";  // Commented for oracle migration
	sqlQuery = "select distinct a.num_financier_branch_cd,(c.strfinanciername||'-'||b.strbranchname) bankbranchname from dcf_accmst_bank_brnch_relation a ,dcf_acc_financier_branch b, dcf_vh_financier_m c "; // Added for oracle migration
																																																			
				sqlQuery = sqlQuery + "where a.num_office_cd = :_officecd and a.txt_payment_mode =:_paymentmode and a.txt_transaction_type_cd = 'SR' and a.num_financier_branch_cd=CAST (b.strfinancierbranchcd AS INTEGER) and a.num_financier_cd =CAST (c.strfinanciercd AS INTEGER)";
				logger.info("DBService :: Branch:: sqlQuery="+ sqlQuery);
				
	query = session.createSQLQuery(sqlQuery)
			// START : ADDED FOR ORACLE MIGRATION
			.addScalar("num_financier_branch_cd", StandardBasicTypes.INTEGER)
			.addScalar("bankbranchname", StandardBasicTypes.STRING)
			// END : ADDED FOR ORACLE MIGRATION
			
			;
				query.setParameter("_officecd", Integer.parseInt(officeCode));
				query.setParameter("_paymentmode", paymentMode);
				
			}else{
	// sqlQuery = "select distinct a.num_financier_branch_cd,(c.strfinanciername||'-'||b.strbranchname) bankbranchname from dcf_master.dcf_accmst_bank_branch_relation a ,dcf_master.dcf_acc_financier_branch b, dcf_master.dcf_vh_financier_m c ";	 // Commented for oracle migration
	sqlQuery = "select distinct a.num_financier_branch_cd,(c.strfinanciername||'-'||b.strbranchname) bankbranchname from dcf_accmst_bank_brnch_relation a ,dcf_acc_financier_branch b, dcf_vh_financier_m c "; 								// Added for oracle migration
				sqlQuery = sqlQuery + "where a.num_office_cd = :_officecd and a.txt_payment_mode =:_paymentmode and a.txt_transaction_type_cd = 'SR' and a.num_financier_branch_cd=CAST (b.strfinancierbranchcd AS INTEGER) and a.num_financier_cd =CAST (c.strfinanciercd AS INTEGER)";
				logger.info("DBService :: Else:: sqlQuery="+ sqlQuery);							
	query = session.createSQLQuery(sqlQuery)
			// START : ADDED FOR ORACLE MIGRATION
			.addScalar("num_financier_branch_cd", StandardBasicTypes.INTEGER)
			.addScalar("bankbranchname", StandardBasicTypes.STRING)
			// END : ADDED FOR ORACLE MIGRATION
			;
				query.setParameter("_officecd", Integer.parseInt(officeCode));
				query.setParameter("_paymentmode", paymentMode);
				
			}
			
			
			logger.info("DBService :: getHouseBranchNameMap :: query="+ query);
				retList = (ArrayList) query.list();
				/*if(result!=null && result.size()>0)
    		{

    			resultMap=(HashMap)result.get(0);
//    			resultMap.put("strhousebranch_name", strhousebranchname);
//    			resultMap.put("strhousebranch_code", strhousebranchcode);
    			resultMap.put("_straccountno", straccountno);
    		}*/
				if(retList != null && !retList.isEmpty() &&retList.size()>0){
					
					if(searchMode!=null && searchMode.equalsIgnoreCase("B")){
						Object obj[] = retList.get(0); // remember first item
						retList.clear(); // clear complete list
						retList.add(obj); // add first item
					}
					
					logger.info("DBService :: getHouseBranchNameMap :: result="+ objMap.writeValueAsString(retList));
				}
			transaction.commit();
		}
		catch (Exception ex)
		{
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getHouseBranchNameMap ::", ex);
		}
		
		return retList;					
	}

	public List getBankAccNoFromPoral(String officeCode, String paymentMode,
			String branchCode, String searchMode) {
		HashMap<String, String> response = new HashMap();
		String strParamVal = null;
		Session session = null;
		Transaction transaction = null;
		List result = new ArrayList();
		List listProduct = new ArrayList();
		HashMap<String, String> resultMap = new HashMap<String, String>();
		ObjectMapper objMap = new ObjectMapper();
		ArrayList docArr = new ArrayList();
		Query query;
		ArrayList<Object[]> retList = new ArrayList();
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			if (searchMode != null && searchMode.equalsIgnoreCase("D")) {
				// String sqlQuery =
				// "select house_bank_acc_no from dcf_housebank_acc_m where house_bank_cd = :_branchCd";
				// // COMMENTED FOR ORACLE MIGRATION
				String sqlQuery = "select house_bank_acc_no from dcf_housebank_acc_m where house_bank_cd = :_branchCd"; // ADDED
																														// FOR
																														// ORACLE
																														// MIGRATION
				query = session.createSQLQuery(sqlQuery).addScalar(
						"house_bank_acc_no", StandardBasicTypes.STRING) // Added
																		// for
																		// oracle
																		// migration
				;
				logger.info("DBService :: getBankAccNoFromPoral bank:: query="
						+ query);
				query.setParameter("_branchCd", Integer.parseInt(branchCode));
			} else {
				// String sqlQuery =
				// "select distinct txt_bank_account_no_cheque  from dcf_master.dcf_accmst_bank_branch_relation where num_office_cd = :_officecd and txt_payment_mode =:_paymentmode and num_financier_branch_cd = :_branchcd";
				// // COMMENTED FOR ORACLE MIGRATION

				String sqlQuery = "select distinct txt_bank_account_no_cheque  from dcf_accmst_bank_brnch_relation where num_office_cd = :officecd and txt_payment_mode =:paymentmode and num_financier_branch_cd = :branchcd and txt_transaction_type_cd = 'SR'"; // ADDED
																																																								// FOR
																																																								// ORACLE
																																																								// MIGRATION
				query = session.createSQLQuery(sqlQuery)
						.addScalar("txt_bank_account_no_cheque",
								StandardBasicTypes.STRING) // Added for oracle
															// migration
				;
				logger.info("DBService :: getBankAccNoFromPoral branch:: query="
						+ query);
				// START : CODE ADDED FOR ORACLE MIGRATION
				/*
				 * query.setParameter("_officecd",
				 * Integer.parseInt(officeCode));
				 * query.setParameter("_paymentmode", paymentMode);
				 * query.setParameter("_branchcd", Integer .parseInt(branchCode
				 * == null || branchCode.equalsIgnoreCase("") ? "0" :
				 * branchCode));
				 */

				query.setParameter("officecd", Integer.parseInt(officeCode));
				query.setParameter("paymentmode", paymentMode);
				query.setParameter("branchcd", Integer
						.parseInt(branchCode == null
								|| branchCode.equalsIgnoreCase("") ? "0"
								: branchCode));

				// START : CODE ADDED FOR ORACLE MIGRATION
			}
			retList = (ArrayList) query.list();
			/*
			 * if(result!=null && result.size()>0) {
			 * 
			 * resultMap=(HashMap)result.get(0); //
			 * resultMap.put("strhousebranch_name", strhousebranchname); //
			 * resultMap.put("strhousebranch_code", strhousebranchcode);
			 * resultMap.put("_straccountno", straccountno); }
			 */
			if(retList != null && !retList.isEmpty() && retList.size()>0){
				
				if(searchMode!=null && searchMode.equalsIgnoreCase("B")){
					Object obj[] = retList.get(0); // remember first item
					retList.clear(); // clear complete list
					retList.add(obj); // add first item
				}
				
				logger.info("DBService :: getBankAccNoFromPoral :: result="+ objMap.writeValueAsString(retList));
			}

			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getBankAccNoFromPoral ::", ex);
		}

		return retList;
	}

	// 2717 : Vishalj : Start
	public void savePayinPdf(PayinPdfMaster payinPdfMaster) throws Exception {
		Session session = null;
		Transaction transaction = null;
		String strMethodName = "savePayinPdf";
		try {
			logger.info("Inside " + service.getClass() + ":: " + strMethodName
					+ " :: Entered");

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			session.saveOrUpdate(payinPdfMaster);
			transaction.commit();

		} catch (Exception ex) {
			logger.error(service.getClass() + "::" + strMethodName
					+ " catch block ::", ex);
			if (!transaction.wasRolledBack())
				transaction.rollback();
		}
	}

	// 2717 : VishalJ : End

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getPayinPdfString(String payinSlipNo)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List retList = new ArrayList();
		String className = "com.majesco.dcf.common.tagic.entity.PayinPdfMaster";
		Session session = null;
		Transaction transaction = null;
		PayinPdfMaster payinPdfMaster = new PayinPdfMaster();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getPayinPdfString Method"); }
			 */

			logger.info("Inside DBService :: getPayinPdfString method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("depositslipno", payinSlipNo));
			retList = criteria.list();

			if (retList != null && retList.size() > 0) {
				payinPdfMaster = (PayinPdfMaster) retList.get(0);
			}

			logger.info("Inside DBService :: getPayinPdfString method :: Execution Completed Successfully");

			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
			logger.error(
					"Inside DBService :: print method :: Execution Completed Successfully",
					e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return payinPdfMaster.getPayinpdf();
	}

	// 3483 : Vishal : Sp Writing Db service for sp master : Start
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<? extends Object> getSpMaster(String className,
			String producerCode) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List<SpMaster> rtoList = new ArrayList<SpMaster>();
		Session session = null;
		Transaction transaction = null;
		List listProduct = new ArrayList();
		try {
			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("In DBService.getSpMaster Method"); }
			 */

			logger.info("Inside DBService :: getSpMaster(String) method :: Execution Started");

			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// rtoList =
			// session.createQuery("select strofficedesc || '('||strofficecd ||')' Office,nofficecd,nparentofficecd,strofficedesc,strofficecd,strparentofficecd from OfficeMaster").list();
			/*
			 * for (Iterator iterator = rtoList.iterator(); iterator.hasNext();)
			 * { OfficeMaster rtof = (OfficeMaster)iterator.next(); }
			 */

			// Query query =
			// session.createSQLQuery("SELECT * from proc_getofficemaster(:_paramkey)").setParameter("_paramkey",
			// strBranchLocation);
			// START : ADDED FOR ORACLE MIGRATION
			/*
			 * Query query = session
			 * .createSQLQuery("SELECT * from proc_getspmaster(:_producerCode)"
			 * ); query.setParameter("_producerCode", producerCode);
			 */

			Query query = session
					.createSQLQuery(
							"SELECT * from table(proc_getspmaster(:producerCode))")
					.addScalar("txt_sp_cert_no", StandardBasicTypes.STRING)
					.addScalar("txt_sp_name", StandardBasicTypes.STRING)
					.addScalar("dat_end_date", StandardBasicTypes.DATE)
					.addScalar("txt_status", StandardBasicTypes.STRING);
			query.setParameter("producerCode", producerCode);

			// START : ADDED FOR ORACLE MIGRATION
			query.setResultTransformer(Transformers.aliasToBean(SpMaster.class));
			listProduct = query.list();

			if (listProduct != null && !listProduct.isEmpty()) {
				// System.out.println("value:***** "+listProduct.get(0));
				// System.out.println("value:XXXXXX "+listProduct.get(0).toString());
			}
			logger.info("Inside DBService :: getSpMaster(String) method :: Execution Completed Successfully");

			/*
			 * if(logger.isDebugEnabled()){
			 * logger.debug("Out DBService.getSpMaster Method"); }
			 */
			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error("Inside DBService :: getSpMaster(String) method :: ",
					ae);
		}

		return listProduct;
	}

	// 3483 : Vishal : Sp Writing Db service for sp master : End

	// START : ADDED FOR ORACLE MIGRATION

	public Connection getConnForCollableStmt(Session session) {
		Connection changedCon = null;

		SessionFactoryImplementor sessionFactoryImplementation = (SessionFactoryImplementor) session
				.getSessionFactory();
		ConnectionProvider connectionProvider = sessionFactoryImplementation
				.getConnectionProvider();
		try {
			changedCon = connectionProvider.getConnection();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return changedCon;
	}

	// END : ADDED FOR ORACLE MIGRATION

	// Start: 9870467
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<PGTransaction> fetchTxnWithPendingStatus() {
		List<PGTransaction> pgtxnlstResult = new ArrayList<PGTransaction>();
		PGTransaction pgTxn = new PGTransaction();
		Session session = null;
		Transaction transaction = null;
		try {

			logger.info("Inside DBService :: fetchTxnWithPendingStatus method :: Execution Started");

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

/*			String sql = "select pg.strscreenrefno as screenRefNo,pg.ntxnamt as txnAmt,pg.strtxnmode as "
					+ "txnMode,pg.strtxnmodeval as txnModeVal "
					+ "from dcf_pg_transaction pg where ntxnstatus = 'PENDING' and dtcreated > sysdate - 20/1440";*/
			String sql = "select pg.strscreenrefno as screenRefNo,pg.ntxnamt as txnAmt,pg.strtxnmode as "
					+ "txnMode,pg.strtxnmodeval as txnModeVal "
					+ "from dcf_pg_transaction pg where nvl(pg.strauthstatus,9) != 0 "
					+ "AND nvl(pg.strauthstatus,9) != 11 "
					+ "and pg.dtcreated >=(SYSDATE - (20/1440) ) and pg.dtcreated <=sysdate";
			logger.info("Issue 9870467:: SQL is + " + sql);

			SQLQuery query = session.createSQLQuery(sql)
					.addScalar("screenRefNo", StandardBasicTypes.STRING)
					.addScalar("txnAmt", StandardBasicTypes.DOUBLE)
					.addScalar("txnMode", StandardBasicTypes.STRING)
					.addScalar("txnModeVal", StandardBasicTypes.STRING);

			Object retList = query.setResultTransformer(
					Transformers.aliasToBean(PGTransaction.class)).list();
			List<PGTransaction> pgtxnList = (List<PGTransaction>) retList;
			logger.info("Issue 9870467:: retList size is:: " + pgtxnList.size());

			for (int i = 0; i < pgtxnList.size(); i++) {
				pgTxn = pgtxnList.get(i);
				pgtxnlstResult.add(pgTxn);
			}

			for (int i = 0; i < pgtxnlstResult.size(); i++) {
				logger.info("Issue 9870467 :: fetchTxnWithPendingStatus method :: pgtxnlstResult>>screenRefNo:: "
						+ pgtxnlstResult.get(i).getScreenRefNo());
			}

			transaction.commit();

		} catch (Exception e) {
			transaction.rollback();
			logger.error("::::::Error in fetchTxnWithPendingStatus ::::::", e);
			e.printStackTrace();
		}

		logger.info("Inside DBService :: fetchTxnWithPendingStatus method :: Execution Completed Successfully");

		return pgtxnlstResult;
	}

	// END: 9870467

	// Start : 9870467
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<SelfPaymentEntiry> fetchCommunicationDetails(List screenRefNo) {

		Session session = null;
		Transaction transaction = null;
		SelfPaymentEntiry payEntryObj;
		List<SelfPaymentEntiry> selfPayList;
		List<SelfPaymentEntiry> finalList = new ArrayList<SelfPaymentEntiry>();

		try {

			logger.info("Inside DBService :: fetchCommunicationDetails method :: Execution Started");

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			String sql = "SELECT pay.strcreatedby AS createdby,pay.strcustomerid as customerId,pay.stremail as email,"
					+ "pay.strmobile as mobile,pay.paylinkused as payLinkUsed,pay.producercd as producerCd,pay.PRODUCERNAME as producerName,"
					+ "pay.PRODUCTCD as productCd,pay.STRPROPPOLNO as propPolNbr,pay.DTSTART as startime,pay.STRSTATUS as status,"
					+ "pay.DTRANSAMT as transAmount,pay.DTTRANS as transDate,pay.STRTRANSID as transId,pay.STRCUSTOMERNAME as customerName "
					+ "FROM dcf_self_pay_trans pay "
					+ "WHERE strtransid = :_transID";
			logger.info("Issue 9870467:: fetchCommunicationDetails :: SQL is::"
					+ sql);

			SQLQuery query = null;

			for (int i = 0; i < screenRefNo.size(); i++) {
				query = session.createSQLQuery(sql);
				query.setParameter("_transID", screenRefNo.get(i));
				query.addScalar("createdby", StandardBasicTypes.STRING)
						.addScalar("customerId", StandardBasicTypes.STRING)
						.addScalar("email", StandardBasicTypes.STRING)
						.addScalar("mobile", StandardBasicTypes.STRING)
						.addScalar("payLinkUsed", StandardBasicTypes.STRING)
						.addScalar("producerCd", StandardBasicTypes.STRING)
						.addScalar("producerName", StandardBasicTypes.STRING)
						.addScalar("productCd", StandardBasicTypes.STRING)
						.addScalar("propPolNbr", StandardBasicTypes.STRING)
						.addScalar("startime", StandardBasicTypes.DATE)
						.addScalar("status", StandardBasicTypes.STRING)
						.addScalar("transAmount", StandardBasicTypes.STRING)
						.addScalar("transDate", StandardBasicTypes.DATE)
						.addScalar("transId", StandardBasicTypes.STRING)
						.addScalar("customerName", StandardBasicTypes.STRING);
				Object retList = query.setResultTransformer(
						Transformers.aliasToBean(SelfPaymentEntiry.class))
						.list();
				selfPayList = (List<SelfPaymentEntiry>) retList;
				for (int k = 0; k < selfPayList.size(); k++) {
					payEntryObj = selfPayList.get(k);
					finalList.add(payEntryObj);
				}
			}

			transaction.commit();

			for (int i = 0; i < finalList.size(); i++) {
				logger.info("ISSUE 9870467:: fetchCommunicationDetails::final list::mobile no::"
						+ finalList.get(i).getMobile());
			}

		} catch (Exception e) {
			transaction.rollback();
			logger.error("::::::Error in fetchCommunicationDetails ::::::", e);
			e.printStackTrace();
		}

		logger.info("Inside DBService :: fetchCommunicationDetails method :: Execution Completed Successfully");

		return finalList;
	}

	// End:9870467

	public int updateSelfPayTrans(String transID) {

		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.updateSelfPayTrans Method"); }
		 */
		int result = 0;
		Integer intCount = 1;
		/*
		 * if(status.equalsIgnoreCase("Success")){ intCount=1;
		 */
		/*
		 * }else if(status.equalsIgnoreCase("Failure")){ intCount=4;
		 */
		// }
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: updateSelfPayTrans method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Query query = session
					.createSQLQuery(" update dcf_self_pay_trans set strerrorexception = :_exception, strlinkhitcount = :_hitCount,paylinkused = :_PAYLINKUSED"
							+ " where strtransid = :_transID");
			query.setParameter("_exception", "CPI_SCHEDULER");
			query.setParameter("_hitCount", intCount);
			query.setParameter("_transID", transID);
			query.setParameter("_PAYLINKUSED", "1");
			result = query.executeUpdate();
			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: updateSelfPayTrans error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
		return result;
	}

	public int updatePgTransaction(String transID, String cpitxId,
			String gatewayTxnId) {

		/*
		 * if(logger.isDebugEnabled()){
		 * logger.debug("In DBService.updatePgTransaction Method"); }
		 */
		int result = 0;
		Session session = null;
		Transaction transaction = null;
		logger.info("Inside DBService :: updatePgTransaction method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			Query query = session
					.createSQLQuery(" update dcf_pg_transaction set strauthstatus = :_authstatus, ntxnstatus = :_status, cpitransid = :cpitxId, strpgtxnrefno = :strpgtxnrefno ,dtupdated= :dtupdated"
							+ " where strscreenrefno = :_transID");
			// if(status.equalsIgnoreCase("Success")){
			query.setParameter("_authstatus", "0");
			query.setParameter("_status", "SUCCESS");
			query.setParameter("cpitxId", cpitxId);
			query.setParameter("strpgtxnrefno", gatewayTxnId);
			query.setParameter("dtupdated",
					new Timestamp(System.currentTimeMillis()));
			/*
			 * }else if(status.equalsIgnoreCase("Failure")){
			 * query.setParameter("_authstatus", "1");
			 * query.setParameter("_status", "FAILURE");
			 */// }
			query.setParameter("_transID", transID);
			result = query.executeUpdate();
			transaction.commit();

		} catch (Exception e) {
			logger.error("In DBService :: updatePgTransaction error ::", e);
			transaction.rollback();
			e.printStackTrace();
		}
		return result;
	}

	public List processCPIUserDetail(String transid) throws Exception {

		List paramList = null;

		String strMethodName = "processCPIUserDetail";
		Session session = null;
		Transaction transaction = null;
		try {
			logger.info("Inside DBService :: " + strMethodName + " :: Entered");

			// String totalCount =
			// this.getConfigParamVal(CommonConstants.PROCESS_REHIT_MECH_CONFIG_KEY);
			// Integer totCount = Integer.parseInt(totalCount);

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// START : CHANGES ARE ADDED FOR ORACLE MIGRATION

			/*
			 * Query query=session.createSQLQuery(
			 * "select * from func_rehit_exception_policy_val(:_totalHitCount)"
			 * ); query.setParameter("_totalHitCount", totCount);
			 * 
			 * paramList=query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
			 * .list();
			 */

			Query query = (Query) session
					.createSQLQuery(
							"select * from table(func_cpi_get_user_detail(:transId))")
					.addScalar("strorderid", StandardBasicTypes.STRING)
					.addScalar("strrequestmsg", StandardBasicTypes.STRING)
					.addScalar("strpgtxnrefno", StandardBasicTypes.STRING);
			// query.setParameter(0, transid);
			query.setParameter("transId", transid);

			paramList = query
					.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();

			// END : CHANGES ARE ADDED FOR ORACLE MIGRATION
			transaction.commit();
		} catch (Exception ex) {
			logger.error("DBService :: " + strMethodName + " catch block ::",
					ex);
			transaction.rollback();
			throw ex;
		}
		return paramList;
	}

	public List getFailedTransactionList() throws Exception {
		List failedTransList = new ArrayList<>();
		String strMethodName = "getFailedTransactionList";
		Session session = null;
		Transaction transaction = null;
		Connection conn = null; // Added for oracle migration
		CallableStatement csmt = null; // Added for oracle migration
		try {

			logger.info("Inside DBService :: " + strMethodName + " :: Entered");
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();

			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : CHANGES FOR ORACLE MIGRATION

			// Query query =
			// session.createSQLQuery("select * from func_get_failedtrans_lst()");
			// failedTransList =
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			// logger.info(" Failed Transaction List " +
			// failedTransList.size());

			Query query = session.createSQLQuery(
					"select * from table(func_get_failedtrans_lst())")
					.addScalar("strscreenrefno", StandardBasicTypes.STRING);
			failedTransList = query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();
			logger.info(" Failed Transaction List " + failedTransList.size());

			// END : CHANGES FOR ORACLE MIGRATION

		} catch (Exception ex) {
			logger.error("DBService :: " + strMethodName + " catch block ::",
					ex);
			transaction.rollback();
			throw ex;
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		return failedTransList;
	}

	/* <!-- */
	// Document Upload Method Added by Rahul Kumar
	// Document Upload Method starts--
	public boolean saveDocUploadDtls(Object insertObj) {
		logger.debug("saveDocUploadDtls");

		boolean isSave = true;
		String strMethodName = "saveDocUploadDtls";
		Session session = null;
		Transaction transaction = null;

		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			logger.debug("After Before Document commited");
			session.save(insertObj);
			transaction.commit();
			logger.debug("After saving Document commited");
		} catch (Exception e) {
			transaction.rollback();
			// TODO Auto-generated catch block
			if (logger.isDebugEnabled()) {
				logger.debug("DBService.save Catch block");
			}
			e.printStackTrace();
			isSave = false;
		}

		return isSave;

	}

	// -----------------------------------------------------------
	public DocUploadDtlsEntity getDocUploadDtls(String className,
			DocUploadDtlsObj docUploadDtlsObj) throws Exception {

		DocUploadDtlsEntity respEntity = new DocUploadDtlsEntity();
		String strMethodName = "getDocUploadDtls";
		Session session = null;
		Transaction transaction = null;
		Class classInstance = null;
		ObjectMapper objMap = new ObjectMapper();

		try {
			logger.info("Inside DBService :: getDocUploadDtls :: docUploadDtlsObj.getProposalNo(): "
					+ docUploadDtlsObj.getProposalNo());
			logger.info("Inside DBService :: getDocUploadDtls :: docUploadDtlsObj.getDocmodMapId(): "
					+ docUploadDtlsObj.getDocmodMapId());
			logger.info("Inside DBService :: getDocUploadDtls :: docUploadDtlsObj.getCreatedBy(): "
					+ docUploadDtlsObj.getCreatedBy());
			classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			// criteria.add(Restrictions.eq("strProposalNo", proposalNo));
			criteria.add(Restrictions.and(
					Restrictions.eq("strProposalNo",
							docUploadDtlsObj.getProposalNo()),
					Restrictions.eq("strDocmodMapId",
							docUploadDtlsObj.getDocmodMapId()),
					Restrictions.eq("strCreatedBy",
							docUploadDtlsObj.getCreatedBy())));

			List retList = criteria.list();

			logger.info("Inside DBService :: getDocUploadDtls :: result List: "
					+ objMap.writeValueAsString(retList));
			// for(int i=0; i<retList.size();i++){
			respEntity = (DocUploadDtlsEntity) retList.get(0);
			// }
			transaction.commit();
			logger.info("Inside DBService :: getDocUploadDtls :: respEntity: "
					+ objMap.writeValueAsString(respEntity));

		} catch (Exception e) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getDocUploadDtls method :: Exception Occurred ::",
					e);
			e.printStackTrace();
		}
		return respEntity;
	}

	public boolean updateDocUploadDtls(Object insertObj) {

		boolean isSave = true;
		String strMethodName = "updateDocUploadDtls";
		Session session = null;
		Transaction transaction = null;

		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			session.update(insertObj);
			transaction.commit();
		} catch (Exception e) {
			isSave = false;
			transaction.rollback();
			logger.error(
					"Inside DBService :: updateDocUploadDtls Exception Occurred ::",
					e);
			e.printStackTrace();
		}
		return isSave;
	}

	/**
	 * Method to provide data for UI for OC Inspection Including Document
	 * 
	 * @param QCInspectionRequest
	 * @return
	 */
	public List getDataForQC(QCInspectionRequest qcInspectionRequest) {
		List lstQCInspectionRes = null;
		Session session = null;
		Transaction transaction = null;
		Date fromDt = null;
		Date toDt = null;
		Date initDate = null;
		String tempDate = null;
		Date initDateToDt = null;
		List result = null;
		ObjectMapper objMap = new ObjectMapper();
		try {
			String className = "com.majesco.dcf.docmgmt.entity.DocUploadDtlsEntity";
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// SimpleDateFormat dbformat = new
			// SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			/*
			 * SimpleDateFormat dbformat = new
			 * SimpleDateFormat("dd-MMM-yy hh.mm.ss.SSS a");
			 * 
			 * if(qcInspectionRequest!=null &&
			 * qcInspectionRequest.getFromDate()!=null &&
			 * qcInspectionRequest.getToDate()!=null &&
			 * !qcInspectionRequest.getFromDate().equals("") &&
			 * !qcInspectionRequest.getToDate().equals("")) { initDate = new
			 * SimpleDateFormat
			 * ("dd/MM/yyyy HH:mm:ss").parse(qcInspectionRequest.
			 * getFromDate()+" 00:01:00"); tempDate = dbformat.format(initDate);
			 * fromDt = dbformat.parse(tempDate);
			 * logger.info("Inside DBService :: getDataForQC 111: fromDt "
			 * +fromDt);
			 * 
			 * initDate = new
			 * SimpleDateFormat("dd/MM/yyyy HH:mm:ss").parse(qcInspectionRequest
			 * .getToDate()+" 23:59:00"); tempDate = dbformat.format(initDate);
			 * toDt = dbformat.parse(tempDate);
			 * logger.info("Inside DBService :: getDataForQC 111: toDt "+toDt);
			 * }
			 */

			SimpleDateFormat dbformatFrmDt = new SimpleDateFormat(
					"dd-MMM-yy hh.mm.ss.SSS a");
			SimpleDateFormat dbformatToDt = new SimpleDateFormat(
					"dd-MMM-yy hh.mm.ss.SSS a");/* Added Due To Format Issue */

			if (qcInspectionRequest != null
					&& qcInspectionRequest.getFromDate() != null
					&& qcInspectionRequest.getToDate() != null
					&& !qcInspectionRequest.getFromDate().equals("")
					&& !qcInspectionRequest.getToDate().equals("")) {
				initDate = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
						.parse(qcInspectionRequest.getFromDate() + " 00:01:00");
				tempDate = dbformatFrmDt.format(initDate);
				fromDt = dbformatFrmDt.parse(tempDate);
				logger.info("Inside DBService :: getDataForQC 111: fromDt "
						+ dbformatFrmDt.format(initDate));

				initDateToDt = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
						.parse(qcInspectionRequest.getToDate() + " 23:59:00");
				tempDate = dbformatToDt.format(initDateToDt);
				toDt = dbformatToDt.parse(tempDate);
				logger.info("Inside DBService :: getDataForQC 111: toDt "
						+ dbformatToDt.format(initDateToDt));
			}

			Criteria criteria = session.createCriteria(classInstance);
			if (qcInspectionRequest != null) {
				if (qcInspectionRequest.getProposalNummber() != null
						&& !qcInspectionRequest.getProposalNummber().equals("")) {
					criteria.add(Restrictions.and(Restrictions.eq(
							"strProposalNo",
							qcInspectionRequest.getProposalNummber()),
							Restrictions.eq("strDocStatus", "U")));
				} else if (qcInspectionRequest.getPolicyNumber() != null
						&& !qcInspectionRequest.getPolicyNumber().equals("")) {
					criteria.add(Restrictions.and(
							Restrictions.eq("strPolicyNo",
									qcInspectionRequest.getPolicyNumber()),
							Restrictions.eq("strDocStatus", "U")));
				} else if (fromDt != null && toDt != null) {
					criteria.add(Restrictions.and(
							Restrictions.ge("dtUpdated", fromDt),
							Restrictions.le("dtUpdated", toDt),
							Restrictions.eq("strDocStatus", "U")));
				} else if (qcInspectionRequest.getProducerCode() != null
						&& !qcInspectionRequest.getProducerCode().equals("")) {
					criteria.add(Restrictions.and(
							Restrictions.eq("strCreatedBy",
									qcInspectionRequest.getProducerCode()),
							Restrictions.eq("strDocStatus", "U")));
				}

				lstQCInspectionRes = criteria.list();
			}

			logger.info("Inside DBService :: getDataForQC : List "
					+ objMap.writeValueAsString(lstQCInspectionRes));

			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("getDataForQC ::", ex);
		}

		return lstQCInspectionRes;

	}

	/**
	 * Method to return list of Checked Document for that Proposal.
	 * 
	 * @param docSearchDtls
	 * @return
	 */
	// Start:<YogeshM>:<14/03/2018>:<SIT>:<DefectID-0001305>:<To get docUpload
	// Pending Status>
	public List<DocUploadDtlsEntity> getUploadDocSearch(
			DocUploadSearchObj docSearchDtls) {
		List<DocUploadDtlsEntity> docUploadDtlsEntities = new ArrayList<DocUploadDtlsEntity>();
		Session session = null;
		Transaction transaction = null;
		DocUploadDtlsEntity docUploadDtlsEntity = null;
		ObjectMapper objMap = new ObjectMapper();
		Date fromDt = null;
		Date toDt = null;
		Date initDate = null;
		Date initDateToDt = null;
		String tempDate = null;

		List result = null;
		try {
			logger.info("Inside DBService getUploadDocSearch:: Method Started :: docSearchDtls: "
					+ objMap.writeValueAsString(docSearchDtls));

			String className = "com.majesco.dcf.docmgmt.entity.DocUploadDtlsEntity";
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			/*
			 * SimpleDateFormat dbformatFrmDt = new
			 * SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); SimpleDateFormat
			 * dbformatToDt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			 *//* Commented Due To Format Issue */

			SimpleDateFormat dbformatFrmDt = new SimpleDateFormat(
					"dd-MMM-yy hh.mm.ss.SSS a");
			SimpleDateFormat dbformatToDt = new SimpleDateFormat(
					"dd-MMM-yy hh.mm.ss.SSS a");/* Added Due To Format Issue */

			if (docSearchDtls != null && docSearchDtls.getFromDate() != null
					&& docSearchDtls.getToDate() != null
					&& !docSearchDtls.getFromDate().equals("")
					&& !docSearchDtls.getToDate().equals("")) {
				initDate = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
						.parse(docSearchDtls.getFromDate() + " 00:01:00");
				tempDate = dbformatFrmDt.format(initDate);
				fromDt = dbformatFrmDt.parse(tempDate);
				logger.info("Inside DBService :: getUploadDocSearch 111: fromDt "
						+ dbformatFrmDt.format(initDate));

				initDateToDt = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
						.parse(docSearchDtls.getToDate() + " 23:59:00");
				tempDate = dbformatToDt.format(initDateToDt);
				toDt = dbformatToDt.parse(tempDate);
				logger.info("Inside DBService :: getUploadDocSearch 111: toDt "
						+ dbformatToDt.format(initDateToDt));
			}

			Criteria criteria = session.createCriteria(classInstance);
			logger.info("Inside DBService.getUploadDocSearch() strDocStatus");
			// criteria.add(Restrictions.and(Restrictions.eq("strProposalNo",
			// proposalNo),Restrictions.isNull("strDocStatus")));
			if (docSearchDtls.getProposalNo() != null
					&& !docSearchDtls.getProposalNo().equalsIgnoreCase("")) {
				criteria.add(Restrictions.and(
						Restrictions.eq("strProposalNo",
								docSearchDtls.getProposalNo()),
						Restrictions.isNull("strDocStatus")));
			}
			/*
			 * else if(fromDt!=null && toDt!=null) {
			 * criteria.add(Restrictions.and(Restrictions.ge("dtUpdated",
			 * fromDt),Restrictions.le("dtUpdated",
			 * toDt),Restrictions.isNull("strDocStatus"))); }
			 */
			else if (docSearchDtls.getFromDate() != null
					&& docSearchDtls.getToDate() != null
					&& !docSearchDtls.getFromDate().equals("")
					&& !docSearchDtls.getToDate().equals("")) {
				logger.info("Inside DBService.getUploadDocSearch() initDate"
						+ dbformatToDt.parse(dbformatFrmDt.format(initDate)));
				logger.info("Inside DBService.getUploadDocSearch() to Date"
						+ dbformatToDt.parse(dbformatToDt.format(initDateToDt)));
				criteria.add(Restrictions.and(Restrictions.ge("dtCreated",
						dbformatToDt.parse(dbformatFrmDt.format(initDate))),
						Restrictions.le("dtCreated", dbformatToDt
								.parse(dbformatToDt.format(initDateToDt))),
						Restrictions.isNull("strDocStatus")));
			} else // else called to search all Pending docUpload Dtls
			{
				// criteria.add(Restrictions.isNull("strDocStatus"));
				criteria.add(Restrictions.and(
						Restrictions.eq("strCreatedBy",
								docSearchDtls.getUserID()),
						Restrictions.isNull("strDocStatus")));
				// criteria.setProjection( Projections.distinct(
				// Projections.property( "strProposalNo" )));
				// criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			}
			criteria.addOrder(Order.desc("dtCreated"));
			List retList = criteria.list();

			logger.info("Inside DBService :: List "
					+ objMap.writeValueAsString(retList));
			for (int i = 0; i < retList.size(); i++) {
				docUploadDtlsEntity = (DocUploadDtlsEntity) retList.get(i);
				docUploadDtlsEntities.add(docUploadDtlsEntity);
			}

			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("Inside DBService getUploadDocSearch ::", ex);
		}

		return docUploadDtlsEntities;

	}

	public boolean saveDocUploadOptn(Object insertObj) {
		if (logger.isDebugEnabled()) {
			logger.debug("In DBService.saveDocUploadOptn Method");
		}
		Session session = null;
		Transaction transaction = null;
		boolean isSave = true;
		logger.info("Inside DBService :: saveDocUploadOptn method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			session.saveOrUpdate(insertObj);
			transaction.commit();
		} catch (Exception e) {
			logger.error("In DBService :: saveDocUploadOptn error ::", e);
			transaction.rollback();
			isSave = false;
			// TODO Auto-generated catch block
			if (logger.isDebugEnabled()) {
				logger.debug("DBService.saveDocUploadOptn catch block");
			}
			e.printStackTrace();
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }

		logger.info("Inside DBService :: saveDocUploadOptn method :: Execution Completed Successfully");

		if (logger.isDebugEnabled()) {
			logger.debug("Out DBService.saveDocUploadOptn Method");
		}
		return isSave;
	}

	public DocUploadDtlsEntity getDocUploadDtlsBySeqID(String className,
			String seqID) throws Exception {

		DocUploadDtlsEntity respEntity = new DocUploadDtlsEntity();
		String strMethodName = "getDocUploadDtlsBySeqID";
		Session session = null;
		Transaction transaction = null;
		Class classInstance = null;
		ObjectMapper objMap = new ObjectMapper();
		Long seqId = (long) 0.0;

		try {
			logger.info("Inside DBService :: " + strMethodName + " :: seqID: "
					+ seqID);
			classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			seqId = Long.parseLong(seqID);

			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("ndocid", seqId));
			List retList = criteria.list();

			respEntity = (DocUploadDtlsEntity) retList.get(0);

			transaction.commit();
			logger.info("Inside DBService :: " + strMethodName
					+ " :: respEntity: "
					+ objMap.writeValueAsString(respEntity));

		} catch (Exception e) {
			transaction.rollback();
			logger.error("Inside DBService :: " + strMethodName
					+ " method :: Exception Occurred ::", e);
			e.printStackTrace();
		}
		return respEntity;
	}

	public Date checkQCProducerDocumentLock(String className, String userID)
			throws Exception {

		DocUploadDtlsEntity respEntity = new DocUploadDtlsEntity();
		String strMethodName = "checkQCProducerDocumentLock";
		Session session = null;
		Transaction transaction = null;
		Class classInstance = null;
		ObjectMapper objMap = new ObjectMapper();
		List retList = null;
		List<DocUploadDtlsEntity> lstDocUploadDtlsEntity = new ArrayList<DocUploadDtlsEntity>();
		Date dtObtained = new Date();
		try {
			logger.info("Inside DBService :: " + strMethodName + " :: userID: "
					+ userID);
			classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);

			criteria.add(
					Restrictions.and(
							Restrictions.eq("strUploadBy", userID),
							Restrictions
									.eq("strDocStatus",
											CommonConstants.DCF_DOCUPLOAD_DTLS_DOC_STATUS)))
					.setProjection(Projections.min("dtUpdated"));

			retList = criteria.list();

			logger.info("Inside DBService :: " + strMethodName
					+ " :: result List: " + objMap.writeValueAsString(retList));
			for (int i = 0; i < retList.size(); i++) {
				dtObtained = new SimpleDateFormat("dd/MM/yyyy").parse(retList
						.get(i).toString());
				// dtObtained = (Date) retList.get(i);
			}
			transaction.commit();
			logger.info("Inside DBService :: " + strMethodName
					+ " :: respEntity: "
					+ objMap.writeValueAsString(lstDocUploadDtlsEntity));
			return dtObtained;
		} catch (Exception e) {
			transaction.rollback();
			logger.error("Inside DBService :: " + strMethodName
					+ " method :: Exception Occurred ::", e);
			e.printStackTrace();
			return null;
		}
	}

	public Date checkProducerDocumentLock(String className, String userID)
			throws Exception {

		DocUploadDtlsEntity respEntity = new DocUploadDtlsEntity();
		String strMethodName = "checkProducerDocumentLock";
		Session session = null;
		Transaction transaction = null;
		Class classInstance = null;
		ObjectMapper objMap = new ObjectMapper();
		List retList = null;
		List<DocUploadOptn> lstDocUploadOptn = new ArrayList<DocUploadOptn>();
		DocUploadOptn docUploadOptn = new DocUploadOptn();
		Date dtObtained = new Date();
		Connection conn = null; // Added for oracle migration
		CallableStatement csmt = null; // Added for oracle migration
		try {
			logger.info("Inside DBService :: checkProducerDocumentLock :: userID: "
					+ userID);
			classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			/*
			 * Criteria criteria = session.createCriteria(classInstance);
			 * 
			 * criteria.add(Restrictions.and(Restrictions.eq("strCreatedBy",
			 * userID), Restrictions.eq("stroption",
			 * CommonConstants.DCF_DOCUMENT_UPLOAD_OPTN_LATER),
			 * Restrictions.isNull("strstatus")
			 * )).setProjection(Projections.min("dtCreated"));
			 * 
			 * retList = criteria.list();
			 */

			// START : ADDED FOR ORACLE MIGRATION
			// Query query =
			// session.createSQLQuery("SELECT * from func_get_mindocpending_date(:_paramkey)").setParameter("_paramkey",
			// userID); // Commented for oracle migration

			Query query = session.createSQLQuery(
					"select * from table(func_get_mindocpending_date(?))")
					.addScalar("dtcreated", StandardBasicTypes.TIMESTAMP);
			query.setParameter(0, userID);
			retList = query.list();

			// END : ADDED FOR ORACLE MIGRATION

			// logger.info("Inside DBService :: checkProducerDocumentLock :- Query Created "+query);
			// result =
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			// retList = query.list();

			if (retList != null && retList.size() > 0) {
				SimpleDateFormat formatter = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss.SSS");
				Date date6 = formatter.parse(retList.get(0).toString());
				dtObtained = date6;
				// dtObtained = (Date) retList.get(0);
			}

			logger.info("Inside DBService :: checkProducerDocumentLock :: result List: "
					+ objMap.writeValueAsString(retList));
			logger.info("Inside DBService :: checkProducerDocumentLock :: Date Obtained: "
					+ dtObtained);
			/*
			 * for(int i=0; i<retList.size();i++) { dtObtained = (Date)
			 * retList.get(i); }
			 */
			transaction.commit();
			return dtObtained;

		} catch (Exception e) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: checkProducerDocumentLock method :: Exception Occurred ::",
					e);
			e.printStackTrace();
			return null;
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
	}

	/**
	 * Start : 28-Dec-2017 : Method to return Customer Doc Upload Link Data.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap getCustDocUploasLinkDtl(String className, String paramName,
			String paramValue) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		List subCatList = new ArrayList();
		Session session = null;
		Transaction transaction = null;
		List result = new ArrayList();
		HashMap resultVal = new HashMap();

		logger.info("Inside DBService :: getCustDocUploasLinkDtl(String, String, String) method :: Execution Started");
		try {
			logger.info("Inside DBService :: getCustDocUploasLinkDtl :- className :- "
					+ className);
			Class classInstance = Class.forName(className);
			logger.info("Inside DBService :: getCustDocUploasLinkDtl :- Got ClassInstance");
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			logger.info("Inside DBService :: getCustDocUploasLinkDtl :- Got Session");
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			// START : ADDED FOR ORACLE MIGRATION
			// Query query =
			// session.createSQLQuery("SELECT * from func_get_uploadLink_dtl(:_paramkey)").setParameter("_paramkey",
			// paramValue); // Commented for oracle migration
			Query query = session
					.createSQLQuery(
							"SELECT * from table(func_get_uploadLink_dtl(?))")
					.addScalar("customerid", StandardBasicTypes.STRING)
					.addScalar("proppolnbr", StandardBasicTypes.STRING)
					.addScalar("transamount", StandardBasicTypes.DOUBLE)
					.addScalar("paylinkused", StandardBasicTypes.STRING)
					.addScalar("productcd", StandardBasicTypes.STRING)
					.addScalar("createdby", StandardBasicTypes.STRING)
					.addScalar("producercd", StandardBasicTypes.STRING)
					.addScalar("producername", StandardBasicTypes.STRING)
					.addScalar("isrenew", StandardBasicTypes.STRING)
					.addScalar("customername", StandardBasicTypes.STRING)
					.addScalar("vehregno", StandardBasicTypes.STRING)
					.addScalar("planname", StandardBasicTypes.STRING);
			query.setParameter(0, paramValue);
			logger.info("Inside DBService :: getCustDocUploasLinkDtl :- Query Created "
					+ query);

			// END : ADDED FOR ORACLE MIGRATION
			// result =
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			result = query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
					.list();
			logger.info("Inside DBService :: getCustDocUploasLinkDtl :- Result "
					+ (result.size() > 0));

			if (logger.isDebugEnabled()) {
				logger.debug("In DBService.getCustDocUploasLinkDtl Method sql-- "
						+ query);
			}

			if (result != null && result.size() > 0) {
				resultVal = (HashMap) result.get(0);
			}

			logger.info("Inside DBService :: getCustDocUploasLinkDtl(String, String, String) method :: Execution Completed Successfully");

			transaction.commit();
		} catch (Exception ae) {
			transaction.rollback();
			logger.error(
					"Inside DBService :: getCustDocUploasLinkDtl(String, String, String) method :: ",
					ae);
		}

		return resultVal;
	}

	public boolean saveProducerLockDtls(ProducerLockDetails lockDetails) {

		if (logger.isDebugEnabled()) {
			logger.debug("In DBService.saveProducerLockDtls Method");
		}
		Session session = null;
		Transaction transaction = null;
		boolean isSave = true;
		logger.info("Inside DBService ::  method saveProducerLockDtls :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			session.saveOrUpdate(lockDetails);
			transaction.commit();
		} catch (Exception e) {
			logger.error("In DBService :: saveProducerLockDtls error ::", e);
			transaction.rollback();
			isSave = false;
			// TODO Auto-generated catch block
			if (logger.isDebugEnabled()) {
				logger.debug("DBService.saveProducerLockDtls catch block");
			}
			e.printStackTrace();
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }

		logger.info("Inside DBService :: saveProducerLockDtls method :: Execution Completed Successfully");

		if (logger.isDebugEnabled()) {
			logger.debug("Out DBService.saveProducerLockDtls Method");
		}
		return isSave;
	}

	// Start : <21/12/2017> : <VishalJ> : <DefectID-0001305>:<:- To save
	// Producer Locking details to give option to manipulate Document Upload
	// option Producer wise.>
	public ProducerLockDetails seachProducerLockDtls(
			ProducerLockDtlsSearchReq producerLockDtlsSearchReq) {
		ProducerLockDetails respEntity = new ProducerLockDetails();
		String strMethodName = "seachProducerLockDtls";
		Session session = null;
		Transaction transaction = null;
		Class classInstance = null;
		ObjectMapper objMap = new ObjectMapper();
		List retList = null;
		try {
			logger.info("Inside DBService :: " + strMethodName);
			String className = "com.majesco.dcf.docmgmt.entity.ProducerLockDetails";
			classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);

			criteria.add(Restrictions.and(Restrictions.eq("strproducercd",
					producerLockDtlsSearchReq.getProducerCd())));

			retList = criteria.list();

			logger.info("Inside DBService :: " + strMethodName
					+ " :: result List: " + objMap.writeValueAsString(retList));

			respEntity = (ProducerLockDetails) retList.get(0);

			transaction.commit();
			logger.info("Inside DBService :: " + strMethodName
					+ " :: respEntity: "
					+ objMap.writeValueAsString(respEntity));

		} catch (Exception e) {
			transaction.rollback();
			logger.error("Inside DBService :: " + strMethodName
					+ " method :: Exception Occurred ::", e);
			e.printStackTrace();
		}
		return respEntity;
	}

	// <Service to Search Rejected Uploaded Documents>
	public List<DocUploadDtlsEntity> getUploadDocSearchByStatus(
			DocUploadSearchObj docSearchDtls) {
		List<DocUploadDtlsEntity> docUploadDtlsEntities = new ArrayList<DocUploadDtlsEntity>();
		Session session = null;
		Transaction transaction = null;
		DocUploadDtlsEntity docUploadDtlsEntity = null;
		logger.info("Inside DBService getUploadDocSearch:: Method Started");
		List result = null;
		try {
			String className = "com.majesco.dcf.docmgmt.entity.DocUploadDtlsEntity";
			Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Criteria criteria = session.createCriteria(classInstance);
			logger.info("Inside DBService strDocStatus");
			criteria.add(Restrictions.and(
					Restrictions.eq("strUploadBy", docSearchDtls.getUserID()),
					Restrictions.eq("strDocStatus",
							docSearchDtls.getSearchFlag()).ignoreCase()));
			List retList = criteria.list();

			logger.info("Inside DBService :: List " + retList.size());
			for (int i = 0; i < retList.size(); i++) {
				docUploadDtlsEntity = new DocUploadDtlsEntity();
				docUploadDtlsEntity = (DocUploadDtlsEntity) retList.get(i);
				docUploadDtlsEntities.add(docUploadDtlsEntity);
			}

			transaction.commit();
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			logger.error("Inside DBService getUploadDocSearch ::", ex);
		}

		return docUploadDtlsEntities;

	}

	// Doc Upload Code
	public boolean updateDocSOurceOptn(DocUploadDtlsEntity docUploadOptn) {
		if (logger.isDebugEnabled()) {
			logger.debug("In DBService.updateDocSOurceOptn Method");
		}
		Session session = null;
		Transaction transaction = null;
		boolean isSave = true;
		logger.info("Inside DBService :: updateDocSOurceOptn method :: Execution Started");
		try {
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			Query query = session
					.createSQLQuery("UPDATE dcf_docupload_dtls SET strsource=:_strsource WHERE  strproposalno=:_strproposalno");
			query.setParameter("_strsource", docUploadOptn.getStrsource());
			query.setParameter("_strproposalno",
					docUploadOptn.getStrProposalNo());

			int res = query.executeUpdate();

			transaction.commit();
		} catch (Exception e) {
			logger.error("In DBService :: updateDocSOurceOptn error ::", e);
			transaction.rollback();
			isSave = false;
			// TODO Auto-generated catch block
			if (logger.isDebugEnabled()) {
				logger.debug("DBService.updateDocSOurceOptn catch block");
			}
			e.printStackTrace();
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }

		logger.info("Inside DBService :: updateDocSOurceOptn method :: Execution Completed Successfully");

		if (logger.isDebugEnabled()) {
			logger.debug("Out DBService.updateDocSOurceOptn Method");
		}
		return true;
	}

	// : Method changed to give getUserInfoDetailsSolIdDB object to LoginOld
	// method ::Deepak Shedge-20-07-2018 :: start
	public String getUserInfoDetailsSolIdDB(String strUserId) {

		Session session = null;
		Transaction transaction = null;
		String user = "";
		// IntermediaryProfile user= null;
		// List<IntermediaryProfile> retList = null;
		try {
			// if(logger.isDebugEnabled())logger.debug("Inside DBService :: getUserInfoDetailsSolIdDB(String) method :: Execution Started :- "+strUserId);
			// String className =
			// "com.majesco.dcf.common.tagic.entity.InternalUser";

			// String className =
			// "com.majesco.dcf.common.tagic.entity.FieldUserGCD";

			// Class classInstance = Class.forName(className);
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();

			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			String sql = "select SOLUTION_ID from DCF_MEDI_SOL where PRODUCER_CD='"
					+ strUserId + "'";

			logger.info("Inside DBService :: getUserInfoDetailsSolIdDB method :: QUERY : "
					+ sql);
			SQLQuery query = session.createSQLQuery(sql)
			// START : ADDED FOR ORACLE MIGRATION
					.addScalar("SOLUTION_ID", StandardBasicTypes.STRING);

			// END : ADDED FOR ORACLE MIGRATION

			// retList =(List<IntermediaryProfile>)
			// query.setResultTransformer(Transformers.aliasToBean(DealerGCD.class)).list();
			List<String> retList = query.list();

			/*
			 * Criteria criteria = session.createCriteria(classInstance);
			 * criteria.add(Restrictions.eq("userId", strUserId));
			 */
			// if(logger.isDebugEnabled())logger.debug("Inside DBService :: getInternalUser(String) method :: Size"+retList.size());
			/* retList = (ArrayList<InternalUser>)criteria.list(); */
			if (retList != null && retList.size() > 0) {

				user = (String) retList.get(0).toString();

			}

		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getUserInfoDetailsSolIdDB:: Exception Occurred..."
					+ e.toString());
			logger.error(
					"Inside DBService :: getUserInfoDetailsSolIdDB method :: Exception Occurred...",
					e);
		}
		return user;
	}
	// : Method changed to give getUserInfoDetailsSolIdDB object to LoginOld
	// method ::Deepak Shedge-20-07-2018 :: END
	
	
	// Start: Dinesh <Payment Done policy not issued>| To change status make for fail or success.				
	
    public void saveUpdatePmtFlowFlag(com.majesco.dcf.common.tagic.entity.PmtFlowFlags pmtFlowFlags){

  	  Session session = null;
  		Transaction transaction = null;

		logger.info("Inside DBService :: saveUpdatePmtFlowFlag method :: Execution Started");

		try {
			if(pmtFlowFlags != null && pmtFlowFlags.getStrproposalno() != null){
			session = transactionManager.getSessionFactory().getCurrentSession();
    		transaction = session.getTransaction();
    		if(!transaction.isActive()){
    			session.beginTransaction();
    		}

			session.saveOrUpdate(pmtFlowFlags);
			transaction.commit();
			
		  }
		} catch (Exception e) {
			logger.error("In DBService :: saveUpdatePmtFlowFlag error ::", e);
			transaction.rollback();
			if(session != null && session.isConnected()){
				session.close();
	        }
			e.printStackTrace();
		}finally{
			if(session != null && session.isConnected()){
				session.close();
	        }
		}
    }
    
    
    public void updatePmtFlowFlag(com.majesco.dcf.common.tagic.entity.PmtFlowFlags pmtFlowFlags){

  	  Session session = null;
  		Transaction transaction = null;

		logger.info("Inside DBService :: updatePmtFlowFlag method :: Execution Started");

		try {
			if(pmtFlowFlags != null && pmtFlowFlags.getStrproposalno() != null && pmtFlowFlags.getStrproposalno() != ""){
			session = transactionManager.getSessionFactory().getCurrentSession();
    		transaction = session.getTransaction();
    		if(!transaction.isActive()){
    			session.beginTransaction();
    		}
    		
    		 PmtFlowFlags pmtOld =(PmtFlowFlags) session.get(PmtFlowFlags.class, pmtFlowFlags.getStrproposalno());
			//session.Update(pmtFlowFlags);
    		 
    		 if(pmtOld != null){
    			 
    			 if(pmtFlowFlags.getStrcreatedby() != null){
    				pmtOld.setStrcreatedby(pmtFlowFlags.getStrcreatedby());
    			 }
    			if(pmtFlowFlags.getDtcreated() != null){
    				pmtOld.setDtcreated(pmtFlowFlags.getDtcreated());
    			}
    			if(pmtFlowFlags.getStrproposaltaggingflag() != null){
    				pmtOld.setStrproposaltaggingflag(pmtFlowFlags.getStrproposaltaggingflag());
    			}

    			if(pmtFlowFlags.getStrreceiptentryflag() != null){
    	      		pmtOld.setStrreceiptentryflag(pmtFlowFlags.getStrreceiptentryflag());
    	      	}
    			
    			if(pmtFlowFlags.getStrpdfgenflag() != null){
    	      		pmtOld.setStrpdfgenflag(pmtFlowFlags.getStrpdfgenflag());
    	      	}
    			if(pmtFlowFlags.getStrpdfgenreq() != null){
    	      		pmtOld.setStrpdfgenreq(pmtFlowFlags.getStrpdfgenreq());
    	      	}
    			if(pmtFlowFlags.getStrproposalflag() != null){
    	      		pmtOld.setStrproposalflag(pmtFlowFlags.getStrproposalflag());
    			}
    			if(pmtFlowFlags.getStrproposalreq() != null){
    	      		pmtOld.setStrproposalreq(pmtFlowFlags.getStrproposalreq());
    	      	}
    			if(pmtFlowFlags.getStrfinalstatus() != null){
    				pmtOld.setStrfinalstatus(pmtFlowFlags.getStrfinalstatus());
    			}
    			if(pmtFlowFlags.getStrpaymnetno() != null){
    				pmtOld.setStrpaymnetno(pmtFlowFlags.getStrpaymnetno());
    			}
    			if(pmtFlowFlags.getStrscreenrefno() != null){
    				pmtOld.setStrscreenrefno(pmtFlowFlags.getStrscreenrefno());
    			}
    			if(pmtFlowFlags.getStrpolicyno() != null){
    				pmtOld.setStrpolicyno(pmtFlowFlags.getStrpolicyno());
    			}
    			if(pmtFlowFlags.getStrreceiptno() != null){
    				pmtOld.setStrreceiptno(pmtFlowFlags.getStrreceiptno());
    			}
    			if(pmtFlowFlags.getStrcount() != null){
    				pmtOld.setStrcount(pmtFlowFlags.getStrcount());
    			}
    			if(pmtFlowFlags.getStrerrormsginpdfgen() != null){
    				pmtOld.setStrerrormsginpdfgen(pmtFlowFlags.getStrerrormsginpdfgen());
    			}
    			if(pmtFlowFlags.getStrerrormsginproptag() != null){
    				pmtOld.setStrerrormsginproptag(pmtFlowFlags.getStrerrormsginproptag());
    			}
    			if(pmtFlowFlags.getStrerrormsginreceiptBfl() != null){
    				pmtOld.setStrerrormsginreceiptBfl(pmtFlowFlags.getStrerrormsginreceiptBfl());
    			}
    			if(pmtFlowFlags.getStrlobtype() != null){
    				pmtOld.setStrlobtype(pmtFlowFlags.getStrlobtype());
    			}
    			
    		//pmt1.setStrproposalno(pmtFlowFlags.getStrproposalno() == null ? pmt1.getStrproposalno():pmtFlowFlags.getStrproposalno());

    		 }else{
    			session.save(pmtFlowFlags);
    		 }
    		
			transaction.commit();
			
		  }
		} catch (Exception e) {
			logger.error("In DBService :: updatePmtFlowFlag error ::", e);
			transaction.rollback();
			if(session != null && session.isConnected()){
				session.close();
	        }
			e.printStackTrace();
		}finally{
			if(session != null && session.isConnected()){
				session.close();
	        }
		}
    }
    
	
    // End: Dinesh <Payment Done policy not issued>| To change status make for fail or success.	
    
    
    
    
    /*
	 * this method returns rto group location.̣ 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getRTOLocationGroupCd(String rtoLocationCode)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		List<RTOLocation> rtoList = new ArrayList<RTOLocation>();
		String rtoLocationGroupCd = "";
		Session session = null;
		Transaction transaction = null;
		try {
			if (logger.isDebugEnabled()) {
				logger.debug("In DBService.getRTOLocationGroupCd Method");
			}
			
			logger.info("Inside DBService :: getRTOLocationGroupCd(String) method :: Execution Started");

			Class classInstance = Class.forName("com.majesco.dcf.common.tagic.entity.RTOLocation");
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// rtoList = session.createQuery("from RTOLocation").list();
			// //Commented As Per Issue Raised On 08/05/2017 12:54PM
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.eq("strstatus",
					CommonConstants.RECORD_STATUS_ACTIVE))
					.add(Restrictions.eq("strrtolocationcd",rtoLocationCode)); // Added As Per
															// Issue Raised On
															// 08/05/2017
															// 12:54PM

			rtoList = criteria.list(); // Added As Per Issue Raised On
										// 08/05/2017 12:54PM

			for (Iterator iterator = rtoList.iterator(); iterator.hasNext();) {
				RTOLocation rtof = (RTOLocation) iterator.next();
				rtoLocationGroupCd = rtof.getStrrtolocgrpcd();
				// System.out.println("test............"+city.getStrcitycd());
			}

			logger.info("Inside DBService :: getRTOLocationGroupCd(String) method :: Execution Completed Successfully");

			if (logger.isDebugEnabled()) {
				logger.debug("Out DBService.getRTOLocationGroupCd Method");
			}
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			logger.info("Inside DBService :: getRTOLocationGroupCd(String) method :: Exception Occurred..."
					+ e);
			logger.error("Inside DBService :: getRTOLocationGroupCd(String) method :: Exception Occurred..."
					+ e);
		}
		// finally{
		// if (session.isOpen()) {
		// session.close();
		// }
		// }
		return rtoLocationGroupCd;
	}
	
	public List<PmtFlowFlags> getFailedRecordsForScheduler() {
  	
  	List<PmtFlowFlags> lstPmtFlowFlags = new ArrayList<PmtFlowFlags>();
		PmtFlowFlags pmtFlowFlags = new PmtFlowFlags();
  	
  	Session session = null;
  	Transaction transaction = null;
  	
  	try {
  		logger.info("Inside DBService :: getFailedRecordsForScheduler method :: Execution Started");
  		session = transactionManager.getSessionFactory().getCurrentSession();
  		transaction = session.getTransaction();
  		if (!transaction.isActive()) {
				session.beginTransaction();
			}
  		
		Calendar cal1 = (Calendar.getInstance());
		cal1.add(Calendar.DATE, 0);
		java.sql.Date dateminus2 = new java.sql.Date(cal1.getTime()
				.getTime());
		logger.info("Dateminus2 :: " + dateminus2);
  		
          
          String sql =  "SELECT pmt.str_created_by as strcreatedby,"
					+ "pmt.dt_created as dtcreated,"
					+ "pmt.str_proposal_no as strproposalno,"
					+ "pmt.str_lob_type as strlobtype,"
					+ "pmt.str_proposal_req as strproposalreq,"
					+ "pmt.str_proposal_flag as strproposalflag,"
					+ "pmt.str_receipt_entry_flag as strreceiptentryflag,"
					+ "pmt.str_proposal_tagging_flag as strproposaltaggingflag,"
					+ "pmt.str_pdf_gen_req as strpdfgenreq,"
					+ "pmt.str_pdf_gen_flag as strpdfgenflag,"
					+ "pmt.str_final_status as strfinalstatus,"
					+ "pmt.str_payment_no as strpaymnetno,"
					+ "pmt.str_screen_ref_no as strscreenrefno,"
					+ "pmt.str_policy_no as strpolicyno,"
					+ "pmt.str_receipt_no as strreceiptno,"
					+ "pmt.str_count as strcount,"
					+ "pmt.str_error_msg_receipt_BFL as strerrormsginreceiptBfl "
					+ "pmt.str_error_msg_prop_tag as strerrormsginproptag "
					+ "pmt.str_error_msg_pdf_gen as strerrormsginpdfgen "
					+ "FROM dcf_pmtflow_flags pmt WHERE pmt.str_final_status = 'F'"
					+ "AND trunc(pmt.dt_created) =trunc(sysdate) ";
  		
		
  	SQLQuery query = session.createSQLQuery(sql)
				.addScalar("strcreatedby", StandardBasicTypes.STRING)
				.addScalar("dtcreated", StandardBasicTypes.DATE)
				.addScalar("strproposalno", StandardBasicTypes.STRING)
				.addScalar("strlobtype", StandardBasicTypes.STRING)
				.addScalar("strproposalreq", StandardBasicTypes.STRING)
				.addScalar("strproposalflag", StandardBasicTypes.STRING)
				.addScalar("strreceiptentryflag", StandardBasicTypes.STRING)
				.addScalar("strproposaltaggingflag", StandardBasicTypes.STRING)
				.addScalar("strpdfgenreq", StandardBasicTypes.STRING)
				.addScalar("strpdfgenflag", StandardBasicTypes.STRING)
				.addScalar("strfinalstatus", StandardBasicTypes.STRING)
				.addScalar("strpaymnetno", StandardBasicTypes.STRING)
				.addScalar("strscreenrefno",StandardBasicTypes.STRING)
				.addScalar("strreceiptno", StandardBasicTypes.STRING)
				.addScalar("strpolicyno", StandardBasicTypes.STRING)
				.addScalar("strcount", StandardBasicTypes.STRING)
				.addScalar("strerrormsginreceiptBfl", StandardBasicTypes.STRING)
				.addScalar("strerrormsginproptag", StandardBasicTypes.STRING)
				.addScalar("strerrormsginpdfgen", StandardBasicTypes.STRING);
		
		//retList =(List<UserDemo>) query.setResultTransformer(Transformers.aliasToBean(UserDemo.class)).list();        	
		Object retList = query.setResultTransformer(Transformers.aliasToBean(PmtFlowFlags.class)).list();
		List<PmtFlowFlags> pmtFlow = (List<PmtFlowFlags>) retList;
		
		logger.info("pmtFlow size is:: " + pmtFlow.size());
		
		for(int i=0;i<pmtFlow.size();i++) {
			pmtFlowFlags = pmtFlow.get(i);
			lstPmtFlowFlags.add(pmtFlowFlags);
		}
		
		transaction.commit();
		logger.info("Inside DBService :: getFailedRecordsForScheduler method :: Execution End Successfully");
  	}
  	catch (Exception e) {
			transaction.rollback();
			logger.error("::::::Error in getFailedRecordsForScheduler ::::::", e);
			e.printStackTrace();
	}
  	
  return lstPmtFlowFlags;
}
	
	 /*public String getRequestMsgFromScrnRef(String screenRef) {
	 String strReqMsg = "";
	 List orderList = new ArrayList();
	 OnlineAccountService onlnStg = new OnlineAccountService();
	 Session session = null;
	 Transaction transaction = null;
	 
	 try {
		 logger.info("Inside DBService :: getRequestMsgFromScrnRef method :: Execution Started");
		 Class classInstance = Class.forName("com.majesco.dcf.common.tagic.entity.OnlineAccountService");
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			
			Criteria criteria = session.createCriteria(classInstance);
			criteria.add(Restrictions.and(
					Restrictions.eq("strorderid", screenRef)));
			
			orderList = criteria.list();
			
			for (Iterator iterator = orderList.iterator(); iterator.hasNext();) {
				onlnStg = (OnlineAccountService) iterator.next();
			}

			if (orderList.size() > 0) {
				strReqMsg = onlnStg.getStrRequestMsg();
			}
			
			String sql = "select dcf.strrequestmsg as strRequestMsg from dcf_online_stg dcf where dcf.strorderid = :orderId";
			Query query = session.createSQLQuery(sql)
					.addScalar("strRequestMsg",StandardBasicTypes.STRING)
					.setParameter("orderId", screenRef);
			//strReqMsg = query; 
			transaction.commit();
	 }
	 catch(Exception e) {
		 transaction.rollback();
			logger.error("::::::Error in fetchTxnWithPendingStatus ::::::", e);
			e.printStackTrace();
	 }
	 
	 return strReqMsg;
}
*/

public OnlineAccountService getListFromScrnRef(String screenRef) {
   //String strReqMsg = "";
   List orderList = new ArrayList();
   OnlineAccountService onlnStg = new OnlineAccountService();
   Session session = null;
   Transaction transaction = null;
   
   try {
           logger.info("Inside DBService :: getRequestMsgFromScrnRef method :: Execution Started");
           Class classInstance = Class.forName("com.majesco.dcf.common.tagic.entity.OnlineAccountService");
                  session = transactionManager.getSessionFactory()
                                  .getCurrentSession();
                  transaction = session.getTransaction();
                  if (!transaction.isActive()) {
                          session.beginTransaction();
                  }
                  
                  Criteria criteria = session.createCriteria(classInstance);
                  criteria.add(Restrictions.and(
                                  Restrictions.eq("strOrderID", screenRef)));
                  
                  orderList = criteria.list();
                  
                  for (Iterator iterator = orderList.iterator(); iterator.hasNext();) {
                          onlnStg = (OnlineAccountService) iterator.next();
                  }

                  /*if (orderList.size() > 0) {
                          strReqMsg = onlnStg.getStrRequestMsg();
                  }*/
                  
                  /*String sql = "select dcf.strrequestmsg as strRequestMsg from dcf_online_stg dcf where dcf.strorderid = :orderId";
                  Query query = session.createSQLQuery(sql)
                                  .addScalar("strRequestMsg",StandardBasicTypes.STRING)
                                  .setParameter("orderId", screenRef);
                  //strReqMsg = query; 
*/                         transaction.commit();

        logger.info("Inside DBService :: getRequestMsgFromScrnRef method :: Execution End successfully");
   }
   catch(Exception e) {
           transaction.rollback();
                  logger.error("::::::Error in fetchTxnWithPendingStatus ::::::", e);
                  e.printStackTrace();
   }
   
   return onlnStg;
}


	public String getBilldeskTrnsrefData(String orderId) {
		Session session = null;
		Transaction transaction = null;
		StringBuilder query = new StringBuilder();
		ArrayList<Object[]> retList = new ArrayList();
		String pgtxnrefno = "";
		try {
			logger.info("Inside DBService :: getBilldeskTrnsrefData(String) method :: Execution Started");

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			query.append("select strpgtxnrefno from dcf_pg_transaction where strscreenrefno = :orderId");

			logger.info("Inside DBService :: getBilldeskTrnsrefData method :: buildQuery.toString() : "
					+ query.toString());

			SQLQuery sqlQuery = session.createSQLQuery(query.toString())
					.addScalar("strpgtxnrefno", StandardBasicTypes.STRING); // Added
																		// for
																		// oracle
																		// migration
			sqlQuery.setParameter("orderId", orderId);
			retList = (ArrayList) sqlQuery.list();
			if (retList != null) {
				Object lst = retList.get(0);
				pgtxnrefno = (String) lst;
			}
			logger.info("Inside DBService :: getBilldeskTrnsrefData method :: Size Of list : "
					+ retList.size());

      	        transaction.commit();
        	     }
        	     catch(Exception e)
         		 {
        	    	transaction.rollback();
         	    	logger.info("Inside DBService :: getBilldeskTrnsrefData:: Exception Occurred..."+e);
         			logger.error("Inside DBService :: getBilldeskTrnsrefData method :: Exception Occurred..."+e);
         		 }
        	     return pgtxnrefno;
        	}
	
	public String getHouseBranchFinCode(String officeCode,String paymentMode,String accountNo,String branchCode){
		Session session = null;
		Transaction transaction = null;
		Query query= null;
		ArrayList<Integer> retList= new ArrayList();
		String finanCode = "";
		try {

			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			
			String sqlQuery = "";
	sqlQuery = "select num_financier_cd from dcf_accmst_bank_brnch_relation a "; 							
				sqlQuery = sqlQuery + "where a.num_office_cd = :_officecd and a.txt_payment_mode =:_paymentmode and a.num_financier_branch_cd = :_financierbranch and a.txt_bank_account_no_cheque= :_accountno ";
				logger.info("DBService :: Else:: sqlQuery="+ sqlQuery);							
	query = session.createSQLQuery(sqlQuery)
			// START : ADDED FOR ORACLE MIGRATION
			.addScalar("num_financier_cd", StandardBasicTypes.INTEGER)

			// END : ADDED FOR ORACLE MIGRATION
			;
				query.setParameter("_officecd", Integer.parseInt(officeCode));
				query.setParameter("_paymentmode", paymentMode);
				query.setParameter("_financierbranch", branchCode);
				query.setParameter("_accountno", accountNo);

			logger.info("DBService :: getHouseBranchFinCode :: query="+ query);
				retList = (ArrayList) query.list();
			if(retList!=null && !retList.isEmpty() &&retList.size()>0)
    		{
				Integer financiercd = retList.get(0);
				int finCode = financiercd.intValue();
				finanCode = finCode+"";
    		}
			transaction.commit();
			if(session != null && session.isConnected()){
				session .close();
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			logger.error("getHouseBranchFinCode ::", ex);
			if(session != null && session.isConnected()){
				session .close();
			}

		}
		
		return finanCode;					
	}
	

	public String getPolicyNumFromProposalNo(String proposalNo){
		Session session = null;
		Transaction transaction = null;
		Query query= null;
		ArrayList<String> retList= new ArrayList();
		String policyNo = "";
		try {
			logger.info("DBService :: getPolicyNumFromProposalNo :: START");
		if(proposalNo != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(proposalNo)){
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();
			if (!transaction.isActive()) {
				session.beginTransaction();
			}
			
			String sqlQuery = "";
				sqlQuery ="select txt_policy_no_char from gen_prop_information_tab@ch_portal where num_reference_number = :_proposalNo";
				logger.info("DBService :: Else:: sqlQuery="+ sqlQuery);							
	query = session.createSQLQuery(sqlQuery)
			// START : ADDED FOR ORACLE MIGRATION
			.addScalar("txt_policy_no_char", StandardBasicTypes.STRING)

			// END : ADDED FOR ORACLE MIGRATION
			;
				query.setParameter("_proposalNo", proposalNo);


			logger.info("DBService :: getPolicyNumFromProposalNo :: query="+ query);
				retList = (ArrayList) query.list();
			if(retList!=null && !retList.isEmpty() &&retList.size()>0)
    		{
				policyNo = retList.get(0);
    		}
			transaction.commit();
			if(session != null && session.isConnected()){
				session .close();
			}
		  }
		logger.info("DBService :: getPolicyNumFromProposalNo :: END");
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			logger.error("getPolicyNumFromProposalNo ::", ex);
			if(session != null && session.isConnected()){
				session .close();
			}

		}
		
		return policyNo;					
	}
	

	
	public List getFailedSplitService() throws Exception {
		List failedTransList = new ArrayList<>();
		String strMethodName = "getFailedSplitService";
		Session session = null;
		Transaction transaction = null;
		Connection conn = null; // Added for oracle migration
		CallableStatement csmt = null; // Added for oracle migration
		try {

			logger.info("Inside DBService :: " + strMethodName + " :: Entered");
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();

			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : CHANGES FOR ORACLE MIGRATION

			// Query query =
			// session.createSQLQuery("select * from func_get_failedtrans_lst()");
			// failedTransList =
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			// logger.info(" Failed Transaction List " +
			// failedTransList.size());

			Query query = session.createSQLQuery(
					"select * from table(func_get_failed_lst())")
					.addScalar("strscreenrefno", StandardBasicTypes.STRING)
			        .addScalar("strtxnmodeVal", StandardBasicTypes.STRING);
			failedTransList = query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();
			logger.info(" Failed Transaction List getFailedSplitService " + failedTransList.size());

			// END : CHANGES FOR ORACLE MIGRATION

		} catch (Exception ex) {
			logger.error("DBService :: " + strMethodName + " catch block ::",
					ex);
			transaction.rollback();
			throw ex;
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		return failedTransList;
	}
	
	
	public String getReceiptFromProposal(String proposalNo) {
		Session session = null;
		Transaction transaction = null;
		Query query = null;
		String receiptNo = "";
		List<PmtFlowFlags> pgtxnlstResult = new ArrayList<PmtFlowFlags>();
		PmtFlowFlags pgTxn = new PmtFlowFlags();
		List<PmtFlowFlags> pgtxnList = null;
		try {
			logger.info("DBService :: getReceiptFromProposal :: START");
			if (proposalNo != null
					&& !CommonConstants.BLANK_STRING.equalsIgnoreCase(proposalNo)) {
				session = transactionManager.getSessionFactory()
						.getCurrentSession();
				transaction = session.getTransaction();
				if (!transaction.isActive()) {
					session.beginTransaction();
				}

				String sqlQuery = "";
				sqlQuery = "select pmt.STR_RECEIPT_NO as strreceiptno from DCF_PMTFLOW_FLAGS pmt where STR_PROPOSAL_NO= :_proposalNo";
				logger.info("DBService :: Else:: sqlQuery=" + sqlQuery);
				query = session.createSQLQuery(sqlQuery).addScalar(
						"strreceiptno", StandardBasicTypes.STRING);

				// END : ADDED FOR ORACLE MIGRATION
				;
				query.setParameter("_proposalNo", proposalNo);

				Object retList = query.setResultTransformer(
						Transformers.aliasToBean(PmtFlowFlags.class)).list();
				if (retList != null) {
					pgtxnList = (List<PmtFlowFlags>) retList;
				}
				logger.info("DBService :: getReceiptFromProposal :: query="
						+ query);

				if (pgtxnList != null) {
					for (int i = 0; i < pgtxnList.size(); i++) {

						if (pgtxnList.get(i) != null) {
							pgTxn = pgtxnList.get(i);
							pgtxnlstResult.add(pgTxn);
						}
					}
				}

				receiptNo = pgtxnlstResult.get(0).getStrreceiptno();
				System.out.println(receiptNo);

				transaction.commit();
				if (session != null && session.isConnected()) {
					session.close();
				}
			}
			logger.info("DBService :: getReceiptFromProposal :: END");
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error("getReceiptFromProposal ::", ex);
			if (session != null && session.isConnected()) {
				session.close();
			}

		}

		return receiptNo;
	}
	
	
	public List getPolicyProcFromProposal(String proposalNo) throws Exception {
		List transList = new ArrayList<>();
		Session session = null;
		Transaction transaction = null;
		Connection conn = null; // Added for oracle migration
		CallableStatement csmt = null; // Added for oracle migration
		try {

			logger.info("Inside DBService :: getReceiptFromProposal :: Entered");
			session = transactionManager.getSessionFactory()
					.getCurrentSession();
			transaction = session.getTransaction();

			if (!transaction.isActive()) {
				session.beginTransaction();
			}

			// START : CHANGES FOR ORACLE MIGRATION

			// Query query =
			// session.createSQLQuery("select * from func_get_failedtrans_lst()");
			// failedTransList =
			// query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
			// logger.info(" Failed Transaction List " +
			// failedTransList.size());

			Query query = session.createSQLQuery(
					"select * from table(func_get_policy_no(:_proposalNo))")
					.addScalar("txt_policy_no_char", StandardBasicTypes.STRING)
			        .addScalar("status", StandardBasicTypes.STRING)
					.addScalar("active_flag", StandardBasicTypes.STRING);
			query.setParameter("_proposalNo",proposalNo);
			transList = query.setResultTransformer(
					Criteria.ALIAS_TO_ENTITY_MAP).list();
			logger.info(" Failed Transaction List getReceiptFromProposal " + transList.size());

			// END : CHANGES FOR ORACLE MIGRATION

		} catch (Exception ex) {
			logger.error("DBService :: catch block ::",
					ex);
			transaction.rollback();
			throw ex;
		}
		// START : CHANGES FOR ORACLE MIGRATION
		finally {
			try {
				if (csmt != null)
					csmt.close(); // close CallableStatement
				if (conn != null)
					conn.close(); // close connection
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// END : CHANGES FOR ORACLE MIGRATION
		return transList;
	}
	
}   

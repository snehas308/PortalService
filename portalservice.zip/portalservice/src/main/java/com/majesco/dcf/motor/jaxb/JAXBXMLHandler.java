package com.majesco.dcf.motor.jaxb;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

//import com.sun.xml.internal.bind.marshaller.CharacterEscapeHandler;

public class JAXBXMLHandler {

	public static String marshal(Object jaxbObj)
			throws IOException, JAXBException {
		JAXBContext context;
		BufferedWriter writer = null;
		StringWriter strwriter=null;
		try {
			//writer = new BufferedWriter(new FileWriter(selectedFile));
			context = JAXBContext.newInstance(jaxbObj.getClass());
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			strwriter=new StringWriter();
			m.marshal(jaxbObj, strwriter);
			//System.out.println(strwriter.toString());
			
		} finally {
			/*try {
				writer.close();
			} catch (IOException io) { 
			}*/
		}
		
		return strwriter.toString();
	}

	public static Object unmarshal(String str,Object jaxbObj) throws JAXBException {
		JAXBContext context;
		str=str.replaceAll( "<!\\[CDATA\\[", "");
		str=str.replaceAll( "\\]\\]>", "");
		InputStream in=new ByteArrayInputStream(str.getBytes());
		
		context = JAXBContext.newInstance(jaxbObj.getClass());
		Unmarshaller um = context.createUnmarshaller();
		jaxbObj = um.unmarshal(in);
		//return um.unmarshal(new StringReader(str));
		return jaxbObj;
	}
	
	public static Object unmarshalTest(File importFile,Object jaxbObj) throws JAXBException {
		Object book = new Object();
		JAXBContext context;

		context = JAXBContext.newInstance(jaxbObj.getClass());
		Unmarshaller um = context.createUnmarshaller();
		book = (Object) um.unmarshal(importFile);

		return book;
	}
}
package com.majesco.dcf.common.tagic.entity;


import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_ch_field_user_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_ch_field_user_m")							// Added for Oracle Migration
public class FieldUser implements Serializable{
	
	private BigDecimal nfielduserseq;
	private BigDecimal nfieldusercd;
	private String struserid ="";
	private String strfieldusername ="";
	private String strintermediarycd = "";
	private BigDecimal nofficecd;
	private String dtstart="";
	private String dtend="";
	private String strcnissuance ="";
	private String stractiveflag ="";
	private String dtcreated ="";
	private String strcreatedby ="";
	private String dtupdated ="";
	private String strupdatedby ="";
	
	@Id
	@Column(name = "nfielduserseq")
	public BigDecimal getNfielduserseq() {
		return nfielduserseq;
	}
	public void setNfielduserseq(BigDecimal nfielduserseq) {
		this.nfielduserseq = nfielduserseq;
	}
	
	@Column(name = "nfieldusercd")
	public BigDecimal getNfieldusercd() {
		return nfieldusercd;
	}
	public void setNfieldusercd(BigDecimal nfieldusercd) {
		this.nfieldusercd = nfieldusercd;
	}
	
	@Column(name = "struserid")
	public String getStruserid() {
		return struserid;
	}
	public void setStruserid(String struserid) {
		this.struserid = struserid;
	}
	
	@Column(name = "strfieldusername")
	public String getStrfieldusername() {
		return strfieldusername;
	}
	public void setStrfieldusername(String strfieldusername) {
		this.strfieldusername = strfieldusername;
	}
	
	@Column(name = "strintermediarycd")
	public String getStrintermediarycd() {
		return strintermediarycd;
	}
	public void setStrintermediarycd(String strintermediarycd) {
		this.strintermediarycd = strintermediarycd;
	}
	
	@Column(name = "nofficecd")
	public BigDecimal getNofficecd() {
		return nofficecd;
	}
	public void setNofficecd(BigDecimal nofficecd) {
		this.nofficecd = nofficecd;
	}
	
	@Column(name = "dtstart")
	public String getDtstart() {
		return dtstart;
	}
	public void setDtstart(String dtstart) {
		this.dtstart = dtstart;
	}
	
	@Column(name = "dtend")
	public String getDtend() {
		return dtend;
	}
	public void setDtend(String dtend) {
		this.dtend = dtend;
	}
	
	@Column(name = "strcnissuance")
	public String getStrcnissuance() {
		return strcnissuance;
	}
	public void setStrcnissuance(String strcnissuance) {
		this.strcnissuance = strcnissuance;
	}
	
	@Column(name = "stractiveflag")
	public String getStractiveflag() {
		return stractiveflag;
	}
	public void setStractiveflag(String stractiveflag) {
		this.stractiveflag = stractiveflag;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
}

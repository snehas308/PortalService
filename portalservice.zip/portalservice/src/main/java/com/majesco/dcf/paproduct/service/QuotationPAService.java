package com.majesco.dcf.paproduct.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.paproduct.json.QuotationPARequest;
import com.majesco.dcf.paproduct.json.QuotationPAResponse;

@Service
public class QuotationPAService {
	
	final static Logger logger=Logger.getLogger(QuotationPAService.class);

	public QuotationPAResponse getQuoteforPA(QuotationPARequest quoteReq) throws Exception
	{
		logger.info("Inside QuotationPAService :: getQuoteforPA method :: Execution Started");
		
		QuotationPAResponse quotres = new QuotationPAResponse();
		List<ResponseError> lstResErr  = new ArrayList<ResponseError>();
		ResponseError reserr = new ResponseError();
		PremiumDetails prmdet = new PremiumDetails();
		
		try{
			
			reserr.setErrorCode("101");
			reserr.setErrorMMessag("Sorry Authentication Issue....");
			lstResErr.add(reserr);
			
			prmdet.setNetPremium("100000");
			prmdet.setDiscount("100");
			prmdet.setPremiumPayable("400.00");
			prmdet.setServiceTax("200");
			prmdet.setSumInsured("10000");
			
			quotres.setPremDet(prmdet);
			quotres.setRessErr(lstResErr);
			quotres.setQuotenumber("PA101");
			quotres.setQuotever("1");
			quotres.setResultCode("Y");
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info("Inside QuotationPAService :: getQuoteforPA method :: Exception Occurred : "+e.toString());
		}
		
		logger.info("Inside QuotationPAService :: getQuoteforPA method :: Execution Completed Successfully");
		
		return quotres;
	}
	
}

package com.majesco.dcf.common.tagic.json;

public class ContactDetails {

	private String preferredcommunication;
	private String emailID;
	private String mobileNumber;
	private String std;
	private String landlinenumber;
	
	
	public String getPreferredcommunication() {
		return preferredcommunication;
	}
	public void setPreferredcommunication(String preferredcommunication) {
		this.preferredcommunication = preferredcommunication;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getLandlinenumber() {
		return landlinenumber;
	}
	public void setLandlinenumber(String landlinenumber) {
		this.landlinenumber = landlinenumber;
	}
	public String getStd() {
		return std;
	}
	public void setStd(String std) {
		this.std = std;
	}
	
	
}

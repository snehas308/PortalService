package com.majesco.dcf.common.tagic.impl;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.ws.Holder;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;

import org.apache.commons.codec.binary.Base64;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestBody;


//import com.majesco.dcf.common.tagic.json.Ticket;







import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.majesco.dcf.common.tagic.entity.PaymentDetails;
import com.googlecode.ehcache.annotations.Cacheable;
import com.majesco.dcf.common.tagic.entity.Product;
import com.majesco.dcf.common.tagic.entity.RenPolicyMaster;
import com.majesco.dcf.common.tagic.json.AddressDetails;
import com.majesco.dcf.common.tagic.json.AgentDashBoardRequest;
import com.majesco.dcf.common.tagic.json.AgentDashBoardResponse;
import com.majesco.dcf.common.tagic.json.AuthenticationResponse;
import com.majesco.dcf.common.tagic.json.BankDetails;
import com.majesco.dcf.common.tagic.json.ContactDetails;
import com.majesco.dcf.common.tagic.json.CustomerDetails;
import com.majesco.dcf.common.tagic.json.DashBoardSummaryDetails;
import com.majesco.dcf.common.tagic.json.FastLaneRequest;
import com.majesco.dcf.common.tagic.json.FastLaneResponse;
import com.majesco.dcf.common.tagic.json.HouseBankAccNoRequest;
import com.majesco.dcf.common.tagic.json.HouseBankAccNoResponse;
import com.majesco.dcf.common.tagic.json.IdDetails;
import com.majesco.dcf.common.tagic.json.JsonDBService;
import com.majesco.dcf.common.tagic.json.KeyValuePair;
import com.majesco.dcf.common.tagic.json.PendingApprovalList;
import com.majesco.dcf.common.tagic.json.PendingInspectionList;
import com.majesco.dcf.common.tagic.json.PendingPayInSlipResponse;
import com.majesco.dcf.common.tagic.json.PendingPaymentList;
import com.majesco.dcf.common.tagic.json.PendingPropListRequest;
import com.majesco.dcf.common.tagic.json.PendingPropListResponse;
import com.majesco.dcf.common.tagic.json.PendingQuotesList;
import com.majesco.dcf.common.tagic.json.PolicyAddressDetails;
import com.majesco.dcf.common.tagic.json.PolicyCustomerDetails;
import com.majesco.dcf.common.tagic.json.PolicyDetailsSearchRequest;
import com.majesco.dcf.common.tagic.json.PolicyDetailsSearchResponse;
import com.majesco.dcf.common.tagic.json.PolicySearchRequest;
import com.majesco.dcf.common.tagic.json.PolicySearchResponse;
import com.majesco.dcf.common.tagic.json.PolicySearchResultDet;
import com.majesco.dcf.common.tagic.json.PortalLockDaysRequest;
import com.majesco.dcf.common.tagic.json.PortalLockDetails;
import com.majesco.dcf.common.tagic.json.PrintProposalReq;
import com.majesco.dcf.common.tagic.json.ProposalSearchRequest;
import com.majesco.dcf.common.tagic.json.ProposalSearchResponse;
import com.majesco.dcf.common.tagic.json.ProposalSearchResultDet;
import com.majesco.dcf.common.tagic.json.ProposalStatus;
import com.majesco.dcf.common.tagic.json.ProposalStatusReq;
import com.majesco.dcf.common.tagic.json.QlikTicketResponse;
//import com.majesco.dcf.common.tagic.json.QlikTicketResponse;
import com.majesco.dcf.common.tagic.json.QuotationListResponse;
import com.majesco.dcf.common.tagic.json.QuotationSearchRequest;
import com.majesco.dcf.common.tagic.json.QuotationSearchResponse;
import com.majesco.dcf.common.tagic.json.RejectedProposalList;
import com.majesco.dcf.common.tagic.json.RenewalCalCountData;
import com.majesco.dcf.common.tagic.json.RenewalCalCountRequest;
import com.majesco.dcf.common.tagic.json.RenewalCalCountResponse;
import com.majesco.dcf.common.tagic.json.RenewalPolLetterRequest;
import com.majesco.dcf.common.tagic.json.RenewalPolLetterResponse;
import com.majesco.dcf.common.tagic.json.RenewalSearchData;
import com.majesco.dcf.common.tagic.json.RenewalSearchRequest;
import com.majesco.dcf.common.tagic.json.RenewalSearchResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.SPLExpiredList;
import com.majesco.dcf.common.tagic.json.Ticket;
import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.common.tagic.json.ValueByEffDateRequest;
import com.majesco.dcf.common.tagic.json.ValueByEffDateResponse;
import com.majesco.dcf.common.tagic.service.AuthenticationService;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.GenerateCacheService;
import com.majesco.dcf.common.tagic.service.TagicCommonService;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.motor.jaxb.search.quote.SearchQuotationRequest;
import com.majesco.dcf.motor.serviceImpl.MotorServiceImpl;
import com.majesco.dcf.receipt.json.ReceiptDetailsResponse;
import com.majesco.dcf.receipt.json.getPolicyDetailsEODResponse;
import com.majesco.dcf.receipt.util.ReceiptConstants;
import com.majesco.dcf.reports.json.PremiumReceivableReportResponse;
import com.majesco.dcf.usermgmt.json.UserDetails;
import com.majesco.dcf.usermgmt.json.UserInfoResponse;
import com.majesco.dcf.common.chp.util.CdataWriterInterceptor;
import com.majesco.dcf.common.chp.util.JAXBXMLHandler;
import com.unotechsoft.stub.accountservice.client.AccountService;
import com.unotechsoft.stub.accountservice.client.AccountService_Service;
import com.unotechsoft.stub.accountservice.client.ClsPaymentAccept;
import com.unotechsoft.stub.accountservice.client.GetDetailsForGridForPortal2;
import com.unotechsoft.stub.accountservice.client.GetDetailsForGridForPortalResponse2;
import com.unotechsoft.stub.accountservice.client.GetHTMLReport2;
import com.unotechsoft.stub.accountservice.client.GetHTMLReportResponse2;
import com.unotechsoft.stub.accountservice.client.GetUserWisePaymentDtlsForAcceptanceForPortal2;
import com.unotechsoft.stub.accountservice.client.KeyValue;
import com.unotechsoft.stub.accountservice.client.PaymentAcceptanceServiceResult;
import com.unotechsoft.stub.accountservice.client.PaymentDepositServiceResult;
import com.unotechsoft.stub.accountservice.client.PaymentEntryServiceResult;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentAcceptance;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentDeposit;
import com.unotechsoft.stub.commonservice.approval.client.ApprovalPending;
import com.unotechsoft.stub.commonservice.approval.client.ApprovalPending_Service;
import com.unotechsoft.stub.commonservice.approval.client.GetApprovalPendingProposalOtherDetails;
import com.unotechsoft.stub.commonservice.approval.client.GetApprovalPendingProposalOtherDetailsResponse;
import com.unotechsoft.stub.commonservice.approval.client.ProposalOtherDetailsResult;
import com.unotechsoft.stub.commonservice.dbservice.client.DBService_Service;
import com.unotechsoft.stub.commonservice.dbservice.client.ProposalNoRequest;
import com.unotechsoft.stub.commonservice.dbservice.client.ProposalNoResponse;
import com.unotechsoft.stub.commonservice.dbservice.client.QuotationNoRequest;
import com.unotechsoft.stub.commonservice.dbservice.client.WorkflowIdResponce;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentDeposit;
import com.unotechsoft.stub.commonservice.fastlane.client.FastLaneService;
import com.unotechsoft.stub.commonservice.fastlane.client.FastLaneService_Service;
import com.unotechsoft.stub.commonservice.fastlane.client.GetfastLaneAuotomobileResponse;
import com.unotechsoft.stub.commonservice.fastlane.client.Response;
import com.unotechsoft.stub.commonservice.fastlane.client.Result;
import com.unotechsoft.stub.commonservice.fastlane.client.Vehicle;
import com.unotechsoft.stub.commonservice.generic.client.ArrayOfclsDailyConvertPendingGrid;
import com.unotechsoft.stub.commonservice.generic.client.ArrayOfclsMISDetailSearchGrid;
import com.unotechsoft.stub.commonservice.generic.client.ArrayOfclsPolicySearchForPortalGrid;
import com.unotechsoft.stub.commonservice.generic.client.ArrayOfclsProposalSearchForPortalGrid;
import com.unotechsoft.stub.commonservice.generic.client.ArrayOfclsQuotionSearchForPortalGrid;
import com.unotechsoft.stub.commonservice.generic.client.ClsDailyConvertPendingGrid;
import com.unotechsoft.stub.commonservice.generic.client.ClsMISDetailSearchGrid;
import com.unotechsoft.stub.commonservice.generic.client.ClsPolicySearchForPortalGrid;
import com.unotechsoft.stub.commonservice.generic.client.ClsProposalSearchForPortalGrid;
import com.unotechsoft.stub.commonservice.generic.client.ClsQuotionSearchForPortalGrid;
import com.unotechsoft.stub.commonservice.generic.client.ClsUserData;
import com.unotechsoft.stub.commonservice.generic.client.GenericIntegration;
import com.unotechsoft.stub.commonservice.generic.client.GenericIntegration_Service;
import com.unotechsoft.stub.commonservice.generic.client.MisDetailSearchGetObjectData;
import com.unotechsoft.stub.commonservice.proppoldocument.client.GetRenewalLetterForPortal;
import com.unotechsoft.stub.commonservice.proppoldocument.client.GetRenewalLetterForPortalResponse;
import com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult;
import com.unotechsoft.stub.genericservice.client.Dealer;
import com.unotechsoft.stub.genericservice.client.GenericResult;
import com.unotechsoft.stub.genericservice.client.GenericSerive;
import com.unotechsoft.stub.genericservice.client.GenericSerive_Service;
import com.unotechsoft.stub.genericservice.client.GetPendingProposalList;
import com.unotechsoft.stub.genericservice.client.LOVTypeDealer;
import com.unotechsoft.stub.genericservice.client.LOVTypePolicyDetail;
import com.unotechsoft.stub.genericservice.client.LOVTypePortalIDLocking;
import com.unotechsoft.stub.motorservice.quotesearch.GetQuotationSearch;
import com.unotechsoft.stub.motorservice.quotesearch.QuotationLOVInfo;
import com.unotechsoft.stub.motorservice.quotesearch.QuotationRequest;
import com.unotechsoft.stub.motorservice.quotesearch.SearchStubService;
import com.unotechsoft.stub.motorservice.quotesearch.SearchStubService_Service;
import com.unotechsoft.stub.policysearch.client.LOVType;
import com.unotechsoft.stub.inspectionservice.client.ArrayOfclsUserData_Portal;
import com.unotechsoft.stub.inspectionservice.client.ClsUserData_Portal;
import com.unotechsoft.stub.inspectionservice.client.VehicleInspction;
import com.unotechsoft.stub.inspectionservice.client.VehicleInspction_Service;

import java.util.Set;

import net.sf.ehcache.Cache;		
import net.sf.ehcache.CacheManager;		
import net.sf.ehcache.Element;

import com.unotechsoft.stub.commonservice.dbservice.client.DBService_Service;
import com.unotechsoft.stub.commonservice.dbservice.client.ProposalNoRequest;
import com.unotechsoft.stub.commonservice.dbservice.client.ProposalNoResponse;
import com.unotechsoft.stub.commonservice.dbservice.client.QuotationNoRequest;
import com.unotechsoft.stub.commonservice.dbservice.client.WorkflowIdResponce;
import com.unotechsoft.stub.genericservice.client.LOVTypeFieldUserDetails;

@Service
@Transactional
public class TagicCommonServiceImpl implements TagicCommonService {

	final static Logger logger = Logger.getLogger(TagicCommonServiceImpl.class);
	
	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/
@Value("${payinslip.privilege}")
	private String privilegePayInSlipLock;
	
	@Value("${eod.privilege}")
	private String privilegeEODLock;

	@Autowired
	AuthenticationService authServ;
	
	@Autowired
	DBService dbService;
	
	
	
	public String propValue="";
	CacheManager cm = CacheManager.getInstance();
	Ehcache cache = null;
	
	@Override
	public ProposalStatus getProposalStatus(ProposalStatusReq reqObj) throws Exception {
		// TODO Auto-generated method stub
		String strMethod="getProposalStatus";
		ProposalStatus statusObj=null;
		String wsdlUrl=null;

		JSONObject statusCache = new JSONObject(); //Added By Ketan - 23/05/2017
		GenerateCacheService generateCacheService = new GenerateCacheService(); //Added By Ketan - 23/05/2017
		ObjectMapper objMap = new ObjectMapper(); //Added By Ketan - 23/05/2017
		
		logger.info("Inside "+_strClassName+" :: "+strMethod+" :: Entered");
		
		if(reqObj!=null && reqObj.getProposalNo()!=null && !reqObj.getProposalNo().equalsIgnoreCase("")){
			
			String source=smc_source;
			String medium=smc_medium;
			String campaign=smc_campaign;
			String strToken=reqObj.getAuthToken();
			String strPropStatus=null;
			String strPropDesc=null;
			HashMap statusMap = new HashMap();
			try{
			//wsdlUrl = getWSDLURL(CommonConstants.PROPOSAL_STATUS_SERVICE);
			
			//GenConfStubService_Service stubService= new GenConfStubService_Service(new URL(wsdlUrl));
			//com.unotechsoft.stub.commonservice.proposalstatus.client.GenConfStubService port=stubService.getSOAPOverHTTP();
			
			//strPropStatus=port.getProposalStatus(source, medium, campaign, strToken, reqObj.getProposalNo());
				ProposalSearchRequest proposalSearchRequest=new ProposalSearchRequest();
				proposalSearchRequest.setAuthToken(strToken);
				proposalSearchRequest.setProposalNo(reqObj.getProposalNo());
				proposalSearchRequest.setProducerCode(reqObj.getProducerCode());
				
			ProposalSearchResponse proposalSearchResponse=searchProposal(proposalSearchRequest);
			//Start:TAGIC:20/12/2016:Added for new proposal search method
			if(proposalSearchResponse!=null){
				if(proposalSearchResponse.getProposalSearchResultDetList()!=null && proposalSearchResponse.getProposalSearchResultDetList().size()>0){
					ProposalSearchResultDet proposalSearchResultDet=proposalSearchResponse.getProposalSearchResultDetList().get(0);
					strPropStatus=proposalSearchResultDet.getStatusCode();
			if(strPropStatus!=null && !strPropStatus.equalsIgnoreCase("")){
				statusObj =new ProposalStatus();
				statusObj.setProposalStatus(strPropStatus);
				
				//strPropDesc=dbService.getCodeDesc(null, strPropStatus, "1097", "1"); //Commented By Ketan For EhCache Implementation
				/*Block Added By Ketan - 23/05/2017.......................*/
				cache = cm.getEhcache("proposalStatusCache");
				Element strDescription = cache.get(strPropStatus);
				if(strDescription == null)
				{
					logger.info("Cache Created For The First Time................");
					statusCache = new JSONObject();
					statusCache = generateCacheService.getProposalStatusCache(dbService);
					
					Set keyMap = (Set) statusCache.keySet();
					Iterator it = keyMap.iterator();
					while(it.hasNext())
					{
						String key = it.next().toString();
						cache.put(new Element(key,statusCache.get(key)));
					}
					Element strDesc = cache.get(strPropStatus);
					strPropDesc = strDesc.getObjectValue().toString();
				}
				else
				{
					logger.info("Retrieving Values through Cache................");
					Element strDesc = cache.get(strPropStatus);
					strPropDesc = strDesc.getObjectValue().toString();
				}
				/*Block Added By Ketan - 23/05/2017.......................*/

				statusObj.setProposalStatusDesc(strPropDesc);
			}
				}
			}//End:TAGIC:20/12/2016:Added for new proposal search method
			}catch(Exception ex){
				logger.error("Inside "+_strClassName+" :: "+strMethod+" :: Error", ex);
			}
		}
		
		return statusObj;
	}
	
	
	
	@Override
	public PolicyDetailsSearchResponse getPolicyDetailsByPolicyNo(PolicyDetailsSearchRequest prodPropDataReq) 
	{
		
		long transId = System.nanoTime();
        logger.info("TransactionID:"+transId+" :: Inside CommonServiceImpl :: getPolicyDetailsByPolicyNo() method :: Execution Started");
        
        propValue="";
        
        PolicyDetailsSearchResponse propRes = new PolicyDetailsSearchResponse();
        
        if(propValue.equalsIgnoreCase(""))
			propValue = this.getWSDLURL(CommonConstants.POLICY_SEARCH);
        
        List<ResponseError> reserrList; 
        
        reserrList = new ArrayList<ResponseError>();
        ResponseError res = new ResponseError();
        JAXBXMLHandler jaxbHandler=new JAXBXMLHandler();
        String jaxbXML = "";
        
        
        try
        {
               ObjectMapper objMapper = new ObjectMapper();
              // if(logger.isDebugEnabled())logger.debug("Inside CommonServiceImpl :: getPolicyDetailsByPolicyNo() method :: Recieved Request JSON Object :: " + objMapper.writeValueAsString(prodPropDataReq));
               
               
               try{
            	   	
            	   com.majesco.dcf.motor.jaxb.policy.request.GetPolicyDetailByPolicyNo p2DtoReq = new com.majesco.dcf.motor.jaxb.policy.request.GetPolicyDetailByPolicyNo();
            	   URL url = new URL(propValue);
            	   com.unotechsoft.stub.policysearch.client.SearchStubService_Service stub = new com.unotechsoft.stub.policysearch.client.SearchStubService_Service(url);

            	   if(prodPropDataReq.getPolicyNumber() != null && !prodPropDataReq.getPolicyNumber().equalsIgnoreCase("")){
            		   p2DtoReq.setStrPolicyNo(prodPropDataReq.getPolicyNumber());
            	   }
            		   
            	   jaxbXML=JAXBXMLHandler.marshal(p2DtoReq);
            	   //if(logger.isDebugEnabled())logger.debug("Inside CommonServiceImpl :: getPolicyDetailsByPolicyNo() method :: JAXB XML :: "+jaxbXML);
       			   
       			     //Getting Authentication Token Starts Here
                     String propFileName = "resource.properties";
                     String userID="";
                     String password="";
                     String responseFrom = "";
                     Properties prop = new Properties();
                     InputStream inputStream = MotorServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
                     prop.load(inputStream);
                     userID=prodPropDataReq.getUserID();
                     password=prodPropDataReq.getPassword();
                     responseFrom=prop.getProperty("ResponseFrom");
                     AuthenticationResponse authRes=null;
                     String strGcToken=null;
                    //Start:Vishal<VAPT comments>| code added to set GC token into user object 
         			if (prodPropDataReq.getAuthToken()!=null && !prodPropDataReq.getAuthToken().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
         				strGcToken=prodPropDataReq.getAuthToken();
         			}else{                     
         				authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userID, password);
         				strGcToken=authRes.getResultRes();                     
         			}
         			//End:Vishal<VAPT comments>| code added to set GC token into user object         			
                    //Getting Authentication Token Stops Here
                     com.unotechsoft.stub.policysearch.client.QuotationRequest reqQ = new com.unotechsoft.stub.policysearch.client.QuotationRequest();
                     
                     reqQ.setAuthenticationToken(strGcToken);
                     //reqQ.setAuthenticationToken(authRes.getResultRes());
                     reqQ.setSource(smc_source);
                     reqQ.setProductCode(prodPropDataReq.getProductCode()==null?"":prodPropDataReq.getProductCode());
     				 reqQ.setModeOfOperation("NEWPOLICY");
                     reqQ.setCampaign(smc_campaign);
                     reqQ.setMedium(smc_medium);
                     reqQ.setCIAName("");
                     reqQ.setHashKey("");
                     reqQ.setHostAddress("");
                     reqQ.setInputXML(jaxbXML);
                     reqQ.setIsBankDataRequired(false);
                     reqQ.setIsCutomerAddressRequired(false);
                     reqQ.setIsFinanciarDataRequired(false);
                     reqQ.setIsManufacturerMappingRequired(false);
                     reqQ.setIsRTOMappingRequired(false);
                     reqQ.setUserId("jkadam");
     				reqQ.setUserRole("ADMIN");
                     
     				com.unotechsoft.stub.policysearch.client.SearchStubService port = stub.getSOAPOverHTTP();
                     Client client=ClientProxy.getClient(port);
                     PrintWriter writer = new PrintWriter(System.out);
                     
                     client.getOutInterceptors().add(new CdataWriterInterceptor());
                     client.getInInterceptors().add(new LoggingInInterceptor(writer));
                     client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
                     
                     //if(logger.isDebugEnabled())logger.debug("Requesting For Private Car Motor CommonServiceImpl :: getPolicyDetailsByPolicyNo()");
                     com.unotechsoft.stub.policysearch.client.GenericResult genericResult = port.getPolicyDetailByPolicyNo(reqQ);
                     //if(logger.isDebugEnabled())logger.debug("Response Recieved For Private Car Motor CommonServiceImpl :: getPolicyDetailsByPolicyNo()");
                     
                     com.unotechsoft.stub.policysearch.client.LOVTypePolicyDetail respObj;
                     List<LOVType> lovTypeList = genericResult.getLOVTypes().getLOVType();
                     com.unotechsoft.stub.policysearch.client.LOVTypePolicyDetail response = (com.unotechsoft.stub.policysearch.client.LOVTypePolicyDetail) lovTypeList.get(0);
                   
                     if (response != null) 
                     {
                    	 //if(logger.isDebugEnabled())logger.debug("CommonServiceImpl :: getPolicyDetailsByPolicyNo() : Response Recieved"+response.toString());
                    	 
                    	 if(response.getErrorText()!=null)
                    		 propRes.setErrorText(response.getErrorText());
                    	 if(response.getID()!=null)
                    		 propRes.setId(response.getID());
                    	 if(response.getName()!=null)
                    		 propRes.setName(response.getName());
                    	 if(response.getStartDate()!=null)
                    		 propRes.setStartDate(response.getStartDate());
                    	 if(response.getStartTime()!=null)
                    		 propRes.setStartTime(response.getStartTime());
                    	 if(response.getApplicationNo()!=null)
                    		 propRes.setApplicationNo(response.getApplicationNo());
                    	 if(response.getCertificateNo()!=null)
                    		 propRes.setCertificateNo(response.getCertificateNo());
                    	 if(response.getChassisNo()!=null)
                    		 propRes.setChassisNo(response.getChassisNo());
                    	 if(response.getClaimAmount()!=null)
                    		 propRes.setClaimAmount(response.getClaimAmount());
                    	 if(response.getClaimNo()!=null)
                    		 propRes.setClaimNo(response.getClaimNo());
                    	 if(response.getClaimStatus()!=null)
                    		 propRes.setClaimStatus(response.getClaimStatus());
                    	 if(response.getCollectionMode()!=null)
                    		 propRes.setCollectionMode(response.getCollectionMode());
                    	 if(response.getCovernoteNo()!=null)
                    		 propRes.setCovernoteNo(response.getCovernoteNo());
                    	 if(response.getCovernoteStatus()!=null)
                    		 propRes.setCovernoteStatus(response.getCovernoteStatus());
                    	 if(response.getCustomer()!=null)
                    	 {
                    		 PolicyCustomerDetails polCustDtls = new PolicyCustomerDetails();
                    		 
                    		 if(response.getCustomer().getDOB()!=null)
                    			 polCustDtls.setDob(response.getCustomer().getDOB());
                    		 if(response.getCustomer().getEmailId()!=null)
                    			 polCustDtls.setEmailId(response.getCustomer().getEmailId());
                    		 if(response.getCustomer().getEndDate()!=null)
                    			 polCustDtls.setEndDate(response.getCustomer().getEndDate());
                    		 if(response.getCustomer().getErrorText()!=null)
                    			 polCustDtls.setErrorText(response.getCustomer().getErrorText());
                    		 if(response.getCustomer().getGender()!=null)
                    			 polCustDtls.setGender(response.getCustomer().getGender());
                    		 if(response.getCustomer().getID()!=null)
                    			 polCustDtls.setId(response.getCustomer().getID());
                    		 if(response.getCustomer().getIFSCode()!=null)
                    			 polCustDtls.setIfscCode(response.getCustomer().getIFSCode());
                    		 if(response.getCustomer().getMICRCode()!=null)
                    			 polCustDtls.setMicrCode(response.getCustomer().getMICRCode());
                    		 
                    		 if(response.getCustomer().getMailLocation()!=null)
                    		 {
                    			 PolicyAddressDetails polAddrsDtls = new PolicyAddressDetails();
                    			 
                    			 if(response.getCustomer().getMailLocation().getAddressLine1()!=null)
                    				 polAddrsDtls.setAddressLine1(response.getCustomer().getMailLocation().getAddressLine1());
                    			 if(response.getCustomer().getMailLocation().getAddressLine2()!=null)
                    				 polAddrsDtls.setAddressLine2(response.getCustomer().getMailLocation().getAddressLine2());
                    			 if(response.getCustomer().getMailLocation().getAddressLine3()!=null)
                    				 polAddrsDtls.setAddressLine3(response.getCustomer().getMailLocation().getAddressLine3());
                    			 if(response.getCustomer().getMailLocation().getAreaVillageCode()!=null)
                    				 polAddrsDtls.setAreaVillageCode(response.getCustomer().getMailLocation().getAreaVillageCode());
                    			 if(response.getCustomer().getMailLocation().getAreaVillageName()!=null)
                    				 polAddrsDtls.setAreaVillageName(response.getCustomer().getMailLocation().getAreaVillageName());
                    			 if(response.getCustomer().getMailLocation().getCityDistrictCode()!=null)
                    				 polAddrsDtls.setCityDistrictCode(response.getCustomer().getMailLocation().getCityDistrictCode());
                    			 if(response.getCustomer().getMailLocation().getCityDistrictName()!=null)
                    				 polAddrsDtls.setCityDistrictName(response.getCustomer().getMailLocation().getCityDistrictName());
                    			 if(response.getCustomer().getMailLocation().getCityId()!=null)
                    				 polAddrsDtls.setCityId(response.getCustomer().getMailLocation().getCityId());
                    			 if(response.getCustomer().getMailLocation().getCityName()!=null)
                    				 polAddrsDtls.setCityName(response.getCustomer().getMailLocation().getCityName());
                    			 if(response.getCustomer().getMailLocation().getCountryID()!=null)
                    				 polAddrsDtls.setCountryID(response.getCustomer().getMailLocation().getCountryID());
                    			 if(response.getCustomer().getMailLocation().getCountryName()!=null)
                    				 polAddrsDtls.setCountryName(response.getCustomer().getMailLocation().getCountryName());
                    			 if(response.getCustomer().getMailLocation().getDistrictName()!=null)
                    				 polAddrsDtls.setDistrictName(response.getCustomer().getMailLocation().getDistrictName());
                    			 if(response.getCustomer().getMailLocation().getDivision()!=null)
                    				 polAddrsDtls.setDivision(response.getCustomer().getMailLocation().getDivision());
                    			 if(response.getCustomer().getMailLocation().getDivisionCode()!=null)
                    				 polAddrsDtls.setDivisionCode(response.getCustomer().getMailLocation().getDivisionCode());
                    			 if(response.getCustomer().getMailLocation().getEndDate()!=null)
                    				 polAddrsDtls.setEndDate(response.getCustomer().getMailLocation().getEndDate());
                    			 if(response.getCustomer().getMailLocation().getErrorText()!=null)
                    				 polAddrsDtls.setErrorText(response.getCustomer().getMailLocation().getErrorText());
                    			 if(response.getCustomer().getMailLocation().getID()!=null)
                    				 polAddrsDtls.setId(response.getCustomer().getMailLocation().getID());
                    			 if(response.getCustomer().getMailLocation().getLandmark()!=null)
                    				 polAddrsDtls.setLandMark(response.getCustomer().getMailLocation().getLandmark());
                    			 if(response.getCustomer().getMailLocation().getMediatorName()!=null)
                    				 polAddrsDtls.setMediatorName(response.getCustomer().getMailLocation().getMediatorName());
                    			 if(response.getCustomer().getMailLocation().getName()!=null)
                    				 polAddrsDtls.setName(response.getCustomer().getMailLocation().getName());
                    			 if(response.getCustomer().getMailLocation().getPOBox()!=null)
                    				 polAddrsDtls.setPoBox(response.getCustomer().getMailLocation().getPOBox());
                    			 if(response.getCustomer().getMailLocation().getPinCode()!=null)
                    				 polAddrsDtls.setPincode(response.getCustomer().getMailLocation().getPinCode());
                    			 if(response.getCustomer().getMailLocation().getPinCodeLocality()!=null)
                    				 polAddrsDtls.setPincodeLocality(response.getCustomer().getMailLocation().getPinCodeLocality());
                    			 if(response.getCustomer().getMailLocation().getRegion()!=null)
                    				 polAddrsDtls.setRegion(response.getCustomer().getMailLocation().getRegion());
                    			 if(response.getCustomer().getMailLocation().getStartDate()!=null)
                    				 polAddrsDtls.setStartDate(response.getCustomer().getMailLocation().getStartDate());
                    			 if(response.getCustomer().getMailLocation().getStateCode()!=null)
                    				 polAddrsDtls.setStateCode(response.getCustomer().getMailLocation().getStateCode());
                    			 if(response.getCustomer().getMailLocation().getStateName()!=null)
                    				 polAddrsDtls.setStateName(response.getCustomer().getMailLocation().getStateName());
                    			 if(response.getCustomer().getMailLocation().getUserID()!=null)
                    				 polAddrsDtls.setUserId(response.getCustomer().getMailLocation().getUserID());
                    			 if(response.getCustomer().getMailLocation().getApartmentName()!=null)
                    				 polAddrsDtls.setApartmentName(response.getCustomer().getMailLocation().getApartmentName());
                    			 if(response.getCustomer().getMailLocation().getLocationCode()!=null)
                    				 polAddrsDtls.setLocationCode(response.getCustomer().getMailLocation().getLocationCode());
                    			 if(response.getCustomer().getMailLocation().getStreetName()!=null)
                    				 polAddrsDtls.setStreetName(response.getCustomer().getMailLocation().getStreetName());
                    			 if(response.getCustomer().getMailLocation().getTitleBarName()!=null)
                    				 polAddrsDtls.setTitleBarName(response.getCustomer().getMailLocation().getTitleBarName());
                    			 
                    			 polCustDtls.setLstPolAddrsDtls(polAddrsDtls==null?null:polAddrsDtls);
                    		 }
                    		 
                    		 if(response.getCustomer().getMailLocationCode()!=null)
                    			 polCustDtls.setMailLocationCode(response.getCustomer().getMailLocationCode());
                    		 if(response.getCustomer().getName()!=null)
                    			 polCustDtls.setName(response.getCustomer().getName());
                    		 if(response.getCustomer().getPanNo()!=null)
                    			 polCustDtls.setPanNo(response.getCustomer().getPanNo());
                    		 if(response.getCustomer().getStartDate()!=null)
                    			 polCustDtls.setStartDate(response.getCustomer().getStartDate());
                    		 if(response.getCustomer().getUserID()!=null)
                    			 polCustDtls.setUserId(response.getCustomer().getUserID());
                    		 if(response.getCustomer().getUserRole()!=null)
                    			 polCustDtls.setUserRole(response.getCustomer().getUserRole());
                    		 if(response.getCustomer().getAffiliationFlag()!=null)
                    			 polCustDtls.setAffiliationFlag(response.getCustomer().getAffiliationFlag());
                    		 if(response.getCustomer().getAlternateEmailId()!=null)
                    			 polCustDtls.setAlternateEmailId(response.getCustomer().getAlternateEmailId());
                    		 if(response.getCustomer().getAnnualIncome()!=null)
                    			 polCustDtls.setAnnualIncome(response.getCustomer().getAnnualIncome());
                    		 if(response.getCustomer().getBlacklisted()!=null)
                    			 polCustDtls.setBlacklisted(response.getCustomer().getBlacklisted());
                    		 if(response.getCustomer().getBloodGroup()!=null)
                    			 polCustDtls.setBloodGroup(response.getCustomer().getBloodGroup());
                    		 if(response.getCustomer().getBusinessName()!=null)
                    			 polCustDtls.setBusinessName(response.getCustomer().getBusinessName());
                    		 if(response.getCustomer().getCAP()!=null)
                    			 polCustDtls.setCap(response.getCustomer().getCAP());
                    		 if(response.getCustomer().getChequeAcceptence()!=null)
                    			 polCustDtls.setChequeAcceptence(response.getCustomer().getChequeAcceptence());
                    		 if(response.getCustomer().getChildCustomer()!=null)
                    			 polCustDtls.setChildCustomer(response.getCustomer().getChildCustomer());
                    		 if(response.getCustomer().getContactNo()!=null)
                    			 polCustDtls.setContactNo(response.getCustomer().getContactNo());
                    		 if(response.getCustomer().getContactPerson()!=null)
                    			 polCustDtls.setContactPerson(response.getCustomer().getContactPerson());
                    		 if(response.getCustomer().getCountry()!=null)
                    			 polCustDtls.setCountry(response.getCustomer().getCountry());
                    		 if(response.getCustomer().getCountryName()!=null)
                    			 polCustDtls.setCountryName(response.getCustomer().getCountryName());
                    		 if(response.getCustomer().getCustomerInitials()!=null)
                    			 polCustDtls.setCustomerInitials(response.getCustomer().getCustomerInitials());
                    		 if(response.getCustomer().getCustomerStatus()!=null)
                    			 polCustDtls.setCustomerStatus(response.getCustomer().getCustomerStatus());
                    		 if(response.getCustomer().getCustomerTier()!=null)
                    			 polCustDtls.setCustomerTier(""+response.getCustomer().getCustomerTier());
                    		 if(response.getCustomer().getCustomerTierName()!=null)
                    			 polCustDtls.setCustomerTierName(response.getCustomer().getCustomerTierName());
                    		 if(response.getCustomer().getCustomerType()!=null)
                    			 polCustDtls.setCustomerType(response.getCustomer().getCustomerType());
                    		 if(response.getCustomer().getCustomerUniqueID()!=null)
                    			 polCustDtls.setCustomerUniqueID(response.getCustomer().getCustomerUniqueID());
                    		 if(response.getCustomer().getDBNo()!=null)
                    			 polCustDtls.setDbNo(response.getCustomer().getDBNo());
                    		 if(response.getCustomer().getDeDupID()!=null)
                    			 polCustDtls.setDeDupID(response.getCustomer().getDeDupID());
                    		 if(response.getCustomer().getDesignation()!=null)
                    			 polCustDtls.setDesignation(response.getCustomer().getDesignation());
                    		 if(response.getCustomer().getDoNotCall()!=null)
                    			 polCustDtls.setDoNotCall(response.getCustomer().getDoNotCall());
                    		 if(response.getCustomer().getDoNotDirectory()!=null)
                    			 polCustDtls.setDoNotDirectory(""+response.getCustomer().getDoNotDirectory());
                    		 if(response.getCustomer().getDomainname()!=null)
                    			 polCustDtls.setDomainname(response.getCustomer().getDomainname());
                    		 if(response.getCustomer().getDrivingLicenseno()!=null)
                    			 polCustDtls.setDrivingLicenseno(response.getCustomer().getDrivingLicenseno());
                    		 if(response.getCustomer().getENDTSubType()!=null)
                    			 polCustDtls.setEndTSubType(response.getCustomer().getENDTSubType());
                    		 if(response.getCustomer().getENDTType()!=null)
                    			 polCustDtls.setEndTType(response.getCustomer().getENDTType());
                    		 if(response.getCustomer().getEducationQualification()!=null)
                    			 polCustDtls.setEducationQualification(""+response.getCustomer().getEducationQualification());
                    		 if(response.getCustomer().getFirstName()!=null)
                    			 polCustDtls.setFirstName(response.getCustomer().getFirstName());
                    		 if(response.getCustomer().getIDProof()!=null)
                    			 polCustDtls.setIdProof(""+response.getCustomer().getIDProof());
                    		 if(response.getCustomer().getIDProofDetails()!=null)
                    			 polCustDtls.setIdProofDetails(response.getCustomer().getIDProofDetails());
                    		 if(response.getCustomer().getISUIICEmployee()!=null)
                    			 polCustDtls.setIsUIICEmployee(""+response.getCustomer().getISUIICEmployee());
                    		 if(response.getCustomer().getIndustry()!=null)
                    			 polCustDtls.setIndustry(response.getCustomer().getIndustry());
                    		 if(response.getCustomer().getIndustryOthers()!=null)
                    			 polCustDtls.setIndustryOthers(response.getCustomer().getIndustryOthers());
                    		 if(response.getCustomer().getInterEmpTag()!=null)
                    			 polCustDtls.setInterEmpTag(response.getCustomer().getInterEmpTag());
                    		 if(response.getCustomer().getIsBlacklisted()!=null)	
                    			 polCustDtls.setIsBlacklisted(response.getCustomer().getIsBlacklisted());
                    		 if(response.getCustomer().getLastName()!=null)	
                    			 polCustDtls.setLastName(response.getCustomer().getLastName());
                    		 if(response.getCustomer().getMAP()!=null)	
                    			 polCustDtls.setMap(response.getCustomer().getMAP());
                    		 if(response.getCustomer().getMOP()!=null)
                    			 polCustDtls.setMop(response.getCustomer().getMOP());
                    		 if(response.getCustomer().getMaidenName()!=null)
                    			 polCustDtls.setMaidenName(response.getCustomer().getMaidenName());
                    		 if(response.getCustomer().getMaritalStatus()!=null)
                    			 polCustDtls.setMaritalStatus(response.getCustomer().getMaritalStatus());
                    		 if(response.getCustomer().getMasterPinCode()!=null)
                    			 polCustDtls.setMasterPinCode(response.getCustomer().getMasterPinCode());
                    		 if(response.getCustomer().getMiddleName()!=null)
                    			 polCustDtls.setMiddleName(response.getCustomer().getMiddleName());
                    		 if(response.getCustomer().getMotherName()!=null)
                    			 polCustDtls.setMotherName(response.getCustomer().getMotherName());
                    		 if(response.getCustomer().getNationality()!=null)
                    			 polCustDtls.setNationality(response.getCustomer().getNationality());
                    		 if(response.getCustomer().getOccupation()!=null)
                    			 polCustDtls.setOccupation(""+response.getCustomer().getOccupation());
                    		 if(response.getCustomer().getOfficeCode()!=null)
                    			 polCustDtls.setOfficeCode(response.getCustomer().getOfficeCode());
                    		 if(response.getCustomer().getOfficeExtn()!=null)
                    			 polCustDtls.setOfficeExtn(response.getCustomer().getOfficeExtn());
                    		 if(response.getCustomer().getOfficeName()!=null)
                    			 polCustDtls.setOfficeName(response.getCustomer().getOfficeName());
                    		 if(response.getCustomer().getPCGClient()!=null)
                    			 polCustDtls.setPcgClient(""+response.getCustomer().getPCGClient());
                    		 if(response.getCustomer().getPaidUpCapital()!=null)
                    			 polCustDtls.setPaidUpCapital(response.getCustomer().getPaidUpCapital());
                    		 if(response.getCustomer().getParentCustomerCode()!=null)	 
                    			 polCustDtls.setParentCustomerCode(response.getCustomer().getParentCustomerCode());
                    		 if(response.getCustomer().getParentCustomerName()!=null)
                    			 polCustDtls.setParentCustomerName(response.getCustomer().getParentCustomerName());
                    		 if(response.getCustomer().getPassportNo()!=null)
                    			 polCustDtls.setPassportNo(response.getCustomer().getPassportNo());
                    		 if(response.getCustomer().getPaymentMode()!=null)
                    			 polCustDtls.setPaymentMode(response.getCustomer().getPaymentMode());
                    		 if(response.getCustomer().getPermanentLocationCode()!=null)
                    			 polCustDtls.setPermanentLocationCode(response.getCustomer().getPermanentLocationCode());
                    		 if(response.getCustomer().getPincodeLocality()!=null)
                    			 polCustDtls.setPincodeLocality(response.getCustomer().getPincodeLocality());
                    		 if(response.getCustomer().getPriorityClient()!=null)
                    			 polCustDtls.setPriorityClient(""+response.getCustomer().getPriorityClient());
                    		 if(response.getCustomer().getProductCode()!=null)
                    			 polCustDtls.setProductCode(response.getCustomer().getProductCode());
                    		 if(response.getCustomer().getProposalNo()!=null)
                    			 polCustDtls.setProposalNo(response.getCustomer().getProposalNo());
                    		 if(response.getCustomer().getRegistrationNumber()!=null)
                    			 polCustDtls.setRegistrationNumber(response.getCustomer().getRegistrationNumber());
                    		 if(response.getCustomer().getRegistrationOffice()!=null)
                    			 polCustDtls.setRegistrationOffice(response.getCustomer().getRegistrationOffice());
                    		 if(response.getCustomer().getRemarks()!=null)
                    			 polCustDtls.setRemarks(response.getCustomer().getRemarks());
                    		 if(response.getCustomer().getRole()!=null)
                    			 polCustDtls.setRole(response.getCustomer().getRole());
                    		 if(response.getCustomer().getSalutation()!=null)
                    			 polCustDtls.setSalutation(response.getCustomer().getSalutation());
                    		 if(response.getCustomer().getSalutationOthers()!=null)
                    			 polCustDtls.setSalutationOthers(response.getCustomer().getSalutationOthers());
                    		 if(response.getCustomer().getServiceTaxRegNo()!=null)
                    			 polCustDtls.setServiceTaxRegNo(response.getCustomer().getServiceTaxRegNo());
                    		 if(response.getCustomer().getServiceTaxRegNo()!=null)
                    			 polCustDtls.setServiceTaxRegNo(response.getCustomer().getServiceTaxRegNo());
                    		 if(response.getCustomer().getTanNo()!=null)
                    			 polCustDtls.setTanNo(response.getCustomer().getTanNo());
                    		 if(response.getCustomer().getTypeOfCompany()!=null)
                    			 polCustDtls.setTypeOfCompany(response.getCustomer().getTypeOfCompany());
                    		 if(response.getCustomer().getUIICEmployeeNO()!=null)
                    			 polCustDtls.setUiicEmployeeNO(response.getCustomer().getUIICEmployeeNO());
                    		 
                    		 propRes.setLstPolCustDetls(polCustDtls==null?null:polCustDtls); 
                    	 }
                    	 
                    	 if(response.getCustomerCode()!=null)
                    		 propRes.setCustomerCode(response.getCustomerCode());
                    	 if(response.getCustomerName()!=null)
                    		 propRes.setCustomerName(response.getCustomerName());
                    	 if(response.getDeclinedStatus()!=null)
                    		 propRes.setDeclinedStatus(response.getDeclinedStatus());
                    	 if(response.getDepartmentCode()!=null)
                    		 propRes.setDepartmentCode(response.getDepartmentCode());
                    	 if(response.getEngineNo()!=null)
                    		 propRes.setEngineNo(response.getEngineNo());
                    	 if(response.getInsuredName()!=null)
                    		 propRes.setInsuredName(response.getInsuredName());
                    	 if(response.getLOBName()!=null)
                    		 propRes.setLobName(response.getLOBName());
                    	 if(response.getLastPaymentDate()!=null)
                    		 propRes.setLastPaymentDate(response.getLastPaymentDate());
                    	 if(response.getManualCoverNoteNo()!=null)
                    		 propRes.setManualCoverNoteNo(response.getManualCoverNoteNo());
                    	 if(response.getMigratedPolicyNo()!=null)
                    		 propRes.setMigratedPolicyNo(response.getMigratedPolicyNo());
                    	 if(response.getModeOfOperation()!=null)
                    		 propRes.setModeOfOperation(response.getModeOfOperation());
                    	 if(response.getNetPremium()!=null)
                    		 propRes.setNetPremium(response.getNetPremium());
                    	 if(response.getOfficeCode()!=null)
                    		 propRes.setOfficeCode(response.getOfficeCode());
                    	 if(response.getOpenCovernote()!=null)
                    		 propRes.setOpenCovernote(response.getOpenCovernote());
                    	 if(response.getOrigin()!=null)
                    		 propRes.setOrigin(response.getOrigin());
                    	 if(response.getPaymentDate()!=null)
                    		 propRes.setPaymentDate(response.getPaymentDate());
                    	 if(response.getPaymentGatewayTransactionDate()!=null)
                    		 propRes.setPaymentGatewayTransactionDate(response.getPaymentGatewayTransactionDate());
                    	 if(response.getPaymentGatewayTransactionId()!=null)
                    		 propRes.setPaymentGatewayTransactionId(response.getPaymentGatewayTransactionId());
                    	 if(response.getPaymentId()!=null)
                    		 propRes.setPaymentId(response.getPaymentId());
                    	 if(response.getPolicyEndDate()!=null)
                    		 propRes.setPolicyEndDate(response.getPolicyEndDate());
                    	 if(response.getPolicyNo()!=null)
                    		 propRes.setPolicyNo(response.getPolicyNo());
                    	 if(response.getPolicyStartDate()!=null)
                    		 propRes.setPolicyStartDate(response.getPolicyStartDate());
                    	 if(response.getPolicyType()!=null)
                    		 propRes.setPolicyType(response.getPolicyType());
                    	 if(response.getProductCode()!=null)
                    		 propRes.setProductCode(response.getProductCode());
                    	 if(response.getProductName()!=null)
                    		 propRes.setProductName(response.getProductName());
                    	 if(response.getProposalDate()!=null)
                    		 propRes.setProposalDate(response.getProposalDate());
                    	 if(response.getProposalNo()!=null)
                    		 propRes.setProposalNo(response.getProposalNo());
                    	 if(response.getQCStatus()!=null)
                    		 propRes.setQcStatus(response.getQCStatus());
                    	 if(response.getReceiptDate()!=null)
                    		 propRes.setReceiptDate(response.getReceiptDate());
                    	 if(response.getReceiptMode()!=null)
                    		 propRes.setReceiptMode(response.getReceiptMode());
                    	 if(response.getReceiptNo()!=null)
                    		 propRes.setReceiptNo(response.getReceiptNo());
                    	 if(response.getRenewalDate()!=null)
                    		 propRes.setRenewalDate(response.getRenewalDate());
                    	 if(response.getRenewalStatus()!=null)
                    		 propRes.setRenewalStatus(response.getRenewalStatus());
                    	 if(response.getRequestStatus()!=null)
                    		 propRes.setRequestStatus(response.getRequestStatus());
                    	 if(response.getSerialNo()!=null)
                    		 propRes.setSerialNo(response.getSerialNo());
                    	 if(response.getServiceTax()!=null)
                    		 propRes.setServiceTax(response.getServiceTax());
                    	 if(response.getStatus()!=null)
                    		 propRes.setStatus(response.getStatus());
                    	 if(response.getStatusCode()!=null)
                    		 propRes.setStatusCode(response.getStatusCode());
                    	 if(response.getSumInsured()!=null)
                    		 propRes.setSumInsured(response.getSumInsured());
                    	 if(response.getTotalPremium()!=null)
                    		 propRes.setTotalPremium(response.getTotalPremium());
                    	 if(response.getTransactionType()!=null)
                    		 propRes.setTransactionType(response.getTransactionType());
                    	 if(response.getVehicleInspectionStatus()!=null)
                    		 propRes.setVehicleInspectionStatus(response.getVehicleInspectionStatus());
                    	 if(response.getVehicleManufacturer()!=null)
                    		 propRes.setVehicleManufacturer(response.getVehicleManufacturer());
                    	 if(response.getVehicleModel()!=null)
                    		 propRes.setVehicleModel(response.getVehicleModel());
                    	 if(response.getVehicleRegistrationAddress()!=null)
                    		 propRes.setVehicleRegistrationAddress(response.getVehicleRegistrationAddress());
                    	 if(response.getVehicleRegistrationNo()!=null)
                    		 propRes.setVehicleRegistrationNo(response.getVehicleRegistrationNo());
                    	 if(response.getWorkflowID()!=null)
                    		 propRes.setWorkflowID(response.getWorkflowID());
                    	 
                    	propRes.setResultCode("1");
     					List<ResponseError> errorList=new ArrayList<ResponseError>();
     					ResponseError errorRes=new ResponseError();
     					errorRes.setErrorCode("NOERR");
     					errorRes.setErrorMMessag("NO ERROR");
     					errorList.add(errorRes);
     					propRes.setResErr(errorList);
     					
     					
     					//if(logger.isDebugEnabled())logger.debug("getPolicyDetailsByPolicyNo() :: maped ProductPropRes JSONObj :: \n " + objMapper.writeValueAsString(propRes));
         				
         				return propRes;
                    		 
					 }
                     else
                     {
                    	 	propRes.setResultCode("0");
	    					List<ResponseError> errorList=new ArrayList<ResponseError>();
	    					ResponseError errorRes=new ResponseError();
	    					errorRes.setErrorCode("ERR");
	    					errorRes.setErrorMMessag("Policy Details Not Recieved From Service...!!");
	    					errorList.add(errorRes);
	    					propRes.setResErr(errorList);
	    					
	    					return propRes;
                     }
                     
               }catch(MalformedURLException mex)
               {
                     //logger.info("TransactionID:"+transId+" :: Inside CommonServiceImpl :: getPolicyDetailsByPolicyNo() method : MalformedURLException :: "+mex);
                     logger.error("TransactionID:"+transId+" :: Inside CommonServiceImpl :: getPolicyDetailsByPolicyNo() method : MalformedURLException :: "+mex.getStackTrace());
                     propRes.setResultCode("0");
                     List<ResponseError> errorList=new ArrayList<ResponseError>();
                     ResponseError errorRes=new ResponseError();
                     errorRes.setErrorCode("ERR00");
                     errorRes.setErrorMMessag("System Failed Due To URL Issue... !!!"+".Transaction ID :: "+transId);
                     errorList.add(errorRes);
                     propRes.setResErr(errorList);
               }
               catch(SocketTimeoutException stex)
               {
                     //logger.info("TransactionID:"+transId+" :: Inside CommonServiceImpl :: getPolicyDetailsByPolicyNo() method : SocketTimeoutException :: "+stex);
                     logger.error("TransactionID:"+transId+" :: Inside CommonServiceImpl :: getPolicyDetailsByPolicyNo() method : SocketTimeoutException :: "+stex.getStackTrace());
                     propRes.setResultCode("0");
                     List<ResponseError> errorList=new ArrayList<ResponseError>();
                     ResponseError errorRes=new ResponseError();
                     errorRes.setErrorCode("ERR00");
                     errorRes.setErrorMMessag("Read Time Out Issue... !!!"+".Transaction ID :: "+transId);
                     errorList.add(errorRes);
                     propRes.setResErr(errorList);
               }
               catch(Exception ex)
               {
                     //logger.info("TransactionID:"+transId+" :: Inside CommonServiceImpl :: getPolicyDetailsByPolicyNo() method ::",ex);
                     logger.error("TransactionID:"+transId+" :: Inside CommonServiceImpl :: getPolicyDetailsByPolicyNo() method ::",ex);
                     propRes.setResultCode("0");
                     List<ResponseError> errorList=new ArrayList<ResponseError>();
                     ResponseError errorRes=new ResponseError();
                     errorRes.setErrorCode("ERR01");
                     errorRes.setErrorMMessag("System Failed to call service... !!!"+".Transaction ID :: "+transId);
                     errorList.add(errorRes);
                     propRes.setResErr(errorList);
                     
               }
 
        }catch(Exception ex)
        {
               //logger.info("TransactionID:"+transId+" :: Inside MotorServiceImpl :: GetPolicyDetailByPolicyNoPrvtCar() method ::",ex);           
               logger.error("TransactionID:"+transId+" :: Inside MotorServiceImpl :: GetPolicyDetailByPolicyNoPrvtCar() method ::",ex);
               propRes.setResultCode("0");
               List<ResponseError> errorList=new ArrayList<ResponseError>();
               ResponseError errorRes=new ResponseError();
               errorRes.setErrorCode("ERR02");
               errorRes.setErrorMMessag("System Failed To Recieve Response From Service !!!"+".Transaction ID :: "+transId);
               errorList.add(errorRes);
               propRes.setResErr(errorList);
                            
        }
        logger.info("TransactionID:"+transId+" :: Inside CommonServiceImpl :: getPolicyDetailsByPolicyNo() method :: Execution Completed");
        
        return propRes;
	}
	
	public byte[] printProposal(PrintProposalReq printProposalReq,HttpServletResponse response) throws Exception{
		
		String wsdlUrl=null;
		String strFileName=null;
		byte[] propDataByteArr = null;
		BufferedOutputStream bos=null;
		try{
			logger.info("Inside TagicCommonServiceImpl :: printProposal() method :: Entered ::");
			
			wsdlUrl = getWSDLURL(CommonConstants.PRINT_PROP_POL_DOCUMENT_SERVICE);
			URL serviceUrl=new URL(wsdlUrl);
			
			final QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/GetDocumentForPortalService/", "GetDocumentForPortalService");
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service ss = new com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service(serviceUrl, SERVICE_NAME);
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService port = ss.getSOAPOverHTTP();
			
			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(port);
			
			String _getProposalFormForPortal_source = smc_source;
			String _getProposalFormForPortal_medium = smc_medium;
			String _getProposalFormForPortal_campaign = smc_campaign;
			String _getProposalFormForPortal_strLVAuthToken = printProposalReq.getAuthToken();
			
			com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult _getProposalFormForPortal_objServiceResultVal = null;
			_getProposalFormForPortal_objServiceResultVal = new com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult();
			com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData userData = new com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData();
			
			
			/*if (printProposalReq.getAuthKey() != null && !printProposalReq.getAuthKey().equalsIgnoreCase("")) 
				userData.setAuthenticateKey(printProposalReq.getAuthKey());*/
	
			if(printProposalReq.getCustomerID() != null && !printProposalReq.getCustomerID().equalsIgnoreCase("")) 
				userData.setCustomerId(printProposalReq.getCustomerID());
			
			if(printProposalReq.getProductCode() != null && !printProposalReq.getProductCode().equalsIgnoreCase("")) 
				userData.setProductCode(printProposalReq.getProductCode());
			
			if(printProposalReq.getProposalDate() != null && !printProposalReq.getProposalDate().equalsIgnoreCase("")) 
				userData.setProposalDate(printProposalReq.getProposalDate());
			
			if(printProposalReq.getProposalNumber() != null && !printProposalReq.getProposalNumber().equalsIgnoreCase("")) 
				userData.setProposalNumber(printProposalReq.getProposalNumber());
			
			userData.setReportAsPDF(true);
			userData.setReportTypeCode("4");
			if(printProposalReq.getUserID()!=null && !printProposalReq.getUserID().equals(""))
			userData.setUserId(printProposalReq.getUserID());
			else
			userData.setUserId("gcwinuat05");
			
			userData.setUserRole("ADMIN");
			if(_getProposalFormForPortal_strLVAuthToken==null || _getProposalFormForPortal_strLVAuthToken.equalsIgnoreCase(CommonConstants.BLANK_STRING)){
			if(printProposalReq.getPassword()!=null && !printProposalReq.getPassword().equalsIgnoreCase(""))
				userData.setPassword(printProposalReq.getPassword());
			}
			_getProposalFormForPortal_objServiceResultVal.setUserData(userData);
			Holder<com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult> _getProposalFormForPortal_objServiceResult = new Holder(_getProposalFormForPortal_objServiceResultVal);
			    
			Holder<byte[]> _getProposalFormForPortal_getProposalFormForPortalResult = new Holder();
			port.getProposalFormForPortal(_getProposalFormForPortal_source, _getProposalFormForPortal_medium, _getProposalFormForPortal_campaign, _getProposalFormForPortal_strLVAuthToken, _getProposalFormForPortal_objServiceResult, _getProposalFormForPortal_getProposalFormForPortalResult);
			
			propDataByteArr = _getProposalFormForPortal_getProposalFormForPortalResult.value;
			
			/*File file=new File("D:/TAGIC/printProposal18102016.pdf");
			FileInputStream fis=new FileInputStream(file);
			byte[] propDataByteArr=new byte[(int)file.length()];
			fis.read(propDataByteArr);*/
			
			if(propDataByteArr!=null){
				SimpleDateFormat sdf=new SimpleDateFormat("ddMMYYYYhhmmss", Locale.US);
				strFileName=printProposalReq.getProposalNumber().concat("_").concat(sdf.format(new Date())).concat(".pdf");
				response.setContentType("application/pdf");
				response.setContentLength((int)propDataByteArr.length);
				response.addHeader("Content-Disposition", "attachment;filename="+strFileName);
				
				ServletOutputStream servletOutputStream=response.getOutputStream();
				
				bos=new BufferedOutputStream(servletOutputStream,propDataByteArr.length);
				bos.write(propDataByteArr);
				//bos.flush();
				//bos.close();
				//servletOutputStream.write(propDataByteArr);
			}
			
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: printProposal() method ::",ex);
		}finally{
			if(bos!=null){
				bos.flush();
				bos.close();
			}
		}
		return propDataByteArr;
	}
	
	
public byte[] printPolicy(PrintProposalReq printProposalReq,HttpServletResponse response) throws Exception{
		
		String wsdlUrl=null;
		String strFileName=null;
		byte[] propDataByteArr = null;
		BufferedOutputStream bos=null;
		try{
			logger.info("Inside TagicCommonServiceImpl :: printPolicy() method :: Entered ::");
			
			wsdlUrl = getWSDLURL(CommonConstants.PRINT_PROP_POL_DOCUMENT_SERVICE);
			URL serviceUrl=new URL(wsdlUrl);
			
			final QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/GetDocumentForPortalService/", "GetDocumentForPortalService");
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service ss = new com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service(serviceUrl, SERVICE_NAME);
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService port = ss.getSOAPOverHTTP();
			
			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(port);
			
			String _getProposalFormForPortal_source = smc_source;
			String _getProposalFormForPortal_medium = smc_medium;
			String _getProposalFormForPortal_campaign = smc_campaign;
			String _getProposalFormForPortal_strLVAuthToken = printProposalReq.getAuthToken();
			
			com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult _getProposalFormForPortal_objServiceResultVal = null;
			_getProposalFormForPortal_objServiceResultVal = new com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult();
			com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData userData = new com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData();
			
			
			/*if (printProposalReq.getAuthKey() != null && !printProposalReq.getAuthKey().equalsIgnoreCase("")) 
				userData.setAuthenticateKey(printProposalReq.getAuthKey());*/
	
			if(printProposalReq.getCustomerID() != null && !printProposalReq.getCustomerID().equalsIgnoreCase("")) 
				userData.setCustomerId(printProposalReq.getCustomerID());
			
			if(printProposalReq.getProductCode() != null && !printProposalReq.getProductCode().equalsIgnoreCase("")) 
				userData.setProductCode(printProposalReq.getProductCode());
			
			if(printProposalReq.getProposalDate() != null && !printProposalReq.getProposalDate().equalsIgnoreCase("")) 
				userData.setProposalDate(printProposalReq.getProposalDate());
			
			if(printProposalReq.getProposalNumber() != null && !printProposalReq.getProposalNumber().equalsIgnoreCase("")) 
				userData.setProposalNumber(printProposalReq.getProposalNumber());
			
			//userData.setReportAsPDF(true);
			//userData.setReportTypeCode("122");
			userData.setReportTypeCode("4");
			if(printProposalReq.getUserID()!=null && !printProposalReq.getUserID().equals(""))
			userData.setUserId(printProposalReq.getUserID());
			else
			userData.setUserId("gcwinuat05");
			
			userData.setUserRole("ADMIN");
			
			if(_getProposalFormForPortal_strLVAuthToken==null || _getProposalFormForPortal_strLVAuthToken.equalsIgnoreCase(CommonConstants.BLANK_STRING)){
			if(printProposalReq.getPassword()!=null && !printProposalReq.getPassword().equalsIgnoreCase(""))
				userData.setPassword(printProposalReq.getPassword());
			}
			_getProposalFormForPortal_objServiceResultVal.setUserData(userData);
			Holder<com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult> _getProposalFormForPortal_objServiceResult = new Holder(_getProposalFormForPortal_objServiceResultVal);
			    
			Holder<byte[]> _getProposalFormForPortal_getProposalFormForPortalResult = new Holder();
			port.getPolicyDocumentForPortal(_getProposalFormForPortal_source, _getProposalFormForPortal_medium, _getProposalFormForPortal_campaign, _getProposalFormForPortal_strLVAuthToken, _getProposalFormForPortal_objServiceResult, _getProposalFormForPortal_getProposalFormForPortalResult);
			
			propDataByteArr = _getProposalFormForPortal_getProposalFormForPortalResult.value;
			
			/*File file=new File("D:/TAGIC/printProposal18102016.pdf");
			FileInputStream fis=new FileInputStream(file);
			byte[] propDataByteArr=new byte[(int)file.length()];
			fis.read(propDataByteArr);*/
			
			if(propDataByteArr!=null){
				SimpleDateFormat sdf=new SimpleDateFormat("ddMMYYYYhhmmss", Locale.US);
				strFileName=printProposalReq.getProposalNumber().concat("_").concat(sdf.format(new Date())).concat(".pdf");
				response.setContentType("application/pdf");
				response.setContentLength((int)propDataByteArr.length);
				response.addHeader("Content-Disposition", "attachment;filename="+strFileName);
				
				ServletOutputStream servletOutputStream=response.getOutputStream();
				
				bos=new BufferedOutputStream(servletOutputStream,propDataByteArr.length);
				bos.write(propDataByteArr);
				//bos.flush();
				//bos.close();
				//servletOutputStream.write(propDataByteArr);
			}
			logger.info("Inside TagicCommonServiceImpl :: printPolicy() method :: Exit ::");
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: printPolicy() method ::",ex);
		}finally{
			if(bos!=null){
				bos.flush();
				bos.close();
			}
		}
		return propDataByteArr;
	}
	
	
	
	private String getWSDLURL(String param)
	{
		String wsdlUrl=null;
		try
		{
			wsdlUrl = dbService.getWSDLURL(param,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			return wsdlUrl;
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorServiceImpl :: getWSDLURL() method ::",ae);
		}
		return wsdlUrl;
	}
	
	
public byte[] printWorksheet(PrintProposalReq printProposalReq,HttpServletResponse response) throws Exception{
		
		String wsdlUrl=null;
		String strFileName=null;
		byte[] propDataByteArr = null;
		BufferedOutputStream bos=null;
		try{
			logger.info("Inside TagicCommonServiceImpl :: printWorksheet() method :: Entered ::");
			
			wsdlUrl = getWSDLURL(CommonConstants.PRINT_PROP_POL_DOCUMENT_SERVICE);
			URL serviceUrl=new URL(wsdlUrl);
			ObjectMapper objMap = new ObjectMapper();
			
			//if(logger.isDebugEnabled())logger.debug("Inside TagicCommonServiceImpl :: printWorksheet() method :: Request Received JSON :: "+objMap.writeValueAsString(printProposalReq));
			
			final QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/GetDocumentForPortalService/", "GetDocumentForPortalService");
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service ss = new com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service(serviceUrl, SERVICE_NAME);
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService port = ss.getSOAPOverHTTP();
			
			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(port);
			
			String _generateWorksheet_source = smc_source;
			String _generateWorksheet_medium = smc_medium;
			String _generateWorksheet_campaign = smc_campaign;
			String _generateWorksheet_strLVAuthToken = printProposalReq.getAuthToken();
			
			/*com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult _getProposalFormForPortal_objServiceResultVal = null;
			_getProposalFormForPortal_objServiceResultVal = new com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult();
			com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData userData = new com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData();*/
			
			com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult _generateWorksheet_objServiceResultVal = null;
			_generateWorksheet_objServiceResultVal=new com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult();
			com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData userData = new com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData();
			
	        
			
			
			/*if (printProposalReq.getAuthKey() != null && !printProposalReq.getAuthKey().equalsIgnoreCase("")) 
				userData.setAuthenticateKey(printProposalReq.getAuthKey());*/
	//Commented as ESB team reverted not to send the following values.
			/*if(printProposalReq.getCustomerID() != null && !printProposalReq.getCustomerID().equalsIgnoreCase("")) 
				userData.setCustomerId(printProposalReq.getCustomerID());
			
			if(printProposalReq.getProductCode() != null && !printProposalReq.getProductCode().equalsIgnoreCase("")) 
				userData.setProductCode(printProposalReq.getProductCode());
			
			if(printProposalReq.getProposalDate() != null && !printProposalReq.getProposalDate().equalsIgnoreCase("")) 
				userData.setProposalDate(printProposalReq.getProposalDate());*/
			
			if(printProposalReq.getProposalNumber() != null && !printProposalReq.getProposalNumber().equalsIgnoreCase("")) 
				userData.setProposalNumber(printProposalReq.getProposalNumber());
			
			//userData.setReportAsPDF(true);
			//userData.setReportTypeCode("122");
			//userData.setReportTypeCode("4");
//			if(printProposalReq.getUserID()!=null && !printProposalReq.getUserID().equals(""))
//			userData.setUserId(printProposalReq.getUserID());
//			else
			
			userData.setAuthenticateKey(CommonConstants.BLANK_STRING);
			if(printProposalReq.getUserID()!=null && !printProposalReq.getUserID().equalsIgnoreCase(""))
				userData.setUserId(printProposalReq.getUserID());
			else
			userData.setUserId("gcwinuat05");
			
			if(_generateWorksheet_strLVAuthToken==null || _generateWorksheet_strLVAuthToken.equalsIgnoreCase(CommonConstants.BLANK_STRING)){
			if(printProposalReq.getPassword()!=null && !printProposalReq.getPassword().equalsIgnoreCase(""))
				userData.setPassword(printProposalReq.getPassword());
			else
			userData.setPassword("cmc123");
			}
			userData.setUserRole("ADMIN");
			
			    
			_generateWorksheet_objServiceResultVal.setUserData(userData);
			
			javax.xml.ws.Holder<com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult> _generateWorksheet_objServiceResult = new javax.xml.ws.Holder<com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult>(_generateWorksheet_objServiceResultVal);
	        javax.xml.ws.Holder<byte[]> _generateWorksheet_generateWorksheetResult = new javax.xml.ws.Holder<byte[]>();
	        port.generateWorksheet(_generateWorksheet_source, _generateWorksheet_medium, _generateWorksheet_campaign, _generateWorksheet_strLVAuthToken, _generateWorksheet_objServiceResult, _generateWorksheet_generateWorksheetResult);
			
			propDataByteArr = _generateWorksheet_generateWorksheetResult.value;
			//if(logger.isDebugEnabled())logger.debug("TagicCommonServiceImpl :: printWorksheet :: Byte stream returned ::"+new String(propDataByteArr));
			/*File file=new File("D:/TAGIC/printProposal18102016.pdf");
			FileInputStream fis=new FileInputStream(file);
			byte[] propDataByteArr=new byte[(int)file.length()];
			fis.read(propDataByteArr);*/
			
			if(propDataByteArr!=null){
				SimpleDateFormat sdf=new SimpleDateFormat("ddMMYYYYhhmmss", Locale.US);
				strFileName=printProposalReq.getProposalNumber().concat("_").concat(sdf.format(new Date())).concat(".pdf");
				response.setContentType("application/pdf");
				response.setContentLength((int)propDataByteArr.length);
				response.addHeader("Content-Disposition", "attachment;filename="+strFileName);
				
				ServletOutputStream servletOutputStream=response.getOutputStream();
				
				bos=new BufferedOutputStream(servletOutputStream,propDataByteArr.length);
				bos.write(propDataByteArr);
				//bos.flush();
				//bos.close();
				//servletOutputStream.write(propDataByteArr);
			}
			logger.info("Inside TagicCommonServiceImpl :: printWorksheet() method :: Exit ::");
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: printWorksheet() method ::",ex);
		}finally{
			if(bos!=null){
				bos.flush();
				bos.close();
			}
		}
		return propDataByteArr;
	}

/**
 * QuotationSearch service.Currently implemented for Motor quote only
 */
public QuotationListResponse searchQuote(QuotationSearchRequest quoteSearchReq) throws Exception{
	
	QuotationListResponse quoteList=new QuotationListResponse();
	//String wsdlUrl=null;
	String strMethodName="searchQuote";
	try{ //Start:28/11/2016:Commented below quotation search service as new quotation search service to be invoked
		/*
		wsdlUrl = getWSDLURL(CommonConstants.MOTOR_QUOTE_SEARCH_SERVICE);
		URL serviceUrl=new URL(wsdlUrl);
		QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/SearchStubService/QuotaionSearchService", "SearchStubService");
		
		SearchStubService_Service ss = new SearchStubService_Service(serviceUrl, SERVICE_NAME);
        SearchStubService port = ss.getSOAPOverHTTP(); 
        ServiceUtility serviceUtil=new ServiceUtility();
        serviceUtil.addClientInterceptor(port);
        
        com.unotechsoft.stub.motorservice.quotesearch.GetQuotationSearch _getQuotationSearch_parameters = new GetQuotationSearch();
        if(quoteSearchReq!=null){
        
        	SearchQuotationRequest inputReq=new SearchQuotationRequest();
        	inputReq.setProductCd(quoteSearchReq.getProductCode());
        	inputReq.setDeptcd("31"); // Hard coded to 31.
        	inputReq.setQuoteNo(quoteSearchReq.getQuoteNo());
        	inputReq.setCustId(quoteSearchReq.getCustomerId());
        	inputReq.setProposalNo("");
        	inputReq.setQuoteDate(quoteSearchReq.getDateFrom());
        	inputReq.setVersionNo("");
        	inputReq.setCustName("");
        	String jaxbXML=JAXBXMLHandler.marshal(inputReq);
        	QuotationRequest quoteReq=new QuotationRequest();
        	quoteReq.setAuthenticationToken(quoteSearchReq.getAuthToken());
        	quoteReq.setCampaign(smc_campaign);
        	quoteReq.setMedium(smc_medium);
        	quoteReq.setSource(smc_source);
        	quoteReq.setIsBankDataRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
        	quoteReq.setIsCutomerAddressRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
        	quoteReq.setIsFinanciarDataRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
        	quoteReq.setIsManufacturerMappingRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
        	quoteReq.setIsModelMappingRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
        	quoteReq.setIsRTOMappingRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
        	
        	quoteReq.setInputXML(jaxbXML);
        	quoteReq.setModeOfOperation(CommonConstants.NEWPOLICY_MOD_OPR);
        	quoteReq.setUserRole("ADMIN"); // Hard coded to ADMIN
        	
        	_getQuotationSearch_parameters.setCreatePolicyRequest(quoteReq);
        	
        com.unotechsoft.stub.motorservice.quotesearch.GetLOVQuotationResponse2 _getQuotationSearch__return = port.getQuotationSearch(_getQuotationSearch_parameters);
        
        if(_getQuotationSearch__return!=null && _getQuotationSearch__return.getGetLOVQuotationResult()!=null){
        	if(_getQuotationSearch__return.getGetLOVQuotationResult().getQuotationLOVList()!=null && _getQuotationSearch__return.getGetLOVQuotationResult().getQuotationLOVList().getQuotationLOVInfo()!=null){
        		List<QuotationLOVInfo> quoteInfoList=_getQuotationSearch__return.getGetLOVQuotationResult().getQuotationLOVList().getQuotationLOVInfo();
        	quoteList=new QuotationListResponse();
        	List<QuotationSearchResponse> quoteResponse=new ArrayList<QuotationSearchResponse>();
        	for(int i=0;i<quoteInfoList.size();i++){
        		QuotationLOVInfo quoteInfo= (QuotationLOVInfo) quoteInfoList.get(i);
        		if(quoteInfo!=null){
        			QuotationSearchResponse quote=new QuotationSearchResponse();
        			quote.setQuoteNo(quoteInfo.getQuotationNo());
        			quote.setCustomerName(quoteInfo.getCustomerName());
        			quote.setCustomerId(quoteInfo.getCustomerId());
        			quote.setCreationDate(quoteInfo.getPolicyStartDate());
        			quote.setProposalNo(quoteInfo.getProposalNo());
        			quoteResponse.add(quote);
        		}
        	}
        	quoteList.setQuoteList(quoteResponse);
        	quoteList.setResultCode("1");
        	}else{
        		quoteList.setResultCode("0");
        	}
        }
        
        }
		
	*/
		//End:28/11/2016:Commented below quotation search service as new quotation search service to be invoked
		
		logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
		String serviceUrl=getWSDLURL(CommonConstants.GENERIC_SERVICE);
		URL wsdlUrl=new URL(serviceUrl);
		GenericIntegration_Service genericService=new GenericIntegration_Service(wsdlUrl);
		GenericIntegration port=genericService.getSOAPOverHTTP();
		ServiceUtility serviceUtil=new ServiceUtility();
		serviceUtil.addClientInterceptor(port);
		
		String _quotionSearchForPortalGetObjectData_source = smc_source;
        String _quotionSearchForPortalGetObjectData_medium = smc_medium;
        String _quotionSearchForPortalGetObjectData_campaingn = smc_campaign;
        String _quotionSearchForPortalGetObjectData_strLVTokenID = "";
        String _quotionSearchForPortalGetObjectData_strQuotationNo = "";
        String _quotionSearchForPortalGetObjectData_strLOB = "";
        String _quotionSearchForPortalGetObjectData_strProductCode = "";
        String _quotionSearchForPortalGetObjectData_strVehRegdNo = "";
        String _quotionSearchForPortalGetObjectData_strCustomerID = "";
        String _quotionSearchForPortalGetObjectData_strDOB = "";
        String _quotionSearchForPortalGetObjectData_strMobileNo = "";
        String _quotionSearchForPortalGetObjectData_strCreatedDate = "";
        String _quotionSearchForPortalGetObjectData_strCreatedToDate = "";
        String _quotionSearchForPortalGetObjectData_strProducerCode = "";
        String _quotionSearchForPortalGetObjectData_strUserId = "";
        String _quotionSearchForPortalGetObjectData_strFlag = "";
        
        if(quoteSearchReq.getAuthToken()!=null && !quoteSearchReq.getAuthToken().equalsIgnoreCase("-1"))
        	_quotionSearchForPortalGetObjectData_strLVTokenID=quoteSearchReq.getAuthToken();
        
        if(quoteSearchReq.getQuoteNo()!=null && !quoteSearchReq.getQuoteNo().equalsIgnoreCase(CommonConstants.BLANK_STRING))
        	_quotionSearchForPortalGetObjectData_strQuotationNo=quoteSearchReq.getQuoteNo();
        
        if(quoteSearchReq.getProductCode()!=null && !quoteSearchReq.getProductCode().equalsIgnoreCase(CommonConstants.BLANK_STRING))
        	_quotionSearchForPortalGetObjectData_strProductCode=quoteSearchReq.getProductCode();
        
        if(quoteSearchReq.getProducerCode()!=null && !quoteSearchReq.getProducerCode().equalsIgnoreCase(CommonConstants.BLANK_STRING))
        	_quotionSearchForPortalGetObjectData_strProducerCode=quoteSearchReq.getProducerCode(); 
//        	_quotionSearchForPortalGetObjectData_strProducerCode="3051994444";	////Adding For TIme Being
        
        if(quoteSearchReq.getVehicleRegNo()!=null && !quoteSearchReq.getVehicleRegNo().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
        	String upperCase = quoteSearchReq.getVehicleRegNo().toUpperCase();
        	quoteSearchReq.setVehicleRegNo(upperCase);
        	_quotionSearchForPortalGetObjectData_strVehRegdNo=quoteSearchReq.getVehicleRegNo();	
        }        
        
        if(quoteSearchReq.getDateOfBirth()!=null && !quoteSearchReq.getDateOfBirth().equalsIgnoreCase(CommonConstants.BLANK_STRING))
        	_quotionSearchForPortalGetObjectData_strDOB=quoteSearchReq.getDateOfBirth();
        
        if(quoteSearchReq.getMobileNo()!=null && !quoteSearchReq.getMobileNo().equalsIgnoreCase(CommonConstants.BLANK_STRING))
        	_quotionSearchForPortalGetObjectData_strMobileNo=quoteSearchReq.getMobileNo();
        
        if(quoteSearchReq.getCustomerId()!=null && !quoteSearchReq.getCustomerId().equalsIgnoreCase(CommonConstants.BLANK_STRING))
        	_quotionSearchForPortalGetObjectData_strCustomerID=quoteSearchReq.getCustomerId();
        
        if(quoteSearchReq.getDateFrom()!=null && !quoteSearchReq.getDateFrom().equalsIgnoreCase(CommonConstants.BLANK_STRING))
        	_quotionSearchForPortalGetObjectData_strCreatedDate=quoteSearchReq.getDateFrom();
        
        if(quoteSearchReq.getDateTo()!=null && !quoteSearchReq.getDateTo().equalsIgnoreCase(CommonConstants.BLANK_STRING))
        	_quotionSearchForPortalGetObjectData_strCreatedToDate=quoteSearchReq.getDateTo();
        
        if(quoteSearchReq.getUserID()!=null && !quoteSearchReq.getUserID().equalsIgnoreCase(CommonConstants.BLANK_STRING))
//        	_quotionSearchForPortalGetObjectData_strUserId=quoteSearchReq.getUserID(); //Need to send in blank as GC giving No Data Found if we send User Id 
        	_quotionSearchForPortalGetObjectData_strUserId="";
        
        if(quoteSearchReq.getLineOfBussiness()!=null && !quoteSearchReq.getLineOfBussiness().equalsIgnoreCase(CommonConstants.BLANK_STRING))
        	_quotionSearchForPortalGetObjectData_strLOB = quoteSearchReq.getLineOfBussiness();
        
        if(quoteSearchReq.getFlag()!=null && !quoteSearchReq.getFlag().equalsIgnoreCase(CommonConstants.BLANK_STRING))
        	_quotionSearchForPortalGetObjectData_strFlag = quoteSearchReq.getFlag();
        
        com.unotechsoft.stub.commonservice.generic.client.ServiceResult _quotionSearchForPortalGetObjectData__return = port.quotionSearchForPortalGetObjectData(_quotionSearchForPortalGetObjectData_source, _quotionSearchForPortalGetObjectData_medium, _quotionSearchForPortalGetObjectData_campaingn, _quotionSearchForPortalGetObjectData_strLVTokenID, _quotionSearchForPortalGetObjectData_strQuotationNo, _quotionSearchForPortalGetObjectData_strLOB, _quotionSearchForPortalGetObjectData_strProductCode, _quotionSearchForPortalGetObjectData_strVehRegdNo, _quotionSearchForPortalGetObjectData_strCustomerID, _quotionSearchForPortalGetObjectData_strDOB, _quotionSearchForPortalGetObjectData_strMobileNo, _quotionSearchForPortalGetObjectData_strCreatedDate, _quotionSearchForPortalGetObjectData_strCreatedToDate, _quotionSearchForPortalGetObjectData_strProducerCode, _quotionSearchForPortalGetObjectData_strUserId, _quotionSearchForPortalGetObjectData_strFlag);
        
        if(_quotionSearchForPortalGetObjectData__return!=null){
        	ClsUserData clsUserData=_quotionSearchForPortalGetObjectData__return.getUserData();
        	
        	if(clsUserData!=null){
        		ArrayOfclsQuotionSearchForPortalGrid arrayOfclsQuotionSearchForPortalGrid=clsUserData.getQuotionSearchForPortalGrid();
        		
        		if(arrayOfclsQuotionSearchForPortalGrid!=null){
        			List<ClsQuotionSearchForPortalGrid> clsQuotionSearchForPortalGridList=arrayOfclsQuotionSearchForPortalGrid.getClsQuotionSearchForPortalGrid();
        			String days =  dbService.getConfigParamVal(CommonConstants.QUOTESEARCH_LIMIT_DAYS_SYSTEM_PARAMCD);
        			int valDay = Integer.parseInt(days);
        			Date valDate  = subtractDays( new Date(), valDay);
        			String dt1 = "";   
					String dt2 = "";
//        			valDate.setTime(0);
        			
        			/*valDate.setHours(0);
        			valDate.setMinutes(0);
        			valDate.setSeconds(0);
        			*/
        			if(clsQuotionSearchForPortalGridList!=null && clsQuotionSearchForPortalGridList.size()>0){
        				int clsQuotionSearchForPortalGridSize=clsQuotionSearchForPortalGridList.size();
        				ClsQuotionSearchForPortalGrid clsQuotionSearchForPortalGrid=null;
        				List<QuotationSearchResponse> quoteResponse=new ArrayList<QuotationSearchResponse>();
        				for(int i=0;i<clsQuotionSearchForPortalGridSize;i++){
        					clsQuotionSearchForPortalGrid=clsQuotionSearchForPortalGridList.get(i);
        					QuotationSearchResponse quotationSearchResponse=new QuotationSearchResponse();
        					if(clsQuotionSearchForPortalGrid!=null){
        						
        						
        						SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
        						Date temp = sdf1.parse(nullCheckString(clsQuotionSearchForPortalGrid.getCreatedDate()));
        						/*temp.setHours(0);
        						temp.setMinutes(0);
        						temp.setSeconds(0);
        						*/
        						dt1 = sdf1.format(temp);   
        						dt2 = sdf1.format(valDate);        					
        						temp = sdf1.parse(dt1);
        						valDate = sdf1.parse(dt2);
        						
        						
        						/*if(logger.isDebugEnabled())logger.debug("String format1 :- "+dt1+"String format2 :- "+dt2+" Validation Date :- "+valDate+" and Created Date  "+temp+" AND COMPARISON after "+temp.after(valDate)+" and comparison equal "+temp.equals(valDate));*/
        						
        						if(temp.after(valDate) || temp.equals(valDate)){
        							quotationSearchResponse.setCreationDate(nullCheckString(clsQuotionSearchForPortalGrid.getCreatedDate()));
            						quotationSearchResponse.setCustomerName(nullCheckString(clsQuotionSearchForPortalGrid.getCustomerName()));
            						quotationSearchResponse.setQuoteNo(nullCheckString(clsQuotionSearchForPortalGrid.getQuotationNumber()));
            						quotationSearchResponse.setProductCode(nullCheckString(clsQuotionSearchForPortalGrid.getProductCode()));
            						quotationSearchResponse.setIntermediaryCode(nullCheckString(clsQuotionSearchForPortalGrid.getProducerCode()));
            						quotationSearchResponse.setTotalPremium(nullCheckString(clsQuotionSearchForPortalGrid.getTotalPremium()));
            						quotationSearchResponse.setTransactionType(nullCheckString(clsQuotionSearchForPortalGrid.getTransactionType()));
            						quotationSearchResponse.setProposalStatus(nullCheckString(clsQuotionSearchForPortalGrid.getProposalStatus()));
            						quoteResponse.add(quotationSearchResponse);	
        						}        						
        					}
        					
        				}
        				
        				quoteList.setQuoteList(quoteResponse);
        				quoteList.setResultCode(CommonConstants.SUCCESS_STATUS);
        			}
        		}else if(clsUserData!=null && clsUserData.getErrorText()!=null && !clsUserData.getErrorText().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
        			quoteList.setResultCode(CommonConstants.FAILURE_STATUS);
        			ArrayList<ResponseError> responseErrorList=new ArrayList<ResponseError>();
        			ResponseError responseError=new ResponseError();
        			responseError.setErrorCode(clsUserData.getErrorCode());
        			responseError.setErrorMMessag(clsUserData.getErrorText());
        			responseErrorList.add(responseError);
        			quoteList.setErrorList(responseErrorList);
        		}
        	}
        }
        logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
	}catch(Exception ex){
		logger.error("Inside TagicCommonServiceImpl :: searchQuote() method ::",ex);
		quoteList.setResultCode(CommonConstants.FAILURE_STATUS);
		ArrayList<ResponseError> responseErrorList=new ArrayList<ResponseError>();
		ResponseError responseError=new ResponseError();
		//responseError.setErrorCode(clsUserData.getErrorCode());
		//responseError.setErrorMMessag(ex.getMessage());  //Commented to handle Exception with Modified Message
		responseError.setErrorMMessag("No Data Found !");
		responseErrorList.add(responseError);
		quoteList.setErrorList(responseErrorList);
	}
	
	return quoteList;
}
	private String _strClassName="CommonServiceImpl";
	
	public ProposalSearchResponse searchProposal(ProposalSearchRequest proposalSearchRequest) throws Exception{

		ProposalSearchResponse proposalSearchResponse=null;
		String strMethodName="searchProposal";
		ObjectMapper objMap=new ObjectMapper();
		String strStatusCode=null;
		String strStatusDesc=null;
		//05/042017:Code changes for defect 668
		String declinedStatus=null,transactionType=null;
		HashMap  proposalStatusMap = new HashMap();
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			String serviceUrl=getWSDLURL(CommonConstants.GENERIC_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			GenericIntegration_Service genericService=new GenericIntegration_Service(wsdlUrl);
			GenericIntegration port=genericService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);

			String _proposalSearchForPortalGetObjectData_source = smc_source;
			String _proposalSearchForPortalGetObjectData_medium = smc_medium;
			String _proposalSearchForPortalGetObjectData_campaingn = smc_campaign;
			
			String _proposalSearchForPortalGetObjectData_strLVTokenID = "";
			
			if(proposalSearchRequest.getAuthToken()!=null && !proposalSearchRequest.getAuthToken().equalsIgnoreCase("-1"))
				_proposalSearchForPortalGetObjectData_strLVTokenID=proposalSearchRequest.getAuthToken();
			
			String _proposalSearchForPortalGetObjectData_strProposalNo = "";

			if(proposalSearchRequest.getProposalNo()!=null)
				_proposalSearchForPortalGetObjectData_strProposalNo=proposalSearchRequest.getProposalNo();

			String _proposalSearchForPortalGetObjectData_strLOB = "";

			if(proposalSearchRequest.getLineOfBusiness()!=null)
				_proposalSearchForPortalGetObjectData_strLOB=proposalSearchRequest.getLineOfBusiness(); 
				//_proposalSearchForPortalGetObjectData_strLOB="";

			String _proposalSearchForPortalGetObjectData_strProductCode = "";
			if(proposalSearchRequest.getProductCode()!=null)
				_proposalSearchForPortalGetObjectData_strProductCode=proposalSearchRequest.getProductCode();

			String _proposalSearchForPortalGetObjectData_strVehRegdNo = "";
			if(proposalSearchRequest.getVehicleRegNo()!=null){
				String upperCase = proposalSearchRequest.getVehicleRegNo().toUpperCase();
				proposalSearchRequest.setVehicleRegNo(upperCase);
				_proposalSearchForPortalGetObjectData_strVehRegdNo=proposalSearchRequest.getVehicleRegNo();
			}
				

			String _proposalSearchForPortalGetObjectData_strManualCoverNoteNo = "";
			if(proposalSearchRequest.getCoverNoteNo()!=null)
				_proposalSearchForPortalGetObjectData_strManualCoverNoteNo=proposalSearchRequest.getCoverNoteNo();

			String _proposalSearchForPortalGetObjectData_strCustomerID = "";
			if(proposalSearchRequest.getCustomerId()!=null)
				_proposalSearchForPortalGetObjectData_strCustomerID=proposalSearchRequest.getCustomerId();

			String _proposalSearchForPortalGetObjectData_strCustomerName = "";
			if(proposalSearchRequest.getCustomerName()!=null)
				_proposalSearchForPortalGetObjectData_strCustomerName=proposalSearchRequest.getCustomerName();

			String _proposalSearchForPortalGetObjectData_strDOB = "";
			if(proposalSearchRequest.getDateOfBirth()!=null)
				_proposalSearchForPortalGetObjectData_strDOB=proposalSearchRequest.getDateOfBirth();

			String _proposalSearchForPortalGetObjectData_strPartnerAppNo = "";
			if(proposalSearchRequest.getPartnerApplNo()!=null)
				_proposalSearchForPortalGetObjectData_strPartnerAppNo=proposalSearchRequest.getPartnerApplNo();

			String _proposalSearchForPortalGetObjectData_strCreatedDate = "";
			if(proposalSearchRequest.getCreateDate()!=null)
				_proposalSearchForPortalGetObjectData_strCreatedDate=proposalSearchRequest.getCreateDate();
			
			String _proposalSearchForPortalGetObjectData_strCreatedToDate = "";
			if(proposalSearchRequest.getCreateToDate()!=null)
				_proposalSearchForPortalGetObjectData_strCreatedToDate=proposalSearchRequest.getCreateToDate();

			String _proposalSearchForPortalGetObjectData_strProducerCode = "";
			if(proposalSearchRequest.getProducerCode()!=null)
				_proposalSearchForPortalGetObjectData_strProducerCode=proposalSearchRequest.getProducerCode(); 
//				_proposalSearchForPortalGetObjectData_strProducerCode="3051994444";

			String _proposalSearchForPortalGetObjectData_strUserId = "";
			//Start:06/01/2017:Commented as confirmed by ESB / GC team , user id to be sent blank.
			/*if(proposalSearchRequest.getUserID()!=null)
				_proposalSearchForPortalGetObjectData_strUserId=proposalSearchRequest.getUserID(); */
//				_proposalSearchForPortalGetObjectData_strUserId="3051994444";
			String _proposalSearchForPortalGetObjectData_strFlag = "";
			if(proposalSearchRequest.getFlag()!=null)
				_proposalSearchForPortalGetObjectData_strFlag=proposalSearchRequest.getFlag();

			StopWatch watch = new StopWatch();
			watch.start();
			com.unotechsoft.stub.commonservice.generic.client.ServiceResult _proposalSearchForPortalGetObjectData__return = port.proposalSearchForPortalGetObjectData(_proposalSearchForPortalGetObjectData_source, _proposalSearchForPortalGetObjectData_medium, _proposalSearchForPortalGetObjectData_campaingn, _proposalSearchForPortalGetObjectData_strLVTokenID, _proposalSearchForPortalGetObjectData_strProposalNo, _proposalSearchForPortalGetObjectData_strLOB, _proposalSearchForPortalGetObjectData_strProductCode, _proposalSearchForPortalGetObjectData_strVehRegdNo, _proposalSearchForPortalGetObjectData_strManualCoverNoteNo, _proposalSearchForPortalGetObjectData_strCustomerID, _proposalSearchForPortalGetObjectData_strCustomerName, _proposalSearchForPortalGetObjectData_strDOB, _proposalSearchForPortalGetObjectData_strPartnerAppNo, _proposalSearchForPortalGetObjectData_strCreatedDate, _proposalSearchForPortalGetObjectData_strCreatedToDate, _proposalSearchForPortalGetObjectData_strProducerCode, _proposalSearchForPortalGetObjectData_strUserId, _proposalSearchForPortalGetObjectData_strFlag);
			watch.stop();
			logger.info("Time Taken by proposalSearchForPortalGetObjectData service in seconds..>>"+watch.getTotalTimeSeconds());
			if(_proposalSearchForPortalGetObjectData__return!=null){

				if(_proposalSearchForPortalGetObjectData__return.getUserData()!=null && _proposalSearchForPortalGetObjectData__return.getUserData().getProposalSearchForPortalGrid()!=null){
					ArrayOfclsProposalSearchForPortalGrid arrayOfclsProposalSearchForPortalGrid =_proposalSearchForPortalGetObjectData__return.getUserData().getProposalSearchForPortalGrid();
					if(arrayOfclsProposalSearchForPortalGrid!=null){
						ArrayList<ClsProposalSearchForPortalGrid> clsProposalSearchForPortalGridList = (ArrayList<ClsProposalSearchForPortalGrid>)arrayOfclsProposalSearchForPortalGrid.getClsProposalSearchForPortalGrid();
						if(clsProposalSearchForPortalGridList!=null){
							proposalSearchResponse=new ProposalSearchResponse();
							ArrayList<ProposalSearchResultDet> proposalSearchResultDetList=new ArrayList<ProposalSearchResultDet>();
							//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::Total Number of Proposal List::"+clsProposalSearchForPortalGridList.size());
							//Start: Added to retrieve All possible proposal stauts values from master table
							proposalStatusMap = dbService.getPropStatusDesc(1097);
							//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::Proposal Statuses extracted from DB::"+objMap.writeValueAsString(proposalStatusMap));
							//End: Added to retrieve All possible proposal status values from master table

							for(int i=0;i<clsProposalSearchForPortalGridList.size();i++){
								ClsProposalSearchForPortalGrid clsProposalSearchForPortalGrid=clsProposalSearchForPortalGridList.get(i);

								ProposalSearchResultDet proposalSearchResultDet=new ProposalSearchResultDet();
								proposalSearchResultDet.setProposalNo(nullCheckString(clsProposalSearchForPortalGrid.getProposalNumber()));
								proposalSearchResultDet.setProductCode(nullCheckString(clsProposalSearchForPortalGrid.getProductCode()));
								proposalSearchResultDet.setPremium(nullCheckString(clsProposalSearchForPortalGrid.getTotalPremium()));
								
								
								//Start : 07-Apr-2017  : To send productName to JSON response. 
								 String strval="";					             
					             List<Product> oComProductList =  (List<Product>) dbService.getProduct("com.majesco.dcf.common.tagic.entity.Product","strprodcd",proposalSearchResultDet.getProductCode());
					             if(oComProductList != null && oComProductList.size()>0){
					             	for(Product productList:oComProductList)	                            		                                  
					                       strval = productList.getStrprodname()!=null?productList.getStrprodname().toString():"";					                       					                 	
					             }	                              					             
					             proposalSearchResultDet.setProductName(strval);	
								//End : 07-Apr-2017  : To send productName to JSON response.								
								
								//Start:05/04/2017:Code changes for defect 668.
								
								PendingPropListRequest pendingPropListRequest = new PendingPropListRequest();
								PendingPropListResponse pendingPropListResponse = new PendingPropListResponse();
								
								pendingPropListRequest.setEntityType(proposalSearchRequest.getUserType()==null ? "INTERMEDIARY":proposalSearchRequest.getUserType());
								pendingPropListRequest.setEntityCode(clsProposalSearchForPortalGrid.getProducerCode()==null ? "" : clsProposalSearchForPortalGrid.getProducerCode());
								
								pendingPropListRequest.setProposalNo(clsProposalSearchForPortalGrid.getProposalNumber());
								pendingPropListResponse =getPendingProposalList(pendingPropListRequest);
								//Start:30/12/2016:Added code to reverse map the correct proposal status code as GC proposal search returning proposal status description rather than status code.
								//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::Proposal status from service before reverse mapping::"+clsProposalSearchForPortalGrid.getProposalStatus());
								/*04/05/2017:CODE CHANGES FOR DEFECT 668*/
								
	                                  if(pendingPropListResponse!=null){    					
									//05/04/2017:Code added for checking if proposal status is declined
								     declinedStatus = pendingPropListResponse.getDeclinedStatus();
								     transactionType = pendingPropListResponse.getTransactionType();
								     //if(logger.isDebugEnabled())logger.debug("Inside "+declinedStatus+"::"+strMethodName+"::Result JSON::"+objMap.writeValueAsString(pendingPropListResponse)+"TransactionType"+transactionType);
										if(declinedStatus!=null && transactionType!=null){
										if(declinedStatus.equalsIgnoreCase("NPDP") || declinedStatus.equalsIgnoreCase("NMTD") || declinedStatus.equalsIgnoreCase("NR") || transactionType.equalsIgnoreCase("DECLINED"))
											{							                     
							                    	//Start: Added to retrieve Proposal status descripction from HashMap
							                    	 proposalSearchResultDet.setStatusCode(pendingPropListResponse.getDeclinedStatus());
							                    	 proposalSearchResultDet.setStatusDesc(pendingPropListResponse.getDeclinedStatusDesc()==null?CommonConstants.BLANK_STRING:pendingPropListResponse.getDeclinedStatusDesc());
							                     										
											}
										   else
									     	 {	
											//Start: Added to retrieve Proposal status descripction from HashMap
											 proposalSearchResultDet.setStatusCode(nullCheckString(clsProposalSearchForPortalGrid.getProposalStatus()));
											 proposalSearchResultDet.setStatusDesc((String)proposalStatusMap.get(clsProposalSearchForPortalGrid.getProposalStatus()));	
									
										     }	
										}
										else
										{	
											//Start: Added to retrieve Proposal status descripction from HashMap
											proposalSearchResultDet.setStatusCode(nullCheckString(clsProposalSearchForPortalGrid.getProposalStatus()));
											proposalSearchResultDet.setStatusDesc((String)proposalStatusMap.get(clsProposalSearchForPortalGrid.getProposalStatus()));	
									
										}	
	                                  }
	                                  else
										{	
											//Start: Added to retrieve Proposal status descripction from HashMap
											proposalSearchResultDet.setStatusCode(nullCheckString(clsProposalSearchForPortalGrid.getProposalStatus()));
											proposalSearchResultDet.setStatusDesc((String)proposalStatusMap.get(clsProposalSearchForPortalGrid.getProposalStatus()));	
									
										}	
										    //End:CODE CHANGES FOR DEFECT 668*/	
											//End: Added to retrieve Proposal status descripction from HashMap
									
								
								//End:30/12/2016:Added code to reverse map the correct proposal status code as GC proposal search returning proposal status description rather than status code.
								
								proposalSearchResultDet.setCustomerName(nullCheckString(clsProposalSearchForPortalGrid.getCustomerName()));
								proposalSearchResultDet.setIntermediaryCode(nullCheckString(clsProposalSearchForPortalGrid.getProducerCode()));
								proposalSearchResultDet.setCreatedDate(nullCheckString(clsProposalSearchForPortalGrid.getCreatedDate()));
								proposalSearchResultDet.setTransactionMode(nullCheckString(clsProposalSearchForPortalGrid.getTransactionType()));

								proposalSearchResultDetList.add(proposalSearchResultDet);
							}

							proposalSearchResponse.setProposalSearchResultDetList(proposalSearchResultDetList);
							proposalSearchResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
						}
					}

				}
			}



			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: searchProposal() method ::Exception::",ex);
			proposalSearchResponse=new ProposalSearchResponse();
			proposalSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);			
			//proposalSearchResponse.setMessage(ex.getMessage());  //Commented to handle Exception with Modified Message
			proposalSearchResponse.setMessage("No Data Found !");
		}
		logger.info("Inside "+_strClassName+"::"+strMethodName+"::Result JSON::"+objMap.writeValueAsString(proposalSearchResponse));
		return proposalSearchResponse;
	}
	
	
	public ProposalSearchResponse searchProposalOnSearchScreen(ProposalSearchRequest proposalSearchRequest) throws Exception{

		ProposalSearchResponse proposalSearchResponse=null;
		String strMethodName="searchProposal";
		ObjectMapper objMap=new ObjectMapper();
		String strStatusCode=null;
		String strStatusDesc=null;
		//05/042017:Code changes for defect 668
		String declinedStatus=null,transactionType=null;
		HashMap  proposalStatusMap = new HashMap();
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			String serviceUrl=getWSDLURL(CommonConstants.GENERIC_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			GenericIntegration_Service genericService=new GenericIntegration_Service(wsdlUrl);
			GenericIntegration port=genericService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);

			String _proposalSearchForPortalGetObjectData_source = smc_source;
			String _proposalSearchForPortalGetObjectData_medium = smc_medium;
			String _proposalSearchForPortalGetObjectData_campaingn = smc_campaign;
			
			String _proposalSearchForPortalGetObjectData_strLVTokenID = "";
			
			if(proposalSearchRequest.getAuthToken()!=null && !proposalSearchRequest.getAuthToken().equalsIgnoreCase("-1"))
				_proposalSearchForPortalGetObjectData_strLVTokenID=proposalSearchRequest.getAuthToken();
			
			String _proposalSearchForPortalGetObjectData_strProposalNo = "";

			if(proposalSearchRequest.getProposalNo()!=null)
				_proposalSearchForPortalGetObjectData_strProposalNo=proposalSearchRequest.getProposalNo();

			String _proposalSearchForPortalGetObjectData_strLOB = "";

			if(proposalSearchRequest.getLineOfBusiness()!=null)
				_proposalSearchForPortalGetObjectData_strLOB=proposalSearchRequest.getLineOfBusiness(); 
				//_proposalSearchForPortalGetObjectData_strLOB="";

			String _proposalSearchForPortalGetObjectData_strProductCode = "";
			if(proposalSearchRequest.getProductCode()!=null)
				_proposalSearchForPortalGetObjectData_strProductCode=proposalSearchRequest.getProductCode();

			String _proposalSearchForPortalGetObjectData_strVehRegdNo = "";
			if(proposalSearchRequest.getVehicleRegNo()!=null)
				_proposalSearchForPortalGetObjectData_strVehRegdNo=proposalSearchRequest.getVehicleRegNo();

			String _proposalSearchForPortalGetObjectData_strManualCoverNoteNo = "";
			if(proposalSearchRequest.getCoverNoteNo()!=null)
				_proposalSearchForPortalGetObjectData_strManualCoverNoteNo=proposalSearchRequest.getCoverNoteNo();

			String _proposalSearchForPortalGetObjectData_strCustomerID = "";
			if(proposalSearchRequest.getCustomerId()!=null)
				_proposalSearchForPortalGetObjectData_strCustomerID=proposalSearchRequest.getCustomerId();

			String _proposalSearchForPortalGetObjectData_strCustomerName = "";
			if(proposalSearchRequest.getCustomerName()!=null)
				_proposalSearchForPortalGetObjectData_strCustomerName=proposalSearchRequest.getCustomerName();

			String _proposalSearchForPortalGetObjectData_strDOB = "";
			if(proposalSearchRequest.getDateOfBirth()!=null)
				_proposalSearchForPortalGetObjectData_strDOB=proposalSearchRequest.getDateOfBirth();

			String _proposalSearchForPortalGetObjectData_strPartnerAppNo = "";
			if(proposalSearchRequest.getPartnerApplNo()!=null)
				_proposalSearchForPortalGetObjectData_strPartnerAppNo=proposalSearchRequest.getPartnerApplNo();

			String _proposalSearchForPortalGetObjectData_strCreatedDate = "";
			if(proposalSearchRequest.getCreateDate()!=null)
				_proposalSearchForPortalGetObjectData_strCreatedDate=proposalSearchRequest.getCreateDate();
			
			String _proposalSearchForPortalGetObjectData_strCreatedToDate = "";
			if(proposalSearchRequest.getCreateToDate()!=null)
				_proposalSearchForPortalGetObjectData_strCreatedToDate=proposalSearchRequest.getCreateToDate();

			String _proposalSearchForPortalGetObjectData_strProducerCode = "";
			if(proposalSearchRequest.getProducerCode()!=null)
				_proposalSearchForPortalGetObjectData_strProducerCode=proposalSearchRequest.getProducerCode(); 
//				_proposalSearchForPortalGetObjectData_strProducerCode="3051994444";

			String _proposalSearchForPortalGetObjectData_strUserId = "";
			//Start:06/01/2017:Commented as confirmed by ESB / GC team , user id to be sent blank.
			/*if(proposalSearchRequest.getUserID()!=null)
				_proposalSearchForPortalGetObjectData_strUserId=proposalSearchRequest.getUserID(); */
//				_proposalSearchForPortalGetObjectData_strUserId="3051994444";
			String _proposalSearchForPortalGetObjectData_strFlag = "";
			if(proposalSearchRequest.getFlag()!=null)
				_proposalSearchForPortalGetObjectData_strFlag=proposalSearchRequest.getFlag();

			StopWatch watch = new StopWatch();
			watch.start();
			com.unotechsoft.stub.commonservice.generic.client.ServiceResult _proposalSearchForPortalGetObjectData__return = port.proposalSearchForPortalGetObjectData(_proposalSearchForPortalGetObjectData_source, _proposalSearchForPortalGetObjectData_medium, _proposalSearchForPortalGetObjectData_campaingn, _proposalSearchForPortalGetObjectData_strLVTokenID, _proposalSearchForPortalGetObjectData_strProposalNo, _proposalSearchForPortalGetObjectData_strLOB, _proposalSearchForPortalGetObjectData_strProductCode, _proposalSearchForPortalGetObjectData_strVehRegdNo, _proposalSearchForPortalGetObjectData_strManualCoverNoteNo, _proposalSearchForPortalGetObjectData_strCustomerID, _proposalSearchForPortalGetObjectData_strCustomerName, _proposalSearchForPortalGetObjectData_strDOB, _proposalSearchForPortalGetObjectData_strPartnerAppNo, _proposalSearchForPortalGetObjectData_strCreatedDate, _proposalSearchForPortalGetObjectData_strCreatedToDate, _proposalSearchForPortalGetObjectData_strProducerCode, _proposalSearchForPortalGetObjectData_strUserId, _proposalSearchForPortalGetObjectData_strFlag);
			watch.stop();
			logger.info("Time Taken by proposalSearchForPortalGetObjectData service in seconds..>>"+watch.getTotalTimeSeconds());
			if(_proposalSearchForPortalGetObjectData__return!=null){

				if(_proposalSearchForPortalGetObjectData__return.getUserData()!=null && _proposalSearchForPortalGetObjectData__return.getUserData().getProposalSearchForPortalGrid()!=null){
					ArrayOfclsProposalSearchForPortalGrid arrayOfclsProposalSearchForPortalGrid =_proposalSearchForPortalGetObjectData__return.getUserData().getProposalSearchForPortalGrid();
					if(arrayOfclsProposalSearchForPortalGrid!=null){
						ArrayList<ClsProposalSearchForPortalGrid> clsProposalSearchForPortalGridList = (ArrayList<ClsProposalSearchForPortalGrid>)arrayOfclsProposalSearchForPortalGrid.getClsProposalSearchForPortalGrid();
						if(clsProposalSearchForPortalGridList!=null){
							proposalSearchResponse=new ProposalSearchResponse();
							ArrayList<ProposalSearchResultDet> proposalSearchResultDetList=new ArrayList<ProposalSearchResultDet>();
							//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::Total Number of Proposal List::"+clsProposalSearchForPortalGridList.size());
							//Start: Added to retrieve All possible proposal stauts values from master table
							proposalStatusMap = dbService.getPropStatusDesc(1097);
							//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::Proposal Statuses extracted from DB::"+objMap.writeValueAsString(proposalStatusMap));
							//End: Added to retrieve All possible proposal status values from master table

							for(int i=0;i<clsProposalSearchForPortalGridList.size();i++){
								ClsProposalSearchForPortalGrid clsProposalSearchForPortalGrid=clsProposalSearchForPortalGridList.get(i);
								
								if(	clsProposalSearchForPortalGrid.getProposalStatus().equalsIgnoreCase("NPA")|| clsProposalSearchForPortalGrid.getProposalStatus().equalsIgnoreCase("NCCN")||
									clsProposalSearchForPortalGrid.getProposalStatus().equalsIgnoreCase("NPVI") || clsProposalSearchForPortalGrid.getProposalStatus().equalsIgnoreCase("NPQC2") ){
									
									ProposalSearchResultDet proposalSearchResultDet=new ProposalSearchResultDet();
									proposalSearchResultDet.setProposalNo(nullCheckString(clsProposalSearchForPortalGrid.getProposalNumber()));
									proposalSearchResultDet.setProductCode(nullCheckString(clsProposalSearchForPortalGrid.getProductCode()));
									proposalSearchResultDet.setPremium(nullCheckString(clsProposalSearchForPortalGrid.getTotalPremium()));
									
									
									//Start : 07-Apr-2017  : To send productName to JSON response. 
									 String strval="";					             
						             List<Product> oComProductList =  (List<Product>) dbService.getProduct("com.majesco.dcf.common.tagic.entity.Product","strprodcd",proposalSearchResultDet.getProductCode());
						             if(oComProductList != null && oComProductList.size()>0){
						             	for(Product productList:oComProductList)	                            		                                  
						                       strval = productList.getStrprodname()!=null?productList.getStrprodname().toString():"";					                       					                 	
						             }	                              					             
						             proposalSearchResultDet.setProductName(strval);	
									//End : 07-Apr-2017  : To send productName to JSON response.								
									
									//Start:05/04/2017:Code changes for defect 668.
									
						             
						        /*   Code Commented to prevent multiple call for getPendingProposalList GC : By Vishal : 12-May-2018 : Start    
									PendingPropListRequest pendingPropListRequest = new PendingPropListRequest();
									PendingPropListResponse pendingPropListResponse = new PendingPropListResponse();
									
									pendingPropListRequest.setEntityType(proposalSearchRequest.getUserType()==null ? "INTERMEDIARY":proposalSearchRequest.getUserType());
									pendingPropListRequest.setEntityCode(clsProposalSearchForPortalGrid.getProducerCode()==null ? "" : clsProposalSearchForPortalGrid.getProducerCode());
									
									pendingPropListRequest.setProposalNo(clsProposalSearchForPortalGrid.getProposalNumber());
									pendingPropListResponse =getPendingProposalList(pendingPropListRequest);
									//Start:30/12/2016:Added code to reverse map the correct proposal status code as GC proposal search returning proposal status description rather than status code.
									//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::Proposal status from service before reverse mapping::"+clsProposalSearchForPortalGrid.getProposalStatus());
									04/05/2017:CODE CHANGES FOR DEFECT 668
									
		                                  if(pendingPropListResponse!=null){    					
										//05/04/2017:Code added for checking if proposal status is declined
									     declinedStatus = pendingPropListResponse.getDeclinedStatus();
									     transactionType = pendingPropListResponse.getTransactionType();
									     if(logger.isDebugEnabled())logger.debug("Inside "+declinedStatus+"::"+strMethodName+"::Result JSON::"+objMap.writeValueAsString(pendingPropListResponse)+"TransactionType"+transactionType);
											if(declinedStatus!=null && transactionType!=null){
											if(declinedStatus.equalsIgnoreCase("NPDP") || declinedStatus.equalsIgnoreCase("NMTD") || declinedStatus.equalsIgnoreCase("NR") || transactionType.equalsIgnoreCase("DECLINED"))
												{							                     
								                    	//Start: Added to retrieve Proposal status descripction from HashMap
								                    	 proposalSearchResultDet.setStatusCode(pendingPropListResponse.getDeclinedStatus());
								                    	 proposalSearchResultDet.setStatusDesc(pendingPropListResponse.getDeclinedStatusDesc()==null?CommonConstants.BLANK_STRING:pendingPropListResponse.getDeclinedStatusDesc());
								                     										
												}
											   else
										     	 {	
												//Start: Added to retrieve Proposal status descripction from HashMap
												 proposalSearchResultDet.setStatusCode(nullCheckString(clsProposalSearchForPortalGrid.getProposalStatus()));
												 proposalSearchResultDet.setStatusDesc((String)proposalStatusMap.get(clsProposalSearchForPortalGrid.getProposalStatus()));	
										
											     }	
											}
											else
											{	
												//Start: Added to retrieve Proposal status descripction from HashMap
												proposalSearchResultDet.setStatusCode(nullCheckString(clsProposalSearchForPortalGrid.getProposalStatus()));
												proposalSearchResultDet.setStatusDesc((String)proposalStatusMap.get(clsProposalSearchForPortalGrid.getProposalStatus()));	
										
											}	
		                                  }
		                                  else
											{	
												//Start: Added to retrieve Proposal status descripction from HashMap
												proposalSearchResultDet.setStatusCode(nullCheckString(clsProposalSearchForPortalGrid.getProposalStatus()));
												proposalSearchResultDet.setStatusDesc((String)proposalStatusMap.get(clsProposalSearchForPortalGrid.getProposalStatus()));	
										
											}	
											    //End:CODE CHANGES FOR DEFECT 668
												//End: Added to retrieve Proposal status descripction from HashMap
								   Code Commented to prevent multiple call for getPendingProposalList GC : By Vishal : 12-May-2018 : End*/	
									
									//End:30/12/2016:Added code to reverse map the correct proposal status code as GC proposal search returning proposal status description rather than status code.
									
						             
						             //Code added because of above comment : By Vishal : 12-May-2018 : Start
		                            proposalSearchResultDet.setStatusCode(nullCheckString(clsProposalSearchForPortalGrid.getProposalStatus()));
									proposalSearchResultDet.setStatusDesc((String)proposalStatusMap.get(clsProposalSearchForPortalGrid.getProposalStatus()));
						             //Code added because of above comment : By Vishal : 12-May-2018 : End
		                                  
									proposalSearchResultDet.setCustomerName(nullCheckString(clsProposalSearchForPortalGrid.getCustomerName()));
									proposalSearchResultDet.setIntermediaryCode(nullCheckString(clsProposalSearchForPortalGrid.getProducerCode()));
									proposalSearchResultDet.setCreatedDate(nullCheckString(clsProposalSearchForPortalGrid.getCreatedDate()));
									proposalSearchResultDet.setTransactionMode(nullCheckString(clsProposalSearchForPortalGrid.getTransactionType()));
									
									proposalSearchResultDetList.add(proposalSearchResultDet);
								}																
							}

							proposalSearchResponse.setProposalSearchResultDetList(proposalSearchResultDetList);
							/*Code Updated On 22/05/2017 for flash screen issue UI*/
							if(proposalSearchResultDetList!=null && proposalSearchResultDetList.size()>0)
								proposalSearchResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
							else
								proposalSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
							/*Code Updated On 22/05/2017 for flash screen issue UI*/
						}
					}

				}
			}



			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: searchProposal() method ::Exception::",ex);
			proposalSearchResponse=new ProposalSearchResponse();
			proposalSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			//proposalSearchResponse.setMessage(ex.getMessage());  //Commented to handle Exception with Modified Message
			proposalSearchResponse.setMessage("No Data Found !");
		}
		logger.info("Inside "+_strClassName+"::"+strMethodName+"::Result JSON::"+objMap.writeValueAsString(proposalSearchResponse));
		return proposalSearchResponse;
	}
	
	
	public AgentDashBoardResponse dashBoardPendingList(AgentDashBoardRequest agentDashBoardRequest) throws Exception{
		
		AgentDashBoardResponse agentDashBoardResponse=null;
		ProposalSearchRequest proposalSearchRequest=null;
		PendingQuotesList pendingQuotesList=null;
		PendingInspectionList pendingInspectionList=null;
		RejectedProposalList rejectedList=null;
		PendingApprovalList pendingApprList=null;
		PendingPaymentList pendingPaymentList=null;
		SPLExpiredList payLinkExpiredList = null;
		QuotationSearchRequest quoteSearchReq = null;
		String strMethodName="dashBoardPendingList";
		ObjectMapper objMap=new ObjectMapper();
		String strStatusDesc="";
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			
			proposalSearchRequest=new ProposalSearchRequest();
			proposalSearchRequest.setProducerCode(agentDashBoardRequest.getProducerCode());
			proposalSearchRequest.setUserID(agentDashBoardRequest.getUserID());
			proposalSearchRequest.setAuthToken(agentDashBoardRequest.getAuthToken());
			//Start: 19/04/2019| code added gor dashboard service
			proposalSearchRequest.setFlag(CommonConstants.BLANK_STRING);
			proposalSearchRequest.setCreateDate(agentDashBoardRequest.getFromDate());
			proposalSearchRequest.setCreateToDate(agentDashBoardRequest.getToDate());
			//End: 19/04/2019| code added gor dashboard service
			ProposalSearchResponse proposalSearchResponse= dashboardPendingsearchProposal(proposalSearchRequest);
			
			if(proposalSearchResponse!=null){
				ArrayList<ProposalSearchResultDet> proposalSearchResultDetList= proposalSearchResponse.getProposalSearchResultDetList();
				agentDashBoardResponse=new AgentDashBoardResponse();
				if(proposalSearchResultDetList!=null){
					
					ProposalSearchResultDet proposalSearchResultDet=null;
					//pendingQuotesList=new PendingQuotesList();
					pendingInspectionList=new PendingInspectionList();
					rejectedList=new RejectedProposalList();
					pendingApprList= new PendingApprovalList();
					pendingPaymentList=new PendingPaymentList();
					
					// RahulT| Commented based on Ankit's mail Thu 2/2/2017 7:15 PM
					//ArrayList<DashBoardSummaryDetails> dashBoardSummaryQuoteList=new ArrayList<DashBoardSummaryDetails>();
					ArrayList<DashBoardSummaryDetails> dashBoardSummaryInspectionList=new ArrayList<DashBoardSummaryDetails>();
					ArrayList<DashBoardSummaryDetails> dashBoardSummaryRejectedList=new ArrayList<DashBoardSummaryDetails>();
					ArrayList<DashBoardSummaryDetails> dashBoardPendingApprovalList=new ArrayList<DashBoardSummaryDetails>();
					ArrayList<DashBoardSummaryDetails> dashBoardPendingPaymentList=new ArrayList<DashBoardSummaryDetails>();
					
					
					for(int i=0;i<proposalSearchResultDetList.size();i++){

						proposalSearchResultDet=proposalSearchResultDetList.get(i);

						DashBoardSummaryDetails dashBoardSummaryDetails=new DashBoardSummaryDetails();
						dashBoardSummaryDetails.setProposalNumber(proposalSearchResultDet.getProposalNo());
						dashBoardSummaryDetails.setCustomerName(proposalSearchResultDet.getCustomerName());
						dashBoardSummaryDetails.setProductCode(proposalSearchResultDet.getProductCode());
						dashBoardSummaryDetails.setTotalPremium(proposalSearchResultDet.getPremium());
						dashBoardSummaryDetails.setProposalStatus(proposalSearchResultDet.getStatusCode());
						dashBoardSummaryDetails.setStatusDesc(proposalSearchResultDet.getStatusDesc());
						dashBoardSummaryDetails.setCreatedDate(proposalSearchResultDet.getCreatedDate());   // Added on 25/02/2017
						//Start:09/08/2017:1710_1711:SIT:Uncommented code to set inspection and pending approval list
						//Commented as PendingApproval and Pending Inspection Service are seperated from this service : 26-May-2017 : Vishal 
						if (dashBoardSummaryDetails.getProposalStatus() != null && 
								(dashBoardSummaryDetails.getProposalStatus().equalsIgnoreCase(CommonConstants.PROP_PENDING_INSPECTION_STATUS) ||
										dashBoardSummaryDetails.getProposalStatus().equalsIgnoreCase(CommonConstants.RENEWAL_PENDING_INSPECTION_STATUS))) {
							dashBoardSummaryInspectionList.add(dashBoardSummaryDetails);
						}
						else if (dashBoardSummaryDetails.getProposalStatus() != null
								&& (dashBoardSummaryDetails
										.getProposalStatus()
										.equalsIgnoreCase(
												CommonConstants.PROP_PENDING_APPROVAL_STATUS) || dashBoardSummaryDetails
										.getProposalStatus()
										.equalsIgnoreCase(
												CommonConstants.RENEWAL_PENDING_APPROVAL_STATUS))) {
							dashBoardPendingApprovalList.add(dashBoardSummaryDetails); //End:09/08/2017:1710_1711:SIT:Uncommented code to set inspection and pending approval list
						} else if (dashBoardSummaryDetails.getProposalStatus() != null && 
								(dashBoardSummaryDetails.getProposalStatus().equalsIgnoreCase(CommonConstants.PROP_PENDING_PAYMENT_STATUS1)|| 
										dashBoardSummaryDetails.getProposalStatus().equalsIgnoreCase(CommonConstants.PROP_PENDING_PAYMENT_STATUS2)||
										dashBoardSummaryDetails.getProposalStatus().equalsIgnoreCase(CommonConstants.PROP_PENDING_PAYMENT_STATUS3)||
										dashBoardSummaryDetails.getProposalStatus().equalsIgnoreCase(CommonConstants.RENEWAL_PENDING_PAYMENT_STATUS1)||
										dashBoardSummaryDetails.getProposalStatus().equalsIgnoreCase(CommonConstants.RENEWAL_PENDING_PAYMENT_STATUS2) ||
										dashBoardSummaryDetails.getProposalStatus().equalsIgnoreCase(CommonConstants.RENEWAL_PENDING_PAYMENT_STATUS3))) {
							dashBoardPendingPaymentList.add(dashBoardSummaryDetails);
						}

					}
					
					//Start:09/08/2017:1710_1711:SIT:Uncommented code to set inspection and pending approval list
					pendingInspectionList.setDashBoardSummaryInspectionList(dashBoardSummaryInspectionList);
					if(dashBoardSummaryInspectionList!=null)
						pendingInspectionList.setNoOfPendingInspection(dashBoardSummaryInspectionList.size());
					//End:09/08/2017:1710_1711:SIT:Uncommented code to set inspection and pending approval list
					if(dashBoardSummaryRejectedList!=null)
						rejectedList.setNoOfRejectedProposal(dashBoardSummaryRejectedList.size());
					rejectedList.setDashBoardSummaryRejectedList(dashBoardSummaryRejectedList);
					//Start:09/08/2017:1710_1711:SIT:Uncommented code to set inspection and pending approval list
					if(dashBoardPendingApprovalList!=null)
						pendingApprList.setNoOfPendingApproval(dashBoardPendingApprovalList.size());
					pendingApprList.setDashBoardPendingApprovalList(dashBoardPendingApprovalList);
					//End:09/08/2017:1710_1711:SIT:Uncommented code to set inspection and pending approval list
					if(dashBoardPendingPaymentList!=null)
						pendingPaymentList.setNoOfPendingPayment(dashBoardPendingPaymentList.size());
					pendingPaymentList.setDashBoardPendingPaymentList(dashBoardPendingPaymentList);
										
					//agentDashBoardResponse.setPendingQuotesList(pendingQuotesList);
					//Start:09/08/2017:1710_1711:SIT:Uncommented code to set inspection and pending approval list
					agentDashBoardResponse.setPendingInspectionList(pendingInspectionList);
					//End:09/08/2017:1710_1711:SIT:Uncommented code to set inspection and pending approval list
					//agentDashBoardResponse.setRejectedProposalList(rejectedList);
					//Start:09/08/2017:1710_1711:SIT:Uncommented code to set inspection and pending approval list
					agentDashBoardResponse.setPendingApprovalList(pendingApprList);
					//End:09/08/2017:1710_1711:SIT:Uncommented code to set inspection and pending approval list
					agentDashBoardResponse.setPendingPaymentList(pendingPaymentList);
					
					agentDashBoardResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
				}
			
				ArrayList<Object[]> resultDataIPAQuote = new ArrayList<Object[]>();
				resultDataIPAQuote = dbService.searchIPAQuotDashBoard();
				ArrayList<DashBoardSummaryDetails> dashBoardSummaryQuoteList=new ArrayList<DashBoardSummaryDetails>();
				pendingQuotesList=new PendingQuotesList();
				for(Object[] rowIPAQuot : resultDataIPAQuote)
				{
					DashBoardSummaryDetails response = new DashBoardSummaryDetails();
					
					String CustomerName = (String) nullCheckString(rowIPAQuot[1]) + (String) nullCheckString(rowIPAQuot[2]);
					
					response.setProposalNumber((String) nullCheckString(rowIPAQuot[0])); 
		            response.setCustomerName(CustomerName);
		            response.setProductCode((String) nullCheckString(rowIPAQuot[3]));
		            response.setTotalPremium((String) nullCheckString(rowIPAQuot[4]));
		            response.setProposalStatus("-"); // this is quotation creation date
		            response.setStatusDesc("Pending");
		            //Start 31-07-2018: code added for IPA changes 
		            if(rowIPAQuot[5] != null){
		            Date date = new Date();
					date.setTime(((Date) rowIPAQuot[5]).getTime());
					String formattedDate = new SimpleDateFormat("yyyyMMdd").format(date);
					response.setCreatedDate(formattedDate);}
		            //END 31-07-2018: code added for IPA changes
					//response.setCreatedDate((String) nullCheckString(rowIPAQuot[5]));  // Added for getting creation date for Ipa Quote
		            dashBoardSummaryQuoteList.add(response);
				}
				
				// Added for dashboard quote search : Start : Vishal : 27/02/2017
				quoteSearchReq = new QuotationSearchRequest();
				quoteSearchReq.setProducerCode(agentDashBoardRequest.getProducerCode());
				quoteSearchReq.setUserID(agentDashBoardRequest.getUserID());
				quoteSearchReq.setAuthToken(agentDashBoardRequest.getAuthToken());
				
				QuotationListResponse quoteListResponse= searchQuote(quoteSearchReq);						
				if(quoteListResponse!=null && quoteListResponse.getQuoteList()!=null && quoteListResponse.getQuoteList().size()>0){
					for(QuotationSearchResponse rowMotorQuote : quoteListResponse.getQuoteList()){						
						if(rowMotorQuote!=null){
						DashBoardSummaryDetails response = new DashBoardSummaryDetails();																		
						response.setProposalNumber(rowMotorQuote.getQuoteNo()); 
			            response.setCustomerName(rowMotorQuote.getCustomerName());
			            response.setProductCode(rowMotorQuote.getProductCode());
			            response.setTotalPremium(rowMotorQuote.getTotalPremium());
			            response.setProposalStatus(rowMotorQuote.getProposalStatus()); // this is quotation creation date
			            response.setStatusDesc(rowMotorQuote.getProposalStatus());				            
			            response.setCreatedDate(rowMotorQuote.getCreationDate());			            
			            dashBoardSummaryQuoteList.add(response);	
						}
					}	
				}											
				// Added for Dashboard Quote search : End  : Vishal : 27/02/2017
				
				pendingQuotesList.setDashBoardSummaryQuoteList(dashBoardSummaryQuoteList);
				if(dashBoardSummaryQuoteList!=null)
					pendingQuotesList.setNoOfPendingQuotes(dashBoardSummaryQuoteList.size());
				
				//agentDashBoardResponse.setPayLinkExpiredList(payLinkExpiredList);.
				agentDashBoardResponse.setPendingQuotesList(pendingQuotesList);
				// End: RahulT| Added to get SPL expired count & data.
			}
			
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
			
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: dashBoardPendingList() method ::Exception::",ex);
			agentDashBoardResponse=new AgentDashBoardResponse();
			agentDashBoardResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			agentDashBoardResponse.setMessage(ex.getMessage());
		}
		//logger.info("Inside "+_strClassName+"::"+strMethodName+"::Response JSON :: "+objMap.writeValueAsString(agentDashBoardResponse));
		return agentDashBoardResponse;
	}



	@Override
	public PolicySearchResponse searchPolicy(
			PolicySearchRequest policySearchRequest) throws Exception {
		PolicySearchResponse policySearchResponse=null;
		String strMethodName="searchPolicy";
		ObjectMapper objMap=new ObjectMapper();
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			String serviceUrl=getWSDLURL(CommonConstants.GENERIC_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			GenericIntegration_Service genericService=new GenericIntegration_Service(wsdlUrl);
			GenericIntegration port=genericService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);

			String _policySearchForPortalGetObjectData_source = smc_source;
			String _policySearchForPortalGetObjectData_medium = smc_medium;
			String _policySearchForPortalGetObjectData_campaingn = smc_campaign;
			String strStatusDesc=null;
			
			String _policySearchForPortalGetObjectData_strLVTokenID = "";
			
			if(policySearchRequest.getAuthToken()!=null && !policySearchRequest.getAuthToken().equalsIgnoreCase("-1"))
				_policySearchForPortalGetObjectData_strLVTokenID=policySearchRequest.getAuthToken();
			String _policySearchForPortalGetObjectData_strPolicyNo = "";
			
			if(policySearchRequest.getPolicyNo()!=null)
			//	_proposalSearchForPortalGetObjectData_strProposalNo=proposalSearchRequest.getProposalNo();
				_policySearchForPortalGetObjectData_strPolicyNo = policySearchRequest.getPolicyNo();

			String _policySearchForPortalGetObjectData_strLOB = "";
				
			if(policySearchRequest.getLob()!=null)
				_policySearchForPortalGetObjectData_strLOB=policySearchRequest.getLob();
			    //_policySearchForPortalGetObjectData_strLOB=""; //Setting it to blank as GC gives response as No Data Found with LOB

			String _policySearchForPortalGetObjectData_strProductCode = "";
			
			if(policySearchRequest.getProductCode()!=null)
				//_policySearchForPortalGetObjectData_strProductCode=policySearchRequest.getProducerCode(); //Commented By Ketan More
				_policySearchForPortalGetObjectData_strProductCode=policySearchRequest.getProductCode(); //Added By Ketan More
			
			/*Added By Ketan More Starts Here*/
			String _policySearchForPortalGetObjectData_strProducerCode = "";
			
			if(policySearchRequest.getProducerCode()!=null)
				_policySearchForPortalGetObjectData_strProducerCode=policySearchRequest.getProducerCode(); 
//				_policySearchForPortalGetObjectData_strProducerCode="3051994444"; //Added By Ketan More
			/*Added By Ketan More Ends Here*/
			

			String _policySearchForPortalGetObjectData_strVehRegdNo = "";
			if(policySearchRequest.getVehRegdNo()!=null){
				String uperCase = policySearchRequest.getVehRegdNo().toUpperCase();
				policySearchRequest.setVehRegdNo(uperCase);
				_policySearchForPortalGetObjectData_strVehRegdNo=policySearchRequest.getVehRegdNo();
			}

			String policySearchForPortalGetObjectData_strUserId = "";
			if(policySearchRequest.getUserID()!=null)
//				policySearchForPortalGetObjectData_strUserId=policySearchRequest.getUserID();
				policySearchForPortalGetObjectData_strUserId="";//If we are sending User Id then GC returns No Data Found
			
			
			
			String policySearchForPortalGetObjectData_strQuotationNo = "";
			if(policySearchRequest.getQuotationNo()!=null)
				policySearchForPortalGetObjectData_strQuotationNo=policySearchRequest.getQuotationNo();
			
			String policySearchForPortalGetObjectData_strProposalNo = "";
			if(policySearchRequest.getProposalNo()!=null)
				policySearchForPortalGetObjectData_strProposalNo=policySearchRequest.getProposalNo();
			
			
			String policySearchForPortalGetObjectData_strAuthorizationNo = "";
			if(policySearchRequest.getAuthorizationNo()!=null)
				policySearchForPortalGetObjectData_strAuthorizationNo=policySearchRequest.getAuthorizationNo();
		//	policySearchRequest.getPartnerAppNo();
			
		//	policySearchRequest.getPolicyNo();
		//done	policySearchRequest.getProducerCode();
		// done	policySearchRequest.getProposalNo();
		//	policySearchRequest.getQuotationNo();
		//	policySearchRequest.getReceiptNo();
			
			
			
			String _policySearchForPortalGetObjectData_strInstrumentNumber = "";
			if(policySearchRequest.getInstrumentNo()!=null)
				_policySearchForPortalGetObjectData_strInstrumentNumber=policySearchRequest.getInstrumentNo();
			
			String _policySearchForPortalGetObjectData_strLvTokenId = "";
			if(policySearchRequest.getLvTokenId()!=null)
				_policySearchForPortalGetObjectData_strLvTokenId=policySearchRequest.getLvTokenId();
			
			String _policySearchForPortalGetObjectData_strManualCoverNoteNumber = "";
			if(policySearchRequest.getManualCoverNoteNo()!=null)
				_policySearchForPortalGetObjectData_strManualCoverNoteNumber=policySearchRequest.getManualCoverNoteNo();
		
			
			
			String _policySearchForPortalGetObjectData_strMobileNumber = "";
			if(policySearchRequest.getMobileNo()!=null)
				_policySearchForPortalGetObjectData_strMobileNumber=policySearchRequest.getMobileNo();
		
			String _policySearchForPortalGetObjectData_strPartnerAppNumber = "";
			if(policySearchRequest.getPartnerAppNo()!=null)
				_policySearchForPortalGetObjectData_strPartnerAppNumber=policySearchRequest.getPartnerAppNo();
			
			String _policySearchForPortalGetObjectData_strPassword = "";
			if(policySearchRequest.getPassword()!=null)
				_policySearchForPortalGetObjectData_strPassword=policySearchRequest.getPassword();
			
			String _policySearchForPortalGetObjectData_strPolicyNumber = "";
			if(policySearchRequest.getPolicyNo()!=null)
				_policySearchForPortalGetObjectData_strPolicyNumber=policySearchRequest.getPolicyNo();
		
			String _policySearchForPortalGetObjectData_strQuotationNumber = "";
			if(policySearchRequest.getQuotationNo()!=null)
				_policySearchForPortalGetObjectData_strQuotationNumber=policySearchRequest.getQuotationNo();
			
			String _policySearchForPortalGetObjectData_strReceiptNumber = "";
			if(policySearchRequest.getReceiptNo()!=null)
				_policySearchForPortalGetObjectData_strReceiptNumber=policySearchRequest.getReceiptNo();
		
			
			/*if(proposalSearchRequest.getCoverNoteNo()!=null)
				_proposalSearchForPortalGetObjectData_strManualCoverNoteNo=proposalSearchRequest.getCoverNoteNo();

			String _proposalSearchForPortalGetObjectData_strCustomerID = "";
			if(proposalSearchRequest.getCustomerId()!=null)
				_proposalSearchForPortalGetObjectData_strCustomerID=proposalSearchRequest.getCustomerId();

			String _proposalSearchForPortalGetObjectData_strCustomerName = "";
			if(proposalSearchRequest.getCustomerName()!=null)
				_proposalSearchForPortalGetObjectData_strCustomerName=proposalSearchRequest.getCustomerName();

			String _proposalSearchForPortalGetObjectData_strDOB = "";
			if(proposalSearchRequest.getDateOfBirth()!=null)
				_proposalSearchForPortalGetObjectData_strDOB=proposalSearchRequest.getDateOfBirth();

			String _proposalSearchForPortalGetObjectData_strPartnerAppNo = "";
			if(proposalSearchRequest.getPartnerApplNo()!=null)
				_proposalSearchForPortalGetObjectData_strPartnerAppNo=proposalSearchRequest.getPartnerApplNo();

			String _proposalSearchForPortalGetObjectData_strCreatedDate = "";
			if(proposalSearchRequest.getCreateDate()!=null)
				_proposalSearchForPortalGetObjectData_strCreatedDate=proposalSearchRequest.getCreateDate();

			String _proposalSearchForPortalGetObjectData_strProducerCode = "";
			if(proposalSearchRequest.getProducerCode()!=null)
				_proposalSearchForPortalGetObjectData_strProducerCode=proposalSearchRequest.getProducerCode();

			String _proposalSearchForPortalGetObjectData_strUserId = "";
			if(proposalSearchRequest.getUserID()!=null)
				_proposalSearchForPortalGetObjectData_strUserId=proposalSearchRequest.getUserID();*/

			//com.unotechsoft.stub.commonservice.generic.client.ServiceResult _policySearchForPortalGetObjectData__return = port.policySearchForPortalGetObjectData(_policySearchForPortalGetObjectData_source, _policySearchForPortalGetObjectData_medium, _policySearchForPortalGetObjectData_campaingn,_policySearchForPortalGetObjectData_strLVTokenID, _policySearchForPortalGetObjectData_strPolicyNo, _policySearchForPortalGetObjectData_strLOB, _policySearchForPortalGetObjectData_strProductCode, _policySearchForPortalGetObjectData_strVehRegdNo, policySearchForPortalGetObjectData_strQuotationNo,policySearchForPortalGetObjectData_strProposalNo,_policySearchForPortalGetObjectData_strManualCoverNoteNumber, _policySearchForPortalGetObjectData_strReceiptNumber, _policySearchForPortalGetObjectData_strInstrumentNumber,policySearchForPortalGetObjectData_strAuthorizationNo,_policySearchForPortalGetObjectData_strPartnerAppNumber, _policySearchForPortalGetObjectData_strMobileNumber, _policySearchForPortalGetObjectData_strProductCode, policySearchForPortalGetObjectData_strUserId); //Commented By Ketan More
			com.unotechsoft.stub.commonservice.generic.client.ServiceResult _policySearchForPortalGetObjectData__return = port.policySearchForPortalGetObjectData(_policySearchForPortalGetObjectData_source, _policySearchForPortalGetObjectData_medium, _policySearchForPortalGetObjectData_campaingn,_policySearchForPortalGetObjectData_strLVTokenID, _policySearchForPortalGetObjectData_strPolicyNo, _policySearchForPortalGetObjectData_strLOB, _policySearchForPortalGetObjectData_strProductCode, _policySearchForPortalGetObjectData_strVehRegdNo, policySearchForPortalGetObjectData_strQuotationNo,policySearchForPortalGetObjectData_strProposalNo,_policySearchForPortalGetObjectData_strManualCoverNoteNumber, _policySearchForPortalGetObjectData_strReceiptNumber, _policySearchForPortalGetObjectData_strInstrumentNumber,policySearchForPortalGetObjectData_strAuthorizationNo,_policySearchForPortalGetObjectData_strPartnerAppNumber, _policySearchForPortalGetObjectData_strMobileNumber, _policySearchForPortalGetObjectData_strProducerCode, policySearchForPortalGetObjectData_strUserId); //Added By Ketan More
			if(_policySearchForPortalGetObjectData__return!=null && _policySearchForPortalGetObjectData__return.getUserData()!=null && _policySearchForPortalGetObjectData__return.getUserData().getErrorText()!=null && _policySearchForPortalGetObjectData__return.getUserData().getErrorText().equalsIgnoreCase("")){

				if(_policySearchForPortalGetObjectData__return.getUserData()!=null && _policySearchForPortalGetObjectData__return.getUserData().getProposalSearchForPortalGrid()!=null){
					ArrayOfclsPolicySearchForPortalGrid arrayOfclsPolicySearchForPortalGrid =_policySearchForPortalGetObjectData__return.getUserData().getPolicySearchForPortalGrid();
					if(arrayOfclsPolicySearchForPortalGrid!=null){
						ArrayList<ClsPolicySearchForPortalGrid> clsPolicySearchForPortalGridList = (ArrayList<ClsPolicySearchForPortalGrid>)arrayOfclsPolicySearchForPortalGrid.getClsPolicySearchForPortalGrid();
						if(clsPolicySearchForPortalGridList!=null){
						//	proposalSearchResponse=new ProposalSearchResponse();
							policySearchResponse = new PolicySearchResponse();
							ArrayList<PolicySearchResultDet> policySearchResultDetList=new ArrayList<PolicySearchResultDet>();

							for(int i=0;i<clsPolicySearchForPortalGridList.size();i++){
						//		ClsProposalSearchForPortalGrid clsProposalSearchForPortalGrid=clsProposalSearchForPortalGridList.get(i);
								ClsPolicySearchForPortalGrid  clsPolicySearchForPortalGrid = clsPolicySearchForPortalGridList.get(i);

							//	ProposalSearchResultDet proposalSearchResultDet=new ProposalSearchResultDet();
								PolicySearchResultDet policySearchResultDet = new PolicySearchResultDet();
								/*proposalSearchResultDet.setProposalNo(clsProposalSearchForPortalGrid.getProposalNumber());
								proposalSearchResultDet.setProductCode(clsProposalSearchForPortalGrid.getProductCode());
								proposalSearchResultDet.setPremium(clsProposalSearchForPortalGrid.getTotalPremium());
								proposalSearchResultDet.setStatusCode(clsProposalSearchForPortalGrid.getProposalStatus());
								proposalSearchResultDet.setCustomerName(clsProposalSearchForPortalGrid.getCustomerName());
								proposalSearchResultDet.setIntermediaryCode(clsProposalSearchForPortalGrid.getProducerCode());
								proposalSearchResultDet.setCreatedDate(clsProposalSearchForPortalGrid.getCreatedDate());
								proposalSearchResultDet.setTransactionMode(clsProposalSearchForPortalGrid.getTransactionType());
*/                             policySearchResultDet.setProposalNo(nullCheckString(clsPolicySearchForPortalGrid.getProposalNumber()));
                              policySearchResultDet.setCustomerName(nullCheckString(clsPolicySearchForPortalGrid.getCustomerName()));
                              policySearchResultDet.setPolicyInceptionDate(nullCheckString(clsPolicySearchForPortalGrid.getPolicyInsDate()));
                              policySearchResultDet.setPolicyNo(nullCheckString(clsPolicySearchForPortalGrid.getPolicyNumber()));
                              policySearchResultDet.setPolicyStatus(nullCheckString(clsPolicySearchForPortalGrid.getPolicyStatus()));
                              if(policySearchResultDet.getPolicyStatus()!=null && !policySearchResultDet.getPolicyStatus().equals(CommonConstants.BLANK_STRING)){
                              strStatusDesc=dbService.getCodeDesc(null, policySearchResultDet.getPolicyStatus(), CommonConstants.PROPOSAL_STATUS_CODE, "1");
                              if(strStatusDesc!=null && !strStatusDesc.equals(CommonConstants.BLANK_STRING)){
                            	  policySearchResultDet.setPolicyStatus(strStatusDesc);
                              }
                              }
                              policySearchResultDet.setProducerCode(nullCheckString(clsPolicySearchForPortalGrid.getProducerCode()));
                              policySearchResultDet.setProductName(nullCheckString(clsPolicySearchForPortalGrid.getProductName()));
                              policySearchResultDet.setProposalNo(nullCheckString(clsPolicySearchForPortalGrid.getProposalNumber()));
                              policySearchResultDet.setCustomerName(nullCheckString(clsPolicySearchForPortalGrid.getCustomerName()));
                              policySearchResultDet.setTotalPremium(nullCheckString(clsPolicySearchForPortalGrid.getTotalPremium()));
                              policySearchResultDet.setTransactionType(nullCheckString(clsPolicySearchForPortalGrid.getTransactionType()));
                              if (clsPolicySearchForPortalGrid.getProductName()!=null && clsPolicySearchForPortalGrid.getProductName().contains("PrivateCar"))
                            	  policySearchResultDet.setProductCode("3121");
                              else if (clsPolicySearchForPortalGrid.getProductName()!=null && clsPolicySearchForPortalGrid.getProductName().contains("Two"))
                            	  policySearchResultDet.setProductCode("3122");
                              else if (clsPolicySearchForPortalGrid.getProductName()!=null && clsPolicySearchForPortalGrid.getProductName().contains("Commercial"))
                            	  policySearchResultDet.setProductCode("3124");
                              else if (clsPolicySearchForPortalGrid.getProductName()!=null && clsPolicySearchForPortalGrid.getProductName().contains("Guard"))
                            	  policySearchResultDet.setProductCode("4251");
                              else if (clsPolicySearchForPortalGrid.getProductName()!=null && clsPolicySearchForPortalGrid.getProductName().contains("Shield"))
                            	  policySearchResultDet.setProductCode("4254");
                              else if (clsPolicySearchForPortalGrid.getProductName()!=null && clsPolicySearchForPortalGrid.getProductName().contains("Future"))
                            	  policySearchResultDet.setProductCode("4255");
                              policySearchResultDetList.add(policySearchResultDet);
							}

						//	proposalSearchResponse.setProposalSearchResultDetList(proposalSearchResultDetList);
							policySearchResponse.setPolicySearchResultDetList(policySearchResultDetList);
							policySearchResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
						}
					}

				}
			}else if(_policySearchForPortalGetObjectData__return!=null && _policySearchForPortalGetObjectData__return.getUserData()!=null && _policySearchForPortalGetObjectData__return.getUserData().getErrorText()!=null && !_policySearchForPortalGetObjectData__return.getUserData().getErrorText().equalsIgnoreCase("")){
				policySearchResponse = new PolicySearchResponse();
				policySearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
				policySearchResponse.setMessage(_policySearchForPortalGetObjectData__return.getUserData().getErrorText());
				ArrayList<ResponseError> responseErrorList=new ArrayList<ResponseError>();
				ResponseError responseError=new ResponseError();
				responseError.setErrorCode("999"); // Temporary setting
				responseError.setErrorMMessag(_policySearchForPortalGetObjectData__return.getUserData().getErrorText());
				policySearchResponse.setResponseError(responseErrorList);
			}



			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: searchPolicy() method ::Exception::",ex);
			policySearchResponse=new PolicySearchResponse();
			policySearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			//policySearchResponse.setMessage(ex.getMessage());  //Commented to handle Exception with Modified Message.
			policySearchResponse.setMessage("No Data Found !");
		}
		logger.info("Inside "+_strClassName+"::"+strMethodName+"::Result JSON::"+objMap.writeValueAsString(policySearchResponse));

		return policySearchResponse;
	}
	
	public String nullCheckString(Object obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }
	
	
	public QuotationListResponse searchQuoteByQuoteNo(QuotationSearchRequest quoteSearchReq) throws Exception{
		
		QuotationListResponse quoteList=new QuotationListResponse();
		String wsdlUrl=null;
		String strMethodName="searchQuoteByQuoteNo";
		try{
			
			wsdlUrl = getWSDLURL(CommonConstants.MOTOR_QUOTE_SEARCH_SERVICE);
			URL serviceUrl=new URL(wsdlUrl);
			QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/SearchStubService/QuotaionSearchService", "SearchStubService");
			
			SearchStubService_Service ss = new SearchStubService_Service(serviceUrl, SERVICE_NAME);
	        SearchStubService port = ss.getSOAPOverHTTP(); 
	        ServiceUtility serviceUtil=new ServiceUtility();
	        serviceUtil.addClientInterceptor(port);
	        
	        com.unotechsoft.stub.motorservice.quotesearch.GetQuotationSearch _getQuotationSearch_parameters = new GetQuotationSearch();
	        if(quoteSearchReq!=null){
	        
	        	SearchQuotationRequest inputReq=new SearchQuotationRequest();
	        	inputReq.setProductCd(quoteSearchReq.getProductCode());
	        	//Start:04/01/2017:Changes done as suggested by ESB / GC team on 04/01/2017
	        	if(quoteSearchReq.getProductCode()!=null && quoteSearchReq.getProductCode().equalsIgnoreCase(CommonConstants.TWO_WHEELER_PRODUCT_CODE))
	        	inputReq.setDeptcd("31"); // Hard coded to 31.
	        	else if(quoteSearchReq.getProductCode()!=null && quoteSearchReq.getProductCode().equalsIgnoreCase(CommonConstants.PRIVATE_CAR_PRODUCT_CODE))
	        		inputReq.setDeptcd(CommonConstants.BLANK_STRING);
	        	//End:04/01/2017:Changes done as suggested by ESB / GC team on 04/01/2017
	        	inputReq.setQuoteNo(quoteSearchReq.getQuoteNo());
	        	inputReq.setCustId(quoteSearchReq.getCustomerId());
	        	inputReq.setProposalNo("");
	        	inputReq.setQuoteDate(quoteSearchReq.getDateFrom());
	        	inputReq.setVersionNo("");
	        	inputReq.setCustName("");
	        	String jaxbXML=JAXBXMLHandler.marshal(inputReq);
	        	QuotationRequest quoteReq=new QuotationRequest();
	        	quoteReq.setAuthenticationToken(quoteSearchReq.getAuthToken());
	        	quoteReq.setCampaign(smc_campaign);
	        	quoteReq.setMedium(smc_medium);
	        	quoteReq.setSource(smc_source);
	        	quoteReq.setIsBankDataRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
	        	quoteReq.setIsCutomerAddressRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
	        	quoteReq.setIsFinanciarDataRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
	        	quoteReq.setIsManufacturerMappingRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
	        	quoteReq.setIsModelMappingRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
	        	quoteReq.setIsRTOMappingRequired(CommonConstants.BOOLEAN_FALSE_FLAG);
	        	
	        	quoteReq.setInputXML(jaxbXML);
	        	quoteReq.setModeOfOperation(CommonConstants.NEWPOLICY_MOD_OPR);
	        	quoteReq.setUserRole("ADMIN"); // Hard coded to ADMIN
	        	
	        	_getQuotationSearch_parameters.setCreatePolicyRequest(quoteReq);
	        	
	        com.unotechsoft.stub.motorservice.quotesearch.GetLOVQuotationResponse2 _getQuotationSearch__return = port.getQuotationSearch(_getQuotationSearch_parameters);
	        
	        if(_getQuotationSearch__return!=null && _getQuotationSearch__return.getGetLOVQuotationResult()!=null){
	        	if(_getQuotationSearch__return.getGetLOVQuotationResult().getQuotationLOVList()!=null && _getQuotationSearch__return.getGetLOVQuotationResult().getQuotationLOVList().getQuotationLOVInfo()!=null){
	        		List<QuotationLOVInfo> quoteInfoList=_getQuotationSearch__return.getGetLOVQuotationResult().getQuotationLOVList().getQuotationLOVInfo();
	        	quoteList=new QuotationListResponse();
	        	List<QuotationSearchResponse> quoteResponse=new ArrayList<QuotationSearchResponse>();
	        	for(int i=0;i<quoteInfoList.size();i++){
	        		QuotationLOVInfo quoteInfo= (QuotationLOVInfo) quoteInfoList.get(i);
	        		if(quoteInfo!=null){
	        			QuotationSearchResponse quote=new QuotationSearchResponse();
	        			quote.setQuoteNo(quoteInfo.getQuotationNo());
	        			quote.setCustomerName(quoteInfo.getCustomerName());
	        			quote.setCustomerId(quoteInfo.getCustomerId());
	        			quote.setCreationDate(quoteInfo.getPolicyStartDate());
	        			quote.setProposalNo(quoteInfo.getProposalNo());
	        			quoteResponse.add(quote);
	        		}
	        	}
	        	quoteList.setQuoteList(quoteResponse);
	        	quoteList.setResultCode("1");
	        	}else{
	        		quoteList.setResultCode("0");
	        	}
	        }
	        
	        }
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl ::"+strMethodName+" ::",ex);
			quoteList.setResultCode(CommonConstants.FAILURE_STATUS);
			ArrayList<ResponseError> responseErrorList=new ArrayList<ResponseError>();
			ResponseError responseError=new ResponseError();
			//responseError.setErrorCode(clsUserData.getErrorCode());
			responseError.setErrorMMessag(ex.getMessage());
			responseErrorList.add(responseError);
			quoteList.setErrorList(responseErrorList);
		}
		
		return quoteList;
	}
	
	@Override
	//@Async
	public byte[] printProposalAttachment(PrintProposalReq printProposalReq) throws Exception{
		
		String wsdlUrl=null;
		String strFileName=null;
		byte[] propDataByteArr = null;
		
		try{
			logger.info("Inside TagicCommonServiceImpl :: printProposal() method :: Entered ::");
			
			wsdlUrl = getWSDLURL(CommonConstants.PRINT_PROP_POL_DOCUMENT_SERVICE);
			URL serviceUrl=new URL(wsdlUrl);
			
			final QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/GetDocumentForPortalService/", "GetDocumentForPortalService");
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service ss = new com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service(serviceUrl, SERVICE_NAME);
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService port = ss.getSOAPOverHTTP();
			
			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(port);
			
			String _getProposalFormForPortal_source = smc_source;
			String _getProposalFormForPortal_medium = smc_medium;
			String _getProposalFormForPortal_campaign = smc_campaign;
			String _getProposalFormForPortal_strLVAuthToken = "";
			
			com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult _getProposalFormForPortal_objServiceResultVal = null;
			_getProposalFormForPortal_objServiceResultVal = new com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult();
			com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData userData = new com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData();
			
			if(printProposalReq.getCustomerID() != null && !printProposalReq.getCustomerID().equalsIgnoreCase("")) 
				userData.setCustomerId(printProposalReq.getCustomerID());
			
			if(printProposalReq.getProductCode() != null && !printProposalReq.getProductCode().equalsIgnoreCase("")) 
				userData.setProductCode(printProposalReq.getProductCode());
			
			if(printProposalReq.getProposalDate() != null && !printProposalReq.getProposalDate().equalsIgnoreCase("")) 
				userData.setProposalDate(printProposalReq.getProposalDate());
			
			if(printProposalReq.getProposalNumber() != null && !printProposalReq.getProposalNumber().equalsIgnoreCase("")) 
				userData.setProposalNumber(printProposalReq.getProposalNumber());
			
			userData.setReportAsPDF(true);
			userData.setReportTypeCode("4");
			if(printProposalReq.getUserID()!=null && !printProposalReq.getUserID().equals(""))
			userData.setUserId(printProposalReq.getUserID());
			else
			userData.setUserId("gcwinuat05");
			
			userData.setUserRole("ADMIN");
			if(printProposalReq.getPassword()!=null && !printProposalReq.getPassword().equalsIgnoreCase(""))
				userData.setPassword(printProposalReq.getPassword());
			    
			_getProposalFormForPortal_objServiceResultVal.setUserData(userData);
			Holder<com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult> _getProposalFormForPortal_objServiceResult = new Holder(_getProposalFormForPortal_objServiceResultVal);
			    
			Holder<byte[]> _getProposalFormForPortal_getProposalFormForPortalResult = new Holder();
			port.getProposalFormForPortal(_getProposalFormForPortal_source, _getProposalFormForPortal_medium, _getProposalFormForPortal_campaign, _getProposalFormForPortal_strLVAuthToken, _getProposalFormForPortal_objServiceResult, _getProposalFormForPortal_getProposalFormForPortalResult);
			
			propDataByteArr = _getProposalFormForPortal_getProposalFormForPortalResult.value;
			
			
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: printProposal() method ::",ex);
		}
		return propDataByteArr;
	}
	
	@Override
	//@Async
	public byte[] printPolicyAttachment(PrintProposalReq printProposalReq) throws Exception{
		
		String wsdlUrl=null;
		String strFileName=null;
		byte[] propDataByteArr = null;
		
		try{
			logger.info("Inside TagicCommonServiceImpl :: printPolicy() method :: Entered ::");
			
			wsdlUrl = getWSDLURL(CommonConstants.PRINT_PROP_POL_DOCUMENT_SERVICE);
			URL serviceUrl=new URL(wsdlUrl);
			
			final QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/GetDocumentForPortalService/", "GetDocumentForPortalService");
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service ss = new com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service(serviceUrl, SERVICE_NAME);
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService port = ss.getSOAPOverHTTP();
			
			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(port);
			
			String _getProposalFormForPortal_source = smc_source;
			String _getProposalFormForPortal_medium = smc_medium;
			String _getProposalFormForPortal_campaign = smc_campaign;
			String _getProposalFormForPortal_strLVAuthToken = "";
			
			com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult _getProposalFormForPortal_objServiceResultVal = null;
			_getProposalFormForPortal_objServiceResultVal = new com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult();
			com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData userData = new com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData();
				
			if(printProposalReq.getCustomerID() != null && !printProposalReq.getCustomerID().equalsIgnoreCase("")) 
				userData.setCustomerId(printProposalReq.getCustomerID());
			
			if(printProposalReq.getProductCode() != null && !printProposalReq.getProductCode().equalsIgnoreCase("")) 
				userData.setProductCode(printProposalReq.getProductCode());
			
			if(printProposalReq.getProposalDate() != null && !printProposalReq.getProposalDate().equalsIgnoreCase("")) 
				userData.setProposalDate(printProposalReq.getProposalDate());
			
			if(printProposalReq.getProposalNumber() != null && !printProposalReq.getProposalNumber().equalsIgnoreCase("")) 
				userData.setProposalNumber(printProposalReq.getProposalNumber());

			userData.setReportTypeCode("4");
			if(printProposalReq.getUserID()!=null && !printProposalReq.getUserID().equals(""))
			userData.setUserId(printProposalReq.getUserID());
			else
			userData.setUserId("gcwinuat05");
			
			userData.setUserRole("ADMIN");
			
			if(printProposalReq.getPassword()!=null && !printProposalReq.getPassword().equalsIgnoreCase(""))
				userData.setPassword(printProposalReq.getPassword());
			
			_getProposalFormForPortal_objServiceResultVal.setUserData(userData);
			Holder<com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult> _getProposalFormForPortal_objServiceResult = new Holder(_getProposalFormForPortal_objServiceResultVal);
			    
			Holder<byte[]> _getProposalFormForPortal_getProposalFormForPortalResult = new Holder();
			port.getPolicyDocumentForPortal(_getProposalFormForPortal_source, _getProposalFormForPortal_medium, _getProposalFormForPortal_campaign, _getProposalFormForPortal_strLVAuthToken, _getProposalFormForPortal_objServiceResult, _getProposalFormForPortal_getProposalFormForPortalResult);
			
			propDataByteArr = _getProposalFormForPortal_getProposalFormForPortalResult.value;
			
			logger.info("Inside TagicCommonServiceImpl :: printPolicy() method :: Exit ::");
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: printPolicy() method ::",ex);
		}
		return propDataByteArr;
	}
	
	@Override
	//@Async
	public byte[] printWorksheetAttachment(PrintProposalReq printProposalReq) throws Exception{
		
		String wsdlUrl=null;
		byte[] propDataByteArr = null;
		
		try{
			logger.info("Inside TagicCommonServiceImpl :: printWorksheet() method :: Entered ::");
			
			wsdlUrl = getWSDLURL(CommonConstants.PRINT_PROP_POL_DOCUMENT_SERVICE);
			URL serviceUrl=new URL(wsdlUrl);
			ObjectMapper objMap = new ObjectMapper();
			
			//if(logger.isDebugEnabled())logger.debug("Inside TagicCommonServiceImpl :: printWorksheet() method :: Request Received JSON :: "+objMap.writeValueAsString(printProposalReq));
			
			final QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/GetDocumentForPortalService/", "GetDocumentForPortalService");
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service ss = new com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service(serviceUrl, SERVICE_NAME);
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService port = ss.getSOAPOverHTTP();
			
			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(port);
			
			String _generateWorksheet_source = smc_source;
			String _generateWorksheet_medium = smc_medium;
			String _generateWorksheet_campaign = smc_campaign;
			String _generateWorksheet_strLVAuthToken = "";
			
			com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult _generateWorksheet_objServiceResultVal = null;
			_generateWorksheet_objServiceResultVal=new com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult();
			com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData userData = new com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData();
			
			if(printProposalReq.getProposalNumber() != null && !printProposalReq.getProposalNumber().equalsIgnoreCase("")) 
				userData.setProposalNumber(printProposalReq.getProposalNumber());
			
			userData.setAuthenticateKey(CommonConstants.BLANK_STRING);
			if(printProposalReq.getUserID()!=null && !printProposalReq.getUserID().equalsIgnoreCase(""))
				userData.setUserId(printProposalReq.getUserID());
			// Start: RahulT| 1959| added to take user name from UI request 
			/*else
			userData.setUserId("gcwinuat05");*/
			
			if(printProposalReq.getPassword()!=null && !printProposalReq.getPassword().equalsIgnoreCase(""))
				userData.setPassword(printProposalReq.getPassword());
			/*else
			userData.setPassword("cmc123");*/
			// End: RahulT| 1959| added to take user name from UI request
			
			userData.setUserRole("ADMIN");
			
			    
			_generateWorksheet_objServiceResultVal.setUserData(userData);
			
			javax.xml.ws.Holder<com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult> _generateWorksheet_objServiceResult = new javax.xml.ws.Holder<com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult>(_generateWorksheet_objServiceResultVal);
	        javax.xml.ws.Holder<byte[]> _generateWorksheet_generateWorksheetResult = new javax.xml.ws.Holder<byte[]>();
	        port.generateWorksheet(_generateWorksheet_source, _generateWorksheet_medium, _generateWorksheet_campaign, _generateWorksheet_strLVAuthToken, _generateWorksheet_objServiceResult, _generateWorksheet_generateWorksheetResult);
			
			propDataByteArr = _generateWorksheet_generateWorksheetResult.value;
			//if(logger.isDebugEnabled())logger.debug("TagicCommonServiceImpl :: printWorksheet :: Byte stream returned ::"+new String(propDataByteArr));
			
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: printWorksheet() method ::",ex);
		}
		return propDataByteArr;
	}
	
	@Override
	//@Async
	public byte[] printReceiptAttachment(String receiptNo, String userId, String password, String proposalNo)throws Exception {
		// TODO Auto-generated method stub
		
		byte[] receiptDataByteArr = null;
		
		String serviceURL=ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING;
		AccountService accServClient;
		String retVal = "";
		try {
			
			if(serviceURL==null || serviceURL.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
				serviceURL=dbService.getWSDLURL(ReceiptConstants.ACCOUNTSERVICE_ID,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
		}
			if (proposalNo== null){
				proposalNo = "";
			}
		AccountService_Service accService=new AccountService_Service(new URL(serviceURL));
		accServClient=accService.getSOAPOverHTTP();
		/*Added By Ketan To Check Logs*/
		Client client=ClientProxy.getClient(accServClient);
		PrintWriter writer = new PrintWriter(System.out);
		
		client.getOutInterceptors().add(new CdataWriterInterceptor());
		
		client.getInInterceptors().add(new LoggingInInterceptor(writer));
		
		client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
		GetHTMLReport2 getHTMLReport2 = new GetHTMLReport2();
		getHTMLReport2.setReceiptNo(receiptNo);
		getHTMLReport2.setUserId(userId);
        getHTMLReport2.setPassword(password);
        getHTMLReport2.setStrProposalNo(proposalNo);
        
        //if(logger.isDebugEnabled())logger.debug("About To Call getHTMLReport() Method.................");
		GetHTMLReportResponse2 getHTMLReportResponse2 = accServClient.getHTMLReport(getHTMLReport2); 
		//if(logger.isDebugEnabled())logger.debug("Call to getHTMLReport() Method Completed.............");
		if (getHTMLReportResponse2 != null) {
			if (getHTMLReportResponse2.getReturn() != null) {
				retVal = getHTMLReportResponse2.getReturn().getRetVal();
				receiptDataByteArr = retVal.getBytes(); //encoding  byte array into base 64
				}
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}	
		
		return receiptDataByteArr;
	}
	
	
	// 1704 : Vishal J | New method added for getting byte[] for renewal notice email attachment | Start
	@Override
	//@Async
	public byte[] printRenewalNoticeAttachment(String policyNo, String userId, String password)throws Exception {
		// TODO Auto-generated method stub
		// Old Method Code		
		String wsdlUrl=null;
		String strMethodName="printRenewalPolicyLetter";
		String retVal = "";
		byte[] retValEncoded = null;	//encode data using BASE64
		try {
			logger.info("Inside TagicCommonServiceImpl :: "+strMethodName+"method :: Entered ::");
			
			wsdlUrl = getWSDLURL(CommonConstants.PRINT_PROP_POL_DOCUMENT_SERVICE);
			URL serviceUrl=new URL(wsdlUrl);
			ObjectMapper objMap = new ObjectMapper();
			
			//if(logger.isDebugEnabled())logger.debug("Inside TagicCommonServiceImpl :: "+strMethodName+" method :: Recieved policy No:: "+policyNo);
		
			QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/GetDocumentForPortalService/", "GetDocumentForPortalService");
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service ss = new com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service(serviceUrl, SERVICE_NAME);
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService port = ss.getSOAPOverHTTP();
			
			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(port);
		
			/*Added By Ketan To Check Logs*/
		
			/*Client client=ClientProxy.getClient(ss);
			PrintWriter writer = new PrintWriter(System.out);
		
			client.getOutInterceptors().add(new CdataWriterInterceptor());
		
			client.getInInterceptors().add(new LoggingInInterceptor(writer));
		
			client.getOutInterceptors().add(new LoggingOutInterceptor(writer));*/
			/*Added By Ketan To Check Logs*/
			if(policyNo != null){
				GetRenewalLetterForPortal renewalLetterForPortal  = new GetRenewalLetterForPortal();
				com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData userData = new com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData();
				if(policyNo!= null && !policyNo.equalsIgnoreCase(""))
					userData.setPolicyNumber(policyNo);									
				if(userId!= null && !userId.equalsIgnoreCase(""))
					userData.setUserId(userId);
												
				ServiceResult serviceResult = new ServiceResult();
				serviceResult.setUserData(userData);							
				
				renewalLetterForPortal.setObjServiceResult(serviceResult);
																		
				GetRenewalLetterForPortalResponse getRenewalLetterForPortalResponse = null;
				//if(logger.isDebugEnabled())logger.debug("About To Call port.getRenewalLetterForPortal() Method.................");
				renewalLetterForPortal.setCampaign(smc_campaign);
				renewalLetterForPortal.setMedium(smc_medium);
				renewalLetterForPortal.setSource(smc_source);
				getRenewalLetterForPortalResponse = port.getRenewalLetterForPortal(renewalLetterForPortal);
			 
			
				//if(logger.isDebugEnabled())logger.debug("Call to portgetRenewalLetterForPortal() Method.................");
				if (getRenewalLetterForPortalResponse != null) {
					if (getRenewalLetterForPortalResponse.getGetRenewalLetterForPortalResult() != null && !getRenewalLetterForPortalResponse.getGetRenewalLetterForPortalResult().equalsIgnoreCase("")) {
						retVal  = getRenewalLetterForPortalResponse.getGetRenewalLetterForPortalResult();
						
						retValEncoded = retVal.getBytes(); //encoding  byte array into base 64
						//if(logger.isDebugEnabled())logger.debug("getRetVal Original String: " + retVal + " & Encoded String: " + new String(retValEncoded ));													
					}
				}
			}
						
		} catch (Exception e) {
			
			e.printStackTrace();
			
		}	
		
		return retValEncoded;
		// Old Method Code
		
	}
	// 1704 : Vishal J | New method added for getting byte[] for renewal notice email attachment | End	
	
	public RenewalCalCountResponse getRenewalCalCount(RenewalCalCountRequest renewalCalCountRequest) throws Exception{
		
		RenewalCalCountResponse renewalCalCountResponse=null;
		String strMethodName="getRenewalCalCount";
		ArrayList<RenewalCalCountData> renewalCalCountDataList=new ArrayList<RenewalCalCountData>();
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			String serviceUrl=getWSDLURL(CommonConstants.GENERIC_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			GenericIntegration_Service genericService=new GenericIntegration_Service(wsdlUrl);
			GenericIntegration port=genericService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);
			
			String _dailyConvertPendingGetObjectData_source = smc_source;
	        String _dailyConvertPendingGetObjectData_medium = smc_medium;
	        String _dailyConvertPendingGetObjectData_campaingn = smc_campaign;
	        String _dailyConvertPendingGetObjectData_strLVTokenID = "";
	        String _dailyConvertPendingGetObjectData_strFromDate = "";
	        String _dailyConvertPendingGetObjectData_strToDate = "";
	        String _dailyConvertPendingGetObjectData_strProducerCode = "";
	        RenewalCalCountData renewalCalCountData=null;
	        
	        if(renewalCalCountRequest!=null){
	        	if(renewalCalCountRequest.getProducerCode()!=null && !renewalCalCountRequest.getProducerCode().equals(CommonConstants.BLANK_STRING)){
	        		_dailyConvertPendingGetObjectData_strProducerCode=renewalCalCountRequest.getProducerCode();
	        	}
	        	
	        	if(renewalCalCountRequest.getFromDate()!=null && !renewalCalCountRequest.getFromDate().equals(CommonConstants.BLANK_STRING)){
	        		_dailyConvertPendingGetObjectData_strFromDate=renewalCalCountRequest.getFromDate();
	        	}
	        	
	        	if(renewalCalCountRequest.getToDate()!=null && !renewalCalCountRequest.getToDate().equals(CommonConstants.BLANK_STRING)){
	        		_dailyConvertPendingGetObjectData_strToDate=renewalCalCountRequest.getToDate();
	        	}
	        	if(renewalCalCountRequest.getAuthToken()!=null && !renewalCalCountRequest.getAuthToken().equals(CommonConstants.BLANK_STRING))
	        	_dailyConvertPendingGetObjectData_strLVTokenID=renewalCalCountRequest.getAuthToken();
	        }
	        
	        com.unotechsoft.stub.commonservice.generic.client.ServiceResult _dailyConvertPendingGetObjectData__return = port.dailyConvertPendingGetObjectData(_dailyConvertPendingGetObjectData_source, _dailyConvertPendingGetObjectData_medium, _dailyConvertPendingGetObjectData_campaingn, _dailyConvertPendingGetObjectData_strLVTokenID, _dailyConvertPendingGetObjectData_strFromDate, _dailyConvertPendingGetObjectData_strToDate, _dailyConvertPendingGetObjectData_strProducerCode);
	        
	        if(_dailyConvertPendingGetObjectData__return!=null){
	        	if(_dailyConvertPendingGetObjectData__return.getUserData()!=null){
	        		ClsUserData clsUserData=_dailyConvertPendingGetObjectData__return.getUserData();
	        		renewalCalCountResponse=new RenewalCalCountResponse();
	        		ArrayOfclsDailyConvertPendingGrid arrayOfclsDailyConvertPendingGrid=clsUserData.getDailyConvertPendingGrid();
	        		
	        		if(arrayOfclsDailyConvertPendingGrid!=null && arrayOfclsDailyConvertPendingGrid.getClsDailyConvertPendingGrid()!=null && arrayOfclsDailyConvertPendingGrid.getClsDailyConvertPendingGrid().size()>0){
	        			ArrayList<ClsDailyConvertPendingGrid> clsDailyConvertPendingGridList=(ArrayList<ClsDailyConvertPendingGrid>)arrayOfclsDailyConvertPendingGrid.getClsDailyConvertPendingGrid();
	        			//ClsDailyConvertPendingGrid clsDailyConvertPendingGrid=null;
	        			for(ClsDailyConvertPendingGrid clsDailyConvertPendingGrid : clsDailyConvertPendingGridList){	        				
	        				if(clsDailyConvertPendingGrid!=null){
	        				renewalCalCountData = new RenewalCalCountData();
	        				renewalCalCountData.setConvertedCount(clsDailyConvertPendingGrid.getConverted());
	        				renewalCalCountData.setPendingCount(clsDailyConvertPendingGrid.getPending());
	        				renewalCalCountData.setPolicyDate(clsDailyConvertPendingGrid.getPolicyDate());
	        				renewalCalCountDataList.add(renewalCalCountData);
	        				}
	        			}	        				        			        	
	        		}
	        		
	        		renewalCalCountResponse.setRenewalCalCountDataList(renewalCalCountDataList);
	        		renewalCalCountResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
	        		
	        	}
	        }
			
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: getRenewalCalCount() method ::Exception::",ex);
			renewalCalCountResponse=new RenewalCalCountResponse();
			renewalCalCountResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			renewalCalCountResponse.setMessage(ex.getMessage());
		}
		return renewalCalCountResponse;
	}


	public RenewalSearchResponse getRenewalSearch(RenewalSearchRequest renewalSearchRequest) throws Exception {
		RenewalSearchResponse renewalSearchResponse=null;
		String strMethodName="getRenewalSearch";
		ObjectMapper objMap = null;
		long transId = System.nanoTime();
		ArrayList<RenewalSearchData> renewalSearchDataList=new ArrayList<RenewalSearchData>();
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			
			
			String serviceUrl=getWSDLURL(CommonConstants.GENERIC_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			GenericIntegration_Service genericService=new GenericIntegration_Service(wsdlUrl);
			GenericIntegration port=genericService.getSOAPOverHTTP();
			
			objMap = new ObjectMapper();
			//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::JSON Request :- "+objMap.writeValueAsString(renewalSearchRequest));
			
			String _misDetailSearchGetObjectData_source = smc_source;
	        String _misDetailSearchGetObjectData_medium = smc_medium;
	        String _misDetailSearchGetObjectData_campaingn = smc_campaign;
	        String _misDetailSearchGetObjectData_strLVTokenID = "";
	        String _misDetailSearchGetObjectData_strFromDate = "";
	        String _misDetailSearchGetObjectData_strToDate = "";
	        String _misDetailSearchGetObjectData_strProducerCode = "";
	        
	        MisDetailSearchGetObjectData misDetailSearchGetObjectData = new MisDetailSearchGetObjectData();
	        
	        RenewalSearchData renewalSearchData=null;
	        
	        
	        /*if(renewalSearchRequest!=null){
	        	if(renewalSearchRequest.getProducerCode()!=null && !renewalSearchRequest.getProducerCode().equals(CommonConstants.BLANK_STRING)){
	        		_misDetailSearchGetObjectData_strProducerCode=renewalSearchRequest.getProducerCode();
	        	}
	        	if(renewalSearchRequest.getFromDate()!=null && !renewalSearchRequest.getFromDate().equals(CommonConstants.BLANK_STRING)){
	        		_misDetailSearchGetObjectData_strFromDate =renewalSearchRequest.getFromDate();
	        	}
	        	
	        	
	        	if(renewalSearchRequest.getToDate()!=null && !renewalSearchRequest.getToDate().equals(CommonConstants.BLANK_STRING)){
	        		_misDetailSearchGetObjectData_strToDate=renewalSearchRequest.getToDate();
	        	}
	        	if(renewalSearchRequest.getAuthToken()!=null && !renewalSearchRequest.getAuthToken().equals(CommonConstants.BLANK_STRING)){
	        		_misDetailSearchGetObjectData_strLVTokenID=renewalSearchRequest.getAuthToken();
	        	}
	        }*/ /*Commented As New WSDL Changes On 16/02/2017*/
	        
	        if(renewalSearchRequest!=null){
	        	misDetailSearchGetObjectData.setSource(smc_source);
	        	misDetailSearchGetObjectData.setMedium(smc_medium);
	        	misDetailSearchGetObjectData.setCampaingn(smc_campaign);
	        	
	        	misDetailSearchGetObjectData.setStrLVTokenID(renewalSearchRequest.getAuthToken() == null ? "":renewalSearchRequest.getAuthToken());
	        		        	
	        	misDetailSearchGetObjectData.setStrFromDate(renewalSearchRequest.getFromDate() == null ? "" :renewalSearchRequest.getFromDate());
	        		        	
	        	misDetailSearchGetObjectData.setStrToDate(renewalSearchRequest.getToDate() == null ? "" : renewalSearchRequest.getToDate());
	        	
	        	
	        	misDetailSearchGetObjectData.setStrCustomerID(renewalSearchRequest.getStrCustomerID() == null ? "":renewalSearchRequest.getStrCustomerID());
	        		        	
	        	misDetailSearchGetObjectData.setStrCustomerName(renewalSearchRequest.getStrCustomerName()== null ? "" : renewalSearchRequest.getStrCustomerName());
	        		        	
	        	misDetailSearchGetObjectData.setStrLOB(renewalSearchRequest.getStrLOB() == null ? "" : renewalSearchRequest.getStrLOB());
	        		        	
	        	misDetailSearchGetObjectData.setStrProductCode(renewalSearchRequest.getStrProductCode() == null ? "": renewalSearchRequest.getStrProductCode());
	        	
	        	misDetailSearchGetObjectData.setStrPolicyNo(renewalSearchRequest.getStrPolicyNo() == null ? "" : renewalSearchRequest.getStrPolicyNo());
	        		        	
	        	misDetailSearchGetObjectData.setStrPolicyInspectionDate(renewalSearchRequest.getStrPolicyInspectionDate() == null ? "" : renewalSearchRequest.getStrPolicyInspectionDate());
	        		        	
	        	misDetailSearchGetObjectData.setStrDOB(renewalSearchRequest.getStrDOB() == null ? "" : renewalSearchRequest.getStrDOB());
	        	
	        	misDetailSearchGetObjectData.setStrMobileNo(renewalSearchRequest.getStrMobileNo() == null ? "" : renewalSearchRequest.getStrMobileNo());
	        		        
	        	misDetailSearchGetObjectData.setStrAddOn(renewalSearchRequest.getStrAddOn() == null ? "" : renewalSearchRequest.getStrAddOn());
	        		        	
	        	misDetailSearchGetObjectData.setStrProducerCode(renewalSearchRequest.getProducerCode() == null ? "" : renewalSearchRequest.getProducerCode());
	        		        
	        	misDetailSearchGetObjectData.setStrUserId(renewalSearchRequest.getUserID() == null ? "" : renewalSearchRequest.getUserID());
	        	
	        }
	        
	        //com.unotechsoft.stub.commonservice.generic.client.ServiceResult _misDetailSearchGetObjectData__return = port.misDetailSearchGetObjectData(_misDetailSearchGetObjectData_source, _misDetailSearchGetObjectData_medium, _misDetailSearchGetObjectData_campaingn, _misDetailSearchGetObjectData_strLVTokenID, _misDetailSearchGetObjectData_strFromDate, _misDetailSearchGetObjectData_strToDate, _misDetailSearchGetObjectData_strProducerCode);	/*Commented As New WSDL Changes On 16/02/2017*/
	        ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(port);
			
			
			//START:Code changes for defect 29474 (App Support Tool Id): Done by Parvind
             misDetailSearchGetObjectData.setStrUserId(CommonConstants.BLANK_STRING); 
           //END:Code changes for defect 29474 (App Support Tool Id): Done by Parvind
             
			com.unotechsoft.stub.commonservice.generic.client.MisDetailSearchGetObjectDataResponse misDetailSearchGetObjectDataResponse = port.misDetailSearchGetObjectData(misDetailSearchGetObjectData);	
	        com.unotechsoft.stub.commonservice.generic.client.ServiceResult _misDetailSearchGetObjectData__return = misDetailSearchGetObjectDataResponse.getMISDetailSearch_GetObjectDataResult();
	        
	        if(_misDetailSearchGetObjectData__return!=null){
	        	if(_misDetailSearchGetObjectData__return.getUserData()!=null){
	        		ClsUserData clsUserData=_misDetailSearchGetObjectData__return.getUserData();
	        		renewalSearchResponse =new RenewalSearchResponse();
	        		ArrayOfclsMISDetailSearchGrid arrayOfclsMISDetailSearchGrid=clsUserData.getMISDetailSearchGrid();
	        		
	        		if(arrayOfclsMISDetailSearchGrid!=null && arrayOfclsMISDetailSearchGrid.getClsMISDetailSearchGrid()!=null && arrayOfclsMISDetailSearchGrid.getClsMISDetailSearchGrid().size()>0){
	        			ArrayList<ClsMISDetailSearchGrid> clsMISDetailSearchGridList=(ArrayList<ClsMISDetailSearchGrid>)arrayOfclsMISDetailSearchGrid.getClsMISDetailSearchGrid();
	        			//ClsDailyConvertPendingGrid clsDailyConvertPendingGrid=null;
	        			String lobCode,productCode="";
	        			for(ClsMISDetailSearchGrid clsMISDetailSearchGrid : clsMISDetailSearchGridList){	        				
	        				if(clsMISDetailSearchGrid!=null){
	        				renewalSearchData = new RenewalSearchData();
	        				renewalSearchData.setAddOn(clsMISDetailSearchGrid.getADDOn());
	        				renewalSearchData.setCustomerCode(clsMISDetailSearchGrid.getCustomerCode());
	        				renewalSearchData.setCustomerName(clsMISDetailSearchGrid.getCustomerName());
	        				renewalSearchData.setDob(clsMISDetailSearchGrid.getDOB());
	        				if(clsMISDetailSearchGrid.getLOB()!=null){
	        					renewalSearchData.setLob(clsMISDetailSearchGrid.getLOB());
	        					
	        					/*lobCode=dbService.getReverseExternalMapCode(null, CommonConstants.Renewal_Search_LobCode_Cat, clsMISDetailSearchGrid.getLOB());
	        					if(lobCode!=null)
	        					renewalSearchData.setLobCode(lobCode);*/
	        				}	        				
	        				renewalSearchData.setMobileNo(clsMISDetailSearchGrid.getMobileNo());
	        				renewalSearchData.setPolicyInsDate(clsMISDetailSearchGrid.getPolicyInsDate());
	        				renewalSearchData.setPolicyNo(clsMISDetailSearchGrid.getPolicyNo());
	        				if(clsMISDetailSearchGrid.getProductName() != null){
	        					renewalSearchData.setProductName(clsMISDetailSearchGrid.getProductName());	        					
	        					productCode=dbService.getReverseExternalMapCode(null, CommonConstants.Renewal_Search_ProductCode_Cat, clsMISDetailSearchGrid.getProductName());
	        					if(productCode!=null)
	        					renewalSearchData.setProductCode(productCode);
	        				}
	        				//Start : 21/03/2017: To send productName in JSON Response. 
                            String strval="";
                            
                            List<Product> oComProductList =  (List<Product>) dbService.getProduct("com.majesco.dcf.common.tagic.entity.Product","strprodcd",productCode);
                            if(oComProductList.size()>0){
                            	for(Product productList:oComProductList){	                            		                                  
	                                  strval = productList.getStrprodname()!=null?productList.getStrprodname().toString():"";
	                                
	                            }	
                            }	                              
                            //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getRenewalSearch  :: Fetching Product Name To Go In Response"+strval);
                            renewalSearchData.setProductName(strval);	
                          //End : 21/03/2017: To send productName in JSON Response.
	        				
	        				
	        				
	        				renewalSearchData.setRenewalStatus(clsMISDetailSearchGrid.getRenewalStatus());
	        				renewalSearchData.setTotalPremium(clsMISDetailSearchGrid.getTotalPremium());
	        				renewalSearchData.setVehRegNo(clsMISDetailSearchGrid.getVehRegNo());	/*Below && productCode is added for time being to skip other products except private car*/
	        				//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getRenewalSearch  ProductCode**"+productCode+"**");
	        				//if(clsMISDetailSearchGrid.getRenewalStatus().equalsIgnoreCase("Pending") && productCode!=null && (productCode.equalsIgnoreCase(CommonConstants.PRIVATE_CAR_PRODUCT_CODE) || productCode.equalsIgnoreCase(CommonConstants.TWO_WHEELER_PRODUCT_CODE)))  // added to fetch only pending details //Commented For Issue ID 1679
	        				if(clsMISDetailSearchGrid.getRenewalStatus().equalsIgnoreCase("Pending") && productCode!=null && (productCode.equalsIgnoreCase(CommonConstants.PRIVATE_CAR_PRODUCT_CODE) || productCode.equalsIgnoreCase(CommonConstants.TWO_WHEELER_PRODUCT_CODE) || productCode.equalsIgnoreCase(CommonConstants.COMMERCIAL_PRODUCT_CODE)))  // added to fetch only pending details //Added For Issue ID 1679
	        					renewalSearchDataList.add(renewalSearchData);
	        				}
	        			}	        				        			        	
	        		}	        		
	        		renewalSearchResponse.setRenewalSearchDataList(renewalSearchDataList);
	        		renewalSearchResponse.setResultCode(CommonConstants.SUCCESS_STATUS);	        		
	        	}
	        }
			
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: "+strMethodName+" method ::Exception::",ex);
			renewalSearchResponse=new RenewalSearchResponse();
			renewalSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			renewalSearchResponse.setMessage(ex.getMessage());	
		}

		logger.info("RenewalSearchResponse :- ## "+objMap.writeValueAsString(renewalSearchResponse));

		return renewalSearchResponse;
		
	}
	
	// Service to get Dealer Info :  Start
	
	public UserInfoResponse getDealerInfo(@RequestBody UserObject userObject){
		UserInfoResponse userInfoResponse=null;
		userInfoResponse=new UserInfoResponse();   
		String strMethodName="getDealerInfo";
		ObjectMapper objMap = null;		

		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			String serviceUrl=getWSDLURL(CommonConstants.GENERIC_COVERNOTE_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			
			GenericSerive_Service genericService=new GenericSerive_Service(wsdlUrl);
			GenericSerive port=genericService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			objMap = new ObjectMapper();
			serviceUtil.addClientInterceptor(port);
			
			Dealer dealer = new Dealer();
			dealer.setDealerCode(userObject.getUserID());
			
			if(userObject != null){								
				dealer.setDealerCode(userObject.getUserID());								
			}
			
			com.unotechsoft.stub.genericservice.client.GenericResult dealerResponse = port.getDealer(smc_source, smc_medium,smc_campaign, "", dealer);
			if(dealerResponse!=null){
				com.unotechsoft.stub.genericservice.client.ArrayOfLOVType arrayOfLOVType= dealerResponse.getLOVTypes();
				if(arrayOfLOVType!=null){
                    List<com.unotechsoft.stub.genericservice.client.LOVType> LOVTypeList= arrayOfLOVType.getLOVType();
                    
                    if(LOVTypeList!=null && LOVTypeList.size()>0){
                          LOVTypeDealer LOVTypeDealer=(LOVTypeDealer)LOVTypeList.get(0);                          
                          if(LOVTypeDealer!=null){                        	  
                        	  UserDetails userDetails=new UserDetails();
                        	  userDetails.setProducerCode(LOVTypeDealer.getProducerCode());
                        	  userDetails.setDealerCode(LOVTypeDealer.getDealerCode());	//Code Added Against Defect ID 273 - Ketan
                        	  userDetails.setDealerName(LOVTypeDealer.getDealerName());	//Code Added Against Defect ID 273 - Ketan
                        	  userInfoResponse.setUserInfoDetails(userDetails);                         
                        	  userInfoResponse.setResultCode(CommonConstants.SUCCESS_STATUS); 
                          }
                        	 
                       }
                    }
             }

			}catch(Exception ex){
				logger.error("Inside TagicCommonServiceImpl :: "+strMethodName+" method ::Exception::",ex);
				userInfoResponse=new UserInfoResponse();
				userInfoResponse.setResultCode(CommonConstants.FAILURE_STATUS);
				userInfoResponse.setMessage(ex.getMessage());	
			}						
		return userInfoResponse;
	}
	// Service to get Dealer Info :  End
	
	
		// Service to GetRenewalLetterForPortal : Start
	
		public RenewalPolLetterResponse printRenewalPolicyLetter(@RequestBody RenewalPolLetterRequest renewLetReq)throws Exception {
			// TODO Auto-generated method stub
			
			RenewalPolLetterResponse renPolLetResp = new RenewalPolLetterResponse();
			String wsdlUrl=null;
			String strMethodName="printRenewalPolicyLetter";
			String retVal = "";
			byte[] retValEncoded;	//encode data using BASE64
			try {
				logger.info("Inside TagicCommonServiceImpl :: "+strMethodName+"method :: Entered ::");
				
				wsdlUrl = getWSDLURL(CommonConstants.PRINT_PROP_POL_DOCUMENT_SERVICE);
				URL serviceUrl=new URL(wsdlUrl);
				ObjectMapper objMap = new ObjectMapper();
				
				//if(logger.isDebugEnabled())logger.debug("Inside TagicCommonServiceImpl :: "+strMethodName+" method :: Request Received JSON :: "+objMap.writeValueAsString(renewLetReq));
			
				QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/GetDocumentForPortalService/", "GetDocumentForPortalService");
				com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service ss = new com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service(serviceUrl, SERVICE_NAME);
				com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService port = ss.getSOAPOverHTTP();
				
				ServiceUtility util=new ServiceUtility();
				util.addClientInterceptor(port);
			
				/*Added By Ketan To Check Logs*/
			
				/*Client client=ClientProxy.getClient(ss);
				PrintWriter writer = new PrintWriter(System.out);
			
				client.getOutInterceptors().add(new CdataWriterInterceptor());
			
				client.getInInterceptors().add(new LoggingInInterceptor(writer));
			
				client.getOutInterceptors().add(new LoggingOutInterceptor(writer));*/
				/*Added By Ketan To Check Logs*/
				if(renewLetReq != null){
					GetRenewalLetterForPortal renewalLetterForPortal  = new GetRenewalLetterForPortal();
					com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData userData = new com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUserData();
					if(renewLetReq.getPolicyNumber()!= null && !renewLetReq.getPolicyNumber().equalsIgnoreCase(""))
						userData.setPolicyNumber(renewLetReq.getPolicyNumber());									
					if(renewLetReq.getUserID()!= null && !renewLetReq.getUserID().equalsIgnoreCase(""))
						userData.setUserId(renewLetReq.getUserID());
													
					ServiceResult serviceResult = new ServiceResult();
					serviceResult.setUserData(userData);							
					
					renewalLetterForPortal.setObjServiceResult(serviceResult);
																			
					GetRenewalLetterForPortalResponse getRenewalLetterForPortalResponse = null;
					//if(logger.isDebugEnabled())logger.debug("About To Call port.getRenewalLetterForPortal() Method.................");
					renewalLetterForPortal.setCampaign(smc_campaign);
					renewalLetterForPortal.setMedium(smc_medium);
					renewalLetterForPortal.setSource(smc_source);
					getRenewalLetterForPortalResponse = port.getRenewalLetterForPortal(renewalLetterForPortal);
				 
				
					//if(logger.isDebugEnabled())logger.debug("Call to portgetRenewalLetterForPortal() Method.................");
					if (getRenewalLetterForPortalResponse != null) {
						if (getRenewalLetterForPortalResponse.getGetRenewalLetterForPortalResult() != null && !getRenewalLetterForPortalResponse.getGetRenewalLetterForPortalResult().equalsIgnoreCase("")) {
							retVal  = getRenewalLetterForPortalResponse.getGetRenewalLetterForPortalResult();
							
							retValEncoded = Base64.encodeBase64(retVal.getBytes()); //encoding  byte array into base 64
							//if(logger.isDebugEnabled())logger.debug("getRetVal Original String: " + retVal + " & Encoded String: " + new String(retValEncoded ));
							renPolLetResp.setStrRenewalLetter(new String(retValEncoded));
							renPolLetResp.setPolicyNumber(getRenewalLetterForPortalResponse.getObjServiceResult().getUserData().getPolicyNumber()==null ? "":getRenewalLetterForPortalResponse.getObjServiceResult().getUserData().getPolicyNumber());							
						}
					}
				}
							
			} catch (Exception e) {
				
				e.printStackTrace();
				
			}	
			
			return renPolLetResp;
		}		
	// Service to GetRenewalLetterForPortal : End			



	@Override
	public PendingPropListResponse getPendingProposalList(
			PendingPropListRequest pendingPropListRequest) throws Exception {
		
		PendingPropListResponse propListResponse = new PendingPropListResponse();
				
		String strMethodName="getPendingProposalList";
		ObjectMapper objMap = null;		
		try{			
			logger.info("Inside TagicCommonServiceImpl :: "+strMethodName+" method :: Entered ::");
			String serviceUrl=getWSDLURL(CommonConstants.GENERIC_COVERNOTE_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			GenericSerive_Service genericService=new GenericSerive_Service(wsdlUrl);
			GenericSerive port=genericService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			objMap = new ObjectMapper();
			serviceUtil.addClientInterceptor(port);			
			
			GetPendingProposalList pendingProposalList = new GetPendingProposalList();
			
			GenericResult genericResult = null;
			StopWatch watch = new StopWatch();
			watch.start();
			genericResult = port.getPendingProposalList(smc_source, smc_medium, smc_campaign, "", pendingPropListRequest.getEntityType(), pendingPropListRequest.getEntityCode(), 
										"", "", "", "", "", pendingPropListRequest.getProposalNo(), "", "", "", "", "");
			watch.stop();
			logger.info("Time Taken by getPendingProposalList service in seconds..>>"+watch.getTotalTimeSeconds());
			if(genericResult!=null){
				com.unotechsoft.stub.genericservice.client.ArrayOfLOVType arrayOfLOVType= genericResult.getLOVTypes();
				
				if(arrayOfLOVType!=null){
					List<com.unotechsoft.stub.genericservice.client.LOVType> listLOVType= arrayOfLOVType.getLOVType();
                    
                         if(listLOVType!=null && listLOVType.size()>0){
                          LOVTypePolicyDetail lovTypePolicyDetail=(LOVTypePolicyDetail)listLOVType.get(0);                          
                          if(lovTypePolicyDetail!=null){                        	  
                        	  propListResponse.setTransactionType(lovTypePolicyDetail.getTransactionType());
                        	  propListResponse.setDeclinedStatus(lovTypePolicyDetail.getDeclinedStatus());
                        	  
                        	  
                        	  String strPropDesc=dbService.getCodeDesc(null, lovTypePolicyDetail.getDeclinedStatus(), "1097", "1");
                        	  propListResponse.setDeclinedStatusDesc(strPropDesc);
                        	  propListResponse.setResultCode(CommonConstants.SUCCESS_STATUS); 
                          }
                        	 
                       }
                    }
             }												
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: "+strMethodName+" method ::Exception::",ex);
			propListResponse=new PendingPropListResponse();
			propListResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			propListResponse.setMessage(ex.getMessage());	
		}						
		return propListResponse;
	}
	
	@Override
	public String getProposalNoByPolicyNo(String  policyNumber,String productCode,String userId,String password,String authToken) 
	{
		
		long transId = System.nanoTime();
        logger.info("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method :: Execution Started");
        
        propValue="";               
        if(propValue.equalsIgnoreCase(""))
			propValue = this.getWSDLURL(CommonConstants.POLICY_SEARCH);
        
        List<ResponseError> reserrList; 
        
        reserrList = new ArrayList<ResponseError>();
        ResponseError res = new ResponseError();
        
        JAXBXMLHandler jaxbHandler=new JAXBXMLHandler();
        String jaxbXML = "";
        
        HashMap constantMap = new HashMap();
        
        
        try
        {
               ObjectMapper objMapper = new ObjectMapper();
               //if(logger.isDebugEnabled())logger.debug("Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method :: Recieved PolicyNo :: " + policyNumber);
               
               
               try{
            	   	
            	   com.majesco.dcf.motor.jaxb.policy.request.GetPolicyDetailByPolicyNo p2DtoReq = new com.majesco.dcf.motor.jaxb.policy.request.GetPolicyDetailByPolicyNo();
            	   URL url = new URL(propValue);
            	   com.unotechsoft.stub.policysearch.client.SearchStubService_Service stub = new com.unotechsoft.stub.policysearch.client.SearchStubService_Service(url);

            	   if(policyNumber != null && !policyNumber.equalsIgnoreCase("")){
            		   p2DtoReq.setStrPolicyNo(policyNumber);
            	   }
            		   
            	   jaxbXML=JAXBXMLHandler.marshal(p2DtoReq);
            	   //if(logger.isDebugEnabled())logger.debug("Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method :: JAXB XML :: "+jaxbXML);
       			   
       			     //Getting Authentication Token Starts Here
                     String propFileName = "resource.properties";
                     
                     String responseFrom = "";
                     Properties prop = new Properties();
                     InputStream inputStream = MotorServiceImpl.class.getClassLoader().getResourceAsStream(propFileName);
                     prop.load(inputStream);
                     
                     responseFrom=prop.getProperty("ResponseFrom");
                     
                     com.unotechsoft.stub.policysearch.client.QuotationRequest reqQ = new com.unotechsoft.stub.policysearch.client.QuotationRequest();
                     
                     
                     //Start:Vishal<VAPT comments>| code added to set GC token into user object 
         			 if (authToken!=null ){
         			 	reqQ.setAuthenticationToken(authToken);
         			 }
         			 else{
         			 	AuthenticationResponse authRes = authServ.getAuthenticationTokenTest(smc_source, smc_medium, smc_campaign, userId, password);
         				/*Getting Authentication Token Stops Here*/	
         				reqQ.setAuthenticationToken(authRes.getResultRes());
         			 }
         			 //End:Vishal<VAPT comments>| code added to set GC token into user object                     
                     
                     reqQ.setSource(smc_source);
                     reqQ.setProductCode(productCode);
     				 reqQ.setModeOfOperation("NEWPOLICY");
                     reqQ.setCampaign(smc_campaign);
                     reqQ.setMedium(smc_medium);
                     reqQ.setCIAName("");
                     reqQ.setHashKey("");
                     reqQ.setHostAddress("");
                     reqQ.setInputXML(jaxbXML);
                     reqQ.setIsBankDataRequired(false);
                     reqQ.setIsCutomerAddressRequired(false);
                     reqQ.setIsFinanciarDataRequired(false);
                     reqQ.setIsManufacturerMappingRequired(false);
                     reqQ.setIsRTOMappingRequired(false);
                     reqQ.setUserId(userId);
     				 reqQ.setUserRole("ADMIN");
                     
     				 com.unotechsoft.stub.policysearch.client.SearchStubService port = stub.getSOAPOverHTTP();
     				
                     Client client=ClientProxy.getClient(port);
                     PrintWriter writer = new PrintWriter(System.out);                     
                     client.getOutInterceptors().add(new CdataWriterInterceptor());
                     client.getInInterceptors().add(new LoggingInInterceptor(writer));
                     client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
                     
                     //if(logger.isDebugEnabled())logger.debug("Inside TagicCommonServiceImpl :- Requesting For GetPolicyDetailByPolicyNoPrvtCar()");
                     com.unotechsoft.stub.policysearch.client.GenericResult genericResult = port.getPolicyDetailByPolicyNo(reqQ);
                     //if(logger.isDebugEnabled())logger.debug("Inside TagicCommonServiceImpl :- Response Recieved GetPolicyDetailByPolicyNoPrvtCar()");
                     
                     com.unotechsoft.stub.policysearch.client.LOVTypePolicyDetail respObj;
                     List<LOVType> lovTypeList = genericResult.getLOVTypes().getLOVType();
                     com.unotechsoft.stub.policysearch.client.LOVTypePolicyDetail response = (com.unotechsoft.stub.policysearch.client.LOVTypePolicyDetail) lovTypeList.get(0);                    
                     if (response != null) 
                     {
                    	 //if(logger.isDebugEnabled())logger.debug("GetPolicyDetailByPolicyNoPrvtCar :: response.getProposalNo(): " + response.getProposalNo());                    	                     	 
                    	 return response.getProposalNo();
					 }
                     else
                     {                    	 		    					
	    					return null;
                     }                  
               }catch(MalformedURLException mex)
               {
                     //logger.info("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method : MalformedURLException :: "+mex);
                     logger.error("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method : MalformedURLException :: "+mex.getStackTrace());
                                          
               }
               catch(SocketTimeoutException stex)
               {
                     //logger.info("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method : SocketTimeoutException :: "+stex);
                     logger.error("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method : SocketTimeoutException :: "+stex.getStackTrace());
                     
               }
               catch(Exception ex)
               {
                     //logger.info("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method ::",ex);
                     logger.error("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method ::",ex);                     
               }
 
        }catch(Exception ex)
        {
               //logger.info("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method ::",ex);           
               logger.error("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method ::",ex);                                                                        
        }
        logger.info("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getProposalNoByPolicyNo() method :: Execution Completed");
        return null;
	}



	@Override
	public AgentDashBoardResponse dashBoardSPLPendingList(AgentDashBoardRequest agentDashBoardRequest) throws Exception {
		
		AgentDashBoardResponse agentDashBoardResponse=null;
		ProposalSearchRequest proposalSearchRequest=null;
		SPLExpiredList payLinkExpiredList = null;
		String strMethodName="dashBoardSPLPendingList";
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			agentDashBoardResponse=new AgentDashBoardResponse();
				
			ArrayList<DashBoardSummaryDetails> dashBoardSPLExpiredtList=new ArrayList<DashBoardSummaryDetails>();
			ArrayList<Object[]> resultDataSPL = new ArrayList<Object[]>();
			payLinkExpiredList = new SPLExpiredList();
			resultDataSPL = dbService.getSPLExpiredData();
			for(Object[] rowSPL : resultDataSPL)
			{
				DashBoardSummaryDetails response = new DashBoardSummaryDetails();
					
				response.setProposalNumber((String) nullCheckString(rowSPL[0])); 
		        response.setCustomerName((String) nullCheckString(rowSPL[1]));
		        response.setProductCode((String) nullCheckString(rowSPL[2]));
		        response.setTotalPremium((String) nullCheckString(rowSPL[3]));
		        response.setProposalStatus((String) nullCheckString(rowSPL[4]));
		        response.setStatusDesc("Expired");
		        Date dtCreated = (Date)rowSPL[5];
		        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		        response.setCreatedDate(sdf.format(dtCreated));   // Added on 25/02/2017
					
		        dashBoardSPLExpiredtList.add(response);
			}
			if(dashBoardSPLExpiredtList!=null)
				payLinkExpiredList.setNoOfPayLinkExpired(dashBoardSPLExpiredtList.size());
			
			payLinkExpiredList.setDashBoardPayLinkExp(dashBoardSPLExpiredtList);	
			agentDashBoardResponse.setPayLinkExpiredList(payLinkExpiredList);
			logger.info("Inside "+_strClassName+"::"+strMethodName+":: SPL Expired Count::: "+dashBoardSPLExpiredtList.size()+" ::: Exit");
			
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: dashBoardPendingList() method ::Exception::",ex);
			agentDashBoardResponse=new AgentDashBoardResponse();
			agentDashBoardResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			agentDashBoardResponse.setMessage(ex.getMessage());
		}
		//logger.info("Inside "+_strClassName+"::"+strMethodName+"::Response JSON :: "+objMap.writeValueAsString(agentDashBoardResponse));
		return agentDashBoardResponse;
	}
	
	public ProposalSearchResponse dashboardPendingsearchProposal(ProposalSearchRequest proposalSearchRequest) throws Exception{

		ProposalSearchResponse proposalSearchResponse=null;
		String strMethodName="searchProposal";
		ObjectMapper objMap=new ObjectMapper();
		HashMap  proposalStatusMap = new HashMap();
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
			String serviceUrl=getWSDLURL(CommonConstants.GENERIC_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			GenericIntegration_Service genericService=new GenericIntegration_Service(wsdlUrl);
			GenericIntegration port=genericService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);

			String _proposalSearchForPortalGetObjectData_source = smc_source;
			String _proposalSearchForPortalGetObjectData_medium = smc_medium;
			String _proposalSearchForPortalGetObjectData_campaingn = smc_campaign;
			
			String _proposalSearchForPortalGetObjectData_strLVTokenID = "";
			
			if(proposalSearchRequest.getAuthToken()!=null && !proposalSearchRequest.getAuthToken().equalsIgnoreCase("-1"))
				_proposalSearchForPortalGetObjectData_strLVTokenID=proposalSearchRequest.getAuthToken();
			
			String _proposalSearchForPortalGetObjectData_strProposalNo = "";

			if(proposalSearchRequest.getProposalNo()!=null)
				_proposalSearchForPortalGetObjectData_strProposalNo=proposalSearchRequest.getProposalNo();

			String _proposalSearchForPortalGetObjectData_strLOB = "";

			if(proposalSearchRequest.getLineOfBusiness()!=null)
				_proposalSearchForPortalGetObjectData_strLOB=proposalSearchRequest.getLineOfBusiness(); 
				//_proposalSearchForPortalGetObjectData_strLOB="";

			String _proposalSearchForPortalGetObjectData_strProductCode = "";
			if(proposalSearchRequest.getProductCode()!=null)
				_proposalSearchForPortalGetObjectData_strProductCode=proposalSearchRequest.getProductCode();

			String _proposalSearchForPortalGetObjectData_strVehRegdNo = "";
			if(proposalSearchRequest.getVehicleRegNo()!=null)
				_proposalSearchForPortalGetObjectData_strVehRegdNo=proposalSearchRequest.getVehicleRegNo();

			String _proposalSearchForPortalGetObjectData_strManualCoverNoteNo = "";
			if(proposalSearchRequest.getCoverNoteNo()!=null)
				_proposalSearchForPortalGetObjectData_strManualCoverNoteNo=proposalSearchRequest.getCoverNoteNo();

			String _proposalSearchForPortalGetObjectData_strCustomerID = "";
			if(proposalSearchRequest.getCustomerId()!=null)
				_proposalSearchForPortalGetObjectData_strCustomerID=proposalSearchRequest.getCustomerId();

			String _proposalSearchForPortalGetObjectData_strCustomerName = "";
			if(proposalSearchRequest.getCustomerName()!=null)
				_proposalSearchForPortalGetObjectData_strCustomerName=proposalSearchRequest.getCustomerName();

			String _proposalSearchForPortalGetObjectData_strDOB = "";
			if(proposalSearchRequest.getDateOfBirth()!=null)
				_proposalSearchForPortalGetObjectData_strDOB=proposalSearchRequest.getDateOfBirth();

			String _proposalSearchForPortalGetObjectData_strPartnerAppNo = "";
			if(proposalSearchRequest.getPartnerApplNo()!=null)
				_proposalSearchForPortalGetObjectData_strPartnerAppNo=proposalSearchRequest.getPartnerApplNo();

			String _proposalSearchForPortalGetObjectData_strCreatedDate = "";
			if(proposalSearchRequest.getCreateDate()!=null)
				_proposalSearchForPortalGetObjectData_strCreatedDate=proposalSearchRequest.getCreateDate();
			
			String _proposalSearchForPortalGetObjectData_strCreatedToDate = "";
			if(proposalSearchRequest.getCreateToDate()!=null)
				_proposalSearchForPortalGetObjectData_strCreatedToDate=proposalSearchRequest.getCreateToDate();

			String _proposalSearchForPortalGetObjectData_strProducerCode = "";
			if(proposalSearchRequest.getProducerCode()!=null)
				_proposalSearchForPortalGetObjectData_strProducerCode=proposalSearchRequest.getProducerCode(); 
//				_proposalSearchForPortalGetObjectData_strProducerCode="3051994444";

			String _proposalSearchForPortalGetObjectData_strUserId = "";
			//Start:06/01/2017:Commented as confirmed by ESB / GC team , user id to be sent blank.
			/*if(proposalSearchRequest.getUserID()!=null)
				_proposalSearchForPortalGetObjectData_strUserId=proposalSearchRequest.getUserID(); */
//				_proposalSearchForPortalGetObjectData_strUserId="3051994444";
			String _proposalSearchForPortalGetObjectData_strFlag = "";
			if(proposalSearchRequest.getFlag()!=null)
				_proposalSearchForPortalGetObjectData_strFlag=proposalSearchRequest.getFlag();

			StopWatch watch = new StopWatch();
			watch.start();
			com.unotechsoft.stub.commonservice.generic.client.ServiceResult _proposalSearchForPortalGetObjectData__return = port.proposalSearchForPortalGetObjectData(_proposalSearchForPortalGetObjectData_source, _proposalSearchForPortalGetObjectData_medium, _proposalSearchForPortalGetObjectData_campaingn, _proposalSearchForPortalGetObjectData_strLVTokenID, _proposalSearchForPortalGetObjectData_strProposalNo, _proposalSearchForPortalGetObjectData_strLOB, _proposalSearchForPortalGetObjectData_strProductCode, _proposalSearchForPortalGetObjectData_strVehRegdNo, _proposalSearchForPortalGetObjectData_strManualCoverNoteNo, _proposalSearchForPortalGetObjectData_strCustomerID, _proposalSearchForPortalGetObjectData_strCustomerName, _proposalSearchForPortalGetObjectData_strDOB, _proposalSearchForPortalGetObjectData_strPartnerAppNo, _proposalSearchForPortalGetObjectData_strCreatedDate, _proposalSearchForPortalGetObjectData_strCreatedToDate, _proposalSearchForPortalGetObjectData_strProducerCode, _proposalSearchForPortalGetObjectData_strUserId, _proposalSearchForPortalGetObjectData_strFlag);
			watch.stop();
			logger.info("Time Taken by proposalSearchForPortalGetObjectData service in seconds..>>"+watch.getTotalTimeSeconds());
			if(_proposalSearchForPortalGetObjectData__return!=null){

				if(_proposalSearchForPortalGetObjectData__return.getUserData()!=null && _proposalSearchForPortalGetObjectData__return.getUserData().getProposalSearchForPortalGrid()!=null){
					ArrayOfclsProposalSearchForPortalGrid arrayOfclsProposalSearchForPortalGrid =_proposalSearchForPortalGetObjectData__return.getUserData().getProposalSearchForPortalGrid();
					if(arrayOfclsProposalSearchForPortalGrid!=null){
						ArrayList<ClsProposalSearchForPortalGrid> clsProposalSearchForPortalGridList = (ArrayList<ClsProposalSearchForPortalGrid>)arrayOfclsProposalSearchForPortalGrid.getClsProposalSearchForPortalGrid();
						if(clsProposalSearchForPortalGridList!=null){
							proposalSearchResponse=new ProposalSearchResponse();
							ArrayList<ProposalSearchResultDet> proposalSearchResultDetList=new ArrayList<ProposalSearchResultDet>();
							//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::Total Number of Proposal List::"+clsProposalSearchForPortalGridList.size());
							//Start: Added to retrieve All possible proposal stauts values from master table
							proposalStatusMap = dbService.getPropStatusDesc(1097);
							//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::Proposal Statuses extracted from DB::"+objMap.writeValueAsString(proposalStatusMap));
							//End: Added to retrieve All possible proposal status values from master table

							for(int i=0;i<clsProposalSearchForPortalGridList.size();i++){
								ClsProposalSearchForPortalGrid clsProposalSearchForPortalGrid=clsProposalSearchForPortalGridList.get(i);

								ProposalSearchResultDet proposalSearchResultDet=new ProposalSearchResultDet();
								proposalSearchResultDet.setProposalNo(nullCheckString(clsProposalSearchForPortalGrid.getProposalNumber()));
								proposalSearchResultDet.setProductCode(nullCheckString(clsProposalSearchForPortalGrid.getProductCode()));
								proposalSearchResultDet.setPremium(nullCheckString(clsProposalSearchForPortalGrid.getTotalPremium()));
								
								
								//Start : 07-Apr-2017  : To send productName to JSON response. 
								 String strval="";					             
					             List<Product> oComProductList =  (List<Product>) dbService.getProduct("com.majesco.dcf.common.tagic.entity.Product","strprodcd",proposalSearchResultDet.getProductCode());
					             if(oComProductList != null && oComProductList.size()>0){
					             	for(Product productList:oComProductList)	                            		                                  
					                       strval = productList.getStrprodname()!=null?productList.getStrprodname().toString():"";					                       					                 	
					             }	                              					             
					             proposalSearchResultDet.setProductName(strval);	
								//End : 07-Apr-2017  : To send productName to JSON response.								
								
					             //End:30/12/2016:Added code to reverse map the correct proposal status code as GC proposal search returning proposal status description rather than status code.
								
								proposalSearchResultDet.setCustomerName(nullCheckString(clsProposalSearchForPortalGrid.getCustomerName()));
								proposalSearchResultDet.setIntermediaryCode(nullCheckString(clsProposalSearchForPortalGrid.getProducerCode()));
								proposalSearchResultDet.setCreatedDate(nullCheckString(clsProposalSearchForPortalGrid.getCreatedDate()));
								proposalSearchResultDet.setTransactionMode(nullCheckString(clsProposalSearchForPortalGrid.getTransactionType()));
								proposalSearchResultDet.setStatusCode(nullCheckString(clsProposalSearchForPortalGrid.getProposalStatus()));
								proposalSearchResultDet.setStatusDesc((String)proposalStatusMap.get(clsProposalSearchForPortalGrid.getProposalStatus()));

								proposalSearchResultDetList.add(proposalSearchResultDet);
							}

							proposalSearchResponse.setProposalSearchResultDetList(proposalSearchResultDetList);
							proposalSearchResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
						}
					}

				}
			}
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: searchProposal() method ::Exception::",ex);
			proposalSearchResponse=new ProposalSearchResponse();
			proposalSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			proposalSearchResponse.setMessage(ex.getMessage());
		}
		logger.info("Inside "+_strClassName+"::"+strMethodName+"::Result JSON::"+objMap.writeValueAsString(proposalSearchResponse));
		return proposalSearchResponse;
	}

	@Override
	public AgentDashBoardResponse dashBoardRejectedList(AgentDashBoardRequest agentDashBoardRequest) throws Exception {
	
		AgentDashBoardResponse agentDashBoardResponse=null;
	
		RejectedProposalList rejectedList=null;
		String strMethodName = "dashBoardRejectedList";
		ObjectMapper objMap=new ObjectMapper();
		String strStatusDesc="";
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
		
			PendingPropListResponse pendingPropListResponse = new PendingPropListResponse();
			
			String _usertType = agentDashBoardRequest.getUserType()==null ? "INTERMEDIARY":agentDashBoardRequest.getUserType();
			String _producerCode = agentDashBoardRequest.getProducerCode()==null ? "" : agentDashBoardRequest.getProducerCode();
			
			logger.info("Inside TagicCommonServiceImpl :: "+strMethodName+" method :: Entered ::");
			String serviceUrl=getWSDLURL(CommonConstants.GENERIC_COVERNOTE_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			GenericSerive_Service genericService=new GenericSerive_Service(wsdlUrl);
			GenericSerive port=genericService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			objMap = new ObjectMapper();
			serviceUtil.addClientInterceptor(port);
			
			GenericResult genericResult = null;
			StopWatch watch = new StopWatch();
			watch.start();
			genericResult = port.getPendingProposalList(smc_source, smc_medium, smc_campaign, "", _usertType, _producerCode, 
						agentDashBoardRequest.getFromDate(), agentDashBoardRequest.getToDate(), "", "", "", "", "", "", "", "", "");
			watch.stop();
			logger.info("Time Taken by TagicCommonServiceImpl --> dashBoardRejectedList --> getPendingProposalList service in seconds..>> "+watch.getTotalTimeSeconds());
			
			if(genericResult!=null && genericResult.getLOVTypes()!=null){
				rejectedList = new RejectedProposalList();
				agentDashBoardResponse =  new AgentDashBoardResponse();
				List<com.unotechsoft.stub.genericservice.client.LOVType> listLOVType = genericResult.getLOVTypes().getLOVType();
				if(listLOVType!=null){
					ArrayList<DashBoardSummaryDetails> dashBoardSummaryRejectedList=new ArrayList<DashBoardSummaryDetails>();
                    for(int i=0; i<listLOVType.size();i++){
                    	LOVTypePolicyDetail lovTypePolicyDetail=(LOVTypePolicyDetail)listLOVType.get(i);                          
                        if(lovTypePolicyDetail!=null){
						    String declinedStatus = lovTypePolicyDetail.getDeclinedStatus();
						    String transactionType = lovTypePolicyDetail.getTransactionType();
							//START:1191:Code changes for defect 1191 by Sailesh.
						    String status = lovTypePolicyDetail.getStatus();
						    
						    //END
						    if(declinedStatus!=null && transactionType!=null && (declinedStatus.equalsIgnoreCase("NPDP") || declinedStatus.equalsIgnoreCase("NMTD") || declinedStatus.equalsIgnoreCase("NR") || transactionType.equalsIgnoreCase("DECLINED") || (status.equalsIgnoreCase("NR") && transactionType.equalsIgnoreCase("NEWPOLICY"))))
							{						                     
								//if(logger.isDebugEnabled())logger.debug("Inside "+declinedStatus+"::"+strMethodName+"::Result JSON::"+objMap.writeValueAsString(pendingPropListResponse)+"TransactionType"+transactionType+"StatusofProposal"+status);
								DashBoardSummaryDetails dashBoardSummaryDetails = new DashBoardSummaryDetails();
								dashBoardSummaryDetails.setProposalNumber(lovTypePolicyDetail.getProposalNo());
								dashBoardSummaryDetails.setCustomerName(lovTypePolicyDetail.getCustomerName());
								dashBoardSummaryDetails.setProductCode(lovTypePolicyDetail.getProductCode());
								dashBoardSummaryDetails.setTotalPremium(lovTypePolicyDetail.getTotalPremium());
								dashBoardSummaryDetails.setProposalStatus(lovTypePolicyDetail.getStatusCode());
								dashBoardSummaryDetails.setCreatedDate(lovTypePolicyDetail.getProposalDate());
								strStatusDesc=dbService.getCodeDesc(null, dashBoardSummaryDetails.getProposalStatus(), CommonConstants.PROPOSAL_STATUS_CODE, "1");
																				
								dashBoardSummaryDetails.setStatusDesc(strStatusDesc);
								dashBoardSummaryRejectedList.add(dashBoardSummaryDetails);
							}
                        }   	 
                    }
                    if(dashBoardSummaryRejectedList!=null && dashBoardSummaryRejectedList.size()!=0){
                    	rejectedList.setNoOfRejectedProposal(dashBoardSummaryRejectedList.size());
                    	rejectedList.setDashBoardSummaryRejectedList(dashBoardSummaryRejectedList);
                    } 
                    agentDashBoardResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
               }
           }
			
			agentDashBoardResponse.setRejectedProposalList(rejectedList);
			logger.info("REJECTED LIST COUNT"+agentDashBoardResponse.getRejectedProposalList().getNoOfRejectedProposal());
			
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
			
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: dashBoardPendingList() method ::Exception::",ex);
			agentDashBoardResponse=new AgentDashBoardResponse();
			agentDashBoardResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			agentDashBoardResponse.setMessage(ex.getMessage());
		}
		return agentDashBoardResponse;
	}
	
	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<String,String> getMinPaymentDateForPortalLock(String userId)
			throws Exception {
		PremiumReceivableReportResponse premiumReceivableReportResponse = null;
		String methodName = "getMinPaymentDateForPortalLock";
		Map<String,String> responseMap = new HashMap<String, String>();
		DateFormat dateFormatter = null;
		HashMap<String, List<Date>> hashMap = new HashMap<String, List<Date>>();
		String serviceURL = ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING;
		QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/AccountService/", "AccountService");
		try{

			logger.info("Inside "+_strClassName+"::"+methodName+"::Entered:: "+userId);
			


			if(serviceURL==null || serviceURL.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
				serviceURL=getWSDLURL(ReceiptConstants.ACCOUNTSERVICE_ID);
			}

			URL wsdlUrl=new URL(serviceURL);
			AccountService_Service ss = new AccountService_Service(wsdlUrl, SERVICE_NAME);
			AccountService port = ss.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);
			com.unotechsoft.stub.accountservice.client.GetUserWisePaymentDtlsForAcceptanceForPortal2 _getUserWisePaymentDtlsForAcceptanceForPortal_parameters = new GetUserWisePaymentDtlsForAcceptanceForPortal2();
	        	        
	        _getUserWisePaymentDtlsForAcceptanceForPortal_parameters.setCampaign(smc_medium);
	        _getUserWisePaymentDtlsForAcceptanceForPortal_parameters.setMedium(smc_campaign);
	        _getUserWisePaymentDtlsForAcceptanceForPortal_parameters.setSource(smc_source);

	        UserDataPaymentAcceptance userDataPaymentAcceptance=new UserDataPaymentAcceptance();
	        userDataPaymentAcceptance.setUserId(userId);
			_getUserWisePaymentDtlsForAcceptanceForPortal_parameters.setObjUserDataPaymentAccept(userDataPaymentAcceptance);
			com.unotechsoft.stub.accountservice.client.GetUserWisePaymentDtlsForAcceptanceForPortalResponse2 _getUserWisePaymentDtlsForAcceptanceForPortal__return = port.getUserWisePaymentDtlsForAcceptanceForPortal(_getUserWisePaymentDtlsForAcceptanceForPortal_parameters);
	        PaymentAcceptanceServiceResult paymentEntryServiceResult=_getUserWisePaymentDtlsForAcceptanceForPortal__return.getReturn();
	        if(paymentEntryServiceResult!=null && paymentEntryServiceResult.getPaymentDetails()!=null && paymentEntryServiceResult.getPaymentDetails()
	        		.getClsPaymentAccept()!=null  && !paymentEntryServiceResult.getPaymentDetails().getClsPaymentAccept().isEmpty() 
	        		&& paymentEntryServiceResult.getPaymentDetails().getClsPaymentAccept().size()>0){
	        		        	
			    List<ClsPaymentAccept> paymentEntryServiceResultList=paymentEntryServiceResult.getPaymentDetails().getClsPaymentAccept();
			    ClsPaymentAccept serviceResult = null;
			    for(int i=0;i<paymentEntryServiceResultList.size();i++){
			    	serviceResult	=	paymentEntryServiceResultList.get(i);
			       	if(serviceResult!=null){
			       	//Start: code added for group data based on office/ branch code
			       		dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
			       		String officeCode = ""+serviceResult.getBusinessLocation();
			       		if (!hashMap.containsKey(officeCode)) {
			       		    List<Date> list = new ArrayList<Date>();
			       		    list.add(dateFormatter.parse(serviceResult.getPaymentDate()));
		        		    hashMap.put(officeCode, list);
		        		} else {
		        		    hashMap.get(officeCode).add(dateFormatter.parse(serviceResult.getPaymentDate()));
		        		}
			       	//End: code added for group data based on office/ branch code		        		
		        	}
		        }
		        Iterator iterator = hashMap.entrySet().iterator();
		        while(iterator.hasNext()){
		        	//Start: code added for sorting dates
		        	Map.Entry object = (Map.Entry)iterator.next();
		        	List<Date> dateList = (List<Date>) object.getValue();
		        	Collections.sort(dateList);
		        	String minPaymentDate = dateFormatter.format(dateList.get(0));
		        	responseMap.put((String)object.getKey(), minPaymentDate);
		        	//End: code added for sorting dates
		        }
	        }
		}
			catch(Exception ex){
				premiumReceivableReportResponse = new PremiumReceivableReportResponse();
				premiumReceivableReportResponse.setResultCode(CommonConstants.FAILURE_STATUS);
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError errorRes=new ResponseError();
				errorRes.setErrorCode("ERR02");
				errorRes.setErrorMMessag("Unable To Process Your Request At This Moment."+ex.toString());
				errorList.add(errorRes);
				premiumReceivableReportResponse.setResponseError(errorList);
			}
		
		
		return responseMap;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public boolean getPortalLockDays (PortalLockDaysRequest request){
		boolean portalLockFlag = false;
		String strMethodName = "getPortalLockDays";
		String noOfAllowedDays = "";
		boolean submittedReceipt= false;
		String minPaymentDate="";
		String result = null;
		HttpHeaders responseHeaders =  new HttpHeaders();
		try{
			logger.info(strMethodName+" method :: Execution started ::");
			String serviceUrl=getWSDLURL(CommonConstants.GENERIC_COVERNOTE_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			GenericSerive_Service genericService=new GenericSerive_Service(wsdlUrl);
			GenericSerive port=genericService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);
			
			String _source = smc_source;
	        String _medium = smc_medium;
	        String _campaign = smc_campaign;
	        String _strLVTokenID = "";
	        String producerCode = request.getProducerCode();
	        String officeCode = request.getOfficeCode();
	        HashMap<String, String> minPayDatesMap = request.getMinPayDatesMap();
	        
	        if (minPayDatesMap!=null && !minPayDatesMap.isEmpty()){
		        Iterator iterator = minPayDatesMap.entrySet().iterator();
		        while (iterator.hasNext()){
		        	Map.Entry keyValuePair = (Map.Entry)iterator.next();
		        	String mapOfficeCode = (String)keyValuePair.getKey();
		        	if (mapOfficeCode.equalsIgnoreCase(officeCode)){
		        		minPaymentDate = (String)keyValuePair.getValue();
		        		submittedReceipt = true;
		        		break;
		        	}
		        	
		        }
			}
	        
	        com.unotechsoft.stub.genericservice.client.GenericResult _response= port.getPortalIDLockingService(_source, _medium, _campaign, _strLVTokenID, producerCode, officeCode);
	        
	        if (_response!=null && _response.getLOVTypes()!=null && _response.getLOVTypes().getLOVType()!=null
	        		&& !_response.getLOVTypes().getLOVType().isEmpty() && _response.getLOVTypes().getLOVType().size()>0){
	        	
	        	List<com.unotechsoft.stub.genericservice.client.LOVType> listLOVType = _response.getLOVTypes().getLOVType();
	        	
	        	for (int i=0;i<listLOVType.size();i++){
	        		LOVTypePortalIDLocking objPortalIDLocking = (LOVTypePortalIDLocking)listLOVType.get(i);
	        		noOfAllowedDays = objPortalIDLocking.getNoofDays();
	        	}
	        	
	        	logger.info(strMethodName+" :: Number of days allowed for not to lock portal is :: "+noOfAllowedDays);
	        	
	        	if (submittedReceipt && noOfAllowedDays!=null && !noOfAllowedDays.equals("") && minPaymentDate!=null && !minPaymentDate.equals("")){
	        		DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
	        		Date dtPaymentDate = dateFormatter.parse(minPaymentDate);
	        		
	        		long diff = new Date().getTime() - dtPaymentDate.getTime();
	       		 	long days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	       		 	// Start : 1630 : VishalJ : code added to calculate no of weekends days between period
	       		 	Calendar calendar1 = Calendar.getInstance();
	       		 	Calendar calendar2 = Calendar.getInstance();
	       		 	calendar1.setTime(dtPaymentDate);
	       		 	calendar2.setTime(new Date());
	       		 	int weekends = 0 ; 
	       		 	while(calendar1.before(calendar2)){
	       		 	if ((Calendar.SATURDAY == calendar1.get(Calendar.DAY_OF_WEEK))
	        		           ||(Calendar.SUNDAY == calendar1.get(Calendar.DAY_OF_WEEK))) {
	        		            weekends++;
	        		    }
	       		 		calendar1.add(Calendar.DATE, 1);
	       		 	}	       		    	       		 		       		 		       		 
	       		 	days = days - weekends;
	       		 	// End : 1630 : VishalJ : code added to calculate no of weekends days between period
	       		 	logger.info(strMethodName+" :: Min payment date difference with system date :: "+days);
	       		 
	       		 	if (days>new Long(noOfAllowedDays))
	       		 		//return new ResponseEntity("Failed",responseHeaders,HttpStatus.UNAUTHORIZED);
	       		 	portalLockFlag=true;
	       		 	//else
	       		 		//return new ResponseEntity("",responseHeaders,HttpStatus.OK);
	        	}
	        	logger.info(strMethodName+" :: Portal lock True/false "+portalLockFlag);
	        }
	        
		}
		catch (Exception e){
			e.printStackTrace();
		}
		//return new ResponseEntity(result,responseHeaders,HttpStatus.OK); 
		
		return portalLockFlag;
	}
	/**
	 * subtract days to date in java
	 * @param date
	 * @param days
	 * @return
	 */
	public static Date subtractDays(Date date, int days) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		cal.add(Calendar.DATE, -days);
				
		return cal.getTime();
	}



	@Override
	public AgentDashBoardResponse getPendingApprovalList(
			AgentDashBoardRequest agentDashBoardRequest) throws Exception {
		// TODO Auto-generated method stub
		
		AgentDashBoardResponse agentDashBoardResponse=new AgentDashBoardResponse(); // Final Response		
		PendingApprovalList pendingApprovalList=null;   // Final List to send in Response.
		
		
		String strMethodName = "getPendingApprovalList";
		ObjectMapper objMap=new ObjectMapper();
		String strStatusDesc="";
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");				
			
			String _usertType = agentDashBoardRequest.getUserType()==null ? "INTERMEDIARY":agentDashBoardRequest.getUserType();
			String _producerCode = agentDashBoardRequest.getProducerCode()==null ? "" : agentDashBoardRequest.getProducerCode();
			
			
			String serviceUrl=getWSDLURL(CommonConstants.DASHBOARD_APPROVAL_PENDING);
			URL wsdlUrl=new URL(serviceUrl);
			ApprovalPending_Service pending_Service = new ApprovalPending_Service(wsdlUrl);
			ApprovalPending port = pending_Service.getSOAPOverHTTP();
			
			ServiceUtility serviceUtil=new ServiceUtility();
			objMap = new ObjectMapper();
			serviceUtil.addClientInterceptor(port);
			
			GetApprovalPendingProposalOtherDetailsResponse pendingResponse = null;   // Object for taking response from ESB Service
			
			GetApprovalPendingProposalOtherDetails parameters = new GetApprovalPendingProposalOtherDetails();
			parameters.setStrAgentId(_producerCode);   // Setting input parameters
			parameters.setStrAuthTokenId(agentDashBoardRequest.getAuthToken());
			parameters.setSource(smc_source);
			parameters.setCampaingn(smc_campaign);
			parameters.setMedium(smc_medium);
			parameters.setStrCustomerId("");
			parameters.setStrUserId("");
			StopWatch watch = new StopWatch();
			watch.start();
			//pendingResponse = port.getApprovalPendingProposalOtherDetails(parameters.getSource(), parameters.getMedium(), parameters.getCampaingn(), parameters.getStrAuthTokenId(), parameters.getStrCustomerId(), parameters.getStrAgentId(), parameters.getStrUserId());   // Calling ESB service
			com.unotechsoft.stub.commonservice.approval.client.ServiceResult serviceResult = port.getApprovalPendingProposalOtherDetails(parameters.getSource(), parameters.getMedium(), parameters.getCampaingn(), parameters.getStrAuthTokenId(), parameters.getStrCustomerId(), parameters.getStrAgentId(), parameters.getStrUserId());   // Calling ESB service
			//com.unotechsoft.stub.commonservice.approval.client.ServiceResult serviceResult=null;
			watch.stop();
			logger.info("getApprovalPendingProposalOtherDetails::"+watch.getTotalTimeSeconds());																	
				ArrayList<DashBoardSummaryDetails> dashBoardSummaryPendingList=null;
				if(serviceResult != null){
					
					com.unotechsoft.stub.commonservice.approval.client.ArrayOfProposalOtherDetailsResult arrayOfProposalOtherDetailsResult = serviceResult.getPropOthrDtls();
					
					if(arrayOfProposalOtherDetailsResult!=null){						
						List<ProposalOtherDetailsResult> otherDetailsResultsList =  arrayOfProposalOtherDetailsResult.getProposalOtherDetailsResult();
						if(otherDetailsResultsList!=null && otherDetailsResultsList.size()>0){
							dashBoardSummaryPendingList = new ArrayList<DashBoardSummaryDetails>();
							pendingApprovalList = new PendingApprovalList();
							for(ProposalOtherDetailsResult otherDetailsResult : otherDetailsResultsList){								
								
								DashBoardSummaryDetails dashBoardSummaryDetails = new DashBoardSummaryDetails(); // Creating object for Each pending proposal  
								
								dashBoardSummaryDetails.setProposalNumber(otherDetailsResult.getProposalNo());
								dashBoardSummaryDetails.setCustomerName(otherDetailsResult.getCustomerName());
								
								if (otherDetailsResult.getProductName()!=null && otherDetailsResult.getProductName().contains("PrivateCar"))
									dashBoardSummaryDetails.setProductCode("3121");
	                            else if (otherDetailsResult.getProductName()!=null && otherDetailsResult.getProductName().contains("Two"))
	                            	dashBoardSummaryDetails.setProductCode("3122");
	                            else if (otherDetailsResult.getProductName()!=null && otherDetailsResult.getProductName().contains("Commercial"))
	                            	dashBoardSummaryDetails.setProductCode("3124");
	                            else if (otherDetailsResult.getProductName()!=null && otherDetailsResult.getProductName().contains("Guard"))
	                            	dashBoardSummaryDetails.setProductCode("4251");
	                            else if (otherDetailsResult.getProductName()!=null && otherDetailsResult.getProductName().contains("Shield"))
	                            	dashBoardSummaryDetails.setProductCode("4254");
	                            else if (otherDetailsResult.getProductName()!=null && otherDetailsResult.getProductName().contains("Future"))
	                            	dashBoardSummaryDetails.setProductCode("4255");
								
								//dashBoardSummaryDetails.setProductCode(otherDetailsResult.getProductName());
								
								dashBoardSummaryDetails.setTotalPremium(otherDetailsResult.getQuoteAmount()+"");
								//dashBoardSummaryDetails.setProposalStatus(lovTypePolicyDetail.getStatusCode());
								dashBoardSummaryDetails.setCreatedDate(otherDetailsResult.getProposalDate());
								dashBoardSummaryDetails.setTransactionType(otherDetailsResult.getTransctionType());
																
								dashBoardSummaryPendingList.add(dashBoardSummaryDetails);
							}
						}																	
					}
					
				}
				
				if(dashBoardSummaryPendingList!=null && dashBoardSummaryPendingList.size()!=0){
					pendingApprovalList.setNoOfPendingApproval(dashBoardSummaryPendingList.size());
					pendingApprovalList.setDashBoardPendingApprovalList(dashBoardSummaryPendingList);
                } 
                agentDashBoardResponse.setResultCode(CommonConstants.SUCCESS_STATUS);								
               
           
			
			agentDashBoardResponse.setPendingApprovalList(pendingApprovalList);
			
			
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit");
			
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: dashBoardPendingList() method ::Exception::",ex);
			agentDashBoardResponse=new AgentDashBoardResponse();
			agentDashBoardResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			agentDashBoardResponse.setMessage(ex.getMessage());
		}
		return agentDashBoardResponse;				
	}
	
	/** 
	 * 
	 * Method added on 18/05/2017 by Sailesh to call PendingInspectionService
	 */ 

	@Override
	public AgentDashBoardResponse getPendingInspectionDetailsForPortal(AgentDashBoardRequest agentDashBoardRequest)
			throws Exception 
	{
		AgentDashBoardResponse agentDashBoardResponse = new AgentDashBoardResponse();
		ProposalSearchRequest proposalSearchRequest=null;
		PendingInspectionList pendingInspectionList=null;
		ArrayList<DashBoardSummaryDetails> lstDashboardPending= new ArrayList<DashBoardSummaryDetails>();
		String strMethodName ="getPendingInspectionForPortal";
		ObjectMapper objMap=new ObjectMapper();
		try{
			logger.info(strMethodName+" method :: Execution started ::");
			String serviceUrl=getWSDLURL(CommonConstants.PRE_INSPECTION_SERVICE);
			com.unotechsoft.stub.inspectionservice.client.ClsUserData_Portal objPortalData = new com.unotechsoft.stub.inspectionservice.client.ClsUserData_Portal();//to pass request parameters
			//URL wsdlUrl=new URL(serviceUrl);
			
			VehicleInspction_Service service=new VehicleInspction_Service(new URL(serviceUrl));
			VehicleInspction stubService=service.getSOAPOverHTTP();
			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(stubService);
			/*objPortalData.setProductCode("3051994444");
			objPortalData.setProducerName("MANOJ GUPTA");
			objPortalData.setProductCode("3121");*/
			objPortalData.setProducerCode(agentDashBoardRequest.getProducerCode());
			objPortalData.setProducerName(agentDashBoardRequest.getProducerName());
			objPortalData.setUSERID(agentDashBoardRequest.getUserID());
			
			objPortalData.setApplicationNo(CommonConstants.BLANK_STRING);
			
			com.unotechsoft.stub.inspectionservice.client.ClsUserData_Portal clsNew=null;
            //Defaulting Vehicle inspection fields.
			//inspectionServiceReq=defaultFields(inspectionServiceReq, inspectionRequest);
			StopWatch watch = new StopWatch(); //Doubt on where to place this
			watch.start();//Doubt on where to place this
			clsNew=stubService.getPendingInspectionForPortal(smc_source, smc_medium, smc_campaign,agentDashBoardRequest.getAuthToken(), objPortalData);
			watch.stop();//Doubr on where to place this
			logger.info("Time Taken by TagicCommonServiceImpl --> dashBoardPendingInspectionList --> getPendingInspectionList service in seconds..>> "+watch.getTotalTimeSeconds());
			if(clsNew !=null){
				ArrayOfclsUserData_Portal _result = clsNew.getServiceResult();
				if (_result!=null && _result.getClsUserData_Portal()!=null && !_result.getClsUserData_Portal().isEmpty()){
					ArrayList<ClsUserData_Portal> clsUserData_PortalList=(ArrayList<ClsUserData_Portal>)_result.getClsUserData_Portal();
					pendingInspectionList = new PendingInspectionList();
					for (ClsUserData_Portal objPortal: clsUserData_PortalList){
						if(objPortal!=null ){
						DashBoardSummaryDetails dashboarddtl = new DashBoardSummaryDetails();
						dashboarddtl.setCustomerName(objPortal.getCustomerName()==null?"":objPortal.getCustomerName());
						dashboarddtl.setProducerCode(objPortal.getProducerCode()==null?"":objPortal.getProducerCode());		//Internally identified.
						dashboarddtl.setProductCode(objPortal.getProductCode()==null?"":objPortal.getProductCode());
						dashboarddtl.setCreatedDate(objPortal.getProposalDate()==null?"":objPortal.getProposalDate());
						dashboarddtl.setProposalNumber(objPortal.getProposalNo()==null?"":objPortal.getProposalNo());
						dashboarddtl.setTotalPremium(objPortal.getProposalAmount()==null?"":objPortal.getProposalAmount());
						lstDashboardPending.add(dashboarddtl);
						}
					}
				}
				pendingInspectionList.setDashBoardSummaryInspectionList(lstDashboardPending);
				pendingInspectionList.setNoOfPendingInspection(lstDashboardPending.size());
				agentDashBoardResponse.setPendingInspectionList(pendingInspectionList);
			}
						
		}
		catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: getPendingInspectionDetailsForPortal() method ::Exception::",ex);
			agentDashBoardResponse=new AgentDashBoardResponse();
			agentDashBoardResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			agentDashBoardResponse.setMessage(ex.getMessage());
		}
				return agentDashBoardResponse;
	}
	
	

	
	@Override
	public PortalLockDetails getPendingPayInSlipCount(UserObject userObjectReq) throws Exception {
		
		logger.info("In ReceiptController :: getPendingPayInSlipCount method");
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		int pendingCashCount = 0;
		int pendingChequeCount = 0;
		int pendingDDCount = 0;
		int totalPendingCases = 0;
		String tokenId = null;
		ObjectMapper objMap2 = new ObjectMapper();
		PendingPayInSlipResponse response = new PendingPayInSlipResponse();
		boolean portalLockFlag = false;
		PortalLockDetails portalLockDtl = new PortalLockDetails();
		
		//if(logger.isDebugEnabled())logger.debug("Inside Exception  TAGICCommonServiceImpl :: getPendingPayInSlipCount :: Request Received From UI JSON : "+objMap2.writeValueAsString(userObjectReq));
		
		DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
		Date dtYesterday = subtractDays(new Date(), 1);
		String strYesterdayDate = dateFormatter.format(dtYesterday);

		ArrayList<ReceiptDetailsResponse> receiptDetailsResp = new ArrayList<ReceiptDetailsResponse>();
		
		GetDetailsForGridForPortal2 fetchRequest =new GetDetailsForGridForPortal2();
		UserDataPaymentDeposit paymentDeposit = new UserDataPaymentDeposit();

		GetDetailsForGridForPortal2 fetchRequestForCheque =new GetDetailsForGridForPortal2();
		UserDataPaymentDeposit paymentDepositCheque = new UserDataPaymentDeposit();
		
		GetDetailsForGridForPortal2 fetchRequestForDD =new GetDetailsForGridForPortal2();
		UserDataPaymentDeposit paymentDepositDD = new UserDataPaymentDeposit();
		
		try{
			tokenId = userObjectReq.getAuthToken();
			
			paymentDeposit.setTransactionTime(strYesterdayDate==null?"":strYesterdayDate);
			paymentDeposit.setUserId(userObjectReq.getUserID());
			paymentDeposit.setPaymentMode(ReceiptConstants.FETCHRECEIPT_MODE_CASH);
			fetchRequest.setObjUserDataPaymentDeposit(paymentDeposit);
			fetchRequest.setStrPDTokenID(tokenId);
				
			String serviceURL=getWSDLURL(ReceiptConstants.ACCOUNTSERVICE_ID);
				
			AccountService_Service accService_Cash=new AccountService_Service(new URL(serviceURL));
			AccountService accServClient_Cash = accService_Cash.getSOAPOverHTTP();
					
			Client client_Cash=ClientProxy.getClient(accServClient_Cash);
			PrintWriter writer_Cash = new PrintWriter(System.out);
					
			client_Cash.getOutInterceptors().add(new CdataWriterInterceptor());
					
			client_Cash.getInInterceptors().add(new LoggingInInterceptor(writer_Cash));
					
			client_Cash.getOutInterceptors().add(new LoggingOutInterceptor(writer_Cash));
					
			//if(logger.isDebugEnabled())logger.debug("In TAGICCommonServiceImpl :: getPendingPayInSlipCount:getDetailsForGridForPortal  method starts");
			GetDetailsForGridForPortalResponse2 fetchResp=accServClient_Cash.getDetailsForGridForPortal(fetchRequest);
			//if(logger.isDebugEnabled())logger.debug("In TAGICCommonServiceImpl :: getPendingPayInSlipCount:getDetailsForGridForPortal  method ends ");
					
			if(fetchResp.getReturn()!=null && fetchResp.getReturn().getPaymentDepositColl()!=null && fetchResp.getReturn().getPaymentDepositColl()
					.getClsPaymentEntry()!=null && fetchResp.getReturn().getPaymentDepositColl().getClsPaymentEntry().size()!=0){
				pendingCashCount = 	fetchResp.getReturn().getPaymentDepositColl().getClsPaymentEntry().size();
				totalPendingCases = totalPendingCases+pendingCashCount;
				//if(logger.isDebugEnabled())logger.debug("Inside Exception  TAGICCommonServiceImpl :: getPendingPayInSlipCount :: Cash Pending cases : "+pendingCashCount);
			}

			// Cheque related changes
		//	paymentDeposit = new UserDataPaymentDeposit();
			paymentDepositCheque.setTransactionTime(strYesterdayDate==null?"":strYesterdayDate);
			paymentDepositCheque.setUserId(userObjectReq.getUserID());
			paymentDepositCheque.setPaymentMode(ReceiptConstants.FETCHRECEIPT_MODE_CHEQUE);
			fetchRequestForCheque.setObjUserDataPaymentDeposit(paymentDepositCheque);
			fetchRequestForCheque.setStrPDTokenID(tokenId);
				
			if(serviceURL==null || serviceURL.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
				serviceURL=getWSDLURL(ReceiptConstants.ACCOUNTSERVICE_ID);
			}
				
			AccountService_Service accService_Cheque=new AccountService_Service(new URL(serviceURL));
			AccountService accServClient_Cheque=accService_Cheque.getSOAPOverHTTP();
				
			Client client_Cheque=ClientProxy.getClient(accServClient_Cheque);
			PrintWriter writer_Cheque = new PrintWriter(System.out);
			
			client_Cheque.getOutInterceptors().add(new CdataWriterInterceptor());
				
			client_Cheque.getInInterceptors().add(new LoggingInInterceptor(writer_Cheque));
				
			client_Cheque.getOutInterceptors().add(new LoggingOutInterceptor(writer_Cheque));
				
			//if(logger.isDebugEnabled())logger.debug("In TAGICCommonServiceImpl :: getPendingPayInSlipCount:getDetailsForGridForPortal  method For Cheque starts");
			GetDetailsForGridForPortalResponse2 fetchRespForCheque = accServClient_Cheque.getDetailsForGridForPortal(fetchRequestForCheque);
			//if(logger.isDebugEnabled())logger.debug("In TAGICCommonServiceImpl :: getPendingPayInSlipCount for Cheque:getDetailsForGridForPortal  method For Cheque Ends");
				
				
			if(fetchRespForCheque.getReturn()!=null && fetchRespForCheque.getReturn().getPaymentDepositColl()!=null && fetchRespForCheque.getReturn()
					.getPaymentDepositColl().getClsPaymentEntry()!=null && fetchRespForCheque.getReturn().getPaymentDepositColl().getClsPaymentEntry().size()!=0){
				pendingChequeCount = fetchRespForCheque.getReturn().getPaymentDepositColl().getClsPaymentEntry().size();
				totalPendingCases = totalPendingCases+pendingChequeCount;
				//if(logger.isDebugEnabled())logger.debug("Inside Exception  TAGICCommonServiceImpl :: getPendingPayInSlipCount :: Cheque Pending cases : "+pendingChequeCount);
			}
			
			//paymentDeposit = new UserDataPaymentDeposit();
			paymentDepositDD.setTransactionTime(strYesterdayDate==null?"":strYesterdayDate);
			paymentDepositDD.setUserId(userObjectReq.getUserID());
			paymentDepositDD.setPaymentMode(ReceiptConstants.FETCHRECEIPT_MODE_DD);
			fetchRequestForDD.setObjUserDataPaymentDeposit(paymentDepositDD);
			fetchRequestForDD.setStrPDTokenID(tokenId);
				
			if(serviceURL==null || serviceURL.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
				serviceURL=getWSDLURL(ReceiptConstants.ACCOUNTSERVICE_ID);
			}
			AccountService_Service accService_DD = new AccountService_Service(new URL(serviceURL));
			AccountService accServClient_DD = accService_DD.getSOAPOverHTTP();
				
			Client client_DD=ClientProxy.getClient(accServClient_DD);
			PrintWriter writer_DD = new PrintWriter(System.out);
				
			client_DD.getOutInterceptors().add(new CdataWriterInterceptor());
				
			client_DD.getInInterceptors().add(new LoggingInInterceptor(writer_DD));
				
			client_DD.getOutInterceptors().add(new LoggingOutInterceptor(writer_DD));
				
			//if(logger.isDebugEnabled())logger.debug("In TAGICCommonServiceImpl :: getPendingPayInSlipCount for DD:getDetailsForGridForPortal  method For DD starts");
			GetDetailsForGridForPortalResponse2 fetchRespForDD=accServClient_DD.getDetailsForGridForPortal(fetchRequestForDD);
			//if(logger.isDebugEnabled())logger.debug("In TAGICCommonServiceImpl :: getPendingPayInSlipCount for DD:getDetailsForGridForPortal  method For DD Ends");
				
			if(fetchRespForDD.getReturn()!=null && fetchRespForDD.getReturn().getPaymentDepositColl()!=null && fetchRespForDD.getReturn().getPaymentDepositColl()
					.getClsPaymentEntry()!=null && fetchRespForDD.getReturn().getPaymentDepositColl().getClsPaymentEntry().size()!=0){
				pendingDDCount = 	fetchRespForDD.getReturn().getPaymentDepositColl().getClsPaymentEntry().size();
				totalPendingCases = totalPendingCases+pendingDDCount;								
			}
			//if(logger.isDebugEnabled())logger.debug("Inside Exception  TAGICCommonServiceImpl :: getPendingPayInSlipCount :: Total Pending cases --> "+totalPendingCases);
			
			if (totalPendingCases > 0)
				portalLockFlag =  true;
			
			if (portalLockFlag){
				portalLockDtl.setPortalLock(portalLockFlag);
				portalLockDtl.setMessage("You have pending payslips, please complete payslip generation for all pending receipts");
				if (privilegePayInSlipLock!=null && !privilegePayInSlipLock.equals("")){
					StringTokenizer tokenizer = new StringTokenizer(privilegePayInSlipLock,",");
					while(tokenizer.hasMoreElements()){
						portalLockDtl.getLstPrivilege().add(tokenizer.nextToken());
					}
				}
			}
			
			response.setTotalPendingCount(totalPendingCases);
			logger.info("Out TAGICCommonServiceImpl :: getPendingPayInSlipCount method");
		
		}
		catch(Exception e)
		{
			logger.error("Inside Exception TAGICCommonServiceImpl :: getPendingPayInSlipCount method :- "+e);
			e.printStackTrace();
		}
		ObjectMapper obj = new ObjectMapper();
		logger.info("Inside Exception TAGICCommonServiceImpl :: getPendingPayInSlipCount :: Response To Send UI JSON : "+obj.writeValueAsString(portalLockDtl));
		return portalLockDtl;
	}

@Override
	public PortalLockDetails portalLockEODReceipting(UserObject request) throws Exception {
		
		getPolicyDetailsEODResponse response = null;
		ArrayList<getPolicyDetailsEODResponse> lstResponse = null;
		ObjectMapper objMapper = new ObjectMapper();
		int pendingEODCount = 0;
		boolean portalLockFlag = false;
		PortalLockDetails portalLockDtl = new PortalLockDetails(); 
		List paymtDtlsList = new ArrayList(); //Code Added For EOD Time Taken Changes
		HashMap paymtDtlsMap = new HashMap();
		
		PaymentDetails payDtlsTrans = null;
		try{
			
			logger.info("In TagicCommonServiceImpl :: Inside portalLockEODReceipting method:"+objMapper.writeValueAsString(request));
			
			String serviceURL=getWSDLURL(ReceiptConstants.ACCOUNTSERVICE_ID);
			
			ArrayList lstPaymentTransDtls = new ArrayList();
			lstResponse = new ArrayList<getPolicyDetailsEODResponse>();
			
			String source = smc_source;
			String medium = smc_medium;
			String campaign = smc_campaign;
			
			String policyNumber = "";
			String productName = "";
			String proposalNo = "";
			String producerCode = request.getProducerCode()==null?"":request.getProducerCode();
			String userId = request.getUserID()==null?"":request.getUserID();
			
			AccountService_Service accService = new AccountService_Service(new URL(serviceURL));
			AccountService accServClient = accService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(accServClient);
			
			PaymentDepositServiceResult paymentDepositServiceResult = accServClient.policySearchPortal(source, medium, campaign, policyNumber, productName, proposalNo, producerCode, userId);
			
			if(paymentDepositServiceResult!=null && paymentDepositServiceResult.getPaymentDepositColl()!=null && paymentDepositServiceResult.getPaymentDepositColl()
					.getClsPaymentEntry()!=null && paymentDepositServiceResult.getPaymentDepositColl().getClsPaymentEntry().size()>0)
			{
				pendingEODCount = paymentDepositServiceResult.getPaymentDepositColl().getClsPaymentEntry().size();
				
				// Added to Development purpose
				
				/*Code Added For EOD Time Taken Changes - Starts Here*/
				paymtDtlsMap = dbService.getPaymentDetailsMap(null, request.getProducerCode());
				/*Code Added For EOD Time Taken Changes - Ends Here*/
				
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				
				for(int i=0;i<paymentDepositServiceResult.getPaymentDepositColl().getClsPaymentEntry().size();i++)
				{
					if(paymentDepositServiceResult.getPaymentDepositColl().getClsPaymentEntry().get(i).getProposalNo()!=null)
					{
						//lstPaymentTransDtls = (ArrayList) dbService.getPaymentDetailsTransaction("com.majesco.dcf.common.tagic.entity.PaymentDetails", paymentDepositServiceResult.getPaymentDepositColl().getClsPaymentEntry().get(i).getProposalNo()); //Code Commented For EOD Time Taken Changes
						
						//payDtlsTrans = new PaymentDetails(); //Code Commented For EOD Time Taken Changes
						//if(lstPaymentTransDtls!=null && lstPaymentTransDtls.size()>0) //Code Commented For EOD Time Taken Changes
						if(paymtDtlsMap.containsKey(paymentDepositServiceResult.getPaymentDepositColl().getClsPaymentEntry().get(i).getProposalNo())) //Code Added For EOD Time Taken Changes
						{
							String createdDate = paymentDepositServiceResult.getPaymentDepositColl().getClsPaymentEntry().get(i).getPolicyInceptionDate();
					
							Date date1 = sdf.parse(createdDate);
							Date dtbackDate = subtractDays(new Date(), 10);
							Date dtYesterday = subtractDays(new Date(), 1);
							if (date1.compareTo(dtbackDate)>0 ){
								portalLockFlag =  true;
								logger.info("$$$$$$$$$$$$ checking Portal Locks dtbackDate--> "+sdf.format(dtbackDate)+" , date1--> "+sdf.format(date1)+ ", Policy No--> "+paymentDepositServiceResult.getPaymentDepositColl().getClsPaymentEntry().get(i).getPolicyNo());
								break;
							}
						}
					}
					
				}
				
				// Added to Development purpose
				
				logger.info("Pending EOD receipt count --> "+pendingEODCount);
				/*if (pendingEODCount > 0)
					portalLockFlag =  true;*/
			}
			if (portalLockFlag){
				portalLockDtl.setPortalLock(portalLockFlag);
				portalLockDtl.setMessage("You have pending EOD receipting, please complete EOD receipting for all pending receipts");
				if (privilegeEODLock!=null && !privilegeEODLock.equals("")){
					StringTokenizer tokenizer = new StringTokenizer(privilegeEODLock,",");
					while(tokenizer.hasMoreElements()){
						portalLockDtl.getLstPrivilege().add(tokenizer.nextToken());
					}
				}
			}
			logger.info("In ReceiptController :: getPolicyDetailsEOD  method: Excecution completed Successfully... "+objMapper.writeValueAsString(lstResponse));
		}
		
		catch(Exception e){
			e.printStackTrace();
			logger.error("In ReceiptController :: getPolicyDetailsEOD  method: Exception Occurred", e);
		}
		return portalLockDtl;
	}
//Start : 03-Jul-2017 : Method to fetch Key & Values by EffDate into table : Vishal
	@Override
	public ValueByEffDateResponse getValueByEffDate(ValueByEffDateRequest request) throws Exception{
		
		ValueByEffDateResponse response = new ValueByEffDateResponse();
		
		ObjectMapper objMapper = new ObjectMapper();	
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		Date effdate=sdf.parse(request.getEffDate());	
		String rsaBaseCharge = null; /*Added For CR 1528 - Ketan*/
		
		try{			
			logger.info("In TagicCommonServiceImpl :: Inside getValueByEffDate method:"+objMapper.writeValueAsString(request));			
			String val = dbService.getValueByEffDate(request.getAmountKey(),effdate);
			
			//String rsaBaseCharge = dbService.getConfigParamVal("RSABASECHARGE");/*Commented For CR 1528 - Ketan*/
			/*START - Added For CR 1528 - Ketan*/
			if(request.getProductCode()!=null && request.getProductCode().equalsIgnoreCase(CommonConstants.PRIVATE_CAR_PRODUCT_CODE))
			{
				rsaBaseCharge = dbService.getConfigParamVal("RSABASECHARGE");
			}
			else if(request.getProductCode()!=null && request.getProductCode().equalsIgnoreCase(CommonConstants.TWO_WHEELER_PRODUCT_CODE))
			{
				rsaBaseCharge = dbService.getConfigParamVal("RSABASECHARGE_TW_Y"+request.getPolicyTerm());
			}
			/*END - Added For CR 1528 - Ketan*/
			Double rsaTax = Double.parseDouble(val);
			Double rsaBaseChargeAmt = Double.parseDouble(rsaBaseCharge);
			Double rsaAmt = rsaBaseChargeAmt  + (rsaBaseChargeAmt * rsaTax/100);
			rsaAmt = (double) Math.round(rsaAmt); // <1865> :: Rounding off RSA Amount. :: Vishal
			logger.info("In TagicCommonServiceImpl :: Inside getValueByEffDate method: RSA Amt :- "+rsaAmt);
			response.setAmountValue(rsaAmt.toString());
			response.setEffDate(request.getEffDate());
			logger.info("In TagicCommonServiceImpl :: getValueByEffDate  method: Excecution completed Successfully... "+objMapper.writeValueAsString(response));
		}
		
		catch(Exception e){
			e.printStackTrace();
			logger.error("In TagicCommonServiceImpl :: getValueByEffDate  method: Exception Occurred", e);
		}
		return response;
	}
	//End : 03-Jul-2017 : Method to fetch Key & Values by EffDate into table : Vishal   

//Start: RahulT <SIT 1608>| service exposed to get workflow id from proposal no based on swaraj mail 24 July 2017 18:37	
	@Override
	public JsonDBService getWorkflowId(JsonDBService data) throws Exception {
		
		ObjectMapper objMapper = new ObjectMapper();
		try{
			
			logger.info("In TagicCommonServiceImpl :: Inside getWorkflowId method:"+objMapper.writeValueAsString(data));
			
			String serviceURL=getWSDLURL(ReceiptConstants.DBSERVICE_ID);
			
			String source = smc_source;
			String medium = smc_medium;
			String campaign = smc_campaign;
			
			
			DBService_Service accService = new DBService_Service(new URL(serviceURL));
			com.unotechsoft.stub.commonservice.dbservice.client.DBService DBServClient = accService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(DBServClient);
			
			ProposalNoRequest _objProposalNoRequest = new ProposalNoRequest();
			_objProposalNoRequest.setAuthenticationToken("");
			_objProposalNoRequest.setCampaign(campaign);
			_objProposalNoRequest.setMedium(medium);
			_objProposalNoRequest.setSource(source);
			_objProposalNoRequest.setProposalNo(data.getProposalNo());
			
			WorkflowIdResponce _response = DBServClient.getWorkFlowIdFromProposalNo(_objProposalNoRequest);
			
			if(_response!=null && _response.getOutPutResult()!=null && _response.getOutPutResult()!=null)
			{
				
				logger.info("workflow ID received from ESB--> "+_response.getOutPutResult());
				data.setWorkflowId(_response.getOutPutResult());
			}
		}
		
		catch(Exception e){
			e.printStackTrace();
			logger.error("In TagicCommonServiceImpl :: getWorkflowId  method: Exception Occurred", e);
		}
		return data;
	}
	
	//End: RahulT <SIT 1608>| service exposed to get workflow id from proposal no based on swaraj mail 24 July 2017 18:37
//Start: RahulT <SIT 1614>| service exposed to get proposal no from quotation no based on swaraj mail 24 July 2017 18:37
	@Override
	public JsonDBService getProposalTaggedWithQuot(JsonDBService data) throws Exception {
		
		ObjectMapper objMapper = new ObjectMapper();
		try{
			
			logger.info("In TagicCommonServiceImpl :: Inside getProposalTaggedWithQuot method:"+objMapper.writeValueAsString(data));
			
			String serviceURL=getWSDLURL(ReceiptConstants.DBSERVICE_ID);

			String source = smc_source;
			String medium = smc_medium;
			String campaign = smc_campaign;
			
			
			DBService_Service accService = new DBService_Service(new URL(serviceURL));
			com.unotechsoft.stub.commonservice.dbservice.client.DBService DBServClient = accService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(DBServClient);
			
			QuotationNoRequest _objQuotNoRequest = new QuotationNoRequest();
			_objQuotNoRequest.setAuthenticationToken("");
			_objQuotNoRequest.setCampaign(campaign);
			_objQuotNoRequest.setMedium(medium);
			_objQuotNoRequest.setSource(source);
			_objQuotNoRequest.setQuotationNo(data.getQuotationNo());
			
			ProposalNoResponse _response = DBServClient.getProposalNoFromQuotationNo(_objQuotNoRequest);
			
			if(_response!=null && _response.getOutPutResult()!=null && _response.getOutPutResult()!=null)
			{
				logger.info("workflow ID received from ESB--> "+_response.getOutPutResult());
				data.setProposalNo(_response.getOutPutResult());
			}
		}
		
		catch(Exception e){
			e.printStackTrace();
			logger.error("In TagicCommonServiceImpl :: getWorkflowId  method: Exception Occurred", e);
		}
		return data;
	}
	
	//End: RahulT <SIT 1614>| service exposed to get proposal no from quotation no based on swaraj mail 24 July 2017 18:37
	

	//Start: KetanM <SIT 2594>| service exposed to getFastLaneIntegration on 29 Nov 2017
	@Override
	public FastLaneResponse getFastLaneIntegration(FastLaneRequest fastLaneRequest) throws Exception 
	{
		String strMethodName = "getFastLaneIntegration";
		FastLaneResponse fastLaneResponse = null;
		ObjectMapper objMap=new ObjectMapper();
		
		try
		{
			logger.info("In TagicCommonServiceImpl :: Inside "+strMethodName+" method :: Execution Started...");
			
			String serviceUrl=getWSDLURL(CommonConstants.FASTLANE_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			FastLaneService_Service fastLaneService_service = new FastLaneService_Service(wsdlUrl);
			FastLaneService port=fastLaneService_service.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);
			
			String _source = smc_source;
			String _medium = smc_medium;
			String _campaingn = smc_campaign;
			String regn_no = null;
			String chasi_no = null;
			String eng_no = null;
			String state_cd = null;
			String fncr_maker_desc = null;
			String fncr_date = null;
			String fncr_vh_class = null;
			String fncr_name = null;
			String module_code = null;
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			
			regn_no = fastLaneRequest.getRegistrationNumber();
			chasi_no = fastLaneRequest.getChasisNumber();
			eng_no = fastLaneRequest.getEngineNumber();
			state_cd = fastLaneRequest.getStateCd();
			fncr_maker_desc = fastLaneRequest.getFncrMakerDesc();
			fncr_date = fastLaneRequest.getFncrDate();
			fncr_vh_class = fastLaneRequest.getFncrVhClass();
			fncr_name = fastLaneRequest.getFncrName();
			module_code = fastLaneRequest.getModuleCode();
			
			
			GetfastLaneAuotomobileResponse getfastLaneAuotomobileResult = new GetfastLaneAuotomobileResponse();
			Response fastLaneResponseObj = new Response();
			JAXBElement<Result> lstFastLaneResultObj;
			JAXBElement<Vehicle> lstFastLaneVehicleObj;
			Result fastLaneResultObj = new Result();
			Vehicle vehicleObj = new Vehicle();
			fastLaneResponseObj = port.getfastLaneAuotomobile(_source, _medium, _campaingn, regn_no, chasi_no, eng_no, state_cd, fncr_maker_desc, fncr_date, fncr_vh_class, fncr_name, module_code);
			lstFastLaneResultObj = fastLaneResponseObj.getResult();
			fastLaneResultObj = lstFastLaneResultObj.getValue();
			lstFastLaneVehicleObj = fastLaneResultObj.getVehicle();
			
			if(lstFastLaneVehicleObj!=null && !lstFastLaneVehicleObj.isNil())
			{
				vehicleObj = lstFastLaneVehicleObj.getValue();
				logger.info("In TagicCommonServiceImpl :: Inside "+strMethodName+" method :: Response For Fast Lane : "+objMap.writeValueAsString(vehicleObj));
				
				if(vehicleObj!=null && vehicleObj.getRegn_No()!=null && !vehicleObj.getRegn_No().toString().equals(""))
				{
					fastLaneResponse=new FastLaneResponse();
					fastLaneResponse.setChasisNumber(vehicleObj.getChasi_No()==null?"":vehicleObj.getChasi_No().getValue());
					fastLaneResponse.setColor(vehicleObj.getColor()==null?"":vehicleObj.getColor().getValue());
					fastLaneResponse.setCubicCapacity(vehicleObj.getCubic_Cap()==null?"":vehicleObj.getCubic_Cap().getValue());
					fastLaneResponse.setEngineNumber(vehicleObj.getEng_No()==null?"":vehicleObj.getEng_No().getValue());
					fastLaneResponse.setFlaCubicCapacity(vehicleObj.getFla_Cubic_Cap()==null?"":vehicleObj.getFla_Cubic_Cap().getValue());
					fastLaneResponse.setFlaFuelTypeDesc(vehicleObj.getFla_Fuel_Type_Desc()==null?"":vehicleObj.getFla_Fuel_Type_Desc().getValue());
					fastLaneResponse.setFlaSeatingCapacity(vehicleObj.getFla_Seat_Cap()==null?"":vehicleObj.getFla_Seat_Cap().getValue());
					fastLaneResponse.setFlaVehClassDesc(vehicleObj.getFla_Vh_Class_Desc()==null?"":vehicleObj.getFla_Vh_Class_Desc().getValue());
					fastLaneResponse.setFuelTypeDesc(vehicleObj.getFuel_Type_Desc()==null?"":vehicleObj.getFuel_Type_Desc().getValue());
					fastLaneResponse.setMakerModel(vehicleObj.getMaker_Model()==null?"":vehicleObj.getMaker_Model().getValue());
					fastLaneResponse.setManufacturerDesc(vehicleObj.getMaker_Desc()==null?"":vehicleObj.getMaker_Desc().getValue());
					fastLaneResponse.setManufacturerYear(vehicleObj.getManu_Yr()==null?"":vehicleObj.getManu_Yr().intValue()+"");
					fastLaneResponse.setPurchaseDate(vehicleObj.getPurchase_Dt()==null?"":vehicleObj.getPurchase_Dt().getValue());
					fastLaneResponse.setRegistrationDate(vehicleObj.getRegn_Dt()==null?"":vehicleObj.getRegn_Dt().getValue());
					fastLaneResponse.setRegistrationNumber(vehicleObj.getRegn_No()==null?"":vehicleObj.getRegn_No().getValue());
					fastLaneResponse.setRtoCode(vehicleObj.getRto_Cd()==null?"":vehicleObj.getRto_Cd().getValue());
					fastLaneResponse.setRtoName(vehicleObj.getRto_Name()==null?"":vehicleObj.getRto_Name().getValue());
					fastLaneResponse.setSeatingCapacity(vehicleObj.getSeat_Cap()==null?"":vehicleObj.getSeat_Cap().getValue());
					fastLaneResponse.setStateCode(vehicleObj.getState_Cd()==null?"":vehicleObj.getState_Cd().getValue());
					fastLaneResponse.setStrManufacturer(vehicleObj.getFla_Maker_Desc()==null?"":vehicleObj.getFla_Maker_Desc().getValue());
					fastLaneResponse.setStrModel(vehicleObj.getFla_Model_Desc()==null?"":vehicleObj.getFla_Model_Desc().getValue());
					fastLaneResponse.setStrVariant(vehicleObj.getFla_Variant()==null?"":vehicleObj.getFla_Variant().getValue());
					fastLaneResponse.setVehClassDesc(vehicleObj.getVh_Class_Desc()==null?"":vehicleObj.getVh_Class_Desc().getValue());
					fastLaneResponse.setVehicleCode(vehicleObj.getVehicle_Cd()==null?"":vehicleObj.getVehicle_Cd().getValue());
					
					if(fastLaneResponse!=null && fastLaneResponse.getStrManufacturer()!=null && !fastLaneResponse.getStrManufacturer().equals(""))
					{
						String manufactCode = dbService.getFastLaneMakeModelCode(fastLaneResponse.getStrManufacturer(), "", "");
						fastLaneResponse.setStrManufacturerCd(manufactCode);
						
						if(manufactCode!=null && !manufactCode.equals("") && fastLaneResponse.getStrModel()!=null && !fastLaneResponse.getStrModel().equals(""))
						{
							String modelCode = dbService.getFastLaneMakeModelCode("", manufactCode, fastLaneResponse.getStrModel());
							fastLaneResponse.setStrModelCd(modelCode);
						}
					}
					else
					{
						fastLaneResponse.setStrManufacturerCd("");
						fastLaneResponse.setStrModelCd("");
					}
					
					fastLaneResponse.setMessage("NO ERROR");
					fastLaneResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
				}
				else
				{
					fastLaneResponse.setMessage("No Data Found");
					fastLaneResponse.setResultCode(CommonConstants.FAILURE_STATUS);
				}
			}
			else
			{
				fastLaneResponse.setMessage("No Data Found");
				fastLaneResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			}
			
		}
		catch(Exception e)
		{
			logger.error("Inside TagicCommonServiceImpl :: "+strMethodName+" method : Exception Occurred::", e);
			fastLaneResponse=new FastLaneResponse();
			fastLaneResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			fastLaneResponse.setMessage(CommonConstants.FASTLANE_EXCEPTION);
		}
		
		return fastLaneResponse;
	}
	//End: KetanM <SIT 2594>| service exposed to getFastLaneIntegration on 29 Nov 2017
	
	//Start: KetanM <SIT 2717>| service exposed to getHouseBankAndAccountNo on 11 Dec 2017
	public HouseBankAccNoResponse getHouseBankAndAccountNo(HouseBankAccNoRequest houseBankAccNoRequest) {
		String branchCode = "";
		String bankName = "";
		String strMethodName = "getHouseBankAndAccountNo";
		HouseBankAccNoResponse houseBankAccNoResponse = null;
		ObjectMapper objMap=new ObjectMapper();
		String pageName = "Portal";
		
		try
		{
			logger.info("In TagicCommonServiceImpl :: Inside "+strMethodName+" method :: Execution Started...");
			
			String serviceUrl=getWSDLURL(CommonConstants.ACCOUNTSERVICE_ID);
			AccountService_Service accService=new AccountService_Service(new URL(serviceUrl));
			AccountService accServClient=accService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(accServClient);
		
			String _source = smc_source;
			String _medium = smc_medium;
			String _campaingn = smc_campaign;
			KeyValuePair keyValuePair = null;
			String bankAccountNo = null;
			
			PaymentEntryServiceResult _houseBankResponse = null;
			
			
			if(houseBankAccNoRequest!=null && houseBankAccNoRequest.getOperationType()!=null && houseBankAccNoRequest.getOperationType().equalsIgnoreCase("HouseBranch"))
			{
				//Start:<YogeshM>:<19/02/2018>:<SIT>:<DefectID-HotFixed>:<mail from Deepak-16/02/2018 Subj-egarding getBankAccountNoForPaymentEntryTransTypewise service response Issue || for paymentmode optn "Payment link to Customer" & "Online Payment modes" need to send value as "DA">
				if (houseBankAccNoRequest.getPaymentMode()!=null && houseBankAccNoRequest.getPaymentMode().equalsIgnoreCase(CommonConstants.HOUSE_BANK_PAYMENT_MODE_UI_OL)) {
					houseBankAccNoRequest.setPaymentMode(CommonConstants.HOUSE_BANK_PAYMENT_MODE_OL_SP);
				} else if (houseBankAccNoRequest.getPaymentMode()!=null && houseBankAccNoRequest.getPaymentMode().equalsIgnoreCase(CommonConstants.HOUSE_BANK_PAYMENT_MODE_UI_SP)) {
					houseBankAccNoRequest.setPaymentMode(CommonConstants.HOUSE_BANK_PAYMENT_MODE_OL_SP);
				}
				//End:<YogeshM>:<19/02/2018>:<SIT>:<DefectID-HotFixed>:<mail from Deepak-16/02/2018 Subj-egarding getBankAccountNoForPaymentEntryTransTypewise service response Issue || for paymentmode optn "Payment link to Customer" & "Online Payment modes" need to send value as "DA">
				
				_houseBankResponse = new PaymentEntryServiceResult();
				_houseBankResponse = accServClient.getHouseBankListForPaymentEntry(smc_source, smc_medium, smc_campaign, houseBankAccNoRequest.getOfficeCode(), houseBankAccNoRequest.getPaymentMode(), pageName);
				
				if (_houseBankResponse!=null && _houseBankResponse.getHouseBankList()!=null && _houseBankResponse.getHouseBankList().getKeyValue()!=null && !_houseBankResponse.getHouseBankList().getKeyValue().isEmpty())
				{
					ArrayList<KeyValuePair> lstKeyValuePair = new ArrayList<KeyValuePair>();
					
					for(int i=0; i<_houseBankResponse.getHouseBankList().getKeyValue().size(); i++)
					{
						keyValuePair = new KeyValuePair();
						KeyValue keyVal = _houseBankResponse.getHouseBankList().getKeyValue().get(i);
						keyValuePair.setKey(keyVal.getKey());
						keyValuePair.setPair(keyVal.getValue());
						lstKeyValuePair.add(keyValuePair);
					}
					
					houseBankAccNoResponse=new HouseBankAccNoResponse();
					houseBankAccNoResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
					houseBankAccNoResponse.setMessage("NOERR");
					houseBankAccNoResponse.setLstKeyValuePair(lstKeyValuePair);
				}
				else
				{
					houseBankAccNoResponse=new HouseBankAccNoResponse();
					houseBankAccNoResponse.setResultCode(CommonConstants.FAILURE_STATUS);
					houseBankAccNoResponse.setMessage("No Data Found");
				}
			}
			else if(houseBankAccNoRequest!=null && houseBankAccNoRequest.getOperationType()!=null && houseBankAccNoRequest.getOperationType().equalsIgnoreCase("AccountNumber"))
			{
				//Start:<YogeshM>:<19/02/2018>:<SIT>:<DefectID-HotFixed>:<mail from Deepak-16/02/2018 Subj-egarding getBankAccountNoForPaymentEntryTransTypewise service response Issue || for paymentmode optn "Payment link to Customer" & "Online Payment modes" need to send value as "DA">
				if (houseBankAccNoRequest.getPaymentMode()!=null && houseBankAccNoRequest.getPaymentMode().equalsIgnoreCase(CommonConstants.HOUSE_BANK_PAYMENT_MODE_UI_OL)) {
					houseBankAccNoRequest.setPaymentMode(CommonConstants.HOUSE_BANK_PAYMENT_MODE_OL_SP);
				} else if (houseBankAccNoRequest.getPaymentMode()!=null && houseBankAccNoRequest.getPaymentMode().equalsIgnoreCase(CommonConstants.HOUSE_BANK_PAYMENT_MODE_UI_SP)) {
					houseBankAccNoRequest.setPaymentMode(CommonConstants.HOUSE_BANK_PAYMENT_MODE_OL_SP);
				}
				//End:<YogeshM>:<19/02/2018>:<SIT>:<DefectID-HotFixed>:<mail from Deepak-16/02/2018 Subj-egarding getBankAccountNoForPaymentEntryTransTypewise service response Issue || for paymentmode optn "Payment link to Customer" & "Online Payment modes" need to send value as "DA">
				
				_houseBankResponse = new PaymentEntryServiceResult();
				_houseBankResponse = accServClient.getBankAccountNoForPaymentEntryTransTypewise(smc_source, smc_medium, smc_campaign, houseBankAccNoRequest.getOfficeCode(), houseBankAccNoRequest.getPaymentMode(), houseBankAccNoRequest.getBranchCode(), pageName);
				
				if (_houseBankResponse!=null && _houseBankResponse.getBankAccountNoList()!=null && _houseBankResponse.getBankAccountNoList().getString()!=null && !_houseBankResponse.getBankAccountNoList().getString().isEmpty())
				{
					ArrayList<KeyValuePair> lstKeyValuePair = new ArrayList<KeyValuePair>();
					ArrayList<String> accountNoLst = (ArrayList<String>) _houseBankResponse.getBankAccountNoList().getString();
					for(int i=0; i<accountNoLst.size(); i++)
					{
						keyValuePair = new KeyValuePair();
						bankAccountNo = accountNoLst.get(i);
						keyValuePair.setKey(bankAccountNo);
						keyValuePair.setPair(bankAccountNo);
						lstKeyValuePair.add(keyValuePair);
					}
					
					houseBankAccNoResponse=new HouseBankAccNoResponse();
					houseBankAccNoResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
					houseBankAccNoResponse.setMessage("NOERR");
					houseBankAccNoResponse.setLstKeyValuePair(lstKeyValuePair);
				}
				else
				{
					houseBankAccNoResponse=new HouseBankAccNoResponse();
					houseBankAccNoResponse.setResultCode(CommonConstants.FAILURE_STATUS);
					houseBankAccNoResponse.setMessage("No Data Found");
				}
			}
			else
			{
				houseBankAccNoResponse=new HouseBankAccNoResponse();
				houseBankAccNoResponse.setMessage(CommonConstants.FASTLANE_WRONG_OPERATION_MSG);
				houseBankAccNoResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			}
			
		}
		catch(Exception e){
			logger.error("Inside TagicCommonServiceImpl :: "+strMethodName+" method : Exception Occurred::", e);
			houseBankAccNoResponse=new HouseBankAccNoResponse();
			houseBankAccNoResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			houseBankAccNoResponse.setMessage(CommonConstants.FASTLANE_EXCEPTION);
		}
		return houseBankAccNoResponse;
	}
	//End: KetanM <SIT 2717>| service exposed to getHouseBankAndAccountNo on 11 Dec 2017
	
	
	//Start: VishalJ <SIT 2717>| service exposed to getHouseBankAndAccountNo from Portal DB on 21 Feb 2018
		public HouseBankAccNoResponse getHouseBankAndAccountNo_portal(HouseBankAccNoRequest houseBankAccNoRequest) {
			String branchCode = "";
			String bankName = "";
			String strMethodName = "getHouseBankAndAccountNo_portal";
			HouseBankAccNoResponse houseBankAccNoResponse = null;
			ObjectMapper objMap=new ObjectMapper();
			String pageName = "Portal";
			
			try
			{
				logger.info("In TagicCommonServiceImpl :: Inside "+strMethodName+" method :: Execution Started..."+objMap.writeValueAsString(houseBankAccNoRequest));											
				KeyValuePair keyValuePair = null;
				String bankAccountNo = null;
				
				PaymentEntryServiceResult _houseBankResponse = null;
				
				if(houseBankAccNoRequest!=null && houseBankAccNoRequest.getOperationType()!=null && houseBankAccNoRequest.getOperationType().equalsIgnoreCase("HouseBranch"))
				{
					//Start:<YogeshM>:<19/02/2018>:<SIT>:<DefectID-HotFixed>:<mail from Deepak-16/02/2018 Subj-egarding getBankAccountNoForPaymentEntryTransTypewise service response Issue || for paymentmode optn "Payment link to Customer" & "Online Payment modes" need to send value as "DA">
					if (houseBankAccNoRequest.getPaymentMode()!=null && houseBankAccNoRequest.getPaymentMode().equalsIgnoreCase(CommonConstants.HOUSE_BANK_PAYMENT_MODE_UI_OL)) {
						houseBankAccNoRequest.setPaymentMode(CommonConstants.HOUSE_BANK_PAYMENT_MODE_OL_SP);
					} else if (houseBankAccNoRequest.getPaymentMode()!=null && houseBankAccNoRequest.getPaymentMode().equalsIgnoreCase(CommonConstants.HOUSE_BANK_PAYMENT_MODE_UI_SP)) {
						houseBankAccNoRequest.setPaymentMode(CommonConstants.HOUSE_BANK_PAYMENT_MODE_OL_SP);
					}
					//End:<YogeshM>:<19/02/2018>:<SIT>:<DefectID-HotFixed>:<mail from Deepak-16/02/2018 Subj-egarding getBankAccountNoForPaymentEntryTransTypewise service response Issue || for paymentmode optn "Payment link to Customer" & "Online Payment modes" need to send value as "DA">
					
					//_houseBankResponse = new PaymentEntryServiceResult();
					//_houseBankResponse = accServClient.getHouseBankListForPaymentEntry(smc_source, smc_medium, smc_campaign, houseBankAccNoRequest.getOfficeCode(), houseBankAccNoRequest.getPaymentMode(), pageName);
					List<Object[]> rows = dbService.getHouseBranchNameMap(houseBankAccNoRequest.getOfficeCode(), houseBankAccNoRequest.getPaymentMode() ,houseBankAccNoRequest.getSearchMode());
					  
					if (rows != null && rows.size()>0)
					{
						ArrayList<KeyValuePair> lstKeyValuePair = new ArrayList<KeyValuePair>();
						//Set<String> set = bankMap.keySet();
						for (Object[] tempObj : rows) {
							keyValuePair = new KeyValuePair();
							keyValuePair.setKey(tempObj[0].toString());
							keyValuePair.setPair(tempObj[1].toString());
							lstKeyValuePair.add(keyValuePair);
						}												
						houseBankAccNoResponse=new HouseBankAccNoResponse();
						houseBankAccNoResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
						houseBankAccNoResponse.setMessage("NOERR");
						houseBankAccNoResponse.setLstKeyValuePair(lstKeyValuePair);
					}
					else
					{
						houseBankAccNoResponse=new HouseBankAccNoResponse();
						houseBankAccNoResponse.setResultCode(CommonConstants.FAILURE_STATUS);
						houseBankAccNoResponse.setMessage("No Data Found");
					}
				}
				else if(houseBankAccNoRequest!=null && houseBankAccNoRequest.getOperationType()!=null && houseBankAccNoRequest.getOperationType().equalsIgnoreCase("AccountNumber"))
				{
					//Start:<YogeshM>:<19/02/2018>:<SIT>:<DefectID-HotFixed>:<mail from Deepak-16/02/2018 Subj-egarding getBankAccountNoForPaymentEntryTransTypewise service response Issue || for paymentmode optn "Payment link to Customer" & "Online Payment modes" need to send value as "DA">
					if (houseBankAccNoRequest.getPaymentMode()!=null && houseBankAccNoRequest.getPaymentMode().equalsIgnoreCase(CommonConstants.HOUSE_BANK_PAYMENT_MODE_UI_OL)) {
						houseBankAccNoRequest.setPaymentMode(CommonConstants.HOUSE_BANK_PAYMENT_MODE_OL_SP);
					} else if (houseBankAccNoRequest.getPaymentMode()!=null && houseBankAccNoRequest.getPaymentMode().equalsIgnoreCase(CommonConstants.HOUSE_BANK_PAYMENT_MODE_UI_SP)) {
						houseBankAccNoRequest.setPaymentMode(CommonConstants.HOUSE_BANK_PAYMENT_MODE_OL_SP);
					}
					//End:<YogeshM>:<19/02/2018>:<SIT>:<DefectID-HotFixed>:<mail from Deepak-16/02/2018 Subj-egarding getBankAccountNoForPaymentEntryTransTypewise service response Issue || for paymentmode optn "Payment link to Customer" & "Online Payment modes" need to send value as "DA">
					
					//_houseBankResponse = new PaymentEntryServiceResult();
					//_houseBankResponse = accServClient.getBankAccountNoForPaymentEntryTransTypewise(smc_source, smc_medium, smc_campaign, houseBankAccNoRequest.getOfficeCode(), houseBankAccNoRequest.getPaymentMode(), houseBankAccNoRequest.getBranchCode(), pageName);
					List<Object[]> rows= dbService.getBankAccNoFromPoral(houseBankAccNoRequest.getOfficeCode(), houseBankAccNoRequest.getPaymentMode(),houseBankAccNoRequest.getBranchCode(),houseBankAccNoRequest.getSearchMode());
					
					if (rows != null && rows.size()>0)
					{
						ArrayList<KeyValuePair> lstKeyValuePair = new ArrayList<KeyValuePair>();												
						for (Object tempObj : rows) {
							keyValuePair = new KeyValuePair();
							keyValuePair.setKey(tempObj.toString());
							keyValuePair.setPair(tempObj.toString());
							lstKeyValuePair.add(keyValuePair);
						}													
						houseBankAccNoResponse=new HouseBankAccNoResponse();
						houseBankAccNoResponse.setResultCode(CommonConstants.SUCCESS_STATUS);
						houseBankAccNoResponse.setMessage("NOERR");
						houseBankAccNoResponse.setLstKeyValuePair(lstKeyValuePair);
					}
					else
					{
						houseBankAccNoResponse=new HouseBankAccNoResponse();
						houseBankAccNoResponse.setResultCode(CommonConstants.FAILURE_STATUS);
						houseBankAccNoResponse.setMessage("No Data Found");
					}
				}
				else
				{
					houseBankAccNoResponse=new HouseBankAccNoResponse();
					houseBankAccNoResponse.setMessage(CommonConstants.FASTLANE_WRONG_OPERATION_MSG);
					houseBankAccNoResponse.setResultCode(CommonConstants.FAILURE_STATUS);
				}
				
			}
			catch(Exception e){
				logger.error("Inside TagicCommonServiceImpl :: "+strMethodName+" method : Exception Occurred::", e);
				houseBankAccNoResponse=new HouseBankAccNoResponse();
				houseBankAccNoResponse.setResultCode(CommonConstants.FAILURE_STATUS);
				houseBankAccNoResponse.setMessage(CommonConstants.FASTLANE_EXCEPTION);
			}
			return houseBankAccNoResponse;
		}
	//End: VishalJ <SIT 2717>| service exposed to getHouseBankAndAccountNo from Portal DB on 21 Feb 2018
	
	
	// Start : Vishal<Mantis 3267> :  New method added for renewal serach from Portal  : 16-Jan-2017
	public RenewalSearchResponse renewalSearchPortal(RenewalSearchRequest renewalSearchRequest) throws Exception {
		RenewalSearchResponse renewalSearchResponse=null;
		String strMethodName="renewalSearchPortal";
		ObjectMapper objMap = null;
		long transId = System.nanoTime();
		ArrayList<RenewalSearchData> renewalSearchDataList=new ArrayList<RenewalSearchData>();
		List<RenPolicyMaster> renewalEntityDataList=new ArrayList<RenPolicyMaster>();
		try{
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");						
			objMap = new ObjectMapper();
			//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::JSON Request :- "+objMap.writeValueAsString(renewalSearchRequest));
        
	        RenewalSearchData renewalSearchData=null;	        
	        if(renewalSearchRequest!=null){	 
	        	renewalSearchResponse =new RenewalSearchResponse();
	        	renewalEntityDataList=dbService.renewalSearchPortal(CommonConstants.RENEWAL_ENTITY_CLASSNAME, renewalSearchRequest);
	        	String productCode=null;
	        	logger.info("Inside "+_strClassName+"::"+strMethodName+"::renewalEntityDataList size "+renewalEntityDataList.size());
	        	for(RenPolicyMaster tempRenPolicyMaster : renewalEntityDataList){	        				
    				if(tempRenPolicyMaster!=null){
    				logger.info("Inside "+_strClassName+"::"+strMethodName+"::inside for loop "+tempRenPolicyMaster.getPolicynumber());
    				renewalSearchData = new RenewalSearchData();
    				renewalSearchData.setAddOn(tempRenPolicyMaster.getStraddonplan());
    				renewalSearchData.setCustomerCode(tempRenPolicyMaster.getCustno());
    				//renewalSearchData.setCustomerName(tempRenPolicyMaster.getCustomerName());  Customer Name field is not there in Table
    				if(tempRenPolicyMaster.getDateofbirth()!=null)
    				renewalSearchData.setDob(tempRenPolicyMaster.getDateofbirth().toString());
    				if(tempRenPolicyMaster.getStrlob()!=null){
    					renewalSearchData.setLob(tempRenPolicyMaster.getStrlob());
    					
    					/*lobCode=dbService.getReverseExternalMapCode(null, CommonConstants.Renewal_Search_LobCode_Cat, clsMISDetailSearchGrid.getLOB());
    					if(lobCode!=null)
    					renewalSearchData.setLobCode(lobCode);*/
    				}	        				
    				renewalSearchData.setMobileNo(tempRenPolicyMaster.getMobileno());
    				if(tempRenPolicyMaster.getPolstartdt()!=null){
    					DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
    					Date date1 = inputFormat.parse(tempRenPolicyMaster.getPolstartdt().toString());

    					// Format date into output format
    					DateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
    					String outputString = outputFormat.format(date1);    					
    					renewalSearchData.setPolicyInsDate(outputString);    					
    				}
    				
    				renewalSearchData.setPolicyNo(tempRenPolicyMaster.getPolicynumber());
    				if(tempRenPolicyMaster.getStrproductname() != null){
    					renewalSearchData.setProductName(tempRenPolicyMaster.getStrproductname());	        					
    					productCode=dbService.getReverseExternalMapCode(null, CommonConstants.Renewal_Search_ProductCode_Cat, tempRenPolicyMaster.getStrproductname());
    					if(productCode!=null)
    					renewalSearchData.setProductCode(productCode);
    				}
    				//Start : 21/03/2017: To send productName in JSON Response. 
                    String strval="";
                    
                    List<Product> oComProductList =  (List<Product>) dbService.getProduct("com.majesco.dcf.common.tagic.entity.Product","strprodcd",productCode);
                    if(oComProductList.size()>0){
                    	for(Product productList:oComProductList){	                            		                                  
                              strval = productList.getStrprodname()!=null?productList.getStrprodname().toString():"";
                            
                        }	
                    }	                              
                    //if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getRenewalSearch  :: Fetching Product Name To Go In Response"+strval);
                    renewalSearchData.setProductName(strval);	
                  //End : 21/03/2017: To send productName in JSON Response.
    				
    				
    				
    				renewalSearchData.setRenewalStatus(tempRenPolicyMaster.getStrrenstatus());
    				renewalSearchData.setTotalPremium(tempRenPolicyMaster.getTotalpremium()+"");
    				//Start : 3520 : 14-Mar-2018
    				renewalSearchData.setProducerCode(tempRenPolicyMaster.getProducercd());
    				//End : 3520 : 14-Mar-2018
    				
    				renewalSearchData.setVehRegNo(tempRenPolicyMaster.getVeh_reg_no()== null ? "-" : tempRenPolicyMaster.getVeh_reg_no());	     				
    				renewalSearchData.setMake(tempRenPolicyMaster.getMake() == null ? "" : tempRenPolicyMaster.getMake() );
    				renewalSearchData.setModel(tempRenPolicyMaster.getModel() == null  ? "" : tempRenPolicyMaster.getModel());
    				renewalSearchData.setRen_status_cd(tempRenPolicyMaster.getRen_status_cd() == null ? "-" : tempRenPolicyMaster.getModel());
    				renewalSearchData.setTxt_customer_name(tempRenPolicyMaster.getTxt_customer_name() == null ? "-" : tempRenPolicyMaster.getTxt_customer_name());
					logger.info("Customer Name :- ## "+tempRenPolicyMaster.getTxt_customer_name());
    				
    				
    				//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getRenewalSearch  ProductCode**"+productCode+"**");
    				//if(clsMISDetailSearchGrid.getRenewalStatus().equalsIgnoreCase("Pending") && productCode!=null && (productCode.equalsIgnoreCase(CommonConstants.PRIVATE_CAR_PRODUCT_CODE) || productCode.equalsIgnoreCase(CommonConstants.TWO_WHEELER_PRODUCT_CODE)))  // added to fetch only pending details //Commented For Issue ID 1679
    				if(tempRenPolicyMaster.getStrrenstatus().equalsIgnoreCase("ACCEPTED") && productCode!=null && (productCode.equalsIgnoreCase(CommonConstants.PRIVATE_CAR_PRODUCT_CODE) || productCode.equalsIgnoreCase(CommonConstants.TWO_WHEELER_PRODUCT_CODE) || productCode.equalsIgnoreCase(CommonConstants.COMMERCIAL_PRODUCT_CODE)))  // added to fetch only pending details //Added For Issue ID 1679    				
    					renewalSearchDataList.add(renewalSearchData);
    				}
    			}
	        	
	        	if(renewalSearchDataList!=null && renewalSearchDataList.size()>0){
	        		//if(logger.isDebugEnabled())logger.debug("TransactionID:"+transId+" :: Inside TagicCommonServiceImpl :: getRenewalSearchfromPortal Got Some Data"+objMap.writeValueAsString(renewalSearchDataList));
	        		renewalSearchResponse.setRenewalSearchDataList(renewalSearchDataList);
	        		renewalSearchResponse.setResultCode(CommonConstants.SUCCESS_STATUS);	
	        	}else{
	        		renewalSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
	        	}
	        		
	        }	       	   	        			        			        			        		        			        				        				        			
	        				        				        			        		        			        			        			        		        			
		}catch(Exception ex){
			logger.error("Inside TagicCommonServiceImpl :: "+strMethodName+" method ::Exception::",ex);
			renewalSearchResponse=new RenewalSearchResponse();
			renewalSearchResponse.setResultCode(CommonConstants.FAILURE_STATUS);
			renewalSearchResponse.setMessage(ex.getMessage());	
		}

		logger.info("RenewalSearchResponse :- ## "+objMap.writeValueAsString(renewalSearchResponse));

		return renewalSearchResponse;		
	}
	// End : Vishal<Mantis 3267> :  New method added for renewal serach from Portal : 16-Jan-2017
		//Service to get FieldUser info
		/* (non-Javadoc)
		 * @see com.majesco.dcf.common.tagic.service.TagicCommonService#getFieldUserInfo(com.majesco.dcf.common.tagic.json.UserObject)
		 */
		public UserInfoResponse getFieldUserInfo(@RequestBody UserObject userObject){
			UserInfoResponse userInfoResponse=null;
			userInfoResponse=new UserInfoResponse();   
			String strMethodName="getFieldUserInfo";
			ObjectMapper objMap = null;	
			String authenticationToken =null;
			try{
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered");
				String serviceUrl=getWSDLURL(CommonConstants.GENERIC_COVERNOTE_SERVICE);
				URL wsdlUrl=new URL(serviceUrl);
				GenericSerive_Service genericService=new GenericSerive_Service(wsdlUrl);
				GenericSerive port=genericService.getSOAPOverHTTP();
				ServiceUtility serviceUtil=new ServiceUtility();
				objMap = new ObjectMapper();
				serviceUtil.addClientInterceptor(port);
				
				if(userObject.getAuthToken()!=null)
					 authenticationToken=userObject.getAuthToken();
				
				
		        com.unotechsoft.stub.genericservice.client.LOVTypeFieldUserDetails _getLOVProducerOfficeField_objfield = new com.unotechsoft.stub.genericservice.client.LOVTypeFieldUserDetails();
		        _getLOVProducerOfficeField_objfield.setFieldUserCode(userObject.getUserID());
		        logger.info("Inside "+_strClassName+"::"+strMethodName+"::Setting USer ID :- "+userObject.getUserID());
		        logger.info("Inside "+_strClassName+"::"+strMethodName+"::Calling getLOVProducerOfficeField");
				com.unotechsoft.stub.genericservice.client.GenericResult _getLOVProducerOfficeField__return = port.getLOVProducerOfficeField(smc_source, smc_medium, smc_campaign,authenticationToken, _getLOVProducerOfficeField_objfield);
				logger.info("Inside "+_strClassName+"::"+strMethodName+"::After Call getLOVProducerOfficeField");
				if(_getLOVProducerOfficeField__return !=null)
				{
					com.unotechsoft.stub.genericservice.client.ArrayOfLOVType arrayOfLOVType= _getLOVProducerOfficeField__return.getLOVTypes();
					logger.info("Inside "+_strClassName+"::"+strMethodName+"Inside If");
					if(arrayOfLOVType!=null)
					{
	                    List<com.unotechsoft.stub.genericservice.client.LOVType> LOVTypeList= arrayOfLOVType.getLOVType();
	                    if(LOVTypeList!=null && LOVTypeList.size()>0){
	                    	LOVTypeFieldUserDetails lOVTypeFieldUserDetails=(com.unotechsoft.stub.genericservice.client.LOVTypeFieldUserDetails)LOVTypeList.get(0);	
	                    
	                          if(lOVTypeFieldUserDetails!=null)
	                          {
	                        	  UserDetails userDetails=new UserDetails();
	                        	  if(lOVTypeFieldUserDetails.getProducerType()!=null)
	                        	  {
	                        		  
	                        		  String producerType =lOVTypeFieldUserDetails.getProducerType();
	                        		  if(producerType.equalsIgnoreCase("Partner Representative"))
	                        		  {
	                        			  userDetails.setProducerCode(lOVTypeFieldUserDetails.getParentProducerCode());
	                        			  userDetails.setProducerName(lOVTypeFieldUserDetails.getParentProducerName());
	                        			  userDetails.setUserName(lOVTypeFieldUserDetails.getFieldUserName());
	                        			  userDetails.setUserID(lOVTypeFieldUserDetails.getFieldUserCode());
	                        		  }
	                        		  else
	                        		  {
	                        			  userDetails.setProducerCode(lOVTypeFieldUserDetails.getIntermediaryCode());
	                        			  userDetails.setProducerName(lOVTypeFieldUserDetails.getProducerName());
	                        			  userDetails.setUserName(lOVTypeFieldUserDetails.getFieldUserName());
	                        			  userDetails.setUserID(lOVTypeFieldUserDetails.getFieldUserCode());
	                        		  }
	                        		  
	                        	  }
	                        	  userInfoResponse.setUserInfoDetails(userDetails);                         
	                        	  userInfoResponse.setResultCode(CommonConstants.SUCCESS_STATUS); 
	                          }
					
	                    } 
	                    
					}
				}
				logger.info("Inside "+_strClassName+"::"+strMethodName+":: Exit");
			}
			catch(Exception ex){
				logger.error("Inside TagicCommonServiceImpl :: "+strMethodName+" method ::Exception::",ex);
				userInfoResponse=new UserInfoResponse();
				userInfoResponse.setResultCode(CommonConstants.FAILURE_STATUS);
				userInfoResponse.setMessage(ex.getMessage());	
			}		
			
			return userInfoResponse;
		}	
    	
		//Start: VishalJ <New Report Issue>| Service to be created for giving token
		@Override
		public QlikTicketResponse getQlikTicketNo(UserObject userObject) throws Exception{
			Ticket ticket = new Ticket();		
			String ticketNo = ticket.getQlikTicket(userObject.getProducerCode(), "QAP");
			QlikTicketResponse qlikTicketResponse = new QlikTicketResponse();
			qlikTicketResponse.setQlikTicketNo(ticketNo);
			return qlikTicketResponse;
		}
		
		//End:VishalJ <New Report Issue>| Service to be created for giving token
		
		/*Code Added For Reports Changes - Starts Here*/
		public String getEncryptedProducerCode(String producerCode) {
		    try {
		    	String booleanRes = null;
		    	ObjectMapper obj = new ObjectMapper();
		    	String jsonText = null;
		    	String valFrmDB = null;
		    	logger.info("getEncryptedProducerCode:: producerCode--> "+producerCode);
		    	
		    	valFrmDB = dbService.getConfigParamVal("producercodeEncrypt");
		    	logger.info("getEncryptedProducerCode:: valFrmDB "+obj.writeValueAsString(valFrmDB));
		    	if(valFrmDB!=null)
		    	{
			        String url = valFrmDB + producerCode;
			        InputStream res = new URL(url).openStream();
			        BufferedReader rd = new BufferedReader(new InputStreamReader(res, Charset.forName("UTF-8")));
	
			        StringBuilder sb = new StringBuilder();
			        int cp;
			        while ((cp = rd.read()) != -1) {
			            sb.append((char) cp);
			        }
			        jsonText = sb.toString();
			        logger.info("getEncryptedProducerCode:: jsonText0 "+obj.writeValueAsString(jsonText));
			        res.close();
			        
			        logger.info("getEncryptedProducerCode:: jsonText1 "+obj.writeValueAsString(jsonText));
			        
			        if(jsonText!=null && !jsonText.equals(""))
			        {
			        	logger.info("getEncryptedProducerCode:: jsonText "+obj.writeValueAsString(jsonText));
			        	JSONParser parser = new JSONParser(); 
			        	JSONObject jsonObject = (JSONObject) parser.parse(jsonText);
			        	booleanRes =   (String) jsonObject.get("encryptedId");
			        	logger.info("getEncryptedProducerCode:: booleanRes "+booleanRes);
			        }
			        else
			        {
			        	booleanRes = "ERROR";
			        }
		    	}
		        
		        return booleanRes;
		    } catch (Exception e) {
		    	e.printStackTrace();
		    	logger.error("getEncryptedProducerCode:: Exception Ocurred ",e);
		        return "EXCEPTION";
		    }
		}
		/*Code Added For Reports Changes - Ends Here*/
		
}

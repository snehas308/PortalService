package com.majesco.dcf.common.tagic.json;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CalculateHomeResponse {

	
	private String result;
	private String quotationNumber;
	private String quotationVersion;
	private List<ResponseError> ErrorList = null ;
	private List<PremiumDetails> premiumDetails = null;
	

	
	
	public List<PremiumDetails> getPremiumDetails() {
		return premiumDetails;
	}
	public void setPremiumDetails(List<PremiumDetails> premiumDetails) {
		this.premiumDetails = premiumDetails;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getQuotationNumber() {
		return quotationNumber;
	}
	public void setQuotationNumber(String quotationNumber) {
		this.quotationNumber = quotationNumber;
	}
	public String getQuotationVersion() {
		return quotationVersion;
	}
	public void setQuotationVersion(String quotationVersion) {
		this.quotationVersion = quotationVersion;
	}
	public List<ResponseError> getErrorList() {
		return ErrorList;
	}
	public void setErrorList(List<ResponseError> errorList) {
		ErrorList = errorList;
	}
	

	
}

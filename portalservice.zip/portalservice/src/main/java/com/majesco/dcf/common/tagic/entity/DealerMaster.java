package com.majesco.dcf.common.tagic.entity;



import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_ch_intermediary_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_ch_intermediary_m")								// Added for Oracle Migration
public class DealerMaster {
	  private String strintermediarycd ="";
	  private String strintermediaryname ="";
	  private String dtbirth ="";
	  private String dtintermediarystart ="";
	  private String dtintermediaryend ="";
	  private BigDecimal nintermediarystatus ;
	  private String strintermediarystatus ="";
	  private String strindcorpflag ="";
	  private BigDecimal ncategoryid ;
	  private String strlicenseno ="";
	  private String strpanno ="";
	  private BigDecimal nlocationcd ;
	  private BigDecimal nbranchcd ;
	  private String strbankbranch ="";
	  private String straccountno ="";
	  private String strparentintermediarycd ="";
	  private BigDecimal nynparent ;
	  private BigDecimal nyndealer ;
	  private BigDecimal nbankcd ;
	  private String strifscd ="";
	  private String strmicrcd ="";
	  private BigDecimal niscorpbranch ;
	  private BigDecimal ncommremtype ;
	  private String strcommpaymode ="";
	  private String strinterpaymentfreq ="";
	  private BigDecimal npaylocationcd ;
	  private String strpayeename ="";
	  private BigDecimal npayoutpayto ;
	  private BigDecimal npartnerid ;
	  private String strchanneltype ="";
	  private String strgender ="";
	  private String struidno ="";
	  private BigDecimal naccounttype ;
	  private String strsalutation ="";
	  private String strdnd ="";
	  private BigDecimal nofficecd ;
	  private String strstatus ="";
	  private BigDecimal nproducerprofilecd ;
	  private String strsubtype ="";
	  private String strreasonsuspension ="";
	  private String strotherreasonsus ="";
	  private String strcategory ="";
	  private String strsubtransfercategory ="";
	  private String stralternatecd ="";
	  private String strissubproducer ="";
	  private String strchequedispatchedto ="";
	  private String strchequedisbursement ="";
	  private String strissuingcompanycd ="";
	  private String dtsubproducerissuedt ="";
	  private BigDecimal nchannelid ;
	  private BigDecimal nchqdisptchoffcloc ;
	  private String strdealercd ="";
	  private String strdealername ="";
	  private String strapprovalstatus ="";
	  private String strchecklocationcdm ="";
	  private String strcheckalllocation ="";
	  private String dtstatusefectivedt ="";
	  private String stremailsmsreqd ="";
	  private String stralt_dnd ="";
	  private String dtcreated ="";
	  private String strcreatedby ="";
	  private String dtupdated ="";
	  private String strupdatedby ="";
	
	@Id
	@Column(name = "strintermediarycd")
	public String getStrintermediarycd() {
		return strintermediarycd;
	}
	public void setStrintermediarycd(String strintermediarycd) {
		this.strintermediarycd = strintermediarycd;
	}
	
	@Column(name = "strintermediaryname")
	public String getStrintermediaryname() {
		return strintermediaryname;
	}
	public void setStrintermediaryname(String strintermediaryname) {
		this.strintermediaryname = strintermediaryname;
	}
	
	@Column(name = "dtbirth")
	public String getDtbirth() {
		return dtbirth;
	}
	public void setDtbirth(String dtbirth) {
		this.dtbirth = dtbirth;
	}
	
	@Column(name = "dtintermediarystart")
	public String getDtintermediarystart() {
		return dtintermediarystart;
	}
	public void setDtintermediarystart(String dtintermediarystart) {
		this.dtintermediarystart = dtintermediarystart;
	}
	
	@Column(name = "dtintermediaryend")
	public String getDtintermediaryend() {
		return dtintermediaryend;
	}
	public void setDtintermediaryend(String dtintermediaryend) {
		this.dtintermediaryend = dtintermediaryend;
	}
	
	@Column(name = "nintermediarystatus")
	public BigDecimal getNintermediarystatus() {
		return nintermediarystatus;
	}
	public void setNintermediarystatus(BigDecimal nintermediarystatus) {
		this.nintermediarystatus = nintermediarystatus;
	}
	
	@Column(name = "strintermediarystatus")
	public String getStrintermediarystatus() {
		return strintermediarystatus;
	}
	public void setStrintermediarystatus(String strintermediarystatus) {
		this.strintermediarystatus = strintermediarystatus;
	}
	
	@Column(name = "strindcorpflag")
	public String getStrindcorpflag() {
		return strindcorpflag;
	}
	public void setStrindcorpflag(String strindcorpflag) {
		this.strindcorpflag = strindcorpflag;
	}
	
	@Column(name = "ncategoryid")
	public BigDecimal getNcategoryid() {
		return ncategoryid;
	}
	public void setNcategoryid(BigDecimal ncategoryid) {
		this.ncategoryid = ncategoryid;
	}
	
	@Column(name = "strlicenseno")
	public String getStrlicenseno() {
		return strlicenseno;
	}
	public void setStrlicenseno(String strlicenseno) {
		this.strlicenseno = strlicenseno;
	}
	
	@Column(name = "strpanno")
	public String getStrpanno() {
		return strpanno;
	}
	public void setStrpanno(String strpanno) {
		this.strpanno = strpanno;
	}
	
	@Column(name = "nlocationcd")
	public BigDecimal getNlocationcd() {
		return nlocationcd;
	}
	public void setNlocationcd(BigDecimal nlocationcd) {
		this.nlocationcd = nlocationcd;
	}
	
	@Column(name = "nbranchcd")
	public BigDecimal getNbranchcd() {
		return nbranchcd;
	}
	public void setNbranchcd(BigDecimal nbranchcd) {
		this.nbranchcd = nbranchcd;
	}
	
	@Column(name = "strbankbranch")
	public String getStrbankbranch() {
		return strbankbranch;
	}
	public void setStrbankbranch(String strbankbranch) {
		this.strbankbranch = strbankbranch;
	}
	
	@Column(name = "straccountno")
	public String getStraccountno() {
		return straccountno;
	}
	public void setStraccountno(String straccountno) {
		this.straccountno = straccountno;
	}
	
	@Column(name = "strparentintermediarycd")
	public String getStrparentintermediarycd() {
		return strparentintermediarycd;
	}
	public void setStrparentintermediarycd(String strparentintermediarycd) {
		this.strparentintermediarycd = strparentintermediarycd;
	}
	
	@Column(name = "nynparent")
	public BigDecimal getNynparent() {
		return nynparent;
	}
	public void setNynparent(BigDecimal nynparent) {
		this.nynparent = nynparent;
	}
	
	@Column(name = "nyndealer")
	public BigDecimal getNyndealer() {
		return nyndealer;
	}
	public void setNyndealer(BigDecimal nyndealer) {
		this.nyndealer = nyndealer;
	}
	
	@Column(name = "nbankcd")
	public BigDecimal getNbankcd() {
		return nbankcd;
	}
	public void setNbankcd(BigDecimal nbankcd) {
		this.nbankcd = nbankcd;
	}
	
	@Column(name = "strifscd")
	public String getStrifscd() {
		return strifscd;
	}
	public void setStrifscd(String strifscd) {
		this.strifscd = strifscd;
	}
	
	@Column(name = "strmicrcd")
	public String getStrmicrcd() {
		return strmicrcd;
	}
	public void setStrmicrcd(String strmicrcd) {
		this.strmicrcd = strmicrcd;
	}
	
	@Column(name = "niscorpbranch")
	public BigDecimal getNiscorpbranch() {
		return niscorpbranch;
	}
	public void setNiscorpbranch(BigDecimal niscorpbranch) {
		this.niscorpbranch = niscorpbranch;
	}
	
	@Column(name = "ncommremtype")
	public BigDecimal getNcommremtype() {
		return ncommremtype;
	}
	public void setNcommremtype(BigDecimal ncommremtype) {
		this.ncommremtype = ncommremtype;
	}
	
	@Column(name = "strcommpaymode")
	public String getStrcommpaymode() {
		return strcommpaymode;
	}
	public void setStrcommpaymode(String strcommpaymode) {
		this.strcommpaymode = strcommpaymode;
	}
	
	@Column(name = "strinterpaymentfreq")
	public String getStrinterpaymentfreq() {
		return strinterpaymentfreq;
	}
	public void setStrinterpaymentfreq(String strinterpaymentfreq) {
		this.strinterpaymentfreq = strinterpaymentfreq;
	}
	
	@Column(name = "npaylocationcd")
	public BigDecimal getNpaylocationcd() {
		return npaylocationcd;
	}
	public void setNpaylocationcd(BigDecimal npaylocationcd) {
		this.npaylocationcd = npaylocationcd;
	}
	
	@Column(name = "strpayeename")
	public String getStrpayeename() {
		return strpayeename;
	}
	public void setStrpayeename(String strpayeename) {
		this.strpayeename = strpayeename;
	}
	
	@Column(name = "npayoutpayto")
	public BigDecimal getNpayoutpayto() {
		return npayoutpayto;
	}
	public void setNpayoutpayto(BigDecimal npayoutpayto) {
		this.npayoutpayto = npayoutpayto;
	}
	
	@Column(name = "npartnerid")
	public BigDecimal getNpartnerid() {
		return npartnerid;
	}
	public void setNpartnerid(BigDecimal npartnerid) {
		this.npartnerid = npartnerid;
	}
	
	@Column(name = "strchanneltype")
	public String getStrchanneltype() {
		return strchanneltype;
	}
	public void setStrchanneltype(String strchanneltype) {
		this.strchanneltype = strchanneltype;
	}
	
	@Column(name = "strgender")
	public String getStrgender() {
		return strgender;
	}
	public void setStrgender(String strgender) {
		this.strgender = strgender;
	}
	
	@Column(name = "struidno")
	public String getStruidno() {
		return struidno;
	}
	public void setStruidno(String struidno) {
		this.struidno = struidno;
	}
	
	@Column(name = "naccounttype")
	public BigDecimal getNaccounttype() {
		return naccounttype;
	}
	public void setNaccounttype(BigDecimal naccounttype) {
		this.naccounttype = naccounttype;
	}
	
	@Column(name = "strsalutation")
	public String getStrsalutation() {
		return strsalutation;
	}
	public void setStrsalutation(String strsalutation) {
		this.strsalutation = strsalutation;
	}
	
	@Column(name = "strdnd")
	public String getStrdnd() {
		return strdnd;
	}
	public void setStrdnd(String strdnd) {
		this.strdnd = strdnd;
	}
	
	@Column(name = "nofficecd")
	public BigDecimal getNofficecd() {
		return nofficecd;
	}
	public void setNofficecd(BigDecimal nofficecd) {
		this.nofficecd = nofficecd;
	}
	
	@Column(name = "strstatus")
	public String getStrstatus() {
		return strstatus;
	}
	public void setStrstatus(String strstatus) {
		this.strstatus = strstatus;
	}
	
	@Column(name = "nproducerprofilecd")
	public BigDecimal getNproducerprofilecd() {
		return nproducerprofilecd;
	}
	public void setNproducerprofilecd(BigDecimal nproducerprofilecd) {
		this.nproducerprofilecd = nproducerprofilecd;
	}
	
	@Column(name = "strsubtype")
	public String getStrsubtype() {
		return strsubtype;
	}
	public void setStrsubtype(String strsubtype) {
		this.strsubtype = strsubtype;
	}
	
	@Column(name = "strreasonsuspension")
	public String getStrreasonsuspension() {
		return strreasonsuspension;
	}
	public void setStrreasonsuspension(String strreasonsuspension) {
		this.strreasonsuspension = strreasonsuspension;
	}
	
	@Column(name = "strotherreasonsus")
	public String getStrotherreasonsus() {
		return strotherreasonsus;
	}
	public void setStrotherreasonsus(String strotherreasonsus) {
		this.strotherreasonsus = strotherreasonsus;
	}
	
	@Column(name = "strcategory")
	public String getStrcategory() {
		return strcategory;
	}
	public void setStrcategory(String strcategory) {
		this.strcategory = strcategory;
	}
	
	@Column(name = "strsubtransfercategory")
	public String getStrsubtransfercategory() {
		return strsubtransfercategory;
	}
	public void setStrsubtransfercategory(String strsubtransfercategory) {
		this.strsubtransfercategory = strsubtransfercategory;
	}
	
	@Column(name = "stralternatecd")
	public String getStralternatecd() {
		return stralternatecd;
	}
	public void setStralternatecd(String stralternatecd) {
		this.stralternatecd = stralternatecd;
	}
	
	@Column(name = "strissubproducer")
	public String getStrissubproducer() {
		return strissubproducer;
	}
	public void setStrissubproducer(String strissubproducer) {
		this.strissubproducer = strissubproducer;
	}
	
	@Column(name = "strchequedispatchedto")
	public String getStrchequedispatchedto() {
		return strchequedispatchedto;
	}
	public void setStrchequedispatchedto(String strchequedispatchedto) {
		this.strchequedispatchedto = strchequedispatchedto;
	}
	
	@Column(name = "strchequedisbursement")
	public String getStrchequedisbursement() {
		return strchequedisbursement;
	}
	public void setStrchequedisbursement(String strchequedisbursement) {
		this.strchequedisbursement = strchequedisbursement;
	}
	
	@Column(name = "strissuingcompanycd")
	public String getStrissuingcompanycd() {
		return strissuingcompanycd;
	}
	public void setStrissuingcompanycd(String strissuingcompanycd) {
		this.strissuingcompanycd = strissuingcompanycd;
	}
	
	@Column(name = "dtsubproducerissuedt")
	public String getDtsubproducerissuedt() {
		return dtsubproducerissuedt;
	}
	public void setDtsubproducerissuedt(String dtsubproducerissuedt) {
		this.dtsubproducerissuedt = dtsubproducerissuedt;
	}
	
	@Column(name = "nchannelid")
	public BigDecimal getNchannelid() {
		return nchannelid;
	}
	public void setNchannelid(BigDecimal nchannelid) {
		this.nchannelid = nchannelid;
	}
	
	@Column(name = "nchqdisptchoffcloc")
	public BigDecimal getNchqdisptchoffcloc() {
		return nchqdisptchoffcloc;
	}
	public void setNchqdisptchoffcloc(BigDecimal nchqdisptchoffcloc) {
		this.nchqdisptchoffcloc = nchqdisptchoffcloc;
	}
	
	@Column(name = "strdealercd")
	public String getStrdealercd() {
		return strdealercd;
	}
	public void setStrdealercd(String strdealercd) {
		this.strdealercd = strdealercd;
	}
	
	@Column(name = "strdealername")
	public String getStrdealername() {
		return strdealername;
	}
	public void setStrdealername(String strdealername) {
		this.strdealername = strdealername;
	}
	
	@Column(name = "strapprovalstatus")
	public String getStrapprovalstatus() {
		return strapprovalstatus;
	}
	public void setStrapprovalstatus(String strapprovalstatus) {
		this.strapprovalstatus = strapprovalstatus;
	}
	
	@Column(name = "strchecklocationcdm")
	public String getStrchecklocationcdm() {
		return strchecklocationcdm;
	}
	public void setStrchecklocationcdm(String strchecklocationcdm) {
		this.strchecklocationcdm = strchecklocationcdm;
	}
	
	@Column(name = "strcheckalllocation")
	public String getStrcheckalllocation() {
		return strcheckalllocation;
	}
	public void setStrcheckalllocation(String strcheckalllocation) {
		this.strcheckalllocation = strcheckalllocation;
	}
	
	@Column(name = "dtstatusefectivedt")
	public String getDtstatusefectivedt() {
		return dtstatusefectivedt;
	}
	public void setDtstatusefectivedt(String dtstatusefectivedt) {
		this.dtstatusefectivedt = dtstatusefectivedt;
	}
	
	@Column(name = "stremailsmsreqd")
	public String getStremailsmsreqd() {
		return stremailsmsreqd;
	}
	public void setStremailsmsreqd(String stremailsmsreqd) {
		this.stremailsmsreqd = stremailsmsreqd;
	}
	
	@Column(name = "stralt_dnd")
	public String getStralt_dnd() {
		return stralt_dnd;
	}
	public void setStralt_dnd(String stralt_dnd) {
		this.stralt_dnd = stralt_dnd;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	
	//@Column(name = "strrtolocgrpcd")
		

}

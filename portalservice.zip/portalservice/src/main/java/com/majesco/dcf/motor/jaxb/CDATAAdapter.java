package com.majesco.dcf.motor.jaxb;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class CDATAAdapter extends XmlAdapter<String, String> {
 
    @Override
    public String marshal(String v) throws Exception {
        //return "<![CDATA[" + v + "]]>";	//We are not using CDATAAdapter In PortalService as we already using own Interceptor, because facing issues for &lt; &gt;
    	return v;
    }
 
    @Override
    public String unmarshal(String v) throws Exception {
        return v;
    }
}

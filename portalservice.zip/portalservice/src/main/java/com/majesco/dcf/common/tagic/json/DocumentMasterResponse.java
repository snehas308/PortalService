package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocumentMasterResponse {
	private List<String> strdcodesc;
	private List<Integer> nisrequired;
	private List<ResponseError> resErr;
	
	public List<String> getStrdcodesc() {
		return strdcodesc;
	}
	public void setStrdcodesc(List<String> strdcodesc) {
		this.strdcodesc = strdcodesc;
	}
	public List<Integer> getNisrequired() {
		return nisrequired;
	}
	public void setNisrequired(List<Integer> nisrequired) {
		this.nisrequired = nisrequired;
	}
			
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
}

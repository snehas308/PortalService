package com.majesco.dcf.motor.json;

import com.majesco.dcf.common.tagic.util.ServiceUtility;

public class RiskDetails {

	private String vehicleType; 
	private String businessType;
	private String policyCoverVariant;
	private String polIncpnDt;//Policy Inception Date
	private String polIncpnTm;//Policy Inception Time
	private String polTerm; //Policy Term
	private String tataAIGBrnch; //TATA AIG Branch
	private String polExpDt;//Policy Expiry Date
	private String polExpTm;//Policy Expiry Time
	private String officeCode;
	private String officeName;
	private String displayOfficeCode;
	private String branchOfficeCode;
	ServiceUtility serviceUtility = new ServiceUtility();
	public String getPolExpDt() {
		return polExpDt;
	}
	public void setPolExpDt(String polExpDt) {
		polExpDt = serviceUtility.blankToNullCheck(polExpDt);
		this.polExpDt = polExpDt;
	}
	public String getPolExpTm() {
		return polExpTm;
	}
	public void setPolExpTm(String polExpTm) {
		polExpTm = serviceUtility.blankToNullCheck(polExpTm);
		this.polExpTm = polExpTm;
	}
	public String getPolIncpnDt() {
		return polIncpnDt;
	}
	public void setPolIncpnDt(String polIncpnDt) {
		polIncpnDt = serviceUtility.blankToNullCheck(polIncpnDt);
		this.polIncpnDt = polIncpnDt;
	}
	public String getPolTerm() {
		return polTerm;
	}
	public void setPolTerm(String polTerm) {
		polTerm = serviceUtility.blankToNullCheck(polTerm);
		this.polTerm = polTerm;
	}
	public String getTataAIGBrnch() {
		return tataAIGBrnch;
	}
	public void setTataAIGBrnch(String tataAIGBrnch) {
		tataAIGBrnch = serviceUtility.blankToNullCheck(tataAIGBrnch);
		this.tataAIGBrnch = tataAIGBrnch;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		vehicleType = serviceUtility.blankToNullCheck(vehicleType);
		this.vehicleType = vehicleType;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		businessType = serviceUtility.blankToNullCheck(businessType);
		this.businessType = businessType;
	}
	public String getPolicyCoverVariant() {
		return policyCoverVariant;
	}
	public void setPolicyCoverVariant(String policyCoverVariant) {
		policyCoverVariant = serviceUtility.blankToNullCheck(policyCoverVariant);
		this.policyCoverVariant = policyCoverVariant;
	}
	public String getPolIncpnTm() {
		return polIncpnTm;
	}
	public void setPolIncpnTm(String polIncpnTm) {
		polIncpnTm = serviceUtility.blankToNullCheck(polIncpnTm);
		this.polIncpnTm = polIncpnTm;
	}
	public String getOfficeCode() {
		return officeCode;
	}
	public void setOfficeCode(String officeCode) {
		officeCode = serviceUtility.blankToNullCheck(officeCode);
		this.officeCode = officeCode;
	}
	public String getOfficeName() {
		return officeName;
	}
	public void setOfficeName(String officeName) {
		officeName = serviceUtility.blankToNullCheck(officeName);
		this.officeName = officeName;
	}
	public String getDisplayOfficeCode() {
		return displayOfficeCode;
	}
	public void setDisplayOfficeCode(String displayOfficeCode) {
		displayOfficeCode = serviceUtility.blankToNullCheck(displayOfficeCode);
		this.displayOfficeCode = displayOfficeCode;
	}
	public String getBranchOfficeCode() {
		return branchOfficeCode;
	}
	public void setBranchOfficeCode(String branchOfficeCode) {
		branchOfficeCode = serviceUtility.blankToNullCheck(branchOfficeCode);
		this.branchOfficeCode = branchOfficeCode;
	}
	
	
	
}

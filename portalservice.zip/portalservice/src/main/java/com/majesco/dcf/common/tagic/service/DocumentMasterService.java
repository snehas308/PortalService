package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.entity.DocumentMaster;
import com.majesco.dcf.common.tagic.json.DocumentMasterRequest;
import com.majesco.dcf.common.tagic.json.DocumentMasterResponse;
import com.majesco.dcf.common.tagic.json.DocumentVO;
import com.majesco.dcf.common.tagic.json.ResponseError;

@Service
public class DocumentMasterService {
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(DocumentMasterService.class);
	
	@SuppressWarnings({ "null", "unchecked" })
	public DocumentMasterResponse FetchDocInfo(DocumentMasterRequest docreq) throws Exception
	{
		DocumentMasterResponse docres = new DocumentMasterResponse();
		ArrayList docArr = new ArrayList();
		DocumentVO docVO = null;
		try
		{
		
			logger.info("In DocumentService.FetchDocumentInfo() Method Begin()...");
			
			String strdcodesc="";
			BigDecimal nisrequired;
			
			List<String> lstStrdcodesc = new ArrayList<String>();
			List<Integer> lstNisrequired = new ArrayList<Integer>();
					
			
			
			List<ResponseError> reserrList = new ArrayList<ResponseError>();
			
			
			ResponseError res = new ResponseError();
			res.setErrorCode("101");
			res.setErrorMMessag("Sorry Authentication Issue....");
			reserrList.add(res);
			
	
			docArr = (ArrayList) dbserv.getDocumentResponse("com.majesco.dcf.common.tagic.entity.DocumentMaster", docreq);
	        for(int i=0; i< docArr.size(); i++)
	        {
	        	docVO = new DocumentVO();
	        	docVO = (DocumentVO) docArr.get(i);
	        	strdcodesc = nullCheckString(docVO.getStrdcodesc().toString());
	        	nisrequired = docVO.getNisrequired();	//Need To Check How To Handle NULL?
	        	lstStrdcodesc.add(nullCheckString(strdcodesc));
	        	lstNisrequired.add(nisrequired==null?0:nisrequired.intValue());
	        }
	        
	        docres.setStrdcodesc(lstStrdcodesc);
	        docres.setNisrequired(lstNisrequired);
		}
		catch(Exception e)
		{
			//System.out.println(e.toString());
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In DocumentService.DocumentInfo() Method End()...");
//		ObjectMapper objMap=new ObjectMapper();
//		System.out.println(objMap.writeValueAsString(docres));
		logger.info("In DocumentService.DocumentInfo() Method :: Response Of variantres : "+docres);
		
		return docres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }
}

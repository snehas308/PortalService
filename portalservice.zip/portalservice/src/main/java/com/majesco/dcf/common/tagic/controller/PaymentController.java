package com.majesco.dcf.common.tagic.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate; //1266

import com.google.gson.Gson;
import com.majesco.dcf.common.tagic.json.BilldeskRequestData;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.PaymentService;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.pg.service.PGDBService; //1266
import com.upi.merchanttoolkit.security.UPISecurity;

//Start:1266
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;
import com.majesco.dcf.pg.upi.json.UPITxnEnquiryResponse;
import com.majesco.dcf.pg.upi.json.UpiTransactionRequest;
import com.majesco.dcf.pg.upi.json.UpiTransactionResponse;
import com.majesco.dcf.pg.upi.service.UPIService; //1266
import com.majesco.dcf.pg.util.PGConstants;
import com.majesco.dcf.pg.util.UPIPaymentHandler;
import org.json.simple.JSONArray;
import com.majesco.dcf.usermgmt.json.UserCredentials;
import com.majesco.dcf.common.chp.usermgmt.util.OAuth2Constants;
import com.majesco.dcf.common.chp.util.AesUtil;
import com.upi.merchanttoolkit.security.UPISecurity;


@Controller
@RequestMapping(value="/payment")
public class PaymentController {
	@Autowired
	PaymentService paymentService;
	@Autowired
	DBService dbService;
@Autowired
	UPIService upiService;  //1266
	
	@Autowired
	PGDBService pgdbService;	//1266

	//Start: RahulT <1908>| fetch userid/password for SPL cases
	

	@Value("${default.userid.spl}")
	private String defaultSPLUseerId;
	
	@Value("${default.password.spl}")
	private String defaultSPLPassword;
	
	@Value("${usgmgt.url}")
	private String usermgtBaseURL;
	//End: RahulT <1908>| fetch userid/password for SPL cases
	
	//Start:1266
	@Value("${upi.checksum}")
	private String upiChecksum;
	//End:1266
		

	
	final static Logger logger = Logger.getLogger(PaymentController.class);
	
	/*@RequestMapping(value = "/payreqBillDesk/{orderID}/{amt}/{userId}/{txtPayCategory}/{propNumber}/{productCode}/{producerCode}/{transType}", method = RequestMethod.GET)*/   // Commented for VAPT issue by Anil Avhad on on 17-Mar-2018
	@RequestMapping(value = "/payreqBillDesk", method = RequestMethod.POST)
	public String payreqBillDesk(Locale locale, Model model,
		/*	 Commented for VAPT issue by Anil Avhad on 17-Mar-2018
		 * 
		 * @PathVariable String orderID, @PathVariable String amt,
			@PathVariable String userId,
			@PathVariable String txtPayCategory,
			@PathVariable String propNumber,
			@PathVariable String productCode,
			@PathVariable String producerCode,
			@PathVariable String transType,*/
			HttpServletRequest httpServletRequest) {
		logger.debug("Inside PaymentController.payreqBillDesk() method.. ");		
		String strMsg = null;
		String strRespJSP = null;
		
		// START : VAPT FIX : ANIL AVHAD on 17-Mar-2018 //
		
				String orderID=httpServletRequest.getParameter("orderID");
				String amt=httpServletRequest.getParameter("transAmt");
				String userId=httpServletRequest.getParameter("system");
				String txtPayCategory=httpServletRequest.getParameter("debit");
				String propNumber=httpServletRequest.getParameter("txnModeVal");
				String productCode=httpServletRequest.getParameter("productCode");//<YogeshM>:<18/04/2018>:<DEV/SIT>:<DefectID-3332><CPI req param required>
				String producerCode=httpServletRequest.getParameter("producerCode");//<YogeshM>:<18/04/2018>:<DEV/SIT>:<DefectID-3332><CPI req param required>
				String transType=httpServletRequest.getParameter("transType");
				String isRenew=httpServletRequest.getParameter("isRenew");//<YogeshM>:<18/04/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration - added isRenew flag - CPI req param required>
				
				logger.info("PaymentController.payreqBillDesk() :: orderID :: "+orderID+"amt :: "+amt+"userId ::"+userId+"txtPayCategory::"+txtPayCategory+"propNumber::"+propNumber+"productCode::"+productCode+"producerCode::"+producerCode+"transType::"+transType+"isRenew::"+isRenew);
				
				// END :  VAPT FIX : ANIL AVHAD on 17-Mar-2018 //
		
		// Vapt Fix : 10-Mar-2018 : Start
		
		//if(logger.isDebugEnabled())logger.debug("Inside PaymentController.payreqBillDesk() :: Encoded PropNumber Value :- "+propNumber);
		byte propNumberByteArr[] = decodeBase64Byte(propNumber);
		propNumber = bytes2String(propNumberByteArr);
		//if(logger.isDebugEnabled())logger.debug("Inside PaymentController.payreqBillDesk() :: Decode PropNumber Value After :- "+propNumber);
		
		// Vapt Fix : 10-Mar-2018 : End		
		try {
			strMsg = paymentService.billdeskPaymentRequest(orderID, amt,userId,
					txtPayCategory, propNumber,productCode,producerCode, transType, isRenew); //<YogeshM>:<18/04/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration - added isRenew flag>
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("PaymentController.payreqBillDesk() method :: return strMsg=> " + strMsg);
		model.addAttribute("msg", strMsg);
		model.addAttribute("txtPayCategory", txtPayCategory);
		
		//Start:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
		int pgFlagVal = 0;	
		String pgFlag = dbService.getConfigParamVal(CommonConstants.PG_REDIRECT_FLAG);
		pgFlagVal = Integer.parseInt(pgFlag);
		if (pgFlagVal == 1) {
			strRespJSP = CommonConstants.CPI_PAY_REQ;
			logger.info("CommonConstants.CPI_PAY_REQ>>>>>>>>>>>>" + CommonConstants.CPI_PAY_REQ);
		} else {
			strRespJSP = CommonConstants.BILLDESK_PAY_REQ;
		}
		
		return strRespJSP;
		//End:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
	}
	
	@RequestMapping(value = "/payreqBillDeskOL", method = RequestMethod.POST)
	@ResponseBody
	public BilldeskRequestData payreqBillDesk(@RequestBody ReceiptCumPolicyRequest accountServReq, HttpServletRequest httpServletRequest)  {
			//Locale locale, Model model,@ModelAttribute("accountServReq") ReceiptCumPolicyRequest accountServReq)  {
			
		logger.debug("Inside PaymentController.billdeskPaymentRequest method##.. -->> "+accountServReq);		
		HashMap<String, String> mapValue = new HashMap<String, String>();
		Gson gson = new Gson();
		ReceiptCumPolicyRequest accountServReqObj= new ReceiptCumPolicyRequest();
		BilldeskRequestData response = new BilldeskRequestData();
		try {
			mapValue = paymentService.processOLPartPayment(accountServReq);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		response.setMsg((String)mapValue.get("strMsg"));
		response.setTxtPayCategory((String)mapValue.get("txtPayCategory"));
		
		return response;
	}
	
	// This service gets invoked when Self payment billdesk response.
	@RequestMapping(value = "/payresBillDesk", method = RequestMethod.POST)
	public String payLinkRes(Locale locale, Model model,
			@ModelAttribute("msg") String msg) {

		Map<String, String> mapVal = null; // SUCCESS/FAILURE

		try {
			
			mapVal = paymentService.selfPayResponse(msg);
			
			model.addAttribute("transactionStatus", mapVal.get("Status"));
			model.addAttribute("orderId", mapVal.get("screenRefNo"));
			model.addAttribute("txnReferenceNo", mapVal.get("TxnReferenceNo"));
			model.addAttribute("bankReferenceNo", mapVal.get("BankReferenceNo"));
			model.addAttribute("txnDate", mapVal.get("TxnDate"));
			model.addAttribute("txnAmount", mapVal.get("TxnAmount"));
			model.addAttribute("errorDesc", mapVal.get("errorDesc"));
			model.addAttribute("policyNo", mapVal.get("policyNo"));
			model.addAttribute("customerID", mapVal.get("customerID"));
			model.addAttribute("proposalDate", mapVal.get("proposalDate"));
			model.addAttribute("receiptNo", mapVal.get("receiptNo"));
			model.addAttribute("productCode", mapVal.get("productCode"));
			model.addAttribute("proposalNo", mapVal.get("proposalNo"));
			model.addAttribute("producerCode", mapVal.get("producerCode"));
			model.addAttribute("userId", mapVal.get("userId"));
		}

		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return CommonConstants.SELF_PAY_RES;
	}
	
	@RequestMapping(value = "/generateOrderID", method = RequestMethod.GET)
	@ResponseBody
	public String generateOrderID (HttpServletRequest httpServletRequest) {
		
		String orderID = null;

		try {
			orderID = paymentService.generateOrderID();

		}
		
		catch (Exception e) {
			e.printStackTrace();
		}

		return orderID;
	}
	
	// This service generates self payment link URL 
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/paylink/{transID}", method = RequestMethod.GET)
	public String payLinkURL(Locale locale, Model model, @PathVariable String transID, HttpServletRequest httpServletRequest) throws Exception {	
		Map<String, String> mapVal = null;
		ObjectMapper objMapper = new ObjectMapper();
		UserCredentials userCredObj= new UserCredentials();
		Gson gson = new Gson();
		HttpHeaders headers = new HttpHeaders();
		
		try {
						       
			mapVal = paymentService.getSelfPayURLDetails(transID);
						
			//Start: RahulT< 1908> | code added to get refresh token for SPL user 
			JSONObject jsonObject = new JSONObject(); 
			jsonObject.put("userId", defaultSPLUseerId);
			jsonObject.put("password", defaultSPLPassword);
			jsonObject.put("username", defaultSPLUseerId);
			
			userCredObj.setUserId(defaultSPLUseerId);
			userCredObj.setPassword(defaultSPLPassword);
			userCredObj.setUsername(defaultSPLUseerId);
			//String userCredJson = gson.toJson(userCredObj);
			String userCredJson = jsonObject.toJSONString();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> entity = new HttpEntity<String>(userCredJson, headers);
			
			logger.debug("Inside PaymentServiceImpl.payLinkURL method:: USER OBJECT FOR SPL toJSONString --> "+objMapper.writeValueAsString(userCredJson));
			logger.debug("Inside PaymentServiceImpl.payLinkURL method:: USER OBJECT FOR SPL toString()--> "+objMapper.writeValueAsString(jsonObject.toString()));
			
			logger.debug("Inside PaymentServiceImpl.payLinkURL method:: USER OBJECT FOR SPL --> "+objMapper.writeValueAsString(jsonObject));
			
			String url =usermgtBaseURL+"/sec/login/";
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<String> loginResponse = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
			
			logger.debug("Inside PaymentServiceImpl.payLinkURL method:: Login Response -->"+loginResponse);
			
			headers = loginResponse.getHeaders();
			Set<String> keys = headers.keySet();
			
			for (String header : keys) {
				List<String> values = headers.get(header);
				if (header.equals("refresh_token")) {
          for (String value : values)
          {
            mapVal.put("refresh_token", value);
            logger.debug("Inside PaymentServiceImpl.payLinkURL method:: Token Value -->" + value);
          }
				}
			}
			//End: RahulT< 1908> | code added to get refresh token for SPL user
			
			//System.out.println("final value in result Map "+objMapper.writeValueAsString(mapVal));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if (mapVal!=null && mapVal.get("proposalNo")!=null) //Start:<YogeshM>:<28/03/2018>:<DEV/SIT>:<DefectID-3510/VAPT>:<iPDS service integration:- if-else added to handle null>
		{
		model.addAttribute("customerName", mapVal.get("customerName"));
		model.addAttribute("proposalNo", mapVal.get("proposalNo"));
		model.addAttribute("transAmt", mapVal.get("transAmt"));	
		model.addAttribute("transID", transID);
		model.addAttribute("custName", mapVal.get("custName"));
			if (mapVal.get("isError")!=null)
			{	
		model.addAttribute("isError", mapVal.get("isError"));
		model.addAttribute("messageDisplay", mapVal.get("messageDisplay"));
			} 
			else 
			{
				model.addAttribute("isError", "0");
				model.addAttribute("messageDisplay", "");
			}
		
		model.addAttribute("productCd", mapVal.get("productCd"));
		model.addAttribute("agentCode", mapVal.get("agentCode"));
		model.addAttribute("agentName", mapVal.get("agentName"));
		model.addAttribute("productName", mapVal.get("productName"));
		model.addAttribute("planName", mapVal.get("planName"));
		model.addAttribute("vehRegNo", mapVal.get("vehRegNo"));
		//Start:27/09/2017:1911:Added for vehicle reg. no
        model.addAttribute("lobNo", mapVal.get("lobNo"));
        //End:27/09/2017:1911:Added for vehicle reg. no
		model.addAttribute("refresh_token", mapVal.get("refresh_token"));	//RahulT< 1908>
		model.addAttribute("isrenew", mapVal.get("isrenew"));//isrenew //<YogeshM>:<18/04/2018>:<DEV/SIT>:<DefectID-3332><CPI req param required>
		} 
		else
		{
			model.addAttribute("isError", "1");
			model.addAttribute("messageDisplay", "Sorry! Your payment link invalid. Please contact your agent for more details!");
			
			model.addAttribute("customerName", "");
			model.addAttribute("proposalNo", "");
			model.addAttribute("transAmt", "");	
			model.addAttribute("transID", ""); //<YogeshM>:<08/05/2018>:<PROD>:<DefectID-VAPT><VAPT to handle invalid SPL request>
			model.addAttribute("custName", "");
			model.addAttribute("productCd", "");
			model.addAttribute("agentCode", "");
			model.addAttribute("agentName", "");
			model.addAttribute("productName", "");
			model.addAttribute("planName", "");
			model.addAttribute("vehRegNo", "");
			model.addAttribute("lobNo", "");
			model.addAttribute("isrenew", "");//isrenew //<YogeshM>:<18/04/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration - added isRenew flag>
		}
		//End:<YogeshM>:<28/03/2018>:<DEV/SIT>:<DefectID-3510/VAPT>:<iPDS service integration:- if-else added to handle null>
		return CommonConstants.SELF_PAYMENT_PAGE;
	}
	
	// Added for 'Payment Link to Customer' functionality
	//This service gets invoked when end user clicked URL which shared on his/her e-mail.
	/*@RequestMapping(value = "/redirectBilldeskURL", method = RequestMethod.POST)
	public String redirectBillDesk(Locale locale, Model model, @ModelAttribute("transID") String transID, @ModelAttribute("policyNo")
	String policyNo, @ModelAttribute("transAmt") String transAmt, @ModelAttribute("txtPayCategory") String txtPayCategory) {

		String strMsg = null; // SUCCESS/FAILURE

		try {
			strMsg = paymentService.billdeskPaymentRequest(transID, transAmt, null,
					txtPayCategory, null, null, null, "SPL");
			
			model.addAttribute("msg", strMsg);
			//model.addAttribute("txtPayCategory", paymentRequest.getTxtPayCategory());
			model.addAttribute("txtPayCategory", txtPayCategory);
		}

		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return CommonConstants.BILLDESK_PAY_REQ;
	}*/
	
	// The URL of this service shared to Billdesk & this service gets invoked by billdesk after user perform transaction on billdesk site. 
		// newly added for online account service
		@RequestMapping(value = "/billdeskResponse", method = RequestMethod.POST)
		//@ResponseBody
		public String billdeskResponse(Locale locale, Model model,
				@ModelAttribute("msg") String msg) {
			
			ObjectMapper mapper = new ObjectMapper();
			Map<String, String> responseVal = null;
			
			try {
				responseVal = paymentService.billdeskResponse(msg);
				
				//System.out.println("result map.. : "+mapper.writeValueAsString(responseVal));
				model.addAttribute("accountServiceJSON", responseVal.get("jsonObj"));
				model.addAttribute("status", responseVal.get("status"));
			}

			catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}

			//return receiptResponse;
			return CommonConstants.BILLDESK_PAY_RES;
		}
//Start: RahulT <1266>| HSBC UPI integration
		@RequestMapping(value = "/upi/upiPage")
		public String getUPIPaymentPage(){
			
			return "UPIPage";
		}
		
		@SuppressWarnings({ "rawtypes", "unchecked"})
		@RequestMapping(value = "/upi/upiPayment", method = RequestMethod.POST, produces = "application/json")
		public ResponseEntity<String> initiateUPIPayment(@RequestBody String upiTxnReq, HttpServletRequest httpServletRequest)  {
			
			ObjectMapper mapper = new ObjectMapper();
			Gson gson = new Gson();
			HttpHeaders responseHeaders =  new HttpHeaders();
			boolean validVPA = true;
			UpiTransactionResponse response = new UpiTransactionResponse();
			UPIPaymentHandler handler = new UPIPaymentHandler();
			try {
				
				logger.debug("Inside UPIController.initiateUPIPayment () -->> "+mapper.writeValueAsString(upiTxnReq));
				UpiTransactionRequest objUPIReq = gson.fromJson(upiTxnReq, UpiTransactionRequest.class);
				String UPITrasanctionURL = httpServletRequest.getContextPath()+"upipg/validateVPA";
				RestTemplate restTemplate = new RestTemplate();
				
				//validVPA = restTemplate.postForObject(UPITrasanctionURL, objUPIReq, Boolean.class);
				
				if (validVPA){
					
					upiService = handler.getHandlerClass(objUPIReq.getBankCode());
										
					response = upiService.collectTxnAPI(objUPIReq, pgdbService);
					String responseJson = gson.toJson(response);
					return new ResponseEntity(responseJson, responseHeaders,HttpStatus.OK);
				}
				else
					return new ResponseEntity("Please provide valid VPA! ",responseHeaders,HttpStatus.NO_CONTENT);			
				
			} catch (Exception e) {
				e.printStackTrace();
				return new ResponseEntity("Failed",responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
		}
		
		//Start: RahulT<1266>| code added for separate service for UPI transaction
		
		@SuppressWarnings("unchecked")
		@RequestMapping(value = "/upi/validateAndCreatePol", method = RequestMethod.POST)
		@ResponseBody
		public ResponseEntity<String> validateAndCreatePol(@RequestBody String upiTxnReq, Locale locale, Model model, HttpServletRequest httpServletRequest)  {
			logger.debug("Inside PaymentController.validateAndCreatePol method##.. -->> "+upiTxnReq);
			Gson gson = new Gson();
			HttpHeaders responseHeaders =  new HttpHeaders();
			UPITxnEnquiryResponse txnEnquiryResponse = null;
			ObjectMapper mapper = new ObjectMapper();
			Map<String, String> mapVal = null; // SUCCESS/FAILURE
			String responseJson = "";
			String methodName="validateAndCreatePol";
			String decodedResponse = null;
			UPISecurity upiSecurity = new UPISecurity();
			try {
				logger.debug("Inside UPIController.initiateUPIPayment () -->> "+mapper.writeValueAsString(upiTxnReq));
				UpiTransactionRequest objUPIReq = gson.fromJson(upiTxnReq, UpiTransactionRequest.class);
				String UPITxnQueryURL = httpServletRequest.getContextPath()+"/upipg/queryTransaction";
				RestTemplate restTemplate = new RestTemplate();
				
			//	txnEnquiryResponse = restTemplate.postForObject(UPITxnQueryURL, objUPIReq, UPITxnEnquiryResponse.class);
				txnEnquiryResponse=upiService.validateTransaction(objUPIReq, pgdbService);
				if (txnEnquiryResponse!=null && txnEnquiryResponse.getTxnStatus()!=null 
						&& txnEnquiryResponse.getTxnStatus().equalsIgnoreCase(PGConstants.HSBC_UPI_TRANSACTION_SUCCESS)){
					
					logger.debug(methodName+ ":::  decoded message receivedfrom HSBC Status Enquiry Service - "+txnEnquiryResponse.getResponseString());
					//decodedResponse = upiSecurity.decrypt(txnEnquiryResponse.getResponseString(), upiChecksum);
					//logger.debug(methodName+ ":::  Decoded message  - "+decodedResponse);
					
					mapVal = paymentService.finalResponseAPIHSBC(txnEnquiryResponse.getResponseString());
					
					model.addAttribute("transactionStatus", mapVal.get("Status"));
					model.addAttribute("orderId", mapVal.get("screenRefNo"));
					model.addAttribute("txnReferenceNo", mapVal.get("TxnReferenceNo"));
					model.addAttribute("bankReferenceNo", mapVal.get("BankReferenceNo"));
					model.addAttribute("txnDate", mapVal.get("TxnDate"));
					model.addAttribute("txnAmount", mapVal.get("TxnAmount"));
					model.addAttribute("errorDesc", mapVal.get("errorDesc"));
					model.addAttribute("policyNo", mapVal.get("policyNo"));
					model.addAttribute("customerID", mapVal.get("customerID"));
					model.addAttribute("proposalDate", mapVal.get("proposalDate"));
					model.addAttribute("receiptNo", mapVal.get("receiptNo"));
					model.addAttribute("productCode", mapVal.get("productCode"));
					model.addAttribute("proposalNo", mapVal.get("proposalNo"));
					model.addAttribute("producerCode", mapVal.get("producerCode"));
					model.addAttribute("userId", mapVal.get("userId"));
					
					txnEnquiryResponse.setMapPolicyDtl(mapVal);
					
					responseJson = gson.toJson(txnEnquiryResponse);
				}
				else{
					return new ResponseEntity(responseJson,responseHeaders,HttpStatus.NO_CONTENT);
				}
				
				
						
			} catch (Exception e) {
				e.printStackTrace();
				return new ResponseEntity(responseJson,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
			}
					
			return new ResponseEntity(responseJson,responseHeaders,HttpStatus.OK);
		}
		
		// This service gets invoked when UPI Self payment billdesk response.
		
		
		@RequestMapping(value = "/upi/hsbcFinalResponse", method = RequestMethod.POST)
		public void hsbcFinalResponseAPI(Locale locale, Model model,
				@ModelAttribute("meRes") String meRes, @ModelAttribute("pgMerchantId") String pgMerchantId) {

			Map<String, String> mapVal = null; // SUCCESS/FAILURE
			String methodName="hsbcFinalResponseAPI";
			String decodedResponse = null;
			UPISecurity upiSecurity = new UPISecurity();
			

			try {
				
				logger.debug(methodName+" -->> message received from HSBC :: "+meRes);
				
				logger.debug(methodName+ ":::  Encoded message receivedfrom HSBC Status Enquiry Service - "+meRes);
				decodedResponse = upiSecurity.decrypt(meRes, upiChecksum);
				logger.debug(methodName+ ":::  Decoded message  - "+decodedResponse);
				
				mapVal = paymentService.finalResponseAPIHSBC(decodedResponse);
				
				model.addAttribute("transactionStatus", mapVal.get("Status"));
				model.addAttribute("orderId", mapVal.get("screenRefNo"));
				model.addAttribute("txnReferenceNo", mapVal.get("TxnReferenceNo"));
				model.addAttribute("bankReferenceNo", mapVal.get("BankReferenceNo"));
				model.addAttribute("txnDate", mapVal.get("TxnDate"));
				model.addAttribute("txnAmount", mapVal.get("TxnAmount"));
				model.addAttribute("errorDesc", mapVal.get("errorDesc"));
				model.addAttribute("policyNo", mapVal.get("policyNo"));
				model.addAttribute("customerID", mapVal.get("customerID"));
				model.addAttribute("proposalDate", mapVal.get("proposalDate"));
				model.addAttribute("receiptNo", mapVal.get("receiptNo"));
				model.addAttribute("productCode", mapVal.get("productCode"));
				model.addAttribute("proposalNo", mapVal.get("proposalNo"));
				model.addAttribute("producerCode", mapVal.get("producerCode"));
				model.addAttribute("userId", mapVal.get("userId"));
			}

			catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}

			//return CommonConstants.SELF_PAY_RES;
		}
		
		@SuppressWarnings({ "unchecked", "rawtypes" })
		@RequestMapping(value = "/upi/upiResponsePage", method = RequestMethod.POST)
		public ResponseEntity<String> upiTxnResponse(Locale locale, Model model, @RequestBody String upiTxnResponse, HttpServletRequest httpServletRequest)
		{
			Gson gson = new Gson();
			Map<String, String> mapVal = null; // SUCCESS/FAILURE
			ObjectMapper mapper= new ObjectMapper();
			String methodName = "upiTxnResponse";
			
			JSONArray jsonArray = new JSONArray();
			JSONObject jsonMainObj = new JSONObject();
			String strMaster = "upiResponse";
			String responseJson = "";
			HttpHeaders responseHeaders =  new HttpHeaders();

			try {
				
				logger.debug(methodName+ ":::  data received for final response JSP page - "+upiTxnResponse);
				
				UPITxnEnquiryResponse txnEnquiryResponse= gson.fromJson(upiTxnResponse,UPITxnEnquiryResponse.class);
				
				logger.debug(methodName+ ":::  data received for final response JSP page - "+mapper.writeValueAsString(txnEnquiryResponse));
				
				if (txnEnquiryResponse!=null && txnEnquiryResponse.getMapPolicyDtl()!=null && !txnEnquiryResponse.getMapPolicyDtl().isEmpty()){		
					logger.debug(methodName+ ":::  got the required details - ");
					
					mapVal = txnEnquiryResponse.getMapPolicyDtl();
					model.addAttribute("transactionStatus", mapVal.get("Status"));
					model.addAttribute("orderId", mapVal.get("screenRefNo"));
					model.addAttribute("txnReferenceNo", mapVal.get("TxnReferenceNo"));
					model.addAttribute("bankReferenceNo", mapVal.get("BankReferenceNo"));
					model.addAttribute("txnDate", mapVal.get("TxnDate"));
					model.addAttribute("txnAmount", mapVal.get("TxnAmount"));
					model.addAttribute("errorDesc", mapVal.get("errorDesc"));
					model.addAttribute("policyNo", mapVal.get("policyNo"));
					model.addAttribute("customerID", mapVal.get("customerID"));
					model.addAttribute("proposalDate", mapVal.get("proposalDate"));
					model.addAttribute("receiptNo", mapVal.get("receiptNo"));
					model.addAttribute("productCode", mapVal.get("productCode"));
					model.addAttribute("proposalNo", mapVal.get("proposalNo"));
					model.addAttribute("producerCode", mapVal.get("producerCode"));
					model.addAttribute("userId", mapVal.get("userId"));
					
					
					txnEnquiryResponse.setMapPolicyDtl(mapVal);
					responseJson = gson.toJson(txnEnquiryResponse);
					
				}
				else{
					return new ResponseEntity(responseJson,responseHeaders,HttpStatus.NO_CONTENT);
				}
				
				//jsonMainObj.put(strMaster, mapVal);
				
				logger.debug(methodName+ ":::  data received for final response JSP page::responseJson - "+responseJson);
			}
			catch (Exception e) {
				e.printStackTrace();
				return new ResponseEntity(responseJson,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
			}

			//return CommonConstants.SELF_PAY_RES;
			return new ResponseEntity(responseJson,responseHeaders,HttpStatus.OK);
		}
		//End: RahulT <1266>| HSBC UPI integration
		
		//Start: YogeshM <1266>| HSBC UPI integration - to return UPIResponse JSP 
		@RequestMapping(value = "/upi/upiResponsePg/{transactionStatus}/{orderId}/{txnReferenceNo}/{bankReferenceNo}/{txnDate}/{txnAmount}/{errorDesc}/{policyNo}/{customerID}/{proposalDate}/{receiptNo}/{productCode}/{proposalNo}/{producerCode}/{userId}", method = RequestMethod.GET)
		public String upiTxnResponse(Locale locale, Model model,	
				@PathVariable String transactionStatus, @PathVariable String orderId,
				@PathVariable String txnReferenceNo,
				@PathVariable String bankReferenceNo,
				@PathVariable String txnDate,
				@PathVariable String txnAmount,
				@PathVariable String errorDesc,
				@PathVariable String policyNo,				
				@PathVariable String customerID,
				@PathVariable String proposalDate,
				@PathVariable String receiptNo,
				@PathVariable String productCode,
				@PathVariable String proposalNo,
				@PathVariable String producerCode,
				@PathVariable String userId,
				
				HttpServletRequest httpServletRequest) {
			logger.debug("Inside PaymentController.upiTxnResponse method.. ");		
			String strMsg = null;
			
			try {
				//strMsg = paymentService.billdeskPaymentRequest(orderID, amt,userId,
				//		txtPayCategory, propNumber,productCode,producerCode, transType);
			
				//model.addAttribute("msg", strMsg);
				model.addAttribute("transactionStatus", transactionStatus);
				model.addAttribute("orderId", orderId);
				model.addAttribute("txnReferenceNo", txnReferenceNo);
				model.addAttribute("bankReferenceNo", bankReferenceNo);
				model.addAttribute("txnDate", txnDate);
				model.addAttribute("txnAmount", txnAmount);
				model.addAttribute("errorDesc", errorDesc);
				model.addAttribute("policyNo", policyNo);
				model.addAttribute("customerID", customerID);
				model.addAttribute("proposalDate", proposalDate);
				model.addAttribute("receiptNo", receiptNo);
				model.addAttribute("productCode", productCode);
				model.addAttribute("proposalNo", proposalNo);
				model.addAttribute("producerCode", producerCode);
				model.addAttribute("userId", userId);
			
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			//return CommonConstants.BILLDESK_PAY_REQ;
			return "upiResponse";
		}
		//End: YogeshM <1266>| HSBC UPI integration - to return UPIResponse JSP 
		//Start:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
		// This service gets invoked when Self payment CPI response.
		@RequestMapping(value = "/payresCPI", method = RequestMethod.POST)
		public String payLinkCPIRes(Locale locale, Model model,
				@ModelAttribute("pgiResponse") String msg) {

			Map<String, String> mapVal = null; // SUCCESS/FAILURE
			ObjectMapper mapper= new ObjectMapper();

			try {
				logger.debug("payLinkCPIRes data received for final response JSP page - "+mapper.writeValueAsString(msg));
				
				mapVal = paymentService.selfPayResponse(msg);
				logger.debug("payLinkCPIRes data received for final response JSP page - "+mapper.writeValueAsString(mapVal));
				
				model.addAttribute("transactionStatus", mapVal.get("Status"));
				model.addAttribute("orderId", mapVal.get("screenRefNo"));
				model.addAttribute("txnReferenceNo", mapVal.get("TxnReferenceNo"));
				model.addAttribute("bankReferenceNo", mapVal.get("BankReferenceNo"));
				model.addAttribute("txnDate", mapVal.get("TxnDate"));
				model.addAttribute("txnAmount", mapVal.get("TxnAmount"));
				model.addAttribute("errorDesc", mapVal.get("errorDesc"));
				model.addAttribute("policyNo", mapVal.get("policyNo"));
				model.addAttribute("customerID", mapVal.get("customerID"));
				model.addAttribute("proposalDate", mapVal.get("proposalDate"));
				model.addAttribute("receiptNo", mapVal.get("receiptNo"));
				model.addAttribute("productCode", mapVal.get("productCode"));
				model.addAttribute("proposalNo", mapVal.get("proposalNo"));
				model.addAttribute("producerCode", mapVal.get("producerCode"));
				model.addAttribute("userId", mapVal.get("userId"));
				if (mapVal.get("rndStrIPDS")!=null)
					model.addAttribute("rndStrIPDS", mapVal.get("rndStrIPDS")); //Start:<YogeshM>:<22/03/2018>:<DEV/SIT>:<DefectID-3510>:<iPDS service integration>
			}

			catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}

			return CommonConstants.SELF_PAY_RES;
		}
		
		
		// The URL of this service shared to Billdesk & this service gets invoked by billdesk after user perform transaction on billdesk site. 
				// newly added for online account service
				@RequestMapping(value = "/CPIPaymentResponse", method = RequestMethod.POST)
				//@ResponseBody
				public String CPIResponse(Locale locale, Model model, @ModelAttribute("pgiRequest") String msg) {
					
					ObjectMapper mapper = new ObjectMapper();
					Map<String, String> responseVal = null;
					
					try {
						responseVal = paymentService.billdeskResponse(msg);
						
						//System.out.println("result map.. : "+mapper.writeValueAsString(responseVal));
						model.addAttribute("accountServiceJSON", responseVal.get("jsonObj"));
						model.addAttribute("status", responseVal.get("status"));
						model.addAttribute("eodFlag",responseVal.get("eodFlag"));
					}

					catch (ClassNotFoundException e) {
						e.printStackTrace();
					} catch (Exception e) {
						e.printStackTrace();
					}

					//return receiptResponse;
					return CommonConstants.BILLDESK_PAY_RES;
		}
		//End:<YogeshM>:<05/02/2018>:<DEV/SIT>:<DefectID-3332>:<CPI service integration>
		// Start : Methods added for decoding base 64 string  : VAPT : Vishal
		private static String bytes2String(byte[] bytes) {
		      StringBuffer stringBuffer = new StringBuffer();
			        for (int i = 0; i<bytes.length; i++) {
			            stringBuffer.append((char) bytes[i]);
			        }
			        return stringBuffer.toString();
			    }
			    
			    public byte[] decodeBase64Byte(String s)
				{
					byte[] name = Base64.decodeBase64(s);
					return name;
				}
	  // End : Methods added for decoding base 64 string  : VAPT : Vishal
			    
			    
	 // Start : This service gets invoked when Self payment billdesk response.
				@RequestMapping(value = "/payresCPINew", method = RequestMethod.POST)
				public String selfPayLiteService(Locale locale, Model model,
						@ModelAttribute("msg") String msg) {

					Map<String, String> mapVal = null; // SUCCESS/FAILURE
					ObjectMapper mapper= new ObjectMapper();
					try {
						logger.debug("payLinkCPIRes data received for final response JSP page - "+mapper.writeValueAsString(msg));
						
						mapVal = paymentService.selfPayLitePaymentService(msg);
						logger.debug("payLinkCPIRes data received for final response JSP page - "+mapper.writeValueAsString(mapVal));
						
						
						model.addAttribute("transactionStatus", mapVal.get("Status"));
						model.addAttribute("orderId", mapVal.get("screenRefNo"));
						model.addAttribute("txnReferenceNo", mapVal.get("TxnReferenceNo"));
						model.addAttribute("bankReferenceNo", mapVal.get("BankReferenceNo"));
						model.addAttribute("txnDate", mapVal.get("TxnDate"));
						model.addAttribute("txnAmount", mapVal.get("TxnAmount"));
						model.addAttribute("errorDesc", mapVal.get("errorDesc"));
						model.addAttribute("policyNo", mapVal.get("policyNo"));
						model.addAttribute("customerID", mapVal.get("customerID"));
						model.addAttribute("proposalDate", mapVal.get("proposalDate"));
						model.addAttribute("receiptNo", mapVal.get("receiptNo"));
						model.addAttribute("productCode", mapVal.get("productCode"));
						model.addAttribute("proposalNo", mapVal.get("proposalNo"));
						model.addAttribute("producerCode", mapVal.get("producerCode"));
						model.addAttribute("userId", mapVal.get("userId"));
					}

					catch (ClassNotFoundException e) {
						e.printStackTrace();
					} catch (Exception e) {
						e.printStackTrace();
					}

					return CommonConstants.SELF_PAY_RES;
				}

				//End : This service gets invoked when Self payment billdesk response.
			    
}




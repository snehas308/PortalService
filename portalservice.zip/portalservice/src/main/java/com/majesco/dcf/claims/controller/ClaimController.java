package com.majesco.dcf.claims.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.majesco.dcf.claims.json.ClaimServiceValidateSaveRequest;
import com.majesco.dcf.claims.json.ClaimServiceValidateSaveResponse;
import com.majesco.dcf.claims.json.CoverageSearchRequest;
import com.majesco.dcf.claims.json.CoverageSearchResponse;
import com.majesco.dcf.claims.json.PolicyDetailsSearchRequest;
import com.majesco.dcf.claims.json.PolicyDetailsSearchResponse;
import com.majesco.dcf.claims.json.PolicySearchCoverNoteRequest;
import com.majesco.dcf.claims.json.PolicySearchCoverNoteResponse;
import com.majesco.dcf.claims.service.ClaimService;
import com.majesco.dcf.paproduct.controller.IPAController;
import com.majesco.dcf.paproduct.json.IPAProposalRequest;
import com.majesco.dcf.paproduct.json.IPAProposalResponse;

@Controller
@RequestMapping(value="/ClaimService")
public class ClaimController {
	
	@Autowired
	ClaimService claimServ;
	
	final static Logger logger=Logger.getLogger(ClaimController.class);
	
	
	@RequestMapping(value="/getClaimServiceGetLOVPol/", method = RequestMethod.POST)
	@ResponseBody
	public PolicySearchCoverNoteResponse getClaimServiceGetLOV(@RequestBody PolicySearchCoverNoteRequest cvrNoteClaimReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside ClaimController :: getClaimServiceGetLOV method :: Execution Started");
		
		PolicySearchCoverNoteResponse cvrNoteClaimRes = claimServ.getClaimServiceGetLOV(cvrNoteClaimReq);
		
		logger.info("Inside ClaimController :: getClaimServiceGetLOV method :: Execution Completed Successfully");
		
		return cvrNoteClaimRes;
	}
	
	
	@RequestMapping(value="/getClaimServiceFetchGeneralDetails/", method = RequestMethod.POST)
	@ResponseBody
	public PolicyDetailsSearchResponse getClaimServiceFetchGeneralDetails(@RequestBody PolicyDetailsSearchRequest polDetSearchReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside ClaimController :: getClaimServiceFetchGeneralDetails method :: Execution Started");
		
		PolicyDetailsSearchResponse polDetSearchRes = claimServ.getClaimServiceFetchGeneralDetails(polDetSearchReq);
		
		logger.info("Inside ClaimController :: getClaimServiceFetchGeneralDetails method :: Execution Completed Successfully");
		
		return polDetSearchRes;
	}
	
	
	@RequestMapping(value="/getClaimServiceGetLOVCover/", method = RequestMethod.POST)
	@ResponseBody
	public CoverageSearchResponse getClaimServiceGetLOV(@RequestBody CoverageSearchRequest cvrgSearchReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside ClaimController :: getClaimServiceGetLOV method :: Execution Started");
		
		CoverageSearchResponse cvrgSearchRes = claimServ.getClaimServiceGetLOV(cvrgSearchReq);
		
		logger.info("Inside ClaimController :: getClaimServiceGetLOV method :: Execution Completed Successfully");
		
		return cvrgSearchRes;
	}

	@RequestMapping(value="/getClaimServiceValidateSave/", method = RequestMethod.POST)
	@ResponseBody
	public ClaimServiceValidateSaveResponse getClaimServiceValidateSave(@RequestBody ClaimServiceValidateSaveRequest claimServValidateSaveReq,HttpServletRequest httpServletRequest) throws Exception
	{
		logger.info("Inside ClaimController :: getClaimServiceValidateSave method :: Execution Started");
		
		ClaimServiceValidateSaveResponse claimServValidateSaveRes = claimServ.getClaimServiceValidateSave(claimServValidateSaveReq);
		
		logger.info("Inside ClaimController :: getClaimServiceValidateSave method :: Execution Completed Successfully");
		
		return claimServValidateSaveRes;
	}
}

package com.majesco.dcf.common.tagic.controller;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.majesco.dcf.common.tagic.json.CalculateHomeRequest;
import com.majesco.dcf.common.tagic.json.CalculateHomeResponse;
import com.majesco.dcf.common.tagic.service.CalculateHomeService;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
//import com.majesco.dcf.motor.service.CalculatorMotorService;
import com.majesco.dcf.paproduct.json.CalculatorPARequest;
import com.majesco.dcf.paproduct.json.CalculatorPAResponse;
import com.majesco.dcf.paproduct.service.CalculatorPAService;


@Controller
@RequestMapping(value="/Calculator")
public class CalculatorController {

	
	@Autowired
	CalculateHomeService calculateHome;
	
	final static Logger logger = Logger.getLogger(CalculatorController.class);
	
	
	@RequestMapping(value="/getHomePrem/", method = RequestMethod.POST)
	@ResponseBody	
	public CalculateHomeResponse CalculatePremiumHome(@RequestBody CalculateHomeRequest quickReq,HttpServletRequest httpServletRequest) throws Exception
	{	
		
		logger.info("Inside CalculatorController :: CalculatePremiumHome method :: Execution Started");
		
		CalculateHomeResponse result = calculateHome.CalculatePremiumHome(quickReq);
		
		logger.info("Inside CalculatorController :: CalculatePremiumHome method :: Execution Completed Successfully");
					
		return result;
	}
	
	
	@Autowired
	CalculatorPAService calcPAserv;
	
	@RequestMapping(value="/calcPremPA/",method = RequestMethod.POST)
	@ResponseBody
	public CalculatorPAResponse calculatepremiumPA(@RequestBody CalculatorPARequest calcpareq,HttpServletRequest httpServletRequest)throws Exception
	
	{
		logger.info("Inside CalculatorController :: calculatepremiumPA method :: Execution Started");
		calcpareq.setSystemIP(ServiceUtility.getClientIpAddr(httpServletRequest));
		if(calcpareq.getCbenunit()!=null && calcpareq.getUnits()!=null){
			
			int dsa=Integer.parseInt(calcpareq.getCbenunit()) * calcpareq.getUnits();
			calcpareq.setSumAssured(String.valueOf(dsa));
		}
		CalculatorPAResponse calcpares =calcPAserv.calculatePAPremium(calcpareq);
		
		
		logger.info("Inside CalculatorController :: calculatepremiumPA method :: Execution Completed Successfully");
		
		return calcpares;
	}	
	
}

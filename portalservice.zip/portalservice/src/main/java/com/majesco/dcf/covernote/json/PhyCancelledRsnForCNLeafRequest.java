package com.majesco.dcf.covernote.json;

import com.majesco.dcf.common.tagic.json.UserObject;

public class PhyCancelledRsnForCNLeafRequest extends UserObject {
	private String leafNumber;

	public String getLeafNumber() {
		return leafNumber;
	}

	public void setLeafNumber(String leafNumber) {
		this.leafNumber = leafNumber;
	}
	
	
}

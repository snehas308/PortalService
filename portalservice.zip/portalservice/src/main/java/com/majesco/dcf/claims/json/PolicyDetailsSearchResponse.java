package com.majesco.dcf.claims.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PolicyDetailsSearchResponse 
{
	private String productCode;
	private String productName;
	private String insuredName;
	private String custPhoneNo;
	private String custEmailID;
	private String producerCode;
	private List<CoverageDetails> lstCoverDtld;
	private String resultCode;
	private List<ResponseError> resErr;
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}
	public String getCustPhoneNo() {
		return custPhoneNo;
	}
	public void setCustPhoneNo(String custPhoneNo) {
		this.custPhoneNo = custPhoneNo;
	}
	public String getCustEmailID() {
		return custEmailID;
	}
	public void setCustEmailID(String custEmailID) {
		this.custEmailID = custEmailID;
	}
	public String getProducerCode() {
		return producerCode;
	}
	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public List<CoverageDetails> getLstCoverDtld() {
		return lstCoverDtld;
	}
	public void setLstCoverDtld(List<CoverageDetails> lstCoverDtld) {
		this.lstCoverDtld = lstCoverDtld;
	}
	
}

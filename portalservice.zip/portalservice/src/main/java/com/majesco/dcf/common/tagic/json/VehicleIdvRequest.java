package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class VehicleIdvRequest {
	
	private String strmanufacturercd="";
	private BigDecimal nvehicleclasscd;
	private BigDecimal nvehicleage;
	private String strrtolocationcd="";
	private String strmodelcd="";
	private String strofficeproducerid="";
	
	public String getStrrtolocationcd() {
		return strrtolocationcd;
	}
	public void setStrrtolocationcd(String strrtolocationcd) {
		this.strrtolocationcd = strrtolocationcd;
	}
	public String getStrmodelcd() {
		return strmodelcd;
	}
	public void setStrmodelcd(String strmodelcd) {
		this.strmodelcd = strmodelcd;
	}
	public String getStrmanufacturercd() {
		return strmanufacturercd;
	}
	public void setStrmanufacturercd(String strmanufacturercd) {
		this.strmanufacturercd = strmanufacturercd;
	}
	public BigDecimal getNvehicleclasscd() {
		return nvehicleclasscd;
	}
	public void setNvehicleclasscd(BigDecimal nvehicleclasscd) {
		this.nvehicleclasscd = nvehicleclasscd;
	}
	public BigDecimal getNvehicleage() {
		return nvehicleage;
	}
	public void setNvehicleage(BigDecimal nvehicleage) {
		this.nvehicleage = nvehicleage;
	}
	public String getStrofficeproducerid() {
		return strofficeproducerid;
	}
	public void setStrofficeproducerid(String strofficeproducerid) {
		this.strofficeproducerid = strofficeproducerid;
	}
	
	
}

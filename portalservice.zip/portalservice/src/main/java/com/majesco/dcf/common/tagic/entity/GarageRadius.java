package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_vh_garage_radius",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_vh_garage_radius")							// Added for Oracle Migration
public class GarageRadius implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String ngarageseq;
	private String strgaragedesc;
	private String strcontactperson;
	private String naddtype;
	private String straddline1;
	private String straddline2;
	private String straddline3;
	private String strcitycd;
	private String strdistrictcd;
	private String strstatecd;
	private BigDecimal nzonecd;
	private String strcountrycd;
	private String npincode;
	private String strlandmark;
	private BigDecimal nstdcode;
	private BigDecimal nlandlinenumber;
	private BigDecimal nfaxnumber;
	private String strcontactno;
	private String strmobileno;
	private BigDecimal ntcarinfoid;
	private String nlatitude;
	private String nlongitude;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated; 
	private String strupdatedby;
	private String address;
	
	@Column(name = "address")
	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}



	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}


	@Id
	@Column(name = "ngarageseq")
	public String getNgarageseq() {
		return ngarageseq;
	}


	public void setNgarageseq(String ngarageseq) {
		this.ngarageseq = ngarageseq;
	}


	@Column(name = "strgaragedesc")
	public String getStrgaragedesc() {
		return strgaragedesc;
	}



	public void setStrgaragedesc(String strgaragedesc) {
		this.strgaragedesc = strgaragedesc;
	}


	@Column(name = "strcontactperson")
	public String getStrcontactperson() {
		return strcontactperson;
	}



	public void setStrcontactperson(String strcontactperson) {
		this.strcontactperson = strcontactperson;
	}


	@Column(name = "naddtype")
	public String getNaddtype() {
		return naddtype;
	}



	public void setNaddtype(String naddtype) {
		this.naddtype = naddtype;
	}


	@Column(name = "straddline1")
	public String getStraddline1() {
		return straddline1;
	}



	public void setStraddline1(String straddline1) {
		this.straddline1 = straddline1;
	}


	@Column(name = "straddline2")
	public String getStraddline2() {
		return straddline2;
	}



	public void setStraddline2(String straddline2) {
		this.straddline2 = straddline2;
	}


	@Column(name = "straddline3")
	public String getStraddline3() {
		return straddline3;
	}



	public void setStraddline3(String straddline3) {
		this.straddline3 = straddline3;
	}


	@Column(name = "strcitycd")
	public String getStrcitycd() {
		return strcitycd;
	}



	public void setStrcitycd(String strcitycd) {
		this.strcitycd = strcitycd;
	}


	@Column(name = "strdistrictcd")
	public String getStrdistrictcd() {
		return strdistrictcd;
	}



	public void setStrdistrictcd(String strdistrictcd) {
		this.strdistrictcd = strdistrictcd;
	}


	@Column(name = "strstatecd")
	public String getStrstatecd() {
		return strstatecd;
	}



	public void setStrstatecd(String strstatecd) {
		this.strstatecd = strstatecd;
	}


	@Column(name = "nzonecd")
	public BigDecimal getNzonecd() {
		return nzonecd;
	}



	public void setNzonecd(BigDecimal nzonecd) {
		this.nzonecd = nzonecd;
	}


	@Column(name = "strcountrycd")
	public String getStrcountrycd() {
		return strcountrycd;
	}



	public void setStrcountrycd(String strcountrycd) {
		this.strcountrycd = strcountrycd;
	}


	@Column(name = "npincode")
	public String getNpincode() {
		return npincode;
	}



	public void setNpincode(String npincode) {
		this.npincode = npincode;
	}


	@Column(name = "strlandmark")
	public String getStrlandmark() {
		return strlandmark;
	}



	public void setStrlandmark(String strlandmark) {
		this.strlandmark = strlandmark;
	}


	@Column(name = "nstdcode")
	public BigDecimal getNstdcode() {
		return nstdcode;
	}



	public void setNstdcode(BigDecimal nstdcode) {
		this.nstdcode = nstdcode;
	}


	@Column(name = "nlandlinenumber")
	public BigDecimal getNlandlinenumber() {
		return nlandlinenumber;
	}



	public void setNlandlinenumber(BigDecimal nlandlinenumber) {
		this.nlandlinenumber = nlandlinenumber;
	}


	@Column(name = "nfaxnumber")
	public BigDecimal getNfaxnumber() {
		return nfaxnumber;
	}



	public void setNfaxnumber(BigDecimal nfaxnumber) {
		this.nfaxnumber = nfaxnumber;
	}


	@Column(name = "strcontactno")
	public String getStrcontactno() {
		return strcontactno;
	}



	public void setStrcontactno(String strcontactno) {
		this.strcontactno = strcontactno;
	}


	@Column(name = "strmobileno")
	public String getStrmobileno() {
		return strmobileno;
	}



	public void setStrmobileno(String strmobileno) {
		this.strmobileno = strmobileno;
	}


	@Column(name = "ntcarinfoid")
	public BigDecimal getNtcarinfoid() {
		return ntcarinfoid;
	}



	public void setNtcarinfoid(BigDecimal ntcarinfoid) {
		this.ntcarinfoid = ntcarinfoid;
	}


	@Column(name = "nlatitude")
	public String getNlatitude() {
		return nlatitude;
	}



	public void setNlatitude(String nlatitude) {
		this.nlatitude = nlatitude;
	}


	@Column(name = "nlongitude")
	public String getNlongitude() {
		return nlongitude;
	}



	public void setNlongitude(String nlongitude) {
		this.nlongitude = nlongitude;
	}


	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}



	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}


	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}



	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}


	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}



	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}


}

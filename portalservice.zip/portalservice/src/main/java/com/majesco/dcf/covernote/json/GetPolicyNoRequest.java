package com.majesco.dcf.covernote.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class GetPolicyNoRequest extends UserObject{
	
	private String workflowProposalId;

	public String getWorkflowProposalId() {
		return workflowProposalId;
	}

	public void setWorkflowProposalId(String workflowProposalId) {
		this.workflowProposalId = workflowProposalId;
	}

}

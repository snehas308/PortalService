package com.majesco.dcf.motor.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResultObject;


@JsonSerialize(include=JsonSerialize.Inclusion.NON_EMPTY)
public class InspectionResponse extends ResultObject{

	
}

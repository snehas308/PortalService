package com.majesco.dcf.docmgmt.json;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

/**
 * @author yogesh570158
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocUploadSearchObj extends UserObject{

	//private long ndocid;
	//private Integer activeStatus;
	private String proposalNo;
	private String policyNo;
	
	//Start:-@Yogesh|Added code for defectId-1305
	private String searchFlag;
	private String fromDate;
	private String toDate;
	//End:-@Yogesh|Added code for defectId-1305
	
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	//Start:-@Yogesh|Added code for defectId-1305
	public String getSearchFlag() {
		return searchFlag;
	}
	public void setSearchFlag(String searchFlag) {
		this.searchFlag = searchFlag;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	//End:-@Yogesh|Added code for defectId-1305
}

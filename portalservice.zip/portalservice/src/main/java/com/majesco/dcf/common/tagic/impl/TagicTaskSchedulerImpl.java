package com.majesco.dcf.common.tagic.impl;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.majesco.dcf.common.tagic.entity.OnlineAccountService;
import com.majesco.dcf.common.tagic.entity.ParameterDetailList;
import com.majesco.dcf.common.tagic.entity.ParameterList;
import com.majesco.dcf.common.tagic.entity.PaymentDetails;
import com.majesco.dcf.common.tagic.entity.PmtFlowFlags;
import com.majesco.dcf.common.tagic.entity.SelfPaymentEntiry;
import com.majesco.dcf.common.tagic.entity.UserParameterList;
import com.majesco.dcf.common.tagic.json.CPIPayment;
import com.majesco.dcf.common.tagic.json.CommunicationRequest;
import com.majesco.dcf.common.tagic.json.DBLinkPolicyDetails;
import com.majesco.dcf.common.tagic.json.EmailAttachment;
import com.majesco.dcf.common.tagic.json.ExceptionPolicy;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.TagicCommonService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationLiteService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;
import com.majesco.dcf.common.tagic.service.TagicTaskScheduler;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.pg.entity.PGTransaction;
import com.majesco.dcf.receipt.handler.ProposalTaggingHandler;
import com.majesco.dcf.receipt.handler.ReceiptSelfPayLinkHandler;
import com.majesco.dcf.receipt.handler.ReceiptSelfPayLinkHandlerForLiteService;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyResponse;
import com.majesco.dcf.receipt.json.ReceiptPaymentDetails;
import com.majesco.dcf.receipt.util.ReceiptConstants;
import com.unotechsoft.stub.accountservice.client.AccountService;
import com.unotechsoft.stub.accountservice.client.AccountService_Service;
import com.unotechsoft.stub.accountservice.client.PaymentEntryServiceResult;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentTaging;


@Service
@EnableScheduling
public class TagicTaskSchedulerImpl implements TagicTaskScheduler {
	
	final static Logger logger = Logger.getLogger(TagicTaskSchedulerImpl.class);
	
	/*Start: KetanM <2505> | Re-hit mechanism to be put up for policycumreciept generation service*/
	@Value("${triggerRehitPolException}")
	private String triggerRehitPolException;
	/*End: KetanM <2505> | Re-hit mechanism to be put up for policycumreciept generation service*/

	@Value("${triggerSplitPaymentScheduler}")
	private String triggerSplitPaymentScheduler;
	
	@Value("${triggerCPIScheduler}")
	private String triggerCPIScheduler;
	
	@Autowired
	DBService dbService;
	
	@Autowired
	TagicCommonService commonService;
	
	@Autowired
	TagicCommunicationService commService;
	
	@Autowired
	TagicCommunicationLiteService tagicCommLite;
	
	@Autowired
	ProposalTaggingHandler propTagService;	
	
	private String className = "TagicTaskSchedulerImpl";
	
	
	// START : PDPN scheduler

	
	
	public String serviceURL=ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING;
	private static Properties prop = new Properties();
	static{
		try{
	InputStream inputStream = ReceiptSelfPayLinkHandler.class.getClassLoader().getResourceAsStream("resources.properties");
	prop.load(inputStream);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	// END : PDPN scheduler
	
	
	// This method will get executed on every day @ 12.00 AM
	// This method will get executed on every day @ 00.00 AM
	@Override
	//@Scheduled(cron = "${cron.schedule.expiredPayLink}")

	@Scheduled(cron = "0 0 0 1/1 * ?") 
	public void markPayLinkInactive() throws Exception{
		
		logger.info("Inside TagicTaskSchedulerImpl..:: Cron job Started at "+new Date());
		
		try{
			dbService.markPayLinkInactive();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		

	}
	// This method will get executed on every Sunday @ 1PM
	@SuppressWarnings("unchecked")
	@Override
	@Scheduled(cron = "0 0 0 1/1 * ?")
	public void generateJSONFileForMstData() throws Exception 
	{	
		String methodName = "generateJSONFileForMstData";	
		JSONObject jsonObject = new JSONObject();
        JSONObject childjsonObject = new JSONObject();
        String code = null;
        List<ParameterList> oComMasterList = new ArrayList<ParameterList>();
        File sysFile = null;
        File usrFile = null;
        File directory = null;
        FileWriter fileWriter = null;
        try
        {
			
			logger.info("Inside "+className+" :: "+methodName+" : Cron job Started at "+new Date());
			
			
			ServiceUtility su = new ServiceUtility();
            JSONParser parser = new JSONParser();
            
            String dirPath = su.getPropertyCodeProperty("master.data.dir.name", "resources.properties");
	        directory = new File(dirPath);
	        if (!directory.exists())
	        {
	            directory.mkdir();
	            //if(logger.isDebugEnabled())
	            	logger.debug("Inside "+className+" :: "+methodName+" : Directory Created As It Was Not Present On Provided Path ==> "+dirPath);
	        }
            
            
	        jsonObject = new JSONObject();
			code = CommonConstants.System_Master_Code;
			oComMasterList = new ArrayList<ParameterList>();
			oComMasterList =  (List<ParameterList>) dbService.get("com.majesco.dcf.common.tagic.entity.ParameterList","nsystemuser",CommonConstants.System_Master_Code);
			String sysFilePath = su.getPropertyCodeProperty("master.data.json.sys", "resources.properties");
			//if(logger.isDebugEnabled())
				logger.debug("Inside "+className+" :: "+methodName+" : sysFilePath ==> "+sysFilePath);
	        for(ParameterList masterList:oComMasterList)
	        {
	                      List<ParameterDetailList> oComListDetails =  (List<ParameterDetailList>) dbService.getList("com.majesco.dcf.common.tagic.entity.ParameterDetailList","iparamtypecd",masterList.getIparamtypecd());
	                      childjsonObject = new JSONObject();
	                      for(ParameterDetailList masterdtl:oComListDetails)
	                      {
	                           String strkey = masterdtl.getStrparamcd();
	                           String strVal = masterdtl.getStrcddesc().trim();                                         
	                           childjsonObject.put(strkey,strVal);
	                      }
	               
	               String strid=masterList.getIparamtypecd()!=null?masterList.getIparamtypecd().toString():"";
	               String strKey = masterList.getStrtypename();
	               jsonObject.put(strKey,childjsonObject);
	        }
	        
	        
	        sysFile = new File(sysFilePath);
	        if (!sysFile.exists()) 
	        {
	        	sysFile.createNewFile();
	        	fileWriter = new FileWriter(sysFile);
	        	fileWriter.write(jsonObject.toJSONString());  
	            fileWriter.flush();  
	            fileWriter.close();
	            //if(logger.isDebugEnabled())
	            	logger.debug("Inside "+className+" :: "+methodName+" : File Created & Writing JSON Object To File ==> "+sysFilePath);
	        } 
	        else 
	        {
	        	sysFile.delete();
	        	sysFile.createNewFile();
	        	fileWriter = new FileWriter(sysFile);
	        	fileWriter.write(jsonObject.toJSONString());  
	            fileWriter.flush();  
	            fileWriter.close();
	            //if(logger.isDebugEnabled())
	            	logger.debug("Inside "+className+" :: "+methodName+" : File Deleted, Created Again & Writing JSON Object To File ==> "+sysFilePath);
	        }
	        
	        
	        jsonObject = new JSONObject();
	        code = CommonConstants.User_Master_Code;
	        oComMasterList = new ArrayList<ParameterList>();
			oComMasterList =  (List<ParameterList>) dbService.get("com.majesco.dcf.common.tagic.entity.ParameterList","nsystemuser",CommonConstants.User_Master_Code);
			String usrFilePath = su.getPropertyCodeProperty("master.data.json.usr", "resources.properties");
			//if(logger.isDebugEnabled())
				logger.debug("Inside "+className+" :: "+methodName+" : usrFilePath ==> "+usrFilePath);
	        for(ParameterList masterList:oComMasterList)
	        {
	                      List<UserParameterList> oComListDetails1 =  (List<UserParameterList>) dbService.getList("com.majesco.dcf.common.tagic.entity.UserParameterList","iparamtypecd",masterList.getIparamtypecd());
	                      childjsonObject = new JSONObject();
	                      for(UserParameterList masterdtl1:oComListDetails1)
	                      {
	                           String strkey1 = masterdtl1.getStrparamcd();
	                           String strVa1l = masterdtl1.getStrcddesc().trim();                                            
	                           childjsonObject.put(strkey1,strVa1l);
	                      }      
	               
	               String strid=masterList.getIparamtypecd()!=null?masterList.getIparamtypecd().toString():"";
	               String strKey = masterList.getStrtypename();
	               jsonObject.put(strKey,childjsonObject);
	        }
	        usrFile = new File(usrFilePath);
	        if (!usrFile.exists()) 
	        {
	        	usrFile.createNewFile();
	        	fileWriter = new FileWriter(usrFile);
	        	fileWriter.write(jsonObject.toJSONString());  
	            fileWriter.flush();  
	            fileWriter.close();
	            //if(logger.isDebugEnabled())
	            	logger.debug("Inside "+className+" :: "+methodName+" : File Created & Writing JSON Object To File ==> "+usrFilePath);
	        } 
	        else 
	        {
	        	usrFile.delete();
	        	usrFile.createNewFile();
	        	fileWriter = new FileWriter(usrFile);
	        	fileWriter.write(jsonObject.toJSONString());  
	            fileWriter.flush();  
	            fileWriter.close();
	            //if(logger.isDebugEnabled())
	            	logger.debug("Inside "+className+" :: "+methodName+" : File Deleted, Created Again & Writing JSON Object To File ==> "+usrFilePath);
	        }
	        
	        
	        
	        
	        
        }
        catch(Exception e)
        {
        	logger.error("Inside "+className+" :: "+methodName+" : Exception Occurred.... ",e);
        	e.printStackTrace();
        }
		
	}
	
	
	
	
	// Start: KetanM <Production 2505>| Re-hit mechanism to be put up for policycumreciept generation service
	@SuppressWarnings("unchecked")
	@Override
	@Scheduled(cron = "0 0/15 * 1/1 * ?")
	public void processRehitMechForExceptionPolicy() throws Exception 
	{	
		String methodName = "processRehitMechForExceptionPolicy";	
		ArrayList<ExceptionPolicy> lstExceptionPolicy = null;
		ReceiptCumPolicyResponse receiptResponse=null;
		ReceiptCumPolicyRequest accountServReq =null;
		Gson gson = new Gson();
		ObjectMapper objMapper = new ObjectMapper();
		ReceiptPaymentDetails paymentDetails = null;
		List<ReceiptPaymentDetails> lstPaymentDetails;
		List<ReceiptPaymentDetails> finalLstPaymentDetails;
		
		if(triggerRehitPolException!=null && triggerRehitPolException.equalsIgnoreCase("Y"))
		{
	        try
	        {
				logger.info("Inside "+className+" :: "+methodName+" : Cron job Started at "+new Date());
				
				List exceptionList = dbService.processRehitMechForExceptionPolicy();
				
				if(exceptionList!=null)
				{
					Iterator exceptionPolicyItr = exceptionList.iterator();
					
					if(exceptionPolicyItr!=null)
					{
						lstExceptionPolicy = new ArrayList<ExceptionPolicy>();
						HashMap<String, String> resultMap =new HashMap<String, String>();
						
						while(exceptionPolicyItr.hasNext())
						{
							resultMap=(HashMap<String, String>)exceptionPolicyItr.next();
							ExceptionPolicy exceptionPolicy = new ExceptionPolicy();
							
							if(resultMap!=null)
							{
								exceptionPolicy.setOrderId(resultMap.get(CommonConstants.PROCESS_REHIT_MECH_ORDER_ID));
								exceptionPolicy.setJsonRequest(resultMap.get(CommonConstants.PROCESS_REHIT_MECH_JSON_REQUEST));
								exceptionPolicy.setPostAuthCode(resultMap.get(CommonConstants.PROCESS_REHIT_MECH_POSTAUTHCODE));
							}
							
							lstExceptionPolicy.add(exceptionPolicy);
						}
					}
				}
				//if(logger.isDebugEnabled())logger.info("Inside "+className+" :: "+methodName+" : Total Count Obtained To Rehit Exception Policies --> "+lstExceptionPolicy.size());
				if(lstExceptionPolicy!=null && lstExceptionPolicy.size()>0)
				{
					for(int i=0;i<lstExceptionPolicy.size();i++)
					{
						ReceiptSelfPayLinkHandler handler = new ReceiptSelfPayLinkHandler();
						accountServReq = new ReceiptCumPolicyRequest();
						ExceptionPolicy exceptionPol = new ExceptionPolicy();
						exceptionPol = lstExceptionPolicy.get(i);
						//if(logger.isDebugEnabled())logger.debug("Inside "+className+" :: "+methodName+ " :: Writing exceptionPol :: "+objMapper.writeValueAsString(exceptionPol));
						String strJsonObj = exceptionPol.getJsonRequest()==null?"":exceptionPol.getJsonRequest();
						accountServReq = gson.fromJson(strJsonObj, ReceiptCumPolicyRequest.class);
						
						lstPaymentDetails = new ArrayList<ReceiptPaymentDetails>();
						lstPaymentDetails = accountServReq.getPaymentDetails();
						finalLstPaymentDetails = new ArrayList<ReceiptPaymentDetails>();
						for(int j=0;j<lstPaymentDetails.size();j++)
						{
							paymentDetails = new ReceiptPaymentDetails();
							paymentDetails = lstPaymentDetails.get(j);
							if(paymentDetails.getPaymentType()!=null && paymentDetails.getPaymentType().contains("SPL"))
							{
								//if(logger.isDebugEnabled())logger.debug("Inside "+className+" :: "+methodName+ " :: Writing AuthCode :: "+exceptionPol.getPostAuthCode());
								paymentDetails.setInstrumentNo(exceptionPol.getPostAuthCode());
							}
							finalLstPaymentDetails.add(paymentDetails);
						}
						accountServReq.setPaymentDetails(finalLstPaymentDetails);
						
						//if(logger.isDebugEnabled())logger.debug("Inside "+className+" :: "+methodName+ " :: accountServReq for lstExceptionPolicy["+i+"]"+objMapper.writeValueAsString(accountServReq));
						if(accountServReq!=null && !accountServReq.equals(""))
						{
							try
							{
								receiptResponse = handler.callReceiptCumPolicyProcess(accountServReq, dbService);
								
								/*if(accountServReq!=null && accountServReq.getProposalDetails()!=null && accountServReq.getProposalDetails().getProposalNo()!=null && !accountServReq.getProposalDetails().getProposalNo().equals(""))
									dbService.isErrorWhileSelfPayTrans(CommonConstants.PROCESS_REHIT_MECH_SUCCESSFULLY_PERFORMED, accountServReq.getProposalDetails().getProposalNo(), accountServReq.getUserId(), null);*///commented as multiple count are going for only one hit.
							}
							catch(Exception e)
							{
								if(accountServReq!=null && accountServReq.getProposalDetails()!=null && accountServReq.getProposalDetails().getProposalNo()!=null && !accountServReq.getProposalDetails().getProposalNo().equals(""))
									dbService.isErrorWhileSelfPayTrans(e.toString(), accountServReq.getProposalDetails().getProposalNo(), accountServReq.getUserId(), null);
								
								logger.error("Inside "+className+" :: "+methodName+ " :: Exception Occurred While Creating Policy Through Rehit Mechanism", e);
							}
						}
						//if(logger.isDebugEnabled())logger.debug("Inside "+className+" :: "+methodName+ " :: accountServReq for lstExceptionPolicy["+i+"]"+objMapper.writeValueAsString(accountServReq)+" : Response Obtained After Rehitting : "+objMapper.writeValueAsString(receiptResponse));
						if(receiptResponse!=null && receiptResponse.getPolicyNo()!=null && !receiptResponse.getPolicyNo().equals(""))
						{
							if(accountServReq!=null && accountServReq.getProposalDetails()!=null && accountServReq.getProposalDetails().getProposalNo()!=null && !accountServReq.getProposalDetails().getProposalNo().equals(""))
								dbService.isErrorWhileSelfPayTrans(CommonConstants.PROCESS_REHIT_MECH_SUCCESS_MESSAGE, accountServReq.getProposalDetails().getProposalNo(), accountServReq.getUserId(), "100");
						}
					}
				}
				
			}
	        catch(Exception e)
	        {
	        	logger.error("Inside "+className+" :: "+methodName+" : Exception Occurred.... ",e);
	        	e.printStackTrace();
	        }
		}
		
	}
	// End: KetanM <Production 2505>| Re-hit mechanism to be put up for policycumreciept generation service	
	
	@Scheduled(cron = "0 0/20 * 1/1 * ?")
	public void sendCommunicationForPendingTxn() throws Exception {
		try {

			logger.info("Issue 9870467 :: sendCommunicationForPendingTxn execution started !!!");

			List<PGTransaction> pendingTxnList = null;
			int pendingTxnListSize = 0;

			List<SelfPaymentEntiry> commDetails = null;
			List<String> screenRefNo = new ArrayList<String>();
			int commDetailsSize = 0;

			// Getting data from dcf_pg_transaction for pending status in last 20min
			
			// if(dbService.fetchTxnWithPendingStatus() != null && !"".equals(dbService.fetchTxnWithPendingStatus())) {
			
			pendingTxnList = dbService.fetchTxnWithPendingStatus();
			pendingTxnListSize = pendingTxnList.size();
			logger.info("sendCommunicationForPendingTxn::pendingTxnListSize: " + pendingTxnListSize);

			// storing screenRefNo from each record into screenRefNo list
		
			if (pendingTxnListSize != 0) {
				for (int i = 0; i < pendingTxnListSize; i++) {
					screenRefNo.add(pendingTxnList.get(i).getScreenRefNo());
					/*logger.info("Issue 9870467: screenRefNo :: "
							+ screenRefNo.get(i));*/
				}

				// Getting mobile no and email for each screenRefNo from
				if (screenRefNo != null) {
					commDetails = dbService.fetchCommunicationDetails(screenRefNo);
					commDetailsSize = commDetails.size();
				}

				// sending sms
				if (commDetailsSize != 0) {
					try {
						logger.info("Issue 9870467::sendCommunicationForPendingTxn:: sending sms");
						for (int i = 0; i < commDetailsSize; i++) {
							CommunicationRequest commRequestSMS = new CommunicationRequest();

							logger.info("In sendCommunicationForPendingTxn :: sending SMS to "
									+ commDetails.get(i).getMobile());
							commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
							commRequestSMS.setEventType(CommonConstants.PMT_PENDING);
							commRequestSMS.setReceipient(commDetails.get(i).getMobile());
							commRequestSMS.setParam1(commDetails.get(i).getCustomerName());
							commRequestSMS.setParam2(commDetails.get(i).getTransId());
							commRequestSMS.setParam3(commDetails.get(i).getPropPolNbr());
							commRequestSMS.setParam4(commDetails.get(i).getProducerName() == null ? "TATAAIG" : commDetails.get(i).getProducerName());
							
							commService.sendCommunication(commRequestSMS);
							logger.info("In sendCommunicationForPendingTxn :: SMS sent successfully to "
									+ commDetails.get(i).getMobile());
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} 

				// send email
				if (commDetailsSize != 0 ) {
					try {
						logger.info("Issue 9870467::sendCommunicationForPendingTxn:: sending mail");
						for (int i = 0; i < commDetailsSize; i++) {
							CommunicationRequest commRequest = new CommunicationRequest();
							commRequest.setAlertType(CommonConstants.SEND_EMAIL);
							commRequest.setEventType(CommonConstants.PMT_PENDING);
							commRequest.setReceipient(commDetails.get(i).getEmail()); // Email
							logger.info("ISSUE 9870467::Sending Email to:: " + commDetails.get(i).getEmail());
							commRequest.setParam1(commDetails.get(i).getCustomerName());
							commRequest.setParam2(commDetails.get(i).getPropPolNbr());
							commRequest.setParam3(commDetails.get(i).getTransAmount());
							commRequest.setParam4(commDetails.get(i).getProducerName() == null ? "TATAAIG" : commDetails.get(i).getProducerName());
							commRequest.setParam5(commDetails.get(i).getProducerCd());
							commRequest.setParam6(commDetails.get(i).getTransId()); 
							commRequest.setParam7(commDetails.get(i).getCustomerName());
							commRequest.setParam8(commDetails.get(i).getPropPolNbr());
							commRequest.setParam9(commDetails.get(i).getProducerName() == null ? "TATAAIG" : commDetails.get(i).getProducerName());
							commRequest.setProductCode(commDetails.get(i).getProductCd());	
    						commRequest.setProducerEmail(commDetails.get(i).getEmail());
    						commRequest.setUserID("0000003000001");
							commRequest.setPassword("Tagic@12345");
							commService.sendCommunication(commRequest);
							
    						logger.info("Issue 9870467 :: In sendCommunicationForPendingTxn, Mail sent successfully to "
									+ commDetails.get(i).getEmail());
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		} catch (Exception e) {
			logger.info("In catch of sendCommunicationForPendingTxn:: ");
			e.printStackTrace();
		}
		logger.info("sendCommunicationForPendingTxn completed successfully!!!!!!!");

	}
	@SuppressWarnings("unchecked")
	@Override
	@Scheduled(cron = "0 0/15 * 1/1 * ?")
	public void processSetStatusForSuccessPolicy() throws Exception 
	{
	if(triggerCPIScheduler!=null && triggerCPIScheduler.equalsIgnoreCase("Y")){
		try {
			
			logger.info("CPI execution started !!!");
			
			//String abc="{\"startDate\":\"2018-05-03 00:00:00.000\",\"endDate\":\"2018-06-01 00:00:00.000\",\"appID\":\"CHP001\"}";
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar now = Calendar.getInstance();
			now.set(Calendar.HOUR, 01);
			now.set(Calendar.MINUTE, 0);
			now.set(Calendar.SECOND, 0);
			logger.info(dateFormat.format(now.getTime()));
			String startDate = dateFormat.format(now.getTime());
			now.set(Calendar.HOUR_OF_DAY, 23);
			logger.info(dateFormat.format(now.getTime()));
			String endDate =  dateFormat.format(now.getTime());
			
			JSONObject jsonObj = new JSONObject(); 
			jsonObj.put("startDate", startDate); 
			jsonObj.put("endDate", endDate); 
			jsonObj.put("appID", "CHP001");

			// CPI code to send message over HTTP
			StringBuffer respBuff = new StringBuffer();
			StringBuffer respBuff1 = new StringBuffer();
			
			//System.getProperties().put("proxySet", "true");
	        //System.getProperties().put("proxyHost", "10.35.14.12");
	        //System.getProperties().put("proxyPort", "8099");	//PORT
	        
	        logger.info("In CPIHelper.postTravelReqOnHTTP :: System.getProperties() after entry...");
	        TrustManager[] trustAllCerts = new TrustManager[]{
	                new X509TrustManager() {
	                    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                        return null;
	                    }
	                    public void checkClientTrusted(
	                        java.security.cert.X509Certificate[] certs, String authType) {
	                    }
	                    public void checkServerTrusted(
	                        java.security.cert.X509Certificate[] certs, String authType) {
	                    }
	                }
	            };
	        
	            SSLContext sc = SSLContext.getInstance("SSL");
	            sc.init(null, trustAllCerts, new java.security.SecureRandom());
	            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	            HostnameVerifier allHostsValid = new HostnameVerifier() {
	                    public boolean verify(String hostname, SSLSession session) {
	                          return true;
	                    }

						
	              };
	            
	              logger.info("licence installation done...");

	            // Install the all-trusting host verifier
	            HttpsURLConnection.setDefaultHostnameVerifier((javax.net.ssl.HostnameVerifier) allHostsValid);
	              
	            //InetSocketAddress proxyInet= new InetSocketAddress("mhpprxy.majesco.com",new Integer("8080"));
	            InetSocketAddress proxyInet= new InetSocketAddress("10.35.14.12",new Integer("8099"));
	            Proxy proxy=new Proxy(Proxy.Type.HTTP,proxyInet);
	            //String json = encyReqStr;
	            
	            //connect to HTTP URL
	            URL url = new URL("https://pay.tataaig.com/PaymentGatewayUtilityServices/getTransactionDetails/");
	            URLConnection connection = url.openConnection(proxy);
	            connection.setDoOutput(true);
	            connection.setDoInput(true);
	            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8"); //added by @Yogesh
	            logger.info("trying to connect CPI system...");
	            
	         // publish xml to remote HTPPS url using URLConnection
	            PrintStream ps = new PrintStream(connection.getOutputStream());
	            ps.println(jsonObj);
	            ps.close();
	            
	         // read response received from remote URL
	            DataInputStream inStream = new DataInputStream(connection.getInputStream());
	            String inputLine;
	            while ((inputLine = inStream.readLine()) != null) {
	            	
	            	if(inputLine.contains("json")){
	            		respBuff1.append(inputLine);
	            	}
	                respBuff.append(inputLine);
	            }

	            

	            logger.info("response json data in string buffer => from CPI Schedular"+ respBuff.toString());
	            
	            List<CPIPayment> paymentList = new ArrayList<CPIPayment>(); 
	            JsonParser parser = new JsonParser();  
	            JsonElement rootNode = parser.parse(respBuff.toString()) ;
	            
	            if (rootNode.isJsonObject()) {
	            
	            	JsonObject json = rootNode.getAsJsonObject(); 
	            	JsonElement  serviceResponse = json.get("serviceResponse"); 
	            	String response = serviceResponse.getAsString();

	                 GsonBuilder builder = new GsonBuilder();
	                 Gson gson = builder.create();
	                
	                 JSONArray responseArray = new JSONArray(response);
	                 List<Object> objectList = responseArray.toList(); 
	                 ListIterator<Object> ltr = objectList.listIterator();
	                 
	                 while(ltr.hasNext()){
	                	 String jsonString = gson.toJson( ltr.next());
	                	 CPIPayment cpireq = gson.fromJson(jsonString, CPIPayment.class);
	                	 paymentList.add(cpireq);  
	                 } 
	            }
	            
	            //call to dbservice to fetch failed transactions 
	            List<String> failedTransList = new ArrayList<String>();
	            List<HashMap<String, String>> proposalList = dbService.getFailedTransactionList();
				for(HashMap<String, String> tempMap : proposalList )
				{
					String tempVar = tempMap.get("strscreenrefno");
					failedTransList.add(tempVar);
				}
				
				//To find transaction where payment status changed to success
				List<CPIPayment> successList = new ArrayList<CPIPayment>();
				logger.info("To find transaction where payment status changed to success from CPI Schedular ");
	            if(failedTransList != null && paymentList != null)
	            {
		           for(int i =0; i<paymentList.size(); i++)
		           {
		        	   for(int j =0; j<failedTransList.size(); j++ )
		        	   {
		        		   if(paymentList.get(i).getConsumer_txn_id().equalsIgnoreCase(failedTransList.get(j)))
		        		   {
		        			   if(paymentList.get(i).getTxn_status().equalsIgnoreCase("Success"))
		        			   {
		        				   successList.add(paymentList.get(i));
		        				   logger.info("Payment Successful but policy not generated from CPI Schedular");
		        			   }
		        		   }
		        	   }
		           }
	
	            }
	            
	            logger.info("SuccessList object size from CPI Schedular>>>>>>>>"+successList.size());
	            Map <String,String> resultMap = new HashMap<String,String>();
	            if(successList != null)
	            {
	            	CPIPayment successTrans = null;
	            	Iterator str = successList.iterator();
	            	while(str.hasNext())
	            	{
	            		successTrans = (CPIPayment) str.next();
	            		try{
	            			
	            			int result1= dbService.updateSelfPayTrans(successTrans.getConsumer_txn_id());
		            		int result2 = dbService.updatePgTransaction(successTrans.getConsumer_txn_id(),successTrans.getCpi_txn_id(),successTrans.getGateway_txn_id());
		            		if(result1==0 && result2 == 0)
							{
								resultMap.put("isError", "1");
								resultMap.put("messageDisplay", "Sorry! Please try after sometime");
								logger.info("In processSetStatusForSuccessPolicy() :: Issue while updating self_pay_trans and pg_transaction in DB from CPI Schedular");
							}
		            		else
		            		{
		            			logger.info("successfully updated table =>from CPI Schedular ");
    			String methodName = "processSetStatusForSuccessPolicy";	
    			ReceiptCumPolicyResponse receiptResponse=null;
    			ReceiptSelfPayLinkHandler handler = new ReceiptSelfPayLinkHandler();
    			ArrayList<ExceptionPolicy> lstExceptionPolicy = null;
    			ReceiptCumPolicyRequest accountServReq =null;
    			
    			ObjectMapper objMapper = new ObjectMapper();
    			List exceptionList = dbService.processCPIUserDetail(successTrans.getConsumer_txn_id());
    			
    			logger.info("Count of User for send Mail from CPISCHEDULAR>>>>>>>>"+ exceptionList.size());
    			//List exceptionList = dbService.processCPIUserDetail("CHP20180510104103312142");
    			lstExceptionPolicy = new ArrayList<ExceptionPolicy>();
				HashMap<String, String> result =new HashMap<String, String>();
				if(exceptionList!=null)
				{
					Iterator exceptionPolicyItr = exceptionList.iterator();
					
					if(exceptionPolicyItr!=null)
					{
						
						
						while(exceptionPolicyItr.hasNext())
						{
							result=(HashMap<String, String>)exceptionPolicyItr.next();
							ExceptionPolicy exceptionPolicy = new ExceptionPolicy();
							logger.info("result map after concerting to MAP "+ objMapper.writeValueAsString(result));
							if(result!=null)
							{
								logger.info("exceptionPolicy.setOrderId from CPI Schedular"+ objMapper.writeValueAsString(result.get(CommonConstants.PROCESS_REHIT_MECH_ORDER_ID)));
								logger.info("exceptionPolicy.setJsonRequest from CPI Schedular "+ objMapper.writeValueAsString(result.get(CommonConstants.PROCESS_REHIT_MECH_JSON_REQUEST)));
								logger.info("exceptionPolicy.setPostAuthCode from CPI Schedular"+ objMapper.writeValueAsString(result.get(CommonConstants.PROCESS_REHIT_MECH_POSTAUTHCODE)));
								exceptionPolicy.setOrderId(result.get(CommonConstants.PROCESS_REHIT_MECH_ORDER_ID));
								exceptionPolicy.setJsonRequest(result.get(CommonConstants.PROCESS_REHIT_MECH_JSON_REQUEST));
								exceptionPolicy.setPostAuthCode(result.get(CommonConstants.PROCESS_REHIT_MECH_POSTAUTHCODE));
								
							}
							
							lstExceptionPolicy.add(exceptionPolicy);
						}
					}
				}
				
				//Added By Rahul Kumar for inserting in payment details
				Gson gson = new Gson();
				PaymentDetails payDtlsTrans = null;
				HashMap<String,String> resultAccService = new HashMap<String,String>();
				resultAccService = (HashMap<String,String>)dbService.getBilldeskStgDtl("com.majesco.dcf.common.tagic.entity.OnlineAccountService","strOrderID",successTrans.getConsumer_txn_id());
				String strJsonObj = (String) resultAccService.get("func_get_online_acc_service_dtl")==null?"":resultAccService.get("func_get_online_acc_service_dtl");
				accountServReq = gson.fromJson(strJsonObj, ReceiptCumPolicyRequest.class);
				ArrayList lstPaymentTransDtls = new ArrayList();
				if(logger.isDebugEnabled())logger.info("Inside "+className+" :: "+methodName+" : Total Count Obtained To CPISCHEDULAR--> "+lstExceptionPolicy.size());
				
				if (accountServReq!=null && accountServReq.getProposalDetails()!=null ){
					{
						for (ReceiptPaymentDetails paymentDtl: accountServReq.getPaymentDetails()){
							if (paymentDtl.getPaymentType()!=null && paymentDtl.getPaymentType().contains("SPL")){ 
								logger.info("Called to Create Policy before from CPI Schedular>>>>>>>>>>");
								paymentDtl.setInstrumentNo(successTrans.getGateway_txn_id());	
							receiptResponse = handler.callReceiptCumPolicyProcess(accountServReq, dbService);
							logger.info("Called to Create Policy After from CPI Schedular>>>>>>>>>>");
							logger.info("Policy Number generated from CPI Schedular>>>>>>>>>>"+receiptResponse.getPolicyNo());
	            			if (receiptResponse!=null && receiptResponse.getPolicyNo()!=null){
	            				
	            				if (paymentDtl!=null && paymentDtl.getPaymentType().contains("SPL")){
	            					payDtlsTrans = new PaymentDetails();
	        						lstPaymentTransDtls = (ArrayList) dbService.getPaymentDetailsTransaction("com.majesco.dcf.common.tagic.entity.PaymentDetails", payDtlsTrans.getStrproposalno());	
	        						if(logger.isDebugEnabled())logger.debug("PaymentServiceImpl:: selfPaymentResponse:: value extracted from payment table for SPL part payment transaction--> "+objMapper.writeValueAsString(lstPaymentTransDtls));
	        						if(lstPaymentTransDtls!=null && lstPaymentTransDtls.size() > 0)
	        						{
	        							for(int i=0;i<lstPaymentTransDtls.size(); i++)
	        							{
	        								PaymentDetails payDtlsDB = new PaymentDetails();
	        								payDtlsDB = (PaymentDetails) lstPaymentTransDtls.get(i);
	        								
	        								if(payDtlsDB!=null && payDtlsDB.getStrpaymentmode()!=null && !payDtlsDB.getStrpaymentmode().equals("") && !payDtlsDB.getStrpaymentmode().equals("SPL"))
	        								{
	        									payDtlsTrans.setLtransId(payDtlsDB.getLtransId());
	        								}
	        							}
	        						}
	        					}
	            				String instrumentDt = "";
	            				SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
	            				instrumentDt=paymentDtl.getInstrumentDate();
	            				if(instrumentDt==null || instrumentDt.equalsIgnoreCase(CommonConstants.BLANK_STRING))
	            					instrumentDt=sdf.format(new Date());
	            				payDtlsTrans.setStrpaymentinstrumentdt(sdf.parse(instrumentDt));
	            				payDtlsTrans.setStrinstrumentno(paymentDtl.getInstrumentNo()!=null?paymentDtl.getInstrumentNo():"");
	            				payDtlsTrans.setStripaddress(accountServReq.getSystemIPAddress()!=null?accountServReq.getSystemIPAddress():"");
	            				payDtlsTrans.setStrpaymentmode(paymentDtl.getPaymentType()!=null?paymentDtl.getPaymentType():"");
	            				payDtlsTrans.setStrpaymentamount(paymentDtl.getPaymentAmount()!=null?paymentDtl.getPaymentAmount():"");
	        					payDtlsTrans.setStrpolicyno(receiptResponse.getPolicyNo()!=null?receiptResponse.getPolicyNo():"");
	        					payDtlsTrans.setStrgcreceiptno(receiptResponse.getReceiptDtls().getReceiptNo()!=null?receiptResponse.getReceiptDtls().getReceiptNo():"");
	        					payDtlsTrans.setStrgcsubreceiptno(receiptResponse.getReceiptDtls().getSubReceiptId()!=null?receiptResponse.getReceiptDtls().getSubReceiptId():"");
	        					if(accountServReq.getProposalDetails()!=null)
	        					{
	        						payDtlsTrans.setStrproposalno(accountServReq.getProposalDetails().getProposalNo()!=null?accountServReq.getProposalDetails().getProposalNo():"");
	        						payDtlsTrans.setStrcustid(accountServReq.getProposalDetails().getCustomerId()!=null?accountServReq.getProposalDetails().getCustomerId():"");
	        						payDtlsTrans.setStrbalanceamt(accountServReq.getProposalDetails().getBalanceAmount()!=null?accountServReq.getProposalDetails().getBalanceAmount():"");
	        						payDtlsTrans.setStrworkflowid(accountServReq.getProposalDetails().getProposalSystemId()!=null?accountServReq.getProposalDetails().getProposalSystemId():"");
	        						
	        						if(accountServReq.getProposalDetails().getPolicyEffDt()!=null && !accountServReq.getProposalDetails().getPolicyEffDt().equals(""))
	        							payDtlsTrans.setStrpolicystartdt(sdf.parse(accountServReq.getProposalDetails().getPolicyEffDt()));
	        						else
	        							payDtlsTrans.setStrpolicystartdt(null);
	        						
	        						if(accountServReq.getProposalDetails().getPolicyEndDt()!=null && !accountServReq.getProposalDetails().getPolicyEndDt().equals(""))
	        							payDtlsTrans.setStrpolicyenddt(sdf.parse(accountServReq.getProposalDetails().getPolicyEndDt()));
	        						else
	        							payDtlsTrans.setStrpolicyenddt(null);
	        						
	        						payDtlsTrans.setStrproductcd(accountServReq.getProposalDetails().getProductCode()!=null?accountServReq.getProposalDetails().getProductCode():"");
	        						payDtlsTrans.setStrproducercd(accountServReq.getProducerCode()!=null?accountServReq.getProducerCode():"");
	        						payDtlsTrans.setStrcreatedby(accountServReq.getProducerName()!=null?accountServReq.getProducerName():"");
	        						payDtlsTrans.setDtcreated(new Date());
	        						payDtlsTrans.setStrbusinessLocation(accountServReq.getProposalDetails().getBusinessLocation()!=null?accountServReq.getProposalDetails().getBusinessLocation():"");
	        						payDtlsTrans.setStrdepositofficecode(accountServReq.getProposalDetails().getDepositOfficeCode()!=null?accountServReq.getProposalDetails().getDepositOfficeCode():"");
	        						payDtlsTrans.setStrbusslocname(accountServReq.getProposalDetails().getBussLocName()!=null?accountServReq.getProposalDetails().getBussLocName():"");
	        						payDtlsTrans.setStrnewrenewflag(accountServReq.getStrnewrenewflag()!=null?accountServReq.getStrnewrenewflag():""); // internal issues to save renewal flag in PaymentDetails. : Vishal J | 11-08-2017
	        					}
	        					if (paymentDtl!=null && paymentDtl.getPaymentType().contains("SPL")){	// 2027| RahulT| condition modified for SPL+AD
	        						//dbService.updatePaymentDetailForSPL(payDtlsTrans);
	        						dbService.saveOrUpdate(payDtlsTrans);
	        						logger.info("Updated or Saved In Payment Details from CPI Schedular>>>>>>>>>>");
	        					}
	        					else{
	        						dbService.saveOrUpdate(payDtlsTrans);
	        						logger.info("Updated or Saved In Payment Details from CPI Schedular>>>>>>>>>>");
	        					}
	            				
	            				
	            				logger.info("Sending Mail To User After Policy Generation");
	            				handler.sendMailAndSmsAfterPolicyGen(receiptResponse,accountServReq,commService);
	            				logger.info("Mail Sent Succesfully from CPI after Policy Generation");
	            			}		
							}
												
						}
				
					}
					///////////////////////////////////////////////////////////
				}
				   			
		            		}
	            			
	            		}
	            		catch(Exception ex)
	            		{
	            			logger.info("In processSetStatusForSuccessPolicy() ::  Excpetion in CPI Schedular while updating self_pay_trans and pg_transaction in DB "+ ex);
	            		}
	            		
	            		
	            	}
	            }
	            logger.info("Closing inStream");
	            inStream.close(); 
		
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		}
	}
	}



	//Start paymentDonePolicyNotIssued
	@Scheduled(cron = "0 0/20 * 1/1 * ?")
	public void paymentSchedulerForSuccessPaymentPolicyNotIssued() throws Exception {
		if(triggerSplitPaymentScheduler!=null && triggerSplitPaymentScheduler.equalsIgnoreCase("Y")){	
		logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: STARTED");
		logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Push data in Pmt_Flow_flag");
		
		List exceptionList = dbService.getFailedSplitService();
		ArrayList<PGTransaction> lstExceptionPolicy = null;
		if(exceptionList!=null)
		{
			Iterator exceptionPolicyItr = exceptionList.iterator();
			
			if(exceptionPolicyItr!=null)
			{
				lstExceptionPolicy = new ArrayList<PGTransaction>();
				HashMap<String, String> resultMap =new HashMap<String, String>();
				
				while(exceptionPolicyItr.hasNext())
				{
					resultMap=(HashMap<String, String>)exceptionPolicyItr.next();
					PGTransaction exceptionPolicy = new PGTransaction();
					
					if(resultMap!=null)
					{
						exceptionPolicy.setScreenRefNo(resultMap.get(CommonConstants.STRING_REF_ID));
						exceptionPolicy.setTxnModeVal(resultMap.get(CommonConstants.STRING_PROPOSAL_NUM));
						if(exceptionPolicy.getScreenRefNo() != null && exceptionPolicy.getTxnModeVal() != null){
							PmtFlowFlags pmtFlowFlags = new PmtFlowFlags();
							pmtFlowFlags.setStrproposalno(exceptionPolicy.getTxnModeVal());
							pmtFlowFlags.setStrscreenrefno(exceptionPolicy.getScreenRefNo());
							pmtFlowFlags.setStrfinalstatus("F");
							pmtFlowFlags.setStrreceiptentryflag("F");
							pmtFlowFlags.setDtcreated(new Date());
							dbService.updatePmtFlowFlag(pmtFlowFlags);

						}
						
					}
					
				}
			}
		}
		
	
		List<PmtFlowFlags> lstPmtFlowFlags = new ArrayList<PmtFlowFlags>();
		boolean CommunicationStatusFlag = false; // flag for sending communication
		
		
		//Get failed records from PMT flow flag table
		logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler ::Befor Calling getFailedRecordsForScheduler");
		lstPmtFlowFlags = dbService.getFailedRecordsForScheduler();
		logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler ::After Calling getFailedRecordsForScheduler");
		
		logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: lstPmtFlowFlags size ---> " + lstPmtFlowFlags.size());
		
		if(lstPmtFlowFlags != null && !lstPmtFlowFlags.isEmpty() &&lstPmtFlowFlags.size() >= 0){
			for (PmtFlowFlags flowFlags :  lstPmtFlowFlags){
				if(flowFlags != null & flowFlags.getStrproposalno() != null){
					logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: lstPmtFlowFlags proposalNo ---> "+flowFlags.getStrproposalno());
				}
			}
		}
		
		
		ReceiptCumPolicyResponse receiptResponse=null;
		ReceiptCumPolicyRequest receptReq =null;
		PaymentEntryServiceResult responsePropTagService =null;
		OnlineAccountService onlAccountService = new OnlineAccountService();
		//TagicCommunicationLiteService tagicCommLite = new TagicCommunicationLiteService();
			
	   if(lstPmtFlowFlags != null && !lstPmtFlowFlags.isEmpty() &&lstPmtFlowFlags.size() > 0) {
				
			 if(serviceURL==null || serviceURL.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING))
			{
				logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before dbService.getWSDLURL---> "+ReceiptConstants.ACCOUNTSERVICE_ID);
				serviceURL=dbService.getWSDLURL(ReceiptConstants.ACCOUNTSERVICE_ID,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
				logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: After dbService.getWSDLURL ---> "+ReceiptConstants.ACCOUNTSERVICE_ID);
				
				
			}
			 
			 if(serviceURL != null && !serviceURL.equalsIgnoreCase(ReceiptConstants.ACCOUNTSERVICE_BLANK_STRING)){
				 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: serviceURL ---> "+serviceURL);
			 }
				
		for(PmtFlowFlags flowFlags : lstPmtFlowFlags) {
				logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Inside For Loop: A1");
				String scrnRefNo = "";
				double dTotalAmtPartPayment = 0;
				String strTotalAmtPartPayment = "";
				String customerSMSSuccess = ""; 
				String customerEmailSuccess = ""; 
				String policyNumber = "";
				String receiptNumber = "";
				String transRefNo="";
				String orderId="";
				Gson gson = new Gson();
				PaymentDetails paymentDetails = new PaymentDetails();
				if(flowFlags.getStrscreenrefno() != null && !flowFlags.getStrscreenrefno().equalsIgnoreCase(CommonConstants.BLANK_STRING)){
					scrnRefNo = flowFlags.getStrscreenrefno();
				}
				if(scrnRefNo != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(scrnRefNo)){
					logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Before Calling getListFromScrnRef");
					onlAccountService = dbService.getListFromScrnRef(scrnRefNo);
					logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Afetr Calling getListFromScrnRef");
				}
				
				if(onlAccountService != null && onlAccountService.getStrRequestMsg() != null 
						&& !CommonConstants.BLANK_STRING.equalsIgnoreCase(onlAccountService.getStrRequestMsg())){
					String requestService = onlAccountService.getStrRequestMsg();
					logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: request Service is ----------> " + requestService);
					
					 if(onlAccountService.getStrOrderID() != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(onlAccountService.getStrOrderID())){
							
							orderId = onlAccountService.getStrOrderID();
							logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: order ID is ------> " + orderId);
							logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before calling dbService.getBilldeskTrnsrefData ");
							transRefNo =  dbService.getBilldeskTrnsrefData(orderId);
							logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after calling dbService.getBilldeskTrnsrefData ");
							logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: transRefNo --------------> " + transRefNo);
							
						}
				
                   if(onlAccountService.getStrOrderID() != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(onlAccountService.getStrOrderID())){
					
					receptReq = gson.fromJson(requestService, ReceiptCumPolicyRequest.class);
					 String email =  receptReq.getPaymentDetails().get(0).getEmailID();
					 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: email --------------> " + email);
					 String mobile = receptReq.getPaymentDetails().get(0).getMobileNo();
					 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: mobile --------------> " + mobile);
					
						 
						 
						 if (receptReq.getPaymentDetails().get(0).getPaymentAmount()!=null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(receptReq.getPaymentDetails().get(0).getPaymentAmount())){
						 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before receptReq.getPaymentDetails().get(0).getPaymentAmount()");
						 dTotalAmtPartPayment = dTotalAmtPartPayment + Double.valueOf(receptReq.getPaymentDetails().get(0).getPaymentAmount()).doubleValue();	
						 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after receptReq.getPaymentDetails().get(0).getPaymentAmount()");
						}
					 strTotalAmtPartPayment = new String(CommonConstants.BLANK_STRING+Math.round(dTotalAmtPartPayment)); 
					 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after strTotalAmtPartPayment"); 

						 // Check For Receipt Failed For Existing Proposal
						 if (flowFlags.getStrproposalno() != null
								 && !CommonConstants.BLANK_STRING.equalsIgnoreCase(flowFlags.getStrproposalno())
								 && flowFlags.getStrreceiptentryflag() !=null
								 && !CommonConstants.BLANK_STRING.equalsIgnoreCase(flowFlags.getStrreceiptentryflag())
								 && flowFlags.getStrreceiptentryflag().equalsIgnoreCase(CommonConstants.FAILURE_VALUE)
								 && flowFlags.getStrreceiptno() == null) {	
							 	logger.info("PDPN SCENARIO ID:: 0 ");
							    logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Failed For Existing Proposal ====>>> "+flowFlags.getStrproposalno());
							 
							    if(transRefNo != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(transRefNo)){
							    	for (ReceiptPaymentDetails paymentDtl: receptReq.getPaymentDetails()){
							    		paymentDtl.setInstrumentNo(transRefNo);
							    	}
							    }

							    
							    logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry:: --> A1 ");
								ReceiptSelfPayLinkHandlerForLiteService handler = new ReceiptSelfPayLinkHandlerForLiteService();
								logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Before Calling callReceiptCumPolicyProcess:: --> A1 ");
								receiptResponse = handler.callReceiptCumPolicyProcess(receptReq, dbService);
								logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: After Calling callReceiptCumPolicyProcess:: --> A1 ");
								
								
								if (receiptResponse != null && receiptResponse.getResultCode()!=null && receiptResponse.getResultCode().equals("1")) {
									logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> Success: --> A2");
									logger.info("PDPN SCENARIO ID:: 1.6 :: SUCCESS IN BOTH CRS AND PROPOSAL TAGGING ");
									if(receiptResponse.getReceiptDtls() != null && receiptResponse.getReceiptDtls().getReceiptNo() != null){
										receiptNumber = receiptResponse.getReceiptDtls().getReceiptNo();
									}
									
									if(receiptResponse.getPolicyNo() != null ){
										policyNumber = receiptResponse.getPolicyNo();
									}
									if(policyNumber != null && receiptNumber != null){
									paymentDetails.setStrpolicyno(policyNumber);
									paymentDetails.setStrgcreceiptno(receiptNumber);
									paymentDetails.setStrgcsubreceiptno("");
									
									if(flowFlags.getStrscreenrefno() != null ){
									setDataInPaymentDetails(paymentDetails,flowFlags.getStrscreenrefno());
									  }
									}
									CommunicationStatusFlag = true;
									logger.info("PDPN SCENARIO ID:: 1.7 :: COMMUNICATION FLAG = TRUE ");
									
									
								}else{
									logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> Failed --> A3");
									if(receiptResponse != null && receiptResponse.getResultCode()!=null 
											&& receiptResponse.getResultCode().equalsIgnoreCase("0") 
											&& receiptResponse.getErrorList() != null 
											&& !receiptResponse.getErrorList().isEmpty()
											&& receiptResponse.getErrorList().size() > 0 
											&& receiptResponse.getErrorList().get(0).getErrorMMessag() != null 
											&& !CommonConstants.BLANK_STRING.equals(receiptResponse.getErrorList().get(0).getErrorMMessag())
											&& receiptResponse.getErrorList().get(0).getErrorMMessag().toLowerCase().contains("Authorization Code already exists in the system.".toLowerCase())
											&& receiptResponse.getErrorList().get(0).getErrorMMessag().toLowerCase().contains("Receipt No(s).".toLowerCase())
											&& receiptResponse.getErrorList().get(0).getErrorMMessag().toLowerCase().contains(CommonConstants.RECEIPT_ENTRY_FOR_BFL.toLowerCase()))
										{
										logger.info("PDPN SCENARIO ID:: 3.4 :: AUTHORIZATION FAILED, RECEIPTbfl");
										
										logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> Failed In ReceiptEntryForBFL >> ErrorCode 12 --> A4");
										
										String str = receiptResponse.getErrorList().get(0).getErrorMMessag() ;
										logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> STring Receipt No.>>"+str);
										str = str.replace(CommonConstants.RECEIPT_ENTRY_FOR_BFL,"");
										String receiptNo="";
										
										logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> STring Receipt No.>>"+str);
										
										if(str != null){
											char charseq[] = str.toCharArray();
											for(int j =1; j<= str.length();j++){
												char last = charseq[str.length()-j];
												  if(last != '.'){
													  if (last == ' '){
														  break;
													  }
													  receiptNo = last+receiptNo;
												  }
											}
											logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued:: after receipt service failed, if error code is 12:: receiptNO ------>> " + receiptNo );
										}
										receiptNumber = receiptNo;
										logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued::before updating data in PmtFlowFlags " + receiptNumber );
										PmtFlowFlags flag = new PmtFlowFlags();
										flag.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
										flag.setStrreceiptentryflag(CommonConstants.SUCCESS_VALUE);
										flag.setStrreceiptno(receiptNumber);
										logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued::before calling  dbService.updatePmtFlowFlag " + receiptNumber );	
										dbService.updatePmtFlowFlag(flag);
										logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued::After calling dbService.updatePmtFlowFlag " + receiptNumber );			
										
										if(receiptNumber != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(receiptNumber)) 
										{
											//ProposalTaggingHandler propTagHandler = new ProposalTaggingHandler();
											
											AccountService_Service accService=new AccountService_Service(new URL(serviceURL));
											AccountService accServClient=accService.getSOAPOverHTTP();
											
											logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued::before calling  propTagHandler.proposalTaggingServiceCall ");
											responsePropTagService = propTagService.proposalTaggingServiceCall(receptReq, dbService, receiptNumber, accServClient);
											logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued::After calling  propTagHandler.proposalTaggingServiceCall ");
												if(responsePropTagService != null && responsePropTagService.getErrorCode()!=null 
													&& responsePropTagService.getErrorCode().equalsIgnoreCase("0") && responsePropTagService.getErrorMsg()!=null 
													&& responsePropTagService.getErrorMsg().equalsIgnoreCase("-1") && responsePropTagService.getPolicyNo() != null)
													{				
													logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> Failed >> ErrorCode 12 >> ProposalTag Success --> A5");
													//Start:: set success flag for proposalTagService
													PmtFlowFlags flag2 = new PmtFlowFlags();
													
													flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
													flag2.setStrreceiptentryflag(CommonConstants.SUCCESS_VALUE);
													flag2.setStrproposaltaggingflag(CommonConstants.SUCCESS_VALUE);
													flag2.setStrpdfgenflag(CommonConstants.FAILURE_VALUE);
													flag2.setStrpolicyno(responsePropTagService.getPolicyNo()== null ? "":responsePropTagService.getPolicyNo());
										            dbService.updatePmtFlowFlag(flag2);
										            //End:: set success flag for proposalTagService
										            if(responsePropTagService.getPolicyNo() != null){
										            policyNumber = responsePropTagService.getPolicyNo();
										            }
										            
													if(policyNumber != null && receiptNumber != null){
													paymentDetails.setStrpolicyno(policyNumber);
													paymentDetails.setStrgcreceiptno(receiptNumber);
													paymentDetails.setStrgcsubreceiptno("");
													
													if(flowFlags.getStrscreenrefno() != null ){
													setDataInPaymentDetails(paymentDetails,flowFlags.getStrscreenrefno());
													 }
													}

										            CommunicationStatusFlag = true;
											}else {
												   
												   logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> Failed >> ErrorCode 12 >> ProposalTag Failed --> A5.5");
													if(responsePropTagService != null 
															&& responsePropTagService.getErrorMsg()!=null 
															&& !responsePropTagService.getErrorMsg().equalsIgnoreCase("-1") 
															&& responsePropTagService.getErrorMsg().toLowerCase().contains("Proposal".toLowerCase())
															&& responsePropTagService.getErrorMsg().toLowerCase().contains("already tagged".toLowerCase())
															&& responsePropTagService.getErrorMsg().toLowerCase().contains(CommonConstants.PROPOSAL_TAGGING_CUM_POLICY_GEN.toLowerCase()))
														 {
															 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> Failed >> ErrorCode 12 >> ErrorCode 52--> A6");
															
															if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
																logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before getPolicyNumFromProposalNo ABC1");
																String policyNoStr = getPolicyNoFromDbLink(receptReq.getProposalDetails().getProposalNo());
																logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after getPolicyNumFromProposalNo ABC1");
																if(policyNoStr != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(policyNoStr)){
																	policyNumber = policyNoStr;
																	logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in if ABC1");
																}else if(responsePropTagService != null && responsePropTagService.getPolicyNo() != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getPolicyNo()) ){
																	policyNumber = responsePropTagService.getPolicyNo();
																	logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else if ABC1");
																}else{
																	policyNumber = "";
																	logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else ABC1");
																}
															}
															PmtFlowFlags flag2 = new PmtFlowFlags();
															flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
															flag2.setStrproposaltaggingflag(CommonConstants.SUCCESS_VALUE);
															flag2.setStrpdfgenflag(CommonConstants.FAILURE_VALUE);
															flag2.setStrpolicyno(policyNumber == null? "":policyNumber);
															if(responsePropTagService != null && responsePropTagService.getErrorCode()!=null 
																	&&  !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getErrorCode()) 
																	&& responsePropTagService.getErrorMsg()!=null && !responsePropTagService.getErrorMsg().equalsIgnoreCase("-1")){
																flag2.setStrerrormsginproptag(responsePropTagService.getErrorMsg()+" Error Code : "+responsePropTagService.getErrorCode()); 
															}
															logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before Calling dbService.updatePmtFlowFlag in A6");
															dbService.updatePmtFlowFlag(flag2);
															logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after Calling dbService.updatePmtFlowFlag in A6");
															
															if(policyNumber != null ){
																paymentDetails.setStrpolicyno(policyNumber);
																if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
																	receiptNumber = dbService.getReceiptFromProposal(receptReq.getProposalDetails().getProposalNo());
																	}
																
																if(receiptNumber != null){
																paymentDetails.setStrgcreceiptno(receiptNumber);
																}
																paymentDetails.setStrgcsubreceiptno("");
																
																if(flowFlags.getStrscreenrefno() != null ){
																setDataInPaymentDetails(paymentDetails,flowFlags.getStrscreenrefno());
																  }
																}
															
															CommunicationStatusFlag = true;
														 }else if(responsePropTagService != null 
																	&& responsePropTagService.getErrorMsg()!=null 
																	&& !responsePropTagService.getErrorMsg().equalsIgnoreCase("-1") 
																	&& responsePropTagService.getErrorMsg().toLowerCase().contains("Proposal No.".toLowerCase())
																	&& responsePropTagService.getErrorMsg().toLowerCase().contains("Authorization Code already exists in the system.".toLowerCase())
																	&& responsePropTagService.getErrorMsg().toLowerCase().contains(CommonConstants.PROPOSAL_TAGGING_CUM_POLICY_GEN.toLowerCase()))
														 {
															 
															 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> Failed >> ErrorCode 12 >> ErrorCode 52--> A6");
															 
																// DB Link code to get policy no
																
																if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
																	logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before getPolicyNumFromProposalNo ABC2");
																	String policyNoStr = getPolicyNoFromDbLink(receptReq.getProposalDetails().getProposalNo());
																	logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after getPolicyNumFromProposalNo ABC2");
																	if(policyNoStr != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(policyNoStr)){
																		policyNumber = policyNoStr;
																		logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in if ABC2");
																	}else if(responsePropTagService != null && responsePropTagService.getPolicyNo() != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getPolicyNo()) ){
																		policyNumber = responsePropTagService.getPolicyNo();
																		logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else if ABC2");
																	}else{
																		policyNumber = "";
																		logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else ABC2");
																	}
																}
															 
																PmtFlowFlags flag2 = new PmtFlowFlags();
																flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
																flag2.setStrproposaltaggingflag(CommonConstants.SUCCESS_VALUE);
																flag2.setStrpdfgenflag(CommonConstants.FAILURE_VALUE);
																flag2.setStrpolicyno(policyNumber == null? "":policyNumber);
																if(responsePropTagService != null && responsePropTagService.getErrorCode()!=null 
																		&&  !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getErrorCode()) 
																		&& responsePropTagService.getErrorMsg()!=null && !responsePropTagService.getErrorMsg().equalsIgnoreCase("-1")){
																			flag2.setStrerrormsginproptag(responsePropTagService.getErrorMsg()+" Error Code : "+responsePropTagService.getErrorCode()); 
																		}
																logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before Calling dbService.updatePmtFlowFlag in A6");
																dbService.updatePmtFlowFlag(flag2);
																logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after Calling dbService.updatePmtFlowFlag in A6");
																
																if(policyNumber != null ){
																	paymentDetails.setStrpolicyno(policyNumber);
																	if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
																		receiptNumber = dbService.getReceiptFromProposal(receptReq.getProposalDetails().getProposalNo());
																		}
																	
																	if(receiptNumber != null){
																	paymentDetails.setStrgcreceiptno(receiptNumber);
																	}
																	paymentDetails.setStrgcsubreceiptno("");
																	
																	if(flowFlags.getStrscreenrefno() != null ){
																	setDataInPaymentDetails(paymentDetails,flowFlags.getStrscreenrefno());
																	  }
																	}
															
																CommunicationStatusFlag = true;
															 
														 }
														 else {
															 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: --> A7");
															PmtFlowFlags flag2 = new PmtFlowFlags();
															flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
															flag2.setStrproposaltaggingflag(CommonConstants.FAILURE_VALUE);
															if(responsePropTagService != null && responsePropTagService.getErrorCode()!=null 
																	&&  !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getErrorCode()) 
																	&& responsePropTagService.getErrorMsg()!=null && !responsePropTagService.getErrorMsg().equalsIgnoreCase("-1")){
																		flag2.setStrerrormsginproptag(responsePropTagService.getErrorMsg()+" Error Code : "+responsePropTagService.getErrorCode()); 
																	}
															dbService.updatePmtFlowFlag(flag2);
															logger.info("Proposal Tag service failed as it is some other reason than error code 52");
														 }
													}	
										    }
										
										}else if(receiptResponse != null && receiptResponse.getResultCode()!=null 
												&& receiptResponse.getResultCode().equalsIgnoreCase("0")
												&& receiptResponse.getErrorList() != null 
												&& !receiptResponse.getErrorList().isEmpty()
												&& receiptResponse.getErrorList().size() > 0 
												&& receiptResponse.getErrorList().get(0).getErrorMMessag() != null 
											    && !CommonConstants.BLANK_STRING.equals(receiptResponse.getErrorList().get(0).getErrorMMessag())
												&& !receiptResponse.getErrorList().get(0).getErrorMMessag().equalsIgnoreCase("-1") 
												&& receiptResponse.getErrorList().get(0).getErrorMMessag().toLowerCase().contains("Proposal".toLowerCase())
												&& receiptResponse.getErrorList().get(0).getErrorMMessag().toLowerCase().contains("already tagged".toLowerCase()) 
												&& receiptResponse.getErrorList().get(0).getErrorMMessag().toLowerCase().contains(CommonConstants.PROPOSAL_TAGGING_CUM_POLICY_GEN.toLowerCase()))
											 {
											logger.info("PDPN SCENARIO ID:: 2.4 :: 'PROPOSAL ALREADY TAGGED SCENARIO'");
												 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> Failed >> ErrorCode 12 >> ErrorCode 52--> A6");
												
												if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
													logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before getPolicyNumFromProposalNo ABC1");
													String policyNoStr = getPolicyNoFromDbLink(receptReq.getProposalDetails().getProposalNo());
													logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after getPolicyNumFromProposalNo ABC1");
													if(policyNoStr != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(policyNoStr)){
														policyNumber = policyNoStr;
														logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in if ABC1");
													}else if(receiptResponse != null && receiptResponse.getPolicyNo() != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(receiptResponse.getPolicyNo()) ){
														policyNumber = receiptResponse.getPolicyNo();
														logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else if ABC1");
													}else{
														policyNumber = "";
														logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else ABC1");
													}
												}
												PmtFlowFlags flag2 = new PmtFlowFlags();
												flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
												flag2.setStrproposaltaggingflag(CommonConstants.SUCCESS_VALUE);
												flag2.setStrpdfgenflag(CommonConstants.FAILURE_VALUE);
												flag2.setStrpolicyno(policyNumber == null? "":policyNumber);
												
												if(receiptResponse != null && !receiptResponse.getErrorList().isEmpty()
														&& receiptResponse.getErrorList().size() > 0 
														&& receiptResponse.getErrorList().get(0).getErrorMMessag() != null 
														&&  !CommonConstants.BLANK_STRING.equalsIgnoreCase(receiptResponse.getErrorList().get(0).getErrorMMessag()) 
														&& !receiptResponse.getErrorList().get(0).getErrorMMessag().equalsIgnoreCase("-1")){
													flag2.setStrerrormsginproptag(receiptResponse.getErrorList().get(0).getErrorMMessag()); 
												}
												logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before Calling dbService.updatePmtFlowFlag in A6");
												dbService.updatePmtFlowFlag(flag2);
												logger.info("PDPN SCENARIO ID:: 2.5 :: UPDATED TABLE WITH PROPTAG = S, PDF = F");
												logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after Calling dbService.updatePmtFlowFlag in A6");
												
												if(policyNumber != null ){
													paymentDetails.setStrpolicyno(policyNumber);
													if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
														receiptNumber = dbService.getReceiptFromProposal(receptReq.getProposalDetails().getProposalNo());
														}
													
													if(receiptNumber != null){
													paymentDetails.setStrgcreceiptno(receiptNumber);
													}
													paymentDetails.setStrgcsubreceiptno("");
													
													if(flowFlags.getStrscreenrefno() != null ){
													setDataInPaymentDetails(paymentDetails,flowFlags.getStrscreenrefno());
													  }
													}
												
												CommunicationStatusFlag = true;
												logger.info("PDPN SCENARIO ID:: 2.6 :: COMM FLAG = TRUE");
											 }else if(receiptResponse != null && receiptResponse.getResultCode()!=null 
														&& receiptResponse.getResultCode().equalsIgnoreCase("0")
													    && receiptResponse.getErrorList() != null 
														&& !receiptResponse.getErrorList().isEmpty()
														&& receiptResponse.getErrorList().size() > 0 
														&& receiptResponse.getErrorList().get(0).getErrorMMessag() != null 
														&& !receiptResponse.getErrorList().get(0).getErrorMMessag().equalsIgnoreCase("-1") 
														&& receiptResponse.getErrorList().get(0).getErrorMMessag().toLowerCase().contains("Proposal No.".toLowerCase())
														&& receiptResponse.getErrorList().get(0).getErrorMMessag().toLowerCase().contains("Authorization Code already exists in the system.".toLowerCase())
														&& receiptResponse.getErrorList().get(0).getErrorMMessag().toLowerCase().contains(CommonConstants.PROPOSAL_TAGGING_CUM_POLICY_GEN.toLowerCase()))
											 {
												 
												 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> Failed >> ErrorCode 12 >> ErrorCode 52--> A6");
												 
													// DB Link code to get policy no
													
													if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
														logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before getPolicyNumFromProposalNo ABC2");
														String policyNoStr = getPolicyNoFromDbLink(receptReq.getProposalDetails().getProposalNo());
														logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after getPolicyNumFromProposalNo ABC2");
														if(policyNoStr != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(policyNoStr)){
															policyNumber = policyNoStr;
															logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in if ABC2");
														}else if(receiptResponse != null && receiptResponse.getPolicyNo() != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(receiptResponse.getPolicyNo()) ){
															policyNumber = receiptResponse.getPolicyNo();
															logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else if ABC2");
														}else{
															policyNumber = "";
															logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else ABC2");
														}
													}
												 
													PmtFlowFlags flag2 = new PmtFlowFlags();
													flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
													flag2.setStrproposaltaggingflag(CommonConstants.SUCCESS_VALUE);
													flag2.setStrpdfgenflag(CommonConstants.FAILURE_VALUE);
													flag2.setStrpolicyno(policyNumber == null? "":policyNumber);
													if(receiptResponse.getErrorList().get(0).getErrorMMessag() !=null && !receiptResponse.getErrorList().get(0).getErrorMMessag().equalsIgnoreCase("-1")){
																flag2.setStrerrormsginproptag(receiptResponse.getErrorList().get(0).getErrorMMessag()); 
															}
													logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before Calling dbService.updatePmtFlowFlag in A6");
													dbService.updatePmtFlowFlag(flag2);
													logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after Calling dbService.updatePmtFlowFlag in A6");
													
													if(policyNumber != null ){
														paymentDetails.setStrpolicyno(policyNumber);
														if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
															receiptNumber = dbService.getReceiptFromProposal(receptReq.getProposalDetails().getProposalNo());
															}
														
														if(receiptNumber != null){
														paymentDetails.setStrgcreceiptno(receiptNumber);
														}
														paymentDetails.setStrgcsubreceiptno("");
														
														if(flowFlags.getStrscreenrefno() != null ){
														setDataInPaymentDetails(paymentDetails,flowFlags.getStrscreenrefno());
														  }
														}
												
													CommunicationStatusFlag = true;
												 
											 }
											 else {
												 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: --> A7");
												 
												 if(receiptResponse != null && receiptResponse.getResultCode()!=null 
															&& receiptResponse.getResultCode().equalsIgnoreCase("0")
														    && receiptResponse.getErrorList() != null 
															&& !receiptResponse.getErrorList().isEmpty()
															&& receiptResponse.getErrorList().size() > 0 
															&& receiptResponse.getErrorList().get(0).getErrorMMessag() != null 
															&& !receiptResponse.getErrorList().get(0).getErrorMMessag().equalsIgnoreCase("-1") 
															&& receiptResponse.getErrorList().get(0).getErrorMMessag().toLowerCase().contains(CommonConstants.RECEIPT_ENTRY_FOR_BFL.toLowerCase())){
													 
													 
													 PmtFlowFlags flag2 = new PmtFlowFlags();
														flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
														flag2.setStrreceiptentryflag(CommonConstants.FAILURE_VALUE);
														flag2.setStrproposaltaggingflag(CommonConstants.FAILURE_VALUE);
														if(receiptResponse != null && receiptResponse.getErrorList() != null 
																&& !receiptResponse.getErrorList().isEmpty()
																&& receiptResponse.getErrorList().size() > 0 
																&& receiptResponse.getErrorList().get(0).getErrorMMessag() != null 
																&&  !CommonConstants.BLANK_STRING.equalsIgnoreCase(receiptResponse.getErrorList().get(0).getErrorMMessag()) 
																&& !receiptResponse.getErrorList().get(0).getErrorMMessag().equalsIgnoreCase("-1")){
																	flag2.setStrerrormsginreceiptBfl(receiptResponse.getErrorList().get(0).getErrorMMessag()); 
																}
														dbService.updatePmtFlowFlag(flag2);
														logger.info("Proposal Tag service failed as it is some other reason than error code 52");
													 
												 }else if(receiptResponse != null && receiptResponse.getResultCode()!=null 
															&& receiptResponse.getResultCode().equalsIgnoreCase("0")
														    && receiptResponse.getErrorList() != null 
															&& !receiptResponse.getErrorList().isEmpty()
															&& receiptResponse.getErrorList().size() > 0 
															&& receiptResponse.getErrorList().get(0).getErrorMMessag() != null 
															&& !receiptResponse.getErrorList().get(0).getErrorMMessag().equalsIgnoreCase("-1") 
															&& receiptResponse.getErrorList().get(0).getErrorMMessag().toLowerCase().contains(CommonConstants.PROPOSAL_TAGGING_CUM_POLICY_GEN.toLowerCase())){
													 PmtFlowFlags flag2 = new PmtFlowFlags();
														flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
														flag2.setStrreceiptentryflag(CommonConstants.SUCCESS_VALUE);
														flag2.setStrproposaltaggingflag(CommonConstants.FAILURE_VALUE);
														if(receiptResponse != null && receiptResponse.getErrorList() != null 
																&& !receiptResponse.getErrorList().isEmpty()
																&& receiptResponse.getErrorList().size() > 0 
																&& receiptResponse.getErrorList().get(0).getErrorMMessag() != null 
																&&  !CommonConstants.BLANK_STRING.equalsIgnoreCase(receiptResponse.getErrorList().get(0).getErrorMMessag()) 
																&& !receiptResponse.getErrorList().get(0).getErrorMMessag().equalsIgnoreCase("-1")){
																	flag2.setStrerrormsginpdfgen(receiptResponse.getErrorList().get(0).getErrorMMessag()); 
																}
														dbService.updatePmtFlowFlag(flag2);
														logger.info("Proposal Tag service failed as it is some other reason than error code 52");
													 
													 
												 }else{
													 logger.info("Something wents wrong");
												 }
										}
								}
						 }
						 
						//Check if Proposal No exists and Receipt Service is Success and Proposal Tagging service is failed
						 if (flowFlags.getStrproposalno() != null
						 && !CommonConstants.BLANK_STRING.equals(flowFlags.getStrproposalno())
						 && flowFlags.getStrreceiptentryflag() !=null
						 && !CommonConstants.BLANK_STRING.equals(flowFlags.getStrreceiptentryflag())
						 && flowFlags.getStrreceiptentryflag().equalsIgnoreCase(CommonConstants.SUCCESS_VALUE) 
						 && flowFlags.getStrproposaltaggingflag() != null
						 && flowFlags.getStrproposaltaggingflag().equalsIgnoreCase(CommonConstants.FAILURE_VALUE)) 
						 {
							 
							 String receiptNo="";
								logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Inside ProposalTagService Failure Loop --> A8");
								if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
								 receiptNo = dbService.getReceiptFromProposal(receptReq.getProposalDetails().getProposalNo());
								}
								if(receiptNo != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(receiptNo)){
								//ProposalTaggingHandler propTagHandler = new ProposalTaggingHandler();
								
								logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Before new AccountService_Service --> A8");
								AccountService_Service accService=new AccountService_Service(new URL(serviceURL));
								logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: After new AccountService_Service --> A8");
								logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before accService.getSOAPOverHTTP() --> A8");
								AccountService accServClient=accService.getSOAPOverHTTP();
								logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after accService.getSOAPOverHTTP() --> A8");
								
								logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before proposalTaggingServiceCall --> A8");
								
								responsePropTagService = propTagService.proposalTaggingServiceCall(receptReq, dbService, receiptNo, accServClient);
								logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after proposalTaggingServiceCall --> A8");
								
								if(responsePropTagService != null && responsePropTagService.getErrorCode()!=null 
										&& responsePropTagService.getErrorCode().equalsIgnoreCase("0") && responsePropTagService.getErrorMsg()!=null 
										&& responsePropTagService.getErrorMsg().equalsIgnoreCase("-1")){
									
									logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: ProposalTagService Response is a success --> A9");
									//Start:: set success flag for proposalTagService
									PmtFlowFlags flag2 = new PmtFlowFlags();
									
									flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
									flag2.setStrproposaltaggingflag(CommonConstants.SUCCESS_VALUE);
									flag2.setStrpdfgenflag(CommonConstants.FAILURE_VALUE);
									//flag2.setStrpolicygenreq(objMap.writeValueAsString(objUserDataPaymentTaging));
									flag2.setStrpolicyno(responsePropTagService.getPolicyNo() == null ? "":responsePropTagService.getPolicyNo());
									if(responsePropTagService != null && responsePropTagService.getErrorCode()!=null 
											&&  !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getErrorCode()) 
											&& responsePropTagService.getErrorMsg()!=null && !responsePropTagService.getErrorMsg().equalsIgnoreCase("-1")){
												flag2.setStrerrormsginproptag(responsePropTagService.getErrorMsg()+" Error Code : "+responsePropTagService.getErrorCode()); 
											}
									logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before updatePmtFlowFlag --> A9");
							        dbService.updatePmtFlowFlag(flag2);
							        logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: After updatePmtFlowFlag --> A9");
							        //End:: set success flag for proposalTagService
							        if(responsePropTagService.getPolicyNo() != null){
							        policyNumber = responsePropTagService.getPolicyNo();
							        }
							        if(receiptNo != null){
							        receiptNumber = receiptNo;
							        }
							        
							        if(policyNumber != null ){
										paymentDetails.setStrpolicyno(policyNumber);
										if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
											receiptNumber = dbService.getReceiptFromProposal(receptReq.getProposalDetails().getProposalNo());
											}
										
										if(receiptNumber != null){
										paymentDetails.setStrgcreceiptno(receiptNumber);
										}
										paymentDetails.setStrgcsubreceiptno("");
										
										if(flowFlags.getStrscreenrefno() != null ){
										setDataInPaymentDetails(paymentDetails,flowFlags.getStrscreenrefno());
										  }
										}
							        
							        CommunicationStatusFlag = true;
							 
						          }else {	
						      		logger.info(" Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler ::  --> A10");
									if(responsePropTagService != null  
										&& responsePropTagService.getErrorMsg()!=null 
										&& !responsePropTagService.getErrorMsg().equalsIgnoreCase("-1") 
										&& responsePropTagService.getErrorMsg().toLowerCase().contains("Proposal".toLowerCase())
										&& responsePropTagService.getErrorMsg().toLowerCase().contains("already tagged".toLowerCase())
										&&  responsePropTagService.getErrorMsg().toLowerCase().contains(CommonConstants.PROPOSAL_TAGGING_CUM_POLICY_GEN.toLowerCase()))
									 {
										// DB Link code to get policy no
										if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
											logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before getPolicyNumFromProposalNo ABC3");
											String policyNoStr = getPolicyNoFromDbLink(receptReq.getProposalDetails().getProposalNo());
											logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after getPolicyNumFromProposalNo ABC3");
											if(policyNoStr != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(policyNoStr)){
												policyNumber = policyNoStr;
												logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in if ABC3");
											}else if(responsePropTagService != null && responsePropTagService.getPolicyNo() != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getPolicyNo()) ){
												policyNumber = responsePropTagService.getPolicyNo();
												logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else if ABC3");
											}else{
												policyNumber = "";
												logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else ABC3");
											}
										}
										
										PmtFlowFlags flag2 = new PmtFlowFlags();
										flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
										flag2.setStrproposaltaggingflag(CommonConstants.SUCCESS_VALUE);
										flag2.setStrpdfgenflag(CommonConstants.FAILURE_VALUE);
										flag2.setStrpolicyno(policyNumber == null? "":policyNumber);
										if(responsePropTagService != null && responsePropTagService.getErrorCode()!=null 
												&&  !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getErrorCode()) 
												&& responsePropTagService.getErrorMsg()!=null && !responsePropTagService.getErrorMsg().equalsIgnoreCase("-1")){
													flag2.setStrerrormsginproptag(responsePropTagService.getErrorMsg()+" Error Code : "+responsePropTagService.getErrorCode()); 
												}
										logger.info(" Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler ::before updatePmtFlowFlag  --> A10");
										dbService.updatePmtFlowFlag(flag2);
										logger.info(" Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler ::after updatePmtFlowFlag --> A10");
										
										if(flowFlags.getStrreceiptno() != null){
							            receiptNumber = flowFlags.getStrreceiptno();
										}
										
										if(policyNumber != null ){
											paymentDetails.setStrpolicyno(policyNumber);
											if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
												receiptNumber = dbService.getReceiptFromProposal(receptReq.getProposalDetails().getProposalNo());
												}
											
											if(receiptNumber != null){
											paymentDetails.setStrgcreceiptno(receiptNumber);
											}
											paymentDetails.setStrgcsubreceiptno("");
											
											if(flowFlags.getStrscreenrefno() != null ){
											setDataInPaymentDetails(paymentDetails,flowFlags.getStrscreenrefno());
											  }
											}
										CommunicationStatusFlag = true;
									 }else if(responsePropTagService != null
												&& responsePropTagService.getErrorMsg()!=null 
												&& !responsePropTagService.getErrorMsg().equalsIgnoreCase("-1") 
												&& responsePropTagService.getErrorMsg().toLowerCase().contains("Proposal No.".toLowerCase())
												&& responsePropTagService.getErrorMsg().toLowerCase().contains("Authorization Code already exists in the system.".toLowerCase())
												&& responsePropTagService.getErrorMsg().toLowerCase().contains(CommonConstants.PROPOSAL_TAGGING_CUM_POLICY_GEN.toLowerCase())){
										 
										 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: Receipt Entry >> Failed >> ErrorCode 12 >> ErrorCode 52--> A6");
										 
											// DB Link code to get policy no
											
											if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
												logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before getPolicyNumFromProposalNo ABC4");
												String policyNoStr = getPolicyNoFromDbLink(receptReq.getProposalDetails().getProposalNo());
												logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after getPolicyNumFromProposalNo ABC4");
												if(policyNoStr != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(policyNoStr)){
													policyNumber = policyNoStr;
													logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in if ABC4");
												}else if(responsePropTagService != null && responsePropTagService.getPolicyNo() != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getPolicyNo()) ){
													policyNumber = responsePropTagService.getPolicyNo();
													logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else if ABC4");
												}else{
													policyNumber = "";
													logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else ABC4");
												}
											}
											
											PmtFlowFlags flag2 = new PmtFlowFlags();
											flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
											flag2.setStrproposaltaggingflag(CommonConstants.SUCCESS_VALUE);
											flag2.setStrpdfgenflag(CommonConstants.FAILURE_VALUE);
											flag2.setStrpolicyno(policyNumber == null? "":policyNumber);
											if(responsePropTagService != null && responsePropTagService.getErrorCode()!=null 
													&&  !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getErrorCode()) 
													&& responsePropTagService.getErrorMsg()!=null && !responsePropTagService.getErrorMsg().equalsIgnoreCase("-1")){
														flag2.setStrerrormsginproptag(responsePropTagService.getErrorMsg()+" Error Code : "+responsePropTagService.getErrorCode()); 
													}
											logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before Calling dbService.updatePmtFlowFlag in A6");
											dbService.updatePmtFlowFlag(flag2);
											logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after Calling dbService.updatePmtFlowFlag in A6");
											
											
											if(policyNumber != null ){
												paymentDetails.setStrpolicyno(policyNumber);
												if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
													receiptNumber = dbService.getReceiptFromProposal(receptReq.getProposalDetails().getProposalNo());
													}
												
												if(receiptNumber != null){
												paymentDetails.setStrgcreceiptno(receiptNumber);
												}
												paymentDetails.setStrgcsubreceiptno("");
												
												if(flowFlags.getStrscreenrefno() != null ){
												setDataInPaymentDetails(paymentDetails,flowFlags.getStrscreenrefno());
												  }
												}
								
											CommunicationStatusFlag = true;
										 
									 }else 
									 {
										logger.info(" Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler ::  --> A11");
										PmtFlowFlags flag2 = new PmtFlowFlags();
										flag2.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
										flag2.setStrproposaltaggingflag(CommonConstants.FAILURE_VALUE);
										if(responsePropTagService != null && responsePropTagService.getErrorCode()!=null 
										&&  !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getErrorCode()) 
										&& responsePropTagService.getErrorMsg()!=null && !responsePropTagService.getErrorMsg().equalsIgnoreCase("-1")){
											flag2.setStrerrormsginproptag(responsePropTagService.getErrorMsg()+" Error Code : "+responsePropTagService.getErrorCode()); 
										}
										logger.info(" Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before updatePmtFlowFlag--> A11");
										dbService.updatePmtFlowFlag(flag2);
										logger.info(" Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after updatePmtFlowFlag--> A11");
										logger.info("Proposal Tag service failed as it is some other reason than error code 52");
									 }
								}
						     }
						 }
						 
						 
						//if receipt and proposaltag flags are success and PDf flag is F

						 if(flowFlags.getStrproposalno() != null
						 && !CommonConstants.BLANK_STRING.equals(flowFlags.getStrproposalno())
						 && flowFlags.getStrreceiptentryflag() !=null
						 && !CommonConstants.BLANK_STRING.equals(flowFlags.getStrreceiptentryflag())
						 && flowFlags.getStrreceiptentryflag().equalsIgnoreCase(CommonConstants.SUCCESS_VALUE) 
						 && flowFlags.getStrproposaltaggingflag() != null
						 && flowFlags.getStrproposaltaggingflag().equalsIgnoreCase(CommonConstants.SUCCESS_VALUE)
						 && flowFlags.getStrpdfgenflag().equalsIgnoreCase(CommonConstants.FAILURE_VALUE)){
						  logger.info(" Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler ::  Inside PDF failure --> A12");
						  
						  
						  if(receptReq != null && receptReq.getProposalDetails() != null && receptReq.getProposalDetails().getProposalNo() != null){
								
							    logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before getPolicyNoFromDbLink ABC3");
							    String policyNoStr = getPolicyNoFromDbLink(receptReq.getProposalDetails().getProposalNo());
								logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after getPolicyNumFromProposalNo ABC3");
								 
								if(policyNoStr != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(policyNoStr)){
									policyNumber = policyNoStr;
									logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in if ABC3");
								}else if(responsePropTagService != null && responsePropTagService.getPolicyNo() != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(responsePropTagService.getPolicyNo()) ){
									policyNumber = responsePropTagService.getPolicyNo();
									logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else if ABC3");
								}else{
									policyNumber = "";
									logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: getPolicyNumFromProposalNo in else ABC3");
								}
							}
						  if(flowFlags.getStrreceiptno() != null){
					         receiptNumber = flowFlags.getStrreceiptno();
							}
						  
						  PmtFlowFlags flags = new PmtFlowFlags();
						  flags.setStrpolicyno(policyNumber);
						  flags.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
						  logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: before Calling dbService.updatePmtFlowFlag in A6");
						  dbService.updatePmtFlowFlag(flags);
						  logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after Calling dbService.updatePmtFlowFlag in A6");

						  CommunicationStatusFlag = true;
						  
						 }
						 
						 
						 
						//Send Communication if receipt and proposal tag services run Successfully	 
						 if(CommunicationStatusFlag == true && policyNumber != null && !CommonConstants.BLANK_STRING.equalsIgnoreCase(policyNumber))
						 {
						 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued :: Sending Communication Started");
						 if(receptReq.getIsCoverNoteProposal().equalsIgnoreCase(CommonConstants.FAILURE_STATUS)) 
						 {
						 	//Sending mail and SMS to customer
						 	if(email!=null && !"".equals(email)) {
						 		try{
						 			 logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued :: trying email sending to customer--->>"+email);
						 			CommunicationRequest commRequest = new CommunicationRequest();
						 			EmailAttachment attachment = new EmailAttachment();
						 			commRequest.setAlertType(CommonConstants.SEND_EMAIL);
						 			commRequest.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS);
						 			commRequest.setReceipient(email+",dinesh.tcs@tataaig.com");	//Email
						 			commRequest.setParam1(receptReq.getProposalDetails().getCustomerName());
						 			commRequest.setParam2(policyNumber == null ? "":policyNumber);
						 			commRequest.setParam3(receptReq.getProposalDetails().getProductLine()== null ?"":receptReq.getProposalDetails().getProductLine());
						 			commRequest.setParam4(receptReq.getProposalDetails().getPlanName()== null ?"NA":receptReq.getProposalDetails().getPlanName());
						 			commRequest.setParam5(strTotalAmtPartPayment == null ? "":strTotalAmtPartPayment);
						 			commRequest.setParam6(receptReq.getProducerName());
						 			commRequest.setParam7(receptReq.getProducerCode());
						 			commRequest.setParam8(receptReq.getProposalDetails().getPolicyEffDt()== null ?"":receptReq.getProposalDetails().getPolicyEffDt());	// Policy inception date
						 			commRequest.setParam9(receptReq.getProposalDetails().getPolicyEndDt()== null ?"":receptReq.getProposalDetails().getPolicyEndDt());	// Policy expiration date
						 			commRequest.setParam10(orderId); 
						 			commRequest.setParam11(transRefNo == null ? "":transRefNo);	
						 			commRequest.setParam12(receptReq.getProposalDetails().getCustomerName());
						 			//commRequest.setParam13(accountServReq.getProposalDetails().getProposalAmount());
						 			commRequest.setParam13(strTotalAmtPartPayment == null ? "":strTotalAmtPartPayment); //Start:15/04/2017:Changes done to set only the part payment amount as suggested by TAGIC
						 			commRequest.setParam14(policyNumber == null ? "":policyNumber);
						 			commRequest.setParam15(receptReq.getProducerName());
						 			commRequest.setParam16(receptReq.getProducerMobile()==null ?"1800 - 266 - 7780":receptReq.getProducerMobile()); 
						 			
						 			attachment.setPolicyNumber(policyNumber == null ? "":policyNumber);
						 			attachment.setProposalNumber(receptReq.getProposalDetails().getProposalNo());
						 			attachment.setProductCode(receptReq.getProposalDetails().getProductCode());
						 			attachment.setProposalDate(receptReq.getProposalDetails().getProposalDate());
						 			attachment.setReceiptNo(receiptNumber == null ? "":receiptNumber);
						 			commRequest.setEmailAttachment(attachment);
						 			commRequest.setUserID(receptReq.getUserID());
						 			commRequest.setPassword(receptReq.getPassword()==null?"":receptReq.getPassword());
						 			commRequest.setProductCode(receptReq.getProposalDetails().getProductCode());
						 			commRequest.setProducerEmail(receptReq.getProducerEmail());
						 			//commService.sendCommunication(commRequest);
						 			customerEmailSuccess = tagicCommLite.sendCommunication(commRequest);
						 			logger.info("In paymentDonePolicyNotIssued Scheduler :: Mail sent successfully to "+email);
						 		}
						 		catch(Exception e){
						 			e.printStackTrace();
						 		}
						 	}
						 			    				
						 	if (mobile!=null && !mobile.equals("")){
						 		try{
						 			logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued :: trying Customer SMS -->>"+mobile);
						 			//Start: changes done to set values for sms in fresh instance
						 			CommunicationRequest commRequestSMS = new CommunicationRequest();
						 			//End: changes done to set values for sms in fresh instance
						 			
						 			commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
						 			commRequestSMS.setEventType(CommonConstants.EVENT_PAYMENT_SUCCESS);
						 			commRequestSMS.setReceipient(mobile);
						 			commRequestSMS.setParam1(receptReq.getProposalDetails().getCustomerName());
						 			commRequestSMS.setParam2(strTotalAmtPartPayment == null ? "":strTotalAmtPartPayment);
						 			commRequestSMS.setParam3(policyNumber == null ? "":policyNumber);
						 			commRequestSMS.setParam4(email);
						 			commRequestSMS.setParam5(receptReq.getProducerName());
						 			commRequestSMS.setParam6(receptReq.getProducerMobile()==null ?"1800 - 266 - 7780":receptReq.getProducerMobile()); 
						 			//commService.sendCommunication(commRequestSMS);
						 			customerSMSSuccess = tagicCommLite.sendCommunication(commRequestSMS);
						 			logger.info("In paymentDonePolicyNotIssued Scheduler :: SMS sent successfully to "+mobile);
						 		}
						 		catch(Exception e){
						 			e.printStackTrace();
						 		}
						 		
						 	}
						 	
						 }
						 			    			  
						   // Mail and SMS for covernote cases
						 else if(receptReq.getIsCoverNoteProposal()!=null && receptReq.getIsCoverNoteProposal().equalsIgnoreCase(CommonConstants.SUCCESS_VALUE)) {
						 	  if (email!=null && !email.equals("")){
						 			try{
						 				CommunicationRequest commRequest = new CommunicationRequest();
						 				EmailAttachment attachment = new EmailAttachment();
						 				commRequest.setAlertType(CommonConstants.SEND_EMAIL);
						 				commRequest.setEventType(CommonConstants.EVENT_OFFLINE_COVERNOTE_PAYMENT_SUCCESS);
						 				commRequest.setReceipient(email);	//Email
						 				commRequest.setParam1(receptReq.getProposalDetails().getCustomerName());
						 				commRequest.setParam2("-");	// cover note number
						 				commRequest.setParam3(receptReq.getProposalDetails().getProductLine()== null ?"":receptReq.getProposalDetails().getProductLine());
						 				commRequest.setParam4(strTotalAmtPartPayment == null ? "":strTotalAmtPartPayment);
						 				commRequest.setParam5(receptReq.getProposalDetails().getCustomerName());
						 				commRequest.setParam6(strTotalAmtPartPayment == null ? "":strTotalAmtPartPayment);
						 				commRequest.setParam7("-");	// cover note number
						 				commRequest.setParam8(receptReq.getProducerName());
						 				commRequest.setParam9(receptReq.getProducerMobile()==null ?"-":receptReq.getProducerMobile()); 
						 				
						 				attachment.setPolicyNumber(policyNumber  == null ? "":policyNumber);
						 				attachment.setProposalNumber(receptReq.getProposalDetails().getProposalNo());
						 				attachment.setProductCode(receptReq.getProposalDetails().getProductCode());
						 				attachment.setProposalDate(receptReq.getProposalDetails().getProposalDate());
						 				attachment.setReceiptNo(receiptNumber == null ? "":receiptNumber);
						 				commRequest.setEmailAttachment(attachment);
						 				commRequest.setUserID(receptReq.getUserID());
						 				commRequest.setPassword(receptReq.getPassword());
						 				commRequest.setProductCode(receptReq.getProposalDetails().getProductCode());
						 				commRequest.setProducerEmail(receptReq.getProducerEmail());
						 				tagicCommLite.sendCommunication(commRequest);
						 				logger.info("In paymentDonePolicyNotIssued Scheduler :: covernote Mail sent successfully to "+email);
						 			}
						 			catch(Exception e){
						 				e.printStackTrace();
						 			}
						 		}
						 		
						 		if (mobile!=null && !mobile.equals("")){
						 			try{
						 				//Start: changes done to set values for sms in fresh instance
						 				CommunicationRequest commRequestSMS = new CommunicationRequest();
						 				//End: changes done to set values for sms in fresh instance
						 				
						 				commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
						 				commRequestSMS.setEventType(CommonConstants.EVENT_OFFLINE_COVERNOTE_PAYMENT_SUCCESS);
						 				commRequestSMS.setReceipient(mobile);
						 				commRequestSMS.setParam1(receptReq.getProposalDetails().getCustomerName());
						 				commRequestSMS.setParam2(strTotalAmtPartPayment  == null ? "":strTotalAmtPartPayment);
						 				commRequestSMS.setParam3("-");	// cover note number
						 				commRequestSMS.setParam4(receptReq.getProducerName()==null?"-":receptReq.getProducerName());
						 				commRequestSMS.setParam5(receptReq.getProducerMobile()==null ?"1800 - 266 - 7780":receptReq.getProducerMobile());
						 				tagicCommLite.sendCommunication(commRequestSMS);
						 				logger.info("In paymentDonePolicyNotIssued Scheduler :: covernote sms sent successfully to "+mobile);
						 			}
						 			catch(Exception e){
						 				e.printStackTrace();
						 			}
						 		  }
						 		}
						 			    			
						 	// Start::Setting final status as S after sending communication	

						 logger.info("Inside paymentDonePolicyNotIssued scheduler:: Setting final and pdf status in PMT flow table");
						 PmtFlowFlags  flags = new PmtFlowFlags();
						 flags.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
						 flags.setStrpdfgenflag(CommonConstants.FAILURE_VALUE);
						 flags.setStrfinalstatus(CommonConstants.FAILURE_VALUE);
						 dbService.updatePmtFlowFlag(flags);
						 
						 if(email != null && CommonConstants.PDF_FAILURE.equalsIgnoreCase(customerEmailSuccess)){
							 logger.info("Inside paymentDonePolicyNotIssued scheduler:: inside pdf failure");
							 flags.setStrerrormsginpdfgen("Error while pdf generation.");
							 logger.info("Inside paymentDonePolicyNotIssued scheduler:: after pdf failure");
						 }
						 

						 //if both email and sms are null
						 if((mobile==null || mobile.equals("")) && (email==null || email.equals("")))
						 { 
						 	//PmtFlowFlags  flags = new PmtFlowFlags();
							 logger.info(" Inside paymentDonePolicyNotIssued scheduler ::  Both Mobile and Email are null");
						 	flags.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
						 	flags.setStrpdfgenflag(CommonConstants.SUCCESS_VALUE);
						 	flags.setStrfinalstatus(CommonConstants.SUCCESS_VALUE);
						 	dbService.updatePmtFlowFlag(flags);
						 	
						 }

						 //if email is null
						 if(email==null || "".equals(email)){
						 	if(mobile!=null || !"".equals(mobile)) {
						 		if(CommonConstants.SMS_SUCCESS.equalsIgnoreCase(customerSMSSuccess)) {
						 			//PmtFlowFlags  flags = new PmtFlowFlags();
						 			logger.info(" Inside paymentDonePolicyNotIssued scheduler ::  Email is null, Mobile is not null");
						 			flags.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
						 			flags.setStrpdfgenflag(CommonConstants.SUCCESS_VALUE);
						 			flags.setStrfinalstatus(CommonConstants.SUCCESS_VALUE);
						 			dbService.updatePmtFlowFlag(flags);
						 			 
						 		}
						 	}
						 }

						 //if mobileno is null
						 if(mobile==null || "".equals(mobile)){
						 	if(email!=null || !"".equals(email)) {
						 		if(CommonConstants.PDF_SUCCESS.equalsIgnoreCase(customerEmailSuccess)) {
						 			//PmtFlowFlags  flags = new PmtFlowFlags();
						 			 logger.info(" Inside paymentDonePolicyNotIssued scheduler ::  Mobile is null, Email is not null");
						 			flags.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
						 			flags.setStrpdfgenflag(CommonConstants.SUCCESS_VALUE);
						 			flags.setStrfinalstatus(CommonConstants.SUCCESS_VALUE);
						 			dbService.updatePmtFlowFlag(flags);
						 			
						 		}
						 	}
						 }

						 //if both are not null
						 if((email!=null || !"".equals(email)) && (mobile!=null || !"".equals(mobile)) ) {
						 	if(CommonConstants.PDF_SUCCESS.equalsIgnoreCase(customerEmailSuccess) && CommonConstants.SMS_SUCCESS.equalsIgnoreCase(customerSMSSuccess)) {
						 		//PmtFlowFlags  flags = new PmtFlowFlags();
						 		 logger.info(" Inside paymentDonePolicyNotIssued scheduler ::  Email and Mobile are not null");
						 		flags.setStrproposalno(receptReq.getProposalDetails().getProposalNo());
						 		flags.setStrpdfgenflag(CommonConstants.SUCCESS_VALUE);
						 		flags.setStrfinalstatus(CommonConstants.SUCCESS_VALUE);
						 		dbService.updatePmtFlowFlag(flags);
						 		
						 	}
						 	
						 }
						 
						
						 
						 
						 //End :: Setting final status as S after sending communication	
						 		
						 }
					 	
						 logger.info(" Inside paymentDonePolicyNotIssued scheduler ::  ENDED"); 
						 
						}
					}
				}
	     }
		}
	   }
	
	
    public void  setDataInPaymentDetails(PaymentDetails payDtlsTrans, String scrrenRefNo){
    	
     	logger.info(" Inside setDataInPaymentDetails  ::  Started");
    	ReceiptCumPolicyRequest accountServReq =null;
    	Gson gson = new Gson();
    	
    	try{
    	HashMap<String,String> resultAccService = new HashMap<String,String>();
    	logger.info(" Inside setDataInPaymentDetails getBilldeskStgDtl::  before"); 
		resultAccService = (HashMap<String,String>)dbService.getBilldeskStgDtl("com.majesco.dcf.common.tagic.entity.OnlineAccountService","strOrderID",scrrenRefNo);
		logger.info(" Inside setDataInPaymentDetails  getBilldeskStgDtl ::  after"); 
		String strJsonObj = (String) resultAccService.get("func_get_online_acc_service_dtl")==null?"":resultAccService.get("func_get_online_acc_service_dtl");
		accountServReq = gson.fromJson(strJsonObj, ReceiptCumPolicyRequest.class);
		
		logger.info(" Inside setDataInPaymentDetails  getBilldeskStgDtl ::  AA1");
		
		if (accountServReq!=null && accountServReq.getProposalDetails()!=null ){
			{

				logger.info(" Inside setDataInPaymentDetails  getBilldeskStgDtl ::  AA2");
				for (ReceiptPaymentDetails paymentDtl: accountServReq.getPaymentDetails()){
		
		String instrumentDt = "";
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		//instrumentDt=paymentDtl.getInstrumentDate();
		if(instrumentDt==null || instrumentDt.equalsIgnoreCase(CommonConstants.BLANK_STRING))
			instrumentDt=sdf.format(new Date());
		payDtlsTrans.setStrpaymentinstrumentdt(sdf.parse(instrumentDt));
		payDtlsTrans.setStrinstrumentno(paymentDtl.getInstrumentNo()!=null?paymentDtl.getInstrumentNo():"");
		payDtlsTrans.setStripaddress(accountServReq.getSystemIPAddress()!=null?accountServReq.getSystemIPAddress():"");
		payDtlsTrans.setStrpaymentmode(paymentDtl.getPaymentType()!=null?paymentDtl.getPaymentType():"");
		payDtlsTrans.setStrpaymentamount(paymentDtl.getPaymentAmount()!=null?paymentDtl.getPaymentAmount():"");
		//payDtlsTrans.setStrpolicyno(receiptResponse.getPolicyNo()!=null?receiptResponse.getPolicyNo():"");
		//payDtlsTrans.setStrgcreceiptno(receiptResponse.getReceiptDtls().getReceiptNo()!=null?receiptResponse.getReceiptDtls().getReceiptNo():"");
		//payDtlsTrans.setStrgcsubreceiptno(receiptResponse.getReceiptDtls().getSubReceiptId()!=null?receiptResponse.getReceiptDtls().getSubReceiptId():"");
		if(accountServReq.getProposalDetails()!=null)
		{
			payDtlsTrans.setStrproposalno(accountServReq.getProposalDetails().getProposalNo()!=null?accountServReq.getProposalDetails().getProposalNo():"");
			payDtlsTrans.setStrcustid(accountServReq.getProposalDetails().getCustomerId()!=null?accountServReq.getProposalDetails().getCustomerId():"");
			payDtlsTrans.setStrbalanceamt(accountServReq.getProposalDetails().getBalanceAmount()!=null?accountServReq.getProposalDetails().getBalanceAmount():"");
			payDtlsTrans.setStrworkflowid(accountServReq.getProposalDetails().getProposalSystemId()!=null?accountServReq.getProposalDetails().getProposalSystemId():"");
			
			if(accountServReq.getProposalDetails().getPolicyEffDt()!=null && !accountServReq.getProposalDetails().getPolicyEffDt().equals(""))
				payDtlsTrans.setStrpolicystartdt(sdf.parse(accountServReq.getProposalDetails().getPolicyEffDt()));
			else
				payDtlsTrans.setStrpolicystartdt(null);
			
			if(accountServReq.getProposalDetails().getPolicyEndDt()!=null && !accountServReq.getProposalDetails().getPolicyEndDt().equals(""))
				payDtlsTrans.setStrpolicyenddt(sdf.parse(accountServReq.getProposalDetails().getPolicyEndDt()));
			else
				payDtlsTrans.setStrpolicyenddt(null);
			
			payDtlsTrans.setStrproductcd(accountServReq.getProposalDetails().getProductCode()!=null?accountServReq.getProposalDetails().getProductCode():"");
			payDtlsTrans.setStrproducercd(accountServReq.getProducerCode()!=null?accountServReq.getProducerCode():"");
			payDtlsTrans.setStrcreatedby(accountServReq.getProducerName()!=null?accountServReq.getProducerName():"");
			payDtlsTrans.setDtcreated(new Date());
			payDtlsTrans.setStrbusinessLocation(accountServReq.getProposalDetails().getBusinessLocation()!=null?accountServReq.getProposalDetails().getBusinessLocation():"");
			payDtlsTrans.setStrdepositofficecode(accountServReq.getProposalDetails().getDepositOfficeCode()!=null?accountServReq.getProposalDetails().getDepositOfficeCode():"");
			payDtlsTrans.setStrbusslocname(accountServReq.getProposalDetails().getBussLocName()!=null?accountServReq.getProposalDetails().getBussLocName():"");
			payDtlsTrans.setStrnewrenewflag(accountServReq.getStrnewrenewflag()!=null?accountServReq.getStrnewrenewflag():""); // internal issues to save renewal flag in PaymentDetails. : Vishal J | 11-08-2017
		}
		if (paymentDtl!=null && paymentDtl.getPaymentType().contains("SPL")){	// 2027| RahulT| condition modified for SPL+AD
			//dbService.updatePaymentDetailForSPL(payDtlsTrans);
			dbService.saveOrUpdate(payDtlsTrans);
			logger.info("Updated or Saved In Payment Details from CPI Schedular>>>>>>>>>>");
		}
		else{
			dbService.saveOrUpdate(payDtlsTrans);
			logger.info("Updated or Saved In Payment Details from CPI Schedular>>>>>>>>>>");
		}
	}
			
		
	}
}
	
    	}catch(Exception e){
    		logger.info("In setDataInPaymentDetails() ::  Excpetion in CPI Schedular while updating self_pay_trans and pg_transaction in DB "+ e);
    	}
	
   }
	
    
    
    public String getPolicyNoFromDbLink(String proposalNo){
    	
    	logger.info(" Inside getPolicyNoFromDbLink  ::  Started ABC 22");
    	String policyNoStr = "";
    	try{
    	
    	List policyNoStrList = dbService.getPolicyProcFromProposal(proposalNo);
		
		if(policyNoStrList!=null)
		{

		Iterator excPolicyItr = policyNoStrList.iterator();
		
			HashMap<String, String> resultMap =new HashMap<String, String>();
			
			while(excPolicyItr.hasNext())
			{
				resultMap=(HashMap<String, String>)excPolicyItr.next();
                DBLinkPolicyDetails dbLinkPolicyDetails = new DBLinkPolicyDetails();
				
				if(resultMap!=null)
				{
					dbLinkPolicyDetails.setPolicyNo(resultMap.get(CommonConstants.STRING_TXT_POLICY_NO_CHAR));
					dbLinkPolicyDetails.setPolicStatus(resultMap.get(CommonConstants.STRING_STATUS));
					dbLinkPolicyDetails.setStatus(resultMap.get(CommonConstants.STRING_ACTIVE_FLAG));
					
					if(dbLinkPolicyDetails.getPolicyNo() != null && dbLinkPolicyDetails.getPolicStatus() != null 
							&& dbLinkPolicyDetails.getStatus() != null){
						if((dbLinkPolicyDetails.getPolicStatus().trim().equalsIgnoreCase(CommonConstants.POLICY_STATUS_RC) || 
								dbLinkPolicyDetails.getPolicStatus().trim().equalsIgnoreCase(CommonConstants.POLICY_STATUS_NC)) && 
								(dbLinkPolicyDetails.getStatus().trim().equalsIgnoreCase(CommonConstants.POLICY_ACTIVE_STATUS) ||
								dbLinkPolicyDetails.getStatus().trim().equalsIgnoreCase(CommonConstants.POLICY_INACTIVE_STATUS))){
							
							
							policyNoStr = dbLinkPolicyDetails.getPolicyNo();
						}
					}
				}
			}
		}
		
		
		logger.info("Inside paymentSchedulerForSuccessPaymentPolicyNotIssued scheduler :: after getPolicyNoFromDbLink ABC 22");
		 
    	}catch(Exception e){
    		logger.info("In setDataInPaymentDetails() ::  Excpetion  while getPolicyProcFromProposal in DB "+ e);
    	}
		
		return policyNoStr;
    	   	
    }
	
	
}
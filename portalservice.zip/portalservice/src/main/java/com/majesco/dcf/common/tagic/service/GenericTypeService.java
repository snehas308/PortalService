package com.majesco.dcf.common.tagic.service;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public interface GenericTypeService {

	final static Logger logger = Logger.getLogger(GenericTypeService.class);

	public <T> T getObject(Class<T> clazz) throws Exception; 
	
	/*public void methodin(String methodname){
		
		logger.info("Inside Method In ::" +methodname);
	}
	
	public void methodout(String methodname){
		
		logger.info("Outside Method In ::" +methodname);
		
	}*/

	
}//end of class

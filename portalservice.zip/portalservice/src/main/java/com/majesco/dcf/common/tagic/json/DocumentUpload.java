package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include= JsonSerialize.Inclusion.NON_EMPTY)
public class DocumentUpload
{
  private Long docType;
  private String docName;
  private String version;
  private String remarks;
  private String file;
  private boolean hardCopy;
  private String docKey;
  private String actionFlag;
  private String errorMsg;
  private String docIndex;
  private String fileSize;
  private String fileType;
  private String fileName;
  private boolean isMandatory;
  private String fileExtension;
  private String fileSrc;
  
  public Long getDocType()
  {
    return this.docType;
  }
  
  public void setDocType(Long docType)
  {
    this.docType = docType;
  }
  
  public String getDocName()
  {
    return this.docName;
  }
  
  public void setDocName(String docName)
  {
    this.docName = docName;
  }
  
  public String getVersion()
  {
    return this.version;
  }
  
  public void setVersion(String version)
  {
    this.version = version;
  }
  
  public String getRemarks()
  {
    return this.remarks;
  }
  
  public void setRemarks(String remarks)
  {
    this.remarks = remarks;
  }
  
  public String getFile()
  {
    return this.file;
  }
  
  public void setFile(String file)
  {
    this.file = file;
  }
  
  public boolean getHardCopy()
  {
    return this.hardCopy;
  }
  
  public void setHardCopy(boolean hardCopy)
  {
    this.hardCopy = hardCopy;
  }
  
  public String getDocKey()
  {
    return this.docKey;
  }
  
  public void setDocKey(String docKey)
  {
    this.docKey = docKey;
  }
  
  public String getActionFlag()
  {
    return this.actionFlag;
  }
  
  public void setActionFlag(String actionFlag)
  {
    this.actionFlag = actionFlag;
  }
  
  public String getErrorMsg()
  {
    return this.errorMsg;
  }
  
  public void setErrorMsg(String errorMsg)
  {
    this.errorMsg = errorMsg;
  }
  
  public String getFileSize()
  {
    return this.fileSize;
  }
  
  public void setFileSize(String fileSize)
  {
    this.fileSize = fileSize;
  }
  
  public String getFileType()
  {
    return this.fileType;
  }
  
  public void setFileType(String fileType)
  {
    this.fileType = fileType;
  }
  
  public String getFileName()
  {
    return this.fileName;
  }
  
  public void setFileName(String fileName)
  {
    this.fileName = fileName;
  }
  
  public boolean getIsMandatory()
  {
    return this.isMandatory;
  }
  
  public void setIsMandatory(boolean isMandatory)
  {
    this.isMandatory = isMandatory;
  }
  
  public String getFileExtension()
  {
    return this.fileExtension;
  }
  
  public void setFileExtension(String fileExtension)
  {
    this.fileExtension = fileExtension;
  }
  
  public String getDocIndex()
  {
    return this.docIndex;
  }
  
  public void setDocIndex(String docIndex)
  {
    this.docIndex = docIndex;
  }
  
  public String getFileSrc()
  {
    return this.fileSrc;
  }
  
  public void setFileSrc(String fileSrc)
  {
    this.fileSrc = fileSrc;
  }
}
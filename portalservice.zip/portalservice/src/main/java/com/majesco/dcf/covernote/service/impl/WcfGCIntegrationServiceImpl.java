package com.majesco.dcf.covernote.service.impl;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import javax.xml.namespace.QName;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.covernote.json.CNFlagProposalResponse;
import com.majesco.dcf.covernote.json.CheckCNFlagForProposal;
import com.majesco.dcf.covernote.json.PendingCoverNoteRequest;
import com.majesco.dcf.covernote.json.PendingCoverNoteResponse;
import com.majesco.dcf.covernote.json.SearchCoverNoteForPropRequest;
import com.majesco.dcf.covernote.json.SearchCoverNoteForPropResponse;
import com.majesco.dcf.covernote.service.WcfGCIntegrationService;
import com.unotechsoft.stub.commonservice.wcfgcintegration.ArrayOfclsManualCoverNoteGrid;
import com.unotechsoft.stub.commonservice.wcfgcintegration.ArrayOfclsPendingOCNForPortalGrid;
import com.unotechsoft.stub.commonservice.wcfgcintegration.ClsManualCoverNoteGrid;
import com.unotechsoft.stub.commonservice.wcfgcintegration.ClsPendingOCNForPortalGrid;
import com.unotechsoft.stub.commonservice.wcfgcintegration.WcfGCIntegrationGateway;
import com.unotechsoft.stub.commonservice.wcfgcintegration.WcfGCIntegrationGateway_Service;
import com.unotechsoft.stub.genericservice.client.ArrayOfKeyValuePairList;
import com.unotechsoft.stub.genericservice.client.GenericSerive;
import com.unotechsoft.stub.genericservice.client.GenericSerive_Service;
import com.unotechsoft.stub.genericservice.client.KeyValuePairList;

@Service
@Transactional
public class WcfGCIntegrationServiceImpl implements WcfGCIntegrationService {
	
	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/

	@Autowired
	DBService dbserv;
	
	private String propValue;
	final static Logger logger = Logger.getLogger(WcfGCIntegrationServiceImpl.class);
	
	private String getWSDLURL(String param)
	{
		try
		{
			propValue = dbserv.getWSDLURL(param,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			return propValue;
		}
		catch(Exception ae)
		{
			logger.error("Inside WcfGCIntegrationServiceImpl :: getWSDLURL() method ::",ae);
		}
		return propValue;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public SearchCoverNoteForPropResponse searchUniqueCoverNote(SearchCoverNoteForPropRequest getCoverNoteReq) throws Exception {
		String strMethodName="searchUniqueCoverNote";
		SearchCoverNoteForPropResponse coverNoteResponse = null;
		ObjectMapper objMapper = new ObjectMapper();
		//Start:20/04/2017:PROD_ISSUE:Modified as suggested by TAGIC, different service needs to be invoked to get covernote no.
		//QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/WcfGCIntegrationGateway/", "WcfGCIntegrationGateway");
		//End:20/04/2017:PROD_ISSUE:Modified as suggested by TAGIC, different service needs to be invoked to get covernote no.
		QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/GenericSerive/", "GenericSerive");
		try{
			
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered :: JSON object--> "+objMapper.writeValueAsString(getCoverNoteReq));
			//Start:20/04/2017:PROD_ISSUE:Modified as suggested by TAGIC, different service needs to be invoked to get covernote no.
			/*String serviceUrl=getWSDLURL(CommonConstants.WCF_GC_INTEGRATION_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			WcfGCIntegrationGateway_Service coverNoteService=new WcfGCIntegrationGateway_Service(wsdlUrl);
			WcfGCIntegrationGateway port=coverNoteService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);
			
			String _coverNote_source = smc_source;
	        String _coverNote_medium = smc_medium;
	        String _coverNote_campaingn = smc_campaign;
	        String _coverNote_strLVTokenID = "";
	        if(getCoverNoteReq!=null && getCoverNoteReq.getAuthToken()!=null)
	        	_coverNote_strLVTokenID=getCoverNoteReq.getAuthToken();
	       
	        String _coverNote_ProductCode = "";
	        if(getCoverNoteReq!=null && getCoverNoteReq.getProductCode()!=null)
	        	_coverNote_ProductCode=getCoverNoteReq.getProductCode();
	        
	        String _coverNote_IntermidiaryCode = "";
	        if(getCoverNoteReq!=null && getCoverNoteReq.getProducerCode()!=null)
	        	_coverNote_IntermidiaryCode = getCoverNoteReq.getProducerCode();
	        
	        String _coverNote_CoverNoteLeafNo = "";
	        if(getCoverNoteReq!=null && getCoverNoteReq.getCoverNoteLeafNo()!=null)
	        	_coverNote_CoverNoteLeafNo=getCoverNoteReq.getCoverNoteLeafNo();
	        
	        String _coverNote_DealerCode = "";
	        if(getCoverNoteReq!=null && getCoverNoteReq.getDealerCode()!=null)
	        	_coverNote_DealerCode=getCoverNoteReq.getDealerCode();
	        
	        String _coverNote_FieldUser = "";
	        if(getCoverNoteReq!=null && getCoverNoteReq.getFieldUser()!=null)
	        	_coverNote_FieldUser=getCoverNoteReq.getFieldUser();
	        
	        String _coverNote_strUserId = "";
	        if(getCoverNoteReq!=null && getCoverNoteReq.getUserID()!=null)
	        	_coverNote_strUserId = getCoverNoteReq.getUserID();
	        
	        String _coverNote_BusinessSourceCode = "A_PORTAL";
	        
	        String _coverNote_OfficeCode = "";
	        if(getCoverNoteReq!=null && getCoverNoteReq.getOfficeCode()!=null)
	        	_coverNote_OfficeCode=getCoverNoteReq.getOfficeCode();
	        
	        String _coverNote_BusinessType = "New Business";
			
	        ServiceUtility util=new ServiceUtility();
			Client client = util.addClientInterceptor(port);
			//Service Time out code
			HTTPConduit conduit=(HTTPConduit)client.getConduit();
			HTTPClientPolicy clientPolicy = new HTTPClientPolicy();
			clientPolicy.setReceiveTimeout(60000);
			clientPolicy.setConnectionTimeout(30000);
			conduit.setClient(clientPolicy);
			
	        com.unotechsoft.stub.commonservice.wcfgcintegration.ServiceResult _coverNote_return = port.getCoveNoteLOV(_coverNote_source, _coverNote_medium, _coverNote_campaingn, _coverNote_strLVTokenID, _coverNote_ProductCode, _coverNote_IntermidiaryCode, _coverNote_CoverNoteLeafNo, CommonConstants.BLANK_STRING, _coverNote_DealerCode, _coverNote_FieldUser, _coverNote_BusinessSourceCode, _coverNote_OfficeCode, _coverNote_BusinessType);
			if(_coverNote_return!=null && _coverNote_return.getUserData()!=null && _coverNote_return.getUserData().getManualCoverNoteLeafNoDataGrid()!=null){
				ArrayOfclsManualCoverNoteGrid objManualCoverNoteLeafNoDataGrid = _coverNote_return.getUserData().getManualCoverNoteLeafNoDataGrid();
				
				HashMap coverNoteMap = new HashMap();
				List<Integer> lstCoverNote = new ArrayList<Integer>();
				
				if (objManualCoverNoteLeafNoDataGrid!= null && objManualCoverNoteLeafNoDataGrid.getClsManualCoverNoteGrid()!= null && !objManualCoverNoteLeafNoDataGrid.getClsManualCoverNoteGrid().isEmpty()){
					logger.info("Inside "+_strClassName+"::"+strMethodName+"::response data found with leaf note size::: "+objManualCoverNoteLeafNoDataGrid.getClsManualCoverNoteGrid().size());
					
					for (ClsManualCoverNoteGrid objCoverNoteResponse : objManualCoverNoteLeafNoDataGrid.getClsManualCoverNoteGrid()){
						coverNoteResponse = new SearchCoverNoteForPropResponse();
						coverNoteResponse.setCoverNoteNo(objCoverNoteResponse.getCoverNoteNo());
						coverNoteResponse.setCoverNoteStatus(objCoverNoteResponse.getCoverNoteStatue());
						coverNoteResponse.setCovernoteProducerCode(objCoverNoteResponse.getCovernoteProducerCode());
						
						if (coverNoteResponse.getCoverNoteNo()!=null && coverNoteResponse.getCoverNoteNo().length()==10){
							logger.info("Inside "+_strClassName+"::"+strMethodName+"::found Valid cover No--> "+coverNoteResponse.getCoverNoteNo());
							Integer coverNoteSeries = Integer.parseInt(coverNoteResponse.getCoverNoteNo().substring(2));
							coverNoteMap.put(coverNoteSeries, coverNoteResponse);
							lstCoverNote.add(coverNoteSeries);
						}
						
					}
				}
				
				if (lstCoverNote!=null && !lstCoverNote.isEmpty()){
					logger.info("Inside "+_strClassName+"::"+strMethodName+"::sorting cover notes... ");
					Collections.sort(lstCoverNote);
					coverNoteResponse = (SearchCoverNoteForPropResponse)coverNoteMap.get(lstCoverNote.get(0));
				}
				
			}*/
			
			String serviceUrl = getWSDLURL(CommonConstants.GENERIC_COVERNOTE_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			GenericSerive_Service genericService=new GenericSerive_Service(wsdlUrl);
			GenericSerive port=genericService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);
			
			String source = smc_source;
	        String medium = smc_medium;
	        String campaign = smc_campaign;
	        
	        String _getCNLeafListByFieldUser_strLVTokenID = "";
	        String _getCNLeafListByFieldUser_strLVFieldUserId = getCoverNoteReq.getFieldUser();
	        com.unotechsoft.stub.genericservice.client.GenericResult _getCNLeafListByFieldUser__return = port.getCNLeafListByFieldUser(source, medium, campaign, _getCNLeafListByFieldUser_strLVTokenID, _getCNLeafListByFieldUser_strLVFieldUserId);
	        if(_getCNLeafListByFieldUser__return!=null && _getCNLeafListByFieldUser__return.getKeyValuePairList()!=null){
	        	ArrayOfKeyValuePairList arrayOfKeyValuePairList=_getCNLeafListByFieldUser__return.getKeyValuePairList();
	        	
	        	if(arrayOfKeyValuePairList!=null && arrayOfKeyValuePairList.getKeyValuePairList()!=null && arrayOfKeyValuePairList.getKeyValuePairList().size()>0){
	        		List<Integer> lstCoverNote = new ArrayList<Integer>();
	        		HashMap<Integer,Object> coverNoteMap = new HashMap<Integer,Object>();
	        		for(KeyValuePairList keyValuePairList:arrayOfKeyValuePairList.getKeyValuePairList()){
	        			
	        			if(keyValuePairList!=null && keyValuePairList.getID()!=null){
	        				coverNoteResponse = new SearchCoverNoteForPropResponse();
	        				coverNoteResponse.setCoverNoteNo(keyValuePairList.getID());
	        				Integer coverNoteSeries = Integer.parseInt(keyValuePairList.getID().substring(2));
	        				coverNoteMap.put(coverNoteSeries, coverNoteResponse);
	        				lstCoverNote.add(coverNoteSeries);
	        			}
	        		}
	        		
	        		if (lstCoverNote!=null && !lstCoverNote.isEmpty()){
	        			//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::sorting cover notes... ");
						Collections.sort(lstCoverNote);
						coverNoteResponse = (SearchCoverNoteForPropResponse)coverNoteMap.get(lstCoverNote.get(0));
					}
	        	}
	        }
	      //End:20/04/2017:PROD_ISSUE:Modified as suggested by TAGIC, different service needs to be invoked to get covernote no.
			
		}
		catch(Exception ex){
			//ex.printStackTrace();
			logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
		}
		logger.info("Inside "+_strClassName+"::"+strMethodName+"::Exit :: Response JSON object--> "+objMapper.writeValueAsString(coverNoteResponse));
		return coverNoteResponse;
	}

	
	
	private static String _strClassName="WcfGCIntegrationServiceImpl";

	@Override
	public List<PendingCoverNoteResponse> getOpenCoverNoteList(PendingCoverNoteRequest openCoverNoteReq) throws Exception {
		
		String strMethodName="getOpenCoverNoteList";
		PendingCoverNoteResponse openCNResponse = null;
		List<PendingCoverNoteResponse> openCNResponseLst = new ArrayList<PendingCoverNoteResponse>();
		ObjectMapper objMapper = new ObjectMapper();
		try{
			
			logger.info("Inside "+_strClassName+"::"+strMethodName+"::Entered :: JSON object--> "+objMapper.writeValueAsString(openCoverNoteReq));
			String serviceUrl=getWSDLURL(CommonConstants.WCF_GC_INTEGRATION_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			WcfGCIntegrationGateway_Service coverNoteService=new WcfGCIntegrationGateway_Service(wsdlUrl);
			WcfGCIntegrationGateway port=coverNoteService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);
			
			String _coverNote_source = smc_source;
	        String _coverNote_medium = smc_medium;
	        String _coverNote_campaingn = smc_campaign;
	        String _coverNote_strLVTokenID = "";
	        if(openCoverNoteReq!=null && openCoverNoteReq.getAuthToken()!=null)
	        	_coverNote_strLVTokenID = openCoverNoteReq.getAuthToken();
	        String _coverNote_strProducerCode = "";
	        if(openCoverNoteReq!=null && openCoverNoteReq.getProducerCode()!=null)
	        	_coverNote_strProducerCode = openCoverNoteReq.getProducerCode();
	        String _coverNote_strRiskStartDate = "";
	        if(openCoverNoteReq!=null && openCoverNoteReq.getRiskStartDate()!=null)
	        	_coverNote_strRiskStartDate = openCoverNoteReq.getRiskStartDate();
	        String _coverNote_strRiskEndDate = "";
	        if(openCoverNoteReq!=null && openCoverNoteReq.getRiskendDate()!=null)
	        	_coverNote_strRiskEndDate = openCoverNoteReq.getRiskendDate();
	        String _coverNote_strProposalFromDt = "";
	        if(openCoverNoteReq!=null && openCoverNoteReq.getProposalFromDate()!=null)
	        	_coverNote_strProposalFromDt = openCoverNoteReq.getProposalFromDate();
	        String _coverNote_strProposalToDt = "";
	        if(openCoverNoteReq!=null && openCoverNoteReq.getProposalToDate()!=null)
	        	_coverNote_strProposalToDt = openCoverNoteReq.getProposalToDate();
	        String _coverNote_strCoverNote = "";
	        if(openCoverNoteReq!=null && openCoverNoteReq.getCoverNoteNo()!=null)
	        	_coverNote_strCoverNote = openCoverNoteReq.getCoverNoteNo();
	        String _coverNote_strProposalNo = "";
	        if(openCoverNoteReq!=null && openCoverNoteReq.getProposalNo()!=null)
	        	_coverNote_strProposalNo = openCoverNoteReq.getProposalNo();
	        String _coverNote_strCustomerId = "";
	        if(openCoverNoteReq!=null && openCoverNoteReq.getCustId()!=null)
	        	_coverNote_strCustomerId = openCoverNoteReq.getCustId();
	        String _coverNote_strUserId = "";
	        if(openCoverNoteReq!=null && openCoverNoteReq.getUserID()!=null)
	        	_coverNote_strUserId = openCoverNoteReq.getUserID();
	        
			com.unotechsoft.stub.commonservice.wcfgcintegration.ServiceResult _coverNote_return = port.getPendingOCNForPortal(_coverNote_source, _coverNote_medium, _coverNote_campaingn, _coverNote_strLVTokenID, _coverNote_strProducerCode, _coverNote_strRiskStartDate, _coverNote_strRiskEndDate, _coverNote_strProposalFromDt, _coverNote_strProposalToDt, _coverNote_strCoverNote, _coverNote_strProposalNo, _coverNote_strCustomerId, _coverNote_strUserId);
			if(_coverNote_return!=null && _coverNote_return.getUserData()!=null && _coverNote_return.getUserData().getPendingOCNForPortalGrid()!=null){
				ArrayOfclsPendingOCNForPortalGrid objManualCoverNoteLeafNoDataGrid = _coverNote_return.getUserData().getPendingOCNForPortalGrid();
								
				if (objManualCoverNoteLeafNoDataGrid!= null && objManualCoverNoteLeafNoDataGrid.getClsPendingOCNForPortalGrid()!= null && !objManualCoverNoteLeafNoDataGrid.getClsPendingOCNForPortalGrid().isEmpty()){
					//if(logger.isDebugEnabled())logger.debug("Inside "+_strClassName+"::"+strMethodName+"::response data found with leaf note size::: "+objManualCoverNoteLeafNoDataGrid.getClsPendingOCNForPortalGrid().size());
					
					for (ClsPendingOCNForPortalGrid objCoverNoteResponse : objManualCoverNoteLeafNoDataGrid.getClsPendingOCNForPortalGrid()){
						openCNResponse = new PendingCoverNoteResponse();
						openCNResponse.setCoverNoteNo(objCoverNoteResponse.getCoverNoteNo());
						openCNResponse.setCustID(objCoverNoteResponse.getCustID());
						openCNResponse.setCustomerName(objCoverNoteResponse.getCustomerName());
						//openCNResponse.setErrorCode(objCoverNoteResponse);
						//openCNResponse.setErrorText(errorText);
						openCNResponse.setMake(objCoverNoteResponse.getMake());
						openCNResponse.setModel(objCoverNoteResponse.getModel());
						openCNResponse.setModelVariant(objCoverNoteResponse.getModelVariant());
						openCNResponse.setOfficeCode(objCoverNoteResponse.getOfficeCode());
						openCNResponse.setProductCode(objCoverNoteResponse.getProductCode());
						openCNResponse.setProposalAmount(objCoverNoteResponse.getProposalAmount());
						openCNResponse.setProposalDate(objCoverNoteResponse.getProposalDate());
						openCNResponse.setProposalNo(objCoverNoteResponse.getProposalNo());
						openCNResponse.setReceiptNumber(objCoverNoteResponse.getReceiptNumber());
						openCNResponse.setReference_Date(objCoverNoteResponse.getReference_Date());
						openCNResponse.setRiskEndDate(objCoverNoteResponse.getRiskEndDate());
						openCNResponse.setRiskStartDate(objCoverNoteResponse.getRiskStartDate());
						openCNResponse.setRto(objCoverNoteResponse.getRTO());
						openCNResponse.setWorkflowid(objCoverNoteResponse.getWorkflowid());
						
						openCNResponseLst.add(openCNResponse);
						
					}
				}
			
			}
		}
		catch(Exception ex){
				//ex.printStackTrace();
			logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
		}
		return openCNResponseLst;
	}

	@Override
	public CNFlagProposalResponse isCoverNoteProposal(CheckCNFlagForProposal cnFlagRequest) throws Exception {
		CNFlagProposalResponse response = new CNFlagProposalResponse();
		String coverNoteFlag = "";
		String strMethodName="isCoverNoteProposal";
		try{
			String serviceUrl=getWSDLURL(CommonConstants.WCF_GC_INTEGRATION_SERVICE);
			URL wsdlUrl=new URL(serviceUrl);
			WcfGCIntegrationGateway_Service coverNoteService=new WcfGCIntegrationGateway_Service(wsdlUrl);
			WcfGCIntegrationGateway port=coverNoteService.getSOAPOverHTTP();
			ServiceUtility serviceUtil=new ServiceUtility();
			serviceUtil.addClientInterceptor(port);
			
			String _coverNote_source = smc_source;
	        String _coverNote_medium = smc_medium;
	        String _coverNote_campaingn = smc_campaign;
	        String _coverNote_strLVTokenID = "";
	        if(cnFlagRequest!=null && cnFlagRequest.getAuthToken()!=null)
	        	_coverNote_strLVTokenID = cnFlagRequest.getAuthToken();
	        
	        String _coverNote_strProposalNo = "";
	        if(cnFlagRequest!=null && cnFlagRequest.getProposalNo()!=null)
	        	_coverNote_strProposalNo = cnFlagRequest.getProposalNo();
	        
	        com.unotechsoft.stub.commonservice.wcfgcintegration.ServiceResult _serviceResult = port.isOCNGetObjectData(_coverNote_source, _coverNote_medium, _coverNote_campaingn, _coverNote_strLVTokenID, _coverNote_strProposalNo);
	        
	        if (_serviceResult!= null && _serviceResult.getUserData()!=null){
	        	response.setCnFlag(_serviceResult.getUserData().getResultValue());
	        }
		}
		catch(Exception ex){
			//ex.printStackTrace();
			logger.error("Inside "+_strClassName+"::"+strMethodName+"::Exception::", ex);
		}
		return response;
	}
}

package com.majesco.dcf.mailcomm.service;

import com.majesco.dcf.mailcomm.json.EmailTemplateParam;

public interface MailTemplateService {

	public Object getHtmlMsgTemplate(EmailTemplateParam emailTemplateParam) throws Exception;
}

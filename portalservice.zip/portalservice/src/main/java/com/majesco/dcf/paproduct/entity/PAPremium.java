package com.majesco.dcf.paproduct.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
//@Table(name = "dcf_pa_prm",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_pa_prm")								// Added for Oracle Migration
public class PAPremium {

	
	  private String strprodcd ;
	  private Integer nprodver;
	  private String strplan ;
	  private Integer nsa ;
	  private String strcovertype ;
	  private String strfamilysize; 
	  private Integer ntenure ;
	  private Integer nbenefitpermonth;
	  private Integer nnoofmonths ;
	  private Double npremium ;
	  private Integer npremium_addon;
	  private Date dtcreated ;
	  private String strcreatedby ;
	  private Date dtupdated ;
	  private String strupdatedby;
	  
	  @Id
	  @Column(name="strprodcd")
	public String getStrprodcd() {
		return strprodcd;
	}
	public void setStrprodcd(String strprodcd) {
		this.strprodcd = strprodcd;
	}
	
	@Column(name="nprodver")
	public Integer getNprodver() {
		return nprodver;
	}
	public void setNprodver(Integer nprodver) {
		this.nprodver = nprodver;
	}
	
	@Column(name="strplan")
	public String getStrplan() {
		return strplan;
	}
	public void setStrplan(String strplan) {
		this.strplan = strplan;
	}
	
	@Column(name="nsa")
	public Integer getNsa() {
		return nsa;
	}
	public void setNsa(Integer nsa) {
		this.nsa = nsa;
	}
	
	@Column(name="strcovertype")
	public String getStrcovertype() {
		return strcovertype;
	}
	public void setStrcovertype(String strcovertype) {
		this.strcovertype = strcovertype;
	}
	
	@Column(name="strfamilysize")
	public String getStrfamilysize() {
		return strfamilysize;
	}
	public void setStrfamilysize(String strfamilysize) {
		this.strfamilysize = strfamilysize;
	}
	
	@Column(name="ntenure")
	public Integer getNtenure() {
		return ntenure;
	}
	public void setNtenure(Integer ntenure) {
		this.ntenure = ntenure;
	}
	
	@Column(name="nbenefitpermonth")
	public Integer getNbenefitpermonth() {
		return nbenefitpermonth;
	}
	public void setNbenefitpermonth(Integer nbenefitpermonth) {
		this.nbenefitpermonth = nbenefitpermonth;
	}
	
	@Column(name="nnoofmonths")
	public Integer getNnoofmonths() {
		return nnoofmonths;
	}
	public void setNnoofmonths(Integer nnoofmonths) {
		this.nnoofmonths = nnoofmonths;
	}
	
	@Column(name="npremium")
	public Double getNpremium() {
		return npremium;
	}
	public void setNpremium(Double npremium) {
		this.npremium = npremium;
	}
	
	@Column(name="npremium_addon")
	public Integer getNpremium_addon() {
		return npremium_addon;
	}
	public void setNpremium_addon(Integer npremium_addon) {
		this.npremium_addon = npremium_addon;
	}
	
	@Column(name="dtcreated")
	public Date getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(Date dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name="strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name="dtupdated")
	public Date getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(Date dtupdated) {
		this.dtupdated = dtupdated;
	}
	@Column(name="strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	  
	  
}

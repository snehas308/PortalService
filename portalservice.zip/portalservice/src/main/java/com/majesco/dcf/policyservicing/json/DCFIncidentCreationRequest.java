package com.majesco.dcf.policyservicing.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DCFIncidentCreationRequest extends UserObject {
	
	// below fields required for onyx mapping
	private String sourceSystem;
	private String destinationSystem;
	private String transactionDate;
	private String transactionNo;
	private String customerName;
	private String customerAdd1;
	private String customerAdd2;
	private String customerAdd3;
	private String city;
	private String state;
	private String pincode;
	private String mobileNo;
	private String emailId;
	private String producerCode;
	private String source;
	private String policyNo;
	private String productCat;
	private String product;
	private String reqType;
	private String reqSubType;
	private String group;
	private String subGroup;
	private String producerName;
	private String requestinfo;
	private List<DCFDocument> docList;
	
	// below fields required for portal screen mapping
	private String remarks;
	private String lob;
	private String modeOfRefund;
	private String motorRegNoNew;
	private String motorRegNoOld;
	private String motorEngineNoNew;
	private String motorEngineNoOld;
	private String motorChassisNoNew;
	private String motorChassisNoOld;
	private String chequeAmt;
	private String chequeDispatcDt;
	private String chequeDeliveryDt;
	private String chequeRTOReason;	
	private String refundType;
	private String refundAmount;
	private String chequeNeft;
	private String neftRefNo;
	private String District;
	private String customerCode;
	private String endorsCat;
	private String endorsSubCat;

	
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getModeOfRefund() {
		return modeOfRefund;
	}
	public void setModeOfRefund(String modeOfRefund) {
		this.modeOfRefund = modeOfRefund;
	}
	public String getMotorRegNoNew() {
		return motorRegNoNew;
	}
	public void setMotorRegNoNew(String motorRegNoNew) {
		this.motorRegNoNew = motorRegNoNew;
	}
	public String getMotorRegNoOld() {
		return motorRegNoOld;
	}
	public void setMotorRegNoOld(String motorRegNoOld) {
		this.motorRegNoOld = motorRegNoOld;
	}
	public String getMotorEngineNoNew() {
		return motorEngineNoNew;
	}
	public void setMotorEngineNoNew(String motorEngineNoNew) {
		this.motorEngineNoNew = motorEngineNoNew;
	}
	public String getMotorEngineNoOld() {
		return motorEngineNoOld;
	}
	public void setMotorEngineNoOld(String motorEngineNoOld) {
		this.motorEngineNoOld = motorEngineNoOld;
	}
	public String getMotorChassisNoNew() {
		return motorChassisNoNew;
	}
	public void setMotorChassisNoNew(String motorChassisNoNew) {
		this.motorChassisNoNew = motorChassisNoNew;
	}
	public String getChequeAmt() {
		return chequeAmt;
	}
	public void setChequeAmt(String chequeAmt) {
		this.chequeAmt = chequeAmt;
	}
	public String getChequeDispatcDt() {
		return chequeDispatcDt;
	}
	public void setChequeDispatcDt(String chequeDispatcDt) {
		this.chequeDispatcDt = chequeDispatcDt;
	}
	public String getChequeDeliveryDt() {
		return chequeDeliveryDt;
	}
	public void setChequeDeliveryDt(String chequeDeliveryDt) {
		this.chequeDeliveryDt = chequeDeliveryDt;
	}
	public String getChequeRTOReason() {
		return chequeRTOReason;
	}
	public void setChequeRTOReason(String chequeRTOReason) {
		this.chequeRTOReason = chequeRTOReason;
	}
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	public String getDestinationSystem() {
		return destinationSystem;
	}
	public void setDestinationSystem(String destinationSystem) {
		this.destinationSystem = destinationSystem;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(String transactionNo) {
		this.transactionNo = transactionNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAdd1() {
		return customerAdd1;
	}
	public void setCustomerAdd1(String customerAdd1) {
		this.customerAdd1 = customerAdd1;
	}
	public String getCustomerAdd2() {
		return customerAdd2;
	}
	public void setCustomerAdd2(String customerAdd2) {
		this.customerAdd2 = customerAdd2;
	}
	public String getCustomerAdd3() {
		return customerAdd3;
	}
	public void setCustomerAdd3(String customerAdd3) {
		this.customerAdd3 = customerAdd3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getProducerCode() {
		return producerCode;
	}
	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getProductCat() {
		return productCat;
	}
	public void setProductCat(String productCat) {
		this.productCat = productCat;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getReqType() {
		return reqType;
	}
	public void setReqType(String reqType) {
		this.reqType = reqType;
	}
	public String getReqSubType() {
		return reqSubType;
	}
	public void setReqSubType(String reqSubType) {
		this.reqSubType = reqSubType;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getSubGroup() {
		return subGroup;
	}
	public void setSubGroup(String subGroup) {
		this.subGroup = subGroup;
	}
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	public String getRequestinfo() {
		return requestinfo;
	}
	public void setRequestinfo(String requestinfo) {
		this.requestinfo = requestinfo;
	}
	public List<DCFDocument> getDocList() {
		return docList;
	}
	public void setDocList(List<DCFDocument> docList) {
		this.docList = docList;
	}
	public String getMotorChassisNoOld() {
		return motorChassisNoOld;
	}
	public void setMotorChassisNoOld(String motorChassisNoOld) {
		this.motorChassisNoOld = motorChassisNoOld;
	}
	public String getRefundType() {
		return refundType;
	}
	public void setRefundType(String refundType) {
		this.refundType = refundType;
	}
	public String getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getChequeNeft() {
		return chequeNeft;
	}
	public void setChequeNeft(String chequeNeft) {
		this.chequeNeft = chequeNeft;
	}
	public String getNeftRefNo() {
		return neftRefNo;
	}
	public void setNeftRefNo(String neftRefNo) {
		this.neftRefNo = neftRefNo;
	}
	public String getDistrict() {
		return District;
	}
	public void setDistrict(String district) {
		District = district;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getEndorsCat() {
		return endorsCat;
	}
	public void setEndorsCat(String endorsCat) {
		this.endorsCat = endorsCat;
	}
	public String getEndorsSubCat() {
		return endorsSubCat;
	}
	public void setEndorsSubCat(String endorsSubCat) {
		this.endorsSubCat = endorsSubCat;
	}

}

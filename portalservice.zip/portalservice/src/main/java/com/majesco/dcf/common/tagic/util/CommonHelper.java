package com.majesco.dcf.common.tagic.util;

import java.io.InputStream;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.xml.namespace.QName;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Value;

import com.majesco.dcf.common.tagic.json.CommunicationRequest;
import com.majesco.dcf.common.tagic.json.CreateCustomerRequest;
import com.majesco.dcf.common.tagic.json.EmailAttachment;
import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.UWCommunicationRequest;
import com.majesco.dcf.common.tagic.service.DBService;
import com.majesco.dcf.common.tagic.service.TagicCommunicationService;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.covernote.json.SaveOpenCNRequest;
import com.majesco.dcf.covernote.json.SaveOpenCNResponse;
import com.majesco.dcf.motor.json.ProposalGenerationCVRequest;
import com.majesco.dcf.motor.json.ProposalGenerationCVResponse;
import com.majesco.dcf.motor.json.ProposalGenerationPVRequest;
import com.majesco.dcf.motor.json.ProposalGenerationPVResponse;
import com.majesco.dcf.motor.json.ProposalGenerationTWRequest;
import com.majesco.dcf.motor.json.ProposalGenerationTWResponse;
import com.majesco.dcf.paproduct.json.IPAProposalRequest;
import com.majesco.dcf.paproduct.json.IPAProposalResponse;
import com.majesco.dcf.paproduct.serviceImpl.IPAServiceImpl;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyRequest;
import com.majesco.dcf.receipt.json.ReceiptCumPolicyResponse;
import com.majesco.dcf.receipt.json.ReceiptProposalDetails;
import com.majesco.dcf.receipt.util.ReceiptConstants;
import com.majesco.dcf.reports.json.PremiumReceivableReportResponse;
import com.majesco.dcf.reports.service.ReportService;
import com.unotechsoft.stub.accountservice.client.AccountService;
import com.unotechsoft.stub.accountservice.client.AccountService_Service;
import com.unotechsoft.stub.accountservice.client.ClsPaymentAccept;
import com.unotechsoft.stub.accountservice.client.GetUserWisePaymentDtlsForAcceptanceForPortal2;
import com.unotechsoft.stub.accountservice.client.KeyValue;
import com.unotechsoft.stub.accountservice.client.PaymentAcceptanceServiceResult;
import com.unotechsoft.stub.accountservice.client.PaymentEntryServiceResult;
import com.unotechsoft.stub.accountservice.client.UserDataPaymentAcceptance;
import com.unotechsoft.stub.customerservice.client.Bank;
import com.unotechsoft.stub.customerservice.client.Customer;
import com.unotechsoft.stub.customerservice.client.ModeOfCommunication;
import com.unotechsoft.stub.genericservice.client.GenericSerive;
import com.unotechsoft.stub.genericservice.client.GenericSerive_Service;
import com.unotechsoft.stub.genericservice.client.LOVTypePortalIDLocking;

public class CommonHelper {
	
	final static Logger logger=Logger.getLogger(CommonHelper.class);
	
	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/
	
	private static Properties prop = new Properties();
	
	static{
		try{
	InputStream inputStream = IPAServiceImpl.class.getClassLoader().getResourceAsStream("resources.properties");
	prop.load(inputStream);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	private String tollFreeNumber = prop.getProperty("tollfree.number");
		
	public static Customer TransformCreateCustReqObj (CreateCustomerRequest objCreateCust){
		
		List<String> list = new ArrayList<String>();
		list.add("CustomerMapping.xml");
		Mapper mapper = (Mapper) new DozerBeanMapper(list);
		
		Customer customer = mapper.map(objCreateCust, Customer.class);
		String strFullName=null;
		
		if (objCreateCust != null && objCreateCust.getCustomerDet()!= null && objCreateCust.getCustomerDet().getIdList()!= null
				&& objCreateCust.getCustomerDet().getIdList().getIdType()!=null && !objCreateCust.getCustomerDet().getIdList().getIdType().equals("")){
			customer.setIDProofDetails(objCreateCust.getCustomerDet().getIdList().getIdNumber());
			customer.setIDProof(Integer.parseInt(objCreateCust.getCustomerDet().getIdList().getIdType()));
		}
		
		customer.setAppSessionID(CommonConstants.BLANK_STRING);
		customer.setAlternateEmailId(CommonConstants.BLANK_STRING);
		customer.setAffiliationFlag(CommonConstants.BLANK_STRING);
		customer.setAnnualIncome(CommonConstants.BLANK_STRING);
		customer.setBlacklisted(CommonConstants.BLANK_STRING);
		customer.setBloodGroup(CommonConstants.BLANK_STRING);
		customer.setBusinessName(CommonConstants.BLANK_STRING);
		customer.setCAP(CommonConstants.BLANK_STRING);
		customer.setChequeAcceptence(CommonConstants.BLANK_STRING);
		customer.setChildCustomer(CommonConstants.BLANK_STRING);
		customer.setContactNo(CommonConstants.BLANK_STRING);
		customer.setContactPerson(CommonConstants.BLANK_STRING);
		customer.setCustomerInitials(CommonConstants.BLANK_STRING);
		customer.setCustomerStatus(CommonConstants.BLANK_STRING);
		customer.setCustomerTier(0);
		customer.setCustomerTierName(CommonConstants.BLANK_STRING);
		customer.setCustomerUniqueID(CommonConstants.BLANK_STRING);
		customer.setDBNo(CommonConstants.BLANK_STRING);
		customer.setDeDupID(CommonConstants.BLANK_STRING);
		customer.setDesignation("0"); // Hard coded to 0
		customer.setDomainname(CommonConstants.BLANK_STRING);
		customer.setDoNotCall(CommonConstants.BLANK_STRING);
		customer.setDoNotDirectory((short)0);
		customer.setDrivingLicenseno(CommonConstants.BLANK_STRING);
		customer.setEducationQualification(0); // Defaulted to 0
		customer.setEndDate(CommonConstants.BLANK_STRING);
		customer.setENDTSubType(CommonConstants.BLANK_STRING);
		customer.setENDTType(CommonConstants.BLANK_STRING);
		customer.setID(CommonConstants.BLANK_STRING);
		customer.setIFSCode(CommonConstants.BLANK_STRING);
		customer.setIndustry(CommonConstants.BLANK_STRING);
		customer.setIndustryOthers(CommonConstants.BLANK_STRING);
		customer.setInterEmpTag(CommonConstants.BLANK_STRING);
		customer.setIsBlacklisted("0");
		customer.setIsCAP(false);
		customer.setIsChildCustomer(false);
		customer.setIsDoNotCall(false);
		customer.setIsGlobalClient(false);
		customer.setIsJapaneseClient(false);
		customer.setIsMAP(false);
		customer.setISOffline(false);
		customer.setIsParent(false);
		customer.setIsPriorityClient(false);
		customer.setIsPortal(false);
		customer.setISUIICEmployee(78); // Hard coded to 78. To check what is the logic for this field.
		customer.setMailLocationCode(CommonConstants.BLANK_STRING);
		customer.setMAP(CommonConstants.BLANK_STRING);
		customer.setMOP(CommonConstants.BLANK_STRING);
		customer.setMaidenName(CommonConstants.BLANK_STRING);
		customer.setMasterPinCode(CommonConstants.BLANK_STRING);
		customer.setMICRCode(CommonConstants.BLANK_STRING);
		
		ModeOfCommunication modOfCom=new ModeOfCommunication();
		modOfCom.setIsEmailCan(false);
		modOfCom.setIsEmailEndt(false);
		modOfCom.setIsEmailNew(false);
		modOfCom.setIsEmailRenew(false);
		modOfCom.setIsEmailRenewNotice(false);
		modOfCom.setIsSMSCan(false);
		modOfCom.setIsSMSEndt(false);
		modOfCom.setIsSMSNew(false);
		modOfCom.setIsSMSRenew(false);
		modOfCom.setIsSMSRenewNotice(false);
		modOfCom.setModeOfOperation(CommonConstants.BLANK_STRING);
		customer.setModeOfCommunication(modOfCom);
		
		customer.setMOP(CommonConstants.BLANK_STRING);
		customer.setMotherName(CommonConstants.BLANK_STRING);
		customer.setOfficeCode(CommonConstants.BLANK_STRING);
		customer.setOfficeExtn(CommonConstants.BLANK_STRING);
		customer.setOfficeName(CommonConstants.BLANK_STRING);
		customer.setPCGClient(0);
		customer.setPaidUpCapital(CommonConstants.BLANK_STRING);
		customer.setParentCustomerCode(CommonConstants.BLANK_STRING);
		customer.setParentCustomerName(CommonConstants.BLANK_STRING);
		customer.setPaymentMode(CommonConstants.BLANK_STRING);
		customer.setPermanentLocationCode(CommonConstants.BLANK_STRING);
		customer.setPriorityClient(0);
		customer.setProductCode(CommonConstants.BLANK_STRING);
		customer.setProposalNo(CommonConstants.BLANK_STRING);
		customer.setRegistrationNumber(CommonConstants.BLANK_STRING);
		customer.setRegistrationOffice(CommonConstants.BLANK_STRING);
		customer.setRemarks(CommonConstants.BLANK_STRING);
		customer.setRole(CommonConstants.BLANK_STRING);
		customer.setSalutationOthers(CommonConstants.BLANK_STRING);
		customer.setServiceTaxRegNo(CommonConstants.BLANK_STRING);
		customer.setSessionID(CommonConstants.BLANK_STRING);
		
		Date startDate=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy", Locale.US);
		customer.setStartDate(sdf.format(startDate));
		
		customer.setTanNo(CommonConstants.BLANK_STRING);
		customer.setTypeOfCompany(CommonConstants.BLANK_STRING);
		customer.setUIICEmployeeNO(CommonConstants.BLANK_STRING);
		customer.setUserID("gcwinuat05"); // Need to change
		customer.setUserRole(CommonConstants.BLANK_STRING);
		
		com.unotechsoft.stub.customerservice.client.ContactDetails conDet=null;
		
if(objCreateCust != null && objCreateCust.getCustomerDet()!=null){
			
			conDet=new com.unotechsoft.stub.customerservice.client.ContactDetails();
			conDet.setAlternateDND(CommonConstants.BLANK_STRING);
			conDet.setAlternateISD(CommonConstants.BLANK_STRING);
			conDet.setAlternateMobileISD(CommonConstants.BLANK_STRING);
			conDet.setAlternateMobileNo(CommonConstants.BLANK_STRING);
			conDet.setAlternateMobileNoCountryCode(CommonConstants.BLANK_STRING);
			conDet.setAlternateNo(CommonConstants.BLANK_STRING);
			conDet.setAlternateSTD(CommonConstants.BLANK_STRING);
			conDet.setAlternateSTD(CommonConstants.BLANK_STRING);
			conDet.setDoNotCall(0);
			conDet.setDoNotCallAlternate(0);
			conDet.setExtension(CommonConstants.BLANK_STRING);
			conDet.setExtension1(CommonConstants.BLANK_STRING);
			conDet.setFaxISD(CommonConstants.BLANK_STRING);
			conDet.setFaxNo(CommonConstants.BLANK_STRING);
			conDet.setIsDoNotCall(false);
			conDet.setIsDoNotCallAlternate(false);
			conDet.setIsEmail(false);
			conDet.setIsSMS(false);
			conDet.setLandLineISD(CommonConstants.BLANK_STRING);
			//conDet.setLandLineNo(CommonConstants.BLANK_STRING);
			conDet.setLandLineSTD(CommonConstants.BLANK_STRING);
			conDet.setMobileDND(CommonConstants.BLANK_STRING);
			conDet.setMobileISD(CommonConstants.BLANK_STRING);
			if(objCreateCust.getCustomerDet().getContDetList()!=null && objCreateCust.getCustomerDet().getContDetList().getMobileNumber()!=null)
				conDet.setMobileNo(objCreateCust.getCustomerDet().getContDetList().getMobileNumber());
			else
				conDet.setMobileNo(CommonConstants.BLANK_STRING);
			//Start: RahulT | changes done for sending landline number
			if(objCreateCust.getCustomerDet().getContDetList()!=null && objCreateCust.getCustomerDet().getContDetList().getStd()!=null
					&& !objCreateCust.getCustomerDet().getContDetList().getStd().equalsIgnoreCase(""))
				conDet.setLandLineSTD(objCreateCust.getCustomerDet().getContDetList().getStd());
			else
				conDet.setLandLineSTD(CommonConstants.BLANK_STRING);
			
			
			if(objCreateCust.getCustomerDet().getContDetList()!=null && objCreateCust.getCustomerDet().getContDetList().getLandlinenumber()!=null
					&& !objCreateCust.getCustomerDet().getContDetList().getLandlinenumber().equalsIgnoreCase(""))
				conDet.setLandLineNo(objCreateCust.getCustomerDet().getContDetList().getLandlinenumber());
			else
				conDet.setLandLineNo(CommonConstants.BLANK_STRING);
						
			if(objCreateCust.getCustomerDet().getContDetList()!=null && objCreateCust.getCustomerDet().getContDetList().getPreferredcommunication()!=null && objCreateCust.getCustomerType().equalsIgnoreCase("I"))
			conDet.setModeOfCommunication(objCreateCust.getCustomerDet().getContDetList().getPreferredcommunication());
			else
			conDet.setModeOfCommunication(CommonConstants.BLANK_STRING);
			
			customer.setContactDetails(conDet);
		}
		
		if(objCreateCust != null && objCreateCust.getCustomerDet()!= null && objCreateCust.getCustomerDet().getAddressDetList()!=null && customer!=null && customer.getPermanentLocation()!=null){
			
			String district[] = objCreateCust.getCustomerDet().getAddressDetList().getDistrict().split("-");
			if(district!=null && district.length>1){
				
				customer.getPermanentLocation().setCityDistrictName(district[0]);
				customer.getPermanentLocation().setCityDistrictCode(district[1]);
			}
			
			String state[] = objCreateCust.getCustomerDet().getAddressDetList().getState().split("-");
			if(state!=null && state.length>1){
				
				customer.getPermanentLocation().setStateName(state[0]);
				customer.getPermanentLocation().setStateCode(state[1]);
			}
			
			String city[] = objCreateCust.getCustomerDet().getAddressDetList().getCity().split("-");
			if(city!=null && city.length>1){
				
				customer.getPermanentLocation().setCityName(city[0]);
				customer.getPermanentLocation().setCityId(city[1]);
			}
			
			String pin[]=objCreateCust.getCustomerDet().getAddressDetList().getPincode().split("-");
			if(pin!=null && pin.length>1){
				customer.getPermanentLocation().setPinCodeLocality(pin[0]);
				customer.getPermanentLocation().setPinCode(pin[1]);
			}
			String country[]=objCreateCust.getCustomerDet().getAddressDetList().getCountry().split("-");
			if(country!=null && country.length>1){
				customer.getPermanentLocation().setCountryName(country[0]);
				customer.getPermanentLocation().setCountryID(country[1]);
				
				customer.setCountry(country[0]);
				customer.setCountryName(country[1]);
			}
			customer.getPermanentLocation().setContactDetails(conDet);
			
			customer.setPermanentLocationSameAsMailLocation(true);
			
			customer.getPermanentLocation().setApartmentName(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setAreaVillageCode(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setAreaVillageName(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setDistrictName(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setDivision(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setDivisionCode(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setEndDate(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setErrorText(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setID(CommonConstants.BLANK_STRING);
			//customer.getPermanentLocation().setLandmark(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setLocationCode("0"); // As informed by ESB / TCS location code can be set to 0
			customer.getPermanentLocation().setMediatorName(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setName(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setPOBox(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setRegion(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setStartDate(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setStreetName(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setTitleBarName(CommonConstants.BLANK_STRING);
			customer.getPermanentLocation().setUserID(customer.getUserID()); // Hard coded for time being.
			
			if (objCreateCust.getCustomerDet().getAddressDetList().getNearLandmark()!=null && !objCreateCust.getCustomerDet().getAddressDetList().getNearLandmark().equalsIgnoreCase("")){
				customer.getPermanentLocation().setLandmark(objCreateCust.getCustomerDet().getAddressDetList().getNearLandmark());
			}
			else{
				customer.getPermanentLocation().setLandmark(CommonConstants.BLANK_STRING);
			}
			
		}
		
		if(objCreateCust != null && objCreateCust.getCustomerDet()!= null && objCreateCust.getCustomerDet().getBankdetList()==null){
			Bank bank=new Bank();
			bank.setAccountHolderName("");
			bank.setBankAccNumber("");
			bank.setBankAccounttype("0");
			bank.setBankBranchCode("0");
			bank.setBankCode(0);
			bank.setBankName("");
			bank.setBankBranchName("");
			bank.setChequeDispatchLocation("");
			bank.setIFSCCode("");
			bank.setMICRCode("");
			customer.setBankDetails(bank);
		}
		//Start: RahulT <Production 1213>| code added to send GST Number in add customer request
		if(objCreateCust.getCustomerDet()!=null && objCreateCust.getCustomerDet().getGstNumber()!=null
				&& !objCreateCust.getCustomerDet().getGstNumber().equals(CommonConstants.BLANK_STRING)){
			customer.setGSTNumber(objCreateCust.getCustomerDet().getGstNumber());
			
		}
		//End: RahulT <Production 1213>| code added to send GST Number in add customer request
		
if(objCreateCust.getCustomerType().equalsIgnoreCase("I")){
	strFullName=objCreateCust.getCustomerDet().getFirstName();
	if(objCreateCust.getCustomerDet().getLastName()!=null)
		strFullName=strFullName+" "+objCreateCust.getCustomerDet().getLastName();
}else if(objCreateCust.getCustomerType().equalsIgnoreCase("O")){
	strFullName=objCreateCust.getCustomerDet().getOrganizationName();
	customer.setFirstName(strFullName);
	if(objCreateCust.getCustomerDet().getTypeofCompany()!=null && !objCreateCust.getCustomerDet().getTypeofCompany().equalsIgnoreCase(""))
	customer.setTypeOfCompany(objCreateCust.getCustomerDet().getTypeofCompany());
}

customer.setName(strFullName);
		
		return customer;
	}
	
	public void sendCommunicationRenewalPolicy(ReceiptCumPolicyRequest accountServReq,
			ReceiptCumPolicyResponse response, String strTotalAmtPartPayment,TagicCommunicationService commService) {
		String emailID = null;
		String mobileNo = null;
		ObjectMapper objMap = new ObjectMapper();  // 1767 
		
		try{
			logger.info("In sendCommunicationRenewalPolicy :: Mail sent successfully to "+objMap.writeValueAsString(accountServReq)); // 1767 
			emailID = accountServReq.getProposalDetails().getEmailId();
			mobileNo = accountServReq.getProposalDetails().getMobileNo();
						
			if (emailID!=null && !emailID.equals("")){
				try{
					CommunicationRequest commRequest = new CommunicationRequest();
					EmailAttachment attachment = new EmailAttachment();
					commRequest.setAlertType(CommonConstants.SEND_EMAIL);
					commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PAYMENT_SUCCESS_MOTOR);
					commRequest.setReceipient(emailID);	//Email
					commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
					commRequest.setParam2(response.getPolicyNo());
					commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
					commRequest.setParam4(accountServReq.getProposalDetails().getPlanName()== null ?"":accountServReq.getProposalDetails().getPlanName());
					commRequest.setParam5(strTotalAmtPartPayment);
					commRequest.setParam6(accountServReq.getProducerName()== null ?"":accountServReq.getProducerName());
					commRequest.setParam7(accountServReq.getProducerCode()== null ?"":accountServReq.getProducerCode());
					commRequest.setParam8(accountServReq.getProposalDetails().getPolicyEffDt()== null ?"":accountServReq.getProposalDetails().getPolicyEffDt());
					commRequest.setParam9(accountServReq.getProposalDetails().getPolicyEndDt()== null ?"":accountServReq.getProposalDetails().getPolicyEndDt());
					commRequest.setParam10(response.getPolicyNo());
					commRequest.setParam11(accountServReq.getProducerName()== null ?"":accountServReq.getProducerName());
					commRequest.setParam12(accountServReq.getProducerMobile() == null ?"":accountServReq.getProducerMobile());
					commRequest.setParam13(accountServReq.getProposalDetails().getCustomerName()== null ?"":accountServReq.getProposalDetails().getCustomerName());
					commRequest.setParam14(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
					commRequest.setParam15(accountServReq.getProposalDetails().getVehRegNo()== null ?"":accountServReq.getProposalDetails().getVehRegNo());
					
					
					attachment.setPolicyNumber(response.getPolicyNo());
					attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
					attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
					attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
					attachment.setReceiptNo(response.getReceiptDtls().getReceiptNo());
					commRequest.setEmailAttachment(attachment);
					commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
					commRequest.setProducerEmail(accountServReq.getProducerEmail());
					logger.info("In CommonHelper :: sendCommunicationRenewalPolicy method :: CommRequest Object :- "+objMap.writeValueAsString(commRequest));
					commService.sendCommunication(commRequest);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: Mail sent successfully to "+emailID);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			if (mobileNo!=null && !mobileNo.equals("")){
				try{
					CommunicationRequest commRequestSMS = new CommunicationRequest();
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ mobileNo);
					commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
					commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PAYMENT_SUCCESS_MOTOR);
					commRequestSMS.setReceipient(mobileNo);
					commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
					commRequestSMS.setParam2(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
					commRequestSMS.setParam3(response.getPolicyNo());
					commRequestSMS.setParam4(emailID);
					commRequestSMS.setParam5(accountServReq.getProducerName());
					commRequestSMS.setParam6(accountServReq.getProducerMobile()==null ?tollFreeNumber:accountServReq.getProducerMobile()); 
					commService.sendCommunication(commRequestSMS);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+mobileNo);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			// Send mail & SMS to producer
			// 1767 : Code changes for sending Producer Email & mobile no : Start
			emailID = accountServReq.getProducerEmail();
			mobileNo = accountServReq.getProducerMobile();
			// 1767 : Code changes for sending Producer Email & mobile no : End
			if (accountServReq.getProducerEmail()!=null && !accountServReq.getProducerEmail().equals("")){
				try{
					CommunicationRequest commRequest = new CommunicationRequest();
					EmailAttachment attachment = new EmailAttachment();
					commRequest.setAlertType(CommonConstants.SEND_EMAIL);
					commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PAYMENT_SUCCESS_PRODUCER);
					commRequest.setReceipient(emailID);	//Email
					commRequest.setParam1(accountServReq.getProposalDetails().getCustomerName());
					commRequest.setParam2(response.getPolicyNo());
					commRequest.setParam3(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
					commRequest.setParam4(accountServReq.getProposalDetails().getVehRegNo()== null ?"":accountServReq.getProposalDetails().getVehRegNo());
					commRequest.setParam5(strTotalAmtPartPayment);
					commRequest.setParam6(accountServReq.getProposalDetails().getCustomerName());
					commRequest.setParam7(response.getPolicyNo());
					
					attachment.setPolicyNumber(response.getPolicyNo());
					attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
					attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
					attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
					attachment.setReceiptNo(response.getReceiptDtls().getReceiptNo());
					commRequest.setEmailAttachment(attachment);
					commRequest.setProductCode(accountServReq.getProposalDetails().getProductCode());
					//commService.sendCommunication(commRequest);		//1703: RahulT
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: Mail sent successfully to "+emailID);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			if (accountServReq.getProducerMobile()!=null && !accountServReq.getProducerMobile().equals("")){
				try{
					CommunicationRequest commRequestSMS = new CommunicationRequest();
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ mobileNo);
					commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
					commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PAYMENT_SUCCESS_PRODUCER);
					commRequestSMS.setReceipient(mobileNo);
					commRequestSMS.setParam1(accountServReq.getProducerName());
					commRequestSMS.setParam2(accountServReq.getProposalDetails().getCustomerName());
					commRequestSMS.setParam3(response.getPolicyNo());
					commRequestSMS.setParam4(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
					//commService.sendCommunication(commRequestSMS);		//1703: RahulT
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+mobileNo);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void sendCommunicationRenewalIPAProp(ReceiptProposalDetails payDtls, PremiumDetails prmdet, IPAProposalRequest accountServReq,
			IPAProposalResponse response, TagicCommunicationService commService) {
		String emailID = null;
		String mobileNo = null;
		String payAmount = null;
		try{
			emailID = payDtls.getEmailId();
			mobileNo = payDtls.getMobileNo();
			if (prmdet.getTotalPremium()!=null && !prmdet.getTotalPremium().equals("")){
				double d = Double.valueOf(prmdet.getTotalPremium()).doubleValue();
				payAmount = new String(""+Math.round(d));
				
			}
						
			/*if (emailID!=null && !emailID.equals("")){
				try{
					CommunicationRequest commRequest = new CommunicationRequest();
					EmailAttachment attachment = new EmailAttachment();
					commRequest.setAlertType(CommonConstants.SEND_EMAIL);
					commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_IPA);
					commRequest.setReceipient(emailID);	//Email
					commRequest.setParam1(payDtls.getCustomerName());
					commRequest.setParam2("-");	//policy number
					commRequest.setParam3(payAmount== null ?"":payAmount);
					commRequest.setParam4(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam5(payDtls.getProposalNo());
					commRequest.setParam6(accountServReq.getProposalDetails().getProductLine());
					commRequest.setParam7(response.getPolicyNo());
					
					attachment.setPolicyNumber(response.getPolicyNo());
					attachment.setProposalNumber(accountServReq.getProposalDetails().getProposalNo());
					attachment.setProductCode(accountServReq.getProposalDetails().getProductCode());
					attachment.setProposalDate(accountServReq.getProposalDetails().getProposalDate());
					attachment.setReceiptNo(response.getReceiptDtls().getReceiptNo());
					commRequest.setEmailAttachment(attachment);
					commService.sendCommunication(commRequest);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: Mail sent successfully to "+emailID);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			if (mobileNo!=null && !mobileNo.equals("")){
				try{
					CommunicationRequest commRequestSMS = new CommunicationRequest();
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ mobileNo);
					commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
					commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_IPA);
					commRequestSMS.setReceipient(mobileNo);
					commRequestSMS.setParam1(accountServReq.getProposalDetails().getCustomerName());
					commRequestSMS.setParam2(accountServReq.getProposalDetails().getProductLine()== null ?"":accountServReq.getProposalDetails().getProductLine());
					commRequestSMS.setParam3(response.getPolicyNo());
					commRequestSMS.setParam4(emailID);
					commRequestSMS.setParam5(accountServReq.getProducerName());
					commRequestSMS.setParam6(accountServReq.getProducerMobile()==null ?tollFreeNumber:accountServReq.getProducerMobile()); 
					commService.sendCommunication(commRequestSMS);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+mobileNo);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}*/
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void sendCommunicationRenewalMotorProp(ReceiptProposalDetails payDtls, PremiumDetails prmdet, ProposalGenerationCVRequest motorpropReq,
			ProposalGenerationCVResponse response, TagicCommunicationService commService) {
		String emailID = null;
		String mobileNo = null;
		String payAmount = null;
		String vehicleRegNo = null;
		try{
			emailID = payDtls.getEmailId();
			mobileNo = payDtls.getMobileNo();
			if (prmdet.getTotalPremium()!=null && !prmdet.getTotalPremium().equals("")){
				double d = Double.valueOf(prmdet.getTotalPremium()).doubleValue();
				payAmount = new String(""+Math.round(d));
				
			}
			if (motorpropReq.getLstvecReg()!=null){
				vehicleRegNo = motorpropReq.getLstvecReg().getVehicleRegNumber1()+" "+motorpropReq.getLstvecReg().getVehicleRegNumber2()+" "+
						motorpropReq.getLstvecReg().getVehicleRegNumber3()+" "+motorpropReq.getLstvecReg().getVehicleRegNumber4();
			}
						
			if (emailID!=null && !emailID.equals("") && motorpropReq.getPrvExisPolDet()!=null){
				try{
					CommunicationRequest commRequest = new CommunicationRequest();
					EmailAttachment attachment = new EmailAttachment();
					commRequest.setAlertType(CommonConstants.SEND_EMAIL);
					commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR);
					commRequest.setReceipient(emailID);	//Email
					commRequest.setParam1(payDtls.getCustomerName());
					commRequest.setParam2(motorpropReq.getPrvExisPolDet().getExistingPolNumber());	//policy number
					commRequest.setParam3(payAmount== null ?"":payAmount);
					commRequest.setParam4(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam5(payDtls.getProposalNo());
					commRequest.setParam6(motorpropReq.getPrvExisPolDet().getPrevPolEndDate());
					commRequest.setParam7(vehicleRegNo);
					
					commRequest.setParam8(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam9(motorpropReq.getProducerName());
					commRequest.setParam10(motorpropReq.getProducerMobile()==null ?tollFreeNumber:motorpropReq.getProducerMobile());
					
					attachment.setCustomerID(motorpropReq.getStrcustID());
					attachment.setProposalNumber(payDtls.getProposalNo());
					attachment.setProductCode(motorpropReq.getProductCode()==null?"":motorpropReq.getProductCode());
					attachment.setProposalDate(motorpropReq.getLstRiskdet().getPolIncpnDt()==null?"":motorpropReq.getLstRiskdet().getPolIncpnDt());
					commRequest.setEmailAttachment(attachment);
					commRequest.setUserID(motorpropReq.getUserID());
					commRequest.setPassword(motorpropReq.getPassword());
					commRequest.setProductCode("3121");
					commService.sendCommunication(commRequest);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: Mail sent successfully to "+emailID);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			// send mail to producer
			if (motorpropReq.getProducerEmail()!=null && !motorpropReq.getProducerEmail().equals("") && motorpropReq.getPrvExisPolDet()!=null){
				try{
					CommunicationRequest commRequest = new CommunicationRequest();
					EmailAttachment attachment = new EmailAttachment();
					commRequest.setAlertType(CommonConstants.SEND_EMAIL);
					commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR_PRODUCER);
					commRequest.setReceipient(motorpropReq.getProducerEmail());	//Email
					commRequest.setParam1(payDtls.getCustomerName());
					commRequest.setParam2(motorpropReq.getPrvExisPolDet().getExistingPolNumber());	//policy number
					commRequest.setParam3(payAmount== null ?"":payAmount);
					commRequest.setParam4(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam5(payDtls.getProposalNo());
					commRequest.setParam6(motorpropReq.getPrvExisPolDet().getPrevPolEndDate());
					commRequest.setParam7(vehicleRegNo);
					
					commRequest.setParam8(motorpropReq.getProducerName());
					commRequest.setParam9(payDtls.getCustomerName()== null ?"":payDtls.getCustomerName());
					commRequest.setParam10(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam11(motorpropReq.getPrvExisPolDet().getExistingPolNumber()==null ?"":motorpropReq.getPrvExisPolDet().getExistingPolNumber());
					
					attachment.setCustomerID(motorpropReq.getStrcustID());
					attachment.setProposalNumber(payDtls.getProposalNo());
					attachment.setProductCode(motorpropReq.getProductCode()==null?"":motorpropReq.getProductCode());
					attachment.setProposalDate(motorpropReq.getLstRiskdet().getPolIncpnDt()==null?"":motorpropReq.getLstRiskdet().getPolIncpnDt());
					commRequest.setEmailAttachment(attachment);
					commRequest.setUserID(motorpropReq.getUserID());
					commRequest.setPassword(motorpropReq.getPassword());
					commService.sendCommunication(commRequest);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: Mail sent successfully to "+motorpropReq.getProducerEmail());
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			if (mobileNo!=null && !mobileNo.equals("")){
				try{
					CommunicationRequest commRequestSMS = new CommunicationRequest();
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ mobileNo);
					commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
					commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR);
					commRequestSMS.setReceipient(mobileNo);
					commRequestSMS.setParam1(payDtls.getCustomerName());
					commRequestSMS.setParam2(payDtls.getProposalNo()== null ?"":payDtls.getProposalNo());
					commRequestSMS.setParam3(emailID);
					commRequestSMS.setParam4(payAmount== null ?"":payAmount);
					commRequestSMS.setParam5(motorpropReq.getProducerName());
					commRequestSMS.setParam6(motorpropReq.getProducerMobile()==null ?tollFreeNumber:motorpropReq.getProducerMobile()); 
					commService.sendCommunication(commRequestSMS);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+mobileNo);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			// sending SMS to producer
			if (motorpropReq.getProducerMobile()!=null && !motorpropReq.getProducerMobile().equals("")){
				try{
					CommunicationRequest commRequestSMS = new CommunicationRequest();
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ mobileNo);
					commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
					commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR_PRODUCER);
					commRequestSMS.setReceipient(motorpropReq.getProducerMobile());
					commRequestSMS.setParam1(motorpropReq.getProducerName());
					commRequestSMS.setParam2(payDtls.getCustomerName()== null ?"":payDtls.getCustomerName());
					commRequestSMS.setParam3(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequestSMS.setParam4(motorpropReq.getProducerEmail()== null ?"":motorpropReq.getProducerEmail());
					commRequestSMS.setParam5(payDtls.getProposalNo());
					commRequestSMS.setParam6(payAmount== null ?"":payAmount); 
					commService.sendCommunication(commRequestSMS);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+motorpropReq.getProducerMobile());
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	public void sendCommunicationRenewalMotorProp(ReceiptProposalDetails payDtls, PremiumDetails prmdet, ProposalGenerationPVRequest motorpropReq,
			ProposalGenerationPVResponse response, TagicCommunicationService commService) {
		String emailID = null;
		String mobileNo = null;
		String payAmount = null;
		String vehicleRegNo = null;
		try{
			emailID = payDtls.getEmailId();
			mobileNo = payDtls.getMobileNo();
			if (prmdet.getTotalPremium()!=null && !prmdet.getTotalPremium().equals("")){
				double d = Double.valueOf(prmdet.getTotalPremium()).doubleValue();
				payAmount = new String(""+Math.round(d));
				
			}
			if (motorpropReq.getLstvecReg()!=null){
				vehicleRegNo = motorpropReq.getLstvecReg().getVehicleRegNumber1()+" "+motorpropReq.getLstvecReg().getVehicleRegNumber2()+" "+
						motorpropReq.getLstvecReg().getVehicleRegNumber3()+" "+motorpropReq.getLstvecReg().getVehicleRegNumber4();
			}
						
			if (emailID!=null && !emailID.equals("") && motorpropReq.getPrvExisPolDet()!=null){
				try{
					CommunicationRequest commRequest = new CommunicationRequest();
					EmailAttachment attachment = new EmailAttachment();
					commRequest.setAlertType(CommonConstants.SEND_EMAIL);
					commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR);
					commRequest.setReceipient(emailID);	//Email
					commRequest.setParam1(payDtls.getCustomerName());
					commRequest.setParam2(motorpropReq.getPrvExisPolDet().getExistingPolNumber());	//policy number
					commRequest.setParam3(payAmount== null ?"":payAmount);
					commRequest.setParam4(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam5(payDtls.getProposalNo());
					commRequest.setParam6(motorpropReq.getPrvExisPolDet().getPrevPolEndDate());
					commRequest.setParam7(vehicleRegNo);
					
					commRequest.setParam8(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam9(motorpropReq.getProducerName());
					commRequest.setParam10(motorpropReq.getProducerMobile()==null ?tollFreeNumber:motorpropReq.getProducerMobile());
					
					attachment.setCustomerID(motorpropReq.getStrcustID());
					attachment.setProposalNumber(payDtls.getProposalNo());
					attachment.setProductCode(motorpropReq.getProductCode()==null?"":motorpropReq.getProductCode());
					attachment.setProposalDate(motorpropReq.getLstRiskdet().getPolIncpnDt()==null?"":motorpropReq.getLstRiskdet().getPolIncpnDt());
					commRequest.setEmailAttachment(attachment);
					commRequest.setUserID(motorpropReq.getUserID());
					commRequest.setPassword(motorpropReq.getPassword());
					commRequest.setProductCode("3121");
					//commService.sendCommunication(commRequest);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: Mail sent successfully to "+emailID);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			// send mail to producer
			if (motorpropReq.getProducerEmail()!=null && !motorpropReq.getProducerEmail().equals("") && motorpropReq.getPrvExisPolDet()!=null){
				try{
					CommunicationRequest commRequest = new CommunicationRequest();
					EmailAttachment attachment = new EmailAttachment();
					commRequest.setAlertType(CommonConstants.SEND_EMAIL);
					commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR_PRODUCER);
					commRequest.setReceipient(motorpropReq.getProducerEmail());	//Email
					commRequest.setParam1(payDtls.getCustomerName());
					commRequest.setParam2(motorpropReq.getPrvExisPolDet().getExistingPolNumber());	//policy number
					commRequest.setParam3(payAmount== null ?"":payAmount);
					commRequest.setParam4(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam5(payDtls.getProposalNo());
					commRequest.setParam6(motorpropReq.getPrvExisPolDet().getPrevPolEndDate());
					commRequest.setParam7(vehicleRegNo);
					
					commRequest.setParam8(motorpropReq.getProducerName());
					commRequest.setParam9(payDtls.getCustomerName()== null ?"":payDtls.getCustomerName());
					commRequest.setParam10(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam11(motorpropReq.getPrvExisPolDet().getExistingPolNumber()==null ?"":motorpropReq.getPrvExisPolDet().getExistingPolNumber());
					
					attachment.setCustomerID(motorpropReq.getStrcustID());
					attachment.setProposalNumber(payDtls.getProposalNo());
					attachment.setProductCode(motorpropReq.getProductCode()==null?"":motorpropReq.getProductCode());
					attachment.setProposalDate(motorpropReq.getLstRiskdet().getPolIncpnDt()==null?"":motorpropReq.getLstRiskdet().getPolIncpnDt());
					commRequest.setEmailAttachment(attachment);
					commRequest.setUserID(motorpropReq.getUserID());
					commRequest.setPassword(motorpropReq.getPassword());
					//commService.sendCommunication(commRequest);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: Mail sent successfully to "+motorpropReq.getProducerEmail());
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}

			
			if (mobileNo!=null && !mobileNo.equals("")){
				try{
					CommunicationRequest commRequestSMS = new CommunicationRequest();
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ mobileNo);
					commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
					commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR);
					commRequestSMS.setReceipient(mobileNo);
					commRequestSMS.setParam1(payDtls.getCustomerName());
					commRequestSMS.setParam2(payDtls.getProposalNo()== null ?"":payDtls.getProposalNo());
					commRequestSMS.setParam3(emailID);
					commRequestSMS.setParam4(payAmount== null ?"":payAmount);
					commRequestSMS.setParam5(motorpropReq.getProducerName());
					commRequestSMS.setParam6(motorpropReq.getProducerMobile()==null ?tollFreeNumber:motorpropReq.getProducerMobile()); 
					//commService.sendCommunication(commRequestSMS);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+mobileNo);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			// sending SMS to producer
			if (motorpropReq.getProducerMobile()!=null && !motorpropReq.getProducerMobile().equals("")){
				try{
					CommunicationRequest commRequestSMS = new CommunicationRequest();
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ mobileNo);
					commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
					commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR);
					commRequestSMS.setReceipient(motorpropReq.getProducerMobile());
					commRequestSMS.setParam1(motorpropReq.getProducerName());
					commRequestSMS.setParam2(payDtls.getCustomerName()== null ?"":payDtls.getCustomerName());
					commRequestSMS.setParam3(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequestSMS.setParam4(motorpropReq.getProducerEmail()== null ?"":motorpropReq.getProducerEmail());
					commRequestSMS.setParam5(payDtls.getProposalNo());
					commRequestSMS.setParam6(payAmount== null ?"":payAmount); 
					//commService.sendCommunication(commRequestSMS);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+motorpropReq.getProducerMobile());
					}
					catch(Exception e){
						e.printStackTrace();
					}
				}			
			}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	public void sendCommunicationRenewalMotorProp(ReceiptProposalDetails payDtls, PremiumDetails prmdet, ProposalGenerationTWRequest motorpropReq,
			ProposalGenerationTWResponse response, TagicCommunicationService commService) {
		String emailID = null;
		String mobileNo = null;
		String payAmount = null;
		String vehicleRegNo = null;
		try{
			emailID = payDtls.getEmailId();
			mobileNo = payDtls.getMobileNo();
			if (prmdet.getTotalPremium()!=null && !prmdet.getTotalPremium().equals("")){
				double d = Double.valueOf(prmdet.getTotalPremium()).doubleValue();
				payAmount = new String(""+Math.round(d));
				
			}
			if (motorpropReq.getLstvecReg()!=null){
				vehicleRegNo = motorpropReq.getLstvecReg().getVehicleRegNumber1()+" "+motorpropReq.getLstvecReg().getVehicleRegNumber2()+" "+
						motorpropReq.getLstvecReg().getVehicleRegNumber3()+" "+motorpropReq.getLstvecReg().getVehicleRegNumber4();
			}
						
			if (emailID!=null && !emailID.equals("") && motorpropReq.getPrvExisPolDet()!=null){
				try{
					CommunicationRequest commRequest = new CommunicationRequest();
					EmailAttachment attachment = new EmailAttachment();
					commRequest.setAlertType(CommonConstants.SEND_EMAIL);
					commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR);
					commRequest.setReceipient(emailID);	//Email
					commRequest.setParam1(payDtls.getCustomerName());
					commRequest.setParam2(motorpropReq.getPrvExisPolDet().getExistingPolNumber());	//policy number
					commRequest.setParam3(payAmount== null ?"":payAmount);
					commRequest.setParam4(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam5(payDtls.getProposalNo());
					commRequest.setParam6(motorpropReq.getPrvExisPolDet().getPrevPolEndDate());
					commRequest.setParam7(vehicleRegNo);
					
					commRequest.setParam8(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam9(motorpropReq.getProducerName());
					commRequest.setParam10(motorpropReq.getProducerMobile()==null ?tollFreeNumber:motorpropReq.getProducerMobile());
					
					attachment.setCustomerID(motorpropReq.getStrcustID());
					attachment.setProposalNumber(payDtls.getProposalNo());
					attachment.setProductCode(motorpropReq.getProductCode()==null?"":motorpropReq.getProductCode());
					attachment.setProposalDate(motorpropReq.getLstRiskdet().getPolIncpnDt()==null?"":motorpropReq.getLstRiskdet().getPolIncpnDt());
					commRequest.setEmailAttachment(attachment);
					commRequest.setUserID(motorpropReq.getUserID());
					commRequest.setPassword(motorpropReq.getPassword());
					commRequest.setProductCode("3121");
					commService.sendCommunication(commRequest);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: Mail sent successfully to "+emailID);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			// send mail to producer
			if (motorpropReq.getProducerEmail()!=null && !motorpropReq.getProducerEmail().equals("") && motorpropReq.getPrvExisPolDet()!=null){
				try{
					CommunicationRequest commRequest = new CommunicationRequest();
					EmailAttachment attachment = new EmailAttachment();
					commRequest.setAlertType(CommonConstants.SEND_EMAIL);
					commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR_PRODUCER);
					commRequest.setReceipient(motorpropReq.getProducerEmail());	//Email
					commRequest.setParam1(payDtls.getCustomerName());
					commRequest.setParam2(motorpropReq.getPrvExisPolDet().getExistingPolNumber());	//policy number
					commRequest.setParam3(payAmount== null ?"":payAmount);
					commRequest.setParam4(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam5(payDtls.getProposalNo());
					commRequest.setParam6(motorpropReq.getPrvExisPolDet().getPrevPolEndDate());
					commRequest.setParam7(vehicleRegNo);
					
					commRequest.setParam8(motorpropReq.getProducerName());
					commRequest.setParam9(payDtls.getCustomerName()== null ?"":payDtls.getCustomerName());
					commRequest.setParam10(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequest.setParam11(motorpropReq.getPrvExisPolDet().getExistingPolNumber()==null ?"":motorpropReq.getPrvExisPolDet().getExistingPolNumber());
					
					attachment.setCustomerID(motorpropReq.getStrcustID());
					attachment.setProposalNumber(payDtls.getProposalNo());
					attachment.setProductCode(motorpropReq.getProductCode()==null?"":motorpropReq.getProductCode());
					attachment.setProposalDate(motorpropReq.getLstRiskdet().getPolIncpnDt()==null?"":motorpropReq.getLstRiskdet().getPolIncpnDt());
					commRequest.setEmailAttachment(attachment);
					commRequest.setUserID(motorpropReq.getUserID());
					commRequest.setPassword(motorpropReq.getPassword());
					commService.sendCommunication(commRequest);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: Mail sent successfully to "+motorpropReq.getProducerEmail());
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}

			
			if (mobileNo!=null && !mobileNo.equals("")){
				try{
					CommunicationRequest commRequestSMS = new CommunicationRequest();
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ mobileNo);
					commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
					commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR);
					commRequestSMS.setReceipient(mobileNo);
					commRequestSMS.setParam1(payDtls.getCustomerName());
					commRequestSMS.setParam2(payDtls.getProposalNo()== null ?"":payDtls.getProposalNo());
					commRequestSMS.setParam3(emailID);
					commRequestSMS.setParam4(payAmount== null ?"":payAmount);
					commRequestSMS.setParam5(motorpropReq.getProducerName());
					commRequestSMS.setParam6(motorpropReq.getProducerMobile()==null ?tollFreeNumber:motorpropReq.getProducerMobile()); 
					commService.sendCommunication(commRequestSMS);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+mobileNo);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			// sending SMS to producer
			if (motorpropReq.getProducerMobile()!=null && !motorpropReq.getProducerMobile().equals("")){
				try{
					CommunicationRequest commRequestSMS = new CommunicationRequest();
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ mobileNo);
					commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
					commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PROPOSAL_GENERATED_MOTOR_PRODUCER);
					commRequestSMS.setReceipient(motorpropReq.getProducerMobile());
					commRequestSMS.setParam1(motorpropReq.getProducerName());
					commRequestSMS.setParam2(payDtls.getCustomerName()== null ?"":payDtls.getCustomerName());
					commRequestSMS.setParam3(payDtls.getProductLine()== null ?"":payDtls.getProductLine());
					commRequestSMS.setParam4(motorpropReq.getProducerEmail()== null ?"":motorpropReq.getProducerEmail());
					commRequestSMS.setParam5(payDtls.getProposalNo());
					commRequestSMS.setParam6(payAmount== null ?"":payAmount); 
					commService.sendCommunication(commRequestSMS);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+motorpropReq.getProducerMobile());
					}
					catch(Exception e){
						e.printStackTrace();
					}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}

	public void sendCommunicationRenewalMotorUW(UWCommunicationRequest uwCommunication, TagicCommunicationService communicationService) {
		
		try{
			if (uwCommunication.getCustomerEmail()!=null && !uwCommunication.getCustomerEmail().equals("") && uwCommunication.getPolicyNo()!=null){
				try{
					CommunicationRequest commRequest = new CommunicationRequest();
					EmailAttachment attachment = new EmailAttachment();
					commRequest.setAlertType(CommonConstants.SEND_EMAIL);
					commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PENDING_UW_PRODUCER);
					commRequest.setReceipient(uwCommunication.getCustomerEmail());	//Email
					commRequest.setParam1(uwCommunication.getCustomerName());
					commRequest.setParam2(uwCommunication.getPolicyNo());	//policy number
					commRequest.setParam3(uwCommunication.getPremiumAmt()== null ?"":uwCommunication.getPremiumAmt());
					commRequest.setParam4(uwCommunication.getProductName()== null ?"":uwCommunication.getProductName());
					commRequest.setParam5(uwCommunication.getProposalNo());
					commRequest.setParam6(uwCommunication.getPrvPolExpDt());
					commRequest.setParam7(uwCommunication.getVehicleRegNo());
					
					commRequest.setParam8(uwCommunication.getCustomerName()== null ?"":uwCommunication.getCustomerName());
					commRequest.setParam9(uwCommunication.getAgentName());
					commRequest.setParam10(uwCommunication.getProducerMobile()==null ?tollFreeNumber:uwCommunication.getProducerMobile());
					
					attachment.setCustomerID(uwCommunication.getCustomerId());
					attachment.setProposalNumber(uwCommunication.getProposalNo());
					attachment.setProductCode(uwCommunication.getProductCode());
					attachment.setProposalDate(uwCommunication.getPolIncptionDt()==null?"":uwCommunication.getPolIncptionDt());
					commRequest.setEmailAttachment(attachment);
					/*commRequest.setUserID(uwCommunication.getUserID());
					commRequest.setPassword(motorpropReq.getPassword());*/
					commRequest.setProductCode("3121");
					communicationService.sendCommunication(commRequest);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalMotorUW method ::: Mail sent successfully to "+uwCommunication.getCustomerEmail());
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			//Producer email
			if (uwCommunication.getProducerEmail()!=null && !uwCommunication.getProducerEmail().equals("") && uwCommunication.getPolicyNo()!=null){
				try{
					CommunicationRequest commRequest = new CommunicationRequest();
					EmailAttachment attachment = new EmailAttachment();
					commRequest.setAlertType(CommonConstants.SEND_EMAIL);
					commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PENDING_UW_PRODUCER);
					commRequest.setReceipient(uwCommunication.getProducerEmail());	//Email
					commRequest.setParam1(uwCommunication.getCustomerName());
					commRequest.setParam2(uwCommunication.getPolicyNo());	//policy number
					commRequest.setParam3(uwCommunication.getPremiumAmt()== null ?"":uwCommunication.getPremiumAmt());
					commRequest.setParam4(uwCommunication.getProductName()== null ?"":uwCommunication.getProductName());
					commRequest.setParam5(uwCommunication.getProposalNo());
					commRequest.setParam6(uwCommunication.getPrvPolExpDt());
					commRequest.setParam7(uwCommunication.getVehicleRegNo());
					
					commRequest.setParam8(uwCommunication.getCustomerName()== null ?"":uwCommunication.getCustomerName());
					commRequest.setParam9(uwCommunication.getAgentName());
					commRequest.setParam10(uwCommunication.getProducerMobile()==null ?tollFreeNumber:uwCommunication.getProducerMobile());
					
					attachment.setCustomerID(uwCommunication.getCustomerId());
					attachment.setProposalNumber(uwCommunication.getProposalNo());
					attachment.setProductCode(uwCommunication.getProductCode());
					attachment.setProposalDate(uwCommunication.getPolIncptionDt()==null?"":uwCommunication.getPolIncptionDt());
					commRequest.setEmailAttachment(attachment);
					/*commRequest.setUserID(motorpropReq.getUserID());
					commRequest.setPassword(motorpropReq.getPassword());*/
					commRequest.setProductCode(uwCommunication.getProductCode());
					communicationService.sendCommunication(commRequest);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalMotorUW method ::: Mail sent successfully to "+uwCommunication.getProducerMobile());
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			if (uwCommunication.getCustomerMobile()!=null && !uwCommunication.getCustomerMobile().equals("")){
				try{
					CommunicationRequest commRequestSMS = new CommunicationRequest();
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ uwCommunication.getCustomerMobile());
					commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
					commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PENDING_UW_MOTOR);
					commRequestSMS.setReceipient(uwCommunication.getCustomerMobile());
					commRequestSMS.setParam1(uwCommunication.getCustomerName());
					communicationService.sendCommunication(commRequestSMS);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+uwCommunication.getCustomerMobile());
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			
			// sms to producer 
			if (uwCommunication.getProducerMobile()!=null && !uwCommunication.getProducerMobile().equals("")){
				try{
					CommunicationRequest commRequestSMS = new CommunicationRequest();
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ uwCommunication.getCustomerMobile());
					commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
					commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PENDING_UW_PRODUCER);
					commRequestSMS.setReceipient(uwCommunication.getProducerMobile());
					commRequestSMS.setParam1(uwCommunication.getAgentName());
					commRequestSMS.setParam2(uwCommunication.getCustomerName()== null ?"":uwCommunication.getCustomerName());
					commRequestSMS.setParam3(uwCommunication.getProductName());
					communicationService.sendCommunication(commRequestSMS);
					logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+uwCommunication.getProducerMobile());
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	public HashMap getHouseBankAndAccountNo(AccountService accServClient,String officeCode, String paymentMode, String pageName) {
		String branchCode = "";
		String bankName = "";
		String bankAccountNo = "";
		HashMap <String,String> hmVal = new HashMap<String,String>();
		try{
			logger.info("In CommonHelper :: getHouseBankAndAccountNo method ::: Entered..");
			/*ServiceUtility serviceUtility = new ServiceUtility();
			serviceUtility.addClientInterceptor(accServClient);*/
			PaymentEntryServiceResult _houseBankResponse = accServClient.getHouseBankListForPaymentEntry(smc_source, smc_medium, smc_campaign, officeCode, paymentMode, pageName);
			if (_houseBankResponse!=null && _houseBankResponse.getHouseBankList()!=null && _houseBankResponse.getHouseBankList().getKeyValue()!=null
					&& !_houseBankResponse.getHouseBankList().getKeyValue().isEmpty()){
				KeyValue keyVal = _houseBankResponse.getHouseBankList().getKeyValue().get(0);
				branchCode = keyVal.getKey();
				bankName = keyVal.getValue();
				logger.info("In CommonHelper :: getHouseBankAndAccountNo method ::: branchCode--> "+branchCode+" , bankName--> "+bankName);
				
				PaymentEntryServiceResult _bankAccountNoResponse = accServClient.getBankAccountNoForPaymentEntryTransTypewise(smc_source, smc_medium, smc_campaign, officeCode, paymentMode, branchCode, pageName);
				if (_bankAccountNoResponse!=null && _bankAccountNoResponse.getBankAccountNoList()!=null
						&& _bankAccountNoResponse.getBankAccountNoList().getString()!=null && !_bankAccountNoResponse.getBankAccountNoList().getString().isEmpty()){
					bankAccountNo = _bankAccountNoResponse.getBankAccountNoList().getString().get(0);
					logger.info("In CommonHelper :: getHouseBankAndAccountNo method :::  bankAccountNo--> "+bankAccountNo);
				}
				hmVal.put("branchCode", branchCode);
				hmVal.put("bankName", bankName);
				hmVal.put("bankAccountNo", bankAccountNo);
			}
			
		}
		catch(Exception e){
			//e.printStackTrace();
			logger.error("In CommonHelper :: getHouseBankAndAccountNo method ::Error", e);
		}
		return hmVal;
	}
	
	public void sendCommunicationCNPolicy(SaveOpenCNRequest saveOpenCNReq, SaveOpenCNResponse response, TagicCommunicationService commService) {
		String emailID = null;
		String mobileNo = null;
		emailID = saveOpenCNReq.getCustomerEmail();
		mobileNo = saveOpenCNReq.getCustomerMobile();
						
		if (emailID!=null && !emailID.equals("")){
			try{
				CommunicationRequest commRequest = new CommunicationRequest();
				EmailAttachment attachment = new EmailAttachment();
				commRequest.setAlertType(CommonConstants.SEND_EMAIL);
				commRequest.setEventType(CommonConstants.EVENT_RENEWAL_PAYMENT_SUCCESS_MOTOR);
				commRequest.setReceipient(emailID);	//Email
				commRequest.setParam1(saveOpenCNReq.getCustomerName());
				commRequest.setParam2(response.getPolicyNo());
				commRequest.setParam3(saveOpenCNReq.getProductDesc()== null ?"":saveOpenCNReq.getProductDesc());
				commRequest.setParam4(saveOpenCNReq.getProductDesc()== null ?"":saveOpenCNReq.getProductDesc());
				commRequest.setParam5(saveOpenCNReq.getProposalAmount());
				commRequest.setParam6(saveOpenCNReq.getProductDesc());
				commRequest.setParam7(response.getPolicyNo());
					
				attachment.setPolicyNumber(response.getPolicyNo());
				attachment.setProposalNumber(saveOpenCNReq.getProposalNo());
				attachment.setProductCode(saveOpenCNReq.getProductCode());
				attachment.setProposalDate(saveOpenCNReq.getProposalDate());
				attachment.setReceiptNo(response.getReceiptNo().get(0));
				commRequest.setUserID(saveOpenCNReq.getUserID());
				commRequest.setPassword(saveOpenCNReq.getPassword());
				commRequest.setEmailAttachment(attachment);
				commRequest.setProductCode("3121");
				commService.sendCommunication(commRequest);
				logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: Mail sent successfully to "+emailID);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
			
		if (mobileNo!=null && !mobileNo.equals("")){
			try{
				CommunicationRequest commRequestSMS = new CommunicationRequest();
				logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: sending SMS to  "+ mobileNo);
				commRequestSMS.setAlertType(CommonConstants.SEND_SMS);
				commRequestSMS.setEventType(CommonConstants.EVENT_RENEWAL_PAYMENT_SUCCESS_MOTOR);
				commRequestSMS.setReceipient(mobileNo);
				commRequestSMS.setParam1(saveOpenCNReq.getCustomerName());
				commRequestSMS.setParam2(saveOpenCNReq.getProductDesc()== null ?"":saveOpenCNReq.getProductDesc());
				commRequestSMS.setParam3(response.getPolicyNo());
				commRequestSMS.setParam4(emailID);
				commRequestSMS.setParam5(saveOpenCNReq.getProducerName());
				commRequestSMS.setParam6(saveOpenCNReq.getProducerMobile()==null ?tollFreeNumber:saveOpenCNReq.getProducerMobile()); 
				commService.sendCommunication(commRequestSMS);
				logger.info("In ReceiptServiceImpl :: sendCommunicationRenewalPolicy method ::: SMS sent successfully to "+mobileNo);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}		
	}
	
}

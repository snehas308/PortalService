package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PreInspectionDetailsResponse {

	private String strinspectionagencycd;
	private String strinspectionagencyname;
	private String stremailid;
	private String strmobileno;
	private String strlandlineno;
	private String strfirstescalationemailid;
	private String strfirstescalationmobno;
	private String strsecondescalationemailid;
	private String strsecondescalationmobno;
	
	public String getStrinspectionagencycd() {
		return strinspectionagencycd;
	}
	public void setStrinspectionagencycd(String strinspectionagencycd) {
		this.strinspectionagencycd = strinspectionagencycd;
	}
	public String getStrinspectionagencyname() {
		return strinspectionagencyname;
	}
	public void setStrinspectionagencyname(String strinspectionagencyname) {
		this.strinspectionagencyname = strinspectionagencyname;
	}
	public String getStremailid() {
		return stremailid;
	}
	public void setStremailid(String stremailid) {
		this.stremailid = stremailid;
	}
	public String getStrmobileno() {
		return strmobileno;
	}
	public void setStrmobileno(String strmobileno) {
		this.strmobileno = strmobileno;
	}
	public String getStrlandlineno() {
		return strlandlineno;
	}
	public void setStrlandlineno(String strlandlineno) {
		this.strlandlineno = strlandlineno;
	}
	public String getStrfirstescalationemailid() {
		return strfirstescalationemailid;
	}
	public void setStrfirstescalationemailid(String strfirstescalationemailid) {
		this.strfirstescalationemailid = strfirstescalationemailid;
	}
	public String getStrfirstescalationmobno() {
		return strfirstescalationmobno;
	}
	public void setStrfirstescalationmobno(String strfirstescalationmobno) {
		this.strfirstescalationmobno = strfirstescalationmobno;
	}
	public String getStrsecondescalationemailid() {
		return strsecondescalationemailid;
	}
	public void setStrsecondescalationemailid(String strsecondescalationemailid) {
		this.strsecondescalationemailid = strsecondescalationemailid;
	}
	public String getStrsecondescalationmobno() {
		return strsecondescalationmobno;
	}
	public void setStrsecondescalationmobno(String strsecondescalationmobno) {
		this.strsecondescalationmobno = strsecondescalationmobno;
	}
	
	
}

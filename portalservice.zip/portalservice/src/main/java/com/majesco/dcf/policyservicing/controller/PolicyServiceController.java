package com.majesco.dcf.policyservicing.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.majesco.dcf.policyservicing.json.DCFIncidentCreationRequest;
import com.majesco.dcf.policyservicing.json.DCFIncidentCreationResult;
import com.majesco.dcf.policyservicing.service.PolicyServicingService;

@Controller
@RequestMapping(value="/policyService")
public class PolicyServiceController {
	
	@Autowired
	PolicyServicingService psService;
	
	final static Logger logger=Logger.getLogger(PolicyServiceController.class);
	
	@RequestMapping(value="/onyx/", method = RequestMethod.POST)
	@ResponseBody
	public DCFIncidentCreationResult fileUploadToOnyx(@RequestBody DCFIncidentCreationRequest incidentReq, HttpServletRequest httpServletRequest) throws Exception
	{			
		logger.info("Inside PolicyServiceController :: fileUploadToOnyx method :: Execution Started");
		DCFIncidentCreationResult result = null;
		try{
			result = psService.fileUploadToOnyx(incidentReq);
			logger.info("Inside PolicyServiceController :: fileUploadToOnyx method :: Execution Completed Successfully");
		}
		
		catch(Exception ex){
			ex.printStackTrace();
		}
		
					
		return result;
	}

}

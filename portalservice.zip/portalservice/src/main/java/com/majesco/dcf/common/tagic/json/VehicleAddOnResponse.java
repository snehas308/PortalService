package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class VehicleAddOnResponse {
	private String strplanname="";
	  private String strchoice="";
	  private BigDecimal ndepreciationreimbursement;
	  private String strnoofclaims="";
	  private BigDecimal nenginesecure;
	  private String strenginesecureoption="";
	  private BigDecimal ntyresecure;
	  private String strtyresecureoption="";
	  private BigDecimal nrepairofglassrubberplasticparts;
	  private BigDecimal nkeyreplacement;
	  private String strkeyreplacementsi="";
	  private BigDecimal nconsumableexpenses;
	  private BigDecimal nlossofpersonalbelongings;
	  private String strlossofpersonalbelongingssi="";
	  private BigDecimal nroadsideassistance;
	  private String stremergtrnsprtandhotelexpensidv="";
	  private String strratioofaoaaoy="";
	  private String stremergencytransportsiaoa="";
	  private String stremergencytransportsiaoy="";
	  private BigDecimal ndailyallowance;
	  private String straccidentallowancedays="";
	  private String strtheftallowancedays="";
	  private String strfranchisedays="";
	  private BigDecimal nreturntoinvoice;
	  private String straddonpremium="";
	  private String dtcreated="";
	  private String strcreatedby="";
	  private String dtupdated="";
	  private String strupdatedby="";
	public String getStrplanname() {
		return strplanname;
	}
	public void setStrplanname(String strplanname) {
		this.strplanname = strplanname;
	}
	public String getStrchoice() {
		return strchoice;
	}
	public void setStrchoice(String strchoice) {
		this.strchoice = strchoice;
	}
	public BigDecimal getNdepreciationreimbursement() {
		return ndepreciationreimbursement;
	}
	public void setNdepreciationreimbursement(BigDecimal ndepreciationreimbursement) {
		this.ndepreciationreimbursement = ndepreciationreimbursement;
	}
	public String getStrnoofclaims() {
		return strnoofclaims;
	}
	public void setStrnoofclaims(String strnoofclaims) {
		this.strnoofclaims = strnoofclaims;
	}
	public BigDecimal getNenginesecure() {
		return nenginesecure;
	}
	public void setNenginesecure(BigDecimal nenginesecure) {
		this.nenginesecure = nenginesecure;
	}
	public String getStrenginesecureoption() {
		return strenginesecureoption;
	}
	public void setStrenginesecureoption(String strenginesecureoption) {
		this.strenginesecureoption = strenginesecureoption;
	}
	public BigDecimal getNtyresecure() {
		return ntyresecure;
	}
	public void setNtyresecure(BigDecimal ntyresecure) {
		this.ntyresecure = ntyresecure;
	}
	public String getStrtyresecureoption() {
		return strtyresecureoption;
	}
	public void setStrtyresecureoption(String strtyresecureoption) {
		this.strtyresecureoption = strtyresecureoption;
	}
	public BigDecimal getNrepairofglassrubberplasticparts() {
		return nrepairofglassrubberplasticparts;
	}
	public void setNrepairofglassrubberplasticparts(
			BigDecimal nrepairofglassrubberplasticparts) {
		this.nrepairofglassrubberplasticparts = nrepairofglassrubberplasticparts;
	}
	public BigDecimal getNkeyreplacement() {
		return nkeyreplacement;
	}
	public void setNkeyreplacement(BigDecimal nkeyreplacement) {
		this.nkeyreplacement = nkeyreplacement;
	}
	public String getStrkeyreplacementsi() {
		return strkeyreplacementsi;
	}
	public void setStrkeyreplacementsi(String strkeyreplacementsi) {
		this.strkeyreplacementsi = strkeyreplacementsi;
	}
	public BigDecimal getNconsumableexpenses() {
		return nconsumableexpenses;
	}
	public void setNconsumableexpenses(BigDecimal nconsumableexpenses) {
		this.nconsumableexpenses = nconsumableexpenses;
	}
	public BigDecimal getNlossofpersonalbelongings() {
		return nlossofpersonalbelongings;
	}
	public void setNlossofpersonalbelongings(BigDecimal nlossofpersonalbelongings) {
		this.nlossofpersonalbelongings = nlossofpersonalbelongings;
	}
	public String getStrlossofpersonalbelongingssi() {
		return strlossofpersonalbelongingssi;
	}
	public void setStrlossofpersonalbelongingssi(
			String strlossofpersonalbelongingssi) {
		this.strlossofpersonalbelongingssi = strlossofpersonalbelongingssi;
	}
	public BigDecimal getNroadsideassistance() {
		return nroadsideassistance;
	}
	public void setNroadsideassistance(BigDecimal nroadsideassistance) {
		this.nroadsideassistance = nroadsideassistance;
	}
	public String getStremergtrnsprtandhotelexpensidv() {
		return stremergtrnsprtandhotelexpensidv;
	}
	public void setStremergtrnsprtandhotelexpensidv(
			String stremergtrnsprtandhotelexpensidv) {
		this.stremergtrnsprtandhotelexpensidv = stremergtrnsprtandhotelexpensidv;
	}
	public String getStrratioofaoaaoy() {
		return strratioofaoaaoy;
	}
	public void setStrratioofaoaaoy(String strratioofaoaaoy) {
		this.strratioofaoaaoy = strratioofaoaaoy;
	}
	public String getStremergencytransportsiaoa() {
		return stremergencytransportsiaoa;
	}
	public void setStremergencytransportsiaoa(String stremergencytransportsiaoa) {
		this.stremergencytransportsiaoa = stremergencytransportsiaoa;
	}
	public String getStremergencytransportsiaoy() {
		return stremergencytransportsiaoy;
	}
	public void setStremergencytransportsiaoy(String stremergencytransportsiaoy) {
		this.stremergencytransportsiaoy = stremergencytransportsiaoy;
	}
	public BigDecimal getNdailyallowance() {
		return ndailyallowance;
	}
	public void setNdailyallowance(BigDecimal ndailyallowance) {
		this.ndailyallowance = ndailyallowance;
	}
	public String getStraccidentallowancedays() {
		return straccidentallowancedays;
	}
	public void setStraccidentallowancedays(String straccidentallowancedays) {
		this.straccidentallowancedays = straccidentallowancedays;
	}
	public String getStrtheftallowancedays() {
		return strtheftallowancedays;
	}
	public void setStrtheftallowancedays(String strtheftallowancedays) {
		this.strtheftallowancedays = strtheftallowancedays;
	}
	public String getStrfranchisedays() {
		return strfranchisedays;
	}
	public void setStrfranchisedays(String strfranchisedays) {
		this.strfranchisedays = strfranchisedays;
	}
	public BigDecimal getNreturntoinvoice() {
		return nreturntoinvoice;
	}
	public void setNreturntoinvoice(BigDecimal nreturntoinvoice) {
		this.nreturntoinvoice = nreturntoinvoice;
	}
	public String getStraddonpremium() {
		return straddonpremium;
	}
	public void setStraddonpremium(String straddonpremium) {
		this.straddonpremium = straddonpremium;
	}
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}

}

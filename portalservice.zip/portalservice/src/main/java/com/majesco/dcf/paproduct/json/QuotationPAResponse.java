package com.majesco.dcf.paproduct.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.PremiumDetails;
import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class QuotationPAResponse {
	private String resultCode;
	private String quotenumber;
	private String quotever;
	private PremiumDetails premDet;
	private List<ResponseError> ressErr;
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getQuotenumber() {
		return quotenumber;
	}
	public void setQuotenumber(String quotenumber) {
		this.quotenumber = quotenumber;
	}
	public String getQuotever() {
		return quotever;
	}
	public void setQuotever(String quotever) {
		this.quotever = quotever;
	}
	public PremiumDetails getPremDet() {
		return premDet;
	}
	public void setPremDet(PremiumDetails premDet) {
		this.premDet = premDet;
	}
	public List<ResponseError> getRessErr() {
		return ressErr;
	}
	public void setRessErr(List<ResponseError> ressErr) {
		this.ressErr = ressErr;
	}
	
	
	
}

package com.majesco.dcf.common.tagic.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.ehcache.annotations.Cacheable;
import com.majesco.dcf.common.tagic.entity.AccFinancierBranch;
import com.majesco.dcf.common.tagic.entity.AccFinancierMaster;
//import com.majesco.dcf.common.tagic.json.AccFinancierVO_old;
import com.majesco.dcf.common.tagic.json.AccFinancierBranchRequest;
import com.majesco.dcf.common.tagic.json.AccFinancierBranchResponse;
import com.majesco.dcf.common.tagic.json.DocumentVO;
import com.majesco.dcf.common.tagic.json.ResponseError;


@Service
public class AccFinancierBranchService {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(AccFinancierBranchService.class);
	
	@SuppressWarnings("null")
	@Cacheable(cacheName="AccFinancierInfoEhcache")
	public List<? extends Object> getAccFinancierBranch(AccFinancierBranchRequest modelreq) throws Exception
	{
		//AccFinancierBranchResponse modelres = new AccFinancierBranchResponse();
		List lst = new ArrayList();
		try
		{
		
			logger.info("In ModelService.getModelInfo() Method Begin()...");
			
			List<ResponseError> reserrList = new ArrayList<ResponseError>();
			
			ResponseError res = new ResponseError();
			res.setErrorCode("101");
			res.setErrorMMessag("Sorry Authentication Issue....");
			reserrList.add(res);
			
			@SuppressWarnings("unchecked")
			List docArr = new ArrayList();
			docArr = dbserv.getAccFinancierBranch("com.majesco.dcf.common.tagic.entity.AccFinancierBranch", modelreq);
			lst = docArr;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In ModelService.getModelInfo() Method End()...");
		ObjectMapper objMap=new ObjectMapper();
		//System.out.println(objMap.writeValueAsString(lst));
		logger.info("In ModelService.getModelInfo() Method ::: "+lst);
		
		return lst;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }
}

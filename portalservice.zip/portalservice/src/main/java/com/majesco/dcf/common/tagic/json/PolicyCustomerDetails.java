package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PolicyCustomerDetails {
	
	private String dob;
	private String emailId;
	private String endDate;
	private String errorText;
	private String gender;
	private String id;
	private String ifscCode;
	private String micrCode;
	private PolicyAddressDetails lstPolAddrsDtls; 
	private String mailLocationCode;
	private String name;
	private String panNo;
	private String startDate;
	private String userId;
	private String userRole;
	private String affiliationFlag;
	private String alternateEmailId;
	private String annualIncome;
	private String blacklisted;
	private String bloodGroup;
	private String businessName;
	private String cap;
	private String chequeAcceptence;
	private String childCustomer;
	private String contactNo;
	private String contactPerson;
	private String country;
	private String countryName;
	private String customerInitials;
	private String customerStatus;
	private String customerTier;
	private String customerTierName;
	private String customerType;
	private String customerUniqueID;
	private String dbNo;
	private String deDupID;
	private String designation;
	private String doNotCall;
	private String doNotDirectory;
	private String domainname;
	private String drivingLicenseno;
	private String endTSubType;
	private String endTType;
	private String educationQualification;
	private String firstName;
	private String idProof;
	private String idProofDetails;
	private String isOffline;
	private String isUIICEmployee;
	private String industry;
	private String industryOthers;
	private String interEmpTag;
	private String isBlacklisted;
	private String isCAP;
	private String isChildCustomer;
	private String isDoNotCall;
	private String isGlobalClient;
	private String isJapaneseClient;
	private String isMAP;
	private String isParent;
	private String isPortal;
	private String isPriorityClient;
	private String isThinCustomer;
	private String lastName;
	private String map;
	private String mop;
	private String maidenName;
	private String maritalStatus;
	private String masterPinCode;
	private String middleName;
	private String modeOfCommunication;
	private String motherName;
	private String nationality;
	private String occupation;
	private String officeCode;
	private String officeExtn;
	private String officeName;
	private String pcgClient;
	private String paidUpCapital;
	private String parentCustomerCode;
	private String parentCustomerName;
	private String passportNo;
	private String paymentMode;
	private String permanentLocation;
	private String permanentLocationCode;
	private String permanentLocationSameAsMailLocation;
	private String pincodeLocality;
	private String priorityClient;
	private String productCode;
	private String proposalNo;
	private String registrationNumber;
	private String registrationOffice;
	private String remarks;
	private String role;
	private String salutation;
	private String salutationOthers;
	private String serviceTaxRegNo;
	private String sourceOfFund;
	private String tanNo;
	private String typeOfCompany;
	private String uiicEmployeeNO;
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getErrorText() {
		return errorText;
	}
	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getMicrCode() {
		return micrCode;
	}
	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}
	public PolicyAddressDetails getLstPolAddrsDtls() {
		return lstPolAddrsDtls;
	}
	public void setLstPolAddrsDtls(PolicyAddressDetails lstPolAddrsDtls) {
		this.lstPolAddrsDtls = lstPolAddrsDtls;
	}
	public String getMailLocationCode() {
		return mailLocationCode;
	}
	public void setMailLocationCode(String mailLocationCode) {
		this.mailLocationCode = mailLocationCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getAffiliationFlag() {
		return affiliationFlag;
	}
	public void setAffiliationFlag(String affiliationFlag) {
		this.affiliationFlag = affiliationFlag;
	}
	public String getAlternateEmailId() {
		return alternateEmailId;
	}
	public void setAlternateEmailId(String alternateEmailId) {
		this.alternateEmailId = alternateEmailId;
	}
	public String getAnnualIncome() {
		return annualIncome;
	}
	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}
	public String getBlacklisted() {
		return blacklisted;
	}
	public void setBlacklisted(String blacklisted) {
		this.blacklisted = blacklisted;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getCap() {
		return cap;
	}
	public void setCap(String cap) {
		this.cap = cap;
	}
	public String getChequeAcceptence() {
		return chequeAcceptence;
	}
	public void setChequeAcceptence(String chequeAcceptence) {
		this.chequeAcceptence = chequeAcceptence;
	}
	public String getChildCustomer() {
		return childCustomer;
	}
	public void setChildCustomer(String childCustomer) {
		this.childCustomer = childCustomer;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getCustomerInitials() {
		return customerInitials;
	}
	public void setCustomerInitials(String customerInitials) {
		this.customerInitials = customerInitials;
	}
	public String getCustomerStatus() {
		return customerStatus;
	}
	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}
	public String getCustomerTier() {
		return customerTier;
	}
	public void setCustomerTier(String customerTier) {
		this.customerTier = customerTier;
	}
	public String getCustomerTierName() {
		return customerTierName;
	}
	public void setCustomerTierName(String customerTierName) {
		this.customerTierName = customerTierName;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getCustomerUniqueID() {
		return customerUniqueID;
	}
	public void setCustomerUniqueID(String customerUniqueID) {
		this.customerUniqueID = customerUniqueID;
	}
	public String getDbNo() {
		return dbNo;
	}
	public void setDbNo(String dbNo) {
		this.dbNo = dbNo;
	}
	public String getDeDupID() {
		return deDupID;
	}
	public void setDeDupID(String deDupID) {
		this.deDupID = deDupID;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDoNotCall() {
		return doNotCall;
	}
	public void setDoNotCall(String doNotCall) {
		this.doNotCall = doNotCall;
	}
	public String getDoNotDirectory() {
		return doNotDirectory;
	}
	public void setDoNotDirectory(String doNotDirectory) {
		this.doNotDirectory = doNotDirectory;
	}
	public String getDomainname() {
		return domainname;
	}
	public void setDomainname(String domainname) {
		this.domainname = domainname;
	}
	public String getDrivingLicenseno() {
		return drivingLicenseno;
	}
	public void setDrivingLicenseno(String drivingLicenseno) {
		this.drivingLicenseno = drivingLicenseno;
	}
	public String getEndTSubType() {
		return endTSubType;
	}
	public void setEndTSubType(String endTSubType) {
		this.endTSubType = endTSubType;
	}
	public String getEndTType() {
		return endTType;
	}
	public void setEndTType(String endTType) {
		this.endTType = endTType;
	}
	public String getEducationQualification() {
		return educationQualification;
	}
	public void setEducationQualification(String educationQualification) {
		this.educationQualification = educationQualification;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getIdProof() {
		return idProof;
	}
	public void setIdProof(String idProof) {
		this.idProof = idProof;
	}
	public String getIdProofDetails() {
		return idProofDetails;
	}
	public void setIdProofDetails(String idProofDetails) {
		this.idProofDetails = idProofDetails;
	}
	public String getIsOffline() {
		return isOffline;
	}
	public void setIsOffline(String isOffline) {
		this.isOffline = isOffline;
	}
	public String getIsUIICEmployee() {
		return isUIICEmployee;
	}
	public void setIsUIICEmployee(String isUIICEmployee) {
		this.isUIICEmployee = isUIICEmployee;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getIndustryOthers() {
		return industryOthers;
	}
	public void setIndustryOthers(String industryOthers) {
		this.industryOthers = industryOthers;
	}
	public String getInterEmpTag() {
		return interEmpTag;
	}
	public void setInterEmpTag(String interEmpTag) {
		this.interEmpTag = interEmpTag;
	}
	public String getIsBlacklisted() {
		return isBlacklisted;
	}
	public void setIsBlacklisted(String isBlacklisted) {
		this.isBlacklisted = isBlacklisted;
	}
	public String getIsCAP() {
		return isCAP;
	}
	public void setIsCAP(String isCAP) {
		this.isCAP = isCAP;
	}
	public String getIsChildCustomer() {
		return isChildCustomer;
	}
	public void setIsChildCustomer(String isChildCustomer) {
		this.isChildCustomer = isChildCustomer;
	}
	public String getIsDoNotCall() {
		return isDoNotCall;
	}
	public void setIsDoNotCall(String isDoNotCall) {
		this.isDoNotCall = isDoNotCall;
	}
	public String getIsGlobalClient() {
		return isGlobalClient;
	}
	public void setIsGlobalClient(String isGlobalClient) {
		this.isGlobalClient = isGlobalClient;
	}
	public String getIsJapaneseClient() {
		return isJapaneseClient;
	}
	public void setIsJapaneseClient(String isJapaneseClient) {
		this.isJapaneseClient = isJapaneseClient;
	}
	public String getIsMAP() {
		return isMAP;
	}
	public void setIsMAP(String isMAP) {
		this.isMAP = isMAP;
	}
	public String getIsParent() {
		return isParent;
	}
	public void setIsParent(String isParent) {
		this.isParent = isParent;
	}
	public String getIsPortal() {
		return isPortal;
	}
	public void setIsPortal(String isPortal) {
		this.isPortal = isPortal;
	}
	public String getIsPriorityClient() {
		return isPriorityClient;
	}
	public void setIsPriorityClient(String isPriorityClient) {
		this.isPriorityClient = isPriorityClient;
	}
	public String getIsThinCustomer() {
		return isThinCustomer;
	}
	public void setIsThinCustomer(String isThinCustomer) {
		this.isThinCustomer = isThinCustomer;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMap() {
		return map;
	}
	public void setMap(String map) {
		this.map = map;
	}
	public String getMop() {
		return mop;
	}
	public void setMop(String mop) {
		this.mop = mop;
	}
	public String getMaidenName() {
		return maidenName;
	}
	public void setMaidenName(String maidenName) {
		this.maidenName = maidenName;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getMasterPinCode() {
		return masterPinCode;
	}
	public void setMasterPinCode(String masterPinCode) {
		this.masterPinCode = masterPinCode;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getModeOfCommunication() {
		return modeOfCommunication;
	}
	public void setModeOfCommunication(String modeOfCommunication) {
		this.modeOfCommunication = modeOfCommunication;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getOfficeCode() {
		return officeCode;
	}
	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}
	public String getOfficeExtn() {
		return officeExtn;
	}
	public void setOfficeExtn(String officeExtn) {
		this.officeExtn = officeExtn;
	}
	public String getOfficeName() {
		return officeName;
	}
	public void setOfficeName(String officeName) {
		this.officeName = officeName;
	}
	public String getPcgClient() {
		return pcgClient;
	}
	public void setPcgClient(String pcgClient) {
		this.pcgClient = pcgClient;
	}
	public String getPaidUpCapital() {
		return paidUpCapital;
	}
	public void setPaidUpCapital(String paidUpCapital) {
		this.paidUpCapital = paidUpCapital;
	}
	public String getParentCustomerCode() {
		return parentCustomerCode;
	}
	public void setParentCustomerCode(String parentCustomerCode) {
		this.parentCustomerCode = parentCustomerCode;
	}
	public String getParentCustomerName() {
		return parentCustomerName;
	}
	public void setParentCustomerName(String parentCustomerName) {
		this.parentCustomerName = parentCustomerName;
	}
	public String getPassportNo() {
		return passportNo;
	}
	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getPermanentLocation() {
		return permanentLocation;
	}
	public void setPermanentLocation(String permanentLocation) {
		this.permanentLocation = permanentLocation;
	}
	public String getPermanentLocationCode() {
		return permanentLocationCode;
	}
	public void setPermanentLocationCode(String permanentLocationCode) {
		this.permanentLocationCode = permanentLocationCode;
	}
	public String getPermanentLocationSameAsMailLocation() {
		return permanentLocationSameAsMailLocation;
	}
	public void setPermanentLocationSameAsMailLocation(String permanentLocationSameAsMailLocation) {
		this.permanentLocationSameAsMailLocation = permanentLocationSameAsMailLocation;
	}
	public String getPincodeLocality() {
		return pincodeLocality;
	}
	public void setPincodeLocality(String pincodeLocality) {
		this.pincodeLocality = pincodeLocality;
	}
	public String getPriorityClient() {
		return priorityClient;
	}
	public void setPriorityClient(String priorityClient) {
		this.priorityClient = priorityClient;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getRegistrationNumber() {
		return registrationNumber;
	}
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}
	public String getRegistrationOffice() {
		return registrationOffice;
	}
	public void setRegistrationOffice(String registrationOffice) {
		this.registrationOffice = registrationOffice;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getSalutation() {
		return salutation;
	}
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}
	public String getSalutationOthers() {
		return salutationOthers;
	}
	public void setSalutationOthers(String salutationOthers) {
		this.salutationOthers = salutationOthers;
	}
	public String getServiceTaxRegNo() {
		return serviceTaxRegNo;
	}
	public void setServiceTaxRegNo(String serviceTaxRegNo) {
		this.serviceTaxRegNo = serviceTaxRegNo;
	}
	public String getSourceOfFund() {
		return sourceOfFund;
	}
	public void setSourceOfFund(String sourceOfFund) {
		this.sourceOfFund = sourceOfFund;
	}
	public String getTanNo() {
		return tanNo;
	}
	public void setTanNo(String tanNo) {
		this.tanNo = tanNo;
	}
	public String getTypeOfCompany() {
		return typeOfCompany;
	}
	public void setTypeOfCompany(String typeOfCompany) {
		this.typeOfCompany = typeOfCompany;
	}
	public String getUiicEmployeeNO() {
		return uiicEmployeeNO;
	}
	public void setUiicEmployeeNO(String uiicEmployeeNO) {
		this.uiicEmployeeNO = uiicEmployeeNO;
	}

	
	
	
}

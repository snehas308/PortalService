package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class GarageRadiusResponse {
	private List<String> address;
	private List<String> nlongitude;
	private List<String> nlatitude;
	private List<ResponseError> resErr;
	
	public List<String> getAddress() {
		return address;
	}
	public void setAddress(List<String> address) {
		this.address = address;
	}
	public List<String> getNlongitude() {
		return nlongitude;
	}
	public void setNlongitude(List<String> nlongitude) {
		this.nlongitude = nlongitude;
	}
	public List<String> getNlatitude() {
		return nlatitude;
	}
	public void setNlatitude(List<String> nlatitude) {
		this.nlatitude = nlatitude;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
}

package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.googlecode.ehcache.annotations.Cacheable;
import com.majesco.dcf.common.tagic.entity.OfficeMaster;
import com.majesco.dcf.common.tagic.entity.SpMaster;
import com.majesco.dcf.common.tagic.json.DealerMasterResponse;
import com.majesco.dcf.common.tagic.json.OfficeMasterRequest;
import com.majesco.dcf.common.tagic.json.OfficeMasterResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.json.SpDetails;
import com.majesco.dcf.common.tagic.json.SpMasterRequest;
import com.majesco.dcf.common.tagic.json.SpMasterResponse;
import com.majesco.dcf.common.tagic.json.UserObject;
import com.majesco.dcf.usermgmt.json.UserDetails;
import com.majesco.dcf.usermgmt.json.UserInfoResponse;
import com.majesco.dcf.usermgmt.service.UserService;

@Service
public class SpMasterService {
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(OfficeMasterService.class);
	
	@Autowired
	UserService userService;
	
	@SuppressWarnings({ "null", "unchecked" })
	@Cacheable(cacheName="spMasterInfoEhcache")
	public SpMasterResponse getSpMaster(SpMasterRequest spreq) throws Exception
	{
		SpMasterResponse spres = new SpMasterResponse();
		ArrayList docArr = new ArrayList();
		try
		{
		
			logger.info("In SpMasterService.getSpMaster() Method Begin()...");
			List<SpDetails> spDetailsList = new ArrayList<SpDetails>();						
			List<ResponseError> reserrList = new ArrayList<ResponseError>();					
			ResponseError res = new ResponseError();			
			reserrList.add(res);
							
			StopWatch watch_OfcMstDB = new StopWatch();
			watch_OfcMstDB.start();
			docArr = (ArrayList<Object>) dbserv.getSpMaster("com.majesco.dcf.common.tagic.entity.SpMaster",spreq.getProducerCode());
			for(int i=0; i< docArr.size(); i++)
			{
		        SpMaster ent = new SpMaster();
		        ent = (SpMaster) docArr.get(i);
		        if(ent!=null){
		        	SpDetails details = new SpDetails();
			        details.setSpNo(ent.getTxt_sp_cert_no());
			        details.setSpName(ent.getTxt_sp_name());
			        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			        
			        String dt = ent.getDat_end_date().toString(); 
					SimpleDateFormat sdfDat=new SimpleDateFormat("dd/MM/yyyy", Locale.US);
					SimpleDateFormat sdfDateIssue=new SimpleDateFormat("yyyy-MM-dd", Locale.US);
					logger.info("Date to be send to UI :- "+sdfDat.format(sdfDateIssue.parse(dt)));
			        
			        
			        details.setDat_end_date(sdfDat.format(sdfDateIssue.parse(dt)));
			        details.setTxt_status(ent.getTxt_status());
			        spDetailsList.add(details);	
		        }		        
	        }
			watch_OfcMstDB.stop();
			logger.info("Time Taken by SpMasterService--> getSpMaster--> getSPMasterDB service in seconds..>>"+watch_OfcMstDB.getTotalTimeSeconds());
			spres.setSpDetailsList(spDetailsList);			
		}
		catch(Exception e)
		{			
			logger.info("Exception StackTrace : ", e);
		}		
		logger.info("In SpMasterService.getSpMaster() Method :: Response Of variantres : "+spres);		
		return spres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }


}

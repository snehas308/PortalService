package com.majesco.dcf.policyservicing.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.policyservicing.json.DCFIncidentCreationRequest;
import com.majesco.dcf.policyservicing.json.DCFIncidentCreationResult;

@Service
@Transactional
public interface PolicyServicingService {
	
	public DCFIncidentCreationResult fileUploadToOnyx(DCFIncidentCreationRequest incidentReq) throws Exception;

}

package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class CreateCustomerRequest extends UserObject{

	
	private String customerType;
	private String pancardNum;
	//private String authenticationToken; 
	private CustomerDetails customerDet;
	
	//Start: @Yogesh added isCustModified flag for DefectID-1841 31/08/2017 
	private String isCustModified;
	//End: @Yogesh added isCustModified flag for DefectID-1841 31/08/2017
	
	public String getCustomerType() {
		return customerType;
	}
	public CustomerDetails getCustomerDet() {
		return customerDet;
	}
	public void setCustomerDet(CustomerDetails customerDet) {
		this.customerDet = customerDet;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getPancardNum() {
		return pancardNum;
	}
	public void setPancardNum(String pancardNum) {
		this.pancardNum = pancardNum;
	}
//	public String getAuthenticationToken() {
//		return authenticationToken;
//	}
//	public void setAuthenticationToken(String authenticationToken) {
//		this.authenticationToken = authenticationToken;
//	}
	
	//Start: @Yogesh added isCustModified flag for DefectID-1841 31/08/2017 
	public String getIsCustModified() {
		return isCustModified;
	}
	public void setIsCustModified(String isCustModified) {
		this.isCustModified = isCustModified;
	}
	//End: @Yogesh added isCustModified flag for DefectID-1841 31/08/2017 
	
}

package com.majesco.dcf.common.tagic.json;

public class PendingProposalLOVType {
	
	private String startDate;
	private String startTime;
	private String applicationNo;
	private String certificateNo;
	private String chassisNo;
	private String claimAmount;
	private String claimNo;
	private String claimStatus;
	private String collectionMode;
	private String covernoteNo;	
	private String covernoteStatus;
	private String customer;
	private String customerCode;
	private String customerName;
	private String declinedStatus;
	private String departmentCode;
	private String engineNo;
	private String insuredName;
	private String lOBName;
	private String lastPaymentDate;
	private String manualCoverNoteNo;
	private String migratedPolicyNo;
	private String modeOfOperation;
	private String netPremium;
	private String officeCode;
	private String openCovernote;
	private String origin;
	private String paymentDate;
	private String paymentGatewayTransactionDate;
	private String paymentGatewayTransactionId;
	private String paymentId;
	private String policyEndDate;
	private String policyNo;
	private String policyStartDate;
	private String policyType;
	private String productCode;
	private String productName;
	private String proposalDate;
	private String proposalNo;
	private String qcStatus;
	private String receiptDate;
	private String receiptMode;
	private String receiptNo;
	private String renewalDate;
	private String renewalStatus;
	private String requestStatus;
	private String serialNo;
	private String serviceTax;
	private String status;
	private String statusCode;
	private String sumInsured;
	private String totalPremium;
	private String transactionType;
	private String vehicleInspectionStatus;
	private String vehicleManufacturer;
	private String vehicleModel;
	private String vehicleRegistrationAddress;
	private String vehicleRegistrationNo;
	private String workflowID;
	
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getApplicationNo() {
		return applicationNo;
	}
	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}
	public String getCertificateNo() {
		return certificateNo;
	}
	public void setCertificateNo(String certificateNo) {
		this.certificateNo = certificateNo;
	}
	public String getChassisNo() {
		return chassisNo;
	}
	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}
	public String getClaimAmount() {
		return claimAmount;
	}
	public void setClaimAmount(String claimAmount) {
		this.claimAmount = claimAmount;
	}
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public String getClaimStatus() {
		return claimStatus;
	}
	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}
	public String getCollectionMode() {
		return collectionMode;
	}
	public void setCollectionMode(String collectionMode) {
		this.collectionMode = collectionMode;
	}
	public String getCovernoteNo() {
		return covernoteNo;
	}
	public void setCovernoteNo(String covernoteNo) {
		this.covernoteNo = covernoteNo;
	}
	public String getCovernoteStatus() {
		return covernoteStatus;
	}
	public void setCovernoteStatus(String covernoteStatus) {
		this.covernoteStatus = covernoteStatus;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDeclinedStatus() {
		return declinedStatus;
	}
	public void setDeclinedStatus(String declinedStatus) {
		this.declinedStatus = declinedStatus;
	}
	public String getDepartmentCode() {
		return departmentCode;
	}
	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}
	public String getEngineNo() {
		return engineNo;
	}
	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}
	public String getlOBName() {
		return lOBName;
	}
	public void setlOBName(String lOBName) {
		this.lOBName = lOBName;
	}
	public String getLastPaymentDate() {
		return lastPaymentDate;
	}
	public void setLastPaymentDate(String lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}
	public String getManualCoverNoteNo() {
		return manualCoverNoteNo;
	}
	public void setManualCoverNoteNo(String manualCoverNoteNo) {
		this.manualCoverNoteNo = manualCoverNoteNo;
	}
	public String getMigratedPolicyNo() {
		return migratedPolicyNo;
	}
	public void setMigratedPolicyNo(String migratedPolicyNo) {
		this.migratedPolicyNo = migratedPolicyNo;
	}
	public String getModeOfOperation() {
		return modeOfOperation;
	}
	public void setModeOfOperation(String modeOfOperation) {
		this.modeOfOperation = modeOfOperation;
	}
	public String getNetPremium() {
		return netPremium;
	}
	public void setNetPremium(String netPremium) {
		this.netPremium = netPremium;
	}
	public String getOfficeCode() {
		return officeCode;
	}
	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}
	public String getOpenCovernote() {
		return openCovernote;
	}
	public void setOpenCovernote(String openCovernote) {
		this.openCovernote = openCovernote;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getPaymentGatewayTransactionDate() {
		return paymentGatewayTransactionDate;
	}
	public void setPaymentGatewayTransactionDate(
			String paymentGatewayTransactionDate) {
		this.paymentGatewayTransactionDate = paymentGatewayTransactionDate;
	}
	public String getPaymentGatewayTransactionId() {
		return paymentGatewayTransactionId;
	}
	public void setPaymentGatewayTransactionId(String paymentGatewayTransactionId) {
		this.paymentGatewayTransactionId = paymentGatewayTransactionId;
	}
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	public String getPolicyEndDate() {
		return policyEndDate;
	}
	public void setPolicyEndDate(String policyEndDate) {
		this.policyEndDate = policyEndDate;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getPolicyStartDate() {
		return policyStartDate;
	}
	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProposalDate() {
		return proposalDate;
	}
	public void setProposalDate(String proposalDate) {
		this.proposalDate = proposalDate;
	}
	public String getProposalNo() {
		return proposalNo;
	}
	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}
	public String getQcStatus() {
		return qcStatus;
	}
	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}
	public String getReceiptDate() {
		return receiptDate;
	}
	public void setReceiptDate(String receiptDate) {
		this.receiptDate = receiptDate;
	}
	public String getReceiptMode() {
		return receiptMode;
	}
	public void setReceiptMode(String receiptMode) {
		this.receiptMode = receiptMode;
	}
	public String getReceiptNo() {
		return receiptNo;
	}
	public void setReceiptNo(String receiptNo) {
		this.receiptNo = receiptNo;
	}
	public String getRenewalDate() {
		return renewalDate;
	}
	public void setRenewalDate(String renewalDate) {
		this.renewalDate = renewalDate;
	}
	public String getRenewalStatus() {
		return renewalStatus;
	}
	public void setRenewalStatus(String renewalStatus) {
		this.renewalStatus = renewalStatus;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getServiceTax() {
		return serviceTax;
	}
	public void setServiceTax(String serviceTax) {
		this.serviceTax = serviceTax;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getSumInsured() {
		return sumInsured;
	}
	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}
	public String getTotalPremium() {
		return totalPremium;
	}
	public void setTotalPremium(String totalPremium) {
		this.totalPremium = totalPremium;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getVehicleInspectionStatus() {
		return vehicleInspectionStatus;
	}
	public void setVehicleInspectionStatus(String vehicleInspectionStatus) {
		this.vehicleInspectionStatus = vehicleInspectionStatus;
	}
	public String getVehicleManufacturer() {
		return vehicleManufacturer;
	}
	public void setVehicleManufacturer(String vehicleManufacturer) {
		this.vehicleManufacturer = vehicleManufacturer;
	}
	public String getVehicleModel() {
		return vehicleModel;
	}
	public void setVehicleModel(String vehicleModel) {
		this.vehicleModel = vehicleModel;
	}
	public String getVehicleRegistrationAddress() {
		return vehicleRegistrationAddress;
	}
	public void setVehicleRegistrationAddress(String vehicleRegistrationAddress) {
		this.vehicleRegistrationAddress = vehicleRegistrationAddress;
	}
	public String getVehicleRegistrationNo() {
		return vehicleRegistrationNo;
	}
	public void setVehicleRegistrationNo(String vehicleRegistrationNo) {
		this.vehicleRegistrationNo = vehicleRegistrationNo;
	}
	public String getWorkflowID() {
		return workflowID;
	}
	public void setWorkflowID(String workflowID) {
		this.workflowID = workflowID;
	}
	

	
	
}

package com.majesco.dcf.claims.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PolicySearchCoverNoteResponse 
{
	private String policyNumber;
	private String resultCode;
	private List<ResponseError> resErr;

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public List<ResponseError> getResErr() {
		return resErr;
	}

	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	
	

}

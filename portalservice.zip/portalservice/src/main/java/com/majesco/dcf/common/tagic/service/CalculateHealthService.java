package com.majesco.dcf.common.tagic.service;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.controller.CalculateHealthController;
import com.majesco.dcf.common.tagic.json.CalculateHealthRequest;
import com.majesco.dcf.common.tagic.json.CalculateHealthResponse;

@Service
public class CalculateHealthService {
	
	final static Logger logger = Logger.getLogger(CalculateHealthService.class);

	public CalculateHealthResponse getQuote(CalculateHealthRequest QuickQuote)
	{
		int a = QuickQuote.getNum1().intValue();
		int b = QuickQuote.getNum2().intValue();
		int c = a+b;
		
		logger.info("Inside CalculateHealthService :: getQuote method :: Execution Started");
		
		CalculateHealthResponse quicre = new  CalculateHealthResponse(); 
		quicre.setNum3(c);
		
		logger.info("Inside CalculateHealthService :: getQuote method :: Execution Completed Successfully");
		
		return quicre;
	}

}

package com.majesco.dcf.common.tagic.service;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.namespace.QName;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.majesco.dcf.common.tagic.entity.DocumentMaster;
import com.majesco.dcf.common.tagic.json.DocListRequest;
import com.majesco.dcf.common.tagic.json.DocListResponse;
import com.majesco.dcf.common.tagic.json.DocumentListGCRequest;
import com.majesco.dcf.common.tagic.json.DocumentListGCResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.common.tagic.util.ServiceUtility;
import com.majesco.dcf.constant.CommonConstants;
import com.unotechsoft.stub.commonservice.proppoldocument.client.ClsUWDocServiceResult;
import com.unotechsoft.stub.commonservice.proppoldocument.client.ServiceResult;

@Service
public class DocListService {
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(DocListService.class);
	
	/*Added For Internal Source-Medium-Campaign Property File Change - Starts Here - 15/06/2017*/
	@Value("${smc.source}")
	private String smc_source;
	
	@Value("${smc.medium}")
	private String smc_medium;
	
	@Value("${smc.campaign}")
	private String smc_campaign;
	/*Added For Internal Source-Medium-Campaign Property File Change - Ends Here - 15/06/2017*/
	
	@SuppressWarnings({ "null", "unchecked" })
	public DocListResponse getDocList(DocListRequest docreq) throws Exception
	{
		DocListResponse docres = new DocListResponse();
		ArrayList docArr = new ArrayList();
		try
		{
		
			logger.info("In DocumentService.FetchDocumentInfo() Method Begin()...");
			
			
			List<String> lstStrdcodesc = new ArrayList<String>();
			List<String> lstStrstrdoccd = new ArrayList<String>();
					
			
			
			List<ResponseError> reserrList = new ArrayList<ResponseError>();
			
			
			ResponseError res = new ResponseError();
			res.setErrorCode("101");
			res.setErrorMMessag("Sorry Authentication Issue....");
			reserrList.add(res);
			
	
			//docArr = (ArrayList) dbserv.getDocList("com.majesco.dcf.common.tagic.entity.DocumentMaster", docreq);
			List<DocumentMaster> idvList =  (List<DocumentMaster>) dbserv.getDocList("com.majesco.dcf.common.tagic.entity.DocumentMaster", docreq);
	        for(DocumentMaster idv:idvList){
	        
	        	lstStrstrdoccd.add(idv.getStrdoccd());
				lstStrdcodesc.add(idv.getStrdcodesc());
	        }
			/*for(int i=0; i< docArr.size(); i++)
			{
				
				lstStrstrdoccd.add(docres.getStrdoccd());
				lstStrdcodesc.add(docres.getStrdcodesc());
		        		        
	        }*/
			docres.setStrdcodesc(lstStrdcodesc);
			docres.setStrdoccd(lstStrstrdoccd);
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In DocumentService.DocumentInfo() Method End()...");
//		ObjectMapper objMap=new ObjectMapper();
//		System.out.println(objMap.writeValueAsString(docres));
		logger.info("In DocumentService.DocumentInfo() Method :: Response Of variantres : "+docres);
		
		return docres;
	}
	
	public List<DocumentListGCResponse> getDocumentListGC(DocumentListGCRequest request) throws Exception{
		String wsdlUrl="";
		String breakIn = null;
		String NCBData = "No";
		String antiTheft = "No";
		DocumentListGCResponse response = null;
		List<DocumentListGCResponse> documentResponseList = new ArrayList<DocumentListGCResponse>();
		try{
			wsdlUrl = getWSDLURL(CommonConstants.PRINT_PROP_POL_DOCUMENT_SERVICE);
			URL serviceUrl=new URL(wsdlUrl);
			
			final QName SERVICE_NAME = new QName("http://stub.unotechsoft.com/wsdl/GetDocumentForPortalService/", "GetDocumentForPortalService");
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service ss = new com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService_Service(serviceUrl, SERVICE_NAME);
			com.unotechsoft.stub.commonservice.proppoldocument.client.GetDocumentForPortalService port = ss.getSOAPOverHTTP();
			
			ServiceUtility util=new ServiceUtility();
			util.addClientInterceptor(port);
			
			//Code to generate Applicable document PropType=new business$BI=L90$NCB=No$ATCode=NO
			StringBuffer applicableDocs = new StringBuffer();
			applicableDocs.append("PropType=new business$BI=");
			// For breakins
			if (request.getBusinessType()!=null && (request.getBusinessType().equals(CommonConstants.DOCUMENTLIST_NEW)
					|| request.getBusinessType().equals(CommonConstants.DOCUMENTLIST_USEDCAR))){
				SimpleDateFormat sdfDateChk = new SimpleDateFormat("dd/MM/yyyy");
				Date vehicleDate = sdfDateChk.parse(request.getVehicleDate());
				Date policyInceptionDate = sdfDateChk.parse(request.getPolicyStartDate());
				int days = daysBetween(vehicleDate, policyInceptionDate);
				// Start : 186 : Vishal J : 02-Feb-2018
				if (days <= 90 && days >0){
					breakIn = "L90";		//RahulT| Mantis #186  
				}else if(days >= 90){
					breakIn = "M90";
				}else{
					breakIn = "No";
				}
				// Start : 186 : Vishal J : 02-Feb-2018
			}
			else if (request.getBusinessType()!=null && (request.getBusinessType().equals(CommonConstants.DOCUMENTLIST_ROLLOVER)
					|| request.getBusinessType().equals(CommonConstants.DOCUMENTLIST_RENEWAL))){
				SimpleDateFormat sdfDateChk = new SimpleDateFormat("dd/MM/yyyy");
				Date prevPolExpDate = sdfDateChk.parse(request.getPrevPolExpiryDate());
				Date d2 = new Date();
				String dt2 = sdfDateChk.format(d2);
				Date currentDate = sdfDateChk.parse(dt2);
				int days = daysBetween(prevPolExpDate, currentDate);
				logger.info(" --> ");
				// Start : 186 : Vishal J : 01-Feb-2018
				if (days <= 90 && days >0){
					breakIn = "L90";		//RahulT| Mantis #186  
				}
				else if(days >= 90){
					breakIn = "M90";
				}else{
					breakIn = "No";
				}
				// End : 186 : Vishal J : 01-Feb-2018
			}
			
			applicableDocs.append(breakIn);
			applicableDocs.append("$NCB=No$ATCode=");
			if (request.getAntiTheftFlag()!=null && request.getAntiTheftFlag().equalsIgnoreCase("true"))
				antiTheft = "Yes";
			applicableDocs.append(antiTheft);									
			
			String _source = smc_source;
			String _medium = smc_medium;
			String _campaign = smc_campaign;
			String _strAuthToken = request.getAuthToken();
			String _strReferenceNo ="";
			if (request.getReferenceNo()!=null && !request.getReferenceNo().equals(""))
				_strReferenceNo = request.getReferenceDt();
			String _strRefDate = "";
			if (request.getReferenceDt()!=null && !request.getReferenceDt().equals(""))
				_strRefDate = request.getReferenceDt(); 
			String _strBlockId ="0";
			String _strProductCode ="";
			if (request.getProductCode()!=null && !request.getProductCode().equals(""))
				_strProductCode = request.getProductCode();
			String _strModeOfoperation ="NEWPOLICY";
			String _strEndorsementCode ="0";
			String _strBusinessType = "";
			String _strApplicableDocs = applicableDocs.toString();
			String _strCoverNoteNo ="";
			if (request.getCoverNoteNo()!=null && !request.getCoverNoteNo().equals(""))
				_strCoverNoteNo = request.getCoverNoteNo();
			String _strRsnForCancellation ="";
			String _strCallLevel ="PORTAL";
			
			//Start : 03-May-2017 : Code for _strModeOfoperation , _strBusinessType
			if (request.getBusinessType()!=null && (request.getBusinessType().equals(CommonConstants.DOCUMENTLIST_NEW))){
				_strModeOfoperation  = "NEWPOLICY";
				_strBusinessType = "New Business";
			}else if (request.getBusinessType()!=null && (request.getBusinessType().equals(CommonConstants.DOCUMENTLIST_ROLLOVER))){
				_strModeOfoperation  = "ROLLOVER";
				_strBusinessType = "Roll Over";
			}else if (request.getBusinessType()!=null && (request.getBusinessType().equals(CommonConstants.DOCUMENTLIST_USEDCAR))){
				_strModeOfoperation  = "NEWPOLICY";
				_strBusinessType = "Used Car";
			}else if (request.getBusinessType()!=null && (request.getBusinessType().equals(CommonConstants.DOCUMENTLIST_RENEWAL))){
				_strModeOfoperation  = "RENEWPOLICY";
				_strBusinessType = "Renewal Business";				
			}
			
			if(request.getPropModificationFlag()!=null && request.getPropModificationFlag().equalsIgnoreCase("true")){
				_strModeOfoperation  = "PROPOSALMODIFICATION";				
			}else if(request.getIsRenew()!=null && request.getIsRenew().equalsIgnoreCase("true")){
				_strModeOfoperation  = "RENEWPOLICY";
			}			
			//End : 03-May-2017 : Code for _strModeOfoperation , _strBusinessType			
			ServiceResult _response = port.getDocumentDetails(_source, _medium, _campaign, _strAuthToken, _strReferenceNo, _strRefDate, _strBlockId, _strProductCode, _strModeOfoperation, _strEndorsementCode, _strBusinessType, _strApplicableDocs, _strCoverNoteNo, _strRsnForCancellation, _strCallLevel);
			
			if (_response!=null && _response.getUserData()!=null && _response.getUserData().getUWDocDtlsGrid()!=null && _response.getUserData().getUWDocDtlsGrid().getClsUWDocServiceResult()!= null 
					&& !_response.getUserData().getUWDocDtlsGrid().getClsUWDocServiceResult().isEmpty()){
				List<ClsUWDocServiceResult> docListResult = _response.getUserData().getUWDocDtlsGrid().getClsUWDocServiceResult();
				
				for (ClsUWDocServiceResult documentObject : docListResult){
					response = new DocumentListGCResponse();
					response.setDocumentName(documentObject.getDocName());
					response.setDocumentcode(""+documentObject.getDocCode());
					response.setIsDocumentReceived(""+documentObject.getIsReceived());
					response.setIsDocumentRequired(""+documentObject.getIsRequired());
					response.setIsDocumentWaived(""+documentObject.getIsWaived());
					response.setDocumentSeries(""+documentObject.getDocSerialNo());
					documentResponseList.add(response);
				}
			}
		}
		catch(Exception ex){
			logger.error("Exception In::DocListService::getDocumentListGC --> ", ex);
		}
		finally{
			
		}
		return documentResponseList;
	}
	
	private String getWSDLURL(String param)
	{
		String wsdlUrl=null;
		try
		{
			wsdlUrl = dbserv.getWSDLURL(param,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			return wsdlUrl;
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorServiceImpl :: getWSDLURL() method ::",ae);
		}
		return wsdlUrl;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }
    
    public int daysBetween(Date pastDate, Date currentDate){
        return (int)( (currentDate.getTime() - pastDate.getTime()) / (1000 * 60 * 60 * 24));
}
}

package com.majesco.dcf.motor.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PremiumBreakup {


private String premiumBrk;
private List<SummarySection> summSection;
public String getPremiumBrk() {
	return premiumBrk;
}
public void setPremiumBrk(String premiumBrk) {
	this.premiumBrk = premiumBrk;
}
public List<SummarySection> getSummSection() {
	return summSection;
}
public void setSummSection(List<SummarySection> summSection) {
	this.summSection = summSection;
}

}

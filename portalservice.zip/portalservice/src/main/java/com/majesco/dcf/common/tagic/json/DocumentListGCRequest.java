package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocumentListGCRequest extends UserObject{
	private String referenceNo;
	private String referenceDt;
	private String businessType;	//new business,used car,renewal,rollover
	private String endorsementCode;
	private String policyStartDate;
	private String prevPolExpiryDate;
	private String vehicleDate;
	private String productCode;
	private String coverNoteNo;
	private String antiTheftFlag;
	private String propModificationFlag;
	private String isRenew;
	
	
	
	public String getIsRenew() {
		return isRenew;
	}
	public void setIsRenew(String isRenew) {
		this.isRenew = isRenew;
	}
	public String getPropModificationFlag() {
		return propModificationFlag;
	}
	public void setPropModificationFlag(String propModificationFlag) {
		this.propModificationFlag = propModificationFlag;
	}
	public String getReferenceNo() {
		return referenceNo;
	}
	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}
	public String getReferenceDt() {
		return referenceDt;
	}
	public void setReferenceDt(String referenceDt) {
		this.referenceDt = referenceDt;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getEndorsementCode() {
		return endorsementCode;
	}
	public void setEndorsementCode(String endorsementCode) {
		this.endorsementCode = endorsementCode;
	}
	public String getPolicyStartDate() {
		return policyStartDate;
	}
	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}
	public String getPrevPolExpiryDate() {
		return prevPolExpiryDate;
	}
	public void setPrevPolExpiryDate(String prevPolExpiryDate) {
		this.prevPolExpiryDate = prevPolExpiryDate;
	}
	
	
	public String getVehicleDate() {
		return vehicleDate;
	}
	public void setVehicleDate(String vehicleDate) {
		this.vehicleDate = vehicleDate;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getCoverNoteNo() {
		return coverNoteNo;
	}
	public void setCoverNoteNo(String coverNoteNo) {
		this.coverNoteNo = coverNoteNo;
	}
	public String getAntiTheftFlag() {
		return antiTheftFlag;
	}
	public void setAntiTheftFlag(String antiTheftFlag) {
		this.antiTheftFlag = antiTheftFlag;
	}
	
}

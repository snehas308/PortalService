package com.majesco.dcf.common.tagic.json;

public class SpDetails {
	
private String 	spNo;
private String 	spName;
private String dat_end_date;  
private String txt_status;  
public String getSpNo() {
	return spNo;
}
public void setSpNo(String spNo) {
	this.spNo = spNo;
}
public String getSpName() {
	return spName;
}
public void setSpName(String spName) {
	this.spName = spName;
}
public String getDat_end_date() {
	return dat_end_date;
}
public void setDat_end_date(String dat_end_date) {
	this.dat_end_date = dat_end_date;
}
public String getTxt_status() {
	return txt_status;
}
public void setTxt_status(String txt_status) {
	this.txt_status = txt_status;
}

}

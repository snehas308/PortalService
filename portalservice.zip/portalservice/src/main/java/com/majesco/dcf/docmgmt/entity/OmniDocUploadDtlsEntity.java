package com.majesco.dcf.docmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

/**
 * @author yogesh570158
 *
 */
@Entity
@Table(name = "dcf_docupload_dtls_omnidoc")
public class OmniDocUploadDtlsEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="dcf_docupload_dtls_ndocid_seq")
	@SequenceGenerator(
			name="dcf_docupload_dtls_ndocid_seq",
			sequenceName="dcf_docupload_dtls_ndocid_seq",
			allocationSize=1
	)
	@Column(name = "ndocid")
	private long ndocid;
	
	@Column(name = "activestatus")
	private Integer activeStatus;
	
	@Column(name = "strproposalno")
	private String strProposalNo;
	
	@Column(name = "strpolicyno")
	private String  strPolicyNo;
	
	@Column(name = "strdocmodmapid")
	private String strDocmodMapId;
	
	@Column(name = "strdocindex")
	private String strDocIndex;
	
	@Column(name = "strDocName")
	private String strDocName;	
	
	@Column(name = "strdocpath")
	@Type(type="text")
	private String strDocPath;
		
	@Column(name = "strfileext")
	private String strFileExt;
	
	@Column(name = "strfilename")
	private String strFileName;
		
	@Column(name = "strfilesize")
	private String strFileSize;
	
	@Column(name = "strfiletype")
	private String strFileType;
		
	@Column(name = "strfunctionid")
	private String strFunctionId;
	
	@Column(name = "bhardcopy")
	private boolean bhardCopy = false;
		
	@Column(name = "bismandatory")
	private boolean bisMandatory = false;
	
	@Column(name = "strmodule")
	private String strModule;
		
	@Column(name = "strremarks")
	private String strRemarks;
	
	@Column(name = "struploadby")
	private String strUploadBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "uploaddate", insertable=false)
	private Date uploadDate;
	
	@Column(name = "nversion")
	private Integer nversion;
		
	@Column(name = "strcreatedby")
	private String strCreatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtcreated", insertable=false)
	private Date dtCreated;
	
	@Column(name = "strupdatedby")
	private String strUpdatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name= "dtupdated", insertable=false)
	private Date dtUpdated;
	
//	@Column(name = "ndocmodmapid")
//	private Integer ndocModMapId;
	
	@Column(name = "strdocstatus")
	private String strDocStatus;
	
	//Start:-@Yogesh|05/01/2018|Added code for defectId-1305
	@Column(name = "stromnidocstatus")
	private String strOmniDocStatus;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "dtomnidoc")
	private Date dtOmniDoc;
	
	@Column(name = "strisrenew")
	private String strIsRenew;
	//End:-@Yogesh|05/01/2018|Added code for defectId-1305
	
	
	@Column(name = "omni_flag")
	private String strOmniFlag;

	

	public String getStrOmniFlag() {
		return strOmniFlag;
	}

	public void setStrOmniFlag(String strOmniFlag) {
		this.strOmniFlag = strOmniFlag;
	}

	public long getNdocid() {
		return ndocid;
	}

	public void setNdocid(long ndocid) {
		this.ndocid = ndocid;
	}

	public Integer getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(Integer activeStatus) {
		this.activeStatus = activeStatus;
	}

	public String getStrProposalNo() {
		return strProposalNo;
	}

	public void setStrProposalNo(String strProposalNo) {
		this.strProposalNo = strProposalNo;
	}

	public String getStrPolicyNo() {
		return strPolicyNo;
	}

	public void setStrPolicyNo(String strPolicyNo) {
		this.strPolicyNo = strPolicyNo;
	}

	public String getStrDocmodMapId() {
		return strDocmodMapId;
	}

	public void setStrDocmodMapId(String strDocmodMapId) {
		this.strDocmodMapId = strDocmodMapId;
	}

	public String getStrDocIndex() {
		return strDocIndex;
	}

	public void setStrDocIndex(String strDocIndex) {
		this.strDocIndex = strDocIndex;
	}

	public String getStrDocName() {
		return strDocName;
	}

	public void setStrDocName(String strDocName) {
		this.strDocName = strDocName;
	}

	public String getStrDocPath() {
		return strDocPath;
	}

	public void setStrDocPath(String strDocPath) {
		this.strDocPath = strDocPath;
	}

	public String getStrFileExt() {
		return strFileExt;
	}

	public void setStrFileExt(String strFileExt) {
		this.strFileExt = strFileExt;
	}

	public String getStrFileName() {
		return strFileName;
	}

	public void setStrFileName(String strFileName) {
		this.strFileName = strFileName;
	}

	public String getStrFileSize() {
		return strFileSize;
	}

	public void setStrFileSize(String strFileSize) {
		this.strFileSize = strFileSize;
	}

	public String getStrFileType() {
		return strFileType;
	}

	public void setStrFileType(String strFileType) {
		this.strFileType = strFileType;
	}

	public String getStrFunctionId() {
		return strFunctionId;
	}

	public void setStrFunctionId(String strFunctionId) {
		this.strFunctionId = strFunctionId;
	}

	public boolean isBhardCopy() {
		return bhardCopy;
	}

	public void setBhardCopy(boolean bhardCopy) {
		this.bhardCopy = bhardCopy;
	}

	public boolean isBisMandatory() {
		return bisMandatory;
	}

	public void setBisMandatory(boolean bisMandatory) {
		this.bisMandatory = bisMandatory;
	}

	public String getStrModule() {
		return strModule;
	}

	public void setStrModule(String strModule) {
		this.strModule = strModule;
	}

	public String getStrRemarks() {
		return strRemarks;
	}

	public void setStrRemarks(String strRemarks) {
		this.strRemarks = strRemarks;
	}

	public String getStrUploadBy() {
		return strUploadBy;
	}

	public void setStrUploadBy(String strUploadBy) {
		this.strUploadBy = strUploadBy;
	}

	public Date getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}

	public Integer getNversion() {
		return nversion;
	}

	public void setNversion(Integer nversion) {
		this.nversion = nversion;
	}

	public String getStrDocStatus() {
		return strDocStatus;
	}

	public void setStrDocStatus(String strDocStatus) {
		this.strDocStatus = strDocStatus;
	}

	public String getStrCreatedBy() {
		return strCreatedBy;
	}

	public void setStrCreatedBy(String strCreatedBy) {
		this.strCreatedBy = strCreatedBy;
	}

	public Date getDtCreated() {
		return dtCreated;
	}

	public void setDtCreated(Date dtCreated) {
		this.dtCreated = dtCreated;
	}

	public String getStrUpdatedBy() {
		return strUpdatedBy;
	}

	public void setStrUpdatedBy(String strUpdatedBy) {
		this.strUpdatedBy = strUpdatedBy;
	}

	public Date getDtUpdated() {
		return dtUpdated;
	}

	public void setDtUpdated(Date dtUpdated) {
		this.dtUpdated = dtUpdated;
	}

	//Start:-@Yogesh|05/01/2018|Added code for defectId-1305
	public String getStrOmniDocStatus() {
		return strOmniDocStatus;
	}

	public void setStrOmniDocStatus(String strOmniDocStatus) {
		this.strOmniDocStatus = strOmniDocStatus;
	}

	public Date getDtOmniDoc() {
		return dtOmniDoc;
	}

	public void setDtOmniDoc(Date dtOmniDoc) {
		this.dtOmniDoc = dtOmniDoc;
	}

	public String getStrIsRenew() {
		return strIsRenew;
	}

	public void setStrIsRenew(String strIsRenew) {
		this.strIsRenew = strIsRenew;
	}
	//End:-@Yogesh|05/01/2018|Added code for defectId-1305
	
//	public Integer getNdocModMapId() {
//		return ndocModMapId;
//	}
//	public void setNdocModMapId(Integer ndocModMapId) {
//		this.ndocModMapId = ndocModMapId;
//	}
	
	
}

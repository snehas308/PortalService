package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;

public class PendingQuotesList {

	private int noOfPendingQuotes;
	private ArrayList<DashBoardSummaryDetails> dashBoardSummaryQuoteList;
	public int getNoOfPendingQuotes() {
		return noOfPendingQuotes;
	}
	public void setNoOfPendingQuotes(int noOfPendingQuotes) {
		this.noOfPendingQuotes = noOfPendingQuotes;
	}
	public ArrayList<DashBoardSummaryDetails> getDashBoardSummaryQuoteList() {
		return dashBoardSummaryQuoteList;
	}
	public void setDashBoardSummaryQuoteList(
			ArrayList<DashBoardSummaryDetails> dashBoardSummaryQuoteList) {
		this.dashBoardSummaryQuoteList = dashBoardSummaryQuoteList;
	}
	
}

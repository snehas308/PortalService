package com.majesco.dcf.claims.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ClaimServiceValidateSaveRequest extends UserObject {
	
	private String notifierType;
	private String notifierName;
	private String notifierContactNo;
	private String notifierEmail;
	private String policyNoCoverNoteNo;
	private String lossDate;
	private String generalDescOfDamage;
	private String insuredName;
	private String insuredLastName;
	private String insuredContactNo;
	private String insuredEmailID;
	private String accidentDesc;
	private String lobName;
	private String lobCode;
	private String prodCode;
	private String prodName;
	private String prodType;
	private String lossLocationPincode;
	private String lossLocationCountry;
	private String lossLocationState;
	private String lossLocationDistrict;
	private String lossLocationCity;
	private String wasVehicleParked;
	private String nearestCityForRepair;
	private String anyInjuryToTPPD;
	private String driverName;
	private String driverLicenceNumber;
	private String lossDescCode;
	private String lossDescName;
	private String otherLossDesc;
	private String servOfficename;
	private String servOfficeCode;
	private String locationLandmark;
	private String intimationDate;
	private String intimationTime;
	private String nolCode;
	private String nolName;
	private String causeOfLossCode;
	private String anatCode;
	private String injuryCode;
	private String lossTime;
	private String examinerCode;
	private String examinername;
	
	public String getLossDate() {
		return lossDate;
	}
	public void setLossDate(String lossDate) {
		this.lossDate = lossDate;
	}
	public String getGeneralDescOfDamage() {
		return generalDescOfDamage;
	}
	public void setGeneralDescOfDamage(String generalDescOfDamage) {
		this.generalDescOfDamage = generalDescOfDamage;
	}
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}
	public String getLobName() {
		return lobName;
	}
	public void setLobName(String lobName) {
		this.lobName = lobName;
	}
	public String getLobCode() {
		return lobCode;
	}
	public void setLobCode(String lobCode) {
		this.lobCode = lobCode;
	}
	public String getProdCode() {
		return prodCode;
	}
	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getProdType() {
		return prodType;
	}
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}
	public String getLossLocationPincode() {
		return lossLocationPincode;
	}
	public void setLossLocationPincode(String lossLocationPincode) {
		this.lossLocationPincode = lossLocationPincode;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public String getDriverLicenceNumber() {
		return driverLicenceNumber;
	}
	public void setDriverLicenceNumber(String driverLicenceNumber) {
		this.driverLicenceNumber = driverLicenceNumber;
	}
	public String getLossDescCode() {
		return lossDescCode;
	}
	public void setLossDescCode(String lossDescCode) {
		this.lossDescCode = lossDescCode;
	}
	public String getLossDescName() {
		return lossDescName;
	}
	public void setLossDescName(String lossDescName) {
		this.lossDescName = lossDescName;
	}
	public String getOtherLossDesc() {
		return otherLossDesc;
	}
	public void setOtherLossDesc(String otherLossDesc) {
		this.otherLossDesc = otherLossDesc;
	}
	public String getServOfficename() {
		return servOfficename;
	}
	public void setServOfficename(String servOfficename) {
		this.servOfficename = servOfficename;
	}
	public String getServOfficeCode() {
		return servOfficeCode;
	}
	public void setServOfficeCode(String servOfficeCode) {
		this.servOfficeCode = servOfficeCode;
	}
	public String getLocationLandmark() {
		return locationLandmark;
	}
	public void setLocationLandmark(String locationLandmark) {
		this.locationLandmark = locationLandmark;
	}
	public String getIntimationDate() {
		return intimationDate;
	}
	public void setIntimationDate(String intimationDate) {
		this.intimationDate = intimationDate;
	}
	public String getIntimationTime() {
		return intimationTime;
	}
	public void setIntimationTime(String intimationTime) {
		this.intimationTime = intimationTime;
	}
	public String getNolCode() {
		return nolCode;
	}
	public void setNolCode(String nolCode) {
		this.nolCode = nolCode;
	}
	public String getNolName() {
		return nolName;
	}
	public void setNolName(String nolName) {
		this.nolName = nolName;
	}
	public String getCauseOfLossCode() {
		return causeOfLossCode;
	}
	public void setCauseOfLossCode(String causeOfLossCode) {
		this.causeOfLossCode = causeOfLossCode;
	}
	public String getAnatCode() {
		return anatCode;
	}
	public void setAnatCode(String anatCode) {
		this.anatCode = anatCode;
	}
	public String getInjuryCode() {
		return injuryCode;
	}
	public void setInjuryCode(String injuryCode) {
		this.injuryCode = injuryCode;
	}
	public String getLossTime() {
		return lossTime;
	}
	public void setLossTime(String lossTime) {
		this.lossTime = lossTime;
	}
	public String getExaminerCode() {
		return examinerCode;
	}
	public void setExaminerCode(String examinerCode) {
		this.examinerCode = examinerCode;
	}
	public String getExaminername() {
		return examinername;
	}
	public void setExaminername(String examinername) {
		this.examinername = examinername;
	}
	public String getNotifierType() {
		return notifierType;
	}
	public void setNotifierType(String notifierType) {
		this.notifierType = notifierType;
	}
	public String getNotifierName() {
		return notifierName;
	}
	public void setNotifierName(String notifierName) {
		this.notifierName = notifierName;
	}
	public String getNotifierContactNo() {
		return notifierContactNo;
	}
	public void setNotifierContactNo(String notifierContactNo) {
		this.notifierContactNo = notifierContactNo;
	}
	public String getNotifierEmail() {
		return notifierEmail;
	}
	public void setNotifierEmail(String notifierEmail) {
		this.notifierEmail = notifierEmail;
	}
	public String getPolicyNoCoverNoteNo() {
		return policyNoCoverNoteNo;
	}
	public void setPolicyNoCoverNoteNo(String policyNoCoverNoteNo) {
		this.policyNoCoverNoteNo = policyNoCoverNoteNo;
	}
	public String getInsuredLastName() {
		return insuredLastName;
	}
	public void setInsuredLastName(String insuredLastName) {
		this.insuredLastName = insuredLastName;
	}
	public String getInsuredContactNo() {
		return insuredContactNo;
	}
	public void setInsuredContactNo(String insuredContactNo) {
		this.insuredContactNo = insuredContactNo;
	}
	public String getInsuredEmailID() {
		return insuredEmailID;
	}
	public void setInsuredEmailID(String insuredEmailID) {
		this.insuredEmailID = insuredEmailID;
	}
	public String getAccidentDesc() {
		return accidentDesc;
	}
	public void setAccidentDesc(String accidentDesc) {
		this.accidentDesc = accidentDesc;
	}
	public String getLossLocationCountry() {
		return lossLocationCountry;
	}
	public void setLossLocationCountry(String lossLocationCountry) {
		this.lossLocationCountry = lossLocationCountry;
	}
	public String getLossLocationState() {
		return lossLocationState;
	}
	public void setLossLocationState(String lossLocationState) {
		this.lossLocationState = lossLocationState;
	}
	public String getLossLocationDistrict() {
		return lossLocationDistrict;
	}
	public void setLossLocationDistrict(String lossLocationDistrict) {
		this.lossLocationDistrict = lossLocationDistrict;
	}
	public String getLossLocationCity() {
		return lossLocationCity;
	}
	public void setLossLocationCity(String lossLocationCity) {
		this.lossLocationCity = lossLocationCity;
	}
	public String getWasVehicleParked() {
		return wasVehicleParked;
	}
	public void setWasVehicleParked(String wasVehicleParked) {
		this.wasVehicleParked = wasVehicleParked;
	}
	public String getNearestCityForRepair() {
		return nearestCityForRepair;
	}
	public void setNearestCityForRepair(String nearestCityForRepair) {
		this.nearestCityForRepair = nearestCityForRepair;
	}
	public String getAnyInjuryToTPPD() {
		return anyInjuryToTPPD;
	}
	public void setAnyInjuryToTPPD(String anyInjuryToTPPD) {
		this.anyInjuryToTPPD = anyInjuryToTPPD;
	}
	
	
	
}

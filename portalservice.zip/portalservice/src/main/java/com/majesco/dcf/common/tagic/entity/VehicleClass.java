package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_vehicle_class_m",schema="dcf_master")			// Commented for Oracle Migration
@Table(name = "dcf_vehicle_class_m")								// Added for Oracle Migration
public class VehicleClass {
	
	private String strvehicleclasscd;
	private String strvehicleclassdesc;
	private String strvehicleclassshortdesc;
	private String strvehiclecatcd;
	private String strallowsubclass;
	private String dtstart;
	private String dtend;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	private String strstatus;
	
	
	@Id
	@Column(name = "strvehicleclasscd")
	public String getStrvehicleclasscd() {
		return strvehicleclasscd;
	}
	public void setStrvehicleclasscd(String strvehicleclasscd) {
		this.strvehicleclasscd = strvehicleclasscd;
	}
	
	
	@Column(name = "strvehicleclassdesc")
	public String getStrvehicleclassdesc() {
		return strvehicleclassdesc;
	}
	public void setStrvehicleclassdesc(String strvehicleclassdesc) {
		this.strvehicleclassdesc = strvehicleclassdesc;
	}
	
	
	@Column(name = "strvehicleclassshortdesc")
	public String getStrvehicleclassshortdesc() {
		return strvehicleclassshortdesc;
	}
	public void setStrvehicleclassshortdesc(String strvehicleclassshortdesc) {
		this.strvehicleclassshortdesc = strvehicleclassshortdesc;
	}
	
	
	@Column(name = "strvehiclecatcd")
	public String getStrvehiclecatcd() {
		return strvehiclecatcd;
	}
	public void setStrvehiclecatcd(String strvehiclecatcd) {
		this.strvehiclecatcd = strvehiclecatcd;
	}
	
	
	@Column(name = "strallowsubclass")
	public String getStrallowsubclass() {
		return strallowsubclass;
	}
	public void setStrallowsubclass(String strallowsubclass) {
		this.strallowsubclass = strallowsubclass;
	}
	
	
	@Column(name = "dtstart")
	public String getDtstart() {
		return dtstart;
	}
	public void setDtstart(String dtstart) {
		this.dtstart = dtstart;
	}
	
	
	@Column(name = "dtend")
	public String getDtend() {
		return dtend;
	}
	public void setDtend(String dtend) {
		this.dtend = dtend;
	}
	
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	
	@Column(name = "strstatus")
	public String getStrstatus() {
		return strstatus;
	}
	public void setStrstatus(String strstatus) {
		this.strstatus = strstatus;
	}

}

package com.majesco.dcf.common.tagic.json;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ValueByEffDateRequest extends UserObject {

	private String amountKey;
	private String effDate;
	private String policyTerm; /*Added For CR 1528 - Ketan*/
	private String productCode; /*Added For CR 1528 - Ketan*/
	

	public String getAmountKey() {
		return amountKey;
	}
	public void setAmountKey(String amountKey) {
		this.amountKey = amountKey;
	}
	public String getEffDate() {
		return effDate;
	}
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	/*START - Added For CR 1528 - Ketan*/
	public String getPolicyTerm() {
		return policyTerm;
	}
	public void setPolicyTerm(String policyTerm) {
		this.policyTerm = policyTerm;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	/*END - Added For CR 1528 - Ketan*/
	
	
	
}

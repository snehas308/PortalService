package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.ResponseError;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DocListResponse {
	private List<String> strdcodesc;
	private List<String> strdoccd;
	private List<ResponseError> resErr;
	
	public List<String> getStrdcodesc() {
		return strdcodesc;
	}
	public void setStrdcodesc(List<String> strdcodesc) {
		this.strdcodesc = strdcodesc;
	}
				
	public List<String> getStrdoccd() {
		return strdoccd;
	}
	public void setStrdoccd(List<String> strdoccd) {
		this.strdoccd = strdoccd;
	}
	public List<ResponseError> getResErr() {
		return resErr;
	}
	public void setResErr(List<ResponseError> resErr) {
		this.resErr = resErr;
	}
}

package com.majesco.dcf.common.tagic.json;

public class ExceptionPolicy {
	
	private String orderId;
	private String jsonRequest;
	private String postAuthCode;
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getJsonRequest() {
		return jsonRequest;
	}
	public void setJsonRequest(String jsonRequest) {
		this.jsonRequest = jsonRequest;
	}
	public String getPostAuthCode() {
		return postAuthCode;
	}
	public void setPostAuthCode(String postAuthCode) {
		this.postAuthCode = postAuthCode;
	}
	
	

}

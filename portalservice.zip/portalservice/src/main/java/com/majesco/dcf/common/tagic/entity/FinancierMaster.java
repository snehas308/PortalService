package com.majesco.dcf.common.tagic.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_vh_financier_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_vh_financier_m")								// Added for Oracle Migration
public class FinancierMaster {
	private String strfinanciercd="";
	private String strfinanciername ="";
	private String strfinanciershortname  ="";
	private String strfinanciertype  ="";
	private String strstatus  ="";
	private String strdefaultflag  ="";
	private String strpanno  ="";
	private String dtcreated  ="";
	private String strcreatedby  ="";
	private String dtupdated  ="";
	private String strupdatedby  ="";
	private Integer nisactive;

	@Id
	@Column(name = "strfinanciercd")
	public String getStrfinanciercd() {
		return strfinanciercd;
	}
	public void setStrfinanciercd(String strfinanciercd) {
		this.strfinanciercd = strfinanciercd;
	}
	
	@Column(name = "strfinanciername")
	public String getStrfinanciername() {
		return strfinanciername;
	}
	public void setStrfinanciername(String strfinanciername) {
		this.strfinanciername = strfinanciername;
	}
	
	@Column(name = "strfinanciershortname")
	public String getStrfinanciershortname() {
		return strfinanciershortname;
	}
	public void setStrfinanciershortname(String strfinanciershortname) {
		this.strfinanciershortname = strfinanciershortname;
	}
	
	@Column(name = "strfinanciertype")
	public String getStrfinanciertype() {
		return strfinanciertype;
	}
	public void setStrfinanciertype(String strfinanciertype) {
		this.strfinanciertype = strfinanciertype;
	}
	
	@Column(name = "strstatus")
	public String getStrstatus() {
		return strstatus;
	}
	public void setStrstatus(String strstatus) {
		this.strstatus = strstatus;
	}
	
	@Column(name = "strpanno")
	public String getStrpanno() {
		return strpanno;
	}
	public void setStrpanno(String strpanno) {
		this.strpanno = strpanno;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	@Column(name = "strdefaultflag")
	public String getStrdefaultflag() {
		return strdefaultflag;
	}
	public void setStrdefaultflag(String strdefaultflag) {
		this.strdefaultflag = strdefaultflag;
	}
	
	@Column(name = "nisactive")
	public Integer getNisactive() {
		return nisactive;
	}
	public void setNisactive(Integer nisactive) {
		this.nisactive = nisactive;
	}
	
}

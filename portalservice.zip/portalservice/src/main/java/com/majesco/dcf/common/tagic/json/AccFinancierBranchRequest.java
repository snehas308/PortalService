package com.majesco.dcf.common.tagic.json;

import java.math.BigDecimal;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class AccFinancierBranchRequest {
	private String strIFSCCD ="";

	public String getStrIFSCCD() {
		return strIFSCCD;
	}

	public void setStrIFSCCD(String strIFSCCD) {
		this.strIFSCCD = strIFSCCD;
	}
	
}

package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class ModelRequest {
	
	private String strmanufacturercd;
	private String strprodcd;


	
	public String getStrmanufacturercd() {
		return strmanufacturercd;
	}
	public void setStrmanufacturercd(String strmanufacturercd) {
		this.strmanufacturercd = strmanufacturercd;
	}
	public String getStrprodcd() {
		return strprodcd;
	}
	public void setStrprodcd(String strprodcd) {
		this.strprodcd = strprodcd;
	}
	
	
}

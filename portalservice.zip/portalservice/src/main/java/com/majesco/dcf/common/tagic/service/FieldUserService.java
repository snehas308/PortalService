package com.majesco.dcf.common.tagic.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.ehcache.annotations.Cacheable;
import com.majesco.dcf.common.tagic.entity.FieldUser;
import com.majesco.dcf.common.tagic.entity.RTOLocation;
import com.majesco.dcf.common.tagic.json.FieldUserRequest;
import com.majesco.dcf.common.tagic.json.FieldUserResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;


@Service
public class FieldUserService {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(FieldUserService.class);
	
	@SuppressWarnings("null")
	@Cacheable(cacheName="fieldUserInfoEhcache")
	public FieldUserResponse getFieldUser(FieldUserRequest modelreq) throws Exception
	{
		FieldUserResponse modelres = new FieldUserResponse();
		//AccFinancierVO_old docVO = null;
		try
		{
		
			logger.info("In ModelService.getModelInfo() Method Begin()...");
			
			List<BigDecimal> nfieldusercd= new ArrayList<BigDecimal>();
			List<String> struserid= new ArrayList<String>();
			List<String> strfieldusername= new ArrayList<String>();
			
			List<ResponseError> reserrList = new ArrayList<ResponseError>();
			
			ResponseError res = new ResponseError();
			res.setErrorCode("101");
			res.setErrorMMessag("Sorry Authentication Issue....");
			reserrList.add(res);
			
			@SuppressWarnings("unchecked")
			List docArr = new ArrayList();
			docArr = (ArrayList<Object>) dbserv.getFieldUser("com.majesco.dcf.common.tagic.entity.FieldUser", modelreq);
			for(int i=0; i< docArr.size(); i++)
			{
		        FieldUser ent = new FieldUser();
		        ent = (FieldUser) docArr.get(i);
				nfieldusercd.add(ent.getNfieldusercd());
				struserid.add(ent.getStruserid());
				strfieldusername.add(ent.getStrfieldusername());
	        }
			modelres.setNfieldusercd(nfieldusercd);
			modelres.setStruserid(struserid);
			modelres.setStrfieldusername(strfieldusername);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.info("Exception StackTrace : ", e);
		}
		logger.info("In ModelService.getModelInfo() Method End()...");
		ObjectMapper objMap=new ObjectMapper();
		//System.out.println(objMap.writeValueAsString(modelres));
		logger.info("In ModelService.getModelInfo() Method ::: "+modelres);
		
		return modelres;
	}
	
	public Integer nullCheckInt(Object obj)
    {
  	  if(obj==null)
  		  return 0;
  	  else
  		  return (Integer) obj;
    }
    
    public double nullCheckDouble(Object obj)
    {
  	  if(obj==null)
  		  return 0.0;
  	  else
  		  return (double) obj;
    }
    
    public String nullCheckString(String obj)
    {
  	  if(obj==null)
  		  return "";
  	  else
  		  return (String) obj;
    }
}

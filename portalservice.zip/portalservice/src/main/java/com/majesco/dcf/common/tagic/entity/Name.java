package com.majesco.dcf.common.tagic.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

/*@Entity
@Table(name = "dif_parameter_lst",schema="dcf_master")*/
public class Name {

	private String firstname;
	private String lastname;
	private String studentid;
	
}

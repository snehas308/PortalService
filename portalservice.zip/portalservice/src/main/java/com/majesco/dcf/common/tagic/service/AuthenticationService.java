package com.majesco.dcf.common.tagic.service;

import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.majesco.dcf.common.tagic.json.AuthenticationRequest;
import com.majesco.dcf.common.tagic.json.AuthenticationResponse;
import com.majesco.dcf.common.tagic.json.ResponseError;
import com.majesco.dcf.constant.CommonConstants;
import com.majesco.dcf.motor.json.CalculatorMotorRequest;
import com.majesco.dcf.motor.json.CalculatorMotorResponse;
import com.majesco.dcf.motor.serviceImpl.MotorServiceImpl;
import com.majesco.dcf.common.chp.util.CdataWriterInterceptor;
import com.unotechsoft.stub.authentication.client.Authenticate;
import com.unotechsoft.stub.authentication.client.AuthenticationService_Service;
import com.unotechsoft.stub.authentication.client.GetUserName;
import com.unotechsoft.stub.authentication.client.GetUserNameResponse;
import com.unotechsoft.stub.motorservice.client.MotorService_Service;
import com.unotechsoft.stub.motorservice.client.QuotationRequest;
import com.unotechsoft.stub.motorservice.client.QuotationResponse;


@Service
@Transactional
public class AuthenticationService {
	
	@Autowired
	DBService dbserv;
	
	final static Logger logger=Logger.getLogger(AuthenticationService.class);
	
	public String propValue="";
	
	public String getWSDLURL(String param)
	{
		String propVal="";
		try
		{
			propVal = dbserv.getWSDLURL(param,"com.majesco.dcf.common.tagic.entity.InterfaceParam");
			return propVal;
		}
		catch(Exception ae)
		{
			logger.error("Inside MotorServiceImpl :: getWSDLURL() method ::",ae);
		}
		return propVal;
	}
	
	public AuthenticationResponse getAuthenticationToken(AuthenticationRequest authReq) throws Exception
	{
		AuthenticationResponse authRes = new AuthenticationResponse();
		
		List<ResponseError> reserrList;
		reserrList = new ArrayList<ResponseError>();
		
		if(propValue.equalsIgnoreCase(""))
			propValue = this.getWSDLURL(CommonConstants.AUTHENTICATION_SERVICE);
		
		try
		{
			URL url = new URL(propValue);
			AuthenticationService_Service stub = new AuthenticationService_Service(url);
			GetUserName reqQ = new GetUserName();
			
			com.unotechsoft.stub.authentication.client.AuthenticationService port = stub.getSOAPOverHTTP();
			
			Client client=ClientProxy.getClient(port);
			PrintWriter writer = new PrintWriter(System.out);
			
			client.getOutInterceptors().add(new CdataWriterInterceptor());
			
			client.getInInterceptors().add(new LoggingInInterceptor(writer));
			
			client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
			
			/*Added Changes On 14/02/2017 as per mail confirmation on 14/02/2017 1.41PM*/
			authReq.setSource(CommonConstants.BLANK_STRING);
			authReq.setMedium(CommonConstants.BLANK_STRING);
			authReq.setCampain(CommonConstants.BLANK_STRING);
			/*Added Changes On 14/02/2017 as per mail confirmation on 14/02/2017 1.41PM*/
			
			String response = port.authenticate(authReq.getSource(), authReq.getMedium(), authReq.getCampain(), authReq.getUserID(), authReq.getPassword());
			
			
			if(response!=null && !response.equalsIgnoreCase(""))
			{
				authRes.setResultCode("1");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError errorRes=new ResponseError();
				errorRes.setErrorCode("NOERR");
				errorRes.setErrorMMessag("NO ERROR");
				errorList.add(errorRes);
				authRes.setResErr(errorList);
				
				authRes.setResultRes(response);
			}
			
		}
		catch(Exception e)
		{
			authRes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERROR");
			errorRes.setErrorMMessag("PROBLEM WHILE RECIEVING AUTHENTICATION TOKEN.....");
			errorList.add(errorRes);
			authRes.setResErr(errorList);
			
			authRes.setResultRes("");
			logger.error("Exception Occurred In AuthenticationService :: getAuthenticationToken() : "+e);
		}
		
		return authRes;
	}
	
	
	
	public AuthenticationResponse getAuthenticationTokenTest(String source, String medium, String campain, String userID, String password) throws Exception
	{
		AuthenticationResponse authRes = new AuthenticationResponse();
		
		List<ResponseError> reserrList;
		reserrList = new ArrayList<ResponseError>();
		
		if(propValue.equalsIgnoreCase(""))
			propValue = this.getWSDLURL(CommonConstants.AUTHENTICATION_SERVICE);
		
		try
		{
			URL url = new URL(propValue);
			AuthenticationService_Service stub = new AuthenticationService_Service(url);
			GetUserName reqQ = new GetUserName();
			
			com.unotechsoft.stub.authentication.client.AuthenticationService port = stub.getSOAPOverHTTP();
			
			Client client=ClientProxy.getClient(port);
			PrintWriter writer = new PrintWriter(System.out);
			
			client.getOutInterceptors().add(new CdataWriterInterceptor());
			
			client.getInInterceptors().add(new LoggingInInterceptor(writer));
			
			client.getOutInterceptors().add(new LoggingOutInterceptor(writer));
			
			/*Added Changes On 14/02/2017 as per mail confirmation on 14/02/2017 1.41PM*/
			source = CommonConstants.BLANK_STRING;
			medium = CommonConstants.BLANK_STRING;
			campain = CommonConstants.BLANK_STRING;
			/*Added Changes On 14/02/2017 as per mail confirmation on 14/02/2017 1.41PM*/
			
			String response = port.authenticate(source, medium, campain, userID, password);
			
			//System.out.println("response.........................................."+response);
			
			if(response!=null && !response.equalsIgnoreCase(""))
			{
				authRes.setResultCode("1");
				List<ResponseError> errorList=new ArrayList<ResponseError>();
				ResponseError errorRes=new ResponseError();
				errorRes.setErrorCode("NOERR");
				errorRes.setErrorMMessag("NO ERROR");
				errorList.add(errorRes);
				authRes.setResErr(errorList);
				
				authRes.setResultRes(response);
			}
			
		}
		catch(Exception e)
		{
			authRes.setResultCode("0");
			List<ResponseError> errorList=new ArrayList<ResponseError>();
			ResponseError errorRes=new ResponseError();
			errorRes.setErrorCode("ERROR");
			errorRes.setErrorMMessag("PROBLEM WHILE RECIEVING AUTHENTICATION TOKEN.....");
			errorList.add(errorRes);
			authRes.setResErr(errorList);
			
			authRes.setResultRes("");
			logger.error("Exception Occurred In AuthenticationService :: getAuthenticationToken() : "+e);
		}
		
		return authRes;
	}

}

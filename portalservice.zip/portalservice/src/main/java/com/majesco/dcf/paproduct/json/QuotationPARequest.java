package com.majesco.dcf.paproduct.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class QuotationPARequest {

	private String strprdcd;// ProductCode
	private String insurFor;//InsuranceFor
	private String strplantype;//PlanType
	private String occupClass;//OccupationClass
	private Integer annualInc;//AnnualIncome
	private Integer coreBenUnit;//CoreBenUnit
	private Integer coreBenNumber;
	private String weekIndemAppl;//WeeklyIndemnityAppl
	private Integer weekIndemNbr;//WeeklyIndemnityNumber
	private Integer tenure;
	private String benPerMonth;//BenefitPerMonth
	private String payoutPer;//PayoutPeriod
	public String getStrprdcd() {
		return strprdcd;
	}
	public void setStrprdcd(String strprdcd) {
		this.strprdcd = strprdcd;
	}
	public String getInsurFor() {
		return insurFor;
	}
	public void setInsurFor(String insurFor) {
		this.insurFor = insurFor;
	}
	public String getStrplantype() {
		return strplantype;
	}
	public void setStrplantype(String strplantype) {
		this.strplantype = strplantype;
	}
	public String getOccupClass() {
		return occupClass;
	}
	public void setOccupClass(String occupClass) {
		this.occupClass = occupClass;
	}
	public Integer getAnnualInc() {
		return annualInc;
	}
	public void setAnnualInc(Integer annualInc) {
		this.annualInc = annualInc;
	}
	public Integer getCoreBenUnit() {
		return coreBenUnit;
	}
	public void setCoreBenUnit(Integer coreBenUnit) {
		this.coreBenUnit = coreBenUnit;
	}
	public Integer getCoreBenNumber() {
		return coreBenNumber;
	}
	public void setCoreBenNumber(Integer coreBenNumber) {
		this.coreBenNumber = coreBenNumber;
	}
	public String getWeekIndemAppl() {
		return weekIndemAppl;
	}
	public void setWeekIndemAppl(String weekIndemAppl) {
		this.weekIndemAppl = weekIndemAppl;
	}
	public Integer getWeekIndemNbr() {
		return weekIndemNbr;
	}
	public void setWeekIndemNbr(Integer weekIndemNbr) {
		this.weekIndemNbr = weekIndemNbr;
	}
	public Integer getTenure() {
		return tenure;
	}
	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}
	public String getBenPerMonth() {
		return benPerMonth;
	}
	public void setBenPerMonth(String benPerMonth) {
		this.benPerMonth = benPerMonth;
	}
	public String getPayoutPer() {
		return payoutPer;
	}
	public void setPayoutPer(String payoutPer) {
		this.payoutPer = payoutPer;
	}

	
	
}

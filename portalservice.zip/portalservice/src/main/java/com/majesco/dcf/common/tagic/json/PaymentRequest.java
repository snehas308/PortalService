package com.majesco.dcf.common.tagic.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class PaymentRequest {
	private String orderID;
	private String amt;
	private String userId;
	private String txtPayCategory;
	private String txtModeValue;
	private String productCode;
	private String producerCode;
	
	public String getOrderID() {
		return orderID;
	}
	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}
	public String getAmt() {
		return amt;
	}
	public void setAmt(String amt) {
		this.amt = amt;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getTxtPayCategory() {
		return txtPayCategory;
	}
	public void setTxtPayCategory(String txtPayCategory) {
		this.txtPayCategory = txtPayCategory;
	}
	public String getTxtModeValue() {
		return txtModeValue;
	}
	public void setTxtModeValue(String txtModeValue) {
		this.txtModeValue = txtModeValue;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProducerCode() {
		return producerCode;
	}
	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}

	
}

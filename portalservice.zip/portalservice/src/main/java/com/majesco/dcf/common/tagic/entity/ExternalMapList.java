package com.majesco.dcf.common.tagic.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "dcf_ext_system_data_map_m",schema="dcf_master")		// Commented for Oracle Migration
@Table(name = "dcf_ext_system_data_map_m")								// Added for Oracle Migration	
public class ExternalMapList implements Serializable{
	
	private String strdatacatg;
	private String strdcfparamcd;
	private String strdcfparamdesc;
	private String strextcd;
	private String strextcddesc;
	private String dtcreated;
	private String strcreatedby;
	private String dtupdated;
	private String strupdatedby;
	
	@Id
	@Column(name = "strdatacatg")
	public String getStrdatacatg() {
		return strdatacatg;
	}
	public void setStrdatacatg(String strdatacatg) {
		this.strdatacatg = strdatacatg;
	}
	
	@Id
	@Column(name = "strdcfparamcd")
	public String getStrdcfparamcd() {
		return strdcfparamcd;
	}
	public void setStrdcfparamcd(String strdcfparamcd) {
		this.strdcfparamcd = strdcfparamcd;
	}
	
	@Column(name = "strdcfparamdesc")
	public String getStrdcfparamdesc() {
		return strdcfparamdesc;
	}
	public void setStrdcfparamdesc(String strdcfparamdesc) {
		this.strdcfparamdesc = strdcfparamdesc;
	}
	
	@Column(name = "strextcd")
	public String getStrextcd() {
		return strextcd;
	}
	public void setStrextcd(String strextcd) {
		this.strextcd = strextcd;
	}
	
	@Column(name = "strextcddesc")
	public String getStrextcddesc() {
		return strextcddesc;
	}
	public void setStrextcddesc(String strextcddesc) {
		this.strextcddesc = strextcddesc;
	}
	
	@Column(name = "dtcreated")
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	
	@Column(name = "strcreatedby")
	public String getStrcreatedby() {
		return strcreatedby;
	}
	public void setStrcreatedby(String strcreatedby) {
		this.strcreatedby = strcreatedby;
	}
	
	@Column(name = "dtupdated")
	public String getDtupdated() {
		return dtupdated;
	}
	public void setDtupdated(String dtupdated) {
		this.dtupdated = dtupdated;
	}
	
	@Column(name = "strupdatedby")
	public String getStrupdatedby() {
		return strupdatedby;
	}
	public void setStrupdatedby(String strupdatedby) {
		this.strupdatedby = strupdatedby;
	}
	
	

}

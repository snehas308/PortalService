package com.majesco.dcf.covernote.json;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.majesco.dcf.common.tagic.json.UserObject;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class NextUnusedLeafNoRequest extends UserObject{
	private String bookNumber;

	public String getBookNumber() {
		return bookNumber;
	}

	public void setBookNumber(String bookNumber) {
		this.bookNumber = bookNumber;
	}

}

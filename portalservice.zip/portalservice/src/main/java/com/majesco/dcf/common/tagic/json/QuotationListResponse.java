package com.majesco.dcf.common.tagic.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class QuotationListResponse {

	private String resultCode;
	private List<ResponseError> errorList;
	private List<QuotationSearchResponse> quoteList;
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public List<ResponseError> getErrorList() {
		return errorList;
	}
	public void setErrorList(List<ResponseError> errorList) {
		this.errorList = errorList;
	}
	public List<QuotationSearchResponse> getQuoteList() {
		return quoteList;
	}
	public void setQuoteList(List<QuotationSearchResponse> quoteList) {
		this.quoteList = quoteList;
	}
	
	
}

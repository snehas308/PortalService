package com.majesco.dcf.covernote.json;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class AgentCoverNoteBook {
	
	private List<String> coverNoteBookList;
	private String errorText;

	public List<String> getCoverNoteBookList() {
		return coverNoteBookList;
	}

	public void setCoverNoteBookList(List<String> coverNoteBookList) {
		this.coverNoteBookList = coverNoteBookList;
	}

	public String getErrorText() {
		return errorText;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

}
